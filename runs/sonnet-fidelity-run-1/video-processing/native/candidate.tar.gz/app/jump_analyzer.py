import sys
import cv2
import numpy as np


def analyze(path):
    cap = cv2.VideoCapture(path)
    bg = None
    bottoms, areas = [], []
    while True:
        ok, f = cap.read()
        if not ok:
            break
        g = cv2.GaussianBlur(cv2.cvtColor(f, cv2.COLOR_BGR2GRAY), (5, 5), 0)
        if bg is None:
            bg = g
        m = (cv2.absdiff(g, bg) > 35).astype(np.uint8)
        m = cv2.morphologyEx(m, cv2.MORPH_OPEN, np.ones((5, 5), np.uint8))
        ys, _ = np.nonzero(m)
        areas.append(len(ys))
        bottoms.append(np.percentile(ys, 99) if len(ys) > 2000 else -1)
    n = len(bottoms)
    # longest run of frames with the runner present
    best, cur, start = (0, 0), 0, 0
    for i in range(n + 1):
        if i < n and bottoms[i] >= 0:
            if cur == 0:
                start = i
            cur += 1
        else:
            if cur > best[1]:
                best = (start, cur)
            cur = 0
    s, e = best[0], best[0] + best[1]
    b = np.array(bottoms[s:e])
    if len(b) < 5:
        return 0, max(n - 1, 0)
    ground = np.percentile(b, 85)
    thr = ground - 12
    air = np.nonzero(b < thr)[0]
    # biggest contiguous airborne stretch (in the stable middle)
    groups, g0 = [], air[0]
    for a, c in zip(air[:-1], air[1:]):
        if c - a > 2:
            groups.append((g0, a))
            g0 = c
    groups.append((g0, air[-1]))
    g0, g1 = max(groups, key=lambda t: t[1] - t[0])
    return s + int(g0) - 1, s + int(g1) + 1


if __name__ == "__main__":
    src = sys.argv[1] if len(sys.argv) > 1 else "/app/example_video.mp4"
    out = sys.argv[2] if len(sys.argv) > 2 else "/app/output.toml"
    t, l = analyze(src)
    with open(out, "w") as fh:
        fh.write("jump_takeoff_frame_number = %d\njump_land_frame_number = %d\n" % (t, l))
