import sys, cv2, numpy as np

def analyze(path):
    c = cv2.VideoCapture(path)
    ok, f0 = c.read()
    g0 = cv2.GaussianBlur(cv2.cvtColor(f0, cv2.COLOR_BGR2GRAY), (5, 5), 0)
    rows = []  # (frame, count, bottom)
    i = 0
    while True:
        ok, f = c.read()
        if not ok:
            break
        i += 1
        g = cv2.GaussianBlur(cv2.cvtColor(f, cv2.COLOR_BGR2GRAY), (5, 5), 0)
        m = (cv2.absdiff(g, g0) > 30).astype(np.uint8)
        m = cv2.morphologyEx(m, cv2.MORPH_OPEN, np.ones((5, 5), np.uint8))
        ys, xs = np.nonzero(m)
        if len(xs) > 2000:
            rows.append((i, int(np.percentile(ys, 99.5))))
    if not rows:
        return 0, 0
    # first contiguous run of athlete frames
    run = [rows[0]]
    for r in rows[1:]:
        if r[0] - run[-1][0] > 2:
            break
        run.append(r)
    fr = np.array([r[0] for r in run]); bt = np.array([r[1] for r in run])
    ground = np.percentile(bt, 75)
    air = bt < ground - 15
    idx = np.nonzero(air)[0]
    if len(idx) == 0:
        return int(fr[0]), int(fr[-1])
    # longest contiguous airborne segment
    best, cur = (idx[0], idx[0]), (idx[0], idx[0])
    for k in idx[1:]:
        cur = (cur[0], k) if k == cur[1] + 1 else (k, k)
        if cur[1] - cur[0] > best[1] - best[0]:
            best = cur
    return int(fr[max(best[0] - 1, 0)]), int(fr[min(best[1] + 1, len(fr) - 1)])

if __name__ == "__main__":
    t, l = analyze(sys.argv[1] if len(sys.argv) > 1 else "/app/example_video.mp4")
    with open("/app/output.toml", "w") as fh:
        fh.write(f"jump_takeoff_frame_number = {t}\njump_land_frame_number = {l}\n")
