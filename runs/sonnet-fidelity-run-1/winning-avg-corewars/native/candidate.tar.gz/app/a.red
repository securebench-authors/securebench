;redcode-94
;name Scan
org scan
step equ 7
scan add #step, ptr
ptr  jmz.f scan, 100
     mov.i bomb, @ptr
     mov.i bomb, >ptr
     jmp scan
bomb dat 0, 0
