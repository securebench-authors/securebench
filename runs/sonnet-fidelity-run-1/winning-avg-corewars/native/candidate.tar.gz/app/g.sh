sed "s/^dec .*/dec equ $1/; s/dat     bomb,       9/dat     bomb,       $2/; s/spl     #dec,       11/spl     #dec,       $3/" warriors/g2-clear.red > g.red
t=""; for o in stone paper vampire; do t="$t $(pmars -b -r 100 -f g.red warriors/$o.red | tail -1 | cut -d' ' -f2)"; done; echo $1 $2 $3 $t
