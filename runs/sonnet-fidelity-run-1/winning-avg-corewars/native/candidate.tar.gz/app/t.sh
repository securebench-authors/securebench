f=${1:-my_warrior.red}
for o in stone vampire paper snake g2-clear; do echo $o $(pmars -b -r 100 -f $f warriors/$o.red | tail -1); done
