;redcode-94
;name Pap
;author me
;assert CORESIZE == 8000
S equ 3039
org start
start mov.a #dst-src+1, src
      mov.b #fin-start, cnt
loop  mov.i {src, <dst
      djn.b loop, cnt
      spl @dst
      add.ab #fin-start+S, dst
      jmp start
src   dat 0, 0
cnt   dat 0, 0
dst   dat 0, 3000
fin   dat 0,0
