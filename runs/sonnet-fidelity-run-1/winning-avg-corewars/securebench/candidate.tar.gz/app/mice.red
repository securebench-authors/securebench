;redcode-94
;name Mice
;author me
;assert CORESIZE == 8000
        org hdr
hdr     spl 1
        spl 1
go      mov.ab  #8, cnt
        mov.a   #fin-src, src
cp      mov.i   {src, {dst
        djn.b   cp, cnt
        spl     @dst, 0
        add.b   #1000, dst
        jmp     go
src     dat     fin-src, 0
dst     dat     0, fin-dst+1000
cnt     dat     0, 0
fin     dat     0,0
