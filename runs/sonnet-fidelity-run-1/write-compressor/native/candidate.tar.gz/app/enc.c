#include <stdio.h>
#include <stdlib.h>
#include <string.h>
unsigned char data[10000];int n;
int cnt[1000000];
unsigned char dg[100000];int k=0;long rng=1;
void bit(int ctx,int b){
  if(rng<255){rng*=255;dg[k++]=0;}
  int*c=cnt+ctx*2;
  long split=rng*(c[0]+1)/(c[0]+c[1]+2);
  if(b){long a=split;for(int i=k-1;a&&i>=0;i--){a+=dg[i];dg[i]=a%255;a/=255;}rng-=split;}
  else rng=split;
  c[b]++;
}
void integer(int v,int t0,int ctx){
  int nn=v+(1<<t0),L=0;while(nn>>L)L++;int m=L-1-t0;
  ctx*=99;
  for(int i=0;i<=m;i++)bit(t0+1+i+ctx,i==m);
  for(int i=L-2;i>=0;i--)bit(ctx,(nn>>i)&1);
}
int main(){
  n=fread(data,1,9000,fopen("data.txt","rb"));n++;
  int T[10000][3],nt=0;
  for(int p=0;p<n;){
    int bl=0,bo=0;
    for(int o=1;o<=p;o++){int l=0;while(p+l<n&&data[p+l]==data[p+l-o]&&l<40)l++;if(l>bl){bl=l;bo=o;}}
    if(bl>=3){T[nt][0]=1;T[nt][1]=bo;T[nt][2]=bl;p+=bl;}else{T[nt][0]=0;T[nt][1]=data[p];p++;}
    nt++;
  }
  integer(nt,9,0);
  for(int i=0;i<nt;i++){
    if(T[i][0]){bit(1,1);integer(T[i][1]-1,5,2);integer(T[i][2]-1,2,3);}
    else{bit(1,0);bit(8,0);integer(T[i][1],4,9);}
  }
  FILE*f=fopen("data.comp","wb");
  for(int i=0;i<k;i++)fputc(dg[i]+1,f);
  fclose(f);printf("%d\n",k);
}
