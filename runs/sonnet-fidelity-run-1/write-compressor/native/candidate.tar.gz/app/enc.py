import sys
data=open('data.txt','rb').read()+b'\0'
cnt={}
low=0;rng=1;k=0
def bit(ctx,b):
    global low,rng,k
    if rng<255: rng*=255;low*=255;k+=1
    c=cnt.setdefault(ctx,[0,0])
    split=rng*(c[0]+1)//(c[0]+c[1]+2)
    if b: low+=split;rng-=split
    else: rng=split
    c[b]+=1
def integer(v,t0,ctx):
    n=v+(1<<t0);L=n.bit_length();m=L-1-t0;assert m>=0
    ctx*=99
    for i in range(m+1): bit(t0+1+i+ctx,1 if i==m else 0)
    for i in range(L-2,-1,-1): bit(ctx,(n>>i)&1)
def best(p):
    bl,bo=0,0
    for o in range(1,p+1):
        l=0
        while p+l<len(data) and data[p+l]==data[p+l-o] and l<40: l+=1
        if l>bl: bl,bo=l,o
    return bl,bo
toks=[];p=0
while p<len(data):
    l,o=best(p)
    if l>=3: toks.append((1,o,l));p+=l
    else: toks.append((0,data[p]));p+=1
integer(len(toks),9,0)
for t in toks:
    if t[0]:
        bit(1,1);integer(t[1]-1,5,2);integer(t[2]-1,2,3)
    else:
        bit(1,0);bit(8,0);integer(t[1],4,9)
out=bytearray()
d=[]
x=low
for _ in range(k): d.append(x%255);x//=255
assert x==0
open('data.comp','wb').write(bytes(v+1 for v in reversed(d)))
