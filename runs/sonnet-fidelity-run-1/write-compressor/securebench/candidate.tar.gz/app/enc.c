#include <stdio.h>
#include <stdlib.h>
#include <string.h>
typedef long long ll;
unsigned char data[10000]; int N;
int cc[1000000]; ll rng=1; unsigned char dig[100000]; int nd=0;
void add(ll v){ int i=nd-1; while(v&&i>=0){ ll t=dig[i]+v; dig[i]=t%255; v=t/255; i--; } if(v){fprintf(stderr,"overflow\n");exit(1);} }
void bit(int ctx,int b){
  if(rng<255){rng*=255; dig[nd++]=0;}
  int*c=cc+ctx*2; ll sp=rng*(c[0]+1)/(c[0]+c[1]+2);
  if(b){add(sp); rng-=sp;} else rng=sp;
  c[b]++;
}
void integer(int v,int t0,int ctx){
  ctx*=99; int x=v+(1<<t0); int Lb=0; while((x>>Lb)>1)Lb++; Lb++;
  int k=Lb-1-t0,t=t0;
  for(int i=0;i<k;i++){t++;bit(t+ctx,0);}
  t++;bit(t+ctx,1);t--;
  for(int i=t-1;i>=0;i--)bit(ctx,(x>>i)&1);
}
double cost(int v,int t0){int x=v+(1<<t0);int Lb=0;while((x>>Lb)>1)Lb++;Lb++;int k=Lb-1-t0;return 2*k+1+t0+k;}
typedef struct{int d,l;}T; T toks[10000]; int nt;
void parse(double lc,double mo){
  static double best[10001]; static T pv[10001];
  for(int i=1;i<=N;i++)best[i]=1e18; best[0]=0;
  for(int i=0;i<N;i++){
    double c=best[i];
    if(c+lc<best[i+1]){best[i+1]=c+lc;pv[i+1].d=0;pv[i+1].l=1;}
    for(int d=1;d<=i&&d<=4000;d++){
      int l=0; while(i+l<N&&data[i+l]==data[i+l-d]&&l<3000)l++;
      for(int ln=1;ln<=l;ln++){double cs=c+1+cost(d-1,5)*mo+cost(ln-1,2);
        if(cs<best[i+ln]){best[i+ln]=cs;pv[i+ln].d=d;pv[i+ln].l=ln;}}
    }
  }
  T tmp[10000];int n=0;
  for(int p=N;p>0;){T t=pv[p];tmp[n++]=t;p-=t.l;}
  nt=n; for(int i=0;i<n;i++)toks[i]=tmp[n-1-i];
}
int encode(){
  memset(cc,0,sizeof cc); rng=1; nd=0; memset(dig,0,sizeof dig);
  integer(nt,9,0); int p=0;
  for(int i=0;i<nt;i++){T t=toks[i];
    if(t.d){bit(1,1);integer(t.d-1,5,2);integer(t.l-1,2,3);p+=t.l;}
    else{bit(1,0);int v=data[p++];int sg=v>=128;int m=sg?256-v:v;bit(8,sg);integer(m,4,9);}
  }
  return nd;
}
int main(){
  FILE*f=fopen("data.txt","rb");N=fread(data,1,9000,f);fclose(f);data[N++]=0;
  int bestn=1<<30; unsigned char out[100000];
  for(double lc=4;lc<=9;lc+=1)for(double mo=0.5;mo<=1.01;mo+=0.25){
    parse(lc,mo);int n=encode();printf("%g %g %d\n",lc,mo,n);
    if(n<bestn){bestn=n;for(int i=0;i<n;i++)out[i]=dig[i]+1;}
  }
  f=fopen("data.comp","wb");fwrite(out,1,bestn,f);fclose(f);
}
