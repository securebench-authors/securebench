import math,sys
data=open('data.txt','rb').read()+b'\0'
N=len(data)
def L(v,t0):
    x=v+(1<<t0); Lb=x.bit_length(); return Lb-1-t0, x
class Enc:
    def __init__(s): s.cc={}; s.low=0; s.rng=1; s.n=0
    def bit(s,ctx,b):
        if s.rng<255: s.rng*=255; s.low*=255; s.n+=1
        c=s.cc.setdefault(ctx,[0,0])
        sp=s.rng*(c[0]+1)//(c[0]+c[1]+2)
        if b: s.low+=sp; s.rng-=sp
        else: s.rng=sp
        c[b]+=1
    def integer(s,v,t0,ctx):
        ctx*=99; k,x=L(v,t0)
        t=t0
        for i in range(k): t+=1; s.bit(t+ctx,0)
        t+=1; s.bit(t+ctx,1); t-=1
        for i in range(t-1,-1,-1): s.bit(ctx,(x>>i)&1)
def cost(v,t0): 
    k,x=L(v,t0); return 2*k+1+t0+k
def parse(lc,mo,ml):
    INF=1e18; best=[INF]*(N+1); best[0]=0; prev=[None]*(N+1)
    for i in range(N):
        c=best[i]
        if c+lc<best[i+1]: best[i+1]=c+lc; prev[i+1]=(0,)
        # find matches
        for d in range(1,min(i,32767)+1):
            l=0
            while i+l<N and data[i+l]==data[i+l-d] and l<2000: l+=1
            for ln in range(1,l+1):
                cc=c+1+mo*cost(d-1,5)+ml*cost(ln-1,2) if False else c+1+cost(d-1,5)*mo+cost(ln-1,2)*ml
                if cc<best[i+ln]: best[i+ln]=cc; prev[i+ln]=(1,d,ln)
    toks=[];p=N
    while p>0:
        t=prev[p]
        if t[0]==0: toks.append(('l',data[p-1])); p-=1
        else: toks.append(('m',t[1],t[2])); p-=t[2]
    return toks[::-1]
def encode(toks):
    e=Enc(); e.integer(len(toks),9,0)
    for t in toks:
        if t[0]=='m':
            e.bit(1,1); e.integer(t[1]-1,5,2); e.integer(t[2]-1,2,3)
        else:
            e.bit(1,0); v=t[1]; sg=1 if v>=128 else 0
            m=256-v if sg else v
            e.bit(8,sg); e.integer(m,4,9)
    v=e.low; out=[]
    for i in range(e.n): out.append(v%255+1); v//=255
    return bytes(out[::-1])
best=None
for lc in (5,6,7,8):
  for mo in (0.7,1.0):
    r=encode(parse(lc,mo,1.0))
    print(lc,mo,len(r),flush=True)
    if best is None or len(r)<len(best): best=r
open('data.comp','wb').write(best)
