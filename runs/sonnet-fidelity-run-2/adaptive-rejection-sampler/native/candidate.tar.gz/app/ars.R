# Adaptive Rejection Sampler (Gilks & Wild, 1992)
# Tangent-based upper hull + chord-based lower (squeeze) hull of h = log f.
# Derivatives of h are obtained numerically, so only the density is required.
#
# Main entry points:  ars(f, n, lo, hi, ...)   and   test()
# Style: plain functions, snake_case, "ars_" prefix for internal helpers.
# The hull is a list with elements x (abscissae), h (log density), d (slope of h).

## ---------------------------------------------------------------- validation
ars_check_inputs <- function(f, n, lo, hi, x_init, is_log) {
  if (!is.function(f)) stop("'f' must be a function (vectorized density).")
  if (!is.numeric(n) || length(n) != 1 || is.na(n) || n < 0 || n != floor(n))
    stop("'n' must be a single non-negative integer.")
  if (!is.numeric(lo) || !is.numeric(hi) || length(lo) != 1 || length(hi) != 1 ||
      is.na(lo) || is.na(hi))
    stop("'lo' and 'hi' must be single numbers (use -Inf/Inf for unbounded).")
  if (lo >= hi) stop("Invalid domain: 'lo' must be strictly less than 'hi'.")
  if (!is.logical(is_log) || length(is_log) != 1 || is.na(is_log))
    stop("'log' must be TRUE or FALSE.")
  if (!is.null(x_init)) {
    if (!is.numeric(x_init) || anyNA(x_init) || length(x_init) < 2)
      stop("'x_init' must be a numeric vector of at least 2 points.")
    if (any(x_init <= lo | x_init >= hi))
      stop("All 'x_init' points must lie strictly inside (lo, hi).")
    if (anyDuplicated(x_init)) stop("'x_init' points must be distinct.")
  }
  invisible(TRUE)
}

## ------------------------------------------------------- log density & slope
# Wrap user density so that it returns log-density, with checks.
ars_make_logf <- function(f, is_log) {
  function(x) {
    v <- f(x)
    if (!is.numeric(v) || length(v) != length(x))
      stop("'f' must be vectorized: return one numeric value per input.")
    if (anyNA(v) || any(v == Inf)) stop("Density returned NA/NaN or +Inf.")
    if (is_log) v else suppressWarnings(log(v))
  }
}

# Central-difference derivative of h, one-sided if close to a domain edge.
ars_slope <- function(h, x, lo, hi) {
  eps <- 1e-5 * (1 + abs(x))
  a <- max(x - eps, lo); b <- min(x + eps, hi)
  hv <- h(c(a, b))
  if (any(!is.finite(hv)))
    stop("Density is zero/non-finite next to abscissa x = ", x,
         "; cannot compute derivative.")
  (hv[2] - hv[1]) / (b - a)
}

# Build hull from abscissae.
ars_new_hull <- function(x, h, lo, hi) {
  x <- sort(x)
  hx <- h(x)
  if (any(!is.finite(hx))) stop("Density is not positive/finite at initial points.")
  d <- vapply(x, function(xi) ars_slope(h, xi, lo, hi), numeric(1))
  list(x = x, h = hx, d = d)
}

# Insert a new abscissa; returns updated hull.
ars_add_point <- function(hull, xn, hn, dn) {
  i <- findInterval(xn, hull$x)
  ins <- function(v, val) append(v, val, after = i)
  list(x = ins(hull$x, xn), h = ins(hull$h, hn), d = ins(hull$d, dn))
}

## ------------------------------------------------------------ log-concavity
# Slopes of h must be non-increasing in x.
ars_check_concave <- function(hull, tol = 1e-6) {
  dd <- diff(hull$d)
  if (any(dd > tol * (1 + abs(hull$d[-length(hull$d)]))))
    stop("Density is not log-concave: slope of log-density increases near x = ",
         signif(hull$x[which(dd > tol)[1]], 5), ".", call. = FALSE)
  invisible(TRUE)
}

## ------------------------------------------------------------- upper hull
# Intersections z_j of tangents at x_j and x_{j+1}.
ars_intersections <- function(hull) {
  k <- length(hull$x)
  j <- seq_len(k - 1)
  x0 <- hull$x[j]; x1 <- hull$x[j + 1]
  h0 <- hull$h[j]; h1 <- hull$h[j + 1]
  d0 <- hull$d[j]; d1 <- hull$d[j + 1]
  z <- (h1 - h0 - x1 * d1 + x0 * d0) / (d0 - d1)
  bad <- !is.finite(z) | abs(d0 - d1) < 1e-10
  z[bad] <- (x0[bad] + x1[bad]) / 2
  pmin(pmax(z, x0), x1)   # guard against rounding
}

# Segment table: segment j uses the tangent at x_j over [a_j, b_j].
ars_segments <- function(hull, lo, hi) {
  z <- ars_intersections(hull)
  a <- c(lo, z); b <- c(z, hi)
  seg <- data.frame(a = a, b = b, x = hull$x, h = hull$h, d = hull$d)
  if (is.infinite(lo) && hull$d[1] <= 0)
    stop("Density not integrable on the left: need positive slope at leftmost point.")
  if (is.infinite(hi) && hull$d[length(hull$d)] >= 0)
    stop("Density not integrable on the right: need negative slope at rightmost point.")
  seg$logmass <- ars_seg_logmass(seg$a, seg$b, seg$x, seg$h, seg$d)
  seg
}

# log of integral of exp(h + d (t - x)) over [a, b]  (vectorized, stable).
ars_seg_logmass <- function(a, b, x, h, d) {
  w <- b - a
  out <- numeric(length(a))
  flat <- abs(d) < 1e-10
  pos <- !flat & d > 0
  neg <- !flat & d < 0
  out[flat] <- (h + d * (a - x))[flat] + log(w[flat])
  out[neg]  <- (h + d * (a - x))[neg] + log(-expm1(d * w)[neg] / -d[neg])
  out[pos]  <- (h + d * (b - x))[pos] + log(-expm1(-d * w)[pos] / d[pos])
  out
}

# Upper hull value (log scale) at point(s) t.
ars_upper <- function(seg, t) {
  j <- pmin(findInterval(t, c(seg$a[1], seg$b)), nrow(seg))
  j <- pmax(j, 1)
  seg$h[j] + seg$d[j] * (t - seg$x[j])
}

# Lower hull (chords) at t; -Inf outside [x_1, x_k].
ars_lower <- function(hull, t) {
  k <- length(hull$x)
  if (t < hull$x[1] || t > hull$x[k]) return(-Inf)
  j <- min(findInterval(t, hull$x), k - 1)
  s <- (hull$h[j + 1] - hull$h[j]) / (hull$x[j + 1] - hull$x[j])
  hull$h[j] + s * (t - hull$x[j])
}

# Draw one value from the normalized exponentiated upper hull.
ars_sample_upper <- function(seg) {
  lm <- seg$logmass
  p <- exp(lm - max(lm))
  j <- sample.int(nrow(seg), 1, prob = p)
  a <- seg$a[j]; b <- seg$b[j]; d <- seg$d[j]; w <- b - a
  u <- runif(1)
  t <- if (abs(d) < 1e-10) a + u * w
       else if (d < 0) a + log1p(u * expm1(d * w)) / d
       else b + log(u + (1 - u) * exp(-d * w)) / d
  min(max(t, a), b)
}

## ------------------------------------------------------- initial abscissae
ars_init_points <- function(h, lo, hi) {
  fin_lo <- is.finite(lo); fin_hi <- is.finite(hi)
  if (fin_lo && fin_hi) {
    x <- lo + (hi - lo) * c(0.1, 0.5, 0.9)
  } else if (fin_lo) {
    x <- lo + c(0.5, 1, 2)
  } else if (fin_hi) {
    x <- hi - c(2, 1, 0.5)
  } else x <- c(-1, 0, 1)
  # Move to where the density is positive, if necessary.
  ok <- is.finite(h(x))
  if (!all(ok)) {
    cand <- if (fin_lo && fin_hi) lo + (hi - lo) * seq(0.01, 0.99, length.out = 99)
            else seq(max(lo, -100), min(hi, 100), length.out = 401)
    cand <- cand[is.finite(h(cand))]
    if (length(cand) < 2) stop("Could not find initial points with positive density; supply 'x_init'.")
    x <- unique(cand[round(seq(1, length(cand), length.out = 3))])
  }
  x
}

# For unbounded domains make sure the end slopes point inward.
ars_expand_ends <- function(h, x, lo, hi, max_iter = 60) {
  x <- sort(x)
  if (is.infinite(lo)) {
    it <- 0
    while (ars_slope(h, x[1], lo, hi) <= 0) {
      if ((it <- it + 1) > max_iter) stop("Could not find left point with positive slope; supply 'x_init'.")
      step <- max(1, abs(x[1])) 
      x <- c(x[1] - step, x)
      if (!is.finite(h(x[1]))) stop("Density vanishes on the left before slope turns positive; supply 'x_init'.")
    }
  }
  if (is.infinite(hi)) {
    it <- 0
    k <- length(x)
    while (ars_slope(h, x[k], lo, hi) >= 0) {
      if ((it <- it + 1) > max_iter) stop("Could not find right point with negative slope; supply 'x_init'.")
      step <- max(1, abs(x[k]))
      x <- c(x, x[k] + step); k <- length(x)
      if (!is.finite(h(x[k]))) stop("Density vanishes on the right before slope turns negative; supply 'x_init'.")
    }
  }
  x
}

## ------------------------------------------------------------- main sampler
#' Adaptive rejection sampler.
#' @param f density (possibly unnormalized), vectorized; or log-density if log=TRUE
#' @param n number of samples
#' @param lo,hi domain bounds (may be infinite)
#' @param x_init optional initial abscissae strictly inside (lo, hi)
#' @param log TRUE if f returns the log density
#' @param max_iter safeguard on total proposals
#' @return numeric vector of n draws
ars <- function(f, n, lo = -Inf, hi = Inf, x_init = NULL, log = FALSE,
                max_iter = 100 * n + 1000) {
  ars_check_inputs(f, n, lo, hi, x_init, log)
  if (n == 0) return(numeric(0))
  h <- ars_make_logf(f, log)
  x0 <- if (is.null(x_init)) ars_init_points(h, lo, hi) else x_init
  x0 <- ars_expand_ends(h, x0, lo, hi)
  hull <- ars_new_hull(x0, h, lo, hi)
  ars_check_concave(hull)
  seg <- ars_segments(hull, lo, hi)

  out <- numeric(n); got <- 0; iter <- 0
  while (got < n) {
    if ((iter <- iter + 1) > max_iter)
      stop("Exceeded maximum iterations without enough samples.")
    t <- ars_sample_upper(seg)
    lu <- log(runif(1))
    up <- ars_upper(seg, t)
    if (lu <= ars_lower(hull, t) - up) {            # squeeze test: accept
      got <- got + 1; out[got] <- t; next
    }
    ht <- h(t)                                       # evaluation test
    if (is.finite(ht) && ht > up + 1e-6 * (1 + abs(up)))
      stop("Density is not log-concave: log-density exceeds upper hull at x = ",
           signif(t, 5), ".", call. = FALSE)
    if (is.finite(ht) && lu <= ht - up) { got <- got + 1; out[got] <- t }
    if (is.finite(ht) && t > lo && t < hi && !(t %in% hull$x)) {   # update hull
      hull <- ars_add_point(hull, t, ht, ars_slope(h, t, lo, hi))
      ars_check_concave(hull)
      seg <- ars_segments(hull, lo, hi)
    } else if (!is.finite(ht)) {
      stop("Density is zero at a proposed point inside the domain; density must be positive (log-concave) on (lo, hi).")
    }
  }
  out
}

## ------------------------------------------------------------------ tests
test <- function(seed = 42, n = 5000) {
  set.seed(seed)
  results <- c()
  report <- function(name, pass, detail = "") {
    cat(sprintf("%s: %s %s\n", name, if (pass) "PASS" else "FAIL", detail))
    results[name] <<- pass
  }
  # Compare sample to known distribution: KS test + mean/sd within tolerance.
  dist_test <- function(name, x, cdf, mu, sdev) {
    m <- mean(x); s <- sd(x)
    ks <- suppressWarnings(ks.test(x, cdf)$p.value)
    ok <- ks > 0.01 && abs(m - mu) < 4 * sdev / sqrt(length(x)) + 1e-3 &&
          abs(s - sdev) < 0.05 * sdev + 1e-3
    report(name, ok, sprintf("(mean=%.4f [true %.4f], sd=%.4f [true %.4f], KS p=%.3f)",
                             m, mu, s, sdev, ks))
  }
  expect_error <- function(name, expr, pattern) {
    msg <- tryCatch({ force(expr); NA_character_}, error = function(e) conditionMessage(e))
    report(name, !is.na(msg) && grepl(pattern, msg, ignore.case = TRUE),
           if (is.na(msg)) "(no error raised)" else paste0("(error: ", msg, ")"))
  }

  cat("=== Unit tests of helper modules ===\n")
  # Hull for standard normal at x=-1,0,1: tangent intersections known analytically.
  h <- function(x) dnorm(x, log = TRUE)
  hull <- ars_new_hull(c(-1, 0, 1), h, -Inf, Inf)
  report("UNIT_slope", max(abs(hull$d - c(1, 0, -1))) < 1e-5,
         sprintf("(slopes=%s)", paste(round(hull$d, 4), collapse = ",")))
  z <- ars_intersections(hull)
  report("UNIT_intersections", max(abs(z - c(-0.5, 0.5))) < 1e-4,
         sprintf("(z=%s, expected -0.5,0.5)", paste(round(z, 4), collapse = ",")))
  seg <- ars_segments(hull, -Inf, Inf)
  tt <- c(-3, -0.7, 0.2, 2)
  report("UNIT_upper_ge_h", all(ars_upper(seg, tt) >= h(tt) - 1e-8))
  report("UNIT_lower_le_h", all(vapply(c(-0.9, 0.3, 0.8), function(t) ars_lower(hull, t) <= h(t), TRUE)) &&
         ars_lower(hull, 3) == -Inf)
  # Total mass of the upper hull must be >= true mass sqrt(2 pi)
  mass <- sum(exp(seg$logmass))
  report("UNIT_hull_mass", mass >= 1 && mass < 1.5,
         sprintf("(hull mass=%.4f, true density mass=1)", mass))
  # Sampling from the hull alone: its shape should match the normalized hull cdf
  smp <- replicate(3000, ars_sample_upper(seg))
  # the 3-point hull is heavier-tailed than N(0,1) (sd ~1.5); mean 0 by symmetry
  report("UNIT_sample_upper", abs(mean(smp)) < 0.15 && sd(smp) > 1.2 && sd(smp) < 1.8,
         sprintf("(mean=%.3f, sd=%.3f)", mean(smp), sd(smp)))
  # Segment mass vs numerical integration of a single tangent piece
  num <- integrate(function(t) exp(seg$h[2] + seg$d[2] * (t - seg$x[2])), seg$a[2], seg$b[2])$value
  report("UNIT_segment_mass", abs(exp(seg$logmass[2]) - num) < 1e-6)
  expect_error("UNIT_concavity_check", ars_check_concave(list(x = 1:3, d = c(-1, 0.5, -1))), "log-concave")

  cat("\n=== Input validation ===\n")
  expect_error("INPUT_negative_n", ars(dnorm, -5), "non-negative")
  expect_error("INPUT_noninteger_n", ars(dnorm, 2.5), "integer")
  expect_error("INPUT_bad_domain", ars(dnorm, 10, lo = 3, hi = -3), "domain")
  expect_error("INPUT_not_function", ars("dnorm", 10), "function")
  expect_error("INPUT_bad_init", ars(dnorm, 10, lo = 0, hi = 1, x_init = c(-1, 0.5)), "inside")
  expect_error("INPUT_bad_log", ars(dnorm, 10, log = NA), "TRUE or FALSE")
  report("INPUT_zero_n", length(ars(dnorm, 0)) == 0)

  cat("\n=== Non-log-concave detection ===\n")
  bimodal <- function(x) dnorm(x, -4) + dnorm(x, 4)
  expect_error("NONCONCAVE_bimodal", ars(bimodal, 1000, x_init = c(-5, -2, 2, 5)), "log-concave")
  expect_error("NONCONCAVE_t_density", ars(function(x) dt(x, 1) , 1000, x_init = c(-3, -0.5, 0.5, 3)), "log-concave|integrable")
  # Hidden non-concavity found during sampling (initial slopes look concave)
  expect_error("NONCONCAVE_found_during_sampling",
               ars(bimodal, 2000, x_init = c(-8, 0, 8)), "log-concave")

  cat("\n=== Sampling from known distributions ===\n")
  x <- ars(dnorm, n)
  dist_test("NORMAL", x, pnorm, 0, 1)
  writeLines(format(x, digits = 10), "/app/normal_samples.txt")
  x <- ars(dnorm, n, lo = -Inf, hi = Inf, x_init = c(-0.3, 0.2))
  dist_test("NORMAL_custom_init", x, pnorm, 0, 1)
  x <- ars(function(t) dnorm(t, 5, 2), n)
  dist_test("NORMAL_mu5_sd2", x, function(q) pnorm(q, 5, 2), 5, 2)
  x <- ars(function(t) exp(-t^2 / 2), n)   # unnormalized
  dist_test("NORMAL_unnormalized", x, pnorm, 0, 1)
  x <- ars(function(t) -t^2 / 2, n, log = TRUE)
  dist_test("NORMAL_log_density", x, pnorm, 0, 1)
  x <- ars(dexp, n, lo = 0)
  dist_test("EXPONENTIAL", x, pexp, 1, 1)
  writeLines(format(x, digits = 10), "/app/exponential_samples.txt")
  x <- ars(function(t) dgamma(t, 3, 2), n, lo = 0)
  dist_test("GAMMA_3_2", x, function(q) pgamma(q, 3, 2), 1.5, sqrt(3) / 2)
  x <- ars(function(t) dbeta(t, 2, 3), n, lo = 0, hi = 1)
  dist_test("BETA_2_3", x, function(q) pbeta(q, 2, 3), 0.4, sqrt(0.04))
  x <- ars(dnorm, n, lo = 0, hi = 1)
  tm <- integrate(function(t) t * dnorm(t), 0, 1)$value / (pnorm(1) - 0.5)
  tv <- integrate(function(t) t^2 * dnorm(t), 0, 1)$value / (pnorm(1) - 0.5) - tm^2
  dist_test("TRUNCATED_NORMAL_0_1", x, function(q) (pnorm(q) - 0.5) / (pnorm(1) - 0.5), tm, sqrt(tv))
  x <- ars(function(t) exp(-abs(t)), n)   # Laplace (log-concave, non-smooth)
  dist_test("LAPLACE", x, function(q) ifelse(q < 0, 0.5 * exp(q), 1 - 0.5 * exp(-q)), 0, sqrt(2))
  x <- ars(dlogis, n)
  dist_test("LOGISTIC", x, plogis, 0, pi / sqrt(3))
  x <- ars(function(t) dunif(t, 0, 1), n, lo = 0, hi = 1)
  dist_test("UNIFORM_flat_log_density", x, punif, 0.5, sqrt(1 / 12))

  cat("\n=== Summary ===\n")
  cat(sprintf("%d of %d tests passed\n", sum(results), length(results)))
  invisible(results)
}

if (sys.nframe() == 0 && !interactive()) invisible(test())
