# Adaptive rejection sampler (Gilks & Wild, 1992), tangent-based version.
# Derivatives of log f are obtained numerically, so only f is required.
#
# Hull object ("hull"): list(x, h, dh, z, lb, ub)
#   x sorted abscissae, h = log f(x), dh = h'(x), z = k+1 knots of the
#   upper hull (z[1] = lb, z[k+1] = ub, interior knots = tangent intersections).

# ---- input validation ------------------------------------------------------
ars_check_inputs <- function(f, n, lb, ub, x_init) {
  if (!is.function(f)) stop("'f' must be a function (vectorized density).")
  if (!is.numeric(n) || length(n) != 1 || is.na(n) || n < 0 || n != floor(n))
    stop("'n' must be a single non-negative integer.")
  if (!is.numeric(lb) || !is.numeric(ub) || length(lb) != 1 || length(ub) != 1 ||
      is.na(lb) || is.na(ub))
    stop("'lb' and 'ub' must be single numeric values (may be infinite).")
  if (lb >= ub) stop("Invalid domain: need lb < ub.")
  if (!is.null(x_init)) {
    if (!is.numeric(x_init) || any(!is.finite(x_init)) || length(unique(x_init)) < 2)
      stop("'x_init' must contain at least two distinct finite numbers.")
    if (any(x_init <= lb | x_init >= ub))
      stop("'x_init' must lie strictly inside (lb, ub).")
  }
  invisible(TRUE)
}

# ---- log density and derivative -------------------------------------------
make_logf <- function(f) {
  function(x) {
    v <- f(x)
    if (length(v) != length(x) || !is.numeric(v) || anyNA(v) || any(v < 0))
      stop("Density 'f' must return non-negative, non-NA values, one per input.")
    suppressWarnings(log(v))
  }
}

# Central difference, switching to one-sided if too close to a finite bound.
num_deriv <- function(logf, x, lb, ub) {
  eps <- 1e-5 * pmax(1, abs(x))
  lo <- pmax(x - eps, lb); hi <- pmin(x + eps, ub)
  (logf(hi) - logf(lo)) / (hi - lo)
}

# ---- upper hull -------------------------------------------------------------
# Check slopes are non-increasing (log-concavity) and build knots.
build_hull <- function(x, h, dh, lb, ub, tol = 1e-6) {
  o <- order(x); x <- x[o]; h <- h[o]; dh <- dh[o]
  k <- length(x)
  if (k > 1 && any(diff(dh) > tol * pmax(1, abs(dh[-k]))))
    stop("Density is not log-concave: slope of log f increases between ",
         "x = ", signif(x[which(diff(dh) > tol * pmax(1, abs(dh[-k])))[1]], 5),
         " and the next abscissa.")
  if (k > 1) {  # each tangent must lie above neighbouring points of log f
    j <- 1:(k - 1)
    bad <- h[j + 1] > h[j] + dh[j] * (x[j + 1] - x[j]) + tol * pmax(1, abs(h[j + 1])) |
           h[j] > h[j + 1] + dh[j + 1] * (x[j] - x[j + 1]) + tol * pmax(1, abs(h[j]))
    if (any(bad))
      stop("Density is not log-concave: tangent at x = ", signif(x[which(bad)[1]], 5),
           " lies below log f at a neighbouring point.")
  }
  z <- numeric(k + 1); z[1] <- lb; z[k + 1] <- ub
  if (k > 1) {
    j <- 1:(k - 1)
    same <- abs(dh[j + 1] - dh[j]) < 1e-12
    zz <- (h[j + 1] - h[j] - x[j + 1] * dh[j + 1] + x[j] * dh[j]) / (dh[j] - dh[j + 1])
    zz[same] <- (x[j][same] + x[j + 1][same]) / 2
    # keep knots between neighbouring abscissae despite round-off
    z[j + 1] <- pmin(pmax(zz, x[j]), x[j + 1])
  }
  list(x = x, h = h, dh = dh, z = z, lb = lb, ub = ub)
}

# Upper hull value at points xs (vector).
upper_eval <- function(hull, xs) {
  j <- findInterval(xs, hull$z[-1], left.open = TRUE) + 1
  j <- pmin(j, length(hull$x))
  hull$h[j] + hull$dh[j] * (xs - hull$x[j])
}

# Lower hull (chords); -Inf outside [min x, max x].
lower_eval <- function(hull, xs) {
  x <- hull$x; h <- hull$h
  out <- rep(-Inf, length(xs))
  ins <- xs >= x[1] & xs <= x[length(x)]
  if (any(ins)) out[ins] <- approx(x, h, xout = xs[ins])$y
  out
}

# ---- sampling from the upper hull ----------------------------------------
# Log of the mass of each exponential piece exp(h_j + d_j (x - x_j)) on [a, b].
segment_logmass <- function(hull) {
  k <- length(hull$x); a <- hull$z[1:k]; b <- hull$z[2:(k + 1)]
  d <- hull$dh; w <- b - a
  lm <- numeric(k)
  flat <- abs(d) < 1e-10
  pos <- !flat & d > 0; neg <- !flat & d < 0
  lm[flat] <- hull$h[flat] + log(w[flat])
  hb <- hull$h + d * (b - hull$x)
  ha <- hull$h + d * (a - hull$x)
  lm[pos] <- hb[pos] + log(-expm1(-d[pos] * w[pos])) - log(d[pos])
  lm[neg] <- ha[neg] + log(-expm1(d[neg] * w[neg])) - log(-d[neg])
  lm
}

# Draw one point from the normalized upper hull.
sample_upper <- function(hull) {
  lm <- segment_logmass(hull)
  p <- exp(lm - max(lm)); j <- sample.int(length(p), 1, prob = p)
  a <- hull$z[j]; b <- hull$z[j + 1]; d <- hull$dh[j]; u <- runif(1)
  if (abs(d) < 1e-10) return(a + u * (b - a))
  if (d > 0) {
    e <- exp(d * (a - b))
    x <- b + log(e + u * (1 - e)) / d
  } else {
    e <- exp(d * (b - a))
    x <- a + log(1 - u * (1 - e)) / d
  }
  min(max(x, a), b)
}

# ---- initialisation ----------------------------------------------------------
default_init <- function(lb, ub) {
  if (is.finite(lb) && is.finite(ub)) lb + c(0.25, 0.5, 0.75) * (ub - lb)
  else if (is.finite(lb)) lb + c(0.5, 1, 2)
  else if (is.finite(ub)) ub - c(2, 1, 0.5)
  else c(-1, 0, 1)
}

# Choose starting abscissae; for unbounded sides ensure slope has correct sign.
init_hull <- function(logf, lb, ub, x_init, max_expand = 60) {
  user <- !is.null(x_init)
  x <- if (user) sort(unique(x_init)) else default_init(lb, ub)
  h <- logf(x); ok <- is.finite(h)
  if (sum(ok) < 2) stop("Density is zero/non-finite at the starting points; supply 'x_init'.")
  x <- x[ok]; h <- h[ok]
  dh <- num_deriv(logf, x, lb, ub)
  step <- max(1, diff(range(x)))
  add <- function(xn) {
    hn <- logf(xn)
    if (!is.finite(hn)) stop("Cannot find starting points with positive density.")
    x <<- c(x, xn); h <<- c(h, hn); dh <<- c(dh, num_deriv(logf, xn, lb, ub))
    o <- order(x); x <<- x[o]; h <<- h[o]; dh <<- dh[o]
  }
  if (is.infinite(lb)) {
    i <- 0
    while (dh[1] <= 0) {
      if ((i <- i + 1) > max_expand) stop("Density appears not integrable on the left (h' <= 0 as x -> -Inf).")
      step <- step * 2; add(x[1] - step)
    }
  }
  step <- max(1, diff(range(x)))
  if (is.infinite(ub)) {
    i <- 0
    while (dh[length(dh)] >= 0) {
      if ((i <- i + 1) > max_expand) stop("Density appears not integrable on the right (h' >= 0 as x -> Inf).")
      step <- step * 2; add(x[length(x)] + step)
    }
  }
  build_hull(x, h, dh, lb, ub)
}

# Insert a new abscissa into the hull (rebuilds knots).
update_hull <- function(hull, xn, hn, logf) {
  dn <- num_deriv(logf, xn, hull$lb, hull$ub)
  build_hull(c(hull$x, xn), c(hull$h, hn), c(hull$dh, dn), hull$lb, hull$ub)
}

# ---- main function -----------------------------------------------------------
# f: vectorized (possibly unnormalized) density; n: number of samples;
# lb, ub: support; x_init: optional starting points.
ars <- function(f, n, lb = -Inf, ub = Inf, x_init = NULL, max_iter = 1e6) {
  ars_check_inputs(f, n, lb, ub, x_init)
  if (n == 0) return(numeric(0))
  logf <- make_logf(f)
  hull <- init_hull(logf, lb, ub, x_init)
  tol <- 1e-6
  out <- numeric(n); got <- 0; iter <- 0
  while (got < n) {
    if ((iter <- iter + 1) > max_iter) stop("Exceeded max_iter without producing enough samples.")
    x <- sample_upper(hull)
    u <- runif(1)
    lo <- lower_eval(hull, x); up <- upper_eval(hull, x)
    if (is.finite(lo) && log(u) <= lo - up) {      # squeeze test: accept, no f evaluation
      got <- got + 1; out[got] <- x; next
    }
    hx <- logf(x)
    if (is.finite(hx) && hx > up + tol * max(1, abs(up)))
      stop("Density is not log-concave: log f exceeds the upper hull at x = ", signif(x, 5))
    if (is.finite(lo) && hx < lo - tol * max(1, abs(lo)))
      stop("Density is not log-concave: log f falls below the lower hull at x = ", signif(x, 5))
    if (log(u) <= hx - up) { got <- got + 1; out[got] <- x }
    if (is.finite(hx)) hull <- update_hull(hull, x, hx, logf)
  }
  out
}

# ---- tests ---------------------------------------------------------------------
report <- function(name, pass, detail = "") {
  cat(sprintf("%s: %s %s\n", name, if (pass) "PASS" else "FAIL", detail))
  invisible(pass)
}

# Compare samples with a known CDF (KS test) and known mean/sd.
check_dist <- function(name, x, cdf, mu, sigma, tol_z = 4) {
  n <- length(x); m <- mean(x); s <- sd(x)
  ks <- suppressWarnings(ks.test(x, cdf))$p.value
  zm <- abs(m - mu) / (sigma / sqrt(n))
  pass <- ks > 0.001 && zm < tol_z && abs(s / sigma - 1) < 0.1
  report(name, pass, sprintf("mean=%.4f (true %.4f), sd=%.4f (true %.4f), KS p=%.3f", m, mu, s, sigma, ks))
}

expect_error <- function(name, expr, pattern) {
  msg <- tryCatch({ force(expr); NA_character_ }, error = function(e) conditionMessage(e))
  report(name, !is.na(msg) && grepl(pattern, msg, ignore.case = TRUE),
         if (is.na(msg)) "(no error raised)" else paste0("-> ", msg))
}

test <- function(n = 5000, seed = 42) {
  ee <- function(...) res <<- c(res, expect_error(...))
  set.seed(seed); res <- logical(0)
  cat("=== Adaptive rejection sampler tests ===\n")
  cat("--- Unit tests: components ---\n")
  # hull: upper >= log f >= lower for a normal
  lf <- function(x) dnorm(x, log = TRUE)
  xs <- c(-2, -0.5, 1, 2.5); hl <- build_hull(xs, lf(xs), -xs, -Inf, Inf)
  g <- seq(-6, 6, length.out = 400)
  res <- c(res, report("HULL_BOUNDS",
    all(upper_eval(hl, g) >= lf(g) - 1e-9) &&
    all(lower_eval(hl, g)[g >= -2 & g <= 2.5] <= lf(g)[g >= -2 & g <= 2.5] + 1e-9)))
  # numeric derivative
  res <- c(res, report("NUM_DERIV", max(abs(num_deriv(lf, g, -Inf, Inf) + g)) < 1e-6))
  # upper hull sampler: exact envelope mass check via draws from the envelope
  e <- replicate(20000, sample_upper(hl))
  masses <- exp(segment_logmass(hl)); masses <- masses / sum(masses)
  emp <- tabulate(findInterval(e, hl$z[-c(1, length(hl$z))]) + 1, length(masses)) / length(e)
  res <- c(res, report("ENVELOPE_SAMPLER", max(abs(emp - masses)) < 0.02,
                       sprintf("max segment prob error=%.4f", max(abs(emp - masses)))))
  cat("--- Distribution tests ---\n")
  x <- ars(dnorm, n); res <- c(res, check_dist("NORMAL", x, pnorm, 0, 1))
  writeLines(format(x, digits = 10), "/app/normal_samples.txt")
  x <- ars(dexp, n, lb = 0); res <- c(res, check_dist("EXPONENTIAL", x, pexp, 1, 1))
  writeLines(format(x, digits = 10), "/app/exponential_samples.txt")
  x <- ars(function(x) dnorm(x, 3, 2) * 17, n)  # unnormalized, shifted
  res <- c(res, check_dist("UNNORMALIZED_NORMAL", x, function(q) pnorm(q, 3, 2), 3, 2))
  x <- ars(function(x) dgamma(x, 3, 2), n, lb = 0)
  res <- c(res, check_dist("GAMMA(3,2)", x, function(q) pgamma(q, 3, 2), 1.5, sqrt(3) / 2))
  x <- ars(function(x) dbeta(x, 2, 3), n, lb = 0, ub = 1)
  res <- c(res, check_dist("BETA(2,3)", x, function(q) pbeta(q, 2, 3), 0.4, sqrt(0.04)))
  x <- ars(dnorm, n, lb = 0, ub = 1.5)
  tm <- (dnorm(0) - dnorm(1.5)) / (pnorm(1.5) - 0.5)
  tv <- 1 + (0 - 1.5 * dnorm(1.5)) / (pnorm(1.5) - 0.5) - tm^2
  res <- c(res, check_dist("TRUNCATED_NORMAL", x, function(q) (pnorm(q) - 0.5) / (pnorm(1.5) - 0.5), tm, sqrt(tv)))
  x <- ars(function(x) dlogis(x), n)
  res <- c(res, check_dist("LOGISTIC", x, plogis, 0, pi / sqrt(3)))
  cat("--- Error handling tests ---\n")
  ee("ERR_NEGATIVE_N", ars(dnorm, -5), "non-negative")
  ee("ERR_NONINTEGER_N", ars(dnorm, 2.5), "integer")
  ee("ERR_BAD_DOMAIN", ars(dnorm, 10, lb = 2, ub = 1), "domain")
  ee("ERR_NOT_FUNCTION", ars("dnorm", 10), "function")
  ee("ERR_BAD_XINIT", ars(dnorm, 10, x_init = c(0, 0)), "x_init")
  ee("ERR_NEGATIVE_DENSITY", ars(function(x) -dnorm(x), 10), "non-negative")
  ee("ERR_NOT_LOGCONCAVE_BIMODAL",
               ars(function(x) dnorm(x, -4) + dnorm(x, 4), 1000, x_init = c(-6, -2, 2, 6)), "log-concave")
  ee("ERR_NOT_LOGCONCAVE_CAUCHY", ars(dcauchy, 1000), "log-concave|integrable")
  ee("ERR_NOT_LOGCONCAVE_UNIFORMMIX",
               ars(function(x) dunif(x, 0, 1) + 5 * dunif(x, 2, 3), 1000, lb = 0, ub = 3,
                   x_init = c(0.5, 1, 2.5)), "log-concave|positive density")
  cat(sprintf("=== Tests passed: %d of %d ===\n", sum(res), length(res)))
  invisible(res)
}

if (sys.nframe() == 0 && !interactive() && any(grepl("--test", commandArgs()))) test()
