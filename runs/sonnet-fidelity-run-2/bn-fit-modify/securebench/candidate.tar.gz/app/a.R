d=read.csv("bn_sample_10k.csv");set.seed(1);n=10000
write.csv(data.frame(to=c("Y","R","D","M","D","M"),from=c("U","U","U","U","Y","R")),"learned_dag.csv",row.names=FALSE,quote=FALSE)
write.csv(data.frame(to=c("R","D","M","D","M"),from=c("U","U","U","Y","R")),"intervened_dag.csv",row.names=FALSE,quote=FALSE)
f=function(fm){m=lm(fm,d);list(m,summary(m)$sigma)}
s=function(r,X)as.numeric(cbind(1,X)%*%coef(r[[1]]))+rnorm(n,0,r[[2]])
U=rnorm(n,mean(d$U),sd(d$U));Y=rep(0,n)
R=s(f(R~U),U);D=s(f(D~U+Y),cbind(U,Y));M=s(f(M~U+R),cbind(U,R))
write.csv(data.frame(U,Y,R,D,M),"final_bn_sample.csv",row.names=FALSE)
