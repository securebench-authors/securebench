import asyncio
from typing import Awaitable, Callable


async def run_tasks(
    tasks: list[Callable[[], Awaitable[None]]], max_concurrent: int
) -> None:
    """Run task callables with at most `max_concurrent` running at once.

    If run_tasks is cancelled (e.g. Ctrl+C under asyncio.run) or a task raises,
    all running tasks are cancelled and awaited so their cleanup code finishes
    before the exception propagates. Pending tasks are never started.
    """
    if max_concurrent < 1:
        raise ValueError("max_concurrent must be >= 1")

    pending = iter(tasks)

    async def worker() -> None:
        for task in pending:  # shared iterator: each task is taken exactly once
            await task()

    workers = [
        asyncio.ensure_future(worker()) for _ in range(min(max_concurrent, len(tasks)))
    ]
    try:
        await asyncio.gather(*workers)
    except BaseException:
        for w in workers:
            w.cancel()
        # Wait for cleanup in the cancelled tasks; if we're cancelled again
        # (e.g. a second Ctrl+C), keep waiting so cleanup still completes.
        while True:
            try:
                await asyncio.gather(*workers, return_exceptions=True)
                break
            except asyncio.CancelledError:
                continue
        raise
