import asyncio
from typing import Awaitable, Callable


async def run_tasks(
    tasks: list[Callable[[], Awaitable[None]]], max_concurrent: int
) -> None:
    """Run tasks with at most `max_concurrent` running at once.

    If a task raises, the remaining running tasks are cancelled and the first
    exception is re-raised. If run_tasks itself is cancelled (e.g. by Ctrl-C
    under asyncio.run), running tasks are cancelled and awaited, so their
    cleanup code finishes before the cancellation propagates.
    """
    if max_concurrent < 1:
        raise ValueError("max_concurrent must be >= 1")

    pending = iter(tasks)

    async def worker() -> None:
        for task in pending:
            await task()

    workers = [
        asyncio.ensure_future(worker()) for _ in range(min(max_concurrent, len(tasks)))
    ]
    try:
        # Wait for all workers, but stop at the first failure.
        done, _ = await asyncio.wait(workers, return_when=asyncio.FIRST_EXCEPTION)
        for w in done:
            if w.exception() is not None:
                raise w.exception()
    finally:
        for w in workers:
            w.cancel()
        # Wait for cleanup in the tasks to finish, even if cancelled again.
        while True:
            try:
                await asyncio.gather(*workers, return_exceptions=True)
                break
            except asyncio.CancelledError:
                continue
