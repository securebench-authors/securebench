G=[]  # body gate strings with tokens
def emit(f):
    G.append(f); return ('B',len(G)-1)
def op(o,a,b=None):
    return emit(('o',o,a,b))
def NOT(a): return op('~',a)
def AND(a,b): return op('&',a,b)
def OR(a,b): return op('|',a,b)
def XOR(a,b): return op('^',a,b)
Z=emit(('c','0'))
def add(x,y,cin,n):
    out=[];c=cin
    for i in range(n):
        xi=x[i];yi=y[i] if i<len(y) else Z
        t=XOR(xi,yi);out.append(XOR(t,c));c=OR(AND(xi,yi),AND(c,t))
    return out
NR=16+33+32+32
def R(k): return ('R',k)
inp=[('I',i) for i in range(32)]
def it(a,b,s,q):
    nq=[NOT(x) for x in q[:32]]
    c=emit(('c','1'))
    for i in range(32):
        t=XOR(inp[i],nq[i]);c=OR(AND(inp[i],nq[i]),AND(c,t))
    # bit 32: N=0, ~q32 ; carry stays only if ~q32 and c
    cond=AND(c,NOT(q[32]))
    one=emit(('c','1'))
    s1=add(s,[],one,16)
    q1=add(q,[one]+s1,Z,33)
    b1=add(a,b,Z,32)
    def mux(old,new):
        return [XOR(o,AND(cond,XOR(o,n))) for o,n in zip(old,new)]
    return mux(a,b),mux(b,b1),mux(s,s1),mux(q,q1)
a=[R(i) for i in range(32)]
b=[R(32+i) for i in range(32)];b[0]=NOT(b[0])
s=[R(64+i) for i in range(16)]
q=[R(80+i) for i in range(33)];q[0]=NOT(q[0])
import sys
K=int(sys.argv[1])
for _ in range(K): a,b,s,q=it(a,b,s,q)
b[0]=NOT(b[0]);q[0]=NOT(q[0])
nxt=a+b+s+q
base=32+len(G)
def name(t):
    if t[0]=='B':return 32+t[1]
    if t[0]=='R':return base+t[1]
    return t[1]
L=[f"out{i} = out{i}" for i in range(32)]
for g in G:
    if g[0]=='c':L.append(f"out{len(L)} = {g[1]}")
    elif g[3] is None:L.append(f"out{len(L)} = ~out{name(g[2])}")
    else:L.append(f"out{len(L)} = out{name(g[2])} {g[1]} out{name(g[3])}")
for t in nxt:L.append(f"out{len(L)} = out{name(t)}")
for i in range(32):L.append(f"out{len(L)} = out{base+i}")
open('gates.txt','w').write("\n".join(L)+"\n")
print(len(L))
