import os
os.chdir('/app')
raw = open('src/INPUT.DAT', 'rb').read()[:22]
if not raw:
    print("Error: Input file is empty")
    raise SystemExit
raw = raw.ljust(22, b' ')
buyer, seller, book = (raw[i:i + 4].decode('latin1') for i in (0, 4, 8))
amt = int(''.join(c for c in raw[12:22].decode('latin1').replace(' ', '0') if c.isdigit()) or 0)


def recs(path, size):
    d = open(path, 'rb').read()
    return [d[i:i + size].decode('latin1') for i in range(0, len(d), size)]


def save(path, r):
    open(path, 'wb').write(''.join(r).encode('latin1'))


acc = recs('data/ACCOUNTS.DAT', 34)
bks = recs('data/BOOKS.DAT', 28)
bf = sf = bk = vo = False
for a in acc:
    bf |= a[:4] == buyer
    sf |= a[:4] == seller
for b in bks:
    if b[:4] == book:
        bk = True
        if b[24:28] == seller:
            vo = True
print(" ")
if bf and sf and bk and vo:
    for i, a in enumerate(acc):
        bal = int(a[24:34])
        if a[:4] == buyer:
            bal = abs(bal - amt) % 10**10
        if a[:4] == seller:
            bal = (bal + amt) % 10**10
        acc[i] = a[:24] + '%010d' % bal
    for i, b in enumerate(bks):
        if b[:4] == book:
            bks[i] = b[:24] + buyer
    save('data/ACCOUNTS.DAT', acc)
    save('data/BOOKS.DAT', bks)
    with open('data/TRANSACTIONS.DAT', 'ab') as f:
        f.write((book + '%010d' % amt + seller + buyer).encode('latin1'))
    print("Transaction completed successfully")
else:
    print("Transaction failed due to validation errors")
