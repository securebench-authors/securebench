import os
os.chdir(os.path.dirname(os.path.abspath(__file__)))

def rd(p):
    return open(p, newline='').read()

def recs(s, n):
    return [s[i:i+n] for i in range(0, len(s) - n + 1, n)]

raw = rd('src/INPUT.DAT').rstrip('\r\n')
if not raw:
    print("Error: Input file is empty")
    raise SystemExit
raw = raw.ljust(22)
buyer, seller, book = raw[0:4], raw[4:8], raw[8:12]
amt = int(raw[12:22].replace(' ', '0')) if raw[12:22].replace(' ', '0').isdigit() else 0

acc = recs(rd('data/ACCOUNTS.DAT'), 28)
bks = recs(rd('data/BOOKS.DAT'), 28)
bf = sf = kf = vo = False
for a in acc:
    if a[:4] == buyer: bf = True
    if a[:4] == seller: sf = True
for b in bks:
    if b[:4] == book:
        kf = True
        if b[24:28] == seller: vo = True
print(" ")
if bf and sf and kf and vo:
    for i, a in enumerate(acc):
        if a[:4] == buyer:
            a = a[:24] + "%010d" % (abs(int(a[24:]) - amt) % 10**10); acc[i] = a
        if a[:4] == seller:
            a = a[:24] + "%010d" % ((int(a[24:]) + amt) % 10**10); acc[i] = a
    for i, b in enumerate(bks):
        if b[:4] == book:
            bks[i] = b[:24] + buyer
    open('data/ACCOUNTS.DAT', 'w', newline='').write(''.join(acc))
    open('data/BOOKS.DAT', 'w', newline='').write(''.join(bks))
    with open('data/TRANSACTIONS.DAT', 'a', newline='') as f:
        f.write(book + "%010d" % amt + seller + buyer)
    print("Transaction completed successfully")
else:
    print("Transaction failed due to validation errors")
