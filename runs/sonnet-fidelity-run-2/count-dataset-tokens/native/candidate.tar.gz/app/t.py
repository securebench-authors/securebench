from datasets import load_dataset
from transformers import AutoTokenizer
tok=AutoTokenizer.from_pretrained("Qwen/Qwen2.5-1.5B-Instruct")
ds=load_dataset("ryanmarten/OpenThoughts-1k-sample","metadata",split="train")
ds=ds.filter(lambda x:x["domain"] in ("physics","chemistry","biology"))
a=b=0
for x in ds:
    a+=len(tok(x["deepseek_reasoning"] or "")["input_ids"]); b+=len(tok(x["deepseek_solution"] or "")["input_ids"])
print(len(ds),a,b,a+b)
open("answer.txt","w").write(str(a+b))
