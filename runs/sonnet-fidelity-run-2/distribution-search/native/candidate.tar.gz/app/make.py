import numpy as np
from scipy.optimize import fsolve
n=150000
def build(x,m,lt):
    # one element x, m elements share (1-x-r)/m, rest share r; tiny eps = exp(lt)
    pass
def kls(p):
    return np.sum(p*np.log(p*n)), np.mean(-np.log(p*n))
# params: a = top mass, m moderate elems total mass 1-a, rest eps each (mass negligible-ish)
def make(a,m,e):
    p=np.full(n,e); p[0]=a; p[1:m+1]=(1-a-(n-m-1)*e)/m
    return p
def f(v,m):
    a=1/(1+np.exp(-v[0])); e=np.exp(v[1])
    p=make(a,m,e)
    if p.min()<=0: return [1e3,1e3]
    k=kls(p); return [k[0]-10,k[1]-10]
for m in [10,100,1000,5000]:
  for v0 in [(0,-20),(1,-22),(-1,-23),(2,-25)]:
    s,info,ier,_=fsolve(f,v0,args=(m,),full_output=True)
    if ier==1:
        a=1/(1+np.exp(-s[0]));p=make(a,m,np.exp(s[1]))
        if p.min()>0 and abs(p.sum()-1)<1e-9:
            k=kls(p)
            if abs(k[0]-10)<1e-4 and abs(k[1]-10)<1e-4:
                np.save('/app/dist.npy',p);print(m,k,p.sum(),p.min());raise SystemExit
