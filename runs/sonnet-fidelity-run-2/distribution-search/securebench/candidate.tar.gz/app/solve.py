import numpy as np
from scipy.optimize import fsolve
V=150000
def build(p0,lc,n1=1000):
    c=np.exp(lc); rest=V-1-n1
    a=(1-p0-c*rest)/n1
    return a,c,n1,rest
def kls(p0,lc,n1):
    a,c,n1,rest=build(p0,lc,n1)
    if a<=0 or c<=0 or not 0<p0<1: return None
    p=np.concatenate([[p0],np.full(n1,a),np.full(rest,c)])
    return p
def kl(p):
    f=np.sum(p*np.log(p*V)); b=-np.log(V)-np.mean(np.log(p)); return f,b
for n1 in [100,1000,5000,20000]:
    def F(x):
        p=kls(x[0],x[1],n1)
        if p is None: return [1e3,1e3]
        f,b=kl(p); return [f-10,b-10]
    for g in [(0.9,-24),(0.5,-25),(0.95,-23),(0.8,-22)]:
        s=fsolve(F,g,xtol=1e-13)
        p=kls(s[0],s[1],n1)
        if p is not None:
            f,b=kl(p)
            if abs(f-10)<1e-4 and abs(b-10)<1e-4:
                np.save('/app/dist.npy',p);print(n1,f,b,p.sum(),p.min());raise SystemExit
