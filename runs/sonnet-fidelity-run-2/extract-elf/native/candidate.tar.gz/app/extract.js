const fs=require('fs');
const b=fs.readFileSync(process.argv[2]);
const out={};
const phoff=Number(b.readBigUInt64LE(32)),phentsize=b.readUInt16LE(54),phnum=b.readUInt16LE(56);
for(let i=0;i<phnum;i++){
  const o=phoff+i*phentsize;
  if(b.readUInt32LE(o)!==1)continue;
  const off=Number(b.readBigUInt64LE(o+8)),va=Number(b.readBigUInt64LE(o+16)),fsz=Number(b.readBigUInt64LE(o+32));
  for(let j=0;j+4<=fsz;j+=4)out[va+j]=b.readUInt32LE(off+j);
}
console.log(JSON.stringify(out));
