const fs = require('fs');
const b = fs.readFileSync(process.argv[2]);
const phoff = Number(b.readBigUInt64LE(32));
const phentsize = b.readUInt16LE(54);
const phnum = b.readUInt16LE(56);
const out = {};
for (let i = 0; i < phnum; i++) {
  const o = phoff + i * phentsize;
  if (b.readUInt32LE(o) !== 1) continue; // PT_LOAD
  const off = Number(b.readBigUInt64LE(o + 8));
  const vaddr = Number(b.readBigUInt64LE(o + 16));
  const filesz = Number(b.readBigUInt64LE(o + 32));
  for (let j = 0; j + 4 <= filesz; j += 4) out[vaddr + j] = b.readUInt32LE(off + j);
}
console.log(JSON.stringify(out));
