import random
from collections import Counter
from feal import f_function

M = 0xFFFFFFFF


def _pairs(encrypt_fn, D, n):
    out = []
    for _ in range(n):
        p = random.getrandbits(64)
        q = p ^ (D << 32) ^ D
        out.append(tuple((c >> 32, (c & M) ^ (c >> 32)) for c in (encrypt_fn(p), encrypt_fn(q))))
    return out


def _score(pairs, k):
    cnt = Counter()
    for (r, l), (r2, l2) in pairs:
        cnt[(r ^ r2) ^ f_function(l ^ k) ^ f_function(l2 ^ k)] += 1
    return cnt.most_common(1)[0][1]


def attack(encrypt_fn):
    D = 0x80808080
    small = _pairs(encrypt_fn, D, 12)
    cands = [(_score(small, (x * 1234567) & M), x) for x in range(65536)]
    cands.sort(reverse=True)
    big = _pairs(encrypt_fn, D, 150)
    best = max(cands[:200], key=lambda t: _score(big, (t[1] * 1234567) & M))
    return (best[1] * 1234567) & M
