import time, feal, attack
for i in range(5):
    feal.create_random_keys(); t=time.time()
    r=attack.attack(feal.encrypt); print(r==feal.key[5], time.time()-t)
