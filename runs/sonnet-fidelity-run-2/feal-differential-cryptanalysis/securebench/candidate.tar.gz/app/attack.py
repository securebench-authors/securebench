import os
from feal import f_function

A = 0x80808080
D = 0x02000002


def attack(encrypt_fn):
    pairs = []
    for _ in range(8):
        l = int.from_bytes(os.urandom(4), 'big')
        r = int.from_bytes(os.urandom(4), 'big')
        p1 = (l << 32) | r
        p2 = ((l ^ A) << 32) | (r ^ A)
        c1, c2 = encrypt_fn(p1), encrypt_fn(p2)
        h1, h2 = c1 >> 32, c2 >> 32
        r1 = (c1 & 0xFFFFFFFF) ^ h1
        r2 = (c2 & 0xFFFFFFFF) ^ h2
        pairs.append((r1, r2, h1 ^ h2 ^ D))
    for x in range(65536):
        k = (x * 1234567) & 0xFFFFFFFF
        if all(f_function(a ^ k) ^ f_function(b ^ k) == t for a, b, t in pairs):
            return k
