#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <immintrin.h>
#include <omp.h>
typedef uint32_t u32; typedef uint8_t u8;
static inline u32 expand(u32 k){return k^(k<<16)^(k*12345);}
static inline u8 g(u8 a,u8 b,u8 x){u8 t=a+b+x;return (t<<2)|(t>>6);}
static inline u8 gi(u8 y){return (y>>2)|(y<<6);}
static u32 F(u32 v){u8 x0=v,x1=v>>8,x2=v>>16,x3=v>>24;
 u8 y2=g(x3^x2,x1^x0,1),y3=g(x3,y2,0),y1=g(x1^x0,y2,0),y0=g(x0,y1,1);
 return y0|(y1<<8)|(y2<<16)|((u32)y3<<24);}
static u32 Finv(u32 v){u8 y0=v,y1=v>>8,y2=v>>16,y3=v>>24;
 u8 b=gi(y1)-y2, x3=gi(y3)-y2, x0=gi(y0)-y1-1, a=gi(y2)-b-1;
 u8 x2=a^x3,x1=b^x0; return x0|(x1<<8)|(x2<<16)|((u32)x3<<24);}
u32 key[4];
uint64_t enc(uint64_t p){u32 l=p>>32,r=p;r^=l;for(int i=0;i<4;i++){u32 m=F(r^key[i]);u32 t=r;r=l^m;l=t;}l^=r;return ((uint64_t)r<<32)|l;}
uint64_t P[32],C[32];
static uint8_t lowok[65536]; static uint64_t *bs;
static inline int inK(u32 x){return (bs[x>>6]>>(x&63))&1;}
static u32 K[1<<20];
int main(){
 FILE*f=fopen("pairs.txt","r");for(int i=0;i<32;i++)fscanf(f,"%lu %lu",&P[i],&C[i]);
 bs=calloc(1<<26,8);for(u32 s=0;s<(1<<20);s++){K[s]=expand(s);lowok[K[s]&0xFFFF]=1;bs[K[s]>>6]|=1ULL<<(K[s]&63);}
 u32 L0=P[0]>>32,R0=(u32)P[0]^L0; u32 R4=C[0]>>32,R3=((u32)C[0])^R4;
 u32*B=malloc(4<<20);
 for(u32 s=0;s<(1<<20);s++){u32 R2=R4^F(R3^K[s]);B[s]=Finv(R0^R2);}
 volatile int done=0;
 #pragma omp parallel for schedule(dynamic,1)
 for(int k0=0;k0<(1<<20);k0++){
  if(done)continue;
  u32 R1=L0^F(R0^K[k0]);
  for(u32 k3=0;k3<(1<<20);k3++){
   u32 x=R1^B[k3];
   if(!lowok[x&0xFFFF]||!inK(x))continue;
   // candidate k1 = x; find s1
   u32 R2=R4^F(R3^K[k3]);
   u32 t=Finv(R3^R1)^R2; // = k2
   if(!inK(t))continue;
   for(u32 s1=0;s1<(1<<20);s1++)if(K[s1]==x){for(u32 s2=0;s2<(1<<20);s2++)if(K[s2]==t){
     u32 sv[4]={k0,s1,s2,k3};
     u32 sk[4]={K[k0],x,t,K[k3]};memcpy(key,sk,16);
     int good=1;for(int i=0;i<32;i++)if(enc(P[i])!=C[i])good=0;
     if(good){
       #pragma omp critical
       {printf("seeds %x %x %x %x\n",k0,s1,s2,k3);fflush(stdout);done=1;}
     }}break;}
  }
 }
}
