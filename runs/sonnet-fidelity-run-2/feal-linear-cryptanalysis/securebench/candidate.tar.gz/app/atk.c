#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
typedef uint32_t u32; typedef uint8_t u8; typedef uint64_t u64;
u32 expand(u32 k){return k^(k<<16)^(k*12345);}
u8 g(u8 a,u8 b,u8 x){u8 t=a+b+x;return (t<<2)|(t>>6);}
u8 gi(u8 y,u8 b,u8 x){u8 t=(y>>2)|(y<<6);return t-b-x;}
u32 f(u32 v){u8 x[4],y[4];for(int i=0;i<4;i++){x[i]=v&255;v>>=8;}
y[2]=g(x[3]^x[2],x[1]^x[0],1);y[3]=g(x[3],y[2],0);y[1]=g(x[1]^x[0],y[2],0);y[0]=g(x[0],y[1],1);
u32 o=0;for(int i=0;i<4;i++)o|=(u32)y[i]<<(8*i);return o;}
u32 finv(u32 v){u8 y[4],x[4];for(int i=0;i<4;i++)y[i]=v>>(8*i);
u8 b=gi(y[1],y[2],0),a=gi(y[2],b,1);x[3]=gi(y[3],y[2],0);x[0]=gi(y[0],y[1],1);x[2]=a^x[3];x[1]=b^x[0];
u32 o=0;for(int i=0;i<4;i++)o|=(u32)x[i]<<(8*i);return o;}
u32 l0[32],r0[32],l4[32],r4[32];
typedef struct{u32 d,k;}E_;
int cmp(const void*a,const void*b){u32 x=((E_*)a)->d,y=((E_*)b)->d;return x<y?-1:x>y;}
int main(){FILE*fp=fopen("pairs.txt","r");int n=0;u64 p,c;
while(n<32&&fscanf(fp,"%lu %lu",&p,&c)==2){u32 L=p>>32,R=p;l0[n]=L;r0[n]=R^L;r4[n]=c>>32;l4[n]=(u32)c^r4[n];n++;}
int N=1<<20;E_*A=malloc(N*sizeof(E_));
for(u32 k=0;k<N;k++){u32 K=expand(k);
 u32 r1p=l0[0]^f(r0[0]^K),r1q=l0[1]^f(r0[1]^K);A[k].d=r1p^r1q;A[k].k=k;}
qsort(A,N,sizeof(E_),cmp);
for(u32 k3=0;k3<N;k3++){u32 K=expand(k3);u32 B[2];
 for(int i=0;i<2;i++){u32 r2=r4[i]^f(l4[i]^K);B[i]=finv(r0[i]^r2);}
 u32 d=B[0]^B[1];
 int lo=0,hi=N;while(lo<hi){int m=(lo+hi)/2;if(A[m].d<d)lo=m+1;else hi=m;}
 for(int j=lo;j<N&&A[j].d==d;j++){u32 k0=A[j].k,K0=expand(k0);
  u32 r1=l0[0]^f(r0[0]^K0);u32 k1=r1^B[0]; // expanded key1
  int ok=1;u32 K1=k1;
  // find seed for k1 later; verify with all pairs using expanded key1
  for(int i=0;i<32&&ok;i++){u32 a=l0[i]^f(r0[i]^K0);u32 r2=r4[i]^f(l4[i]^K);
   if((r0[i]^f(a^K1))!=r2)ok=0;
   u32 r3=l4[i]; if((a^f(r2^0))==0&&0)ok=0;}
  if(ok){ // solve k2 : r3 = r1 ^ f(r2^K2)
   u32 a=l0[0]^f(r0[0]^K0),r2=r4[0]^f(l4[0]^K);u32 K2=r2^finv(l4[0]^a);
   int good=1;for(int i=0;i<32;i++){u32 a=l0[i]^f(r0[i]^K0);u32 r2=r4[i]^f(l4[i]^K);if((a^f(r2^K2))!=l4[i])good=0;}
   if(good){u32 s1=0,s2=0;for(u32 s=0;s<N;s++){if(expand(s)==K1)s1=s+1;if(expand(s)==K2)s2=s+1;}
    printf("%x %x %x %x\n",k0,s1-1,s2-1,k3);}}
 }}
}
