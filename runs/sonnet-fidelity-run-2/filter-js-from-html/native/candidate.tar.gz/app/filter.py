import html
import re
import sys

SCRIPT_RE = r'<\s*script\b(?:"[^"]*"|\'[^\']*\'|[^\'">])*>.*?(?:<\s*/\s*script[^>]*>|\Z)'
BLOCK_RE = (r'<\s*(iframe|object|embed|applet)\b(?:"[^"]*"|\'[^\']*\'|[^\'">])*>'
            r'(?:.*?<\s*/\s*\1[^>]*>|)')
TOKEN = re.compile(
    r'(?P<comment><!--.*?(?:-->|\Z))'
    r'|(?P<script>' + SCRIPT_RE + r')'
    r'|(?P<block>' + BLOCK_RE.replace(r'\1', r'\2') + r')'
    r'|(?P<tag><[a-zA-Z][^\s/>]*(?:"[^"]*"|\'[^\']*\'|[^\'">])*>?)',
    re.S | re.I)
ATTR = re.compile(
    r'(?P<sep>[\s/]+)(?P<name>[^\s/=>"\']+)(?P<val>\s*=\s*(?:"[^"]*"|\'[^\']*\'|[^\s>]*))?',
    re.S)


def bad_value(name, val):
    v = html.unescape(val)
    v = re.sub(r'[\x00-\x20\x7f]+', '', v).lower()
    if re.match(r'(javascript|vbscript|livescript|mocha):', v):
        return True
    if v.startswith('data:') and 'html' in v[:30] or v.startswith('data:image/svg'):
        return True
    if name == 'style' and ('expression(' in v or 'javascript:' in v
                            or '-moz-binding' in v):
        return True
    return False


def clean_tag(m):
    tag = m.group(0)
    head = re.match(r'<[^\s/>]*', tag).group(0)
    rest = tag[len(head):]

    def fix(a):
        name = a.group('name').lower()
        val = a.group('val') or ''
        v = val.split('=', 1)[1].strip().strip('"\'') if val else ''
        if name.startswith('on') or bad_value(name, v):
            return ''
        return a.group(0)

    return head + ATTR.sub(fix, rest)


def sub(m):
    if m.group('comment') is not None:
        return m.group(0)
    if m.group('script') is not None or m.group('block') is not None:
        return ''
    return clean_tag(m)


def main():
    path = sys.argv[1]
    with open(path, 'r', encoding='utf-8', errors='surrogateescape', newline='') as f:
        data = f.read()
    out = TOKEN.sub(sub, data)
    with open(path, 'w', encoding='utf-8', errors='surrogateescape', newline='') as f:
        f.write(out)


if __name__ == '__main__':
    main()
