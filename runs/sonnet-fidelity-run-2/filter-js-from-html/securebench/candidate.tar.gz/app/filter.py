#!/usr/bin/env python3
"""Remove JavaScript from an HTML file in place, leaving everything else byte-identical."""
import html
import re
import sys

BLOCK = ("script", "iframe", "object", "embed", "applet")
URL_ATTRS = {"href", "src", "action", "formaction", "xlink:href", "data", "background",
             "poster", "srcdoc", "codebase", "lowsrc", "dynsrc", "ping"}

TAG_RE = re.compile(r"<[a-zA-Z][^\s/>]*(?:\"[^\"]*\"|'[^']*'|[^'\">])*>")
ATTR_RE = re.compile(
    r"""(?P<sep>[\s/]+)(?P<name>[^\s"'<>/=]+)(?P<val>\s*=\s*(?:"[^"]*"|'[^']*'|[^\s>]*))?""")


def bad_value(v):
    v = html.unescape(v)
    v = re.sub(r"[\x00-\x20\x7f]+", "", v).lower()
    return (v.startswith(("javascript:", "vbscript:", "livescript:", "data:text/html",
                          "data:application", "data:image/svg"))
            or "expression(" in v or "javascript:" in v and v.startswith(("url", "expression")))


def clean_tag(m):
    tag = m.group(0)
    name_end = re.match(r"<[^\s/>]+", tag).end()
    head, rest = tag[:name_end], tag[name_end:]

    def attr(a):
        name = a.group("name").lower()
        val = a.group("val") or ""
        v = val.split("=", 1)[1].strip().strip("\"'") if "=" in val else ""
        if name.startswith("on"):
            return ""
        if name in URL_ATTRS and bad_value(v):
            return ""
        if name == "style" and ("expression(" in v.lower() or "javascript:" in v.lower()
                                or "behavior" in v.lower() or "-moz-binding" in v.lower()):
            return ""
        return a.group(0)

    return head + ATTR_RE.sub(attr, rest)


def filter_html(s):
    for t in BLOCK:
        s = re.sub(r"<%s\b.*?</%s\s*>" % (t, t), "", s, flags=re.I | re.S)
        s = re.sub(r"<%s\b.*\Z" % t, "", s, flags=re.I | re.S)
        s = re.sub(r"</%s\s*>" % t, "", s, flags=re.I)
    s = re.sub(r"<meta\b[^>]*http-equiv\s*=\s*[\"']?\s*refresh[^>]*>", "", s, flags=re.I)
    return TAG_RE.sub(clean_tag, s)


def main():
    path = sys.argv[1]
    with open(path, "r", encoding="utf-8", errors="surrogateescape", newline="") as f:
        data = f.read()
    out = filter_html(data)
    with open(path, "w", encoding="utf-8", errors="surrogateescape", newline="") as f:
        f.write(out)


if __name__ == "__main__":
    main()
