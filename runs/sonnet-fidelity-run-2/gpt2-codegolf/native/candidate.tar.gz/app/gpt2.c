#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
typedef float F;typedef unsigned char U;
U bs[256],ib[256],*pa[50000],*S[50257],*o,*p,*r,*w;
int la[50000],lb[50000],Ln[50257],T[1024],n,i,j,k,t,l;
F*W,*E,*P,x[768],h[768],q[2304],a[768],f[3072],s[1024],kc[12<<10<<10],vc[12<<10<<10];
#define Z 7087872
int g(){int c=*p++;if(c>127)c=(c&31)<<6|*p++&63;return c<256?c:bs[188+c-256];}
int K(int c){return c==32||c>8&&c<14||!c?0:(c|32)-97<26u||c>127?1:c-48<10u?2:3;}
void LN(F*o,F*x,F*g,F*b){F m=0,v=0;int i;for(i=0;i<768;i++)m+=x[i];m/=768;for(i=0;i<768;i++)v+=(x[i]-m)*(x[i]-m);v=1/sqrtf(v/768+1e-5);for(i=0;i<768;i++)o[i]=(x[i]-m)*v*g[i]+b[i];}
void M(F*o,F*x,F*w,F*b,int n,int m){int i,j;memcpy(o,b,m*4);for(i=0;i<n;i++)for(j=0;j<m;j++)o[j]+=x[i]*w[i*m+j];}
int main(int c,char**v){
FILE*d=fopen(v[1],"rb");W=malloc(497759232);fread(W,1,497759232,d);
for(i=0;i<256;i++)bs[i]=i;
for(j=k=0;j<2;j++)for(i=0;i<256;i++)if(j^(i>32&&i<127||i>160&&i!=173))bs[k++]=i;
for(i=0;i<256;i++)ib[bs[i]]=i,S[i]=bs+i,Ln[i]=1;
d=fopen(v[2],"rb");p=calloc(1<<20,1);o=calloc(1<<20,1);fread(p,1,1<<20,d);while(*p++!=10);
for(i=0;i<50000;i++){pa[i]=o;for(k=0;*p!=32;k++)*o++=g();p++;la[i]=k;for(k=0;*p!=10;k++)*o++=g();p++;lb[i]=k;S[256+i]=pa[i];Ln[256+i]=la[i]+k;}
for(p=v[3];*p;p=r){
r=p;
if(*p==39){char*e[]={"s","t","m","d","re","ve","ll"};for(i=0;i<7;i++)if(!strncmp(p+1,e[i],strlen(e[i])))r=p+1+strlen(e[i]);}
if(r==p){r=p+(*p==32&&K(p[1]));k=K(*r);
if(k)while(K(*r)==k)r++;else{while(*r&&!K(*r))r++;if(*r&&r-p>1)r--;}}
int st[99],ln[99],id[99],m=r-p;w=p;
for(i=0;i<m;i++)st[i]=i,ln[i]=1,id[i]=ib[w[i]];
for(i=0;i<50000;i++)for(k=0;k<m-1;k++)if(ln[k]==la[i]&&ln[k+1]==lb[i]&&!memcmp(w+st[k],pa[i],la[i]+lb[i])){ln[k]+=ln[k+1];id[k]=256+i;m--;for(j=k+1;j<m;j++)st[j]=st[j+1],ln[j]=ln[j+1],id[j]=id[j+1];}
for(i=0;i<m;i++)T[n++]=id[i];}
fputs(v[3],stdout);
E=W+85054464+1536+786432;P=W+85054464+1536;
for(t=0;t<n+19;t++){
for(i=0;i<768;i++)x[i]=E[T[t]*768+i]+P[t*768+i];
for(l=0;l<12;l++){
F*B=W+(l<2?l:l<10?l+2:l-8)*(long)Z;
LN(h,x,B+2363136,B+2362368);M(q,h,B+2304,B,768,2304);
memcpy(kc+(l*1024+t)*768,q+768,3072);memcpy(vc+(l*1024+t)*768,q+1536,3072);
for(i=0;i<12;i++){F mx=-1e9,z=0;
for(j=0;j<=t;j++){F e=0;for(k=0;k<64;k++)e+=q[i*64+k]*kc[(l*1024+j)*768+i*64+k];s[j]=e*.125f;if(e*.125f>mx)mx=e*.125f;}
for(j=0;j<=t;j++)z+=s[j]=expf(s[j]-mx);
for(k=0;k<64;k++){F e=0;for(j=0;j<=t;j++)e+=s[j]*vc[(l*1024+j)*768+i*64+k];a[i*64+k]=e/z;}}
M(h,a,B+1772544,B+1771776,768,768);for(i=0;i<768;i++)x[i]+=h[i];
LN(h,x,B+2364672,B+2363904);M(f,h,B+2368512,B+2365440,768,3072);
for(i=0;i<3072;i++)f[i]=.5f*f[i]*(1+tanhf(.79788456f*(f[i]+.044715f*f[i]*f[i]*f[i])));
M(h,f,B+4728576,B+4727808,3072,768);for(i=0;i<768;i++)x[i]+=h[i];}
if(t<n-1)continue;
LN(h,x,W+85054464+768,W+85054464);
F mx=-1e9;
for(j=0;j<50257;j++){F e=0;for(i=0;i<768;i++)e+=E[j*768+i]*h[i];if(e>mx)mx=e,k=j;}
T[t+1]=k;fwrite(S[k],1,Ln[k],stdout);fflush(stdout);}
puts("");}
