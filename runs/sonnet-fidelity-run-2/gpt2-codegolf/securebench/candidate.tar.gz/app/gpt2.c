#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
typedef float F;
#define S 7087872
char*T[50257],Q[1<<21],V[1<<19],bb[256],*p,*q;
int N[50257],K[50000],cp[256],I[3000],A[3000],n,m;
F*W,X[768],H[768],Y[768],B[3072],D[2304],C[12][1024][1536],P[1024];
void M(F*o,F*x,F*w,F*b,int n,int m,int a){int i,j;
for(j=0;j<m;j++)o[j]=a*o[j]+b[j];
for(i=0;i<n;i++)for(j=0;j<m;j++)o[j]+=x[i]*w[i*m+j];}
void L(F*o,F*x,F*g,F*b){F u=0,v=0;int i;
for(i=0;i<768;i++)u+=x[i];u/=768;
for(i=0;i<768;i++)v+=(x[i]-u)*(x[i]-u);v=1/sqrtf(v/768+1e-5);
for(i=0;i<768;i++)o[i]=(x[i]-u)*v*g[i]+b[i];}
int d(){int c=*p++&255,k;if(c>127)c=(c&31)<<6|*p++&63;
for(k=0;cp[k]!=c;k++);return bb[k];}
int Z(int c){c&=255;return c<33?0:c>47&&c<58?2:c>64&&c<91||c>96&&c<123||c>127?1:3;}
int rk(int x,int y){int i,a=N[x],t=a+N[y];
for(i=0;i<50000;i++)if(N[256+i]==t&&K[i]==a&&!memcmp(T[256+i],T[x],a)&&!memcmp(T[256+i]+a,T[y],N[y]))return i;
return 1<<30;}
int f(int t,int s){int l,i,j,h,u,r=0;F*w,*c,e,z,g;
F*E=W+12*S+1536+786432;
for(i=0;i<768;i++)X[i]=E[t*768+i]+E[-786432+s*768+i];
for(l=0;l<12;l++){w=W+(l<2?l:l<10?l+2:l-8)*(long)S;
L(H,X,w+2363136,w+2362368);
M(D,H,w+2304,w,768,2304,0);
memcpy(C[l][s],D+768,6144);
for(h=0;h<12;h++){F sc[1024];z=-1e30;
for(u=0;u<=s;u++){c=C[l][u]+h*64;for(e=i=0;i<64;i++)e+=D[h*64+i]*c[i];
sc[u]=e/8;if(e/8>z)z=e/8;}
for(g=u=0;u<=s;u++)g+=sc[u]=expf(sc[u]-z);
for(i=0;i<64;i++){for(e=u=0;u<=s;u++)e+=sc[u]*C[l][u][768+h*64+i];Y[h*64+i]=e/g;}}
M(X,Y,w+1772544,w+1771776,768,768,1);
L(H,X,w+2364672,w+2363904);
M(B,H,w+2368512,w+2365440,768,3072,0);
for(i=0;i<3072;i++)e=B[i],B[i]=.5*e*(1+tanhf(.7978846*(e+.044715*e*e*e)));
M(X,B,w+4728576,w+4727808,3072,768,1);}
if(s<m-1)return 0;
L(H,X,W+12*S+768,W+12*S);
for(z=-1e30,j=0;j<50257;j++){for(e=i=0;i<768;i++)e+=H[i]*E[j*768+i];if(e>z)z=e,r=j;}
return r;}
int main(int c,char**v){FILE*o=fopen(v[1],"rb");int i,k,b,s,j;char*e,*a[]={"'s","'t","'m","'d","'re","'ve","'ll"};
W=malloc(497759232);fread(W,4,124439808,o);
for(b=i=k=0;b<512;b++)if((b&255)>32&&(b&255)<127||(b&255)>160&&(b&255)!=173){if(b<256)bb[i]=b,cp[i++]=b;}else if(b>255)bb[i]=b-256,cp[i++]=256+k++;
for(i=0;i<256;i++)T[i]=bb+i,N[i]=1;
o=fopen(v[2],"rb");fread(V,1,sizeof V-1,o);p=V;while(*p++!=10);q=Q;
for(i=0;i<50000&&*p;i++){T[256+i]=q;while(*p!=32)*q++=d();K[i]=q-T[256+i];p++;while(*p!=10)*q++=d();p++;N[256+i]=q-T[256+i];}
for(p=v[3];*p;){char*t=p;e=p;
for(i=0;i<7;i++)if(!strncmp(p,a[i],strlen(a[i])))e=p+strlen(a[i]);
if(e==p){t=p;if(*t==32&&Z(t[1]))t++;
if(Z(*t)){k=Z(*t);while(Z(*t)==k)t++;}
else{while(*t&&!Z(*t))t++;if(*t&&t-p>1)t--;}
e=t;}
for(s=0;p<e;p++){for(i=0;bb[i]!=*p;i++);A[s++]=i;}
for(;;){b=1<<30;k=0;
for(j=0;j<s-1;j++){i=rk(A[j],A[j+1]);if(i<b)b=i,k=j;}
if(b==1<<30)break;
A[k]=256+b;memmove(A+k+1,A+k+2,(s---k-2)*4);}
memcpy(I+n,A,s*4);n+=s;}
m=n;
for(s=0;n<m+20;s++){j=f(I[s],s);if(s>=m-1)I[n++]=j,fwrite(T[j],1,N[j],stdout);}
return 0;}
