import fcntl
import os
import pty
import select
import signal
import struct
import termios
import threading
import time

from base_terminal import BaseTerminal


class HeadlessTerminal(BaseTerminal):
    """An interactive bash shell running on a pseudo-terminal."""

    def __init__(self, rows: int = 50, cols: int = 200, shell: str = "bash"):
        self.rows, self.cols = rows, cols
        self._buf = bytearray()
        self._lock = threading.Lock()
        self._closed = False

        pid, fd = pty.fork()
        if pid == 0:
            env = dict(os.environ, TERM="xterm-256color",
                       LINES=str(rows), COLUMNS=str(cols))
            try:
                os.execvpe(shell, [shell, "-i"], env)
            finally:
                os._exit(127)
        self.pid, self.fd = pid, fd
        fcntl.ioctl(fd, termios.TIOCSWINSZ, struct.pack("HHHH", rows, cols, 0, 0))
        self._reader = threading.Thread(target=self._read_loop, daemon=True)
        self._reader.start()
        time.sleep(0.5)  # let startup files run and the prompt appear

    def _read_loop(self) -> None:
        while not self._closed:
            try:
                r, _, _ = select.select([self.fd], [], [], 0.1)
                if not r:
                    continue
                data = os.read(self.fd, 65536)
            except (OSError, ValueError):
                break
            if not data:
                break
            with self._lock:
                self._buf.extend(data)

    def send_keystrokes(self, keystrokes: str, wait_sec: float = 0.0) -> None:
        """Write raw keystrokes (e.g. "ls\\n", "\\x03", "\\x1b[A") to the terminal."""
        data = keystrokes.encode()
        while data:
            n = os.write(self.fd, data)
            data = data[n:]
        if wait_sec > 0:
            time.sleep(wait_sec)

    def get_output(self, clear: bool = False) -> str:
        """Return everything the terminal has printed so far."""
        with self._lock:
            out = bytes(self._buf).decode(errors="replace")
            if clear:
                self._buf.clear()
        return out

    def close(self) -> None:
        if self._closed:
            return
        self._closed = True
        try:
            os.kill(self.pid, signal.SIGHUP)
        except OSError:
            pass
        try:
            os.close(self.fd)
        except OSError:
            pass
        try:
            os.waitpid(self.pid, 0)
        except OSError:
            pass

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        self.close()

    def __del__(self):
        try:
            self.close()
        except Exception:
            pass
