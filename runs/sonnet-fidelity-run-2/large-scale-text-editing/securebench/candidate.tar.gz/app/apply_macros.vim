call setreg('a', ":s/\\v^\\s*(.{-})\\s*,\\s*(.{-})\\s*,\\s*(.{-})\\s*$/\\U\\3;\\2;\\1;OK/\<CR>")
call setreg('b', "0")
call setreg('c', "$")
:%normal! @a
:%normal! @b
:%normal! @c
:wq
