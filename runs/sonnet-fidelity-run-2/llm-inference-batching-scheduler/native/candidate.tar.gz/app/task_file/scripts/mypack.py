import json,sys,collections
sys.path.insert(0,'scripts')
from cost_model import *
cm=CostModel(64);import os;MU=float(os.environ.get('MU',0))
def load(p): return [json.loads(l) for l in open(p)]
def plan(reqs,lam,shapes=None):
    groups=collections.defaultdict(list)
    for r in reqs: groups[align(r['prompt_len'],64)].append(r)
    batches=[]
    for S,g in groups.items():
        g.sort(key=lambda r:r['gen_len']); n=len(g)
        def c(i,j):
            m=cm.batch_metrics(g[i:j]); return m['cost']+1e7+lam*m['pad_tokens']+MU*(max(m['latencies'])+8)
        best=[0]+[1e30]*n; pr=[0]*(n+1)
        for j in range(1,n+1):
            for i in range(j):
                v=best[i]+c(i,j)
                if v<best[j]: best[j]=v;pr[j]=i
        j=n
        while j>0: batches.append((S,g[pr[j]:j])); j=pr[j]
    return batches
def assign(batches,k):
    Ss=sorted({S for S,_ in batches}); return Ss
def out(bs,shapes,path,pre):
    with open(path,'w') as f:
        for i,(S,g) in enumerate(bs):
            sh=min(s for s in shapes if s>=S)
            for r in g: f.write(json.dumps({"request_id":r['request_id'],"batch_id":f"{pre}-{i:04d}","shape":{"seq_align":sh,"heads_align":32,"hidden_align":4096}})+"\n")
if __name__=="__main__":
    lam=float(sys.argv[1])
    R=[load(f'input_data/requests_bucket_{i}.jsonl') for i in (1,2)]
    B=[plan(r,lam) for r in R]
    allS=sorted({S for b in B for S,_ in b}); print(allS)
    # choose 8 shapes: greedy drop of the one adding least padding-of-shape cost; simple: DP by count weight
    cnt=collections.Counter(S for b in B for S,_ in b)
    shapes=set(allS)
    while len(shapes)>8:
        best=None
        for s in sorted(shapes)[:-1]:
            nxt=min(t for t in shapes if t>s)
            d=cnt[s]*0+ (0)  # shape padding free; drop smallest compile-cost-insensitive by count
            key=(cnt[s],s)
            if best is None or key<best[0]: best=(key,s)
        shapes.discard(best[1])
    shapes=sorted(shapes);print(shapes)
    for i,(b,rr) in enumerate(zip(B,R),1):
        out(b,shapes,f'output_data/plan_b{i}.jsonl',f'b{i}')
        reqs={r['request_id']:r for r in rr}
        pl=[json.loads(l) for l in open(f'output_data/plan_b{i}.jsonl')]
        m=cm.plan_metrics(reqs,pl)
        print(i,len(b),m['cost'],m['pad_ratio'],m['p95_latency_ms'],m['sequential_timecost'])
