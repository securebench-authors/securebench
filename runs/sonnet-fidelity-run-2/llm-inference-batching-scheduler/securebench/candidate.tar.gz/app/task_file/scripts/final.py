import sys,json
sys.path.insert(0,'scripts')
from solve2 import *
mus={1:float(sys.argv[1]),2:float(sys.argv[2])}
BS={b:solve2(load(b),mus[b]) for b in (1,2)}
Sm={b:{max(align(r['prompt_len'],64) for r in x) for x in BS[b]} for b in BS}
vals=sorted(Sm[1]|Sm[2]);m=len(vals);K=8
def gc(i,j): # group vals[i:j], shape vals[j-1]
    f=sum(1 for b in Sm if any(v in Sm[b] for v in vals[i:j]))
    return f*(500*vals[j-1]**2+2*4096*vals[j-1])
INF=float('inf');D=[[INF]*(m+1) for _ in range(K+1)];P=[[0]*(m+1) for _ in range(K+1)];D[0][0]=0
for k in range(1,K+1):
    for j in range(1,m+1):
        for i in range(j):
            v=D[k-1][i]+gc(i,j)
            if v<D[k][j]:D[k][j]=v;P[k][j]=i
k=min(range(1,K+1),key=lambda k:D[k][m]);shapes=[];j=m
while k>0: shapes.append(vals[j-1]);j=P[k][j];k-=1
print(sorted(shapes))
for b in (1,2):
    plan,mt=evalp(load(b),BS[b],sorted(shapes))
    print(b,len(BS[b]),'%.3e %.4f %.3e %.3e'%(mt['cost'],mt['pad_ratio'],mt['p95_latency_ms'],mt['sequential_timecost']))
    with open(f'output_data/plan_b{b}.jsonl','w') as f:
        for p in plan:f.write(json.dumps(p)+'\n')
