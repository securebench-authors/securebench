import json,sys
sys.path.insert(0,'scripts')
from cost_model import CostModel,align
cm=CostModel(64)
def load(b): return {x['request_id']:x for x in map(json.loads,open(f'input_data/requests_bucket_{b}.jsonl'))}
def solve(reqs,lam,key):
    R=sorted(reqs.values(),key=key); n=len(R)
    pp=[0]
    for r in R: pp.append(pp[-1]+align(r['prompt_len'],64)-r['prompt_len'])
    gs=[0]
    for r in R: gs.append(gs[-1]+r['gen_len'])
    INF=float('inf'); D=[0]+[INF]*n; P=[0]*(n+1)
    for j in range(1,n+1):
        S=G=0
        for i in range(j-1,-1,-1):
            S=max(S,align(R[i]['prompt_len'],64));G=max(G,R[i]['gen_len'])
            k=j-i
            m=cm.batch_metrics([{'prompt_len':S,'gen_len':G}]*1)  # cost per request decode+prefill approx
            dec=(m['cost']-cm._prefill_cost(S))*k
            pre=0
            c=dec+1e7+lam*(G*k-(gs[j]-gs[i]))+0
            if D[i]+c<D[j]: D[j]=D[i]+c;P[j]=i
    out=[];j=n
    while j>0: out.append(R[P[j]:j]);j=P[j]
    return out[::-1]
def evalp(reqs,batches,shapes):
    plan=[]
    for bi,b in enumerate(batches):
        S=max(align(r['prompt_len'],64) for r in b)
        s=min(x for x in shapes if x>=S)
        for r in b: plan.append({'request_id':r['request_id'],'batch_id':f'b-{bi+1:04d}','shape':{'seq_align':s,'heads_align':32,'hidden_align':4096}})
    return plan,cm.plan_metrics(reqs,plan)
if __name__=='__main__':
    res={}
    for b in (1,2):
        reqs=load(b); best=None
        for name,key in (('g',lambda r:(r['gen_len'],r['prompt_len'])),('s',lambda r:(r['prompt_len'],r['gen_len']))):
          for lam in (0,1e3,1e4,3e4,1e5,3e5,1e6,1e7):
            bs=solve(reqs,lam,key)
            Ss=sorted({max(align(r['prompt_len'],64) for r in x) for x in bs})
            res[(b,name,lam)]=bs
            _,m=evalp(reqs,bs,Ss+[10**9])  # ignoring shape cap for exploration
            print(b,name,lam,len(bs),len(Ss),'%.3e %.4f %.3e %.3e'%(m['cost'],m['pad_ratio'],m['p95_latency_ms'],m['sequential_timecost']))
