import json,sys,functools
sys.path.insert(0,'scripts')
from solve import *
@functools.lru_cache(None)
def dec(S,G):
    m=cm.batch_metrics([{'prompt_len':S,'gen_len':G}])
    return m['cost']-cm._prefill_cost(S), m['latencies'][0]-cm._prefill_lat(S)
def inner(R,mu,lam):
    # R sorted by gen; groups of equal gen
    gr=[]
    for r in R:
        if gr and gr[-1][0]==r['gen_len']: gr[-1][1].append(r)
        else: gr.append((r['gen_len'],[r]))
    n=len(gr); INF=float('inf'); D=[0]+[INF]*n; P=[0]*(n+1)
    for j in range(1,n+1):
        S=0;k=0;gsum=0
        G=gr[j-1][0]
        for i in range(j-1,-1,-1):
            for r in gr[i][1]:
                S=max(S,align(r['prompt_len'],64))
            c=len(gr[i][1]);k+=c;gsum+=c*gr[i][0]
            dc,dl=dec(S,G)
            v=D[i]+dc*k+1e7+mu*(dl+8)+lam*(G*k-gsum)
            if v<D[j]: D[j]=v;P[j]=i
    out=[];j=n
    while j>0:
        out.append([r for g in gr[P[j]:j] for r in g[1]]);j=P[j]
    return D[n],out[::-1]
def solve2(reqs,mu,lam=0):
    R=sorted(reqs.values(),key=lambda r:(r['prompt_len']))
    # group by aligned S
    ss=sorted({align(r['prompt_len'],64) for r in R}); m=len(ss)
    by={s:[r for r in R if align(r['prompt_len'],64)==s] for s in ss}
    F=[0]+[float('inf')]*m;P=[0]*(m+1);B={}
    for j in range(1,m+1):
        seg=[]
        for i in range(j-1,-1,-1):
            seg=seg+by[ss[i]]
            v,b=inner(sorted(seg,key=lambda r:r['gen_len']),mu,lam)
            if F[i]+v<F[j]:F[j]=F[i]+v;P[j]=i;B[j]=b
    out=[];j=m
    while j>0: out+=B[j];j=P[j]
    return out
def pickshapes(bs):
    Ss=sorted({max(align(r['prompt_len'],64) for r in x) for x in bs}); return Ss
if __name__=='__main__':
    b=int(sys.argv[1]);reqs=load(b)
    for mu in map(float,sys.argv[2:]):
        bs=solve2(reqs,mu);Ss=pickshapes(bs)
        _,m=evalp(reqs,bs,Ss)
        print(b,mu,len(bs),len(Ss),'%.3e %.4f %.3e %.3e'%(m['cost'],m['pad_ratio'],m['p95_latency_ms'],m['sequential_timecost']),flush=True)
