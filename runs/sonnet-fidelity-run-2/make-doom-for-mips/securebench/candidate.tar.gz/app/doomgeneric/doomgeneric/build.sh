#!/bin/sh
# Builds doomgeneric_mips (freestanding MIPS32 LE, soft-float) for vm.js
set -e
cd "$(dirname "$0")"
P=mipsel-linux-gnu
GI=/usr/lib/gcc-cross/$P/12/include
CF="-march=mips2 -EL -O2 -ffreestanding -nostdinc -isystem mylibc -isystem $GI -fno-pic -mno-abicalls -G0 -mno-branch-likely -mno-check-zero-division -msoft-float -I. -DNORMALUNIX -DLINUX -w"
mkdir -p build
for s in $(cat srcs.txt) mylibc/mylibc mylibc/rt; do $P-gcc $CF -c $s.c -o build/$(basename $s).o & done
wait
$P-ld -EL -T link.ld -o ../../doomgeneric_mips build/*.o 
