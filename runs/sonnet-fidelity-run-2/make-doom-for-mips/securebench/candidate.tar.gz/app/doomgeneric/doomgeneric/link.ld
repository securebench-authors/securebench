ENTRY(main)
SECTIONS
{
  . = 0x00400000;
  .text : { *(.text.startup) *(.text .text.*) . = ALIGN(4); }
  .rodata : { *(.rodata .rodata.* .rodata1) . = ALIGN(4); }
  .data : { *(.data .data.* .sdata .sdata.* .data.rel.ro*) . = ALIGN(4); }
  .bss : { *(.sbss .sbss.* .bss .bss.* COMMON) . = ALIGN(4); }
  /DISCARD/ : { *(.MIPS.abiflags) *(.reginfo) *(.gnu.attributes) *(.pdr) *(.comment) *(.mdebug*) }
}
