#ifndef MY_STDLIB_H
#define MY_STDLIB_H
#include <stddef.h>
#include <stdint.h>
#include <stdarg.h>
#include <limits.h>

#define NULL ((void*)0)
#define EOF (-1)
#define BUFSIZ 1024
#define SEEK_SET 0
#define SEEK_CUR 1
#define SEEK_END 2
#define RAND_MAX 32767
#define EXIT_SUCCESS 0
#define EXIT_FAILURE 1
#define O_RDONLY 0
#define O_WRONLY 1
#define O_RDWR 2
#define O_CREAT 64
#define O_TRUNC 512
#define O_APPEND 1024
#define O_BINARY 0
#define F_OK 0
#define ENOENT 2
#define EEXIST 17
#define EISDIR 21
#define ENOTDIR 20
#define EACCES 13
#define EINVAL 22
#define ERANGE 34
#define M_PI 3.14159265358979323846
#define INT_MAX_ __INT_MAX__

typedef struct _FILE { int fd; int err; int eof; int unget; int wr; } FILE;
extern FILE *stdin, *stdout, *stderr;
typedef long ssize_t;
typedef long off_t;
typedef long time_t;
typedef unsigned int mode_t;
extern int errno;

/* stdio */
int printf(const char *, ...);
int fprintf(FILE *, const char *, ...);
int sprintf(char *, const char *, ...);
int snprintf(char *, size_t, const char *, ...);
int vprintf(const char *, va_list);
int vfprintf(FILE *, const char *, va_list);
int vsnprintf(char *, size_t, const char *, va_list);
int vsprintf(char *, const char *, va_list);
int sscanf(const char *, const char *, ...);
int puts(const char *);
int putchar(int);
int fputs(const char *, FILE *);
int fputc(int, FILE *);
int putc(int, FILE *);
int fgetc(FILE *);
int getc(FILE *);
int ungetc(int, FILE *);
char *fgets(char *, int, FILE *);
FILE *fopen(const char *, const char *);
int fclose(FILE *);
size_t fread(void *, size_t, size_t, FILE *);
size_t fwrite(const void *, size_t, size_t, FILE *);
int fseek(FILE *, long, int);
long ftell(FILE *);
int fflush(FILE *);
int feof(FILE *);
int ferror(FILE *);
int remove(const char *);
int rename(const char *, const char *);
void perror(const char *);
int setvbuf(FILE *, char *, int, size_t);

/* stdlib */
void *malloc(size_t);
void *calloc(size_t, size_t);
void *realloc(void *, size_t);
void free(void *);
void exit(int) __attribute__((noreturn));
void abort(void) __attribute__((noreturn));
int atexit(void (*)(void));
int abs(int);
long labs(long);
int atoi(const char *);
long atol(const char *);
double atof(const char *);
long strtol(const char *, char **, int);
unsigned long strtoul(const char *, char **, int);
double strtod(const char *, char **);
int rand(void);
void srand(unsigned);
void qsort(void *, size_t, size_t, int (*)(const void *, const void *));
char *getenv(const char *);
int system(const char *);

/* string */
void *memcpy(void *, const void *, size_t);
void *memmove(void *, const void *, size_t);
void *memset(void *, int, size_t);
int memcmp(const void *, const void *, size_t);
void *memchr(const void *, int, size_t);
size_t strlen(const char *);
char *strcpy(char *, const char *);
char *strncpy(char *, const char *, size_t);
char *strcat(char *, const char *);
char *strncat(char *, const char *, size_t);
int strcmp(const char *, const char *);
int strncmp(const char *, const char *, size_t);
int strcasecmp(const char *, const char *);
int strncasecmp(const char *, const char *, size_t);
char *strchr(const char *, int);
char *strrchr(const char *, int);
char *strstr(const char *, const char *);
char *strdup(const char *);
char *strerror(int);

/* ctype */
int toupper(int);
int tolower(int);
int isspace(int);
int isdigit(int);
int isalpha(int);
int isalnum(int);
int isupper(int);
int islower(int);
int isprint(int);
int isxdigit(int);
int ispunct(int);

/* unistd / fcntl / sys */
int open(const char *, int, ...);
int close(int);
ssize_t read(int, void *, size_t);
ssize_t write(int, const void *, size_t);
off_t lseek(int, off_t, int);
int access(const char *, int);
int mkdir(const char *, mode_t);
int isatty(int);
int usleep(unsigned);
time_t time(time_t *);
struct stat { unsigned st_mode; long st_size; };
int stat(const char *, struct stat *);
#define S_ISDIR(m) 0
struct timeval { long tv_sec; long tv_usec; };
int gettimeofday(struct timeval *, void *);

/* math */
double fabs(double);
double floor(double);
double ceil(double);
double sqrt(double);
double sin(double);
double cos(double);
double atan(double);
double atan2(double, double);
double pow(double, double);
double fmod(double, double);

#define assert(x) ((void)0)
#endif
