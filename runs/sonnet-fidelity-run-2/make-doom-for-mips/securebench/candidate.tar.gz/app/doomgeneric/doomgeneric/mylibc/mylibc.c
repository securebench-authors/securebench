#include <my_stdlib.h>

int errno;

/* ---- syscalls (this VM's numbering) ---- */
static inline int sys3(int n, int a, int b, int c)
{
    register int v0 __asm__("$2") = n;
    register int a0 __asm__("$4") = a;
    register int a1 __asm__("$5") = b;
    register int a2 __asm__("$6") = c;
    __asm__ volatile("syscall" : "+r"(v0) : "r"(a0), "r"(a1), "r"(a2) : "memory", "$3", "$7", "$8", "$9", "$10", "$11", "$12", "$13", "$14", "$15", "$24", "$25");
    return v0;
}
ssize_t read(int fd, void *b, size_t n) { return sys3(0, fd, (int)b, n); }
ssize_t write(int fd, const void *b, size_t n) { return sys3(1, fd, (int)b, n); }
int close(int fd) { return sys3(3, fd, 0, 0); }
off_t lseek(int fd, off_t o, int w) { return sys3(8, fd, o, w); }
int open(const char *p, int fl, ...) { return sys3(2, (int)p, fl, 0644); }
time_t time(time_t *t) { time_t r = sys3(201, 0, 0, 0); if (t) *t = r; return r; }
int gettimeofday(struct timeval *tv, void *tz) { tv->tv_sec = time(0); tv->tv_usec = 0; return 0; }
int access(const char *p, int m) { int fd = open(p, O_RDONLY); if (fd < 0) return -1; close(fd); return 0; }
int mkdir(const char *p, mode_t m) { return 0; }
int isatty(int fd) { return 0; }
int usleep(unsigned u) { return 0; }
int system(const char *c) { return -1; }
char *getenv(const char *n) { return NULL; }
int stat(const char *p, struct stat *s)
{
    int fd = open(p, O_RDONLY);
    if (fd < 0) return -1;
    s->st_size = lseek(fd, 0, SEEK_END);
    s->st_mode = 0;
    close(fd);
    return 0;
}
int remove(const char *p) { return -1; }
int rename(const char *a, const char *b) { return sys3(38, (int)a, (int)b, 0); }

void exit(int c)
{
    for (;;) __asm__ volatile("break");
}
void abort(void) { exit(1); }
int atexit(void (*f)(void)) { return 0; }

/* ---- memory ---- */
void *memcpy(void *d, const void *s, size_t n)
{
    unsigned char *a = d; const unsigned char *b = s;
    if ((((uintptr_t)a | (uintptr_t)b) & 3) == 0)
    {
        while (n >= 4) { *(uint32_t *)a = *(const uint32_t *)b; a += 4; b += 4; n -= 4; }
    }
    while (n--) *a++ = *b++;
    return d;
}
void *memmove(void *d, const void *s, size_t n)
{
    unsigned char *a = d; const unsigned char *b = s;
    if (a < b) { while (n--) *a++ = *b++; }
    else { a += n; b += n; while (n--) *--a = *--b; }
    return d;
}
void *memset(void *d, int c, size_t n)
{
    unsigned char *a = d;
    uint32_t w = (unsigned char)c; w |= w << 8; w |= w << 16;
    while (n && ((uintptr_t)a & 3)) { *a++ = c; n--; }
    while (n >= 4) { *(uint32_t *)a = w; a += 4; n -= 4; }
    while (n--) *a++ = c;
    return d;
}
int memcmp(const void *x, const void *y, size_t n)
{
    const unsigned char *a = x, *b = y;
    for (; n; n--, a++, b++) if (*a != *b) return *a - *b;
    return 0;
}
void *memchr(const void *s, int c, size_t n)
{
    const unsigned char *a = s;
    for (; n; n--, a++) if (*a == (unsigned char)c) return (void *)a;
    return NULL;
}
size_t strlen(const char *s) { const char *p = s; while (*p) p++; return p - s; }
char *strcpy(char *d, const char *s) { char *r = d; while ((*d++ = *s++)); return r; }
char *strncpy(char *d, const char *s, size_t n)
{
    size_t i = 0;
    for (; i < n && s[i]; i++) d[i] = s[i];
    for (; i < n; i++) d[i] = 0;
    return d;
}
char *strcat(char *d, const char *s) { strcpy(d + strlen(d), s); return d; }
char *strncat(char *d, const char *s, size_t n)
{
    char *p = d + strlen(d);
    while (n-- && *s) *p++ = *s++;
    *p = 0;
    return d;
}
int strcmp(const char *a, const char *b)
{
    while (*a && *a == *b) { a++; b++; }
    return (unsigned char)*a - (unsigned char)*b;
}
int strncmp(const char *a, const char *b, size_t n)
{
    for (; n; n--, a++, b++)
    {
        if (*a != *b) return (unsigned char)*a - (unsigned char)*b;
        if (!*a) return 0;
    }
    return 0;
}
int toupper(int c) { return (c >= 'a' && c <= 'z') ? c - 32 : c; }
int tolower(int c) { return (c >= 'A' && c <= 'Z') ? c + 32 : c; }
int isspace(int c) { return c == ' ' || (c >= 9 && c <= 13); }
int isdigit(int c) { return c >= '0' && c <= '9'; }
int isupper(int c) { return c >= 'A' && c <= 'Z'; }
int islower(int c) { return c >= 'a' && c <= 'z'; }
int isalpha(int c) { return isupper(c) || islower(c); }
int isalnum(int c) { return isalpha(c) || isdigit(c); }
int isprint(int c) { return c >= 32 && c < 127; }
int isxdigit(int c) { return isdigit(c) || (c >= 'a' && c <= 'f') || (c >= 'A' && c <= 'F'); }
int ispunct(int c) { return isprint(c) && c != ' ' && !isalnum(c); }
int strcasecmp(const char *a, const char *b)
{
    while (*a && tolower(*a) == tolower(*b)) { a++; b++; }
    return tolower((unsigned char)*a) - tolower((unsigned char)*b);
}
int strncasecmp(const char *a, const char *b, size_t n)
{
    for (; n; n--, a++, b++)
    {
        int d = tolower((unsigned char)*a) - tolower((unsigned char)*b);
        if (d) return d;
        if (!*a) return 0;
    }
    return 0;
}
char *strchr(const char *s, int c)
{
    for (;; s++) { if (*s == (char)c) return (char *)s; if (!*s) return NULL; }
}
char *strrchr(const char *s, int c)
{
    const char *r = NULL;
    for (;; s++) { if (*s == (char)c) r = s; if (!*s) return (char *)r; }
}
char *strstr(const char *h, const char *n)
{
    size_t l = strlen(n);
    if (!l) return (char *)h;
    for (; *h; h++) if (!strncmp(h, n, l)) return (char *)h;
    return NULL;
}
char *strdup(const char *s) { size_t n = strlen(s) + 1; char *p = malloc(n); if (p) memcpy(p, s, n); return p; }
char *strerror(int e) { return "error"; }

/* ---- malloc: first-fit free list with coalescing ---- */
#define HEAP_SIZE (24 * 1024 * 1024)
static char heap[HEAP_SIZE] __attribute__((aligned(16)));
typedef struct blk { size_t size; struct blk *next; } blk; /* size includes header; next only valid when free */
#define HDR 8
static blk *freelist;
static int heap_init;

void *malloc(size_t n)
{
    if (!heap_init)
    {
        heap_init = 1;
        freelist = (blk *)heap;
        freelist->size = HEAP_SIZE;
        freelist->next = NULL;
    }
    n = (n + HDR + 7) & ~7u;
    if (n < 16) n = 16;
    blk **pp = &freelist;
    for (blk *b = freelist; b; pp = &b->next, b = b->next)
    {
        if (b->size >= n)
        {
            if (b->size >= n + 16)
            {
                blk *r = (blk *)((char *)b + n);
                r->size = b->size - n;
                r->next = b->next;
                *pp = r;
                b->size = n;
            }
            else *pp = b->next;
            return (char *)b + HDR;
        }
    }
    return NULL;
}
void free(void *p)
{
    if (!p) return;
    blk *b = (blk *)((char *)p - HDR);
    blk *prev = NULL, *cur = freelist;
    while (cur && cur < b) { prev = cur; cur = cur->next; }
    b->next = cur;
    if (prev) prev->next = b; else freelist = b;
    if (cur && (char *)b + b->size == (char *)cur) { b->size += cur->size; b->next = cur->next; }
    if (prev && (char *)prev + prev->size == (char *)b) { prev->size += b->size; prev->next = b->next; }
}
void *calloc(size_t a, size_t b)
{
    void *p = malloc(a * b);
    if (p) memset(p, 0, a * b);
    return p;
}
void *realloc(void *p, size_t n)
{
    if (!p) return malloc(n);
    size_t old = ((blk *)((char *)p - HDR))->size - HDR;
    if (old >= n) return p;
    void *q = malloc(n);
    if (!q) return NULL;
    memcpy(q, p, old);
    free(p);
    return q;
}

/* ---- stdlib misc ---- */
int abs(int x) { return x < 0 ? -x : x; }
long labs(long x) { return x < 0 ? -x : x; }
unsigned long strtoul(const char *s, char **e, int base)
{
    unsigned long v = 0;
    int neg = 0;
    while (isspace(*s)) s++;
    if (*s == '-') { neg = 1; s++; } else if (*s == '+') s++;
    if ((base == 0 || base == 16) && s[0] == '0' && (s[1] == 'x' || s[1] == 'X')) { s += 2; base = 16; }
    else if (base == 0) base = (s[0] == '0') ? 8 : 10;
    for (;; s++)
    {
        int d;
        if (isdigit(*s)) d = *s - '0';
        else if (isalpha(*s)) d = tolower(*s) - 'a' + 10;
        else break;
        if (d >= base) break;
        v = v * base + d;
    }
    if (e) *e = (char *)s;
    return neg ? -v : v;
}
long strtol(const char *s, char **e, int base) { return (long)strtoul(s, e, base); }
int atoi(const char *s) { return (int)strtol(s, NULL, 10); }
long atol(const char *s) { return strtol(s, NULL, 10); }
double strtod(const char *s, char **e)
{
    /* integer part only */
    long v = strtol(s, e, 10);
    return (double)v;
}
double atof(const char *s) { return strtod(s, NULL); }
static unsigned rnd = 1;
int rand(void) { rnd = rnd * 1103515245u + 12345u; return (rnd >> 16) & 0x7fff; }
void srand(unsigned s) { rnd = s; }
void qsort(void *base, size_t n, size_t sz, int (*cmp)(const void *, const void *))
{
    /* insertion sort via swaps; heap sort would be overkill for doom's small arrays */
    char *a = base;
    char tmp[64];
    for (size_t i = 1; i < n; i++)
    {
        size_t j = i;
        while (j > 0 && cmp(a + (j - 1) * sz, a + j * sz) > 0)
        {
            for (size_t o = 0; o < sz; o += sizeof tmp)
            {
                size_t l = sz - o < sizeof tmp ? sz - o : sizeof tmp;
                memcpy(tmp, a + j * sz + o, l);
                memcpy(a + j * sz + o, a + (j - 1) * sz + o, l);
                memcpy(a + (j - 1) * sz + o, tmp, l);
            }
            j--;
        }
    }
}

/* ---- stdio ---- */
static FILE s_in = {0}, s_out = {1}, s_err = {2};
FILE *stdin = &s_in, *stdout = &s_out, *stderr = &s_err;

FILE *fopen(const char *p, const char *m)
{
    int fl;
    int plus = strchr(m, '+') != NULL;
    if (m[0] == 'r') fl = plus ? O_RDWR : O_RDONLY;
    else if (m[0] == 'w') fl = (plus ? O_RDWR : O_WRONLY) | O_CREAT | O_TRUNC;
    else fl = O_WRONLY | O_CREAT | O_APPEND;
    int fd = open(p, fl, 0644);
    if (fd < 0) return NULL;
    FILE *f = malloc(sizeof(FILE));
    f->fd = fd; f->err = 0; f->eof = 0; f->unget = -1; f->wr = m[0] != 'r';
    return f;
}
int fclose(FILE *f) { int r = close(f->fd); if (f != stdin && f != stdout && f != stderr) free(f); return r; }
size_t fread(void *b, size_t sz, size_t n, FILE *f)
{
    size_t total = sz * n, got = 0;
    char *p = b;
    if (!total) return 0;
    if (f->unget >= 0) { *p++ = f->unget; f->unget = -1; got++; }
    while (got < total)
    {
        int r = read(f->fd, p + 0, total - got);
        if (r <= 0) { f->eof = 1; break; }
        got += r; p += r;
    }
    return got / sz;
}
size_t fwrite(const void *b, size_t sz, size_t n, FILE *f)
{
    size_t total = sz * n;
    if (!total) return 0;
    const char *p = b;
    size_t done = 0;
    while (done < total)
    {
        int r = write(f->fd, p + done, total - done);
        if (r <= 0) { f->err = 1; break; }
        done += r;
    }
    return done / sz;
}
int fseek(FILE *f, long o, int w) { f->eof = 0; f->unget = -1; return lseek(f->fd, o, w) < 0 ? -1 : 0; }
long ftell(FILE *f) { return lseek(f->fd, 0, SEEK_CUR) - (f->unget >= 0); }
int fflush(FILE *f) { return 0; }
int feof(FILE *f) { return f->eof; }
int ferror(FILE *f) { return f->err; }
int setvbuf(FILE *f, char *b, int m, size_t s) { return 0; }
int fgetc(FILE *f)
{
    unsigned char c;
    if (fread(&c, 1, 1, f) != 1) return EOF;
    return c;
}
int getc(FILE *f) { return fgetc(f); }
int ungetc(int c, FILE *f) { f->unget = c; f->eof = 0; return c; }
char *fgets(char *s, int n, FILE *f)
{
    int i = 0;
    while (i < n - 1)
    {
        int c = fgetc(f);
        if (c == EOF) break;
        s[i++] = c;
        if (c == '\n') break;
    }
    if (!i) return NULL;
    s[i] = 0;
    return s;
}
int fputc(int c, FILE *f) { unsigned char ch = c; return fwrite(&ch, 1, 1, f) == 1 ? c : EOF; }
int putc(int c, FILE *f) { return fputc(c, f); }
int putchar(int c) { return fputc(c, stdout); }
int fputs(const char *s, FILE *f) { return fwrite(s, 1, strlen(s), f) ? 0 : EOF; }
int puts(const char *s) { fputs(s, stdout); fputc('\n', stdout); return 0; }
void perror(const char *s) { fputs(s, stderr); fputs(": error\n", stderr); }

typedef struct { char *buf; size_t pos, cap; } out_t;
static void outc(out_t *o, char c) { if (o->pos + 1 < o->cap) o->buf[o->pos] = c; o->pos++; }

static void fmt_uint(out_t *o, unsigned long long v, int base, int upper, int width, int zero, int left, const char *prefix, int prec)
{
    char tmp[24]; int n = 0;
    const char *dg = upper ? "0123456789ABCDEF" : "0123456789abcdef";
    if (v == 0) tmp[n++] = '0';
    while (v) { tmp[n++] = dg[v % base]; v /= base; }
    while (n < prec) tmp[n++] = '0';
    int pl = prefix ? strlen(prefix) : 0;
    int pad = width - n - pl;
    if (!left && !zero) while (pad-- > 0) outc(o, ' ');
    for (int i = 0; i < pl; i++) outc(o, prefix[i]);
    if (!left && zero) while (pad-- > 0) outc(o, '0');
    while (n) outc(o, tmp[--n]);
    if (left) while (pad-- > 0) outc(o, ' ');
}

int vsnprintf(char *buf, size_t cap, const char *fmt, va_list ap)
{
    out_t o = { buf, 0, cap };
    for (; *fmt; fmt++)
    {
        if (*fmt != '%') { outc(&o, *fmt); continue; }
        fmt++;
        int left = 0, zero = 0, plus = 0, alt = 0, space = 0;
        for (;; fmt++)
        {
            if (*fmt == '-') left = 1;
            else if (*fmt == '0') zero = 1;
            else if (*fmt == '+') plus = 1;
            else if (*fmt == '#') alt = 1;
            else if (*fmt == ' ') space = 1;
            else break;
        }
        int width = 0, prec = -1;
        if (*fmt == '*') { width = va_arg(ap, int); if (width < 0) { left = 1; width = -width; } fmt++; }
        else while (isdigit(*fmt)) width = width * 10 + *fmt++ - '0';
        if (*fmt == '.')
        {
            fmt++; prec = 0;
            if (*fmt == '*') { prec = va_arg(ap, int); fmt++; }
            else while (isdigit(*fmt)) prec = prec * 10 + *fmt++ - '0';
        }
        int lng = 0;
        while (*fmt == 'l' || *fmt == 'h' || *fmt == 'z' || *fmt == 't' || *fmt == 'j')
        {
            if (*fmt == 'l') lng++;
            else if (*fmt == 'z' || *fmt == 'j' || *fmt == 't') lng = 1;
            fmt++;
        }
        switch (*fmt)
        {
        case 'd': case 'i':
        {
            long long v = lng >= 2 ? va_arg(ap, long long) : va_arg(ap, int);
            int neg = v < 0;
            unsigned long long u = neg ? -(unsigned long long)v : v;
            const char *pre = neg ? "-" : plus ? "+" : space ? " " : NULL;
            fmt_uint(&o, u, 10, 0, width, zero && !left && prec < 0, left, pre, prec);
            break;
        }
        case 'u': fmt_uint(&o, lng >= 2 ? va_arg(ap, unsigned long long) : va_arg(ap, unsigned), 10, 0, width, zero, left, NULL, prec); break;
        case 'x': case 'X':
        {
            unsigned long long u = lng >= 2 ? va_arg(ap, unsigned long long) : va_arg(ap, unsigned);
            fmt_uint(&o, u, 16, *fmt == 'X', width, zero, left, alt && u ? (*fmt == 'X' ? "0X" : "0x") : NULL, prec);
            break;
        }
        case 'o': fmt_uint(&o, va_arg(ap, unsigned), 8, 0, width, zero, left, NULL, prec); break;
        case 'p': fmt_uint(&o, (uintptr_t)va_arg(ap, void *), 16, 0, width, zero, left, "0x", prec); break;
        case 'c': { int pad = width - 1; if (!left) while (pad-- > 0) outc(&o, ' '); outc(&o, (char)va_arg(ap, int)); if (left) while (pad-- > 0) outc(&o, ' '); break; }
        case 's':
        {
            const char *s = va_arg(ap, const char *);
            if (!s) s = "(null)";
            int l = 0;
            while (s[l] && (prec < 0 || l < prec)) l++;
            int pad = width - l;
            if (!left) while (pad-- > 0) outc(&o, ' ');
            for (int i = 0; i < l; i++) outc(&o, s[i]);
            if (left) while (pad-- > 0) outc(&o, ' ');
            break;
        }
        case 'f': case 'g': case 'e': { double dv = va_arg(ap, double); fmt_uint(&o, (unsigned)(int)dv, 10, 0, width, zero, left, NULL, 0); break; }
        case '%': outc(&o, '%'); break;
        case 0: fmt--; break;
        default: outc(&o, '%'); outc(&o, *fmt); break;
        }
    }
    if (cap) o.buf[o.pos < cap ? o.pos : cap - 1] = 0;
    return o.pos;
}
int vsprintf(char *b, const char *f, va_list ap) { return vsnprintf(b, 1 << 30, f, ap); }
int snprintf(char *b, size_t n, const char *f, ...) { va_list ap; va_start(ap, f); int r = vsnprintf(b, n, f, ap); va_end(ap); return r; }
int sprintf(char *b, const char *f, ...) { va_list ap; va_start(ap, f); int r = vsnprintf(b, 1 << 30, f, ap); va_end(ap); return r; }
int vfprintf(FILE *fp, const char *f, va_list ap)
{
    char buf[1024];
    int r = vsnprintf(buf, sizeof buf, f, ap);
    fwrite(buf, 1, r < (int)sizeof buf ? r : (int)sizeof buf - 1, fp);
    return r;
}
int vprintf(const char *f, va_list ap) { return vfprintf(stdout, f, ap); }
int printf(const char *f, ...) { va_list ap; va_start(ap, f); int r = vfprintf(stdout, f, ap); va_end(ap); return r; }
int fprintf(FILE *fp, const char *f, ...) { va_list ap; va_start(ap, f); int r = vfprintf(fp, f, ap); va_end(ap); return r; }

/* minimal sscanf: %d %i %u %x %s %c with optional literal matching */
int sscanf(const char *s, const char *fmt, ...)
{
    va_list ap; va_start(ap, fmt);
    int n = 0;
    for (; *fmt; fmt++)
    {
        if (isspace(*fmt)) { while (isspace(*s)) s++; continue; }
        if (*fmt != '%') { if (*s != *fmt) break; s++; continue; }
        fmt++;
        int skip = 0, width = 0, lng = 0;
        if (*fmt == '*') { skip = 1; fmt++; }
        while (isdigit(*fmt)) width = width * 10 + *fmt++ - '0';
        while (*fmt == 'l' || *fmt == 'h') { lng++; fmt++; }
        if (*fmt != 'c' && *fmt != '%') while (isspace(*s)) s++;
        if (*fmt == 'd' || *fmt == 'i' || *fmt == 'u' || *fmt == 'x')
        {
            char *e;
            long v = *fmt == 'x' ? (long)strtoul(s, &e, 16) : strtol(s, &e, *fmt == 'i' ? 0 : 10);
            if (e == s) break;
            s = e;
            if (!skip) { int *p = va_arg(ap, int *); *p = v; n++; }
        }
        else if (*fmt == 's')
        {
            if (!*s) break;
            char *d = skip ? NULL : va_arg(ap, char *);
            int i = 0;
            while (*s && !isspace(*s) && (!width || i < width)) { if (d) d[i] = *s; s++; i++; }
            if (d) { d[i] = 0; n++; }
        }
        else if (*fmt == 'c')
        {
            if (!*s) break;
            if (!skip) { *va_arg(ap, char *) = *s; n++; }
            s++;
        }
        else if (*fmt == '%') { if (*s != '%') break; s++; }
        else break;
    }
    va_end(ap);
    return n;
}

/* ---- math ---- */
double fabs(double x) { union { double d; uint64_t u; } v; v.d = x; v.u &= ~(1ull << 63); return v.d; }
