/* Minimal compiler runtime: 64-bit division and the few soft-float helpers doom needs. */
#include <stdint.h>

typedef uint64_t u64;
typedef int64_t s64;
typedef uint32_t u32;

u64 __udivmoddi4(u64 n, u64 d, u64 *rem)
{
    u64 q = 0, r = 0;
    if (d == 0) { if (rem) *rem = 0; return 0; }
    int hi = 63;
    while (hi >= 0 && !((n >> hi) & 1)) hi--;
    for (int i = hi; i >= 0; i--)
    {
        r = (r << 1) | ((n >> i) & 1);
        if (r >= d) { r -= d; q |= (u64)1 << i; }
    }
    if (rem) *rem = r;
    return q;
}
u64 __udivdi3(u64 n, u64 d) { return __udivmoddi4(n, d, 0); }
u64 __umoddi3(u64 n, u64 d) { u64 r; __udivmoddi4(n, d, &r); return r; }
s64 __divdi3(s64 n, s64 d)
{
    int neg = (n < 0) ^ (d < 0);
    u64 q = __udivmoddi4(n < 0 ? -(u64)n : n, d < 0 ? -(u64)d : d, 0);
    return neg ? -(s64)q : (s64)q;
}
s64 __moddi3(s64 n, s64 d)
{
    u64 r;
    __udivmoddi4(n < 0 ? -(u64)n : n, d < 0 ? -(u64)d : d, &r);
    return n < 0 ? -(s64)r : (s64)r;
}

/* ---- single precision (float is passed as its bit pattern in a GPR) ---- */
typedef union { float f; u32 u; } fu;
static inline u32 fbits(float f) { fu x; x.f = f; return x.u; }
static inline float fromf(u32 u) { fu x; x.u = u; return x.f; }

/* unpack to sign, unbiased exponent, mantissa with hidden bit at bit 23 (normalised for non-zero) */
static int unpack(u32 b, u32 *m, int *e)
{
    *e = (b >> 23) & 0xff;
    *m = b & 0x7fffff;
    if (*e == 0)
    {
        if (!*m) return 0;
        *e = 1;
        while (!(*m & 0x800000)) { *m <<= 1; (*e)--; }
    }
    else *m |= 0x800000;
    return 1;
}
/* pack from mantissa m (any width >= 1 bit, value = m * 2^(e-127-23)) with truncation-to-nearest */
static u32 pack(u32 sign, int e, u64 m)
{
    if (!m) return sign << 31;
    int sh = 0;
    while (m >> (24 + sh)) sh++;
    /* normalise so top bit is at 23 */
    if (sh > 0)
    {
        u64 half = (u64)1 << (sh - 1);
        u64 rem = m & (((u64)1 << sh) - 1);
        m >>= sh; e += sh;
        if (rem > half || (rem == half && (m & 1))) { m++; if (m >> 24) { m >>= 1; e++; } }
    }
    else while (!(m & 0x800000)) { m <<= 1; e--; }
    if (e >= 255) return (sign << 31) | 0x7f800000;
    if (e <= 0) return sign << 31; /* flush denormals */
    return (sign << 31) | ((u32)e << 23) | (u32)(m & 0x7fffff);
}

float __mulsf3(float a, float b)
{
    u32 x = fbits(a), y = fbits(b), ma, mb; int ea, eb;
    u32 s = (x ^ y) >> 31;
    if (!unpack(x, &ma, &ea) || !unpack(y, &mb, &eb)) return fromf(s << 31);
    return fromf(pack(s, ea + eb - 127, (u64)ma * mb >> 23));
}
float __divsf3(float a, float b)
{
    u32 x = fbits(a), y = fbits(b), ma, mb; int ea, eb;
    u32 s = (x ^ y) >> 31;
    if (!unpack(y, &mb, &eb)) return fromf((s << 31) | 0x7f800000);
    if (!unpack(x, &ma, &ea)) return fromf(s << 31);
    return fromf(pack(s, ea - eb + 127, __udivdi3((u64)ma << 24, mb) >> 1));
}
static float addsf(u32 x, u32 y)
{
    u32 ma, mb; int ea, eb;
    int za = !unpack(x, &ma, &ea), zb = !unpack(y, &mb, &eb);
    if (za) return fromf(y);
    if (zb) return fromf(x);
    u32 sa = x >> 31, sb = y >> 31;
    u64 A = (u64)ma << 8, B = (u64)mb << 8;
    if (ea < eb || (ea == eb && A < B)) { u64 t = A; A = B; B = t; int te = ea; ea = eb; eb = te; u32 ts = sa; sa = sb; sb = ts; }
    int d = ea - eb;
    B = d > 40 ? 0 : B >> d;
    u64 r = (sa == sb) ? A + B : A - B;
    /* value = r * 2^(ea-127-31) ; pack expects m*2^(e-127-23) */
    return fromf(pack(r ? sa : 0, ea - 8, r));
}
float __addsf3(float a, float b) { return addsf(fbits(a), fbits(b)); }
float __subsf3(float a, float b) { return addsf(fbits(a), fbits(b) ^ 0x80000000u); }
float __floatsisf(int i)
{
    if (!i) return 0;
    u32 s = i < 0;
    return fromf(pack(s, 127 + 23, s ? -(u64)(s64)i : (u64)i));
}
int __fixsfsi(float f)
{
    u32 b = fbits(f), m; int e;
    if (!unpack(b, &m, &e)) return 0;
    e -= 127;
    if (e < 0) return 0;
    if (e > 30) return (b >> 31) ? (int)0x80000000 : 0x7fffffff;
    int v = e >= 23 ? (int)(m << (e - 23)) : (int)(m >> (23 - e));
    return (b >> 31) ? -v : v;
}

/* ---- double precision, passed as bits ---- */
typedef union { double d; u64 u; } du;
double __extendsfdf2(float f)
{
    u32 b = fbits(f), m; int e;
    du r;
    u64 s = (u64)(b >> 31) << 63;
    if (!unpack(b, &m, &e)) { r.u = s; return r.d; }
    r.u = s | ((u64)(e - 127 + 1023) << 52) | ((u64)(m & 0x7fffff) << 29);
    return r.d;
}
float __truncdfsf2(double d)
{
    du x; x.d = d;
    u32 s = x.u >> 63;
    int e = (int)((x.u >> 52) & 0x7ff);
    if (!e) return fromf(s << 31);
    u64 m = (x.u & 0xfffffffffffffull) | ((u64)1 << 52);
    return fromf(pack(s, e - 1023 + 127, m >> 29));
}
double __floatsidf(int i)
{
    du r;
    if (!i) { r.u = 0; return r.d; }
    u64 s = i < 0;
    u64 m = s ? -(u64)(s64)i : (u64)i;
    int e = 63;
    while (!(m >> 63)) { m <<= 1; e--; }
    r.u = (s << 63) | ((u64)(e + 1023) << 52) | ((m >> 11) & 0xfffffffffffffull);
    return r.d;
}
static int dcmp(double a, double b, int nan)
{
    du x, y; x.d = a; y.d = b;
    s64 p = (s64)x.u, q = (s64)y.u;
    if (p < 0) p = (s64)0x8000000000000000ull - p;
    if (q < 0) q = (s64)0x8000000000000000ull - q;
    return p < q ? -1 : p > q;
}
int __ltdf2(double a, double b) { return dcmp(a, b, 1); }
int __ledf2(double a, double b) { return dcmp(a, b, 1); }
int __gtdf2(double a, double b) { return dcmp(a, b, -1); }
int __gedf2(double a, double b) { return dcmp(a, b, -1); }
int __fixdfsi(double d)
{
    du x; x.d = d;
    int e = (int)((x.u >> 52) & 0x7ff) - 1023;
    if (e < 0) return 0;
    if (e > 30) return (x.u >> 63) ? (int)0x80000000 : 0x7fffffff;
    u64 m = (x.u & 0xfffffffffffffull) | ((u64)1 << 52);
    int v = (int)(m >> (52 - e));
    return (x.u >> 63) ? -v : v;
}
