'use strict';
// MIPS32 (little-endian) user-mode interpreter for doomgeneric_mips.
const fs = require('fs');
const path = require('path');

const ELF = process.argv[2] || path.join(__dirname, 'doomgeneric_mips');
const MEM_SIZE = 0x41000000;
const buf = new ArrayBuffer(MEM_SIZE);
const u8 = new Uint8Array(buf);
const i32 = new Int32Array(buf);
const u16 = new Uint16Array(buf);
const i16 = new Int16Array(buf);
const i8 = new Int8Array(buf);

// ---- ELF loading ----
const elf = fs.readFileSync(ELF);
const entry = elf.readUInt32LE(24);
const phoff = elf.readUInt32LE(28), phentsize = elf.readUInt16LE(42), phnum = elf.readUInt16LE(44);
for (let i = 0; i < phnum; i++) {
  const o = phoff + i * phentsize;
  if (elf.readUInt32LE(o) !== 1) continue;
  const off = elf.readUInt32LE(o + 4), va = elf.readUInt32LE(o + 8), fsz = elf.readUInt32LE(o + 16);
  elf.copy(u8, va, off, off + fsz);
}

// ---- CPU state ----
const R = new Int32Array(32);
let HI = 0, LO = 0;
const fbuf = new ArrayBuffer(128);
const FU = new Uint32Array(fbuf), FI = new Int32Array(fbuf), FS = new Float32Array(fbuf), FD = new Float64Array(fbuf);
let fcc = 0; // condition flag
R[29] = MEM_SIZE - 0x1000;
let pc = entry;

// ---- file descriptors ----
const fds = new Map(); // vm fd -> node fd
let nextFd = 3;
const frameCount = { n: 0 };

function cstr(addr) {
  let e = addr; while (u8[e]) e++;
  return Buffer.from(u8.subarray(addr, e)).toString('latin1');
}

function mapFlags(f) {
  let m = f & 3 ? (f & 3) === 1 ? fs.constants.O_WRONLY : fs.constants.O_RDWR : fs.constants.O_RDONLY;
  if (f & 0x40) m |= fs.constants.O_CREAT;
  if (f & 0x200) m |= fs.constants.O_TRUNC;
  if (f & 0x400) m |= fs.constants.O_APPEND;
  return m;
}
const errno = (e) => -(typeof e.errno === 'number' ? Math.abs(e.errno) : 5);
const filePos = new Map();
let exited = false;
const t0 = Date.now();

function syscall() {
  const n = R[2], a0 = R[4], a1 = R[5], a2 = R[6], a3 = R[7];
  // Accept both x86-64-style numbers (used by the program) and MIPS o32 numbers.
  try {
    switch (n) {
      case 0: case 4003: { // read
        if (a0 === 0) return 0;
        const nfd = fds.get(a0); if (nfd === undefined) return -9;
        const r = fs.readSync(nfd, u8, a1 >>> 0, a2 >>> 0, filePos.get(a0));
        filePos.set(a0, filePos.get(a0) + r); return r;
      }
      case 1: case 4004: { // write
        const p = a1 >>> 0, len = a2 >>> 0;
        if (a0 === 1 || a0 === 2) {
          const b = Buffer.from(u8.subarray(p, p + len));
          try { fs.writeSync(a0, b); } catch (e) {}
          return len;
        }
        const nfd = fds.get(a0); if (nfd === undefined) return -9;
        const r = fs.writeSync(nfd, u8, p, len, filePos.get(a0));
        filePos.set(a0, filePos.get(a0) + r); return r;
      }
      case 2: case 4005: { // open
        const name = cstr(a0 >>> 0);
        const nfd = fs.openSync(name, mapFlags(a1), a2 || 0o644);
        const fd = nextFd++; fds.set(fd, nfd);
        filePos.set(fd, (a1 & 0x400) ? fs.fstatSync(nfd).size : 0); return fd;
      }
      case 3: case 4006: { // close
        const nfd = fds.get(a0); if (nfd === undefined) return a0 < 3 ? 0 : -9;
        fs.closeSync(nfd); fds.delete(a0); filePos.delete(a0); return 0;
      }
      case 8: case 4019: { // lseek
        const nfd = fds.get(a0); if (nfd === undefined) return -29;
        let base = 0;
        if (a2 === 1) base = filePos.get(a0); else if (a2 === 2) base = fs.fstatSync(nfd).size;
        const np = base + a1; if (np < 0) return -22;
        filePos.set(a0, np); return np;
      }
      case 74: case 4118: return 0; // fsync
      case 82: case 4038: fs.renameSync(cstr(a0 >>> 0), cstr(a1 >>> 0)); return 0;
      case 83: case 4039: fs.mkdirSync(cstr(a0 >>> 0), { recursive: false }); return 0;
      case 87: case 4010: fs.unlinkSync(cstr(a0 >>> 0)); return 0;
      case 201: case 4013: { // time
        const t = Math.floor(Date.now() / 1000);
        if (a0) i32[a0 >>> 2] = t; return t;
      }
      case 60: case 231: case 93: case 4001: case 4246:
        exited = true; process.exitCode = a0 & 255; return 0;
      case 12: case 45: case 4045: return 0; // brk
      default:
        process.stderr.write(`unhandled syscall ${n} at pc=0x${pc.toString(16)}\n`);
        return -38;
    }
  } catch (e) { return errno(e); }
}

function load8(a) { return i8[a >>> 0]; }

function run(maxSteps) {
  let npc = pc + 4;
  for (let steps = 0; steps < maxSteps && !exited; steps++) {
    const ins = i32[pc >>> 2];
    let next = npc, target = -1;
    const op = ins >>> 26, rs = (ins >>> 21) & 31, rt = (ins >>> 16) & 31, rd = (ins >>> 11) & 31, sa = (ins >>> 6) & 31;
    const imm = (ins << 16) >> 16;
    switch (op) {
      case 0: {
        switch (ins & 63) {
          case 0: R[rd] = R[rt] << sa; break;
          case 2: R[rd] = (ins & (1 << 21)) ? (R[rt] >>> sa) | (R[rt] << (32 - sa)) : R[rt] >>> sa; break;
          case 3: R[rd] = R[rt] >> sa; break;
          case 4: R[rd] = R[rt] << (R[rs] & 31); break;
          case 6: { const s = R[rs] & 31; R[rd] = (ins & (1 << 6)) ? (R[rt] >>> s) | (R[rt] << (32 - s)) : R[rt] >>> s; break; }
          case 7: R[rd] = R[rt] >> (R[rs] & 31); break;
          case 8: target = R[rs]; break;
          case 9: { const t = R[rs]; R[rd] = pc + 8; target = t; break; }
          case 10: if (R[rt] === 0) R[rd] = R[rs]; break;
          case 11: if (R[rt] !== 0) R[rd] = R[rs]; break;
          case 12: { const r = syscall(); R[2] = r; if (r < 0 && r > -200) { /* errors returned as negative */ } break; }
          case 13: exited = true; break;
          case 15: break;
          case 16: R[rd] = HI; break;
          case 17: HI = R[rs]; break;
          case 18: R[rd] = LO; break;
          case 19: LO = R[rs]; break;
          case 24: { const p = BigInt(R[rs]) * BigInt(R[rt]); LO = Number(BigInt.asIntN(32, p)); HI = Number(BigInt.asIntN(32, p >> 32n)); break; }
          case 25: { const p = BigInt(R[rs] >>> 0) * BigInt(R[rt] >>> 0); LO = Number(BigInt.asIntN(32, p)); HI = Number(BigInt.asIntN(32, p >> 32n)); break; }
          case 26: if (R[rt] !== 0) { LO = (R[rs] / R[rt]) | 0; HI = R[rs] % R[rt] | 0; } break;
          case 27: if (R[rt] !== 0) { const a = R[rs] >>> 0, b = R[rt] >>> 0; LO = Math.floor(a / b) | 0; HI = (a % b) | 0; } break;
          case 32: case 33: R[rd] = R[rs] + R[rt]; break;
          case 34: case 35: R[rd] = R[rs] - R[rt]; break;
          case 36: R[rd] = R[rs] & R[rt]; break;
          case 37: R[rd] = R[rs] | R[rt]; break;
          case 38: R[rd] = R[rs] ^ R[rt]; break;
          case 39: R[rd] = ~(R[rs] | R[rt]); break;
          case 42: R[rd] = R[rs] < R[rt] ? 1 : 0; break;
          case 43: R[rd] = (R[rs] >>> 0) < (R[rt] >>> 0) ? 1 : 0; break;
          case 52: if (R[rs] === R[rt]) throw new Error('teq trap at 0x' + pc.toString(16)); break;
          default: throw new Error(`bad special ${ins & 63} at 0x${pc.toString(16)}`);
        }
        break;
      }
      case 1: {
        const c = R[rs];
        let take = false;
        switch (rt) { case 0: take = c < 0; break; case 1: take = c >= 0; break;
          case 16: R[31] = pc + 8; take = c < 0; break; case 17: R[31] = pc + 8; take = c >= 0; break;
          default: throw new Error('bad regimm'); }
        if (take) target = pc + 4 + (imm << 2);
        break;
      }
      case 2: target = ((pc + 4) & 0xF0000000) | ((ins & 0x3FFFFFF) << 2); break;
      case 3: R[31] = pc + 8; target = ((pc + 4) & 0xF0000000) | ((ins & 0x3FFFFFF) << 2); break;
      case 4: if (R[rs] === R[rt]) target = pc + 4 + (imm << 2); break;
      case 5: if (R[rs] !== R[rt]) target = pc + 4 + (imm << 2); break;
      case 6: if (R[rs] <= 0) target = pc + 4 + (imm << 2); break;
      case 7: if (R[rs] > 0) target = pc + 4 + (imm << 2); break;
      case 8: case 9: R[rt] = R[rs] + imm; break;
      case 10: R[rt] = R[rs] < imm ? 1 : 0; break;
      case 11: R[rt] = (R[rs] >>> 0) < (imm >>> 0) ? 1 : 0; break;
      case 12: R[rt] = R[rs] & (ins & 0xFFFF); break;
      case 13: R[rt] = R[rs] | (ins & 0xFFFF); break;
      case 14: R[rt] = R[rs] ^ (ins & 0xFFFF); break;
      case 15: R[rt] = ins << 16; break;
      case 17: { // COP1
        const fmt = rs, fd = sa, fsr = rd, ft = rt, fn = ins & 63;
        if (fmt === 0) R[rt] = FI[fsr];
        else if (fmt === 2) R[rt] = 0;
        else if (fmt === 3) R[rt] = FI[fsr + 1];
        else if (fmt === 4) FI[fsr] = R[rt];
        else if (fmt === 7) FI[fsr + 1] = R[rt];
        else if (fmt === 6) { /* ctc1 */ }
        else if (fmt === 8) { const tf = (ins >>> 16) & 1; if ((fcc ? 1 : 0) === tf) target = pc + 4 + (imm << 2); }
        else if (fmt === 16 || fmt === 17 || fmt === 20) {
          const d = fmt === 17, A = d ? FD : FS, fi = d ? fsr >> 1 : fsr, ti = d ? ft >> 1 : ft, di = d ? fd >> 1 : fd;
          switch (fn) {
            case 0: A[di] = A[fi] + A[ti]; break;
            case 1: A[di] = A[fi] - A[ti]; break;
            case 2: A[di] = A[fi] * A[ti]; break;
            case 3: A[di] = A[fi] / A[ti]; break;
            case 4: A[di] = Math.sqrt(A[fi]); break;
            case 5: A[di] = Math.abs(A[fi]); break;
            case 6: if (d) { FU[fd] = FU[fsr]; FU[fd + 1] = FU[fsr + 1]; } else FU[fd] = FU[fsr]; break;
            case 7: A[di] = -A[fi]; break;
            case 13: if (fmt === 16 || fmt === 17) FI[fd] = Math.trunc(A[fi]) | 0; break; // trunc.w
            case 17: { const tf = (ins >>> 16) & 1; if ((fcc ? 1 : 0) === tf) { if (d) { FU[fd] = FU[fsr]; FU[fd + 1] = FU[fsr + 1]; } else FU[fd] = FU[fsr]; } break; }
            case 32: if (fmt === 17) FS[fd] = FD[fsr >> 1]; else if (fmt === 20) FS[fd] = FI[fsr]; break; // cvt.s
            case 33: if (fmt === 16) FD[fd >> 1] = FS[fsr]; else if (fmt === 20) FD[fd >> 1] = FI[fsr]; break; // cvt.d
            case 36: FI[fd] = Math.round(A[fi]) | 0; break;
            default:
              if (fn >= 48) {
                const a = A[fi], b = A[ti]; const c = fn & 15; let r = false;
                const un = a !== a || b !== b;
                if (c & 1 && un) r = true;
                if (c & 2 && a === b) r = true;
                if (c & 4 && a < b) r = true;
                fcc = r ? 1 : 0;
              } else throw new Error('bad fpu fn ' + fn + ' at 0x' + pc.toString(16));
          }
        } else throw new Error('bad cop1 fmt ' + fmt);
        break;
      }
      case 28: { // SPECIAL2
        const f = ins & 63;
        if (f === 2) R[rd] = Math.imul(R[rs], R[rt]);
        else if (f === 32) R[rd] = Math.clz32(R[rs]);
        else if (f === 33) R[rd] = Math.clz32(~R[rs]);
        else throw new Error('bad special2 ' + f);
        break;
      }
      case 31: { // SPECIAL3
        const f = ins & 63;
        if (f === 0) { const size = rd + 1, pos = sa; R[rt] = size === 32 ? R[rs] : (R[rs] >>> pos) & ((1 << size) - 1); }
        else if (f === 4) { const msb = rd, lsb = sa, size = msb - lsb + 1; const m = size === 32 ? -1 : ((1 << size) - 1); R[rt] = (R[rt] & ~(m << lsb)) | ((R[rs] & m) << lsb); }
        else if (f === 32) {
          if (sa === 16) R[rd] = (R[rt] << 24) >> 24;
          else if (sa === 24) R[rd] = (R[rt] << 16) >> 16;
          else if (sa === 2) { const v = R[rt]; R[rd] = ((v & 0xFF00FF00) >>> 8) | ((v & 0x00FF00FF) << 8); }
          else throw new Error('bad bshfl');
        } else if (f === 59) R[rt] = 0;
        else throw new Error('bad special3 ' + f);
        break;
      }
      case 32: R[rt] = i8[(R[rs] + imm) >>> 0]; break;
      case 33: R[rt] = i16[(R[rs] + imm) >>> 1]; break;
      case 34: { const a = (R[rs] + imm) >>> 0, sh = (a & 3) * 8; const w = i32[a >>> 2]; R[rt] = sh === 24 ? w : (R[rt] & ((1 << (24 - sh)) - 1)) | (w << (24 - sh)); break; }
      case 35: R[rt] = i32[(R[rs] + imm) >>> 2]; break;
      case 36: R[rt] = u8[(R[rs] + imm) >>> 0]; break;
      case 37: R[rt] = u16[(R[rs] + imm) >>> 1]; break;
      case 38: { const a = (R[rs] + imm) >>> 0, sh = (a & 3) * 8; const w = i32[a >>> 2]; R[rt] = sh === 0 ? w : (R[rt] & (0xFFFFFFFF << (32 - sh))) | (w >>> sh); break; }
      case 40: u8[(R[rs] + imm) >>> 0] = R[rt]; break;
      case 41: u16[(R[rs] + imm) >>> 1] = R[rt]; break;
      case 42: { const a = (R[rs] + imm) >>> 0, sh = (a & 3) * 8; const w = i32[a >>> 2]; const keep = sh === 24 ? 0 : (0xFFFFFFFF << (sh + 8)); i32[a >>> 2] = (w & keep) | (R[rt] >>> (24 - sh)); break; }
      case 43: i32[(R[rs] + imm) >>> 2] = R[rt]; break;
      case 46: { const a = (R[rs] + imm) >>> 0, sh = (a & 3) * 8; const w = i32[a >>> 2]; i32[a >>> 2] = sh === 0 ? R[rt] : (w & (0xFFFFFFFF >>> (32 - sh))) | (R[rt] << sh); break; }
      case 48: R[rt] = i32[(R[rs] + imm) >>> 2]; break; // ll
      case 56: i32[(R[rs] + imm) >>> 2] = R[rt]; R[rt] = 1; break; // sc
      case 49: FI[rt] = i32[(R[rs] + imm) >>> 2]; break;
      case 53: { const a = ((R[rs] + imm) >>> 2); FI[rt] = i32[a]; FI[rt + 1] = i32[a + 1]; break; }
      case 57: i32[(R[rs] + imm) >>> 2] = FI[rt]; break;
      case 61: { const a = ((R[rs] + imm) >>> 2); i32[a] = FI[rt]; i32[a + 1] = FI[rt + 1]; break; }
      case 51: break; // pref
      default: throw new Error(`bad opcode ${op} at 0x${pc.toString(16)}`);
    }
    R[0] = 0;
    pc = npc;
    npc = target !== -1 ? target : npc + 4;
  }
}

process.on('exit', () => {});
try {
  while (!exited) run(5000000);
} catch (e) {
  console.error(e.message, 'pc=0x' + pc.toString(16));
  process.exitCode = 1;
}
