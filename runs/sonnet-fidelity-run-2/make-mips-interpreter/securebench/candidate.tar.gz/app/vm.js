'use strict';
// MIPS32 (little-endian, o32) interpreter that runs doomgeneric_mips.
const fs = require('fs');
const path = require('path');

const ELF = process.argv[2] || path.join(__dirname, 'doomgeneric_mips');
const MEM_SIZE = 0x40700000; // covers .bss/heap (up to 0x404b1790) plus stack
const mem = new Uint8Array(MEM_SIZE);
const m32 = new Int32Array(mem.buffer);
const m16 = new Uint16Array(mem.buffer);

// ---- ELF loading ----
const elf = fs.readFileSync(ELF);
if (elf.readUInt32BE(0) !== 0x7f454c46) throw new Error('not an ELF file');
const entry = elf.readUInt32LE(24);
const phoff = elf.readUInt32LE(28);
const phentsize = elf.readUInt16LE(42);
const phnum = elf.readUInt16LE(44);
for (let i = 0; i < phnum; i++) {
  const o = phoff + i * phentsize;
  if (elf.readUInt32LE(o) !== 1) continue; // PT_LOAD
  const off = elf.readUInt32LE(o + 4), va = elf.readUInt32LE(o + 8), fsz = elf.readUInt32LE(o + 16);
  elf.copy(mem, va, off, off + fsz);
}

// ---- registers ----
const r = new Int32Array(32);
let hi = 0, lo = 0;
const fbuf = new ArrayBuffer(128);
const fi = new Int32Array(fbuf), ff = new Float32Array(fbuf), fd = new Float64Array(fbuf);
let fcc = 0; // condition code bit 0
r[29] = 0x406ffff0; // sp
r[28] = 0;
let pc = entry, npc = entry + 4;

// ---- syscalls (x86-64 style numbers as used by the guest's libc) ----
const files = new Map(); // guest fd -> {fd, pos, append}
files.set(0, { fd: 0, std: true }); files.set(1, { fd: 1, std: true }); files.set(2, { fd: 2, std: true });
let nextFd = 3;
const startTime = Date.now();
const cstr = (a) => { let e = a >>> 0; while (mem[e]) e++; return Buffer.from(mem.buffer, a >>> 0, e - (a >>> 0)).toString('latin1'); };
const errno = (e) => -(typeof e.errno === 'number' ? Math.abs(e.errno) : 5);

function syscall() {
  const n = r[2], a0 = r[4], a1 = r[5], a2 = r[6], a3 = r[7];
  try {
    switch (n) {
      case 0: { // read
        const f = files.get(a0); if (!f) return -9;
        const buf = Buffer.from(mem.buffer, a1 >>> 0, a2 >>> 0);
        if (f.std) { try { return fs.readSync(f.fd, buf, 0, buf.length, null); } catch (e) { return 0; } }
        const got = fs.readSync(f.fd, buf, 0, buf.length, f.pos);
        f.pos += got; return got;
      }
      case 1: { // write
        const f = files.get(a0); if (!f) return -9;
        const buf = Buffer.from(mem.buffer, a1 >>> 0, a2 >>> 0);
        if (f.std) { try { return fs.writeSync(f.fd, buf); } catch (e) { return a2; } }
        if (f.append) f.pos = fs.fstatSync(f.fd).size;
        const w = fs.writeSync(f.fd, buf, 0, buf.length, f.pos);
        f.pos += w; return w;
      }
      case 2: { // open
        const p = cstr(a0);
        const fdn = fs.openSync(p, a1 & 0x7ff, a2 || 0o644);
        const g = nextFd++;
        files.set(g, { fd: fdn, pos: 0, append: !!(a1 & 1024) });
        return g;
      }
      case 3: { // close
        const f = files.get(a0); if (!f) return -9;
        if (!f.std) { fs.closeSync(f.fd); files.delete(a0); }
        return 0;
      }
      case 8: { // lseek
        const f = files.get(a0); if (!f || f.std) return -29;
        let np;
        if (a2 === 0) np = a1; else if (a2 === 1) np = f.pos + a1; else np = fs.fstatSync(f.fd).size + a1;
        if (np < 0) return -22;
        f.pos = np; return np;
      }
      case 74: { const f = files.get(a0); if (f && !f.std) fs.fsyncSync(f.fd); return 0; }
      case 82: fs.renameSync(cstr(a0), cstr(a1)); return 0;
      case 83: fs.mkdirSync(cstr(a0), a1); return 0;
      case 87: fs.unlinkSync(cstr(a0)); return 0;
      case 60: process.exit(a0);
      case 201: { // time
        const t = Math.floor(Date.now() / 1000);
        if (a0) m32[a0 >>> 2] = t;
        return t;
      }
      case 96: { // gettimeofday
        const now = Date.now();
        if (a0) { m32[a0 >>> 2] = Math.floor(now / 1000); m32[(a0 >>> 2) + 1] = (now % 1000) * 1000; }
        return 0;
      }
      case 35: return 0; // nanosleep
      default:
        process.stderr.write(`unhandled syscall ${n}\n`);
        return -38;
    }
  } catch (e) {
    if (e.code === 'ENOENT') return -2;
    if (e.code === 'EEXIST') return -17;
    if (e.code === 'EACCES') return -13;
    return errno(e);
  }
}

function mulu(a, b) { // 64-bit unsigned product
  const p = BigInt(a >>> 0) * BigInt(b >>> 0);
  lo = Number(p & 0xffffffffn) | 0; hi = Number((p >> 32n) & 0xffffffffn) | 0;
}
function muls(a, b) {
  const p = BigInt(a) * BigInt(b);
  lo = Number(BigInt.asIntN(32, p)); hi = Number(BigInt.asIntN(32, p >> 32n));
}

function fpu(ins) {
  const fmt = (ins >>> 21) & 31, ft = (ins >>> 16) & 31, fs_ = (ins >>> 11) & 31, fdr = (ins >>> 6) & 31;
  const fn = ins & 63;
  switch (fmt) {
    case 0: r[ft] = fi[fs_]; return;                 // mfc1
    case 2: r[ft] = fi[fs_]; return;                 // cfc1 (unused)
    case 3: r[ft] = fi[fs_ | 1]; return;             // mfhc1
    case 4: fi[fs_] = r[ft]; return;                 // mtc1
    case 6: return;                                  // ctc1
    case 7: fi[fs_ | 1] = r[ft]; return;             // mthc1
    case 8: {                                        // bc1f/bc1t
      const tf = (ins >>> 16) & 1;
      const off = (ins << 16) >> 16;
      if ((fcc & 1) === tf) pendingBranch = (pc + (off << 2)) >>> 0; // pc already = delay slot addr
      return;
    }
    case 16: case 17: case 20: {
      const d = fmt === 17;
      const get = (x) => d ? fd[x >> 1] : ff[x];
      const set = (x, v) => { if (d) fd[x >> 1] = v; else ff[x] = v; };
      if (fn >= 48) { // c.cond
        const a = get(fs_), b = get(ft);
        const un = a !== a || b !== b;
        const c = fn & 15;
        let res = false;
        if ((c & 1) && un) res = true;
        if ((c & 2) && !un && a === b) res = true;
        if ((c & 4) && !un && a < b) res = true;
        fcc = res ? 1 : 0; return;
      }
      switch (fn) {
        case 0: set(fdr, get(fs_) + get(ft)); return;
        case 1: set(fdr, get(fs_) - get(ft)); return;
        case 2: set(fdr, get(fs_) * get(ft)); return;
        case 3: set(fdr, get(fs_) / get(ft)); return;
        case 4: set(fdr, Math.sqrt(get(fs_))); return;
        case 5: set(fdr, Math.abs(get(fs_))); return;
        case 6: if (d) fd[fdr >> 1] = fd[fs_ >> 1]; else fi[fdr] = fi[fs_]; return;
        case 7: set(fdr, -get(fs_)); return;
        case 9: case 13: fi[fdr] = Math.trunc(get(fs_)) | 0; return; // trunc.l unsupported / trunc.w
        case 8: case 12: fi[fdr] = Math.round(get(fs_)) | 0; return;
        case 10: fi[fdr] = Math.ceil(get(fs_)) | 0; return;
        case 11: fi[fdr] = Math.floor(get(fs_)) | 0; return;
        case 17: { // movf/movt
          const tf = (ins >>> 16) & 1;
          if ((fcc & 1) === tf) { if (d) fd[fdr >> 1] = fd[fs_ >> 1]; else fi[fdr] = fi[fs_]; }
          return;
        }
        case 18: if (r[ft] === 0) { if (d) fd[fdr >> 1] = fd[fs_ >> 1]; else fi[fdr] = fi[fs_]; } return;
        case 19: if (r[ft] !== 0) { if (d) fd[fdr >> 1] = fd[fs_ >> 1]; else fi[fdr] = fi[fs_]; } return;
        case 32: ff[fdr] = get(fs_); return;        // cvt.s
        case 33: fd[fdr >> 1] = get(fs_); return;   // cvt.d
        case 36: fi[fdr] = Math.round(get(fs_)) | 0; return; // cvt.w
      }
      break;
    }
    case 20 + 0: break;
  }
  throw new Error(`unimplemented FPU ins ${(ins >>> 0).toString(16)} at ${(pc - 4).toString(16)}`);
}
let pendingBranch = -1;
function fpuW(ins) { // fmt W (20): cvt.s.w / cvt.d.w
  const fs_ = (ins >>> 11) & 31, fdr = (ins >>> 6) & 31, fn = ins & 63;
  if (fn === 32) { ff[fdr] = fi[fs_]; return; }
  if (fn === 33) { fd[fdr >> 1] = fi[fs_]; return; }
  throw new Error(`unimplemented FPU W ins ${(ins >>> 0).toString(16)}`);
}

function run() {
  let count = 0;
  for (;;) {
    const ins = m32[pc >>> 2];
    const cur = pc;
    pc = npc; npc = (npc + 4) | 0;
    const op = ins >>> 26;
    const rs = (ins >>> 21) & 31, rt = (ins >>> 16) & 31, rd = (ins >>> 11) & 31, sh = (ins >>> 6) & 31;
    const imm = (ins << 16) >> 16;
    switch (op) {
      case 0: {
        switch (ins & 63) {
          case 0: r[rd] = r[rt] << sh; break;
          case 2: r[rd] = rs === 1 ? (r[rt] >>> sh) | (r[rt] << (32 - sh)) : r[rt] >>> sh; break; // srl / rotr
          case 3: r[rd] = r[rt] >> sh; break;
          case 4: r[rd] = r[rt] << (r[rs] & 31); break;
          case 6: { const s = r[rs] & 31; r[rd] = sh & 1 ? (r[rt] >>> s) | (r[rt] << (32 - s)) : r[rt] >>> s; break; }
          case 7: r[rd] = r[rt] >> (r[rs] & 31); break;
          case 8: npc = r[rs]; break;
          case 9: { const t = r[rs]; r[rd] = cur + 8; npc = t; break; }
          case 10: if (r[rt] === 0) r[rd] = r[rs]; break;
          case 11: if (r[rt] !== 0) r[rd] = r[rs]; break;
          case 12: r[2] = syscall(); r[7] = 0; break;
          case 13: throw new Error('break at ' + cur.toString(16));
          case 15: break; // sync
          case 16: r[rd] = hi; break;
          case 17: hi = r[rs]; break;
          case 18: r[rd] = lo; break;
          case 19: lo = r[rs]; break;
          case 24: muls(r[rs], r[rt]); break;
          case 25: mulu(r[rs], r[rt]); break;
          case 26: if (r[rt] !== 0) { lo = (r[rs] / r[rt]) | 0; hi = r[rs] % r[rt] | 0; } break;
          case 27: if (r[rt] !== 0) { const a = r[rs] >>> 0, b = r[rt] >>> 0; lo = Math.floor(a / b) | 0; hi = (a % b) | 0; } break;
          case 32: case 33: r[rd] = r[rs] + r[rt]; break;
          case 34: case 35: r[rd] = r[rs] - r[rt]; break;
          case 36: r[rd] = r[rs] & r[rt]; break;
          case 37: r[rd] = r[rs] | r[rt]; break;
          case 38: r[rd] = r[rs] ^ r[rt]; break;
          case 39: r[rd] = ~(r[rs] | r[rt]); break;
          case 42: r[rd] = r[rs] < r[rt] ? 1 : 0; break;
          case 43: r[rd] = (r[rs] >>> 0) < (r[rt] >>> 0) ? 1 : 0; break;
          case 52: if (r[rs] === r[rt]) throw new Error('trap (teq) at ' + cur.toString(16)); break;
          default: throw new Error(`bad SPECIAL ${(ins >>> 0).toString(16)} at ${cur.toString(16)}`);
        }
        break;
      }
      case 1: {
        const v = r[rs];
        let take;
        switch (rt) {
          case 0: take = v < 0; break;
          case 1: take = v >= 0; break;
          case 16: take = v < 0; r[31] = cur + 8; break;
          case 17: take = v >= 0; r[31] = cur + 8; break;
          default: throw new Error('bad REGIMM at ' + cur.toString(16));
        }
        if (take) npc = pc + (imm << 2);
        break;
      }
      case 2: npc = ((pc & 0xf0000000) | ((ins & 0x3ffffff) << 2)) | 0; break;
      case 3: r[31] = cur + 8; npc = ((pc & 0xf0000000) | ((ins & 0x3ffffff) << 2)) | 0; break;
      case 4: if (r[rs] === r[rt]) npc = pc + (imm << 2); break;
      case 5: if (r[rs] !== r[rt]) npc = pc + (imm << 2); break;
      case 6: if (r[rs] <= 0) npc = pc + (imm << 2); break;
      case 7: if (r[rs] > 0) npc = pc + (imm << 2); break;
      case 8: case 9: r[rt] = r[rs] + imm; break;
      case 10: r[rt] = r[rs] < imm ? 1 : 0; break;
      case 11: r[rt] = (r[rs] >>> 0) < (imm >>> 0) ? 1 : 0; break;
      case 12: r[rt] = r[rs] & (ins & 0xffff); break;
      case 13: r[rt] = r[rs] | (ins & 0xffff); break;
      case 14: r[rt] = r[rs] ^ (ins & 0xffff); break;
      case 15: r[rt] = ins << 16; break;
      case 16: { // COP0: not needed
        throw new Error('COP0 at ' + cur.toString(16));
      }
      case 17: {
        if (((ins >>> 21) & 31) === 20) fpuW(ins);
        else {
          pendingBranch = -1;
          fpu(ins);
          if (pendingBranch !== -1) npc = pendingBranch | 0;
        }
        break;
      }
      case 28: { // SPECIAL2
        switch (ins & 63) {
          case 2: r[rd] = Math.imul(r[rs], r[rt]); break;
          case 32: r[rd] = Math.clz32(r[rs]); break;
          case 33: r[rd] = Math.clz32(~r[rs]); break;
          case 0: { const p = BigInt(r[rs]) * BigInt(r[rt]) + ((BigInt(hi) << 32n) | BigInt(lo >>> 0)); lo = Number(BigInt.asIntN(32, p)); hi = Number(BigInt.asIntN(32, p >> 32n)); break; }
          default: throw new Error(`bad SPECIAL2 ${(ins >>> 0).toString(16)} at ${cur.toString(16)}`);
        }
        break;
      }
      case 31: { // SPECIAL3
        switch (ins & 63) {
          case 0: { // ext: rd=msbd, sh=lsb
            const size = rd + 1;
            r[rt] = size === 32 ? r[rs] : (r[rs] >>> sh) & ((1 << size) - 1);
            break;
          }
          case 4: { // ins: rd=msb, sh=lsb
            const size = rd - sh + 1;
            const mask = size === 32 ? -1 : ((1 << size) - 1) << sh;
            r[rt] = (r[rt] & ~mask) | ((r[rs] << sh) & mask);
            break;
          }
          case 32: {
            if (sh === 16) r[rd] = (r[rt] << 24) >> 24;
            else if (sh === 24) r[rd] = (r[rt] << 16) >> 16;
            else if (sh === 2) { const v = r[rt]; r[rd] = ((v & 0x00ff00ff) << 8) | ((v >>> 8) & 0x00ff00ff); }
            else throw new Error('bad BSHFL');
            break;
          }
          case 59: r[rd] = 0; break; // rdhwr
          default: throw new Error(`bad SPECIAL3 ${(ins >>> 0).toString(16)} at ${cur.toString(16)}`);
        }
        break;
      }
      case 32: r[rt] = (mem[(r[rs] + imm) >>> 0] << 24) >> 24; break;
      case 33: r[rt] = (m16[(r[rs] + imm) >>> 1] << 16) >> 16; break;
      case 34: { // lwl
        const a = (r[rs] + imm) >>> 0, k = a & 3, w = m32[a >>> 2];
        const sft = (3 - k) * 8;
        r[rt] = k === 3 ? w : (w << sft) | (r[rt] & ((1 << sft) - 1));
        break;
      }
      case 35: r[rt] = m32[(r[rs] + imm) >>> 2]; break;
      case 36: r[rt] = mem[(r[rs] + imm) >>> 0]; break;
      case 37: r[rt] = m16[(r[rs] + imm) >>> 1]; break;
      case 38: { // lwr
        const a = (r[rs] + imm) >>> 0, k = a & 3, w = m32[a >>> 2];
        r[rt] = k === 0 ? w : (w >>> (k * 8)) | (r[rt] & ~(-1 >>> (k * 8)));
        break;
      }
      case 40: mem[(r[rs] + imm) >>> 0] = r[rt]; break;
      case 41: m16[(r[rs] + imm) >>> 1] = r[rt]; break;
      case 42: { // swl
        const a = (r[rs] + imm) >>> 0, k = a & 3, i = a >>> 2, w = m32[i];
        if (k === 3) m32[i] = r[rt];
        else { const sft = (3 - k) * 8; const keep = ~(-1 >>> sft); m32[i] = (w & keep) | (r[rt] >>> sft); }
        break;
      }
      case 43: m32[(r[rs] + imm) >>> 2] = r[rt]; break;
      case 46: { // swr
        const a = (r[rs] + imm) >>> 0, k = a & 3, i = a >>> 2, w = m32[i];
        if (k === 0) m32[i] = r[rt];
        else { const sft = k * 8; m32[i] = (w & ((1 << sft) - 1)) | (r[rt] << sft); }
        break;
      }
      case 47: break; // cache
      case 48: r[rt] = m32[(r[rs] + imm) >>> 2]; break; // ll
      case 49: fi[rt] = m32[(r[rs] + imm) >>> 2]; break; // lwc1
      case 51: break; // pref
      case 53: { const a = (r[rs] + imm) >>> 2; fi[rt] = m32[a]; fi[rt | 1] = m32[a + 1]; break; } // ldc1
      case 56: m32[(r[rs] + imm) >>> 2] = r[rt]; r[rt] = 1; break; // sc
      case 57: m32[(r[rs] + imm) >>> 2] = fi[rt]; break; // swc1
      case 61: { const a = (r[rs] + imm) >>> 2; m32[a] = fi[rt]; m32[a + 1] = fi[rt | 1]; break; } // sdc1
      default: throw new Error(`bad opcode ${op} (${(ins >>> 0).toString(16)}) at ${cur.toString(16)}`);
    }
    r[0] = 0;
  }
}

try { run(); } catch (e) {
  console.error(e.message);
  process.exit(1);
}
