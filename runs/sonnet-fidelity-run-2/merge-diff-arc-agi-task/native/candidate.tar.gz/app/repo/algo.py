def map(g):
    rows = len(g)
    cols = len(g[0]) if rows else 0
    d = {}
    for i in range(rows):
        for j in range(cols):
            if g[i][j] != 0:
                d.setdefault((i + j) % 3, g[i][j])
    return [[d.get((i + j) % 3, 0) for j in range(cols)] for i in range(rows)]
