def map(g):
    num_rows = len(g)
    num_cols = len(g[0]) if num_rows else 0
    d = {}
    for i in range(num_rows):
        for j in range(num_cols):
            c = g[i][j]
            if c != 0:
                d[(i + j) % 3] = c
    return [[d.get((i + j) % 3, 0) for j in range(num_cols)] for i in range(num_rows)]
