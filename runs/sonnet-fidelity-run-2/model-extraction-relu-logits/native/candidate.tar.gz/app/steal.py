import numpy as np
from forward import forward

rng = np.random.default_rng(1)
D = 10

def grad(x, h=1e-6):
    f0 = forward(x)
    g = np.empty(D)
    for i in range(D):
        e = np.zeros(D); e[i] = h
        g[i] = (forward(x + e) - f0) / h
    return g

rows = []
def add(v):
    n = np.linalg.norm(v)
    if n < 1e-4:
        return
    v = v / n
    for r in rows:
        if abs(abs(r @ v) - 1) < 1e-3:
            return
    rows.append(v)

T = np.linspace(-4, 4, 801)
sp = T[1] - T[0]
for _ in range(60):
    x0 = rng.standard_normal(D); d = rng.standard_normal(D); d /= np.linalg.norm(d)
    f = lambda t: forward(x0 + t * d)
    y = np.array([f(t) for t in T])
    s = np.diff(y) / sp
    for i in range(1, len(s) - 1):
        if abs(s[i] - s[i - 1]) < 1e-7 and abs(s[i] - s[i + 1]) < 1e-7:
            continue
        if abs(s[i + 1] - s[i - 1]) < 1e-7 and abs(s[i]-s[i-1])<1e-7:
            continue
        # kink within segment i (T[i],T[i+1]) given neighbours linear on each side
        a, b = T[i], T[i + 1]
        h = sp / 20
        s1 = (f(a) - f(a - h)) / h
        s2 = (f(b + h) - f(b)) / h
        if abs(s1 - s2) < 1e-7:
            continue
        # intersect lines
        fa, fb = f(a), f(b)
        t = (fb - fa + s1 * a - s2 * b) / (s1 - s2)
        if not (a - 1e-9 <= t <= b + 1e-9):
            continue
        if abs(f(t - h/2) - (fa + s1 * (t - h/2 - a))) > 1e-9 or abs(f(t + h/2) - (fb + s2 * (t + h/2 - b))) > 1e-9:
            continue
        e = 1e-3
        gl = grad(x0 + (t - e) * d); gr = grad(x0 + (t + e) * d)
        add(gr - gl)
A = np.array(rows)
np.save('/app/stolen_A1.npy', A)
print(A.shape)
