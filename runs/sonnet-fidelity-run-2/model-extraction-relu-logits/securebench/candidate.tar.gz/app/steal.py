import numpy as np
from forward import forward

rng = np.random.default_rng(1)
D = 10
f = lambda x: forward(x)

def kinks(p, d, lo=-4.0, hi=4.0, n=400):
    ts = np.linspace(lo, hi, n + 1)
    ys = np.array([f(p + t * d) for t in ts])
    out = []
    for i in range(1, n):
        s1 = (ys[i] - ys[i-1]) / (ts[i] - ts[i-1])
        s2 = (ys[i+1] - ys[i]) / (ts[i+1] - ts[i])
        if abs(s2 - s1) > 1e-7:
            out.append((ts[i-1], ts[i+1]))
    # refine by bisection on slope change using the outer slopes
    res = []
    for a, b in out:
        h = (b - a) / 2
        # lines through the points on each side
        sa = (f(p + (a - 0) * d) - f(p + (a - h/50) * d)) / (h/50)
        sb = (f(p + (b + h/50) * d) - f(p + b * d)) / (h/50)
        if abs(sa - sb) < 1e-7:
            continue
        lo_, hi_ = a, b
        for _ in range(60):
            m = (lo_ + hi_) / 2
            e = 1e-9
            sm = (f(p + (m + e) * d) - f(p + m * d)) / e
            if abs(sm - sa) < abs(sm - sb):
                lo_ = m
            else:
                hi_ = m
        res.append((lo_ + hi_) / 2)
    return res

def grad(x, h=1e-6):
    g = np.zeros(D)
    for j in range(D):
        e = np.zeros(D); e[j] = h
        g[j] = (f(x + e) - f(x - e)) / (2 * h)
    return g

rows = []
for it in range(300):
    p = rng.normal(size=D)
    d = rng.normal(size=D); d /= np.linalg.norm(d)
    ks = kinks(p, d)
    for k in ks:
        # skip if neighbouring kinks are too close
        if any(abs(k - k2) < 1e-2 for k2 in ks if k2 != k):
            continue
        eps = 1e-3
        gl = grad(p + (k - eps) * d)
        gr = grad(p + (k + eps) * d)
        j = gr - gl
        nj = np.linalg.norm(j)
        if nj < 1e-6:
            continue
        j /= nj
        if j[np.argmax(abs(j))] < 0:
            j = -j
        for r in rows:
            if abs(r[0] @ j) > 1 - 1e-6:
                r[1].append(j); break
        else:
            rows.append([j, [j]])

mx = max(len(r[1]) for r in rows)
A = np.array([np.mean(r[1], axis=0) for r in rows if len(r[1]) >= max(3, 0.2 * mx)])
A /= np.linalg.norm(A, axis=1, keepdims=True)
np.save('/app/stolen_A1.npy', A)
print(A.shape)
