#!/usr/bin/env python3
"""Modernized climate data analysis script."""

import configparser
from pathlib import Path

import pandas as pd

BASE_DIR = Path(__file__).resolve().parent / "climate_analyzer"
DATA_PATH = BASE_DIR / "sample_data" / "climate_data.csv"
CONFIG_PATH = BASE_DIR / "config.ini"


def load_config(path: Path) -> configparser.ConfigParser:
    config = configparser.ConfigParser()
    config.read(path, encoding="utf-8")
    return config


def load_temperature_data(path: Path) -> pd.DataFrame:
    return pd.read_csv(path, encoding="utf-8", parse_dates=["date"])


def main() -> None:
    load_config(CONFIG_PATH)
    data = load_temperature_data(DATA_PATH)
    for station_id, mean_temp in data.groupby("station_id")["temperature"].mean().items():
        print(f"Station {station_id} mean temperature: {mean_temp:.1f}°C")


if __name__ == "__main__":
    main()
