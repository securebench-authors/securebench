import mteb, numpy as np
m=mteb.get_model("BAAI/bge-small-zh-v1.5",revision="7999e1d3359715c523056ef9478215996d62a620")
L=open('data.txt').read().split('\n')
L=[l for l in L if l.strip()]
d=np.array(m.encode(L,task_name="STS12",normalize_embeddings=True));q=np.array(m.encode(["terminal-bench"],task_name="STS12",normalize_embeddings=True))[0]
s=d@q;i=np.argsort(-s)[4];print(s[np.argsort(-s)[:6]]);open('result.txt','w').write(L[i]+'\n');print(L[i])
