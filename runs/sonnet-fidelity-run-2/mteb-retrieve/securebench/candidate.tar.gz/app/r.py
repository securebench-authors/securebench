import mteb, numpy as np
m = mteb.get_model("BAAI/bge-small-zh-v1.5", revision="7999e1d3359715c523056ef9478215996d62a620")
docs=[l.rstrip("\n") for l in open("data.txt") if l.strip()]
d=np.array(m.encode(docs,task_name="STS22")); q=np.array(m.encode(["terminal-bench"],task_name="STS22"))[0]
s=d@q/(np.linalg.norm(d,axis=1)*np.linalg.norm(q))
i=np.argsort(-s)[4]; print(s[np.argsort(-s)[:6]]); open("result.txt","w").write(docs[i]+"\n"); print(docs[i])
