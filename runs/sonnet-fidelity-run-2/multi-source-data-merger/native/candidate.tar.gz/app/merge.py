import json,pandas as pd
M={'id':'user_id','userId':'user_id','email_address':'email','full_name':'name','userName':'name','registration_date':'created_date','created_at':'created_date','joined':'created_date'}
def norm(r):
    o={}
    for k,v in r.items():
        if pd.isna(v) if not isinstance(v,(list,dict)) else False: continue
        k=M.get(k,k)
        if k in('active','is_active'):
            if isinstance(v,str): v=v.lower()=='true'
            o['status']='active' if v else 'inactive'; continue
        if k=='user_id': v=int(v)
        elif k=='created_date': v=pd.to_datetime(v).strftime('%Y-%m-%d')
        elif k in('name','email','status'): v=str(v).strip()
        o[k]=v
    return o
a=[norm(r) for r in json.load(open('/data/source_a/users.json'))]
b=[norm(r) for r in pd.read_csv('/data/source_b/users.csv').to_dict('records')]
c=[norm(r) for r in pd.read_parquet('/data/source_c/users.parquet').to_dict('records')]
S={'source_a':{r['user_id']:r for r in a},'source_b':{r['user_id']:r for r in b},'source_c':{r['user_id']:r for r in c}}
ids=sorted(set().union(*S.values()))
rows=[];conf=[]
F=['name','email','created_date','status']
for i in ids:
    row={'user_id':i}
    for f in F:
        vals={s:S[s][i][f] for s in S if i in S[s] and f in S[s][i]}
        if not vals: row[f]=None;continue
        sel=vals[next(s for s in S if s in vals)]
        row[f]=sel
        if len(set(vals.values()))>1: conf.append({'user_id':i,'field':f,'values':vals,'selected':sel})
    rows.append(row)
df=pd.DataFrame(rows,columns=['user_id']+F);df['user_id']=df.user_id.astype('int64')
df.to_parquet('merged_users.parquet',index=False)
json.dump({'total_conflicts':len(conf),'conflicts':conf},open('conflicts.json','w'),indent=2)
print(df,len(conf))
