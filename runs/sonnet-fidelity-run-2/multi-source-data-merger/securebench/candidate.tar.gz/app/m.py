import pandas as pd, json
A=json.load(open('/data/source_a/users.json'))
B=pd.read_csv('/data/source_b/users.csv',dtype=str).to_dict('records')
C=pd.read_parquet('/data/source_c/users.parquet').to_dict('records')
M={'user_id':['user_id','id','userId'],'email':['email','email_address'],'name':['full_name','name','userName'],'created_date':['registration_date','created_at','joined']}
def st(v):
    if isinstance(v,str) and v.strip().lower() in('true','false'): v=v.strip().lower()=='true'
    return ('active' if v else 'inactive') if isinstance(v,(bool,)) or hasattr(v,'dtype') else v
def norm(r):
    o={}
    for k,al in M.items():
        for a in al:
            if a in r and pd.notna(r[a]): o[k]=r[a];break
    o['user_id']=int(o['user_id'])
    if 'created_date' in o: o['created_date']=pd.to_datetime(o['created_date']).strftime('%Y-%m-%d')
    for a in('status','is_active','active'):
        if a in r and pd.notna(r[a]): o['status']=st(r[a]);break
    return o
S={'source_a':A,'source_b':B,'source_c':C}
by={}
for s,rs in S.items():
    for r in rs: by.setdefault(norm(r)['user_id'],{})[s]=norm(r)
rows=[];conf=[]
for uid in sorted(by):
    d=by[uid];row={'user_id':uid}
    for f in['name','email','created_date','status']:
        vals={s:d[s][f] for s in S if s in d and f in d[s]}
        if not vals: continue
        sel=vals[next(iter(vals))];row[f]=sel
        if len(set(vals.values()))>1: conf.append({'user_id':uid,'field':f,'values':vals,'selected':sel})
    rows.append(row)
pd.DataFrame(rows,columns=['user_id','name','email','created_date','status']).astype({'user_id':'int64'}).to_parquet('merged_users.parquet',index=False)
json.dump({'total_conflicts':len(conf),'conflicts':conf},open('conflicts.json','w'),indent=2)
