import subprocess
import sys
from datetime import datetime

CERT = "/app/ssl/server.crt"


def openssl(*args):
    return subprocess.check_output(["openssl", "x509", "-in", CERT, "-noout", *args], text=True).strip()


def main():
    try:
        subject = openssl("-subject").split("=", 1)[1].strip()
        end = openssl("-enddate").split("=", 1)[1]
    except (subprocess.CalledProcessError, FileNotFoundError, IndexError) as e:
        print(f"Certificate verification failed: {e}")
        return 1
    expiry = datetime.strptime(" ".join(end.split()[:4]), "%b %d %H:%M:%S %Y")
    cn = next((p.split("=", 1)[1].strip() for p in subject.split(",") if p.strip().startswith("CN")), None)
    if cn is None:
        cn = subject.split("CN")[-1].lstrip(" =").split(",")[0].strip()
    print(f"Subject: {subject}")
    print(f"Common Name: {cn}")
    print(f"Expiration Date: {expiry:%Y-%m-%d}")
    print("Certificate verification successful")
    return 0


if __name__ == "__main__":
    sys.exit(main())
