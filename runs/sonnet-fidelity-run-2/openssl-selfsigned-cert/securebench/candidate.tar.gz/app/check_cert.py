#!/usr/bin/env python3
import os
import re
import subprocess
import sys
from datetime import datetime

CERT = "/app/ssl/server.crt"


def openssl_x509(*args):
    return subprocess.run(
        ["openssl", "x509", "-in", CERT, "-noout", *args],
        check=True, capture_output=True, text=True,
    ).stdout.strip()


def main():
    if not os.path.isfile(CERT):
        print(f"Certificate not found: {CERT}")
        return 1
    try:
        subject = openssl_x509("-subject").split("=", 1)[1].strip()
        end = openssl_x509("-enddate").split("=", 1)[1].strip()
    except subprocess.CalledProcessError as e:
        print(f"Failed to load certificate: {e.stderr}")
        return 1

    cn = re.search(r"CN\s*=\s*([^,/]+)", subject)
    expiry = datetime.strptime(re.sub(r"\s+", " ", end), "%b %d %H:%M:%S %Y GMT")

    print(f"Subject: {subject}")
    print(f"Common Name: {cn.group(1).strip() if cn else 'N/A'}")
    print(f"Expiration Date: {expiry.strftime('%Y-%m-%d')}")

    if not cn or cn.group(1).strip() != "dev-internal.company.local":
        print("Common Name mismatch")
        return 1
    print("Certificate verification successful")
    return 0


if __name__ == "__main__":
    sys.exit(main())
