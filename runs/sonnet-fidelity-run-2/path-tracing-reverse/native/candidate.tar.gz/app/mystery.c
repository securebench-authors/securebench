#include <stdio.h>
#include <math.h>
typedef float F;
typedef struct{F t,p[3],n[3];int h;}H;
static F L[3];
static void nrm(F*v){F l=sqrtf(v[0]*v[0]+v[1]*v[1]+v[2]*v[2]);v[0]/=l;v[1]/=l;v[2]/=l;}
static H sph(F*o,F*d){
 H r={0};F c[3]={0,-.5f,-5},R=1;
 F a=d[0]*d[0]+d[1]*d[1]+d[2]*d[2];
 F e[3]={o[0]-c[0],o[1]-c[1],o[2]-c[2]};
 F b=2*(e[0]*d[0]+e[1]*d[1]+e[2]*d[2]);
 F k=e[0]*e[0]+e[1]*e[1]+e[2]*e[2]-R*R;
 F D=b*b-k*(4*a);
 if(D<0)return r;
 double s=sqrt((double)D),nb=(double)-b,a2=(double)(2*a);
 F t=(F)((nb-s)/a2);
 if(t<.001f){t=(F)((nb+s)/a2);if(t<.001f)return r;}
 r.t=t;
 for(int i=0;i<3;i++){r.p[i]=o[i]+d[i]*t;r.n[i]=r.p[i]-c[i];}
 nrm(r.n);r.h=1;return r;
}
int main(){
 enum{W=800,Hh=600};
 static F im[Hh][W][3];
 fprintf(stderr,"Creating high-resolution image: %dx%d\n",W,Hh);
 fwrite("This will be downsampled with ffmpeg after rendering\n",1,53,stderr);
 L[0]=1;L[1]=1;L[2]=-1;nrm(L);
 fwrite("Rendering high-resolution image...\n",1,35,stderr);
 for(int y=0;y<Hh;y++){
  fprintf(stderr,"Progress: %.1f%%",(double)(100*(F)y/600));
  F v=1-(F)y/599,p=0*v,v2=2*v;
  for(int x=0;x<W;x++){
   F u=(F)x/799,z0=0*u;
   F d[3]={u*2.6666667f+p-1.3333334f,z0+v2-1,p+z0-1};
   nrm(d);
   F o[3]={0,0,0};
   H h=sph(o,d);
   F col[3],br,n[3],P[3];int pl=0,sp=0,sky=0;
   F tp=0;
   if(fabsf(d[1])<.0001f){if(h.h)sp=1;else sky=1;}
   else{
    tp=-1.5f/d[1];
    if(tp<.001f){if(h.h)sp=1;else sky=1;}
    else if(h.h&&h.t<tp)sp=1;
    else pl=1;
   }
   if(sky){
    F s=(d[1]+1)*.5f,m=1-s;
    col[0]=s*.5f+m;col[1]=s*.7f+m;col[2]=s+m;
   }else{
    if(sp){for(int i=0;i<3;i++){n[i]=h.n[i];P[i]=h.p[i]+n[i]*.001f;}}
    else{P[0]=d[0]*tp+0;P[1]=d[1]*tp+0;P[2]=d[2]*tp+0;n[0]=0;n[1]=1;n[2]=0;P[1]+=.001f;
     F t=P[1]-.001f;(void)t;}
    F ld[3]={L[0],L[1],L[2]};nrm(ld);
    H s=sph(P,ld);
    if(s.h)br=.2f;
    else{
     F dt=n[0]*L[0]+n[1]*L[1]+n[2]*L[2];
     br=(F)fmax((double)dt,0.)*.8f+.2f;
    }
    if(sp){col[0]=br;col[1]=col[2]=.2f*br;}
    else{
     F a=P[0]-0,b=P[2];
     (void)a;(void)b;
     F fx=floorf(d[0]*tp),fz=floorf(d[2]*tp);
     int c=(int)((double)fx+(double)fz);
     F g=(c&1)?.4f:.9f;
     col[0]=col[1]=col[2]=g*br;
    }
   }
   for(int i=0;i<3;i++)for(int j=0;j<1;j++)im[y][x][i]=col[i];
  }
 }
 fwrite("\nRendering complete\n",1,20,stderr);
 FILE*f=fopen("image.ppm","w");
 if(!f){fprintf(stderr,"Error: Could not open file %s for writing\n","image.ppm");}
 else{
  fprintf(f,"P3\n%d %d\n255\n",W,Hh);
  for(int y=0;y<Hh;y++)for(int x=0;x<W;x++){
   int c[3];
   for(int i=0;i<3;i++){double q=fmin(fmax((double)im[y][x][i],0.),1.);c[i]=(int)((F)q*255.99f);}
   fprintf(f,"%d %d %d\n",c[0],c[1],c[2]);
  }
  fclose(f);
  fprintf(stderr,"Wrote image to %s\n","image.ppm");
 }
 fwrite("Done.\n",1,6,stderr);
 return 0;
}
