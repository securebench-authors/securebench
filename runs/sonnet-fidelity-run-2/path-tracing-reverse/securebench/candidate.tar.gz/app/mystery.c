#include <stdio.h>
#include <math.h>
typedef struct{float t,p[3],n[3];int h;}H;
static H hit(float*o,float*d){
 H r={0};float c[3]={0,-.5f,-5};
 float a=d[0]*d[0]+d[1]*d[1]+d[2]*d[2];
 float x=o[0]-c[0],y=o[1]-c[1],z=o[2]-c[2];
 float b=2*(x*d[0]+y*d[1]+z*d[2]);
 float cc=y*y+x*x+z*z-1;
 float disc=b*b-4*a*cc;
 if(disc<0)return r;
 double s=sqrt((double)disc),nb=-b;
 float a2=a+a,t=(float)((nb-s)/a2);
 if(t<.001f){t=(float)((nb+s)/a2);if(t<.001f)return r;}
 r.t=t;
 float q[3];
 for(int i=0;i<3;i++){r.p[i]=d[i]*t+o[i];q[i]=r.p[i]-c[i];}
 float l=sqrtf(q[0]*q[0]+q[1]*q[1]+q[2]*q[2]);
 for(int i=0;i<3;i++)r.n[i]=q[i]/l;
 r.h=1;return r;
}
int main(){
 int W=800,Hh=600;
 static float im[600][800][3];
 fprintf(stderr,"Creating high-resolution image: %dx%d\n",W,Hh);
 fprintf(stderr,"This will be downsampled with ffmpeg after rendering\n");
 float l0=sqrtf(1*1+1*1+1);
 float L[3]={1/l0,1/l0,-1/l0};
 fprintf(stderr,"Rendering high-resolution image...\n");
 for(int j=0;j<Hh;j++){
  fprintf(stderr,"\rProgress: %.1f%%",(double)(100.0f*(float)j/600.0f));
  float v=(float)j/599.0f;
  for(int i=0;i<W;i++){
   float u=(float)i/799.0f;
   float x=u*(8.0f/3)-(4.0f/3),y=(1-v)*2-1,z=-1;
   float ln=sqrtf(x*x+y*y+z*z);
   float d[3]={x/ln,y/ln,z/ln},o[3]={0,0,0};
   H s=hit(o,d);
   float tp=0,*px=0;int pl=0;
   if(!(fabsf(d[1])<1e-4f)){tp=-1.5f/d[1];if(!(tp<.001f))pl=1;}
   int sph=s.h&&!(pl&&!(tp>s.t));
   float*out=im[j][i],r,g,bl;
   if(!pl&&!sph){
    float t=(d[1]+1)*.5f;
    out[0]=t*.5f+(1-t);out[1]=t*.7f+(1-t);out[2]=t+(1-t);continue;
   }
   float P[3],n[3];
   if(sph){for(int k=0;k<3;k++){P[k]=s.p[k];n[k]=s.n[k];}}
   else{for(int k=0;k<3;k++)P[k]=d[k]*tp+0;n[0]=0;n[1]=1;n[2]=0;}
   float so[3];
   for(int k=0;k<3;k++)so[k]=n[k]*.001f+P[k];
   float m=sqrtf(L[0]*L[0]+L[1]*L[1]+L[2]*L[2]);
   float sd[3]={L[0]/m,L[1]/m,L[2]/m};
   H sh=hit(so,sd);
   float shade=.2f;
   if(!sh.h){
    float dt=n[0]*L[0]+n[1]*L[1]+n[2]*L[2];
    if(sph)dt=n[2]*L[2]+(n[0]*L[0]+n[1]*L[1]);
    shade=(float)fmax(dt,0.0)*.8f+.2f;
   }
   if(sph){out[0]=shade;out[1]=out[2]=.2f*shade;}
   else{
    float a=floorf(P[2]),bb=floorf(P[0]);
    int k=(int)((double)bb+(double)a);
    float c=(k&1)?.4f:.9f;
    out[0]=out[1]=out[2]=c*shade;
   }
  }
 }
 fprintf(stderr,"\nRendering complete\n");
 FILE*f=fopen("image.ppm","w");
 fprintf(f,"P3\n%d %d\n255\n",W,Hh);
 for(int j=0;j<Hh;j++)for(int i=0;i<W;i++){
  int c[3];
  for(int k=0;k<3;k++){double v=fmin(fmax((double)im[j][i][k],0.0),1.0);c[k]=(int)((float)v*255.99f);}
  fprintf(f,"%d %d %d\n",c[0],c[1],c[2]);
 }
 fclose(f);
 fprintf(stderr,"Wrote image to %s\n","image.ppm");
 fprintf(stderr,"Done.\n");
 return 0;
}
