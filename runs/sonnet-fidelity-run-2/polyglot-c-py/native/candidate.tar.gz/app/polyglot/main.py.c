#if 0
"""
#endif
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char **argv) {
    if (argc < 2) return 1;
    int n = atoi(argv[1]);
    unsigned long long a = 0, b = 1;
    for (int i = 0; i < n; i++) {
        unsigned long long t = a + b;
        a = b;
        b = t;
    }
    printf("%llu\n", a);
    return 0;
}
#if 0
"""
#endif
#if 0
import sys
a, b = 0, 1
for _ in range(int(sys.argv[1])):
    a, b = b, a + b
print(a)
#endif
