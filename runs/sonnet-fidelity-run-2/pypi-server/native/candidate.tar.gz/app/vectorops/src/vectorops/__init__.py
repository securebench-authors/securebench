__version__ = "0.1.0"


def dotproduct(a, b):
    """Return the dot product of two equal-length lists of numbers."""
    if len(a) != len(b):
        raise ValueError("lists must have the same length")
    return sum(x * y for x, y in zip(a, b))


__all__ = ["dotproduct"]
