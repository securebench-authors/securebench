#include <cstdio>
#include <vector>
#include <string>
#include "lodepng.h"
extern "C" {
#include "cJSON.h"
}
static std::vector<float> get(cJSON* r, const char* k) {
  std::vector<float> v;
  cJSON* a = cJSON_GetObjectItem(r, k);
  cJSON* e;
  cJSON_ArrayForEach(e, a) v.push_back((float)e->valuedouble);
  return v;
}
static std::vector<float> lin(const std::vector<float>& x, const std::vector<float>& W, const std::vector<float>& b, bool relu) {
  size_t o = b.size(), n = x.size();
  std::vector<float> y(o);
  for (size_t i = 0; i < o; i++) {
    float s = b[i];
    for (size_t j = 0; j < n; j++) s += W[i * n + j] * x[j];
    y[i] = (relu && s < 0) ? 0 : s;
  }
  return y;
}
int main(int argc, char** argv) {
  if (argc < 3) { fprintf(stderr, "usage: %s weights.json image.png\n", argv[0]); return 1; }
  std::vector<unsigned char> img;
  unsigned w, h;
  if (lodepng::decode(img, w, h, argv[2], LCT_GREY, 8)) { fprintf(stderr, "png error\n"); return 1; }
  if (w * h != 784) { fprintf(stderr, "expected 28x28 image\n"); return 1; }
  std::string txt; { FILE* f = fopen(argv[1], "rb"); if (!f) return 1; char buf[65536]; size_t n; while ((n = fread(buf, 1, sizeof buf, f))) txt.append(buf, n); fclose(f); }
  cJSON* r = cJSON_Parse(txt.c_str());
  if (!r) { fprintf(stderr, "json error\n"); return 1; }
  std::vector<float> x(784);
  for (int i = 0; i < 784; i++) x[i] = img[i] / 255.0f;
  x = lin(x, get(r, "input_layer.weight"), get(r, "input_layer.bias"), true);
  x = lin(x, get(r, "hidden_layer.weight"), get(r, "hidden_layer.bias"), true);
  x = lin(x, get(r, "output_layer.weight"), get(r, "output_layer.bias"), false);
  int best = 0;
  for (int i = 1; i < 10; i++) if (x[i] > x[best]) best = i;
  printf("%d\n", best);
  return 0;
}
