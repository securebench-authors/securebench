import torch,torch.nn as nn
class PE(nn.Module):
    def __init__(s):
        super().__init__(); s.register_buffer('pe',torch.zeros(1,5000,128))
    def forward(s,x): return x+s.pe[:,:x.size(1)]
class RecoveredModel(nn.Module):
    def __init__(s):
        super().__init__()
        s.embedding=nn.Linear(64,128); s.pos_encoder=PE()
        s.transformer_encoder=nn.TransformerEncoder(nn.TransformerEncoderLayer(128,8,256,batch_first=True),3)
        s.transformer_decoder=nn.TransformerDecoder(nn.TransformerDecoderLayer(128,8,256,batch_first=True),1)
        s.output_layer=nn.Linear(128,64)
    def forward(s,src,tgt):
        m=s.transformer_encoder(s.pos_encoder(s.embedding(src)))
        return s.output_layer(s.transformer_decoder(s.pos_encoder(s.embedding(tgt)),m))
w=torch.load('weights.pt'); d=torch.load('dataset.pt')
m=RecoveredModel(); m.load_state_dict(w); m.eval()
S,T=d['src_sequences'],d['tgt_sequences']
f=nn.functional.mse_loss
with torch.no_grad(): print('orig',f(m(S,T),T).item())
for n,p in m.named_parameters(): p.requires_grad='output_layer' in n
o=torch.optim.Adam(m.output_layer.parameters(),1e-3)
for i in range(300):
    o.zero_grad(); l=f(m(S,T),T); l.backward(); o.step()
with torch.no_grad(): print('new',f(m(S,T),T).item())
torch.jit.script(m).save('model.pt')
r=torch.jit.load('model.pt'); sd=r.state_dict()
print([k for k in w if not torch.equal(w[k],sd[k])])
