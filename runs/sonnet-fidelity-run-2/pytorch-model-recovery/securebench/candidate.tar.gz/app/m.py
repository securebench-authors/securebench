import torch,torch.nn as nn
class PE(nn.Module):
    def __init__(s):
        super().__init__(); s.register_buffer('pe',torch.zeros(1,5000,128))
    def forward(s,x): return x+s.pe[:,:x.size(1)]
class RecoveredModel(nn.Module):
    def __init__(s):
        super().__init__()
        s.embedding=nn.Linear(64,128); s.pos_encoder=PE()
        s.transformer_encoder=nn.TransformerEncoder(nn.TransformerEncoderLayer(128,4,256,0.0,batch_first=True),3)
        s.transformer_decoder=nn.TransformerDecoder(nn.TransformerDecoderLayer(128,4,256,0.0,batch_first=True),1)
        s.output_layer=nn.Linear(128,64)
    def forward(s,src,tgt):
        m=s.transformer_encoder(s.pos_encoder(s.embedding(src)))
        return s.output_layer(s.transformer_decoder(s.pos_encoder(s.embedding(tgt)),m))
