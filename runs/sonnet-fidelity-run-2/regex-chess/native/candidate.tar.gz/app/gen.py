import json, itertools
R=[]
def idx(r,c): return 9*r+c
files='abcdefgh'
for d in range(8,0,-1):
    R.append([f"{d}(?=[^ ]* w )", "."*d])
R.append([r"^(\S+) w (\S+) (\S+) .*$", r"G\1|\2|\3"])
for n in range(1,5):
    for sub in itertools.combinations(range(4),n):
        s=''.join("KQkq"[i] for i in sub)
        R.append([r"\|"+s+r"\|", "|"+''.join("KQkq"[i] if i in sub else '_' for i in range(4))+"|"])
R.append([r"\|-\|", "|____|"])
R.append([r"\|-$", "|--"])

def gen(edits, flag='D', slotreq='....', ep='..', newep='--'):
    pat="(?m)^G"; rep=""; g=0; prev=0
    for i in sorted(edits):
        m,n=edits[i]
        gap=i-prev
        if gap>0:
            g+=1; pat+=f"(.{{{gap}}})"; rep+=f"\\g<{g}>"
        pat+=m; rep+=n; prev=i+1
    gap=71-prev
    if gap>0:
        g+=1; pat+=f"(.{{{gap}}})"; rep+=f"\\g<{g}>"
    g+=1
    pat+=r"\|("+slotreq+r")\|"+ep
    rep=f"\\g<0>\n{flag}"+rep+f"|\\g<{g}>|"+newep
    R.append([pat,rep])

TGT='[pnbrq.]'
ORTH=[(1,0),(-1,0),(0,1),(0,-1)]
DIAG=[(1,1),(1,-1),(-1,1),(-1,-1)]
def rays(dirs, piece):
    for r in range(8):
        for c in range(8):
            for dr,dc in dirs:
                path=[]
                rr,cc=r+dr,c+dc
                while 0<=rr<8 and 0<=cc<8:
                    e={idx(r,c):(piece,'.')}
                    for (pr,pc) in path: e[idx(pr,pc)]=(r'\.','.')
                    e[idx(rr,cc)]=(TGT,piece)
                    gen(e)
                    path.append((rr,cc)); rr+=dr; cc+=dc
rays(ORTH,'R'); rays(DIAG,'B'); rays(ORTH+DIAG,'Q')
KN=[(1,2),(2,1),(-1,2),(-2,1),(1,-2),(2,-1),(-1,-2),(-2,-1)]
for r in range(8):
    for c in range(8):
        for dr,dc in KN:
            if 0<=r+dr<8 and 0<=c+dc<8:
                gen({idx(r,c):('N','.'),idx(r+dr,c+dc):(TGT,'N')})
        for dr,dc in ORTH+DIAG:
            if 0<=r+dr<8 and 0<=c+dc<8:
                gen({idx(r,c):('K','.'),idx(r+dr,c+dc):(TGT,'K')})
for c in range(8):
    for r in range(1,7):
        new='Q' if r==1 else 'P'
        gen({idx(r,c):('P','.'),idx(r-1,c):(r'\.',new)})
        for dc in (-1,1):
            if 0<=c+dc<8:
                gen({idx(r,c):('P','.'),idx(r-1,c+dc):('[pnbrq]',new)})
    gen({idx(6,c):('P','.'),idx(5,c):(r'\.','.'),idx(4,c):(r'\.','P')},newep=files[c]+'3')
    for dc in (-1,1):
        if 0<=c+dc<8:
            gen({idx(3,c+dc):('P','.'),idx(2,c):(r'\.','P'),idx(3,c):('p','.')},ep=files[c]+'6')
gen({67:('K','K'),68:(r'\.','.'),69:(r'\.','.'),70:('R','R')},flag='E',slotreq='K...')
gen({63:('R','R'),64:(r'\.','.'),65:(r'\.','.'),66:(r'\.','.'),67:('K','K')},flag='H',slotreq='.Q..')

def filt():
    for r in range(8):
        for c in range(8):
            s=idx(r,c); alts=[]
            def alt(e):
                p=""; prev=0
                for i in sorted(e):
                    if i>prev: p+=f".{{{i-prev}}}"
                    p+=e[i]; prev=i+1
                alts.append(p)
            for dirs,cls in ((ORTH,'[qr]'),(DIAG,'[qb]')):
                for dr,dc in dirs:
                    path=[]; rr,cc=r+dr,c+dc
                    while 0<=rr<8 and 0<=cc<8:
                        e={s:'K',idx(rr,cc):cls}
                        for (pr,pc) in path: e[idx(pr,pc)]=r'\.'
                        alt(e); path.append((rr,cc)); rr+=dr; cc+=dc
            for dr,dc in KN:
                if 0<=r+dr<8 and 0<=c+dc<8: alt({s:'K',idx(r+dr,c+dc):'n'})
            for dr,dc in ORTH+DIAG:
                if 0<=r+dr<8 and 0<=c+dc<8: alt({s:'K',idx(r+dr,c+dc):'k'})
            for dc in (-1,1):
                if r>0 and 0<=c+dc<8: alt({s:'K',idx(r-1,c+dc):'p'})
            R.append(["(?m)^[DEFHI](?=(?:"+"|".join(alts)+"))","X"])
filt()
R.append([r"(?m)^E(.{67})K\.", r"F\1.K"])
R.append([r"(?m)^H(.{66})\.K", r"I\1K."])
filt()
R.append([r"(?m)^F(.{67})\.K\.R", r"D\1.RK."])
R.append([r"(?m)^I(.{63})R\.\.K\.", r"D\1..KR."])
filt()
R+= [
 [r"(?m)^(D.{70})([^R])\|K", r"\1\2|_"],
 [r"(?m)^(D.{63})([^R])(.{7}\|.)Q", r"\1\2\3_"],
 [r"(?m)^(D.{67})([^K])(.{3}\|)..", r"\1\2\3__"],
 [r"(?m)^(D.{7})([^r])(.{63}\|..)k", r"\1\2\3_"],
 [r"(?m)^(D)([^r])(.{70}\|...)q", r"\1\2\3_"],
 [r"(?m)^(D.{4})([^k])(.{66}\|..)..", r"\1\2\3__"],
]
R.append([r"(?m)^[GX][^\n]*(\n|$)",""])
R.append([r"\n\Z",""])
R.append([r"(?m)^D(.{71})\|(....)\|(..)$", r"\1 b \2 \3 0 0"])
for d in range(8,0,-1):
    R.append([r"\.{%d}"%d, str(d)])
R.append(["--","-"]); R.append([" ____ "," - "]); R.append(["_",""])
json.dump(R,open("re.json","w"))
print(len(R))
