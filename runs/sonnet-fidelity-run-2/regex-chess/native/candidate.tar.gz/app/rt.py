import random, chess, json, re
R=json.load(open('/app/re.json'))
def run(fen):
    for p,r in R: fen=re.sub(p,r,fen)
    return set(" ".join(x.split(" ")[:-2]) for x in fen.split("\n")) if fen else set()
def exp(b):
    s=set()
    for m in b.legal_moves:
        if m.promotion and m.promotion!=chess.QUEEN: continue
        c=b.copy(); c.push(m); s.add(" ".join(c.fen().split(" ")[:-2]))
    return s
random.seed(1); n=0; bad=0
for g in range(150):
    b=chess.Board()
    for ply in range(150):
        if b.is_game_over(): break
        if b.turn:
            o=run(b.fen()); e=exp(b); n+=1
            o2={x for x in o if x in e or x.rpartition(" ")[0]+" -" in e}
            if len(o)!=len(e) or o2!=o:
                bad+=1; print(b.fen(), len(o),len(e), list(o-e)[:2], list(e-o)[:2])
                if bad>5: raise SystemExit
        mv=list(b.legal_moves)
        # bias toward captures/castle/promo
        pri=[m for m in mv if b.is_capture(m) or b.is_castling(m) or m.promotion]
        b.push(random.choice(pri) if pri and random.random()<.4 else random.choice(mv))
print(n,bad)
