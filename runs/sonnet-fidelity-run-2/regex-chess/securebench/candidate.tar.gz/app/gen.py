import json

def idx(r, c): return 9 * r + c
def inb(r, c): return 0 <= r < 8 and 0 <= c < 8
ROOK = [(-1,0),(1,0),(0,-1),(0,1)]
BISH = [(-1,-1),(-1,1),(1,-1),(1,1)]
KN = [(-2,-1),(-2,1),(2,-1),(2,1),(-1,-2),(-1,2),(1,-2),(1,2)]
KG = ROOK + BISH
ANYT = '[.pnbrqk]'
CAPT = '[pnbrqk]'
pairs = []

def add(p, r): pairs.append([p, r])

def gen(min_, mout, specials, cast='[KQkq-]+', ep='[a-h-]', newep='-'):
    # specials: (idx, regex, name|None, out)
    specials = sorted(specials, key=lambda s: s[0])
    parts = ['(?m)^' + min_]
    reps = []
    refs = {}
    n = 0
    pos = 0
    for i, rx, name, out in specials:
        gap = i - pos
        if gap:
            n += 1
            parts.append('(.{%d})' % gap)
            reps.append('\\g<%d>' % n)
        if name:
            n += 1
            parts.append('(' + rx + ')')
            refs[name] = '\\g<%d>' % n
        else:
            parts.append(rx)
        reps.append(out)
        pos = i + 1
    gap = 72 - pos
    if gap:
        n += 1
        parts.append('(.{%d})' % gap)
        reps.append('\\g<%d>' % n)
    n += 1
    parts.append(' (%s) %s$' % (cast, ep))
    reps.append(' \\g<%d> %s' % (n, newep))
    rep = '\\g<0>\n' + mout + ''.join(reps)
    add(''.join(parts), rep.format(**refs) if '{' in rep else rep)

def movegen():
    # sliders
    for r in range(8):
        for c in range(8):
            f = idx(r, c)
            for dirs, cls in ((ROOK, '[QR]'), (BISH, '[QB]')):
                for dr, dc in dirs:
                    path = []
                    rr, cc = r + dr, c + dc
                    while inb(rr, cc):
                        t = idx(rr, cc)
                        sp = [(f, cls, 'f', '.'), (t, ANYT, None, '{f}')]
                        sp += [(p, r'\.', None, '.') for p in path]
                        gen('S', 'M', sp)
                        if True:
                            path.append(t)
                        rr += dr; cc += dc
            for dirs, ch in ((KN, 'N'), (KG, 'K')):
                for dr, dc in dirs:
                    rr, cc = r + dr, c + dc
                    if inb(rr, cc):
                        gen('S', 'M', [(f, ch, None, '.'), (idx(rr, cc), ANYT, None, ch)])
            # pawns
            if 1 <= r <= 6:
                nr = r - 1
                out = 'Q' if nr == 0 else 'P'
                gen('S', 'M', [(f, 'P', None, '.'), (idx(nr, c), r'\.', None, out)])
                if r == 6:
                    gen('S', 'M', [(f, 'P', None, '.'), (idx(5, c), r'\.', None, '.'),
                                   (idx(4, c), r'\.', None, 'P')], newep='abcdefgh'[c])
                for dc in (-1, 1):
                    if inb(nr, c + dc):
                        gen('S', 'M', [(f, 'P', None, '.'), (idx(nr, c + dc), CAPT, None, out)])
                if r == 3:
                    for dc in (-1, 1):
                        if inb(2, c + dc):
                            fl = 'abcdefgh'[c + dc]
                            gen('S', 'M', [(f, 'P', None, '.'), (idx(3, c + dc), 'p', None, '.'),
                                           (idx(2, c + dc), r'\.', None, 'P')], ep=fl)

def attackers():
    """list of token lists (idx,rx) ; K token included"""
    res = []
    for r in range(8):
        for c in range(8):
            k = idx(r, c)
            for dirs, cls in ((ROOK, '[qr]'), (BISH, '[qb]')):
                for dr, dc in dirs:
                    path = []
                    rr, cc = r + dr, c + dc
                    while inb(rr, cc):
                        t = idx(rr, cc)
                        res.append([(k, 'K'), (t, cls)] + [(p, r'\.') for p in path])
                        path.append(t)
                        rr += dr; cc += dc
            for dr, dc in KN:
                if inb(r + dr, c + dc):
                    res.append([(k, 'K'), (idx(r + dr, c + dc), 'n')])
            for dr, dc in KG:
                if inb(r + dr, c + dc):
                    res.append([(k, 'K'), (idx(r + dr, c + dc), 'k')])
            for dc in (-1, 1):
                if inb(r - 1, c + dc):
                    res.append([(k, 'K'), (idx(r - 1, c + dc), 'p')])
    return res

ATT = attackers()
def checkpass(marker):
    for toks in ATT:
        toks = sorted(toks)
        parts = ['(?m)^' + marker]
        pos = 0
        for i, rx in toks:
            if i - pos: parts.append('.{%d}' % (i - pos))
            parts.append(rx)
            pos = i + 1
        parts.append(r'.*\n')
        add(''.join(parts), '')

# normalisation
add(r'^(\S+) w (\S+) (\S+)(?: \d+)*$', 'S\\1/ \\2 \\3\n')
add(r' ([a-h])6\n', ' \\1\n')
add(r'/', '/')  # no-op placeholder removed below
pairs.pop()
for d in range(1, 9):
    add(str(d), '.' * d)
# row separators: every row needs trailing '/', rows joined by '/', last gets '/' appended above
movegen()
# castling candidates
gen('S', 'C', [(67, 'K', None, 'K'), (68, r'\.', None, '.'), (69, r'\.', None, '.'), (70, 'R', None, 'R')], cast='[KQkq-]*K[KQkq-]*')
gen('S', 'E', [(63, 'R', None, 'R'), (64, r'\.', None, '.'), (65, r'\.', None, '.'), (66, r'\.', None, '.'), (67, 'K', None, 'K')], cast='[KQkq-]*Q[KQkq-]*')
checkpass('[CE]')
add(r'(?m)^C(.{67})K\.', 'D\\g<1>.K')
add(r'(?m)^E(.{63})R\.\.\.K', 'F\\g<1>R..K.')
checkpass('[DF]')
add(r'(?m)^D(.{67})\.K\.R', 'M\\g<1>.RK.')
add(r'(?m)^F(.{63})R\.\.K\.', 'M\\g<1>..KR.')
add(r'(?m)^S.*\n', '')
checkpass('M')
# castling rights
add(r'(?m)^(M(?=.{67}[^K]|.{70}[^R]).{72} [^ ]*?)K', '\\1')
add(r'(?m)^(M(?=.{67}[^K]|.{63}[^R]).{72} [^ ]*?)Q', '\\1')
add(r'(?m)^(M(?=.{4}[^k]|.{7}[^r]).{72} [^ ]*?)k', '\\1')
add(r'(?m)^(M(?=.{4}[^k]|.{0}[^r]).{72} [^ ]*?)q', '\\1')
add(r'(?m)^(M.{72} )(?= )', '\\1-')
# output
add(r'(?m)^M', '')
add(r'(?m)/ ', ' b ')
add(r'(?m) ([a-h])$', ' \\g<1>3 0 0')
add(r'(?m) -$', ' - 0 0')
for n in range(8, 0, -1):
    add(r'\.{%d}' % n, str(n))
add(r'\n\Z', '')
json.dump(pairs, open('/app/re.json', 'w'))
print(len(pairs))
