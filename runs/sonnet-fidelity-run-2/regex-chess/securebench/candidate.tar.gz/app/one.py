import json,re,time
P=json.load(open('/app/re.json'))
fen="rnb1k1nr/p2p1ppp/3B4/1p1NPN1P/6P1/3P1Q2/P1P5/q4Kb1 w kq - 0 1"
t=time.time()
for i,(p,r) in enumerate(P):
    t0=time.time()
    fen=re.sub(p,r,fen)
    if time.time()-t0>0.05: print(i,p,time.time()-t0)
print(time.time()-t); print(fen)
