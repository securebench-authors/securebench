import random, chess, sys
sys.path.insert(0,'/app')
from check import ChessGameTester
t=ChessGameTester()
random.seed(int(sys.argv[1]))
n=0
for g in range(int(sys.argv[2])):
    print("game",g,flush=True)
    b=chess.Board()
    if g%3==0:
        # bias: castling/promo-rich
        pass
    for ply in range(200):
        if b.is_game_over(): break
        if b.turn==chess.WHITE and any(True for _ in b.legal_moves):
            t.verify_legal_moves(b.fen()); n+=1
        ms=list(b.legal_moves)
        # prefer captures/promos/castles/ep sometimes
        pri=[m for m in ms if b.is_capture(m) or m.promotion or b.is_castling(m)]
        b.push(random.choice(pri) if pri and random.random()<0.4 else random.choice(ms))
print("ok",n)
