;; Metacircular evaluator for the Scheme dialect implemented by interp.py.
;; Reads one line (a file path) from stdin, then interprets that file.

(define (cadr x) (car (cdr x)))
(define (cddr x) (cdr (cdr x)))
(define (caddr x) (car (cdr (cdr x))))
(define (cdddr x) (cdr (cdr (cdr x))))

;; A closure is (tag params body . env); the tag is a unique pair.
(define closure-tag (cons 'closure '()))
(define (make-closure params body env)
  (cons closure-tag (cons params (cons body env))))
(define (closure-params c) (car (cdr c)))
(define (closure-body c) (car (cdr (cdr c))))
(define (closure-env c) (cdr (cdr (cdr c))))

;; An environment is (frame . parent). A local frame is an alist of
;; (name . value) bindings.  The global frame (whose parent is '()) is a
;; binary search tree of bindings ordered by symbol name, node = (binding left . right).
(define halted #f)

(define (find-binding name frame)
  (cond ((null? frame) #f)
        ((eq? name (car (car frame))) (car frame))
        (else (find-binding name (cdr frame)))))

(define (bst-find name node)
  (if (null? node)
      #f
      (let ((k (car (car node))))
        (cond ((eq? name k) (car node))
              ((< name k) (bst-find name (cadr node)))
              (else (bst-find name (cddr node)))))))

;; Insert binding b into non-empty tree node.
(define (bst-insert! node b)
  (let ((k (car (car node))))
    (if (< (car b) k)
        (if (null? (cadr node))
            (set-car! (cdr node) (cons b (cons '() '())))
            (bst-insert! (cadr node) b))
        (if (null? (cddr node))
            (set-cdr! (cdr node) (cons b (cons '() '())))
            (bst-insert! (cddr node) b)))))

(define (env-find name env)
  (if (null? (cdr env))
      (bst-find name (car env))
      (let ((b (find-binding name (car env))))
        (if b b (env-find name (cdr env))))))

(define (error-undefined name)
  (display "Error: Undefined variable: ")
  (display name)
  (newline)
  (set! halted #t)
  '())

(define (lookup name env)
  (let ((b (env-find name env)))
    (if b (cdr b) (error-undefined name))))

(define (env-define! env name val)
  (if (null? (cdr env))
      (let ((b (bst-find name (car env))))
        (if b
            (set-cdr! b val)
            (bst-insert! (car env) (cons name val))))
      (let ((b (find-binding name (car env))))
        (if b
            (set-cdr! b val)
            (set-car! env (cons (cons name val) (car env)))))))

(define (env-set! env name val)
  (let ((b (env-find name env)))
    (if b (set-cdr! b val) (error-undefined name))))

(define (bind-params ps args)
  (if (null? ps)
      '()
      (cons (cons (car ps) (car args))
            (bind-params (cdr ps) (cdr args)))))

(define (eval-args aps env)
  (if (null? aps)
      '()
      (cons ((car aps) env) (eval-args (cdr aps) env))))

(define (eval-let-bindings names inits env)
  (if (null? names)
      '()
      (cons (cons (car names) ((car inits) env))
            (eval-let-bindings (cdr names) (cdr inits) env))))

(define (apply-prim f args)
  (cond ((null? args) (f))
        ((null? (cdr args)) (f (car args)))
        ((null? (cddr args)) (f (car args) (cadr args)))
        ((null? (cdddr args)) (f (car args) (cadr args) (caddr args)))
        (else (apply-prim f (cons (f (car args) (cadr args) (caddr args))
                                  (cdddr args))))))

(define (apply-proc f args)
  (if (eq? (car f) closure-tag)
      ((closure-body f)
       (cons (bind-params (closure-params f) args) (closure-env f)))
      (apply-prim f args)))

;; analyze: compile an expression into a procedure of one argument (env).
(define (map-analyze es)
  (if (null? es)
      '()
      (cons (analyze (car es)) (map-analyze (cdr es)))))

(define (analyze-seq es)
  (cond ((null? es) (lambda (env) '()))
        ((null? (cdr es)) (analyze (car es)))
        (else (analyze-seq2 (analyze (car es)) (analyze-seq (cdr es))))))

(define (analyze-seq2 f r)
  (lambda (env) (f env) (r env)))

(define (analyze-cond clauses)
  (cond ((null? clauses) (lambda (env) '()))
        ((eq? (car (car clauses)) 'else) (analyze-seq (cdr (car clauses))))
        (else (analyze-cond2 (analyze (car (car clauses)))
                             (analyze-seq (cdr (car clauses)))
                             (analyze-cond (cdr clauses))))))

(define (analyze-cond2 t b r)
  (lambda (env) (if (t env) (b env) (r env))))

(define (analyze-if t c a)
  (lambda (env) (if (t env) (c env) (a env))))

(define (analyze-app fp aps)
  (cond ((null? aps)
         (lambda (env) (apply-proc (fp env) '())))
        ((null? (cdr aps))
         (analyze-app1 fp (car aps)))
        (else
         (lambda (env) (apply-proc (fp env) (eval-args aps env))))))

(define (analyze-app1 fp a)
  (lambda (env) (apply-proc (fp env) (cons (a env) '()))))

(define (analyze-lambda params body)
  (lambda (env) (make-closure params body env)))

(define (analyze-define name vp)
  (lambda (env) (env-define! env name (vp env))))

(define (analyze-set name vp)
  (lambda (env) (env-set! env name (vp env))))

(define (analyze-let names inits body)
  (lambda (env) (body (cons (eval-let-bindings names inits env) env))))

(define (let-names bs)
  (if (null? bs) '() (cons (car (car bs)) (let-names (cdr bs)))))
(define (let-inits bs)
  (if (null? bs) '() (cons (analyze (cadr (car bs))) (let-inits (cdr bs)))))

(define (analyze e)
  (cond ((symbol? e) (lambda (env) (lookup e env)))
        ((not (pair? e)) (lambda (env) e))
        ((eq? (car e) 'quote) (analyze-const (cadr e)))
        ((eq? (car e) 'if)
         (analyze-if (analyze (cadr e))
                     (analyze (caddr e))
                     (if (null? (cdddr e))
                         (lambda (env) '())
                         (analyze (car (cdddr e))))))
        ((eq? (car e) 'define)
         (if (pair? (cadr e))
             (analyze-define (car (cadr e))
                             (analyze-lambda (cdr (cadr e)) (analyze-seq (cddr e))))
             (analyze-define (cadr e) (analyze (caddr e)))))
        ((eq? (car e) 'set!) (analyze-set (cadr e) (analyze (caddr e))))
        ((eq? (car e) 'lambda)
         (analyze-lambda (cadr e) (analyze-seq (cddr e))))
        ((eq? (car e) 'let)
         (analyze-let (let-names (cadr e)) (let-inits (cadr e)) (analyze-seq (cddr e))))
        ((eq? (car e) 'begin) (analyze-seq (cdr e)))
        ((eq? (car e) 'progn) (analyze-seq (cdr e)))
        ((eq? (car e) 'cond) (analyze-cond (cdr e)))
        (else (analyze-app (analyze (car e)) (map-analyze (cdr e))))))

(define (analyze-const v) (lambda (env) v))

(define (eval e env) ((analyze e) env))

(define prims (cons (cons 'else #t) (cons '() '())))
(define global-env (cons prims '()))
(define (add-prim! name val)
  (bst-insert! prims (cons name val)))
(add-prim! '< <)
(add-prim! 'cons cons)
(add-prim! 'not not)
(add-prim! '/ /)
(add-prim! 'cdr cdr)
(add-prim! 'or or)
(add-prim! 'fclose fclose)
(add-prim! 'eq? eq?)
(add-prim! 'pair? pair?)
(add-prim! '- -)
(add-prim! 'display display)
(add-prim! 'fgetchr fgetchr)
(add-prim! 'set-cdr! set-cdr!)
(add-prim! '* *)
(add-prim! 'car car)
(add-prim! 'symbol? symbol?)
(add-prim! 'fopen fopen)
(add-prim! 'null? null?)
(add-prim! 'chr chr)
(add-prim! 'putchr putchr)
(add-prim! 'string? string?)
(add-prim! 'set-car! set-car!)
(add-prim! 'read read)
(add-prim! '> >)
(add-prim! '<= <=)
(add-prim! 'and and)
(add-prim! 'fdisplay fdisplay)
(add-prim! 'fread fread)
(add-prim! 'number? number?)
(add-prim! '+ +)
(add-prim! 'getchr getchr)
(add-prim! '= =)
(add-prim! 'newline newline)
(add-prim! 'symbol symbol)
(add-prim! '>= >=)
(add-prim! 'fputchr fputchr)
(add-prim! 'equal? equal?)

(define (run-port port)
  (let ((e (fread port)))
    (if (null? e)
        '()
        (begin
          (eval e global-env)
          (if halted '() (run-port port))))))

(run-port (fopen (read) "r"))
