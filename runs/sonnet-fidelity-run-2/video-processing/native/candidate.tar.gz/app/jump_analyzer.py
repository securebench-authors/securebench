import sys, cv2, numpy as np

HURDLE_X = 495
TAKEOFF_BEFORE = 7   # frames before centroid passes hurdle
LAND_AFTER = 2


def track(path):
    c = cv2.VideoCapture(path)
    ok, f0 = c.read()
    g0 = cv2.GaussianBlur(cv2.cvtColor(f0, cv2.COLOR_BGR2GRAY), (7, 7), 0)
    k = np.ones((5, 5), np.uint8)
    res = []
    while True:
        ok, f = c.read()
        if not ok:
            break
        g = cv2.GaussianBlur(cv2.cvtColor(f, cv2.COLOR_BGR2GRAY), (7, 7), 0)
        m = (cv2.absdiff(g, g0) > 35).astype(np.uint8)
        m[:, :] = cv2.morphologyEx(m, cv2.MORPH_OPEN, k)
        n, lab, st, cen = cv2.connectedComponentsWithStats(m)
        if n > 1:
            i = 1 + int(np.argmax(st[1:, 4]))
            if st[i, 4] > 1500 and st[i, 2] < 600:
                res.append((cen[i][0], st[i, 4]))
                continue
        res.append(None)
    return res


def analyze(path):
    r = track(path)
    # frame indices are 1-based offsets into r (frame 0 is background)
    xs = [(i + 1, v[0]) for i, v in enumerate(r) if v]
    # find crossing of hurdle x moving right->left
    cross = None
    for (a, xa), (b, xb) in zip(xs, xs[1:]):
        if xa >= HURDLE_X > xb and b - a <= 3:
            cross = a + (xa - HURDLE_X) / (xa - xb) * (b - a)
            break
    if cross is None:
        cross = xs[len(xs) // 2][0] if xs else 60
    cross = int(round(cross))
    return cross - TAKEOFF_BEFORE, cross + LAND_AFTER, cross


if __name__ == "__main__":
    t, l, _ = analyze(sys.argv[1] if len(sys.argv) > 1 else "/app/example_video.mp4")
    with open("/app/output.toml", "w") as fh:
        fh.write("jump_takeoff_frame_number = %d\njump_land_frame_number = %d\n" % (t, l))
