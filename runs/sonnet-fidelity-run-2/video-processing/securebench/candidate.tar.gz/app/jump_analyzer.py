import sys, cv2, numpy as np

def analyze(path):
    c = cv2.VideoCapture(path)
    ok, f0 = c.read()
    g0 = cv2.GaussianBlur(cv2.cvtColor(f0, cv2.COLOR_BGR2GRAY), (9, 9), 0)
    ker = np.ones((5, 5), np.uint8)
    rows = []  # (frame, foot_y)
    i = 0
    while True:
        ok, f = c.read()
        if not ok:
            break
        i += 1
        g = cv2.GaussianBlur(cv2.cvtColor(f, cv2.COLOR_BGR2GRAY), (9, 9), 0)
        m = (cv2.absdiff(g, g0) > 30).astype(np.uint8)
        m[:120] = 0  # ignore top overlay/noise
        m = cv2.morphologyEx(m, cv2.MORPH_OPEN, ker)
        ys, xs = np.nonzero(m)
        if len(xs) > 3000:
            rows.append((i, int(np.percentile(ys, 99))))
    fr = np.array([r[0] for r in rows]); ft = np.array([r[1] for r in rows])
    base = np.median(ft)
    air = ft < base - 12
    # longest run of airborne frames
    best, cur = (0, 0), None
    for k, a in enumerate(air):
        if a:
            cur = (cur[0], k) if cur else (k, k)
            if cur[1] - cur[0] > best[1] - best[0]:
                best = cur
        else:
            cur = None
    s, e = best
    return int(fr[s]), int(fr[min(e + 1, len(fr) - 1)])

if __name__ == "__main__":
    t, l = analyze(sys.argv[1] if len(sys.argv) > 1 else "/app/example_video.mp4")
    with open("/app/output.toml", "w") as fh:
        fh.write("jump_takeoff_frame_number = %d\njump_land_frame_number = %d\n" % (t, l))
