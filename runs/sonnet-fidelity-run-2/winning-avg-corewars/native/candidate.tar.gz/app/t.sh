for o in stone paper vampire snake g2-clear; do echo -n "$o "; pmars -b -r 100 -f ${1:-my_warrior.red} warriors/$o.red | tail -1; done
