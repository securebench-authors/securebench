for o in stone vampire paper snake g2-clear; do echo -n "$o: "; pmars -b -r 100 -f my_warrior.red warriors/$o.red | tail -1; done
