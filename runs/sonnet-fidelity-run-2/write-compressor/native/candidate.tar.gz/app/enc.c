#include <stdio.h>
#include <string.h>
static int cc[1000000];
static unsigned char dg[100000];int nd=0;long rng=1;
void add(long v){int k=nd-1;while(v){v+=dg[k];dg[k]=v%255;v/=255;k--;}}
void bit(int ctx,int b){
 if(rng<255){rng*=255;dg[nd++]=0;}
 int*c=cc+ctx*2;long sp=rng*(c[0]+1)/(c[0]+c[1]+2);
 if(b){add(sp);rng-=sp;}else rng=sp;
 c[b]++;fprintf(stderr,"%d:%d ",ctx,b);}
void integer(int t0,int ctx,int v){
 ctx*=99;int x=v+(1<<t0),L=0;while(x>>L)L++;int k=L-t0-1,t=t0;
 for(int i=0;i<k;i++){t++;bit(t+ctx,0);}
 t++;bit(t+ctx,1);
 for(int i=L-2;i>=0;i--)bit(ctx,(x>>i)&1);}
int main(){static unsigned char d[10000];int n=fread(d,1,10000,fopen("data.txt","rb"));
 integer(9,0,n);int i=0;
 while(i<n){int bl=0,bo=0;
  for(int j=0;j<i;j++){int l=0;while(i+l<n&&d[j+l]==d[i+l])l++;if(l>bl){bl=l;bo=i-j;}}
  if(bl>=3){bit(1,1);integer(5,2,bo-1);integer(2,3,bl-1);i+=bl;}
  else{bit(1,0);bit(8,0);integer(4,9,d[i]);i++;}}
 FILE*f=fopen("data.comp","wb");for(int k=0;k<nd;k++)fputc(dg[k]+1,f);fclose(f);printf("%d\n",nd);}
