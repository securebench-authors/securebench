import sys
d=open('data.txt','rb').read()
assert all(0<c<128 for c in d)
cnt={}
low=0;rng=1;nd=0
def bit(ctx,b):
    global low,rng,nd
    if rng<255: rng*=255;low*=255;nd+=1
    c=cnt.setdefault(ctx,[0,0])
    sp=rng*(c[0]+1)//(c[0]+c[1]+2)
    if b: low+=sp;rng-=sp
    else: rng=sp
    c[b]+=1
def integer(t0,ctx,v):
    ctx*=99
    x=v+(1<<t0);L=x.bit_length();k=L-t0-1
    assert k>=0
    t=t0
    for i in range(k): t+=1;bit(t+ctx,0)
    t+=1;bit(t+ctx,1)
    for i in range(L-2,-1,-1): bit(ctx,(x>>i)&1)
integer(9,0,len(d))
i=0;n=len(d)
while i<n:
    bl=0;bo=0
    for j in range(max(0,i-10000),i):
        l=0
        while i+l<n and d[j+l]==d[i+l]: l+=1
        if l>bl: bl=l;bo=i-j
    if bl>=3:
        bit(1,1);integer(5,2,bo-1);integer(2,3,bl-1);i+=bl
    else:
        bit(1,0);bit(8,0);integer(4,9,d[i]);i+=1
out=bytes(((low//255**(nd-1-k))%255)+1 for k in range(nd))
open('data.comp','wb').write(out);print(len(out))
