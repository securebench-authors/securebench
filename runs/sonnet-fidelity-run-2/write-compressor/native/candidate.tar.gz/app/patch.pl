undef $/;$_=<>;
s/integer\(9,0,n\);int i=0;/int i=0,T=1;{int p=0;while(p<n){int bl=0;for(int j=0;j<p;j++){int l=0;while(p+l<n&&d[j+l]==d[p+l])l++;if(l>bl)bl=l;}p+=bl>=MINL?bl:1;T++;}}\n integer(9,0,T);/;
s/ FILE\*f=/ bit(1,0);bit(8,0);integer(4,9,0);\n FILE*f=/;
s/bl>=3/bl>=MINL/;
s/fprintf\(stderr,"%d:%d ",ctx,b\);//;
print;
