#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
unsigned char data[10000]; int N;
int cc[1000000];
unsigned char dig[100000]; int nd=0; long rng=1;
void addlow(long v){int p=nd-1;while(v&&p>=0){v+=dig[p];dig[p]=v%255;v/=255;p--;} if(v){fprintf(stderr,"overflow\n");exit(1);}}
void bit(int ctx,int b){
  if(rng<255){rng*=255;dig[nd++]=0;}
  int*c=cc+ctx*2;
  long split=rng*(c[0]+1)/(c[0]+c[1]+2);
  if(b){addlow(split);rng-=split;}else rng=split;
  c[b]++;
}
void integer(int t0,int ctx,int v){
  int x=v+(1<<t0),k=0;while((x>>(k+1)))k++;
  ctx*=99;
  for(int t=t0+1;t<=k;t++)bit(t+ctx,0);
  bit(k+1+ctx,1);
  for(int i=k-1;i>=0;i--)bit(ctx,(x>>i)&1);
}
int tk[10000][3],nt=0;
int main(){
  FILE*f=fopen("data.txt","rb");N=fread(data,1,9000,f);data[N++]=0;
  int i=0;
  while(i<N){
    int bl=0,bo=0;
    for(int j=(i>300?i-300:0);j<i;j++){int l=0;while(i+l<N&&data[j+l]==data[i+l]&&l<40)l++;if(l>=bl&&l>0){bl=l;bo=i-j;}}
    if(bl>=3){tk[nt][0]=1;tk[nt][1]=bo;tk[nt][2]=bl;i+=bl;}
    else{tk[nt][0]=0;tk[nt][1]=data[i];i++;}
    nt++;
  }
  integer(9,0,nt);
  for(i=0;i<nt;i++){
    if(tk[i][0]){bit(1,1);integer(5,2,tk[i][1]-1);integer(2,3,tk[i][2]-1);}
    else{bit(1,0);bit(8,0);integer(4,9,tk[i][1]);}
  }
  unsigned char out[100000];int n=nd;
  for(i=0;i<n;i++)out[i]=dig[i]+1;
  while(n&&out[n-1]==255)n--;
  fprintf(stderr,"tokens %d bytes %d\n",nt,n);
  f=fopen("data.comp","wb");fwrite(out,1,n,f);fclose(f);
}
