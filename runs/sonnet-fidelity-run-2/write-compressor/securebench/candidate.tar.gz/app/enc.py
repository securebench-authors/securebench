import sys, math
from fractions import Fraction
data=open('data.txt','rb').read()+b'\0'
N=len(data)
class Enc:
    def __init__(s):
        s.cc={};s.low=0;s.rng=1;s.n=0;s.cost=0
    def bit(s,ctx,b):
        if s.rng<255:
            s.rng*=255;s.low*=255;s.n+=1
        c=s.cc.setdefault(ctx,[0,0])
        split=s.rng*(c[0]+1)//(c[0]+c[1]+2)
        if b: s.low+=split; s.rng-=split
        else: s.rng=split
        c[b]+=1
    def integer(s,t0,ctx,v):
        x=v+(1<<t0);k=x.bit_length()-1;ctx*=99
        for t in range(t0+1,k+1): s.bit(t+ctx,0)
        s.bit(k+1+ctx,1)
        for i in range(k-1,-1,-1): s.bit(ctx,(x>>i)&1)
def cost_est(ctxcc,ctx,b):
    c=ctxcc.get(ctx,[0,0]);return -math.log2((c[b]+1)/(c[0]+c[1]+2))
def tokens_greedy():
    toks=[];i=0
    while i<N:
        bl=0;bo=0
        for j in range(max(0,i-300),i):
            l=0
            while i+l<N and data[j+l]==data[i+l] and l<40: l+=1
            if l>=bl and l>0: bl=l;bo=i-j
        if bl>=3: toks.append(('c',bo,bl));i+=bl
        else: toks.append(('l',data[i]));i+=1
    return toks
def encode(toks):
    e=Enc();e.integer(9,0,len(toks))
    for t in toks:
        if t[0]=='c':
            e.bit(1,1);e.integer(5,2,t[1]-1);e.integer(2,3,t[2]-1)
        else:
            e.bit(1,0);e.bit(8,0);e.integer(4,9,t[1])
    # pick F in [low,low+rng) with trailing 254 digits maximal
    lo,hi=e.low,e.low+e.rng-1
    F=hi
    # try to round up to many trailing max digits: F = largest value <=hi of form ...254 254; simple search
    best=lo
    for k in range(e.n,-1,-1):
        m=255**k
        cand=(hi+1)//m*m-1 + 0
        cand=((hi+1)//m)*m - 1  # ends with k digits of 254
        if cand>=lo: best=cand;break
    F=best
    digs=[]
    for _ in range(e.n): digs.append(F%255);F//=255
    digs=digs[::-1]
    out=bytes(d+1 for d in digs)
    return out.rstrip(b'\xff')
toks=tokens_greedy()
out=encode(toks)
print(len(toks),len(out),file=sys.stderr)
open('data.comp','wb').write(out)
