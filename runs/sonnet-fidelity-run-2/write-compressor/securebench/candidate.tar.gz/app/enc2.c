#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
unsigned char data[10000]; int N;
int cc[1000000];
unsigned char dig[100000]; int nd=0; long rng=1;
void addlow(long v){int p=nd-1;while(v&&p>=0){v+=dig[p];dig[p]=v%255;v/=255;p--;} if(v){fprintf(stderr,"overflow\n");exit(1);}}
void bit(int ctx,int b){
  if(rng<255){rng*=255;dig[nd++]=0;}
  int*c=cc+ctx*2;
  long split=rng*(c[0]+1)/(c[0]+c[1]+2);
  if(b){addlow(split);rng-=split;}else rng=split;
  c[b]++;
}
void integer(int t0,int ctx,int v){
  int x=v+(1<<t0),k=0;while((x>>(k+1)))k++;
  ctx*=99;
  for(int t=t0+1;t<=k;t++)bit(t+ctx,0);
  bit(k+1+ctx,1);
  for(int i=k-1;i>=0;i--)bit(ctx,(x>>i)&1);
}
int tk[10000][3],nt=0;
int cs[1000000]; int have=0;
double bc(int ctx,int b){int*c=cs+ctx*2;return -log2((c[b]+0.5)/(c[0]+c[1]+1.0));}
double ic(int t0,int ctx,int v){
  int x=v+(1<<t0),k=0;while((x>>(k+1)))k++;ctx*=99;double s=0;
  for(int t=t0+1;t<=k;t++)s+=bc(t+ctx,0);
  s+=bc(k+1+ctx,1);
  // mantissa approx 1 bit each
  for(int i=k-1;i>=0;i--)s+=bc(ctx,(x>>i)&1);
  return s;
}
double best[10000];int bt[10000][3];
void parse(){
  best[N]=0;
  for(int i=N-1;i>=0;i--){
    best[i]=bc(1,0)+bc(8,0)+ic(4,9,data[i])+best[i+1];bt[i][0]=0;
    int maxl=0;
    for(int l=1;l<=60&&i+l<=N;l++){
      double bo=1e9;int bj=-1;
      for(int j=0;j<i;j++){
        int m=0;while(m<l&&data[j+m]==data[i+m])m++;
        if(m<l)continue;
        double c=ic(5,2,i-j-1);if(c<bo){bo=c;bj=i-j;}
      }
      if(bj<0)break;
      double c=bc(1,1)+bo+ic(2,3,l-1)+best[i+l];
      if(c<best[i]){best[i]=c;bt[i][0]=1;bt[i][1]=bj;bt[i][2]=l;}
    }
  }
  nt=0;int i=0;
  while(i<N){tk[nt][0]=bt[i][0];if(bt[i][0]){tk[nt][1]=bt[i][1];tk[nt][2]=bt[i][2];i+=bt[i][2];}else{tk[nt][1]=data[i];i++;}nt++;}
}
int emit(){
  memset(cc,0,sizeof cc);nd=0;rng=1;memset(dig,0,sizeof dig);
  integer(9,0,nt);
  for(int i=0;i<nt;i++){
    if(tk[i][0]){bit(1,1);integer(5,2,tk[i][1]-1);integer(2,3,tk[i][2]-1);}
    else{bit(1,0);bit(8,0);integer(4,9,tk[i][1]);}
  }
  return nd;
}
int main(){
  FILE*f=fopen("data.txt","rb");N=fread(data,1,9000,f);data[N++]=0;
  for(int i=0;i<2*1000000;i++)cs[i/2*0+i%1000000]=0;
  int bestn=1<<30;
  for(int it=0;it<8;it++){
    parse(); int n=emit();
    fprintf(stderr,"iter %d tokens %d bytes %d\n",it,nt,n);
    if(n<bestn){bestn=n;unsigned char out[100000];for(int i=0;i<n;i++)out[i]=dig[i]+1;int m=n;while(m&&out[m-1]==255)m--;
      f=fopen("data.comp","wb");fwrite(out,1,m,f);fclose(f);}
    memcpy(cs,cc,sizeof cs);
  }
}
