undef $/; $_=<STDIN>;
s/int tk\[10000\]\[3\],nt=0;.*//s;
print $_;
